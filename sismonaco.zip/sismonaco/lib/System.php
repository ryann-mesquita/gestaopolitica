<?php

namespace lib;

class System extends Router {
	
	private $url;
	private $explode;
	private $module;
	private $controller;
	private $action;
	private $params;
	private $init;
	
	
	public function __construct() {
	
		$this->_limpaTexto();
		$this->setUrl();
		$this->setExplode();
		$this->setModule();
		$this->setController();
		$this->setAction();
		$this->setParams();
	}
	
	private function setUrl() {
		$this->url = isset($_GET['url']) ? $_GET['url'] : 'index/index';
	}
	
	private function setExplode() {
		$this->explode = explode('/', $this->url);
	}
	
	private function setModule() {
		foreach ($this->modules as $i => $v) {
			if ($this->onDefault && $this->explode[0] == $i) {
				$this->module = array('modulo' => $v['modulo'],'des_modulo' => $v['des_modulo']);
				$this->onDefault = false;
			}
		}
		
		$this->module = array ('modulo' => empty($this->module['modulo']) ? $this->moduleOnDefault['modulo'] : $this->module['modulo'],'des_modulo' => empty($this->module['des_modulo']) ? $this->moduleOnDefault['des_modulo'] : $this->module['des_modulo']);
		if (!defined('APP_AREA')){
			define('APP_AREA', $this->module['des_modulo']);
		}
	}
	
	public function getModule() {
		return $this->module;
	}
	
	private function setController() {
		$this->controller = $this->onDefault ? $this->explode[0] :
		(empty($this->explode[1]) || is_null($this->explode[1]) || !isset($this->explode[1]) ? 'index' : $this->explode[1]);
		@$this->controller = array('controle' => $this->controllers["$this->controller"]["controle"],'des_controle' => $this->controller);
	}
	
	public function getController() {
		return $this->controller;
	}
	
	private function setAction() {
		$this->action = $this->onDefault ?
		(!isset($this->explode[1]) || is_null($this->explode[1]) || empty($this->explode[1]) ? 'index' : $this->explode[1]) :
		(!isset($this->explode[2]) || is_null($this->explode[2]) || empty($this->explode[2]) ? 'index' : $this->explode[2]);
		@$this->action = array('acao' => $this->actions["$this->action"]["acao"] , 'des_acao' => $this->action);
	}
	
	public function getAction() {
		return $this->action;
	}
	
	private function setParams() {
		if ($this->onDefault) {
			unset($this->explode[0], $this->explode[1]);
		} else {
			unset($this->explode[0], $this->explode[1], $this->explode[2]);
		}
		
		if (end($this->explode) == null) {
			array_pop($this->explode);
		}
		
		if (empty($this->explode)) {
			$this->params = array();
		} else {
			foreach ($this->explode as $val) {
				$params[] = $val;
			}
			$this->params = $params;
		}
	}
	
	public function getParams($indice) {
		return isset($this->params[$indice]) ? $this->params[$indice] : null;
	}
	
	private function _validaController() {
		if (!(class_exists($this->init))) {
			header("HTTP/1.0 404 Not Found");
			define('ERROR', 'N�o foi localizado o Controle: ' . $this->controller['des_controle']);
			include("content/geral/shared/404_error.phtml");
			exit();
		}
	}
	
	private function _validaAction() {	
		if (!(method_exists($this->init, $this->action['des_acao']))) {
			header("HTTP/1.0 404 Not Found");
			define('ERROR', 'N�o foi localizada a Acao: ' . $this->action['des_acao']);
			include("content/geral/shared/404_error.phtml");
			exit();
		}
	}
	
	public function run() {
		$this->init = 'controller\\' . $this->module['des_modulo'] . '\\' . $this->controller['des_controle'] . 'Controller';
		$this->_validaController();
		$this->init = new $this->init();
		$this->_validaAction();
		$act = $this->action['des_acao'];
		$this->init->$act();
	}
	
	private function _limpaTexto() {
		if (isset($_POST)) {
			foreach ($_POST as $ind => $val) {
				$_POST[$ind] = $this->_regrasTexto($val);
			}
		}
		if (isset($_GET)) {
			foreach ($_GET as $ind => $val) {
				$_GET[$ind] = $this->_regrasTexto($val);
			}
		}
	}
	
	private function _regrasTexto($val) {	
		$search = array(
			'INSERT', 'insert',
			'UPDATE', 'update',
			'DELETE', 'delete',
			'SELECT', 'select',
			'FROM', 'from',
			'WHERE', 'where'
		);
		$texto = $val;
		$texto = str_replace("'", "´", $texto);
		$texto = str_replace($search, "", $texto);
		return $texto;
	}
}