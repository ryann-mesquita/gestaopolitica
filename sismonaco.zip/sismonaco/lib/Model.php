<?php

namespace lib;

class Model extends Config {
	
	protected $con;
	
	public function __construct() {
		$dbtns  = "(DESCRIPTION = (ADDRESS_LIST = (ADDRESS = (PROTOCOL = TCP)(HOST = ".self::srvMyhostOracle.")(PORT = ".self::srvMyportOracle.")))(CONNECT_DATA =(SERVICE_NAME = ".self::srvMyServiceNameOracle.")))";
		$options = [
			\PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,
			\PDO::ATTR_EMULATE_PREPARES => false,
			\PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
			\PDO::ATTR_CASE => \PDO::CASE_LOWER
		];
		try{
			//Conex�o com Oracle
			//$pdo = new PDO("oci:dbname=" . $dbtns . ";charset=utf8", $usuario, $senha, $options);
			$this->con = new \PDO("oci:dbname=" . $dbtns . ";charset=WE8MSWIN1252", self::srvMyuserOracle, self::srvMypassOracle);
			//$this->con->exec("set names " . self::OracleCharset);
			$this->con->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
			$this->con->beginTransaction();
			$sql = "ALTER SESSION SET NLS_DATE_FORMAT='DD/MM/YYYY'";
			$this->con->exec($sql);
			
		} catch (\PDOException $ex){
			die($ex->getMessage());
		}
	}
	
	public function Select($sql) {
		
		try {
			
			$state = $this->con->prepare($sql);
			$state->execute();
			
		} catch (\PDOException $ex){
			
			die($ex->getMessage() . " " . $sql);
			
		}
		$array = array();
		while($row = $state->fetchObject()){
			
			$array[] = $row;
		}
		
		return $array;
		$this->con = NULL;
	}
	
	public function Execute($sql) {
		
		$rs = array();
		$rs[3] = "";
		
		try {
			
			if (count($sql)>1){
				
				foreach ($sql as $i){
					
					$this->con->exec($i);
					$rs[3] .= ",".$i;
				}
				
				$rs[4] = 'sucesso';
				
			}else {
				
				$this->con->exec($sql[0]);
				$rs[3] = $sql[0];
				$rs[4] = 'sucesso';
			}
			
			$this->con->commit();
			return $rs;
			
		} catch (\PDOException $ex){
			
			$this->con->rollBack();
			$ex->errorInfo[3] = $sql[0];
			return $ex->errorInfo;
		}
		
		$this->con = NULL;
	}
	
	public function First($obj) {
		 
		if (isset($obj[0])){
			return $obj[0];
		} else {
			return null;
		}
	}
	
	public function setObject($obj, $Values, $Exits = true) {
		
		if (is_object($obj)){
			if (count($Values) > 0){
				foreach ($Values as $in => $va){
					if (property_exists($obj,$in) || $Exits){
						$obj->$in = $Values->$in;
					}
				}
			}
		}
	}
}