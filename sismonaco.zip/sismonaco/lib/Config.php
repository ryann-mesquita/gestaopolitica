<?php

namespace lib;

class Config {
	//Oracle Configura��es
//	const srvMyhostOracle = '10.0.1.40';
	const srvMyhostOracle = '10.3.101.21';
	const srvMyuserOracle = 'sismonaco';
	const srvMypassOracle = 'sism0n4c0php2020';
//	const srvMyServiceNameOracle = 'orion.grupomonaco.local';
	const srvMyServiceNameOracle = 'teste.grupomonaco.local';
	const srvMyportOracle = '1521';
	const OracleCharset = 'latin1';
	
	//Mysql Pandion
	const MyhostPandion = '10.3.101.56';
	const MyuserPandion = 'ejabberd';
	const MypassPandion = '3jabBer';
	const MydbnamePandion = 'ejabberd';
	const CharsetPandion = 'utf8';	
}
