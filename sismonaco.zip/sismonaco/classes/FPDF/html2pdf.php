<?php
use classes\FPDF;

require('fpdf.php');
require('htmlparser.inc');

function hex2dec($couleur = "#000000"){
	$R = substr($couleur, 1, 2);
	$rouge = hexdec($R);
	$V = substr($couleur, 3, 2);
	$vert = hexdec($V);
	$B = substr($couleur, 5, 2);
	$bleu = hexdec($B);
	$tbl_couleur = array();
	$tbl_couleur['R']=$rouge;
	$tbl_couleur['V']=$vert;
	$tbl_couleur['B']=$bleu;
	return $tbl_couleur;
}

//conversion pixel -> millimeter at 72 dpi
function px2mm($px){
	return $px*25.4/72;
}

function txtentities($html){
	$trans = get_html_translation_table(HTML_ENTITIES);
	$trans = array_flip($trans);
	return strtr($html, $trans);
}

class PDF_HTML extends FPDF{
	var $widths;
	var $aligns;
	protected $B;
	protected $I;
	protected $U;
	protected $HREF;
	protected $fontList;
	protected $issetfont;
	protected $issetcolor;
	
	function __construct($orientation='P', $unit='mm', $format='A4'){
		//Call parent constructor
		parent::__construct($orientation,$unit,$format);
		//Initialization
		$this->B=0;
		$this->I=0;
		$this->U=0;
		$this->HREF='';
		$this->fontlist=array('arial', 'times', 'courier', 'helvetica', 'symbol');
		$this->issetfont=false;
		$this->issetcolor=false;
	}
	
	function WriteHTML2($html){
		//HTML parser
		$html=str_replace("\n",' ',$html);
		$a=preg_split('/<(.*)>/U',$html,-1,PREG_SPLIT_DELIM_CAPTURE);
		foreach($a as $i=>$e)
		{
			if($i%2==0)
			{
				//Text
				if($this->HREF)
					$this->PutLink($this->HREF,$e);
					else
						$this->Write(5,$e);
			}
			else
			{
				//Tag
				if(substr($e, 0, 1) =='/')
					$this->CloseTag(strtoupper(substr($e,1)));
					else
					{
						//Extract attributes
						$a2=explode(' ',$e);
						$tag=strtoupper(array_shift($a2));
						$attr=array();
						foreach($a2 as $v)
						{
							if(preg_match('/([^=]*)=["\']?([^"\']*)/',$v,$a3))
								$attr[strtoupper(substr($a3, 1, 1))]=substr($a3, 2, 1);
						}
						$this->OpenTag($tag,$attr);
					}
			}
		}
	}
	
	function OpenTag($tag, $attr){
		//Opening tag
		if($tag=='B' || $tag=='I' || $tag=='U')
			$this->SetStyle($tag,true);
			if($tag=='A')
				$this->HREF=$attr['HREF'];
				if($tag=='BR')
					$this->Ln(5);
					if($tag=='P')
						$this->Ln(10);
	}
	
	function CloseTag($tag){
		//Closing tag
		if($tag=='B' || $tag=='I' || $tag=='U')
			$this->SetStyle($tag,false);
			if($tag=='A')
				$this->HREF='';
				if($tag=='P')
					$this->Ln(10);
	}
	
	function SetStyle($tag, $enable){
		//Modify style and select corresponding font
		$this->$tag+=($enable ? 1 : -1);
		$style='';
		foreach(array('B','I','U') as $s)
			if($this->$s>0)
				$style.=$s;
				$this->SetFont('',$style);
	}
	
	function PutLink($URL, $txt)
	{
		//Put a hyperlink
		$this->SetTextColor(0,0,255);
		$this->SetStyle('U',true);
		$this->Write(5,$txt,$URL);
		$this->SetStyle('U',false);
		$this->SetTextColor(0);
	}
	
	function WriteTable($data, $w){
		$this->SetLineWidth(.3);
		$this->SetFillColor(255,255,255);
		$this->SetTextColor(0);
		$this->SetFont('');
		foreach($data as $row)
		{
			$nb=0;
			for($i=0;$i<count($row);$i++)
				$nb=max($nb,$this->NbLines($w[$i],trim($row[$i])));
				$h=5*$nb;
				$this->CheckPageBreak($h);
				for($i=0;$i<count($row);$i++)
				{
					$x=$this->GetX();
					$y=$this->GetY();
					$this->Rect($x,$y,$w[$i],$h);
					$this->MultiCell($w[$i],5,trim($row[$i]),0,'C');
					//Put the position to the right of the cell
					$this->SetXY($x+$w[$i],$y);
				}
				$this->Ln($h);
				
		}
	}
	
	/*function NbLines($w, $txt){
		//Computes the number of lines a MultiCell of width w will take
		$cw=&$this->CurrentFont['cw'];
		if($w==0)
			$w=$this->w-$this->rMargin-$this->x;
			$wmax=($w-2*$this->cMargin)*1000/$this->FontSize;
			$s=str_replace("\r",'',$txt);
			$nb=strlen($s);
			if($nb>0 && substr($s, ($nb-1), 1) == "\n")
				$nb--;
				$sep=-1;
				$i=0;
				$j=0;
				$l=0;
				$nl=1;
				while($i<$nb)
				{
					$c=substr($s, $i, 1);
					if($c=="\n")
					{
						$i++;
						$sep=-1;
						$j=$i;
						$l=0;
						$nl++;
						continue;
					}
					if($c==' ')
						$sep=$i;
						$l+=$cw[$c];
						if($l>$wmax)
						{
							if($sep==-1)
							{
								if($i==$j)
									$i++;
							}
							else
								$i=$sep+1;
								$sep=-1;
								$j=$i;
								$l=0;
								$nl++;
						}
						else
							$i++;
				}
				return $nl;
	}*/
	function NbLines($w,$txt)
	{
		//Computes the number of lines a MultiCell of width w will take
		$cw=&$this->CurrentFont['cw'];
		if($w==0)
			$w=$this->w-$this->rMargin-$this->x;
			$wmax=($w-2*$this->cMargin)*1000/$this->FontSize;
			$s=str_replace("\r",'',$txt);
			$nb=strlen($s);
			if($nb>0 and $s[$nb-1]=="\n")
				$nb--;
				$sep=-1;
				$i=0;
				$j=0;
				$l=0;
				$nl=1;
				while($i<$nb)
				{
					$c=$s[$i];
					if($c=="\n")
					{
						$i++;
						$sep=-1;
						$j=$i;
						$l=0;
						$nl++;
						continue;
					}
					if($c==' ')
						$sep=$i;
						$l+=$cw[$c];
						if($l>$wmax)
						{
							if($sep==-1)
							{
								if($i==$j)
									$i++;
							}
							else
								$i=$sep+1;
								$sep=-1;
								$j=$i;
								$l=0;
								$nl++;
						}
						else
							$i++;
				}
				return $nl;
	}
	
	function CheckPageBreak($h){
		//If the height h would cause an overflow, add a new page immediately
		if($this->GetY()+$h>$this->PageBreakTrigger)
			$this->AddPage($this->CurOrientation);
	}
	
	function ReplaceHTML($html){
		$html = str_replace( '<li>', "\n<br> - " , $html );
		$html = str_replace( '<LI>', "\n - " , $html );
		$html = str_replace( '</ul>', "\n\n" , $html );
		$html = str_replace( '<strong>', "<b>" , $html );
		$html = str_replace( '</strong>', "</b>" , $html );
		$html = str_replace( '&#160;', "\n" , $html );
		$html = str_replace( '&nbsp;', " " , $html );
		$html = str_replace( '&quot;', "\"" , $html );
		$html = str_replace( '&#39;', "'" , $html );
		return $html;
	}
	
	function ParseTable($Table){
		$_var='';
		$htmlText = $Table;
		$parser = new HtmlParser($htmlText);
		while ($parser->parse())
		{
			if(strtolower($parser->iNodeName)=='table')
			{
				if($parser->iNodeType == NODE_TYPE_ENDELEMENT)
					$_var .='/::';
					else
						$_var .='::';
			}
			
			if(strtolower($parser->iNodeName)=='tr')
			{
				if($parser->iNodeType == NODE_TYPE_ENDELEMENT)
					$_var .='!-:'; //opening row
					else
						$_var .=':-!'; //closing row
			}
			if(strtolower($parser->iNodeName)=='td' && $parser->iNodeType == NODE_TYPE_ENDELEMENT)
			{
				$_var .='#,#';
			}
			if ($parser->iNodeName=='Text' && isset($parser->iNodeValue))
			{
				$_var .= $parser->iNodeValue;
			}
		}
		$ele = str_replace('/','',str_replace('::','',str_replace('!-:','',$_var)));
		$elems = explode(':-!', $ele); //opening row
		foreach($elems as $key=>$value)
		{
			if(trim($value)!='')
			{
				$elems2 = explode('#,#',$value);
				array_pop($elems2);
				$data[] = $elems2;
			}
		}
		return $data;
	}
	
	function WriteHTML($html){
		$html = $this->ReplaceHTML($html);
		//Search for a table
		$start = strpos(strtolower($html),'<table');
		$end = strpos(strtolower($html),'</table');
		if($start!==false && $end!==false){
			$this->WriteHTML2(substr($html,0,$start).'<BR>');
			$tableVar = substr($html,$start,($end-$start));
			$tableData = $this->ParseTable($tableVar);
			$w = array();
			for($i=1;$i<=(is_array($tableData[0]) ? count($tableData[0]) : 0);$i++){
				if($this->CurOrientation=='L'){
					$w[] = abs(120/((is_array($tableData[0]) ? count($tableData[0]) : 0)-1))+24;
				}else{
					$w[] = abs(120/((is_array($tableData[0]) ? count($tableData[0]) : 0)-1))+5;
				}
			}
			$this->WriteTable($tableData,$w);
			$this->WriteHTML2(substr($html,$end+8,strlen($html)-1).'<BR>');
		}else{
			$this->WriteHTML2($html);
		}
	}
	
	function WriteHTML3($html,&$parsed){
		//HTML parser
		$html=strip_tags($html,"<b><u><i><a><img><p><br><strong><em><font><tr><blockquote>"); //supprime tous les tags sauf ceux reconnus
		$html=str_replace("\n",' ',$html); //remplace retour � la ligne par un espace
		$a=preg_split('/<(.*)>/U',$html,-1,PREG_SPLIT_DELIM_CAPTURE); //�clate la cha�ne avec les balises
		foreach($a as $i=>$e)
		{
			if($i%2==0){
				//Text
				if($this->HREF)
					$this->PutLink($this->HREF,$e);
					else
						$parsed.=$this->Write(4, stripslashes(txtentities($e)));
			}else{
				//Tag
				if($e[0]=="/")
					$this->CloseTag2(strtoupper(substr($e,1)));
					else
					{
						//Extract attributes
						$a2=explode(" ",$e);
						$tag=strtoupper(array_shift($a2));
						$attr=array();
						foreach($a2 as $v)
						{
							if(preg_match('/([^=]*)=["\']?([^"\']*)/',$v,$a3))
								$attr[strtoupper($a3[1])]=$a3[2];
						}
						$this->OpenTag2($tag,$attr);
					}
			}
		}
	}
	
	function OpenTag2($tag, $attr){
		//Opening tag
		switch($tag){
			case 'STRONG':
				$this->SetStyle('B',true);
				break;
			case 'EM':
				$this->SetStyle('I',true);
				break;
			case 'B':
			case 'I':
			case 'U':
				$this->SetStyle($tag,true);
				break;
			case 'A':
				$this->HREF=$attr['HREF'];
				break;
			case 'IMG':
				if(isset($attr['SRC']) && (isset($attr['WIDTH']) || isset($attr['HEIGHT']))) {
					if(!isset($attr['WIDTH']))
						$attr['WIDTH'] = 0;
						if(!isset($attr['HEIGHT']))
							$attr['HEIGHT'] = 0;
							$this->Image($attr['SRC'], $this->GetX(), $this->GetY(), px2mm($attr['WIDTH']), px2mm($attr['HEIGHT']));
				}
				break;
			case 'TR':
			case 'BLOCKQUOTE':
			case 'BR':
				$this->Ln(5);
				break;
			case 'P':
				$this->Ln(10);
				break;
			case 'FONT':
				if (isset($attr['COLOR']) && $attr['COLOR']!='') {
					$coul=hex2dec($attr['COLOR']);
					$this->SetTextColor($coul['R'],$coul['V'],$coul['B']);
					$this->issetcolor=true;
				}
				if (isset($attr['FACE']) && in_array(strtolower($attr['FACE']), $this->fontlist)) {
					$this->SetFont(strtolower($attr['FACE']));
					$this->issetfont=true;
				}
				break;
		}
	}
	
	function CloseTag2($tag){
		//Closing tag
		if($tag=='STRONG')
			$tag='B';
			if($tag=='EM')
				$tag='I';
				if($tag=='B' || $tag=='I' || $tag=='U')
					$this->SetStyle($tag,false);
					if($tag=='A')
						$this->HREF='';
						if($tag=='FONT'){
							if ($this->issetcolor==true) {
								$this->SetTextColor(0);
							}
							if ($this->issetfont) {
								$this->SetFont('arial');
								$this->issetfont=false;
							}
						}
	}
	
	function SetWidths($w)
	{
		$this->widths=$w;
	}
	
	function SetAligns($a)
	{
		$this->aligns=$a;
	}
	
	function Row($data,$fonte = NULL, $tamanho = NULL, $negrito = NULL)
	{
		//Calculate the height of the row
		if($fonte != NULL){
			$this->SetFont("{$fonte}","{$negrito}",$tamanho);
		}
		$nb=0;
		for($i=0;$i<count($data);$i++)
			$nb=max($nb,$this->NbLines($this->widths[$i],$data[$i]));
			$h=4*$nb;
			//Issue a page break first if needed
			$this->CheckPageBreak($h);
			//Draw the cells of the row
			for($i=0;$i<count($data);$i++)
			{
				$w=$this->widths[$i];
				$a=isset($this->aligns[$i]) ? $this->aligns[$i] : 'L';
				//Save the current position
				$x=$this->GetX();
				$y=$this->GetY();
				//Draw the border
				$this->Rect($x,$y,$w,$h);
				//Print the text
				$this->MultiCell($w,4,$data[$i],0,$a);
				//Put the position to the right of the cell
				$this->SetXY($x+$w,$y);
			}
			//Go to the next line
			$this->Ln($h);
	}
}
?>