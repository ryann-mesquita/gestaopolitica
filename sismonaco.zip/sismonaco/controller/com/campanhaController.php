<?php

namespace controller\com;

use lib\Controller;
use helper\Security;
use api\com\apiCampanha;
use helper\Paginator;
use obj\com\Campanha;
use obj\geral\Log;
use api\geral\apiLog;
use api\geral\apiEmpresa;
use helper\Funcoes;
use obj\com\Regra;

class campanhaController extends Controller {

	public function __construct() {

		parent::__construct();

		new Security($this->getModule(),$this->getController(),$this->getAction());
	}

	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Lista de Campanha";
		$apiCampanha = new apiCampanha();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		$apiEmpresa = new apiEmpresa();
		$emp = $apiEmpresa->geEmpresarevenda($_SESSION['empresa_sessao']);
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$busca = array(
				'1' => array('c' => '1', 'coluna' => 'des_reduzida', 'valor' => @$_POST['busca_valor']),
				'2' => array('c' => '1', 'coluna' => 'des_campanha', 'valor' => @$_POST['busca_valor']),
				'3' => array('c' => '3', 'coluna' => '', 'valor' => '')
			);
			if(isset($busca[$_POST['busca']])){
				$this->dados = array('campanha' => $apiCampanha->filtroCampanha($busca[$_POST['busca']]['c'], $emp->EMPRESA, $busca[$_POST['busca']]['coluna'], $busca[$_POST['busca']]['valor']));
				$_SESSION['filtro_sessao'] = array('c' => $busca[$_POST['busca']]['c'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'busca_valor' => $busca[$_POST['busca']]['valor'], 'busca' => $_POST['busca']);
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'com/index/index/acessonegado');
				die();
			}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				$this->dados = array('campanha' => $apiCampanha->filtroCampanha($_SESSION['filtro_sessao']['c'], $emp->EMPRESA, $_SESSION['filtro_sessao']['coluna'], $_SESSION['filtro_sessao']['busca_valor']));
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('campanha' => $apiCampanha->filtroCampanha('3',$emp->EMPRESA));
					$_SESSION['filtro_sessao'] = array('c' => '3', 'coluna' => '' , 'busca_valor' => '', 'busca' => '3');
					$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}
		}
		$TotalItem = (is_array($this->dados['campanha']) ? count($this->dados['campanha']) : 0);
		$this->dados['campanha'] = array_chunk($this->dados['campanha'], $ItemPorPagina);
		@$this->dados['campanha'] = $this->dados['campanha'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->view();
	}

	public function adicionar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Cadastro de Campanha";
		$apiCampanha = new apiCampanha();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$funcoes = new Funcoes();
			$apiEmpresa = new apiEmpresa();
			$emp = $apiEmpresa->geEmpresarevenda($_SESSION['empresa_sessao']);
			$apiCampanha = new apiCampanha();
			$rs = $apiCampanha->filtroCampanha('1',$emp->EMPRESA,'des_reduzida',$_POST['des_reduzida']);
			if ((is_array($rs) ? count($rs) : 0) > 0){
				$this->rollback = new Campanha();
				$this->rollback->des_reduzida = $_POST['des_reduzida'];
				$this->rollback->des_campanha = $_POST['des_campanha'];
				$ordem = 0;
				$tipo_operacao = $_POST["tipo_operacao"];
				$tipo_campanha = $_POST["tipo_campanha"];
				$veiculo = $_POST["veiculo"];
				$operador1 = $_POST["operador1"];
				$valor = $_POST["valor"];
				$premio = $_POST["premio"];
				$operador2 = $_POST["operador2"];
				foreach ($tipo_operacao as $key => $op) {
					$ordem = $ordem + 1;
					$this->rollback->tipo_operacao[$ordem] = $op;
					$this->rollback->tipo_campanha[$ordem] = $tipo_campanha{$key};
					$this->rollback->veiculo[$ordem] = $veiculo{$key};
					$this->rollback->operador1[$ordem] = $operador1{$key};
					$this->rollback->valor[$ordem] = $valor{$key};
					$this->rollback->premio[$ordem] = $premio{$key};
					$this->rollback->operador2[$ordem] = $operador2{$key};
				}
				$this->Alert = "J� existe uma campanha com esse nome cadastrado!";
			}else{
				$Post = new Campanha();
				$Post->des_reduzida = strtoupper($funcoes->retiraAcentos(trim($_POST['des_reduzida'])));
				$Post->des_campanha = strtoupper($funcoes->retiraAcentos(trim($_POST['des_campanha'])));
				$Post->empresa = $_SESSION['empresa_sessao'];
				$sql[$i] = $apiCampanha->addCampanha($Post);
				$log = new Log();
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico = "DES_REDUZIDA||{$Post->des_reduzida};;DES_CAMPANHA||{$Post->des_campanha};;EMPRESA||{$Post->empresa}";
				$apiLog = new apiLog();
				$campanha = array('coluna' => 'campanha','tabela' => 'com_campanha');
				$reg = 0;
				$tipo_operacao = $_POST["tipo_operacao"];
				$tipo_campanha = $_POST["tipo_campanha"];
				$veiculo = $_POST["veiculo"];
				$operador1 = $_POST["operador1"];
				$valor = $_POST["valor"];
				$premio = $_POST["premio"];
				$operador2 = $_POST["operador2"];
				$regra = new Regra();
				foreach ($tipo_operacao as $key => $op) {
					$i = $i+1;
					$reg = $reg + 1;
					$regra->regra = $reg;
					$regra->tipo_operacao = $op;
					$regra->tipo_campanha = $tipo_campanha{$key};
					$regra->veiculo = $veiculo{$key};
					$regra->operador1 = $operador1{$key};
					$regra->valor = $valor{$key};
					$regra->premio = $funcoes->sanearValor($premio{$key});
					$regra->operador2 = $operador2{$key};
					$sql[$i] = $apiCampanha->addRegra($regra,$campanha);
				}
				$i = $i+1;
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiCampanha->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'com/campanha/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'com/campanha/index/sucesso');
					}
				}else{
					$this->rollback = new Campanha();
					$this->rollback->des_reduzida = $_POST['des_reduzida'];
					$this->rollback->des_campanha = $_POST['des_campanha'];
					$ordem = 0;
					$tipo_operacao = $_POST["tipo_operacao"];
					$tipo_campanha = $_POST["tipo_campanha"];
					$veiculo = $_POST["veiculo"];
					$operador1 = $_POST["operador1"];
					$valor = $_POST["valor"];
					$premio = $_POST["premio"];
					$operador2 = $_POST["operador2"];
					foreach ($tipo_operacao as $key => $op) {
						$ordem = $ordem + 1;
						$this->rollback->tipo_operacao[$ordem] = $op;
						$this->rollback->tipo_campanha[$ordem] = $tipo_campanha{$key};
						$this->rollback->veiculo[$ordem] = $veiculo{$key};
						$this->rollback->operador1[$ordem] = $operador1{$key};
						$this->rollback->valor[$ordem] = $valor{$key};
						$this->rollback->premio[$ordem] = $premio{$key};
						$this->rollback->operador2[$ordem] = $operador2{$key};
					}
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}

		$this->view();
	}

	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Altera��o de Campanha";
		$campanha = new Campanha();
		$campanha->campanha = $this->getParams(0);
		$apiEmpresa = new apiEmpresa();
		$emp = $apiEmpresa->geEmpresarevenda($_SESSION['empresa_sessao']);
		$apiCampanha = new apiCampanha();
		$this->dados = array('campanha' => $apiCampanha->getCampanha($campanha,$emp->EMPRESA));
		if (!isset($this->dados['campanha'])){
			header('location:' .APP_ROOT. 'com/index/index/acessonegado');
			die();		
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->regras = $apiCampanha->getRegra($campanha);
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$funcoes = new Funcoes();
			$anterior = "";
			$atual = "::";
			$Post = new Campanha();
			$Post->campanha = $this->getParams(0);
			$rs = $apiCampanha->filtroCampanha('1',$emp->EMPRESA,'des_reduzida',$_POST['des_reduzida']);
			if ((is_array($rs) ? count($rs) : 0) > 0 && ($rs[0]->DES_REDUZIDA != $this->dados['campanha']->DES_REDUZIDA)){
				$this->dados['campanha']->DES_REDUZIDA = $_POST['des_reduzida'];
				$this->dados['campanha']->DES_CAMPANHA = $_POST['des_campanha'];
				$this->Alert = "J� existe uma campanha com esse nome cadastrado!";
			}else{
				if ($this->dados['campanha']->DES_REDUZIDA != strtoupper($funcoes->retiraAcentos(trim($_POST['des_reduzida'])))){
					$Post->des_reduzida =  strtoupper($funcoes->retiraAcentos(trim($_POST['des_reduzida'])));
					$anterior .= "DES_REDUZIDA||{$this->dados['campanha']->DES_REDUZIDA};;";
					$atual .= "DES_REDUZIDA||{$Post->des_reduzida};;";
				}
				if ($this->dados['campanha']->DES_CAMPANHA != strtoupper($funcoes->retiraAcentos(trim($_POST['des_campanha'])))){
					$Post->des_campanha =  strtoupper($funcoes->retiraAcentos(trim($_POST['des_campanha'])));
					$anterior .= "DES_CAMPANHA||{$this->dados['campanha']->DES_CAMPANHA};;";
					$atual .= "DES_CAMPANHA||{$Post->des_campanha};;";
				}
				if ($anterior != ""){
					$sql[$i] = $apiCampanha->editCampanha($Post);
					$i = $i+1;
				}
				$ar = 0;
				$tipo_operacao = $_POST["tipo_operacao"];
				$tipo_campanha = $_POST["tipo_campanha"];
				$veiculo = $_POST["veiculo"];
				$operador1 = $_POST["operador1"];
				$valor = $_POST["valor"];
				$premio = $_POST["premio"];
				$operador2 = $_POST["operador2"];
				$alt = "";
				foreach ($tipo_operacao as $key => $op) {
					if (isset($this->regras[$ar])){
						$regra = new Regra();
						$regra->campanha = $this->getParams(0);
						$regra->regra = $key;
						$alt = "nao";
						if ($this->regras[$ar]->TIPO_OPERACAO != $op){
							$alt = "sim";
							$regra->tipo_operacao =  $op;
							$anterior .= "TIPO_OPERACAO{$key}||{$this->regras[$ar]->TIPO_OPERACAO};;";
							$atual .= "TIPO_OPERACAO{$key}||{$regra->tipo_operacao};;";
						}
						if($this->regras[$ar]->TIPO_CAMPANHA != $tipo_campanha{$key}){
							$alt = "sim";
							$regra->tipo_campanha =  $tipo_campanha{$key};
							$anterior .= "TIPO_CAMPANHA{$key}||{$this->regras[$ar]->TIPO_CAMPANHA};;";
							$atual .= "TIPO_CAMPANHA{$key}||{$regra->tipo_campanha};;";
						}
						if($this->regras[$ar]->VEICULO != $veiculo{$key}){
							$alt = "sim";
							$regra->veiculo = $veiculo{$key};
							$anterior .= "VEICULO{$key}||{$this->regras[$ar]->VEICULO};;";
							$atual .= "VEICULO{$key}||{$regra->veiculo};;";
						}
						if($this->regras[$ar]->OPERADOR1 != $operador1{$key}){
							$alt = "sim";
							$regra->operador1 = $operador1{$key};
							$anterior .= "OPERADOR1-{$key}||{$this->regras[$ar]->OPERADOR1};;";
							$atual .= "OPERADOR1-{$key}||{$regra->operador1};;";
						}
						if($this->regras[$ar]->VALOR != $valor{$key}){
							$alt = "sim";
							$regra->valor = $valor{$key};
							$anterior .= "VALOR{$key}||{$this->regras[$ar]->VALOR};;";
							$atual .= "VALOR{$key}||{$regra->valor};;";
						}
						if($this->regras[$ar]->PREMIO != $funcoes->sanearValor($premio{$key})){
							$alt = "sim";
							$regra->premio = $funcoes->sanearValor($premio{$key});
							$anterior .= "PREMIO{$key}||{$this->regras[$ar]->PREMIO};;";
							$atual .= "PREMIO{$key}||{$regra->premio};;";
						}
						if($this->regras[$ar]->OPERADOR2 != $operador2{$key}){
							$alt = "sim";
							$regra->operador2 = $operador2{$key};
							$anterior .= "OPERADOR2-{$key}||{$this->regras[$ar]->OPERADOR2};;";
							$atual .= "OPERADOR2-{$key}||{$regra->operador2};;";
						}
						if ($alt == "sim"){
							if (isset($sql[$i])) {
								$i = $i + 1;
								$sql[$i] = $apiCampanha->editRegra($regra,$campanha);
							}else{
								$sql[$i] = $apiCampanha->editRegra($regra,$campanha);
							}
						}
					}else{
						$regra = new Regra();
						$regra->campanha = $this->getParams(0);
						$regra->regra = $key;
						$regra->tipo_operacao = $op;
						$regra->tipo_campanha = $tipo_campanha{$key};
						$regra->veiculo = $veiculo{$key};
						$regra->operador1 = $operador1{$key};
						$regra->valor = $valor{$key};
						$regra->premio = $funcoes->sanearValor($premio{$key});
						$regra->operador2 = $operador2{$key};
						if (isset($sql[$i])) {
							$i = $i + 1;
							$sql[$i] = $apiCampanha->addRegra($regra,$campanha);
						}else{
							$sql[$i] = $apiCampanha->addRegra($regra,$campanha);
						}
						$anterior .= "REGRA{$key}||CAMPANHA:{$regra->campanha} REGRA:{$key} NAO EXISTIA;;";
						$atual .= "REGRA{$key}||CAMPANHA:{$regra->campanha} REGRA:{$key} CRIADA;;";
					}
					$ar = $ar + 1;
				}
				$total = (is_array($this->regras) ? count($this->regras) : 0);
				if ($total > $ar){
					for ($i=$ar; $i < $total; $i++){
						$regra = new Regra();
						$regra->campanha = $this->getParams(0);
						$regra->regra = $i;
						if (isset($sql[$i])) {
							$i = $i + 1;
							$sql[$i] = $apiCampanha->delRegra($regra,$campanha);
						}else{
							$sql[$i] = $apiCampanha->delRegra($regra,$campanha);
						}
						$anterior .= "REGRA{$i}||CAMPANHA:{$regra->campanha} REGRA:{$i} EXISTIA;;";
						$atual .= "REGRA{$i}||CAMPANHA:{$regra->campanha} REGRA:{$i} DELETADA;;";
					}
				}
				if ($anterior != ""){
					$log = new Log();
					$log->historico = substr($anterior,0,-2);
					$log->usuario = $_SESSION['usuario_sessao'];
					$log->modulo = $this->getModule()['modulo'];
					$log->controle = $this->getController()['controle'];
					$log->acao = $this->getAction()['acao'];
					$log->empresa = $_SESSION['empresa_sessao'];
					$log->tipo = "A";
					$log->dta_registro = date("d/m/Y H:i:s");
					$log->historico .= substr($atual,0,-2);
					$apiLog = new apiLog();
					$sql[$i] = $apiLog->addLog($log);
					$rs = $apiCampanha->executeSQL($sql);
					if (@$rs[4] == 'sucesso') {
						if (isset($this->PaginaAtual)) {
							header('location:' .APP_ROOT. 'com/campanha/index/pagina/'.$this->PaginaAtual.'/sucesso');
						}else {
							header('location:' .APP_ROOT. 'com/campanha/index/sucesso');
						}
					}else{
						$this->dados['campanha']->DES_TIPO = $Post->des_campanha;
						$this->dados['campanha']->ATIVO = $Post->ativo;
						$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
						$erro = str_replace($retirar, "", $rs[2]);
						$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
					}
				}else{
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'com/campanha/index/pagina/'.$this->PaginaAtual.'/insucesso');
					}else {
						header('location:' .APP_ROOT. 'com/campanha/index/insucesso');
					}
				}
			}
		}
		$this->view();
	}
	public function excluir() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Exclus�o de Campanha";
		$campanha = new Campanha();
		$campanha->campanha = $this->getParams(0);
		$apiEmpresa = new apiEmpresa();
		$emp = $apiEmpresa->geEmpresarevenda($_SESSION['empresa_sessao']);
		$apiCampanha = new apiCampanha();
		$this->dados = array('campanha' => $apiCampanha->getCampanha($campanha,$emp->EMPRESA));
		if (!isset($this->dados['campanha'])){
			header('location:' .APP_ROOT. 'com/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$sql[$i] = $apiCampanha->delTodasRegras($campanha);
			$i = $i+1;
			$sql[$i] = $apiCampanha->delCampanha($campanha);
			$i = $i+1;
			$log = new Log();
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "E";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico = "CAMPANHA||{$this->dados['campanha']->CAMPANHA};;DES_REDUZIDA||{$this->dados['campanha']->DES_REDUZIDA};;DES_CAMPANHA||{$this->dados['campanha']->DES_CAMPANHA};;EMPRESA||{$this->dados['campanha']->EMPRESA}";
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiCampanha->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'com/campanha/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'com/campanha/index/sucesso');
				}
			}else{
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}
		$this->view();
	}
}