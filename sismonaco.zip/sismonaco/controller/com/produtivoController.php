<?php

namespace controller\com;

use lib\Controller;
use helper\Security;
use api\com\apiProdutivo;
use obj\com\Produtivo;
use obj\geral\Log;
use api\geral\apiLog;
use helper\Funcoes;
use api\geral\apiEmpresa;
use obj\com\Parametros;

class produtivoController extends Controller {
	
	public function __construct() {
		
		parent::__construct();
		
		new Security($this->getModule(),$this->getController(),$this->getAction());
	}
	
	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Parametriza��o";
		$apiEmpresa = new apiEmpresa();
		$empresa = $apiEmpresa->geEmpresarevenda($_SESSION['empresa_sessao']);
		$produtivo = new Produtivo();
		$produtivo->empresa = $empresa->EMPRESA;
		$produtivo->revenda = $empresa->REVENDA;
		$apiProdutivo = new apiProdutivo();
		$this->dados = array('produtivo' => $apiProdutivo->getProdutivo($produtivo));
		$this->active1 = 'active';
		$this->active2 = '';
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			if ($_POST["submeter"] == "alterar"){
				$i = 0;
				$funcoes = new Funcoes();
				$anterior = "";
				$atual = "::";
				$sql = array();
				$Post = new Produtivo();
				$Post->empresa = $empresa->EMPRESA;
				$Post->revenda = $empresa->REVENDA;
				
				if ($this->dados['produtivo']->QTD_MECA != $_POST['qtd_meca']){
					$Post->qtd_meca = $_POST['qtd_meca'];
					$anterior .= "QTD_MECA||{$this->dados['produtivo']->QTD_MECA};;";
					$atual .= "QTD_MECA||{$Post->qtd_meca};;";
				}
				
				if ($this->dados['produtivo']->QTD_ELET != $_POST['qtd_elet']){
					$Post->qtd_elet = $_POST['qtd_elet'];
					$anterior .= "QTD_ELET||{$this->dados['produtivo']->QTD_ELET};;";
					$atual .= "QTD_ELET||{$Post->qtd_elet};;";
				}
				
				if ($this->dados['produtivo']->QTD_CONS != $_POST['qtd_cons']){
					$Post->qtd_cons = $_POST['qtd_cons'];
					$anterior .= "QTD_CONS||{$this->dados['produtivo']->QTD_CONS};;";
					$atual .= "QTD_CONS||{$Post->qtd_cons};;";
				}
				if ($this->dados['produtivo']->ILA != $_POST['ila']){
					$Post->ila = $_POST['ila'];
					$anterior .= "ILA||{$this->dados['produtivo']->ILA};;";
					$atual .= "ILA||{$Post->ila};;";
				}
				
				$prod = "";
				$prod = $funcoes->sanearValor($_POST['mec_prod1']);
				if ($this->dados['produtivo']->MEC_PROD1 != $prod){
					$Post->mec_prod1 = $prod;
					$anterior .= "MEC_PROD1||{$this->dados['produtivo']->MEC_PROD1};;";
					$atual .= "MEC_PROD1||{$Post->mec_prod1};;";
				}
				
				$prod = "";
				$prod = $funcoes->sanearValor($_POST['mec_prod2']);
				if ($this->dados['produtivo']->MEC_PROD2 != $prod){
					$Post->mec_prod2 = $prod;
					$anterior .= "MEC_PROD2||{$this->dados['produtivo']->MEC_PROD2};;";
					$atual .= "MEC_PROD2||{$Post->mec_prod2};;";
				}
				
				$prod = "";
				$prod = $funcoes->sanearValor($_POST['mec_prod3']);
				if ($this->dados['produtivo']->MEC_PROD3 != $prod){
					$Post->mec_prod3 = $prod;
					$anterior .= "MEC_PROD3||{$this->dados['produtivo']->MEC_PROD3};;";
					$atual .= "MEC_PROD3||{$Post->mec_prod3};;";
				}
				
				$prod = "";
				$prod = $funcoes->sanearValor($_POST['mec_prod4']);
				if ($this->dados['produtivo']->MEC_PROD4 != $prod){
					$Post->mec_prod4 = $prod;
					$anterior .= "MEC_PROD4||{$this->dados['produtivo']->MEC_PROD4};;";
					$atual .= "MEC_PROD4||{$Post->mec_prod4};;";
				}
				
				$prod = "";
				$prod = $funcoes->sanearValor($_POST['ele_prod1']);
				if ($this->dados['produtivo']->ELE_PROD1 != $prod){
					$Post->ele_prod1 = $prod;
					$anterior .= "ELE_PROD1||{$this->dados['produtivo']->ELE_PROD1};;";
					$atual .= "ELE_PROD1||{$Post->ele_prod1};;";
				}
				
				$prod = "";
				$prod = $funcoes->sanearValor($_POST['ele_prod2']);
				if ($this->dados['produtivo']->ELE_PROD2 != $prod){
					$Post->ele_prod2 = $prod;
					$anterior .= "ELE_PROD2||{$this->dados['produtivo']->ELE_PROD2};;";
					$atual .= "ELE_PROD2||{$Post->ele_prod2};;";
				}
				
				$prod = "";
				$prod = $funcoes->sanearValor($_POST['ele_prod3']);
				if ($this->dados['produtivo']->ELE_PROD3 != $prod){
					$Post->ele_prod3 = $prod;
					$anterior .= "ELE_PROD3||{$this->dados['produtivo']->ELE_PROD3};;";
					$atual .= "ELE_PROD3||{$Post->ele_prod3};;";
				}
				
				$prod = "";
				$prod = $funcoes->sanearValor($_POST['ele_prod4']);
				if ($this->dados['produtivo']->ELE_PROD4 != $prod){
					$Post->ele_prod4 = $prod;
					$anterior .= "ELE_PROD4||{$this->dados['produtivo']->ELE_PROD4};;";
					$atual .= "ELE_PROD4||{$Post->ele_prod4};;";
				}
				
				$prod = "";
				$prod = $funcoes->sanearValor($_POST['con_prod1']);
				if ($this->dados['produtivo']->CON_PROD1 != $prod){
					$Post->con_prod1 = $prod;
					$anterior .= "CON_PROD1||{$this->dados['produtivo']->CON_PROD1};;";
					$atual .= "CON_PROD1||{$Post->con_prod1};;";
				}
				
				$prod = "";
				$prod = $funcoes->sanearValor($_POST['con_prod2']);
				if ($this->dados['produtivo']->CON_PROD2 != $prod){
					$Post->con_prod2 = $prod;
					$anterior .= "CON_PROD2||{$this->dados['produtivo']->CON_PROD2};;";
					$atual .= "CON_PROD2||{$Post->con_prod2};;";
				}
				
				$prod = "";
				$prod = $funcoes->sanearValor($_POST['con_prod3']);
				if ($this->dados['produtivo']->CON_PROD3 != $prod){
					$Post->con_prod3 = $prod;
					$anterior .= "CON_PROD3||{$this->dados['produtivo']->CON_PROD3};;";
					$atual .= "CON_PROD3||{$Post->con_prod3};;";
				}
				
				$prod = "";
				$prod = $funcoes->sanearValor($_POST['con_prod4']);
				if ($this->dados['produtivo']->CON_PROD4 != $prod){
					$Post->con_prod4 = $prod;
					$anterior .= "CON_PROD4||{$this->dados['produtivo']->CON_PROD4};;";
					$atual .= "CON_PROD4||{$Post->con_prod4};;";
				}
				
				if ($anterior != ""){
					if ((is_array($this->dados['produtivo']) ? count($this->dados['produtivo']) : 0) > 0 ){
						$sql[$i] = $apiProdutivo->editProdutivo($Post);
					}else{
						$sql[$i] = $apiProdutivo->addProdutivo($Post);
					}
					
					$i = $i+1;
					$log = new Log();
					$log->usuario = $_SESSION['usuario_sessao'];
					$log->modulo = $this->getModule()['modulo'];
					$log->controle = $this->getController()['controle'];
					$log->acao = $this->getAction()['acao'];
					$log->empresa = $_SESSION['empresa_sessao'];
					$log->tipo = "A";
					$log->dta_registro = date("d/m/Y H:i:s");
					$log->historico = substr($anterior,0,-2);
					$log->historico .= substr($atual,0,-2);
					$apiLog = new apiLog();
					$sql[$i] = $apiLog->addLog($log);
				}
				$rs = $apiProdutivo->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'com/produtivo/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'com/produtivo/index/sucesso');
					}
				}else{
					$this->dados = $Post;
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}elseif ($_POST["submeter"] == "consultar"){
				$this->active1 = '';
				$this->active2 = 'active';
				$ano = $_POST['ano'];
				$mes = $_POST['mes'];
				unset($_SESSION['filtro_sessao']);
				$_SESSION['filtro_sessao'] = array('ano' => $ano, 'mes' => $mes);
				$this->parametros = $apiProdutivo->getParametrosBD($empresa->EMPRESA, $empresa->REVENDA, $_SESSION['filtro_sessao']['ano'], $_SESSION['filtro_sessao']['mes']);
			}
		}else{
			if(isset($_SESSION['filtro_sessao']['ano'])){
				$this->parametros = $apiProdutivo->getParametrosBD($empresa->EMPRESA, $empresa->REVENDA, $_SESSION['filtro_sessao']['ano'], $_SESSION['filtro_sessao']['mes']);
			}else{
				$this->parametros = $apiProdutivo->getParametrosBD($empresa->EMPRESA, $empresa->REVENDA);
			}
		}
		$this->view();
	}
	
	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Parametriza��o";
		$apiEmpresa = new apiEmpresa();
		$empresa = $apiEmpresa->geEmpresarevenda($_SESSION['empresa_sessao']);
		$apiProdutivo = new apiProdutivo();
		$exp = explode(',', $this->getParams(0));
		$params = $apiProdutivo->getParametrosBD($empresa->EMPRESA, $empresa->REVENDA, $exp[0], $exp[1]);
		$this->dados = array('parametros' => $params[0]);
		$funcoes = new Funcoes();
		$this->horastrabalhadas = $funcoes->horasTrabalhadas($empresa->EMPRESA, $empresa->REVENDA, $exp[1], $exp[0]);
		$this->produtividade = $this->horastrabalhadas * $this->dados['parametros']->MAODEOBRA;
		
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$funcoes = new Funcoes();
			$anterior = "";
			$atual = "::";
			$sql = array();
			$Post = new Parametros();
			$Post->empresa = $empresa->EMPRESA;
			$Post->revenda = $empresa->REVENDA;
			$Post->ano = $exp[0];
			$Post->mes = "<str>".$exp[1];
			
			if ($this->dados['parametros']->QTD_MECA != $_POST['qtd_meca']){
				$Post->qtd_meca = $_POST['qtd_meca'];
				$anterior .= "QTD_MECA||{$this->dados['parametros']->QTD_MECA};;";
				$atual .= "QTD_MECA||{$Post->qtd_meca};;";
			}
			
			if ($this->dados['parametros']->QTD_ELET != $_POST['qtd_elet']){
				$Post->qtd_elet = $_POST['qtd_elet'];
				$anterior .= "QTD_ELET||{$this->dados['parametros']->QTD_ELET};;";
				$atual .= "QTD_ELET||{$Post->qtd_elet};;";
			}
			
			if ($this->dados['parametros']->QTD_CONS != $_POST['qtd_cons']){
				$Post->qtd_cons = $_POST['qtd_cons'];
				$anterior .= "QTD_CONS||{$this->dados['parametros']->QTD_CONS};;";
				$atual .= "QTD_CONS||{$Post->qtd_cons};;";
			}
			$ila = $funcoes->sanearValor($_POST['ila']);
			if ($this->dados['parametros']->ILA != $ila){
				$Post->ila = $ila;
				$anterior .= "ILA||{$this->dados['parametros']->ILA};;";
				$atual .= "ILA||{$Post->ila};;";
			}
			
			$prod = "";
			$prod = $funcoes->sanearValor($_POST['mec_prod1']);
			if ($this->dados['parametros']->MEC_PROD1 != $prod){
				$Post->mec_prod1 = $prod;
				$anterior .= "MEC_PROD1||{$this->dados['parametros']->MEC_PROD1};;";
				$atual .= "MEC_PROD1||{$Post->mec_prod1};;";
			}
			
			$prod = "";
			$prod = $funcoes->sanearValor($_POST['mec_prod2']);
			if ($this->dados['parametros']->MEC_PROD2 != $prod){
				$Post->mec_prod2 = $prod;
				$anterior .= "MEC_PROD2||{$this->dados['parametros']->MEC_PROD2};;";
				$atual .= "MEC_PROD2||{$Post->mec_prod2};;";
			}
			
			$prod = "";
			$prod = $funcoes->sanearValor($_POST['mec_prod3']);
			if ($this->dados['parametros']->MEC_PROD3 != $prod){
				$Post->mec_prod3 = $prod;
				$anterior .= "MEC_PROD3||{$this->dados['parametros']->MEC_PROD3};;";
				$atual .= "MEC_PROD3||{$Post->mec_prod3};;";
			}
			
			$prod = "";
			$prod = $funcoes->sanearValor($_POST['mec_prod4']);
			if ($this->dados['parametros']->MEC_PROD4 != $prod){
				$Post->mec_prod4 = $prod;
				$anterior .= "MEC_PROD4||{$this->dados['parametros']->MEC_PROD4};;";
				$atual .= "MEC_PROD4||{$Post->mec_prod4};;";
			}
			
			$prod = "";
			$prod = $funcoes->sanearValor($_POST['ele_prod1']);
			if ($this->dados['parametros']->ELE_PROD1 != $prod){
				$Post->ele_prod1 = $prod;
				$anterior .= "ELE_PROD1||{$this->dados['parametros']->ELE_PROD1};;";
				$atual .= "ELE_PROD1||{$Post->ele_prod1};;";
			}
			
			$prod = "";
			$prod = $funcoes->sanearValor($_POST['ele_prod2']);
			if ($this->dados['parametros']->ELE_PROD2 != $prod){
				$Post->ele_prod2 = $prod;
				$anterior .= "ELE_PROD2||{$this->dados['parametros']->ELE_PROD2};;";
				$atual .= "ELE_PROD2||{$Post->ele_prod2};;";
			}
			
			$prod = "";
			$prod = $funcoes->sanearValor($_POST['ele_prod3']);
			if ($this->dados['parametros']->ELE_PROD3 != $prod){
				$Post->ele_prod3 = $prod;
				$anterior .= "ELE_PROD3||{$this->dados['parametros']->ELE_PROD3};;";
				$atual .= "ELE_PROD3||{$Post->ele_prod3};;";
			}
			
			$prod = "";
			$prod = $funcoes->sanearValor($_POST['ele_prod4']);
			if ($this->dados['parametros']->ELE_PROD4 != $prod){
				$Post->ele_prod4 = $prod;
				$anterior .= "ELE_PROD4||{$this->dados['parametros']->ELE_PROD4};;";
				$atual .= "ELE_PROD4||{$Post->ele_prod4};;";
			}
			
			$prod = "";
			$prod = $funcoes->sanearValor($_POST['con_prod1']);
			if ($this->dados['parametros']->CON_PROD1 != $prod){
				$Post->con_prod1 = $prod;
				$anterior .= "CON_PROD1||{$this->dados['parametros']->CON_PROD1};;";
				$atual .= "CON_PROD1||{$Post->con_prod1};;";
			}
			
			$prod = "";
			$prod = $funcoes->sanearValor($_POST['con_prod2']);
			if ($this->dados['parametros']->CON_PROD2 != $prod){
				$Post->con_prod2 = $prod;
				$anterior .= "CON_PROD2||{$this->dados['parametros']->CON_PROD2};;";
				$atual .= "CON_PROD2||{$Post->con_prod2};;";
			}
			
			$prod = "";
			$prod = $funcoes->sanearValor($_POST['con_prod3']);
			if ($this->dados['parametros']->CON_PROD3 != $prod){
				$Post->con_prod3 = $prod;
				$anterior .= "CON_PROD3||{$this->dados['parametros']->CON_PROD3};;";
				$atual .= "CON_PROD3||{$Post->con_prod3};;";
			}
			
			$prod = "";
			$prod = $funcoes->sanearValor($_POST['con_prod4']);
			if ($this->dados['parametros']->CON_PROD4 != $prod){
				$Post->con_prod4 = $prod;
				$anterior .= "CON_PROD4||{$this->dados['parametros']->CON_PROD4};;";
				$atual .= "CON_PROD4||{$Post->con_prod4};;";
			}
			
			if ($anterior != ""){
				$sql[$i] = $apiProdutivo->editParametros($Post);	
				$i = $i+1;
				$log = new Log();
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "A";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico = substr($anterior,0,-2);
				$log->historico .= substr($atual,0,-2);
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
			}
			$rs = $apiProdutivo->executeSQL($sql);
			if (isset($rs[4])){
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'com/produtivo/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'com/produtivo/index/sucesso');
					}
				}else{
					$this->dados = $Post;
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}else{
				header('location:' .APP_ROOT. 'com/produtivo/index/insucesso');
			}
		}
		
		$this->view();
	}
}