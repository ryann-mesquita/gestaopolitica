<?php

namespace controller\com;

use lib\Controller;
use helper\Security;
use api\com\apiGrupo;
use api\com\apiIndex;
use helper\Funcoes;
use api\geral\apiEmpresa;

include 'classes/PHPExcel.php';

class indexController extends Controller {
	
	public function __construct() {
		
		parent::__construct();
		
		new Security($this->getModule(),$this->getController(),$this->getAction());
	}
	
	public function index() {
		$funcoes = new Funcoes();
		if (@$_POST['submeter'] != "imprimir" && @$_POST['submeter'] != "exportar"){
			unset($_SESSION['filtro_sessao']);
			unset($_SESSION['consulta_sessao']);
		}
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Comiss�es M�naco";
		$apiGrupo = new apiGrupo();
		$grupo = $apiGrupo->filtroGrupo('3', $_SESSION['empresa_sessao'], '', '');
		foreach ($grupo as $rs){
			$this->grupo[$rs->GRUPO] = $rs;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$de = $_POST['de'];
			$ate = $_POST['ate'];
			$grupo = $_POST['grupo'];
			$apiEmpresa = new apiEmpresa();
			$emp = $apiEmpresa->geEmpresarevenda($_SESSION['empresa_sessao']);
			$apiIndex = new apiIndex();
			if ($_POST['submeter'] == "gerar"){
				$i = 1;
				$sq = "";
				foreach ($grupo as $rs){
					$this->grupos_selecionados[$i] = $this->grupo[$rs];
					$strVal = explode(';;', $this->grupo[$rs]->CAMPO_FORMULA);
					foreach ($strVal as $va){
						@list($k, $v) = explode('||', $va);
						$campo_formula[$i][$k] = $v;
					}
					$this->grupos_selecionados[$i] = array('grupo' => $this->grupo[$rs]->GRUPO, 'des_grupo' => $this->grupo[$rs]->DES_GRUPO, 'tipo' => $this->grupo[$rs]->TIPO, 'des_tipo' => $this->grupo[$rs]->DES_TIPO, 'considerar' => $campo_formula[$i]["CONSIDERAR"]);
					$empresa = str_replace(",", "','", $campo_formula[$i]["EMPRESA"]);
					$emplocal = explode(",", $campo_formula[$i]["EMPRESA"]);
					$tipo = str_replace(",", "','", $campo_formula[$i]["CONSIDERAR"]);
					$considerar = explode(",", $campo_formula[$i]["CONSIDERAR"]);
					$vendedor = $campo_formula[$i]["VENDEDOR"];
					if (isset($campo_formula[$i]["EQUIPE"])){
						$equipe = "and m.usuario in ({$campo_formula[$i]["EQUIPE"]}) ";
					}else{
						$equipe = "";
					}
					if (isset($campo_formula[$i]["EQUIPEN"])){
						$equipen = "and v.vendedor in ({$campo_formula[$i]["EQUIPEN"]}) ";
					}else{
						$equipen = "";
					}
					if (isset($campo_formula[$i]["EQUIPEU"])){
						$equipeu = "and v.vendedor in ({$campo_formula[$i]["EQUIPEU"]}) ";
					}else{
						$equipeu = "";
					}
					if (isset($campo_formula[$i]["EQUIPED"])){
						$equiped = "and v.vendedor in ({$campo_formula[$i]["EQUIPED"]}) ";
					}else{
						$equiped = "";
					}
					if (isset($campo_formula[$i]["DEPARTAMENTO"])){
						$departamento = "and m.departamento in ({$campo_formula[$i]["DEPARTAMENTO"]}) ";
					}else{
						$departamento = "";
					}
					if(isset($campo_formula[$i]["FAI_AUTO"])){
						$auto = "S";
					}else{
						$auto = "N";
					}
					$com = 0;
					$exp = explode('/',$de);
					$emprev = "{$emp->EMPRESA}.{$emp->REVENDA}";
					$parametros = $apiIndex->getParametros($emprev,"{$exp[1]}/{$exp[2]}");
					@$prcmao = str_replace(",", ".", $parametros->MAODEOBRA);
					@$produtividade = ($funcoes->horasTrabalhadas($emp->EMPRESA, $emp->REVENDA, $exp[1], $exp[2])) * $prcmao;
					
					$sq .= $apiIndex->getComissao($rs, $emp->EMPRESA, $emp->REVENDA, $this->grupo[$rs]->TIPO, $campo_formula[$i]["POR"], $auto, $produtividade, $parametros, $i, $campo_formula[$i], $de, $ate, $empresa, $tipo, $vendedor, $considerar, $equipe, $departamento, $equipen, $equipeu, $equiped);
					
					$i = $i + 1;
					$empresa = "";
					$tipo = "";
					$considerar = "";
					$vendedor = "";
					$case = "";
				}
				$sq = substr($sq,0,-6);
				$sq .= "order by 1, 4";
				$comis = $apiIndex->getCalculo($sq);
				$in = 1;
				$search = array(',','.');
				foreach ($comis as $rs){
					@$prem[$rs->GRUPO]["P{$in}-{$rs->USUARIO}"] = $prem[$rs->GRUPO]["P{$in}-{$rs->USUARIO}"] + str_replace(",", ".", $rs->PREMIO);
					$this->vendedores[$rs->GRUPO]["P{$in}-{$rs->USUARIO}"] = array('empresa' => $rs->EMPRESA, 'nome'=> $rs->NOME, 'usuario' => $rs->USUARIO, 'premio' => $prem[$rs->GRUPO]["P{$in}-{$rs->USUARIO}"]);
					$this->resultados[$rs->GRUPO][$rs->USUARIO]["{$rs->TIPO_ITEM}"] = array('valor' => str_replace(",", ".", $rs->VALOR_TOTAL), 'pct_comissao' => str_replace(",", ".", $rs->PCT_COMISSAO),'comissao' => str_replace(",", ".", $rs->VALOR_COMISSAO));
					$exp = explode(";", str_replace(",", ".", $rs->VALOR_COMISSAO));
					$com1 = (isset($exp[0]) && $exp[0] != "") ? $exp[0] : 0;
					$com2 = (isset($exp[1]) && $exp[1] != "") ? $exp[1] : 0;
					$com3 = (isset($exp[2]) && $exp[2] != "") ? $exp[2] : 0;
					$com4 = (isset($exp[3]) && $exp[3] != "") ? $exp[3] : 0;
					$comiss = ($com1 + $com2 + $com3 + $com4);
					unset($exp);
					if (str_replace(",", ".",$rs->PREMIO) > 0){
						$this->metadados["{$rs->USUARIO}-{$rs->METAPREMIO}"] = array('vdb' => $rs->METAPREMIO, 'cpf' => $rs->CPF, 'comissao' =>  str_replace($search, "", number_format(str_replace(",", ".", $rs->PREMIO), 2, ",", ".")));
					}
					@$metacom["{$rs->USUARIO}-{$rs->METADADOS}"] = $metacom["{$rs->USUARIO}-{$rs->METADADOS}"] + $comiss;
					$this->metadados["{$rs->USUARIO}-{$rs->METADADOS}"] = array('vdb' => $rs->METADADOS, 'cpf' => $rs->CPF, 'comissao' =>  str_replace($search, "", number_format(str_replace(",", ".", $metacom["{$rs->USUARIO}-{$rs->METADADOS}"]), 2, ",", ".")));
				}
				$_SESSION['filtro_sessao'] = array('de' => $_POST['de'], 'ate' => $_POST['ate'], 'grupo' => $_POST['grupo']);
				$_SESSION['consulta_sessao'] = array('grupos_selecionados' => @$this->grupos_selecionados, 'vendedores' => @$this->vendedores, 'resultados' => @$this->resultados, 'metadados' => @$this->metadados);
					
			}elseif ($_POST['submeter'] == "imprimir"){
				$i = 0;
				$objPHPExcel = new \PHPExcel();
				
				$objPHPExcel->getActiveSheet()->getPageSetup()->setOrientation(\PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
				$objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(\PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
				$objPHPExcel->getActiveSheet()->setShowGridlines(true);
				$objPHPExcel->getActiveSheet()->getPageSetup()->setFitToWidth(1);
				$objPHPExcel->getActiveSheet()->getPageSetup()->setFitToHeight(0);
				$objPHPExcel->getActiveSheet()->getPageSetup()->setFitToPage(true);
				$objPHPExcel->getActiveSheet()->getSheetView()->setZoomScale(80);
				$objPHPExcel->setActiveSheetIndex(0);
				
				$objPHPExcel->getActiveSheet()->mergeCells('A1:I1');
				$objPHPExcel->getActiveSheet()->getStyle('A1:I1')->getFont()->setSize(18)->setName('Courier New')->setBold(true);
				$gdImage = imagecreatefromjpeg($_SERVER["DOCUMENT_ROOT"] . "/sismonaco/content/geral/img/logomonacom.jpg");
				$objDrawing = new \PHPExcel_Worksheet_MemoryDrawing();
				$objDrawing->setName('Monaco');
				$objDrawing->setDescription('Logo Monaco');
				$objDrawing->setImageResource($gdImage);
				$objDrawing->setRenderingFunction(\PHPExcel_Worksheet_MemoryDrawing::RENDERING_JPEG);
				$objDrawing->setMimeType(\PHPExcel_Worksheet_MemoryDrawing::MIMETYPE_JPEG);
				$objDrawing->setCoordinates('A1');
				$objDrawing->setOffsetX(2);
				$objDrawing->setOffsetY(2);
				$objDrawing->setResizeProportional(false);
				$objDrawing->setWidth(25);
				$objDrawing->setHeight(20);
				$objDrawing->setWorksheet($objPHPExcel->getActiveSheet());
				
				$objPHPExcel->setActiveSheetIndex()->setCellValue('A1', utf8_encode("   Grupo M�naco - Comiss�es do Per�odo De {$_SESSION['filtro_sessao']['de']} At� {$_SESSION['filtro_sessao']['ate']}") );
				
				$i = 1;
				foreach ($_SESSION['consulta_sessao']['grupos_selecionados'] as $gs){
					$i = $i + 1;
					$objPHPExcel->getActiveSheet()->mergeCells("A{$i}:M{$i}");
					$objPHPExcel->getActiveSheet()->getStyle("A{$i}:M{$i}")->getFont()->setSize(16)->setName('Courier New')->setBold(true);
					$objPHPExcel->setActiveSheetIndex()->setCellValue("A{$i}", utf8_encode("{$gs['des_tipo']} - {$gs['des_grupo']}") );
					$i = $i + 1;
					$considerar = explode(",", $gs['considerar']);
					$objPHPExcel->getActiveSheet()->setCellValue("A{$i}", "Nome" );
					$col1 = 1;
					$col2 = 2;
					$col3 = 3;
					$col = 3;
					if (in_array("N", $considerar)){
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1,$i, utf8_encode("Novos"))
						->setCellValueByColumnAndRow($col2, $i, utf8_encode("%Novos"))
						->setCellValueByColumnAndRow($col3, $i, utf8_encode("Parcial"));
						$col1 = ($col = $col + 1);
						$col2 = ($col = $col + 1);
						$col3 = ($col = $col + 1);
					}
					if (in_array("U", $considerar)){
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1,$i, utf8_encode("Usados"))
						->setCellValueByColumnAndRow($col2, $i, utf8_encode("%Usados"))
						->setCellValueByColumnAndRow($col3, $i, utf8_encode("Parcial"));
						$col1 = ($col = $col + 1);
						$col2 = ($col = $col + 1);
						$col3 = ($col = $col + 1);
					}
					if (in_array("D", $considerar)){
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1,$i, utf8_encode("Direto"))
						->setCellValueByColumnAndRow($col2, $i, utf8_encode("%Direto"))
						->setCellValueByColumnAndRow($col3, $i, utf8_encode("Parcial"));
						$col1 = ($col = $col + 1);
						$col2 = ($col = $col + 1);
						$col3 = ($col = $col + 1);
					}
					if (in_array("C", $considerar)){
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1,$i, utf8_encode("Cons�rcio"))
						->setCellValueByColumnAndRow($col2, $i, utf8_encode("%Cons�rcio"))
						->setCellValueByColumnAndRow($col3, $i, utf8_encode("Parcial"));
						$col1 = ($col = $col + 1);
						$col2 = ($col = $col + 1);
						$col3 = ($col = $col + 1);
					}
					if (in_array("P", $considerar)){
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1,$i, utf8_encode("Pe�as"))
						->setCellValueByColumnAndRow($col2, $i, utf8_encode("%Pe�as"))
						->setCellValueByColumnAndRow($col3, $i, utf8_encode("Parcial"));
						$col1 = ($col = $col + 1);
						$col2 = ($col = $col + 1);
						$col3 = ($col = $col + 1);
					}
					if (in_array("S", $considerar)){
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1,$i, utf8_encode("Servi�o"))
						->setCellValueByColumnAndRow($col2, $i, utf8_encode("%Servi�o"))
						->setCellValueByColumnAndRow($col3, $i, utf8_encode("Parcial"));
						$col1 = ($col = $col + 1);
						$col2 = ($col = $col + 1);
						$col3 = ($col = $col + 1);
					}
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1,$i, utf8_encode("Total"))
					->setCellValueByColumnAndRow($col2, $i, utf8_encode("Pr�mio"))
					->setCellValueByColumnAndRow($col3, $i, utf8_encode("Comiss�o"));
					
					$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(55);
					$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(16);
					$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(16);
					$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(16);
					$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(16);
					$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(16);
					$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(16);
					$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(16);
					$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(16);
					$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(16);
					$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(16);
					$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(16);
					$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(16);
					$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(16);
					/*$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(16);
					$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(16);
					$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(16);
					$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(16);
					$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(16);*/
					
					$objPHPExcel->getActiveSheet()->getStyle("A{$i}:R{$i}")->getFont()->setSize(16)->setName('Courier New')->setBold(true);
					$tot_val = 0;
					$tot_comissao = 0;
					$de = $i + 1;
					foreach ($_SESSION['consulta_sessao']['vendedores'][$gs['grupo']] as $rs){
						$i = $i + 1;
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, utf8_encode("".ucfirst(strtolower($rs['nome'])).""));
						$col1 = 1;
						$col2 = 2;
						$col3 = 3;
						$col = 3;
						$n_ln = 1;
						if ($rs['empresa'] == 13){
							if ($gs['tipo'] == 1){
								if (in_array("N", $considerar)){
									$n_ln = 4;
									@$exp = explode(";", $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['N']['valor']);
									$val_ve = (isset($exp[0]) && $exp[0] != "") ? $exp[0] : 0;
									$val_fi = (isset($exp[1]) && $exp[1] != "") ? $exp[1] : 0;
									$val_ac = (isset($exp[2]) && $exp[2] != "") ? $exp[2] : 0;
									$tot_val = $tot_val + ($val_ve + $val_fi + $val_ac);
									@$exp = explode(";", $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['N']['pct_comissao']);
									$com_ve = (isset($exp[0]) && $exp[0] != "") ? $exp[0] : 0;
									$com_fi = (isset($exp[1]) && $exp[1] != "") ? $exp[1] : 0;
									$com_ac = (isset($exp[2]) && $exp[2] != "") ? $exp[2] : 0;
									@$exp = explode(";", $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['N']['comissao']);
									$vcom_ve = (isset($exp[0]) && $exp[0] != "") ? $exp[0] : 0;
									$vcom_fi = (isset($exp[1]) && $exp[1] != "") ? $exp[1] : 0;
									$vcom_ac = (isset($exp[2]) && $exp[2] != "") ? $exp[2] : 0;
									$vcom_emp = (isset($exp[3]) && $exp[3] != "") ? $exp[3] : 0;
									$tot_comissao = $tot_comissao + ($vcom_ve + $vcom_fi + $vcom_ac + $vcom_emp);
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, ($i+1), utf8_encode("Venda"));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, ($i+1), number_format($val_ve, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, ($i+1), number_format($com_ve, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, ($i+1), number_format($vcom_ve, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, ($i+2), utf8_encode("F&i"));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, ($i+2), number_format($val_fi, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, ($i+2), number_format($com_fi, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, ($i+2), number_format($vcom_fi, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, ($i+3), utf8_encode("Acess�rio"));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, ($i+3), number_format($val_ac, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, ($i+3), number_format($com_ac, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, ($i+3), number_format($vcom_ac, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, ($i+4), utf8_encode("Emplacamento"));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, ($i+4), number_format($vcom_emp, 2, ",", "."));
									$col1 = ($col = $col + 1);
									$col2 = ($col = $col + 1);
									$col3 = ($col = $col + 1);
								}
								if (in_array("U", $considerar)){
									$n_ln = 4;
									@$exp = explode(";", $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['U']['valor']);
									$val_ve = (isset($exp[0]) && $exp[0] != "") ? $exp[0] : 0;
									$val_fi = (isset($exp[1]) && $exp[1] != "") ? $exp[1] : 0;
									$val_ac = (isset($exp[2]) && $exp[2] != "") ? $exp[2] : 0;
									$tot_val = $tot_val + ($val_ve + $val_fi + $val_ac);
									@$exp = explode(";", $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['U']['pct_comissao']);
									$com_ve = (isset($exp[0]) && $exp[0] != "") ? $exp[0] : 0;
									$com_fi = (isset($exp[1]) && $exp[1] != "") ? $exp[1] : 0;
									$com_ac = (isset($exp[2]) && $exp[2] != "") ? $exp[2] : 0;
									@$exp = explode(";", $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['U']['comissao']);
									$vcom_ve = (isset($exp[0]) && $exp[0] != "") ? $exp[0] : 0;
									$vcom_fi = (isset($exp[1]) && $exp[1] != "") ? $exp[1] : 0;
									$vcom_ac = (isset($exp[2]) && $exp[2] != "") ? $exp[2] : 0;
									$vcom_emp = (isset($exp[3]) && $exp[3] != "") ? $exp[3] : 0;
									$tot_comissao = $tot_comissao + ($vcom_ve + $vcom_fi + $vcom_ac + $vcom_emp);
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, ($i+1), utf8_encode("Venda"));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, ($i+1), number_format($val_ve, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, ($i+1), number_format($com_ve, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, ($i+1), number_format($vcom_ve, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, ($i+2), utf8_encode("F&i"));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, ($i+2), number_format($val_fi, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, ($i+2), number_format($com_fi, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, ($i+2), number_format($vcom_fi, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, ($i+3), utf8_encode("Acess�rio"));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, ($i+3), number_format($val_ac, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, ($i+3), number_format($com_ac, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, ($i+3), number_format($vcom_ac, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, ($i+4), utf8_encode("Emplacamento"));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, ($i+4), number_format($vcom_emp, 2, ",", "."));
									$col1 = ($col = $col + 1);
									$col2 = ($col = $col + 1);
									$col3 = ($col = $col + 1);
								}
								if (in_array("D", $considerar)){
									$n_ln = 4;
									@$exp = explode(";", $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['D']['valor']);
									$val_ve = (isset($exp[0]) && $exp[0] != "") ? $exp[0] : 0;
									$val_fi = (isset($exp[1]) && $exp[1] != "") ? $exp[1] : 0;
									$val_ac = (isset($exp[2]) && $exp[2] != "") ? $exp[2] : 0;
									$tot_val = $tot_val + ($val_ve + $val_fi + $val_ac);
									@$exp = explode(";", $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['D']['pct_comissao']);
									$com_ve = (isset($exp[0]) && $exp[0] != "") ? $exp[0] : 0;
									$com_fi = (isset($exp[1]) && $exp[1] != "") ? $exp[1] : 0;
									$com_ac = (isset($exp[2]) && $exp[2] != "") ? $exp[2] : 0;
									@$exp = explode(";", $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['D']['comissao']);
									$vcom_ve = (isset($exp[0]) && $exp[0] != "") ? $exp[0] : 0;
									$vcom_fi = (isset($exp[1]) && $exp[1] != "") ? $exp[1] : 0;
									$vcom_ac = (isset($exp[2]) && $exp[2] != "") ? $exp[2] : 0;
									$vcom_emp = (isset($exp[3]) && $exp[3] != "") ? $exp[3] : 0;
									$tot_comissao = $tot_comissao + ($vcom_ve + $vcom_fi + $vcom_ac + $vcom_emp);
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, ($i+1), utf8_encode("Venda"));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, ($i+1), number_format($val_ve, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, ($i+1), number_format($com_ve, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, ($i+1), number_format($vcom_ve, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, ($i+2), utf8_encode("F&i"));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, ($i+2), number_format($val_fi, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, ($i+2), number_format($com_fi, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, ($i+2), number_format($vcom_fi, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, ($i+3), utf8_encode("Acess�rio"));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, ($i+3), number_format($val_ac, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, ($i+3), number_format($com_ac, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, ($i+3), number_format($vcom_ac, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, ($i+4), utf8_encode("Emplacamento"));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, ($i+4), number_format($vcom_emp, 2, ",", "."));
									$col1 = ($col = $col + 1);
									$col2 = ($col = $col + 1);
									$col3 = ($col = $col + 1);
								}
								if (in_array("C", $considerar)){
									$val_c = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['C']['valor'];
									$tot_val = $tot_val + $val_c;
									$pct_c = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['C']['pct_comissao'];
									$comissao_c = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['C']['comissao'];
									$tot_comissao = $tot_comissao + $comissao_c;
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, $i, number_format($val_c, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, $i, number_format($pct_c, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, $i, number_format($comissao_c, 2, ",", "."));
									$col1 = ($col = $col + 1);
									$col2 = ($col = $col + 1);
									$col3 = ($col = $col + 1);
								}
								if (in_array("P", $considerar)){
									$val_p = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['P']['valor'];
									$tot_val = $tot_val + $val_p;
									$pct_p = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['P']['pct_comissao'];
									$comissao_p = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['P']['comissao'];
									$tot_comissao = $tot_comissao + $comissao_p;
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, $i, number_format($val_p, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, $i, number_format($pct_p, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, $i, number_format($comissao_p, 2, ",", "."));
									$col1 = ($col = $col + 1);
									$col2 = ($col = $col + 1);
									$col3 = ($col = $col + 1);
								}
								if (in_array("S", $considerar)){
									$val_s = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['S']['valor'];
									$tot_val = $tot_val + $val_s;
									$pct_s = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['S']['pct_comissao'];
									$comissao_s = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['S']['comissao'];
									$tot_comissao = $tot_comissao + $comissao_s;
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, $i, number_format($val_s, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, $i, number_format($pct_s, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, $i, number_format($comissao_s, 2, ",", "."));
									$col1 = ($col = $col + 1);
									$col2 = ($col = $col + 1);
									$col3 = ($col = $col + 1);
								}
								if ($n_ln == 4){
									$f0 = $i - 1;
									$f1 = $i + 1;
									$f2 = $i + 2;
									$f3 = $i + 3;
									$f4 = $i + 4;
									if ($col == 6){
										$tot_val = "=SUM(B{$f1}+B{$f2}+B{$f3})";
										$tot_comissao = "=SUM(D{$f1}+D{$f2}+D{$f3}+D{$f4}+F{$i})";
										$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
										$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$f4}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$f4}")->applyFromArray($styleArray);
										$fim = "G";
										unset($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("A{$i}:G{$f4}")->getFont()->setSize(14)->setName('Courier New');
										$objPHPExcel->getActiveSheet()->getStyle("B{$i}:G{$f4}")->getNumberFormat()->setFormatCode('#,##0.00');
									}elseif ($col == 9){
										$tot_val = "=SUM(B{$f1}+B{$f2}+B{$f3}+E{$f1}+E{$f2}+E{$f3})";
										$tot_comissao = "=SUM(D{$f1}+D{$f2}+D{$f3}+D{$f4}+G{$f1}+G{$f2}+G{$f3}+G{$f4}+I{$i})";
										$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
										$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$f4}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$f4}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("J{$f0}:J{$f4}")->applyFromArray($styleArray);
										$fim = "J";
										unset($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("A{$i}:J{$f4}")->getFont()->setSize(14)->setName('Courier New');
										$objPHPExcel->getActiveSheet()->getStyle("B{$i}:J{$f4}")->getNumberFormat()->setFormatCode('#,##0.00');
									}elseif ($col == 12){
										$tot_val = "=SUM(B{$f1}+B{$f2}+B{$f3}+E{$f1}+E{$f2}+E{$f3}+H{$f1}+H{$f2}+H{$f3})";
										$tot_comissao = "=SUM(D{$f1}+D{$f2}+D{$f3}+D{$f4}+G{$f1}+G{$f2}+G{$f3}+G{$f4}+J{$f1}+J{$f2}+J{$f3}+J{$f4}+L{$i})";
										$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
										$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$f4}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$f4}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("J{$f0}:J{$f4}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("M{$f0}:M{$f4}")->applyFromArray($styleArray);
										$fim = "M";
										unset($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("A{$i}:M{$f4}")->getFont()->setSize(14)->setName('Courier New');
										$objPHPExcel->getActiveSheet()->getStyle("B{$i}:M{$f4}")->getNumberFormat()->setFormatCode('#,##0.00');
									}elseif ($col == 15){
										$tot_val = "=SUM(B{$f1}+B{$f2}+B{$f3}+E{$f1}+E{$f2}+E{$f3}+H{$f1}+H{$f2}+H{$f3}+K{$f1}+K{$f2}+K{$f3})";
										$tot_comissao = "=SUM(D{$f1}+D{$f2}+D{$f3}+D{$f4}+G{$f1}+G{$f2}+G{$f3}+G{$f4}+J{$f1}+J{$f2}+J{$f3}+J{$f4}+M{$f1}+M{$f2}+M{$f3}+M{$f4}+O{$i})";
										$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
										$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$f4}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$f4}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("J{$f0}:J{$f4}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("M{$f0}:M{$f4}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("P{$f0}:P{$f4}")->applyFromArray($styleArray);
										$fim = "P";
										unset($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("A{$i}:P{$f4}")->getFont()->setSize(14)->setName('Courier New');
										$objPHPExcel->getActiveSheet()->getStyle("B{$i}:P{$f4}")->getNumberFormat()->setFormatCode('#,##0.00');
									}elseif ($col == 18){
										$tot_val = "=SUM(B{$f1}+B{$f2}+B{$f3}+E{$f1}+E{$f2}+E{$f3}+H{$f1}+H{$f2}+H{$f3}+K{$f1}+K{$f2}+K{$f3}+N{$f1}+N{$f2}+N{$f3})";
										$tot_comissao = "=SUM(D{$f1}+D{$f2}+D{$f3}+D{$f4}+G{$f1}+G{$f2}+G{$f3}+G{$f4}+J{$f1}+J{$f2}+J{$f3}+J{$f4}+M{$f1}+M{$f2}+M{$f3}+M{$f4}+P{$f1}+P{$f2}+P{$f3}+P{$f4}+R{$i})";
										$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
										$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$f4}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$f4}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("J{$f0}:J{$f4}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("M{$f0}:M{$f4}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("P{$f0}:P{$f4}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("S{$f0}:S{$f4}")->applyFromArray($styleArray);
										$fim = "S";
										unset($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("A{$i}:S{$f4}")->getFont()->setSize(14)->setName('Courier New');
										$objPHPExcel->getActiveSheet()->getStyle("B{$i}:S{$f4}")->getNumberFormat()->setFormatCode('#,##0.00');
									}elseif ($col == 21){
										$tot_val = "=SUM(B{$f1}+B{$f2}+B{$f3}+E{$f1}+E{$f2}+E{$f3}+H{$f1}+H{$f2}+H{$f3}+K{$f1}+K{$f2}+K{$f3}+N{$f1}+N{$f2}+N{$f3}+Q{$f1}+Q{$f2}+Q{$f3})";
										$tot_comissao = "=SUM(D{$f1}+D{$f2}+D{$f3}+D{$f4}+G{$f1}+G{$f2}+G{$f3}+G{$f4}+J{$f1}+J{$f2}+J{$f3}+J{$f4}+M{$f1}+M{$f2}+M{$f3}+M{$f4}+P{$f1}+P{$f2}+P{$f3}+P{$f4}+S{$f1}+S{$f2}+S{$f3}+S{$f4}+U{$i})";
										$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
										$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$f4}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$f4}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("J{$f0}:J{$f4}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("M{$f0}:M{$f4}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("P{$f0}:P{$f4}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("S{$f0}:S{$f4}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("V{$f0}:V{$f4}")->applyFromArray($styleArray);
										$fim = "V";
										unset($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("A{$i}:V{$f4}")->getFont()->setSize(14)->setName('Courier New');
										$objPHPExcel->getActiveSheet()->getStyle("B{$i}:V{$f4}")->getNumberFormat()->setFormatCode('#,##0.00');
									}
								}else{
									$f0 = $i - 1;
									if ($col == 6){
										$tot_val = "=SUM(B{$i})";
										$tot_comissao = "=SUM(D{$i}+F{$i})";
										$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
										$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$i}")->applyFromArray($styleArray);
										$fim = "G";
										unset($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("A{$i}:G{$i}")->getFont()->setSize(14)->setName('Courier New');
										$objPHPExcel->getActiveSheet()->getStyle("B{$i}:G{$i}")->getNumberFormat()->setFormatCode('#,##0.00');
									}elseif ($col == 9){
										$tot_val = "=SUM(B{$i}+E{$i})";
										$tot_comissao = "=SUM(D{$i}+G{$i}+I{$i})";
										$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
										$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("J{$f0}:J{$i}")->applyFromArray($styleArray);
										$fim = "J";
										unset($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("A{$i}:J{$i}")->getFont()->setSize(14)->setName('Courier New');
										$objPHPExcel->getActiveSheet()->getStyle("B{$i}:J{$i}")->getNumberFormat()->setFormatCode('#,##0.00');
									}elseif ($col == 12){
										$tot_val = "=SUM(B{$i}+E{$i}+H{$i})";
										$tot_comissao = "=SUM(D{$i}+G{$i}+J{$i}+L{$i})";
										$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
										$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("J{$f0}:J{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("M{$f0}:M{$i}")->applyFromArray($styleArray);
										$fim = "M";
										unset($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("A{$i}:M{$i}")->getFont()->setSize(14)->setName('Courier New');
										$objPHPExcel->getActiveSheet()->getStyle("B{$i}:M{$i}")->getNumberFormat()->setFormatCode('#,##0.00');
									}elseif ($col == 15){
										$tot_val = "=SUM(B{$i}+E{$i}+H{$i}+K{$i})";
										$tot_comissao = "=SUM(D{$i}+G{$i}+J{$i}+M{$i}+O{$i})";
										$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
										$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("J{$f0}:J{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("M{$f0}:M{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("P{$f0}:P{$i}")->applyFromArray($styleArray);
										$fim = "P";
										unset($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("A{$i}:P{$i}")->getFont()->setSize(14)->setName('Courier New');
										$objPHPExcel->getActiveSheet()->getStyle("B{$i}:P{$i}")->getNumberFormat()->setFormatCode('#,##0.00');
									}elseif ($col == 18){
										$tot_val = "=SUM(B{$i}+E{$i}+H{$i}+K{$i}+N{$i})";
										$tot_comissao = "=SUM(D{$i}+G{$i}+J{$i}+M{$i}+P{$i}+R{$i})";
										$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
										$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("J{$f0}:J{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("M{$f0}:M{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("P{$f0}:P{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("S{$f0}:S{$i}")->applyFromArray($styleArray);
										$fim = "S";
										unset($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("A{$i}:S{$i}")->getFont()->setSize(14)->setName('Courier New');
										$objPHPExcel->getActiveSheet()->getStyle("B{$i}:S{$i}")->getNumberFormat()->setFormatCode('#,##0.00');
									}elseif ($col == 21){
										$tot_val = "=SUM(B{$i}+E{$i}+H{$i}+K{$i}+N{$i}+Q{$i})";
										$tot_comissao = "=SUM(D{$i}+G{$i}+J{$i}+M{$i}+P{$i}+S{$i}+U{$i})";
										$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
										$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("J{$f0}:J{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("M{$f0}:M{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("P{$f0}:P{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("S{$f0}:S{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("V{$f0}:V{$i}")->applyFromArray($styleArray);
										$fim = "V";
										unset($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("A{$i}:V{$i}")->getFont()->setSize(14)->setName('Courier New');
										$objPHPExcel->getActiveSheet()->getStyle("B{$i}:V{$i}")->getNumberFormat()->setFormatCode('#,##0.00');
									}
								}
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, $i, $tot_val);
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, $i, $rs['premio']);
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, $i, $tot_comissao);
								$tot_val = 0;
								$tot_comissao = 0;
								$i = $i + $n_ln;
								$styleArray = array('borders' => array('bottom' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
								$objPHPExcel->getActiveSheet()->getStyle("A{$i}:{$fim}{$i}")->applyFromArray($styleArray);
								unset($styleArray);
							}elseif ($gs['tipo'] == 'desativado'){
								if (in_array("N", $considerar)){
									$n_ln = 2;
									@$exp = explode(";", $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['N']['valor']);
									$val_ve = (isset($exp[0]) && $exp[0] != "") ? $exp[0] : 0;
									$val_ac = (isset($exp[1]) && $exp[1] != "") ? $exp[1] : 0;
									$tot_val = $tot_val + ($val_ve + $val_ac);
									@$exp = explode(";", $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['N']['pct_comissao']);
									$com_ve = (isset($exp[0]) && $exp[0] != "") ? $exp[0] : 0;
									$com_ac = (isset($exp[1]) && $exp[1] != "") ? $exp[1] : 0;
									@$exp = explode(";", $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['N']['comissao']);
									$vcom_ve = (isset($exp[0]) && $exp[0] != "") ? $exp[0] : 0;
									$vcom_ac = (isset($exp[1]) && $exp[1] != "") ? $exp[1] : 0;
									$tot_comissao = $tot_comissao + ($vcom_ve + $vcom_ac);
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, ($i+1), utf8_encode("Contrato"));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, ($i+1), number_format($val_ve, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, ($i+1), number_format($com_ve, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, ($i+1), number_format($vcom_ve, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, ($i+2), utf8_encode("Acess�rio"));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, ($i+2), number_format($val_ac, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, ($i+2), number_format($com_ac, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, ($i+2), number_format($vcom_ac, 2, ",", "."));
									$col1 = ($col = $col + 1);
									$col2 = ($col = $col + 1);
									$col3 = ($col = $col + 1);
								}
								if (in_array("U", $considerar)){
									$n_ln = 2;
									@$exp = explode(";", $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['U']['valor']);
									$val_ve = (isset($exp[0]) && $exp[0] != "") ? $exp[0] : 0;
									$val_ac = (isset($exp[1]) && $exp[1] != "") ? $exp[1] : 0;
									$tot_val = $tot_val + ($val_ve + $val_ac);
									@$exp = explode(";", $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['U']['pct_comissao']);
									$com_ve = (isset($exp[0]) && $exp[0] != "") ? $exp[0] : 0;
									$com_ac = (isset($exp[1]) && $exp[1] != "") ? $exp[1] : 0;
									@$exp = explode(";", $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['U']['comissao']);
									$vcom_ve = (isset($exp[0]) && $exp[0] != "") ? $exp[0] : 0;
									$vcom_ac = (isset($exp[1]) && $exp[1] != "") ? $exp[1] : 0;
									$tot_comissao = $tot_comissao + ($vcom_ve + $vcom_ac);
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, ($i+1), utf8_encode("Contrato"));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, ($i+1), number_format($val_ve, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, ($i+1), number_format($com_ve, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, ($i+1), number_format($vcom_ve, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, ($i+2), utf8_encode("Acess�rio"));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, ($i+2), number_format($val_ac, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, ($i+2), number_format($com_ac, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, ($i+2), number_format($vcom_ac, 2, ",", "."));
									$col1 = ($col = $col + 1);
									$col2 = ($col = $col + 1);
									$col3 = ($col = $col + 1);
								}
								if (in_array("D", $considerar)){
									$n_ln = 2;
									@$exp = explode(";", $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['D']['valor']);
									$val_ve = (isset($exp[0]) && $exp[0] != "") ? $exp[0] : 0;
									$val_ac = (isset($exp[1]) && $exp[1] != "") ? $exp[1] : 0;
									$tot_val = $tot_val + ($val_ve + $val_ac);
									@$exp = explode(";", $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['D']['pct_comissao']);
									$com_ve = (isset($exp[0]) && $exp[0] != "") ? $exp[0] : 0;
									$com_ac = (isset($exp[1]) && $exp[1] != "") ? $exp[1] : 0;
									@$exp = explode(";", $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['D']['comissao']);
									$vcom_ve = (isset($exp[0]) && $exp[0] != "") ? $exp[0] : 0;
									$vcom_ac = (isset($exp[1]) && $exp[1] != "") ? $exp[1] : 0;
									$tot_comissao = $tot_comissao + ($vcom_ve + $vcom_ac);
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, ($i+1), utf8_encode("Contrato"));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, ($i+1), number_format($val_ve, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, ($i+1), number_format($com_ve, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, ($i+1), number_format($vcom_ve, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, ($i+2), utf8_encode("Acess�rio"));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, ($i+2), number_format($val_ac, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, ($i+2), number_format($com_ac, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, ($i+2), number_format($vcom_ac, 2, ",", "."));
									$col1 = ($col = $col + 1);
									$col2 = ($col = $col + 1);
									$col3 = ($col = $col + 1);
								}
								if (in_array("C", $considerar)){
									$val_c = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['C']['valor'];
									$tot_val = $tot_val + $val_c;
									$pct_c = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['C']['pct_comissao'];
									$comissao_c = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['C']['comissao'];
									$tot_comissao = $tot_comissao + $comissao_c;
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, $i, number_format($val_c, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, $i, number_format($pct_c, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, $i, number_format($comissao_c, 2, ",", "."));
									$col1 = ($col = $col + 1);
									$col2 = ($col = $col + 1);
									$col3 = ($col = $col + 1);
								}
								if (in_array("P", $considerar)){
									$val_p = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['P']['valor'];
									$tot_val = $tot_val + $val_p;
									$pct_p = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['P']['pct_comissao'];
									$comissao_p = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['P']['comissao'];
									$tot_comissao = $tot_comissao + $comissao_p;
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, $i, number_format($val_p, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, $i, number_format($pct_p, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, $i, number_format($comissao_p, 2, ",", "."));
									$col1 = ($col = $col + 1);
									$col2 = ($col = $col + 1);
									$col3 = ($col = $col + 1);
								}
								if (in_array("S", $considerar)){
									$val_s = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['S']['valor'];
									$tot_val = $tot_val + $val_s;
									$pct_s = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['S']['pct_comissao'];
									$comissao_s = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['S']['comissao'];
									$tot_comissao = $tot_comissao + $comissao_s;
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, $i, number_format($val_s, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, $i, number_format($pct_s, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, $i, number_format($comissao_s, 2, ",", "."));
									$col1 = ($col = $col + 1);
									$col2 = ($col = $col + 1);
									$col3 = ($col = $col + 1);
								}
								if ($n_ln == 2){
									$f0 = $i - 1;
									$f1 = $i + 1;
									$f2 = $i + 2;
									if ($col == 6){
										$tot_val = "=SUM(B{$f1}+B{$f2})";
										$tot_comissao = "=SUM(D{$f1}+D{$f2})";
										$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
										$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$f2}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("F{$f0}:F{$f2}")->applyFromArray($styleArray);
										$fim = "F";
										unset($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("A{$i}:F{$f4}")->getFont()->setSize(14)->setName('Courier New');
										$objPHPExcel->getActiveSheet()->getStyle("B{$i}:F{$f4}")->getNumberFormat()->setFormatCode('#,##0.00');
									}elseif ($col == 9){
										$tot_val = "=SUM(B{$f1}+B{$f2}+E{$f1}+E{$f2})";
										$tot_comissao = "=SUM(D{$f1}+D{$f2}+G{$f1}+G{$f2})";
										$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
										$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$f2}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$f2}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("I{$f0}:I{$f2}")->applyFromArray($styleArray);
										$fim = "I";
										unset($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("A{$i}:I{$f2}")->getFont()->setSize(14)->setName('Courier New');
										$objPHPExcel->getActiveSheet()->getStyle("B{$i}:I{$f2}")->getNumberFormat()->setFormatCode('#,##0.00');
									}elseif ($col == 12){
										$tot_val = "=SUM(B{$f1}+B{$f2}+E{$f1}+E{$f2}+H{$f1}+H{$f2})";
										$tot_comissao = "=SUM(D{$f1}+D{$f2}+G{$f1}+G{$f2}+J{$f1}+J{$f2})";
										$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
										$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$f2}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$f2}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("J{$f0}:J{$f2}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("L{$f0}:L{$f2}")->applyFromArray($styleArray);
										$fim = "L";
										unset($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("A{$i}:L{$f2}")->getFont()->setSize(14)->setName('Courier New');
										$objPHPExcel->getActiveSheet()->getStyle("B{$i}:L{$f2}")->getNumberFormat()->setFormatCode('#,##0.00');
									}elseif ($col == 15){
										$tot_val = "=SUM(B{$f1}+B{$f2}+E{$f1}+E{$f2}+H{$f1}+H{$f2}+K{$f1}+K{$f2})";
										$tot_comissao = "=SUM(D{$f1}+D{$f2}+G{$f1}+G{$f2}+J{$f1}+J{$f2}+M{$f1}+M{$f2})";
										$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
										$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$f2}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$f2}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("J{$f0}:J{$f2}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("M{$f0}:M{$f2}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("O{$f0}:O{$f2}")->applyFromArray($styleArray);
										$fim = "O";
										unset($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("A{$i}:O{$f2}")->getFont()->setSize(14)->setName('Courier New');
										$objPHPExcel->getActiveSheet()->getStyle("B{$i}:O{$f2}")->getNumberFormat()->setFormatCode('#,##0.00');
									}elseif ($col == 18){
										$tot_val = "=SUM(B{$f1}+B{$f2}+E{$f1}+E{$f2}+H{$f1}+H{$f2}+K{$f1}+K{$f2}+N{$f1}+N{$f2})";
										$tot_comissao = "=SUM(D{$f1}+D{$f2}+G{$f1}+G{$f2}+J{$f1}+J{$f2}+M{$f1}+M{$f2}+P{$f1}+P{$f2})";
										$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
										$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$f2}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$f2}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("J{$f0}:J{$f2}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("M{$f0}:M{$f2}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("P{$f0}:P{$f2}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("R{$f0}:R{$f2}")->applyFromArray($styleArray);
										$fim = "R";
										unset($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("A{$i}:R{$f2}")->getFont()->setSize(14)->setName('Courier New');
										$objPHPExcel->getActiveSheet()->getStyle("B{$i}:R{$f2}")->getNumberFormat()->setFormatCode('#,##0.00');
									}elseif ($col == 21){
										$tot_val = "=SUM(B{$f1}+B{$f2}+E{$f1}+E{$f2}+H{$f1}+H{$f2}+K{$f1}+K{$f2}+N{$f1}+N{$f2}+Q{$f1}+Q{$f2})";
										$tot_comissao = "=SUM(D{$f1}+D{$f2}+G{$f1}+G{$f2}+J{$f1}+J{$f2}+M{$f1}+M{$f2}+P{$f1}+P{$f2}+S{$f1}+S{$f2})";
										$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
										$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$f2}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$f2}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("J{$f0}:J{$f2}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("M{$f0}:M{$f2}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("P{$f0}:P{$f2}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("S{$f0}:S{$f2}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("U{$f0}:U{$f2}")->applyFromArray($styleArray);
										$fim = "U";
										unset($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("A{$i}:U{$f2}")->getFont()->setSize(14)->setName('Courier New');
										$objPHPExcel->getActiveSheet()->getStyle("B{$i}:U{$f2}")->getNumberFormat()->setFormatCode('#,##0.00');
									}
								}else{
									$f0 = $i - 1;
									if ($col == 6){
										$tot_val = "=SUM(B{$i})";
										$tot_comissao = "=SUM(D{$i})";
										$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
										$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("F{$f0}:F{$i}")->applyFromArray($styleArray);
										$fim = "F";
										unset($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("A{$i}:F{$i}")->getFont()->setSize(14)->setName('Courier New');
										$objPHPExcel->getActiveSheet()->getStyle("B{$i}:F{$i}")->getNumberFormat()->setFormatCode('#,##0.00');
									}elseif ($col == 9){
										$tot_val = "=SUM(B{$i}+E{$i})";
										$tot_comissao = "=SUM(D{$i}+G{$i})";
										$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
										$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("I{$f0}:I{$i}")->applyFromArray($styleArray);
										$fim = "I";
										unset($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("A{$i}:I{$i}")->getFont()->setSize(14)->setName('Courier New');
										$objPHPExcel->getActiveSheet()->getStyle("B{$i}:I{$i}")->getNumberFormat()->setFormatCode('#,##0.00');
									}elseif ($col == 12){
										$tot_val = "=SUM(B{$i}+E{$i}+H{$i})";
										$tot_comissao = "=SUM(D{$i}+G{$i}+J{$i})";
										$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
										$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("J{$f0}:J{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("L{$f0}:L{$i}")->applyFromArray($styleArray);
										$fim = "L";
										unset($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("A{$i}:L{$i}")->getFont()->setSize(14)->setName('Courier New');
										$objPHPExcel->getActiveSheet()->getStyle("B{$i}:L{$i}")->getNumberFormat()->setFormatCode('#,##0.00');
									}elseif ($col == 15){
										$tot_val = "=SUM(B{$i}+E{$i}+H{$i}+K{$i})";
										$tot_comissao = "=SUM(D{$i}+G{$i}+J{$i}+M{$i})";
										$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
										$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("J{$f0}:J{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("M{$f0}:M{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("O{$f0}:O{$i}")->applyFromArray($styleArray);
										$fim = "O";
										unset($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("A{$i}:O{$i}")->getFont()->setSize(14)->setName('Courier New');
										$objPHPExcel->getActiveSheet()->getStyle("B{$i}:O{$i}")->getNumberFormat()->setFormatCode('#,##0.00');
									}elseif ($col == 18){
										$tot_val = "=SUM(B{$i}+E{$i}+H{$i}+K{$i}+N{$i})";
										$tot_comissao = "=SUM(D{$i}+G{$i}+J{$i}+M{$i}+P{$i})";
										$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
										$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("J{$f0}:J{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("M{$f0}:M{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("P{$f0}:P{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("R{$f0}:R{$i}")->applyFromArray($styleArray);
										$fim = "R";
										unset($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("A{$i}:R{$i}")->getFont()->setSize(14)->setName('Courier New');
										$objPHPExcel->getActiveSheet()->getStyle("B{$i}:R{$i}")->getNumberFormat()->setFormatCode('#,##0.00');
									}elseif ($col == 21){
										$tot_val = "=SUM(B{$i}+E{$i}+H{$i}+K{$i}+N{$i}+Q{$i})";
										$tot_comissao = "=SUM(D{$i}+G{$i}+J{$i}+M{$i}+P{$i}+S{$i})";
										$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
										$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("J{$f0}:J{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("M{$f0}:M{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("P{$f0}:P{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("S{$f0}:S{$i}")->applyFromArray($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("U{$f0}:U{$i}")->applyFromArray($styleArray);
										$fim = "U";
										unset($styleArray);
										$objPHPExcel->getActiveSheet()->getStyle("A{$i}:U{$i}")->getFont()->setSize(14)->setName('Courier New');
										$objPHPExcel->getActiveSheet()->getStyle("B{$i}:U{$i}")->getNumberFormat()->setFormatCode('#,##0.00');
									}
								}
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, $i, $tot_val);
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, $i, $rs['premio']);
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, $i, $tot_comissao);
								$tot_val = 0;
								$tot_comissao = 0;
								$i = $i + $n_ln;
								$styleArray = array('borders' => array('bottom' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
								$objPHPExcel->getActiveSheet()->getStyle("A{$i}:{$fim}{$i}")->applyFromArray($styleArray);
								unset($styleArray);
							}else{
								if (in_array("N", $considerar)){
									$val_n = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['N']['valor'];
									$tot_val = $tot_val + $val_n;
									$pct_n = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['N']['pct_comissao'];
									$comissao_n = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['N']['comissao'];
									$tot_comissao = $tot_comissao + $comissao_n;
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, $i, number_format($val_n, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, $i, number_format($pct_n, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, $i, number_format($comissao_n, 2, ",", "."));
									$col1 = ($col = $col + 1);
									$col2 = ($col = $col + 1);
									$col3 = ($col = $col + 1);
								}
								if (in_array("U", $considerar)){
									$val_u = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['U']['valor'];
									$tot_val = $tot_val + $val_u;
									$pct_u = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['U']['pct_comissao'];
									$comissao_u = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['U']['comissao'];
									$tot_comissao = $tot_comissao + $comissao_u;
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, $i, number_format($val_u, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, $i, number_format($pct_u, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, $i, number_format($comissao_u, 2, ",", "."));
									$col1 = ($col = $col + 1);
									$col2 = ($col = $col + 1);
									$col3 = ($col = $col + 1);
								}
								if (in_array("D", $considerar)){
									$val_d = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['D']['valor'];
									$tot_val = $tot_val + $val_d;
									$pct_d = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['D']['pct_comissao'];
									$comissao_d = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['D']['comissao'];
									$tot_comissao = $tot_comissao + $comissao_d;
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, $i, number_format($val_u, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, $i, number_format($pct_u, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, $i, number_format($comissao_d, 2, ",", "."));
									$col1 = ($col = $col + 1);
									$col2 = ($col = $col + 1);
									$col3 = ($col = $col + 1);
								}
								if (in_array("C", $considerar)){
									$val_c = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['C']['valor'];
									$tot_val = $tot_val + $val_c;
									$pct_c = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['C']['pct_comissao'];
									$comissao_c = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['C']['comissao'];
									$tot_comissao = $tot_comissao + $comissao_c;
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, $i, number_format($val_c, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, $i, number_format($pct_c, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, $i, number_format($comissao_c, 2, ",", "."));
									$col1 = ($col = $col + 1);
									$col2 = ($col = $col + 1);
									$col3 = ($col = $col + 1);
								}
								if (in_array("P", $considerar)){
									$val_p = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['P']['valor'];
									$tot_val = $tot_val + $val_p;
									$pct_p = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['P']['pct_comissao'];
									$comissao_p = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['P']['comissao'];
									$tot_comissao = $tot_comissao + $comissao_p;
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, $i, number_format($val_p, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, $i, number_format($pct_p, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, $i, number_format($comissao_p, 2, ",", "."));
									$col1 = ($col = $col + 1);
									$col2 = ($col = $col + 1);
									$col3 = ($col = $col + 1);
								}
								if (in_array("S", $considerar)){
									$val_s = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['S']['valor'];
									$tot_val = $tot_val + $val_s;
									$pct_s = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['S']['pct_comissao'];
									$comissao_s = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['S']['comissao'];
									$tot_comissao = $tot_comissao + $comissao_s;
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, $i, number_format($val_s, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, $i, number_format($pct_s, 2, ",", "."));
									$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, $i, number_format($comissao_s, 2, ",", "."));
									$col1 = ($col = $col + 1);
									$col2 = ($col = $col + 1);
									$col3 = ($col = $col + 1);
								}
								$f0 = $i - 1;
								if ($col == 6){
									$tot_val = "=SUM(B{$i})";
									$tot_comissao = "=SUM(D{$i}+F{$i})";
									$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
									$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$i}")->applyFromArray($styleArray);
									$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$i}")->applyFromArray($styleArray);
									$fim = "G";
									unset($styleArray);
									$objPHPExcel->getActiveSheet()->getStyle("A{$i}:G{$i}")->getFont()->setSize(14)->setName('Courier New');
									$objPHPExcel->getActiveSheet()->getStyle("B{$i}:G{$i}")->getNumberFormat()->setFormatCode('#,##0.00');
								}elseif ($col == 9){
									$tot_val = "=SUM(B{$i}+E{$i})";
									$tot_comissao = "=SUM(D{$i}+G{$i}+I{$i})";
									$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
									$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$i}")->applyFromArray($styleArray);
									$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$i}")->applyFromArray($styleArray);
									$objPHPExcel->getActiveSheet()->getStyle("J{$f0}:J{$i}")->applyFromArray($styleArray);
									$fim = "J";
									unset($styleArray);
									$objPHPExcel->getActiveSheet()->getStyle("A{$i}:J{$i}")->getFont()->setSize(14)->setName('Courier New');
									$objPHPExcel->getActiveSheet()->getStyle("B{$i}:J{$i}")->getNumberFormat()->setFormatCode('#,##0.00');
								}elseif ($col == 12){
									$tot_val = "=SUM(B{$i}+E{$i}+H{$i})";
									$tot_comissao = "=SUM(D{$i}+G{$i}+J{$i}+L{$i})";
									$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
									$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$i}")->applyFromArray($styleArray);
									$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$i}")->applyFromArray($styleArray);
									$objPHPExcel->getActiveSheet()->getStyle("J{$f0}:J{$i}")->applyFromArray($styleArray);
									$objPHPExcel->getActiveSheet()->getStyle("M{$f0}:M{$i}")->applyFromArray($styleArray);
									$fim = "M";
									unset($styleArray);
									$objPHPExcel->getActiveSheet()->getStyle("A{$i}:M{$i}")->getFont()->setSize(14)->setName('Courier New');
									$objPHPExcel->getActiveSheet()->getStyle("B{$i}:M{$i}")->getNumberFormat()->setFormatCode('#,##0.00');
								}elseif ($col == 15){
									$tot_val = "=SUM(B{$i}+E{$i}+H{$i}+K{$i})";
									$tot_comissao = "=SUM(D{$i}+G{$i}+J{$i}+M{$i}+O{$i})";
									$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
									$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$i}")->applyFromArray($styleArray);
									$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$i}")->applyFromArray($styleArray);
									$objPHPExcel->getActiveSheet()->getStyle("J{$f0}:J{$i}")->applyFromArray($styleArray);
									$objPHPExcel->getActiveSheet()->getStyle("M{$f0}:M{$i}")->applyFromArray($styleArray);
									$objPHPExcel->getActiveSheet()->getStyle("P{$f0}:P{$i}")->applyFromArray($styleArray);
									$fim = "P";
									unset($styleArray);
									$objPHPExcel->getActiveSheet()->getStyle("A{$i}:P{$i}")->getFont()->setSize(14)->setName('Courier New');
									$objPHPExcel->getActiveSheet()->getStyle("B{$i}:P{$i}")->getNumberFormat()->setFormatCode('#,##0.00');
								}elseif ($col == 18){
									$tot_val = "=SUM(B{$i}+E{$i}+H{$i}+K{$i}+N{$i})";
									$tot_comissao = "=SUM(D{$i}+G{$i}+J{$i}+M{$i}+P{$i}+R{$i})";
									$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
									$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$i}")->applyFromArray($styleArray);
									$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$i}")->applyFromArray($styleArray);
									$objPHPExcel->getActiveSheet()->getStyle("J{$f0}:J{$i}")->applyFromArray($styleArray);
									$objPHPExcel->getActiveSheet()->getStyle("M{$f0}:M{$i}")->applyFromArray($styleArray);
									$objPHPExcel->getActiveSheet()->getStyle("P{$f0}:P{$i}")->applyFromArray($styleArray);
									$objPHPExcel->getActiveSheet()->getStyle("S{$f0}:S{$i}")->applyFromArray($styleArray);
									$fim = "S";
									unset($styleArray);
									$objPHPExcel->getActiveSheet()->getStyle("A{$i}:S{$i}")->getFont()->setSize(14)->setName('Courier New');
									$objPHPExcel->getActiveSheet()->getStyle("B{$i}:S{$i}")->getNumberFormat()->setFormatCode('#,##0.00');
								}elseif ($col == 21){
									$tot_val = "=SUM(B{$i}+E{$i}+H{$i}+K{$i}+N{$i}+Q{$i})";
									$tot_comissao = "=SUM(D{$i}+G{$i}+J{$i}+M{$i}+P{$i}+S{$i}+U{$i})";
									$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
									$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$i}")->applyFromArray($styleArray);
									$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$i}")->applyFromArray($styleArray);
									$objPHPExcel->getActiveSheet()->getStyle("J{$f0}:J{$i}")->applyFromArray($styleArray);
									$objPHPExcel->getActiveSheet()->getStyle("M{$f0}:M{$i}")->applyFromArray($styleArray);
									$objPHPExcel->getActiveSheet()->getStyle("P{$f0}:P{$i}")->applyFromArray($styleArray);
									$objPHPExcel->getActiveSheet()->getStyle("S{$f0}:S{$i}")->applyFromArray($styleArray);
									$objPHPExcel->getActiveSheet()->getStyle("V{$f0}:V{$i}")->applyFromArray($styleArray);
									$fim = "V";
									unset($styleArray);
									$objPHPExcel->getActiveSheet()->getStyle("A{$i}:V{$i}")->getFont()->setSize(14)->setName('Courier New');
									$objPHPExcel->getActiveSheet()->getStyle("B{$i}:V{$i}")->getNumberFormat()->setFormatCode('#,##0.00');
								}
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, $i, $tot_val);
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, $i, $rs['premio']);
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, $i, $tot_comissao);
								$tot_val = 0;
								$tot_comissao = 0;
								$styleArray = array('borders' => array('bottom' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
								$objPHPExcel->getActiveSheet()->getStyle("A{$i}:{$fim}{$i}")->applyFromArray($styleArray);
								unset($styleArray);
							}
						}else{
							if (in_array("N", $considerar)){
								$val_n = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['N']['valor'];
								$tot_val = $tot_val + $val_n;
								$pct_n = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['N']['pct_comissao'];
								$comissao_n = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['N']['comissao'];
								$tot_comissao = $tot_comissao + $comissao_n;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, $i, number_format($val_n, 2, ",", "."));
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, $i, number_format($pct_n, 2, ",", "."));
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, $i, number_format($comissao_n, 2, ",", "."));
								$col1 = ($col = $col + 1);
								$col2 = ($col = $col + 1);
								$col3 = ($col = $col + 1);
							}
							if (in_array("U", $considerar)){
								$val_u = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['U']['valor'];
								$tot_val = $tot_val + $val_u;
								$pct_u = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['U']['pct_comissao'];
								$comissao_u = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['U']['comissao'];
								$tot_comissao = $tot_comissao + $comissao_u;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, $i, number_format($val_u, 2, ",", "."));
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, $i, number_format($pct_u, 2, ",", "."));
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, $i, number_format($comissao_u, 2, ",", "."));
								$col1 = ($col = $col + 1);
								$col2 = ($col = $col + 1);
								$col3 = ($col = $col + 1);
							}
							if (in_array("D", $considerar)){
								$val_d = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['D']['valor'];
								$tot_val = $tot_val + $val_d;
								$pct_d = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['D']['pct_comissao'];
								$comissao_d = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['D']['comissao'];
								$tot_comissao = $tot_comissao + $comissao_d;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, $i, number_format($val_u, 2, ",", "."));
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, $i, number_format($pct_u, 2, ",", "."));
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, $i, number_format($comissao_d, 2, ",", "."));
								$col1 = ($col = $col + 1);
								$col2 = ($col = $col + 1);
								$col3 = ($col = $col + 1);
							}
							if (in_array("C", $considerar)){
								$val_c = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['C']['valor'];
								$tot_val = $tot_val + $val_c;
								$pct_c = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['C']['pct_comissao'];
								$comissao_c = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['C']['comissao'];
								$tot_comissao = $tot_comissao + $comissao_c;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, $i, number_format($val_c, 2, ",", "."));
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, $i, number_format($pct_c, 2, ",", "."));
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, $i, number_format($comissao_c, 2, ",", "."));
								$col1 = ($col = $col + 1);
								$col2 = ($col = $col + 1);
								$col3 = ($col = $col + 1);
							}
							if (in_array("P", $considerar)){
								$val_p = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['P']['valor'];
								$tot_val = $tot_val + $val_p;
								$pct_p = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['P']['pct_comissao'];
								$comissao_p = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['P']['comissao'];
								$tot_comissao = $tot_comissao + $comissao_p;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, $i, number_format($val_p, 2, ",", "."));
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, $i, number_format($pct_p, 2, ",", "."));
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, $i, number_format($comissao_p, 2, ",", "."));
								$col1 = ($col = $col + 1);
								$col2 = ($col = $col + 1);
								$col3 = ($col = $col + 1);
							}
							if (in_array("S", $considerar)){
								$val_s = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['S']['valor'];
								$tot_val = $tot_val + $val_s;
								$pct_s = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['S']['pct_comissao'];
								$comissao_s = $_SESSION['consulta_sessao']['resultados'][$gs['grupo']][$rs['usuario']]['S']['comissao'];
								$tot_comissao = $tot_comissao + $comissao_s;
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, $i, number_format($val_s, 2, ",", "."));
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, $i, number_format($pct_s, 2, ",", "."));
								$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, $i, number_format($comissao_s, 2, ",", "."));
								$col1 = ($col = $col + 1);
								$col2 = ($col = $col + 1);
								$col3 = ($col = $col + 1);
							}
							$f0 = $i - 1;
							if ($col == 6){
								$tot_val = "=SUM(B{$i})";
								$tot_comissao = "=SUM(D{$i}+F{$i})";
								$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
								$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$i}")->applyFromArray($styleArray);
								$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$i}")->applyFromArray($styleArray);
								$fim = "G";
								unset($styleArray);
								$objPHPExcel->getActiveSheet()->getStyle("A{$i}:G{$i}")->getFont()->setSize(14)->setName('Courier New');
								$objPHPExcel->getActiveSheet()->getStyle("B{$i}:G{$i}")->getNumberFormat()->setFormatCode('#,##0.00');
							}elseif ($col == 9){
								$tot_val = "=SUM(B{$i}+E{$i})";
								$tot_comissao = "=SUM(D{$i}+G{$i}+I{$i})";
								$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
								$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$i}")->applyFromArray($styleArray);
								$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$i}")->applyFromArray($styleArray);
								$objPHPExcel->getActiveSheet()->getStyle("J{$f0}:J{$i}")->applyFromArray($styleArray);
								$fim = "J";
								unset($styleArray);
								$objPHPExcel->getActiveSheet()->getStyle("A{$i}:J{$i}")->getFont()->setSize(14)->setName('Courier New');
								$objPHPExcel->getActiveSheet()->getStyle("B{$i}:J{$i}")->getNumberFormat()->setFormatCode('#,##0.00');
							}elseif ($col == 12){
								$tot_val = "=SUM(B{$i}+E{$i}+H{$i})";
								$tot_comissao = "=SUM(D{$i}+G{$i}+J{$i}+L{$i})";
								$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
								$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$i}")->applyFromArray($styleArray);
								$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$i}")->applyFromArray($styleArray);
								$objPHPExcel->getActiveSheet()->getStyle("J{$f0}:J{$i}")->applyFromArray($styleArray);
								$objPHPExcel->getActiveSheet()->getStyle("M{$f0}:M{$i}")->applyFromArray($styleArray);
								$fim = "M";
								unset($styleArray);
								$objPHPExcel->getActiveSheet()->getStyle("A{$i}:M{$i}")->getFont()->setSize(14)->setName('Courier New');
								$objPHPExcel->getActiveSheet()->getStyle("B{$i}:M{$i}")->getNumberFormat()->setFormatCode('#,##0.00');
							}elseif ($col == 15){
								$tot_val = "=SUM(B{$i}+E{$i}+H{$i}+K{$i})";
								$tot_comissao = "=SUM(D{$i}+G{$i}+J{$i}+M{$i}+O{$i})";
								$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
								$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$i}")->applyFromArray($styleArray);
								$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$i}")->applyFromArray($styleArray);
								$objPHPExcel->getActiveSheet()->getStyle("J{$f0}:J{$i}")->applyFromArray($styleArray);
								$objPHPExcel->getActiveSheet()->getStyle("M{$f0}:M{$i}")->applyFromArray($styleArray);
								$objPHPExcel->getActiveSheet()->getStyle("P{$f0}:P{$i}")->applyFromArray($styleArray);
								$fim = "P";
								unset($styleArray);
								$objPHPExcel->getActiveSheet()->getStyle("A{$i}:P{$i}")->getFont()->setSize(14)->setName('Courier New');
								$objPHPExcel->getActiveSheet()->getStyle("B{$i}:P{$i}")->getNumberFormat()->setFormatCode('#,##0.00');
							}elseif ($col == 18){
								$tot_val = "=SUM(B{$i}+E{$i}+H{$i}+K{$i}+N{$i})";
								$tot_comissao = "=SUM(D{$i}+G{$i}+J{$i}+M{$i}+P{$i}+R{$i})";
								$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
								$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$i}")->applyFromArray($styleArray);
								$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$i}")->applyFromArray($styleArray);
								$objPHPExcel->getActiveSheet()->getStyle("J{$f0}:J{$i}")->applyFromArray($styleArray);
								$objPHPExcel->getActiveSheet()->getStyle("M{$f0}:M{$i}")->applyFromArray($styleArray);
								$objPHPExcel->getActiveSheet()->getStyle("P{$f0}:P{$i}")->applyFromArray($styleArray);
								$objPHPExcel->getActiveSheet()->getStyle("S{$f0}:S{$i}")->applyFromArray($styleArray);
								$fim = "S";
								unset($styleArray);
								$objPHPExcel->getActiveSheet()->getStyle("A{$i}:S{$i}")->getFont()->setSize(14)->setName('Courier New');
								$objPHPExcel->getActiveSheet()->getStyle("B{$i}:S{$i}")->getNumberFormat()->setFormatCode('#,##0.00');
							}elseif ($col == 21){
								$tot_val = "=SUM(B{$i}+E{$i}+H{$i}+K{$i}+N{$i}+Q{$i})";
								$tot_comissao = "=SUM(D{$i}+G{$i}+J{$i}+M{$i}+P{$i}+S{$i}+U{$i})";
								$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
								$objPHPExcel->getActiveSheet()->getStyle("D{$f0}:D{$i}")->applyFromArray($styleArray);
								$objPHPExcel->getActiveSheet()->getStyle("G{$f0}:G{$i}")->applyFromArray($styleArray);
								$objPHPExcel->getActiveSheet()->getStyle("J{$f0}:J{$i}")->applyFromArray($styleArray);
								$objPHPExcel->getActiveSheet()->getStyle("M{$f0}:M{$i}")->applyFromArray($styleArray);
								$objPHPExcel->getActiveSheet()->getStyle("P{$f0}:P{$i}")->applyFromArray($styleArray);
								$objPHPExcel->getActiveSheet()->getStyle("S{$f0}:S{$i}")->applyFromArray($styleArray);
								$objPHPExcel->getActiveSheet()->getStyle("V{$f0}:V{$i}")->applyFromArray($styleArray);
								$fim = "V";
								unset($styleArray);
								$objPHPExcel->getActiveSheet()->getStyle("A{$i}:V{$i}")->getFont()->setSize(14)->setName('Courier New');
								$objPHPExcel->getActiveSheet()->getStyle("B{$i}:V{$i}")->getNumberFormat()->setFormatCode('#,##0.00');
							}
							$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col1, $i, $tot_val);
							$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col2, $i, $rs['premio']);
							$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow($col3, $i, $tot_comissao);
							$tot_val = 0;
							$tot_comissao = 0;
							$styleArray = array('borders' => array('bottom' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
							$objPHPExcel->getActiveSheet()->getStyle("A{$i}:{$fim}{$i}")->applyFromArray($styleArray);
							unset($styleArray);		
						}
					}
					$deln = $de - 1;
					$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle("A{$deln}:A{$i}")->applyFromArray($styleArray);
					unset($styleArray);
				}
				
				$objPHPExcel->getActiveSheet()->setTitle( utf8_encode("Comiss�es M�naco"));
				
				$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
				$nome_arquivo = "COMISSAO-".date('d-m-Y').".xls";
				header('Content-Type: application/vnd.ms-excel');
				header("Content-Disposition: attachment;filename={$nome_arquivo}");
				header("Pragma: no-cache");
				header("Expires: 0");
				
				ob_end_clean();
				$objWriter->save('php://output');
				
			}elseif ($_POST['submeter'] == "exportar"){
				$exporte = "";
				foreach ($_SESSION['consulta_sessao']['metadados'] as $rs){
					$exporte .= "".str_pad($rs['vdb'], 9, "0", STR_PAD_LEFT).str_pad($rs['cpf'], 11, "0", STR_PAD_LEFT).str_pad($rs['comissao'], 15, "0", STR_PAD_LEFT)."\r\n";
				}
				$nome = "Metadados-".date("d-m-Y");
				$arquivo = fopen($_SERVER["DOCUMENT_ROOT"] . "/".RAIZ_PATH.$nome.".txt", "w");
				fwrite($arquivo, $exporte);
				fclose($anexo);
				fclose($arquivo);
				ob_end_clean();
				header('Content-type: text/plain');
				header("Content-Disposition: attachment;filename={$nome}.txt");
				header("Pragma: no-cache");
				header("Expires: 0");
				readfile($_SERVER["DOCUMENT_ROOT"] . "/".RAIZ_PATH.$nome.".txt");
				unlink($_SERVER["DOCUMENT_ROOT"] . "/".RAIZ_PATH.$nome.".txt");
				die();
			}
			$_SESSION['filtro_sessao'] = array('de' => $de, 'ate' => $ate, 'grupo' => $_POST['grupo']);
			$this->vendedores = $_SESSION['consulta_sessao']['vendedores'];
			$this->resultados = $_SESSION['consulta_sessao']['resultados'];	
		}
		if (isset($_SESSION['consulta_sessao']['vendedores'])){
			$this->vendedores = $_SESSION['consulta_sessao']['vendedores'];
			$this->resultados = $_SESSION['consulta_sessao']['resultados'];
		}	
		$this->view();
	}
}