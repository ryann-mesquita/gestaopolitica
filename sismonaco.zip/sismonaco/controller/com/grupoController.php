<?php

namespace controller\com;

use lib\Controller;
use helper\Security;
use api\com\apiGrupo;
use helper\Paginator;
use obj\com\Grupo;
use obj\geral\Log;
use api\geral\apiLog;
use api\geral\apiApollo;
use api\com\apiTipo;
use helper\Funcoes;
use api\geral\apiEmpresa;
use api\com\apiIndex;
use api\com\apiCampanha;

class grupoController extends Controller {
	
	public function __construct() {
		
		parent::__construct();
		
		new Security($this->getModule(),$this->getController(),$this->getAction());
	}
	
	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Lista de Grupo";
		$apiGrupo = new apiGrupo();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$busca = array(
				'1' => array('c' => '1', 'coluna' => 'ativo', 'valor' => '1'),
				'2' => array('c' => '1', 'coluna' => 'ativo', 'valor' => '0'),
				'3' => array('c' => '2', 'coluna' => 'des_grupo', 'valor' => @$_POST['busca_valor']),
				'4' => array('c' => '3', 'coluna' => "",'valor' => "")
			);
			if(isset($busca[$_POST['busca']])){
				$this->dados = array('grupo' => $apiGrupo->filtroGrupo($busca[$_POST['busca']]['c'], $_SESSION['empresa_sessao'], $busca[$_POST['busca']]['coluna'], $busca[$_POST['busca']]['valor']));
				$_SESSION['filtro_sessao'] = array('c' => $busca[$_POST['busca']]['c'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'valor' => $busca[$_POST['busca']]['valor'], 'busca' => $_POST['busca'], 'busca_valor' => isset($_POST['busca_valor']) ? $_POST['busca_valor'] : "");
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'com/index/index/acessonegado');
				die();
			}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				$this->dados = array('grupo' => $apiGrupo->filtroGrupo($_SESSION['filtro_sessao']['c'], $_SESSION['empresa_sessao'], $_SESSION['filtro_sessao']['coluna'], $_SESSION['filtro_sessao']['valor']));
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('grupo' => $apiGrupo->filtroGrupo('3', $_SESSION['empresa_sessao'], '', ''));
					$_SESSION['filtro_sessao'] = array('c' => '3', 'coluna' => 'ativo' , 'valor' => '', 'busca' => '4', 'busca_valor' => '');
					$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}
		}
		$TotalItem = (is_array($this->dados['grupo']) ? count($this->dados['grupo']) : 0);
		$this->dados['grupo'] = array_chunk($this->dados['grupo'], $ItemPorPagina);
		@$this->dados['grupo'] = $this->dados['grupo'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->view();
	}
	
	public function adicionar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Cadastro de Grupo";
		$apiGrupo = new apiGrupo();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		$apiTipo = new apiTipo();
		$this->tipo = $apiTipo->filtroTipo('1','3','ativo', '1');
		foreach ($this->tipo as $rs){
			$strVal = explode(';;', $rs->LEIAUTE);
			foreach ($strVal as $i){
				@list($k, $v) = explode('||', $i);
				$leiaute[$k] = $v;
			}
			$this->considerar[$rs->TIPO]= explode(",", $leiaute["CONSIDERAR"]);
			@$this->sobre[$rs->TIPO] = explode(",", $leiaute["SOBRE"]);
		}
		$apiApollo = new apiApollo();
		$this->vendedores = $apiApollo->getVendedoresapollo($_SESSION['empresa_sessao']);
		$this->empresas = $apiApollo->getEmpresaapollo($_SESSION['empresa_sessao']);
		$this->todasempresas = $apiApollo->getAllempresaapollo();
		$apiEmpresa = new apiEmpresa();
		$this->emp = $apiEmpresa->geEmpresarevenda($_SESSION['empresa_sessao']);
		$apiCampanha = new apiCampanha();
		$this->campanha = $apiCampanha->filtroCampanha('3',$this->emp->EMPRESA);
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$funcoes = new Funcoes();
			$Post = new Grupo();
			$Post->tipo = $_POST['tipo'];
			$Post->empresa = $_SESSION['empresa_sessao'];
			$Post->des_grupo = strtoupper($funcoes->retiraAcentos(trim($_POST['des_grupo'])));
			$Post->des_formula = $_POST['des_formula'];
			$apiGrupo = new apiGrupo();
			$rs = $apiGrupo->filtroGrupo('4',$_SESSION['empresa_sessao'],'des_grupo',$Post->des_grupo, $Post->tipo);
			if ((is_array($rs) ? count($rs) : 0) > 0){
				$this->rollback = new Grupo();
				$this->rollback->tipo = $_POST['tipo'];
				$this->rollback->des_grupo = $_POST['des_grupo'];
				$this->rollback->des_formula = $_POST['des_formula'];
				$this->rollback->campanha = $_POST['campanha'];
				$this->rollback->campanha_de = $_POST['campanha_de'];
				$this->rollback->campanha_ate = $_POST['campanha_ate'];
				if (isset($_POST['empresa'])){
					foreach ($_POST['empresa'] as $rs){
						$this->empresas_rollback["{$rs}"] = $rs;
					}
				}
				if (isset($_POST['vendedor'])){
					foreach ($_POST['vendedor'] as $rs){
						$this->vendedores_rollback["{$rs}"] = $rs;
					}
				}
				if (isset($_POST['equipe'])){
					foreach ($_POST['equipe'] as $rs){
						$this->equipes_rollback["{$rs}"] = $rs;
					}
				}
				if (isset($_POST['equipen'])){
					foreach ($_POST['equipen'] as $rs){
						$this->equipesn_rollback["{$rs}"] = $rs;
					}
				}
				if (isset($_POST['equipeu'])){
					foreach ($_POST['equipeu'] as $rs){
						$this->equipesu_rollback["{$rs}"] = $rs;
					}
				}
				if (isset($_POST['equiped'])){
					foreach ($_POST['equiped'] as $rs){
						$this->equipesd_rollback["{$rs}"] = $rs;
					}
				}
				if (isset($_POST['ignorar_vendedor'])){
					foreach ($_POST['ignorar_vendedor'] as $rs){
						$this->ignorar_vendedor_rollback["{$rs}"] = $rs;
					}
				}
				if (isset($_POST['departamento'])){
					foreach ($_POST['departamento'] as $rs){
						$this->departamentos_rollback["{$rs}"] = $rs;
					}
				}
				$this->rollback->considerar = $_POST['considerar'];
				$this->rollback->faturamento = $_POST['faturamento'];
				$this->rollback->por = $_POST['por'];
				$this->campo_formula = array();
				if ($_POST['faturamento'] == 'D' || $_POST['faturamento'] == 'M'){
					if ($_POST['faturamento'] == 'D'){
						$de1 = $funcoes->sanearValor($_POST['desc_de1']);
						$this->campo_formula["DESC_DE1"] = $de1;
						$ate1 = $funcoes->sanearValor($_POST['desc_ate1']);
						$this->campo_formula["DESC_ATE1"] = $ate1;
						$comissao1 = $funcoes->sanearValor($_POST['desc_comissao1']);
						$this->campo_formula["DESC_COMISSAO1"] = $comissao1;
						if ($_POST['desc_de2'] != ""){
							$de2 = $funcoes->sanearValor($_POST['desc_de2']);
							$this->campo_formula["DESC_DE2"] = $de2;
							$ate2 = $funcoes->sanearValor($_POST['desc_ate2']);
							$this->campo_formula["DESC_ATE2"] = $ate2;
							$comissao2 = $funcoes->sanearValor($_POST['desc_comissao2']);
							$this->campo_formula["DESC_COMISSAO2"] = $comissao2;
						}
						if ($_POST['desc_de3'] != ""){
							$de3 = $funcoes->sanearValor($_POST['desc_de3']);
							$this->campo_formula["DESC_DE3"] = $de3;
							$ate3 = $funcoes->sanearValor($_POST['desc_ate3']);
							$this->campo_formula["DESC_ATE3"] = $ate3;
							$comissao3 = $funcoes->sanearValor($_POST['desc_comissao3']);
							$this->campo_formula["DESC_COMISSAO3"] = $comissao3;
						}
						if ($_POST['desc_de4'] != ""){
							$de4 = $funcoes->sanearValor($_POST['desc_de4']);
							$this->campo_formula["DESC_DE4"] = $de4;
							$ate4 = $funcoes->sanearValor($_POST['desc_ate4']);
							$this->campo_formula["DESC_ATE4"] = $ate4;
							$comissao4 = $funcoes->sanearValor($_POST['desc_comissao4']);
							$this->campo_formula["DESC_COMISSAO4"] = $comissao4;
						}
						if ($_POST['desc_de5'] != ""){
							$de5 = $funcoes->sanearValor($_POST['desc_de5']);
							$this->campo_formula["DESC_DE5"] = $de5;
							$ate5 = $funcoes->sanearValor($_POST['desc_ate5']);
							$this->campo_formula["DESC_ATE5"] = $ate2;
							$comissao5 = $funcoes->sanearValor($_POST['desc_comissao5']);
							$this->campo_formula["DESC_COMISSAO5"] = $comissao5;
						}
						$this->campo_formula["META_VEICULO"] = $_POST['meta_veiculo'];
					}elseif ($_POST['faturamento'] == 'M'){
						$de1 = $funcoes->sanearValor($_POST['marg_de1']);
						$this->campo_formula["MARG_DE1"] = $de1;
						$ate1 = $funcoes->sanearValor($_POST['marg_ate1']);
						$this->campo_formula["MARG_ATE1"] = $ate1;
						$comissao1 = $funcoes->sanearValor($_POST['marg_comissao1']);
						$this->campo_formula["MARG_COMISSAO1"] = $comissao1;
						if ($_POST['marg_de2'] != ""){
							$de2 = $funcoes->sanearValor($_POST['marg_de2']);
							$this->campo_formula["MARG_DE2"] = $de2;
							$ate2 = $funcoes->sanearValor($_POST['marg_ate2']);
							$this->campo_formula["MARG_ATE2"] = $ate2;
							$comissao2 = $funcoes->sanearValor($_POST['marg_comissao2']);
							$this->campo_formula["MARG_COMISSAO2"] = $comissao2;
						}
						if ($_POST['marg_de3'] != ""){
							$de3 = $funcoes->sanearValor($_POST['marg_de3']);
							$this->campo_formula["MARG_DE3"] = $de3;
							$ate3 = $funcoes->sanearValor($_POST['marg_ate3']);
							$this->campo_formula["MARG_ATE3"] = $ate3;
							$comissao3 = $funcoes->sanearValor($_POST['marg_comissao3']);
							$this->campo_formula["MARG_COMISSAO3"] = $comissao3;
						}
						if ($_POST['marg_de4'] != ""){
							$de4 = $funcoes->sanearValor($_POST['marg_de4']);
							$this->campo_formula["MARG_DE4"] = $de4;
							$ate4 = $funcoes->sanearValor($_POST['marg_ate4']);
							$this->campo_formula["MARG_ATE4"] = $ate4;
							$comissao4 = $funcoes->sanearValor($_POST['marg_comissao4']);
							$this->campo_formula["MARG_COMISSAO4"] = $comissao4;
						}
						if ($_POST['marg_de5'] != ""){
							$de5 = $funcoes->sanearValor($_POST['marg_de5']);
							$this->campo_formula["MARG_DE5"] = $de5;
							$ate5 = $funcoes->sanearValor($_POST['marg_ate5']);
							$this->campo_formula["MARG_ATE5"] = $ate2;
							$comissao5 = $funcoes->sanearValor($_POST['marg_comissao5']);
							$this->campo_formula["MARG_COMISSAO5"] = $comissao5;
						}
						
						if (isset($_POST['meta_novos'])){
							$this->campo_formula["META_NOVOS"] = $_POST['meta_novos'];
						}
						if (isset($_POST['meta_usados'])){
							$this->campo_formula["META_USADOS"] = $_POST['meta_usados'];
						}
						if (isset($_POST['meta_direto'])){
							$this->campo_formula["META_DIRETO"] = $_POST['meta_direto'];
						}
						if (isset($_POST['meta_consorcio'])){
							$this->campo_formula["META_CONSORCIO"] = $_POST['meta_consorcio'];
						}
						if (isset($_POST['meta_pecas'])){
							$this->campo_formula["META_PECAS"] = $_POST['meta_pecas'];
						}
						if (isset($_POST['meta_maodeobra'])){
							$this->campo_formula["META_MAODEOBRA"] = $_POST['meta_maodeobra'];
						}
					}
					if ($cnh == 'sim'){
						$venda = $funcoes->sanearValor($_POST['comissao_venda']);
						$this->campo_formula["COMISSAO_VENDA"] = $venda;
						if ($_POST['comissao_parcela1'] != ""){
							$parc1 = $funcoes->sanearValor($_POST['comissao_parcela1']);
							$this->campo_formula["COMISSAO_PARCELA1"] = $parc1;
							$this->campo_formula["NRO_PARCELA1"] = $_POST['nro_parcela1'];
						}
						if ($_POST['comissao_parcela2'] != ""){
							$parc2 = $funcoes->sanearValor($_POST['comissao_parcela2']);
							$this->campo_formula["COMISSAO_PARCELA2"] = $parc2;
							$this->campo_formula["NRO_PARCELA2"] = $_POST['nro_parcela2'];
						}
						if ($_POST['comissao_parcela3'] != ""){
							$parc3 = $funcoes->sanearValor($_POST['comissao_parcela3']);
							$this->campo_formula["COMISSAO_PARCELA3"] = $parc3;
							$this->campo_formula["NRO_PARCELA3"] = $_POST['nro_parcela3'];
						}
						$this->campo_formula["META_CONSORCIO"] = $_POST['meta_consorcio'];
						$this->campo_formula["META_PARCELA"] = $_POST['meta_parcela'];
					}
				}elseif ($_POST['faturamento'] == 'B' || $_POST['faturamento'] == 'L'){
					if ($_POST['por'] == "OBJ"){
						$de1 = $funcoes->sanearValor($_POST['obj_de1']);
						$this->campo_formula["OBJ_DE1"] = $de1;
						$ate1 = $funcoes->sanearValor($_POST['obj_ate1']);
						$this->campo_formula["OBJ_ATE1"] = $ate1;
						$comissao1 = $funcoes->sanearValor($_POST['obj_comissao1']);
						$this->campo_formula["OBJ_COMISSAO1"] = $comissao1;
						if ($_POST['obj_de2'] != ""){
							$de2 = $funcoes->sanearValor($_POST['obj_de2']);
							$this->campo_formula["OBJ_DE2"] = $de2;
							$ate2 = $funcoes->sanearValor($_POST['obj_ate2']);
							$this->campo_formula["OBJ_ATE2"] = $ate2;
							$comissao2 = $funcoes->sanearValor($_POST['obj_comissao2']);
							$this->campo_formula["OBJ_COMISSAO2"] = $comissao2;
						}
						if ($_POST['obj_de3'] != ""){
							$de3 = $funcoes->sanearValor($_POST['obj_de3']);
							$this->campo_formula["OBJ_DE3"] = $de3;
							$ate3 = $funcoes->sanearValor($_POST['obj_ate3']);
							$this->campo_formula["OBJ_ATE3"] = $ate3;
							$comissao3 = $funcoes->sanearValor($_POST['obj_comissao3']);
							$this->campo_formula["OBJ_COMISSAO3"] = $comissao3;
						}
						if ($_POST['obj_de4'] != ""){
							$de4 = $funcoes->sanearValor($_POST['obj_de4']);
							$this->campo_formula["OBJ_DE4"] = $de4;
							$ate4 = $funcoes->sanearValor($_POST['obj_ate4']);
							$this->campo_formula["OBJ_ATE4"] = $ate4;
							$comissao4 = $funcoes->sanearValor($_POST['obj_comissao4']);
							$this->campo_formula["OBJ_COMISSAO4"] = $comissao4;
						}
						if ($_POST['obj_de5'] != ""){
							$de5 = $funcoes->sanearValor($_POST['obj_de5']);
							$this->campo_formula["OBJ_DE5"] = $de5;
							$ate5 = $funcoes->sanearValor($_POST['obj_ate5']);
							$this->campo_formula["OBJ_ATE5"] = $ate2;
							$comissao5 = $funcoes->sanearValor($_POST['obj_comissao5']);
							$this->campo_formula["OBJ_COMISSAO5"] = $comissao5;
						}
						$this->campo_formula["OBJ_VENDA"] = $_POST['obj_venda'];
						if (isset($_POST['meta_novos'])){
							$this->campo_formula["META_NOVOS"] = $_POST['meta_novos'];
						}
						if (isset($_POST['meta_usados'])){
							$this->campo_formula["META_USADOS"] = $_POST['meta_usados'];
						}
						if (isset($_POST['meta_direto'])){
							$this->campo_formula["META_DIRETO"] = $_POST['meta_direto'];
						}
						if (isset($_POST['meta_consorcio'])){
							$this->campo_formula["META_CONSORCIO"] = $_POST['meta_consorcio'];
						}
						if (isset($_POST['meta_pecas'])){
							$this->campo_formula["META_PECAS"] = $_POST['meta_pecas'];
						}
						if (isset($_POST['meta_maodeobra'])){
							$this->campo_formula["META_MAODEOBRA"] = $_POST['meta_maodeobra'];
						}
					}elseif ($_POST['por'] == "FAI"){
						if (isset($_POST['fai_auto'])){
							$this->campo_formula["FAI_AUTO"] = 'S';
						}
						$de1 = $funcoes->sanearValor($_POST['fai_de1']);
						$this->campo_formula["FAI_DE1"] = $de1;
						$ate1 = $funcoes->sanearValor($_POST['fai_ate1']);
						$this->campo_formula["FAI_ATE1"] = $ate1;
						$comissao1 = $funcoes->sanearValor($_POST['fai_comissao1']);
						$this->campo_formula["FAI_COMISSAO1"] = $comissao1;
						if ($_POST['premio1'] != ""){
							$premio1 = $funcoes->sanearValor($_POST['premio1']);
							$this->campo_formula["PREMIO1"] = $premio1;
						}
						if ($_POST['fai_de2'] != ""){
							$de2 = $funcoes->sanearValor($_POST['fai_de2']);
							$this->campo_formula["FAI_DE2"] = $de2;
							$ate2 = $funcoes->sanearValor($_POST['fai_ate2']);
							$this->campo_formula["FAI_ATE2"] = $ate2;
							$comissao2 = $funcoes->sanearValor($_POST['fai_comissao2']);
							$this->campo_formula["FAI_COMISSAO2"] = $comissao2;
							if ($_POST['premio2'] != ""){
								$premio2 = $funcoes->sanearValor($_POST['premio2']);
								$this->campo_formula["PREMIO2"] = $premio2;
							}
						}
						if ($_POST['fai_de3'] != ""){
							$de3 = $funcoes->sanearValor($_POST['fai_de3']);
							$this->campo_formula["FAI_DE3"] = $de3;
							$ate3 = $funcoes->sanearValor($_POST['fai_ate3']);
							$this->campo_formula["FAI_ATE3"] = $ate3;
							$comissao3 = $funcoes->sanearValor($_POST['fai_comissao3']);
							$this->campo_formula["FAI_COMISSAO3"] = $comissao3;
							if ($_POST['premio3'] != ""){
								$premio3 = $funcoes->sanearValor($_POST['premio3']);
								$this->campo_formula["PREMIO3"] = $premio3;
							}
						}
						if ($_POST['fai_de4'] != ""){
							$de4 = $funcoes->sanearValor($_POST['fai_de4']);
							$this->campo_formula["FAI_DE4"] = $de4;
							$ate4 = $funcoes->sanearValor($_POST['fai_ate4']);
							$this->campo_formula["FAI_ATE4"] = $ate4;
							$comissao4 = $funcoes->sanearValor($_POST['fai_comissao4']);
							$this->campo_formula["FAI_COMISSAO4"] = $comissao4;
							if ($_POST['premio4'] != ""){
								$premio4 = $funcoes->sanearValor($_POST['premio4']);
								$this->campo_formula["PREMIO4"] = $premio4;
							}
						}
						if ($_POST['fai_de5'] != ""){
							$de5 = $funcoes->sanearValor($_POST['fai_de5']);
							$this->campo_formula["FAI_DE5"] = $de5;
							$ate5 = $funcoes->sanearValor($_POST['fai_ate5']);
							$this->campo_formula["FAI_ATE5"] = $ate2;
							$comissao5 = $funcoes->sanearValor($_POST['fai_comissao5']);
							$this->campo_formula["FAI_COMISSAO5"] = $comissao5;
						}
						if (isset($_POST['meta_novos'])){
							$this->campo_formula["META_NOVOS"] = $_POST['meta_novos'];
						}
						if (isset($_POST['meta_usados'])){
							$this->campo_formula["META_USADOS"] = $_POST['meta_usados'];
						}
						if (isset($_POST['meta_direto'])){
							$this->campo_formula["META_DIRETO"] = $_POST['meta_direto'];
						}
						if (isset($_POST['meta_consorcio'])){
							$this->campo_formula["META_CONSORCIO"] = $_POST['meta_consorcio'];
						}
						if (isset($_POST['meta_pecas'])){
							$this->campo_formula["META_PECAS"] = $_POST['meta_pecas'];
						}
						if (isset($_POST['meta_maodeobra'])){
							$this->campo_formula["META_MAODEOBRA"] = $_POST['meta_maodeobra'];
						}
						if (isset($_POST['meta_premio'])){
							$this->campo_formula["META_PREMIO"] = $_POST['meta_premio'];
						}
					}elseif ($_POST['por'] == "TIP"){
						if (isset($_POST['comissao_novos'])){
							$com = $funcoes->sanearValor($_POST['comissao_novos']);
							$this->campo_formula["COMISSAO_NOVOS"] = $com;
							$this->campo_formula["META_NOVOS"] = $_POST['meta_novos'];
						}
						if (isset($_POST['comissao_usados'])){
							$com = $funcoes->sanearValor($_POST['comissao_usados']);
							$this->campo_formula["COMISSAO_USADOS"] = $com;
							$this->campo_formula["META_USADOS"] = $_POST['meta_usados'];
						}
						if (isset($_POST['comissao_direto'])){
							$com = $funcoes->sanearValor($_POST['comissao_direto']);
							$this->campo_formula["COMISSAO_DIRETO"] = $com;
							$this->campo_formula["META_DIRETO"] = $_POST['meta_direto'];
						}
						if (isset($_POST['comissao_consorcio'])){
							$com = $funcoes->sanearValor($_POST['comissao_consorcio']);
							$this->campo_formula["COMISSAO_CONSORCIO"] = $com;
							$this->campo_formula["META_CONSORCIO"] = $_POST['meta_consorcio'];
						}
						if (isset($_POST['comissao_pecas'])){
							$com = $funcoes->sanearValor($_POST['comissao_pecas']);
							$this->campo_formula["COMISSAO_PECAS"] = $com;
							$this->campo_formula["META_PECAS"] = $_POST['meta_pecas'];
						}
						if (isset($_POST['comissao_maodeobra'])){
							$com = $funcoes->sanearValor($_POST['comissao_maodeobra']);
							$this->campo_formula["COMISSAO_MAODEOBRA"] = $com;
							$this->campo_formula["META_MAODEOBRA"] = $_POST['meta_maodeobra'];
						}
					}
				}
				$this->Alert = "J� existe um grupo com esse nome cadastrado!";
			}else{
				$empresa = "";
				foreach ($_POST['empresa'] as $rs){
					$empresa .= "{$rs},";
				}
				$empresa = substr($empresa,0,-1);
				$Post->campo_formula = "EMPRESA||{$empresa};;";
				$vendedor = "";
				foreach ($_POST['vendedor'] as $rs){
					$vendedor .= "{$rs},";
				}
				$vendedor = substr($vendedor,0,-1);
				$Post->campo_formula .= "VENDEDOR||{$vendedor};;";
				if (isset($_POST['equipe'])){
					$equipe = "";
					foreach ($_POST['equipe'] as $rs){
						$equipe .= "{$rs},";
					}
					$equipe = substr($equipe,0,-1);
					$Post->campo_formula .= "EQUIPE||{$equipe};;";
				}
				if (isset($_POST['equipen'])){
					$equipen = "";
					foreach ($_POST['equipen'] as $rs){
						$equipen .= "{$rs},";
					}
					$equipen = substr($equipen,0,-1);
					$Post->campo_formula .= "EQUIPEN||{$equipen};;";
				}
				if (isset($_POST['equipeu'])){
					$equipeu = "";
					foreach ($_POST['equipeu'] as $rs){
						$equipeu .= "{$rs},";
					}
					$equipeu = substr($equipeu,0,-1);
					$Post->campo_formula .= "EQUIPEU||{$equipeu};;";
				}
				if (isset($_POST['equiped'])){
					$equiped = "";
					foreach ($_POST['equiped'] as $rs){
						$equiped .= "{$rs},";
					}
					$equiped = substr($equiped,0,-1);
					$Post->campo_formula .= "EQUIPED||{$equiped};;";
				}
				if (isset($_POST['ignorar_vendedor'])){
					$ivendedor = "";
					foreach ($_POST['ignorar_vendedor'] as $rs){
						$ivendedor .= "{$rs},";
					}
					$ivendedor = substr($ivendedor,0,-1);
					$Post->campo_formula .= "IGNORAR_VENDEDOR||{$ivendedor};;";
				}
				if (isset($_POST['departamento'])){
					$departamento = "";
					foreach ($_POST['departamento'] as $rs){
						$departamento .= "{$rs},";
					}
					$departamento = substr($departamento,0,-1);
					$Post->campo_formula .= "DEPARTAMENTO||{$departamento};;";
				}
				$considerar = "";
				$cnh = "";
				foreach ($_POST['considerar'] as $rs){
					if ($rs == 'C'){
						$cnh = "sim";
					}
					$considerar .= "{$rs},";
				}
				$considerar = substr($considerar,0,-1);
				$Post->campo_formula .= "CONSIDERAR||{$considerar};;";
				$Post->campo_formula .= "FATURAMENTO||{$_POST['faturamento']};;";
				$Post->campo_formula .= "POR||{$_POST['por']};;";
				if ($_POST['campanha'] != ""){
					$Post->campo_formula .= "CAMPANHA||{$_POST['campanha']};;";
				}
				if ($_POST['campanha_de'] != ""){
					$Post->campo_formula .= "CAMPANHA_DE||{$_POST['campanha_de']};;";
				}
				if ($_POST['campanha_ate'] != ""){
					$Post->campo_formula .= "CAMPANHA_ATE||{$_POST['campanha_ate']};;";
				}
				if ($_POST['faturamento'] == 'D' || $_POST['faturamento'] == 'M'){
					if ($_POST['faturamento'] == 'D'){
						$de1 = $funcoes->sanearValor($_POST['desc_de1']);
						$Post->campo_formula .= "DESC_DE1||{$de1};;";
						$ate1 = $funcoes->sanearValor($_POST['desc_ate1']);
						$Post->campo_formula .= "DESC_ATE1||{$ate1};;";
						$comissao1 = $funcoes->sanearValor($_POST['desc_comissao1']);
						$Post->campo_formula .= "DESC_COMISSAO1||{$comissao1};;";
						if ($_POST['desc_de2'] != ""){
							$de2 = $funcoes->sanearValor($_POST['desc_de2']);
							$Post->campo_formula .= "DESC_DE2||{$de2};;";
							$ate2 = $funcoes->sanearValor($_POST['desc_ate2']);
							$Post->campo_formula .= "DESC_ATE2||{$ate2};;";
							$comissao2 = $funcoes->sanearValor($_POST['desc_comissao2']);
							$Post->campo_formula .= "DESC_COMISSAO2||{$comissao2};;";
						}
						if ($_POST['desc_de3'] != ""){
							$de3 = $funcoes->sanearValor($_POST['desc_de3']);
							$Post->campo_formula .= "DESC_DE3||{$de3};;";
							$ate3 = $funcoes->sanearValor($_POST['desc_ate3']);
							$Post->campo_formula .= "DESC_ATE3||{$ate3};;";
							$comissao3 = $funcoes->sanearValor($_POST['desc_comissao3']);
							$Post->campo_formula .= "DESC_COMISSAO3||{$comissao3};;";
						}
						if ($_POST['desc_de4'] != ""){
							$de4 = $funcoes->sanearValor($_POST['desc_de4']);
							$Post->campo_formula .= "DESC_DE4||{$de4};;";
							$ate4 = $funcoes->sanearValor($_POST['desc_ate4']);
							$Post->campo_formula .= "DESC_ATE4||{$ate4};;";
							$comissao4 = $funcoes->sanearValor($_POST['desc_comissao4']);
							$Post->campo_formula .= "DESC_COMISSAO4||{$comissao4};;";
						}
						if ($_POST['desc_de5'] != ""){
							$de5 = $funcoes->sanearValor($_POST['desc_de5']);
							$Post->campo_formula .= "DESC_DE5||{$de5};;";
							$ate5 = $funcoes->sanearValor($_POST['desc_ate5']);
							$Post->campo_formula .= "DESC_ATE5||{$ate2};;";
							$comissao5 = $funcoes->sanearValor($_POST['desc_comissao5']);
							$Post->campo_formula .= "DESC_COMISSAO5||{$comissao5};;";
						}
						$Post->campo_formula .= "META_VEICULO||{$_POST['meta_veiculo']};;";
					}elseif ($_POST['faturamento'] == 'M'){
						$de1 = $funcoes->sanearValor($_POST['marg_de1']);
						$Post->campo_formula .= "MARG_DE1||{$de1};;";
						$ate1 = $funcoes->sanearValor($_POST['marg_ate1']);
						$Post->campo_formula .= "MARG_ATE1||{$ate1};;";
						$comissao1 = $funcoes->sanearValor($_POST['marg_comissao1']);
						$Post->campo_formula .= "MARG_COMISSAO1||{$comissao1};;";
						if ($_POST['marg_de2'] != ""){
							$de2 = $funcoes->sanearValor($_POST['marg_de2']);
							$Post->campo_formula .= "MARG_DE2||{$de2};;";
							$ate2 = $funcoes->sanearValor($_POST['marg_ate2']);
							$Post->campo_formula .= "MARG_ATE2||{$ate2};;";
							$comissao2 = $funcoes->sanearValor($_POST['marg_comissao2']);
							$Post->campo_formula .= "MARG_COMISSAO2||{$comissao2};;";
						}
						if ($_POST['marg_de3'] != ""){
							$de3 = $funcoes->sanearValor($_POST['marg_de3']);
							$Post->campo_formula .= "MARG_DE3||{$de3};;";
							$ate3 = $funcoes->sanearValor($_POST['marg_ate3']);
							$Post->campo_formula .= "MARG_ATE3||{$ate3};;";
							$comissao3 = $funcoes->sanearValor($_POST['marg_comissao3']);
							$Post->campo_formula .= "MARG_COMISSAO3||{$comissao3};;";
						}
						if ($_POST['marg_de4'] != ""){
							$de4 = $funcoes->sanearValor($_POST['marg_de4']);
							$Post->campo_formula .= "MARG_DE4||{$de4};;";
							$ate4 = $funcoes->sanearValor($_POST['marg_ate4']);
							$Post->campo_formula .= "MARG_ATE4||{$ate4};;";
							$comissao4 = $funcoes->sanearValor($_POST['marg_comissao4']);
							$Post->campo_formula .= "MARG_COMISSAO4||{$comissao4};;";
						}
						if ($_POST['marg_de5'] != ""){
							$de5 = $funcoes->sanearValor($_POST['marg_de5']);
							$Post->campo_formula .= "MARG_DE5||{$de5};;";
							$ate5 = $funcoes->sanearValor($_POST['marg_ate5']);
							$Post->campo_formula .= "MARG_ATE5||{$ate2};;";
							$comissao5 = $funcoes->sanearValor($_POST['marg_comissao5']);
							$Post->campo_formula .= "MARG_COMISSAO5||{$comissao5};;";
						}
						
						if (isset($_POST['meta_novos'])){
							$Post->campo_formula .= "META_NOVOS||{$_POST['meta_novos']};;";
						}
						if (isset($_POST['meta_usados'])){
							$Post->campo_formula .= "META_USADOS||{$_POST['meta_usados']};;";
						}
						if (isset($_POST['meta_direto'])){
							$Post->campo_formula .= "META_DIRETO||{$_POST['meta_direto']};;";
						}
						if (isset($_POST['meta_consorcio'])){
							$Post->campo_formula .= "META_CONSORCIO||{$_POST['meta_consorcio']};;";
						}
						if (isset($_POST['meta_pecas'])){
							$Post->campo_formula .= "META_PECAS||{$_POST['meta_pecas']};;";
						}
						if (isset($_POST['meta_maodeobra'])){
							$Post->campo_formula .= "META_MAODEOBRA||{$_POST['meta_maodeobra']};;";
						}
					}
					if ($cnh == 'sim'){
						$venda = $funcoes->sanearValor($_POST['comissao_venda']);
						$Post->campo_formula .= "COMISSAO_VENDA||{$venda};;";
						if ($_POST['comissao_parcela1'] != ""){
							$parc1 = $funcoes->sanearValor($_POST['comissao_parcela1']);
							$Post->campo_formula .= "COMISSAO_PARCELA1||{$parc1};;";
							$Post->campo_formula .= "NRO_PARCELA1||{$_POST['nro_parcela1']};;";
						}
						if ($_POST['comissao_parcela2'] != ""){
							$parc2 = $funcoes->sanearValor($_POST['comissao_parcela2']);
							$Post->campo_formula .= "COMISSAO_PARCELA2||{$parc2};;";
							$Post->campo_formula .= "NRO_PARCELA2||{$_POST['nro_parcela2']};;";
						}
						if ($_POST['comissao_parcela3'] != ""){
							$parc3 = $funcoes->sanearValor($_POST['comissao_parcela3']);
							$Post->campo_formula .= "COMISSAO_PARCELA3||{$parc3};;";
							$Post->campo_formula .= "NRO_PARCELA3||{$_POST['nro_parcela3']};;";
						}
						$Post->campo_formula .= "META_CONSORCIO||{$_POST['meta_consorcio']};;";
						$Post->campo_formula .= "META_PARCELA||{$_POST['meta_parcela']};;";
					}
				}elseif ($_POST['faturamento'] == 'B' || $_POST['faturamento'] == 'L'){
					if ($_POST['por'] == "OBJ"){
						$de1 = $funcoes->sanearValor($_POST['obj_de1']);
						$Post->campo_formula .= "OBJ_DE1||{$de1};;";
						$ate1 = $funcoes->sanearValor($_POST['obj_ate1']);
						$Post->campo_formula .= "OBJ_ATE1||{$ate1};;";
						$comissao1 = $funcoes->sanearValor($_POST['obj_comissao1']);
						$Post->campo_formula .= "OBJ_COMISSAO1||{$comissao1};;";
						if ($_POST['obj_de2'] != ""){
							$de2 = $funcoes->sanearValor($_POST['obj_de2']);
							$Post->campo_formula .= "OBJ_DE2||{$de2};;";
							$ate2 = $funcoes->sanearValor($_POST['obj_ate2']);
							$Post->campo_formula .= "OBJ_ATE2||{$ate2};;";
							$comissao2 = $funcoes->sanearValor($_POST['obj_comissao2']);
							$Post->campo_formula .= "OBJ_COMISSAO2||{$comissao2};;";
						}
						if ($_POST['obj_de3'] != ""){
							$de3 = $funcoes->sanearValor($_POST['obj_de3']);
							$Post->campo_formula .= "OBJ_DE3||{$de3};;";
							$ate3 = $funcoes->sanearValor($_POST['obj_ate3']);
							$Post->campo_formula .= "OBJ_ATE3||{$ate3};;";
							$comissao3 = $funcoes->sanearValor($_POST['obj_comissao3']);
							$Post->campo_formula .= "OBJ_COMISSAO3||{$comissao3};;";
						}
						if ($_POST['obj_de4'] != ""){
							$de4 = $funcoes->sanearValor($_POST['obj_de4']);
							$Post->campo_formula .= "OBJ_DE4||{$de4};;";
							$ate4 = $funcoes->sanearValor($_POST['obj_ate4']);
							$Post->campo_formula .= "OBJ_ATE4||{$ate4};;";
							$comissao4 = $funcoes->sanearValor($_POST['obj_comissao4']);
							$Post->campo_formula .= "OBJ_COMISSAO4||{$comissao4};;";
						}
						if ($_POST['obj_de5'] != ""){
							$de5 = $funcoes->sanearValor($_POST['obj_de5']);
							$Post->campo_formula .= "OBJ_DE5||{$de5};;";
							$ate5 = $funcoes->sanearValor($_POST['obj_ate5']);
							$Post->campo_formula .= "OBJ_ATE5||{$ate2};;";
							$comissao5 = $funcoes->sanearValor($_POST['obj_comissao5']);
							$Post->campo_formula .= "OBJ_COMISSAO5||{$comissao5};;";
						}
						$Post->campo_formula .= "OBJ_VENDA||{$_POST['obj_venda']};;";
						if (isset($_POST['meta_novos'])){
							$Post->campo_formula .= "META_NOVOS||{$_POST['meta_novos']};;";
						}
						if (isset($_POST['meta_usados'])){
							$Post->campo_formula .= "META_USADOS||{$_POST['meta_usados']};;";
						}
						if (isset($_POST['meta_direto'])){
							$Post->campo_formula .= "META_DIRETO||{$_POST['meta_direto']};;";
						}
						if (isset($_POST['meta_consorcio'])){
							$Post->campo_formula .= "META_CONSORCIO||{$_POST['meta_consorcio']};;";
						}
						if (isset($_POST['meta_pecas'])){
							$Post->campo_formula .= "META_PECAS||{$_POST['meta_pecas']};;";
						}
						if (isset($_POST['meta_maodeobra'])){
							$Post->campo_formula .= "META_MAODEOBRA||{$_POST['meta_maodeobra']};;";
						}
					}elseif ($_POST['por'] == "FAI"){
						if (isset($_POST['fai_auto'])){
							if ($this->emp->EMPRESA == 13){
								if ($Post->tipo == 5 || $Post->tipo == 7){
									$apiIndex = new apiIndex();
									$Post->campo_formula .= "FAI_AUTO||{$_POST['fai_auto']};;";
									$de = date('d/m/Y');
									$exp = explode('/',$de);
									
									$emprev = "{$this->emp->EMPRESA}.{$this->emp->REVENDA}";
									$parametros = $apiIndex->getParametros($emprev,"{$exp[1]}/{$exp[2]}");
									$prcmao = str_replace(",", ".", $parametros->MAODEOBRA);
									$produtividade = ($funcoes->horasTrabalhadas($this->emp->EMPRESA, $this->emp->REVENDA, $exp[1], $exp[2])) * $prcmao;
									
									if ($Post->tipo == 5){
										$per1 = ($parametros->MEC_PROD1 > 0) ? ($parametros->MEC_PROD1/100) : 0;
										$per2 = ($parametros->MEC_PROD2 > 0) ? ($parametros->MEC_PROD2/100) : 0;
										$per3 = ($parametros->MEC_PROD3 > 0) ? ($parametros->MEC_PROD3/100) : 0;
										$per4 = ($parametros->MEC_PROD4 > 0) ? ($parametros->MEC_PROD4/100) : 0;
									}else{
										$per1 = ($parametros->ELE_PROD1 > 0) ? ($parametros->ELE_PROD1/100) : 0;
										$per2 = ($parametros->ELE_PROD2 > 0) ? ($parametros->ELE_PROD2/100) : 0;
										$per3 = ($parametros->ELE_PROD3 > 0) ? ($parametros->ELE_PROD3/100) : 0;
										$per4 = ($parametros->ELE_PROD4 > 0) ? ($parametros->ELE_PROD4/100) : 0;
									}
									$fai_de1 = 0;
									$fai_ate1 = $produtividade * $per1;
									$fai_de2 = ($produtividade * $per1) + 1;
									$fai_ate2 = $produtividade * $per2;
									$fai_de3 = ($produtividade * $per2) + 1;
									$fai_ate3 = $produtividade * $per3;
									$fai_de4 = ($produtividade * $per3) + 1;
									$fai_ate4 = $produtividade;
									
									$Post->campo_formula .= "FAI_DE1||{$fai_de1};;";
									$Post->campo_formula .= "FAI_ATE1||{$fai_ate1};;";
									$comissao1 = $funcoes->sanearValor($_POST['fai_comissao1']);
									$Post->campo_formula .= "FAI_COMISSAO1||{$comissao1};;";
									if ($_POST['premio1'] != ""){
										$premio1 = $funcoes->sanearValor($_POST['premio1']);
										$Post->campo_formula  .= "PREMIO1||{$premio1};;";
									}
									$Post->campo_formula .= "FAI_DE2||{$fai_de2};;";
									$Post->campo_formula .= "FAI_ATE2||{$fai_ate2};;";
									$comissao2 = $funcoes->sanearValor($_POST['fai_comissao2']);
									$Post->campo_formula .= "FAI_COMISSAO2||{$comissao2};;";
									if ($_POST['premio2'] != ""){
										$premio2 = $funcoes->sanearValor($_POST['premio2']);
										$Post->campo_formula  .= "PREMIO2||{$premio2};;";
									}
									$Post->campo_formula .= "FAI_DE3||{$fai_de3};;";
									$Post->campo_formula .= "FAI_ATE3||{$fai_ate3};;";
									$comissao3 = $funcoes->sanearValor($_POST['fai_comissao3']);
									$Post->campo_formula .= "FAI_COMISSAO3||{$comissao3};;";
									if ($_POST['premio3'] != ""){
										$premio3 = $funcoes->sanearValor($_POST['premio3']);
										$Post->campo_formula  .= "PREMIO3||{$premio3};;";
									}
									$Post->campo_formula .= "FAI_DE4||{$fai_de4};;";
									$Post->campo_formula .= "FAI_ATE4||{$fai_ate4};;";
									$comissao4 = $funcoes->sanearValor($_POST['fai_comissao4']);
									$Post->campo_formula .= "FAI_COMISSAO4||{$comissao4};;";
									if ($_POST['premio4'] != ""){
										$premio4 = $funcoes->sanearValor($_POST['premio4']);
										$Post->campo_formula  .= "PREMIO4||{$premio4};;";
									}
								}elseif ($Post->tipo == 4){
									$apiIndex = new apiIndex();
									$Post->campo_formula .= "FAI_AUTO||{$_POST['fai_auto']};;";
									$de = date('d/m/Y');
									$exp = explode('/',$de);
									
									$emprev = "{$this->emp->EMPRESA}.{$this->emp->REVENDA}";
									$parametros = $apiIndex->getParametros($emprev,"{$exp[1]}/{$exp[2]}");
									$prcmao = str_replace(",", ".", $parametros->MAODEOBRA);
									$produtividade = ($funcoes->horasTrabalhadas($this->emp->EMPRESA, $this->emp->REVENDA, $exp[1], $exp[2])) * $prcmao;
									
									$m1 = ($parametros->MEC_PROD1 > 0) ? ($parametros->MEC_PROD1/100) : 0;
									$mv1 = (($produtividade * $m1) * $parametros->QTD_MECA);
									$m2 = ($parametros->MEC_PROD2 > 0) ? ($parametros->MEC_PROD2/100) : 0;
									$mv2 = (($produtividade * $m2) * $parametros->QTD_MECA);
									$m3 = ($parametros->MEC_PROD3 > 0) ? ($parametros->MEC_PROD3/100) : 0;
									$mv3 = (($produtividade * $m3) * $parametros->QTD_MECA);
									$m4 = ($parametros->MEC_PROD4 > 0) ? ($parametros->MEC_PROD4/100) : 0;
									$mv4 = (($produtividade * $m4) * $parametros->QTD_MECA);
									$e1 = ($parametros->ELE_PROD1 > 0) ? ($parametros->ELE_PROD1/100) : 0;
									$ev1 = (($produtividade * $e1) * $parametros->QTD_ELET);
									$e2 = ($parametros->ELE_PROD2 > 0) ? ($parametros->ELE_PROD2/100) : 0;
									$ev2 = (($produtividade * $e2) * $parametros->QTD_ELET);
									$e3 = ($parametros->ELE_PROD3 > 0) ? ($parametros->ELE_PROD3/100) : 0;
									$ev3 = (($produtividade * $e3) * $parametros->QTD_ELET);
									$e4 = ($parametros->ELE_PROD4 > 0) ? ($parametros->ELE_PROD4/100) : 0;
									$ev4 = (($produtividade * $e4) * $parametros->QTD_ELET);
									
									$fai_de1 = 0;
									$fai_ate1 = (($mv1 + $ev1)/$parametros->QTD_CONS);
									$fai_de2 = (($mv1 + $ev1)/$parametros->QTD_CONS) + 1;
									$fai_ate2 = (($mv2 + $ev2)/$parametros->QTD_CONS);
									$fai_de3 = (($mv2 + $ev2)/$parametros->QTD_CONS) + 1;
									$fai_ate3 = (($mv3 + $ev3)/$parametros->QTD_CONS);
									$fai_de4 = (($mv3 + $ev3)/$parametros->QTD_CONS) + 1;
									$fai_ate4 = (($mv4 + $ev4)/$parametros->QTD_CONS);
									
									$Post->campo_formula .= "FAI_DE1||{$fai_de1};;";
									$Post->campo_formula .= "FAI_ATE1||{$fai_ate1};;";
									$comissao1 = $funcoes->sanearValor($_POST['fai_comissao1']);
									$Post->campo_formula .= "FAI_COMISSAO1||{$comissao1};;";
									if ($_POST['premio1'] != ""){
										$premio1 = $funcoes->sanearValor($_POST['premio1']);
										$Post->campo_formula  .= "PREMIO1||{$premio1};;";
									}
									$Post->campo_formula .= "FAI_DE2||{$fai_de2};;";
									$Post->campo_formula .= "FAI_ATE2||{$fai_ate2};;";
									$comissao2 = $funcoes->sanearValor($_POST['fai_comissao2']);
									$Post->campo_formula .= "FAI_COMISSAO2||{$comissao2};;";
									if ($_POST['premio2'] != ""){
										$premio2 = $funcoes->sanearValor($_POST['premio2']);
										$Post->campo_formula  .= "PREMIO2||{$premio2};;";
									}
									$Post->campo_formula .= "FAI_DE3||{$fai_de3};;";
									$Post->campo_formula .= "FAI_ATE3||{$fai_ate3};;";
									$comissao3 = $funcoes->sanearValor($_POST['fai_comissao3']);
									$Post->campo_formula .= "FAI_COMISSAO3||{$comissao3};;";
									if ($_POST['premio3'] != ""){
										$premio3 = $funcoes->sanearValor($_POST['premio3']);
										$Post->campo_formula  .= "PREMIO3||{$premio3};;";
									}
									$Post->campo_formula .= "FAI_DE4||{$fai_de4};;";
									$Post->campo_formula .= "FAI_ATE4||{$fai_ate4};;";
									$comissao4 = $funcoes->sanearValor($_POST['fai_comissao4']);
									$Post->campo_formula .= "FAI_COMISSAO4||{$comissao4};;";
									if ($_POST['premio4'] != ""){
										$premio4 = $funcoes->sanearValor($_POST['premio4']);
										$Post->campo_formula  .= "PREMIO4||{$premio4};;";
									}
								}
							}
						}else{
							$de1 = $funcoes->sanearValor($_POST['fai_de1']);
							$Post->campo_formula .= "FAI_DE1||{$de1};;";
							$ate1 = $funcoes->sanearValor($_POST['fai_ate1']);
							$Post->campo_formula .= "FAI_ATE1||{$ate1};;";
							$comissao1 = $funcoes->sanearValor($_POST['fai_comissao1']);
							$Post->campo_formula .= "FAI_COMISSAO1||{$comissao1};;";
							if ($_POST['premio1'] != ""){
								$premio1 = $funcoes->sanearValor($_POST['premio1']);
								$Post->campo_formula  .= "PREMIO1||{$premio1};;";
							}
							if ($_POST['fai_de2'] != ""){
								$de2 = $funcoes->sanearValor($_POST['fai_de2']);
								$Post->campo_formula .= "FAI_DE2||{$de2};;";
								$ate2 = $funcoes->sanearValor($_POST['fai_ate2']);
								$Post->campo_formula .= "FAI_ATE2||{$ate2};;";
								$comissao2 = $funcoes->sanearValor($_POST['fai_comissao2']);
								$Post->campo_formula .= "FAI_COMISSAO2||{$comissao2};;";
								if ($_POST['premio2'] != ""){
									$premio2 = $funcoes->sanearValor($_POST['premio2']);
									$Post->campo_formula  .= "PREMIO2||{$premio2};;";
								}
							}
							if ($_POST['fai_de3'] != ""){
								$de3 = $funcoes->sanearValor($_POST['fai_de3']);
								$Post->campo_formula .= "FAI_DE3||{$de3};;";
								$ate3 = $funcoes->sanearValor($_POST['fai_ate3']);
								$Post->campo_formula .= "FAI_ATE3||{$ate3};;";
								$comissao3 = $funcoes->sanearValor($_POST['fai_comissao3']);
								$Post->campo_formula .= "FAI_COMISSAO3||{$comissao3};;";
								if ($_POST['premio3'] != ""){
									$premio3 = $funcoes->sanearValor($_POST['premio3']);
									$Post->campo_formula  .= "PREMIO3||{$premio3};;";
								}
							}
							if ($_POST['fai_de4'] != ""){
								$de4 = $funcoes->sanearValor($_POST['fai_de4']);
								$Post->campo_formula .= "FAI_DE4||{$de4};;";
								$ate4 = $funcoes->sanearValor($_POST['fai_ate4']);
								$Post->campo_formula .= "FAI_ATE4||{$ate4};;";
								$comissao4 = $funcoes->sanearValor($_POST['fai_comissao4']);
								$Post->campo_formula .= "FAI_COMISSAO4||{$comissao4};;";
								if ($_POST['premio4'] != ""){
									$premio4 = $funcoes->sanearValor($_POST['premio4']);
									$Post->campo_formula  .= "PREMIO4||{$premio4};;";
								}
							}
							if ($_POST['fai_de5'] != ""){
								$de5 = $funcoes->sanearValor($_POST['fai_de5']);
								$Post->campo_formula .= "FAI_DE5||{$de5};;";
								$ate5 = $funcoes->sanearValor($_POST['fai_ate5']);
								$Post->campo_formula .= "FAI_ATE5||{$ate2};;";
								$comissao5 = $funcoes->sanearValor($_POST['fai_comissao5']);
								$Post->campo_formula .= "FAI_COMISSAO5||{$comissao5};;";
							}
						}
						
						if (isset($_POST['meta_novos'])){
							$Post->campo_formula .= "META_NOVOS||{$_POST['meta_novos']};;";
						}
						if (isset($_POST['meta_usados'])){
							$Post->campo_formula .= "META_USADOS||{$_POST['meta_usados']};;";
						}
						if (isset($_POST['meta_direto'])){
							$Post->campo_formula .= "META_DIRETO||{$_POST['meta_direto']};;";
						}
						if (isset($_POST['meta_consorcio'])){
							$Post->campo_formula .= "META_CONSORCIO||{$_POST['meta_consorcio']};;";
						}
						if (isset($_POST['meta_pecas'])){
							$Post->campo_formula .= "META_PECAS||{$_POST['meta_pecas']};;";
						}
						if (isset($_POST['meta_maodeobra'])){
							$Post->campo_formula .= "META_MAODEOBRA||{$_POST['meta_maodeobra']};;";
						}
						if (isset($_POST['meta_premio'])){
							$Post->campo_formula .= "META_PREMIO||{$_POST['meta_premio']};;";
						}
					}elseif ($_POST['por'] == "TIP"){
						if (isset($_POST['comissao_novos'])){
							$com = $funcoes->sanearValor($_POST['comissao_novos']);
							$Post->campo_formula .= "COMISSAO_NOVOS||{$com};;";
							$Post->campo_formula .= "META_NOVOS||{$_POST['meta_novos']};;";
						}
						if (isset($_POST['comissao_usados'])){
							$com = $funcoes->sanearValor($_POST['comissao_usados']);
							$Post->campo_formula .= "COMISSAO_USADOS||{$com};;";
							$Post->campo_formula .= "META_USADOS||{$_POST['meta_usados']};;";
						}
						if (isset($_POST['comissao_direto'])){
							$com = $funcoes->sanearValor($_POST['comissao_direto']);
							$Post->campo_formula .= "COMISSAO_DIRETO||{$com};;";
							$Post->campo_formula .= "META_DIRETO||{$_POST['meta_direto']};;";
						}
						if (isset($_POST['comissao_consorcio'])){
							$com = $funcoes->sanearValor($_POST['comissao_consorcio']);
							$Post->campo_formula .= "COMISSAO_CONSORCIO||{$com};;";
							$Post->campo_formula .= "META_CONSORCIO||{$_POST['meta_consorcio']};;";
						}
						if (isset($_POST['comissao_pecas'])){
							$com = $funcoes->sanearValor($_POST['comissao_pecas']);
							$Post->campo_formula .= "COMISSAO_PECAS||{$com};;";
							$Post->campo_formula .= "META_PECAS||{$_POST['meta_pecas']};;";
						}
						if (isset($_POST['comissao_maodeobra'])){
							$com = $funcoes->sanearValor($_POST['comissao_maodeobra']);
							$Post->campo_formula .= "COMISSAO_MAODEOBRA||{$com};;";
							$Post->campo_formula .= "META_MAODEOBRA||{$_POST['meta_maodeobra']};;";
						}
					}
				}
				$sql[$i] = $apiGrupo->addGrupo($Post);
				$i = $i+1;
				$log = new Log();
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico = "TIPO||{$Post->tipo};;EMPRESA||{$Post->empresa};;DES_GRUPO||{$Post->des_grupo};;CAMPO_FORMULA||{$Post->campo_formula}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiGrupo->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'com/grupo/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'com/grupo/index/sucesso');
					}
				}else{
					$this->rollback = new Grupo();
					$this->rollback->tipo = $_POST['tipo'];
					$this->rollback->des_grupo = $_POST['des_grupo'];
					$this->rollback->des_formula = $_POST['des_formula'];
					$this->rollback->campanha = $_POST['campanha'];
					$this->rollback->campanha_de = $_POST['campanha_de'];
					$this->rollback->campanha_ate = $_POST['campanha_ate'];
					if (isset($_POST['empresa'])){
						foreach ($_POST['empresa'] as $rs){
							$this->empresas_rollback["{$rs}"] = $rs;
						}
					}
					if (isset($_POST['vendedor'])){
						foreach ($_POST['vendedor'] as $rs){
							$this->vendedores_rollback["{$rs}"] = $rs;
						}
					}
					if (isset($_POST['equipe'])){
						foreach ($_POST['equipe'] as $rs){
							$this->equipes_rollback["{$rs}"] = $rs;
						}
					}
					if (isset($_POST['equipen'])){
						foreach ($_POST['equipen'] as $rs){
							$this->equipesn_rollback["{$rs}"] = $rs;
						}
					}
					if (isset($_POST['equipeu'])){
						foreach ($_POST['equipeu'] as $rs){
							$this->equipesu_rollback["{$rs}"] = $rs;
						}
					}
					if (isset($_POST['equiped'])){
						foreach ($_POST['equiped'] as $rs){
							$this->equipesd_rollback["{$rs}"] = $rs;
						}
					}
					if (isset($_POST['ignorar_vendedor'])){
						foreach ($_POST['ignorar_vendedor'] as $rs){
							$this->ignorar_vendedor_rollback["{$rs}"] = $rs;
						}
					}
					if (isset($_POST['departamento'])){
						foreach ($_POST['departamento'] as $rs){
							$this->departamentos_rollback["{$rs}"] = $rs;
						}
					}
					$this->rollback->considerar = $_POST['considerar'];
					$this->rollback->faturamento = $_POST['faturamento'];
					$this->rollback->por = $_POST['por'];
					$this->campo_formula = array();
					if ($_POST['faturamento'] == 'D' || $_POST['faturamento'] == 'M'){
						if ($_POST['faturamento'] == 'D'){
							$de1 = $funcoes->sanearValor($_POST['desc_de1']);
							$this->campo_formula["DESC_DE1"] = $de1;
							$ate1 = $funcoes->sanearValor($_POST['desc_ate1']);
							$this->campo_formula["DESC_ATE1"] = $ate1;
							$comissao1 = $funcoes->sanearValor($_POST['desc_comissao1']);
							$this->campo_formula["DESC_COMISSAO1"] = $comissao1;
							if ($_POST['desc_de2'] != ""){
								$de2 = $funcoes->sanearValor($_POST['desc_de2']);
								$this->campo_formula["DESC_DE2"] = $de2;
								$ate2 = $funcoes->sanearValor($_POST['desc_ate2']);
								$this->campo_formula["DESC_ATE2"] = $ate2;
								$comissao2 = $funcoes->sanearValor($_POST['desc_comissao2']);
								$this->campo_formula["DESC_COMISSAO2"] = $comissao2;
							}
							if ($_POST['desc_de3'] != ""){
								$de3 = $funcoes->sanearValor($_POST['desc_de3']);
								$this->campo_formula["DESC_DE3"] = $de3;
								$ate3 = $funcoes->sanearValor($_POST['desc_ate3']);
								$this->campo_formula["DESC_ATE3"] = $ate3;
								$comissao3 = $funcoes->sanearValor($_POST['desc_comissao3']);
								$this->campo_formula["DESC_COMISSAO3"] = $comissao3;
							}
							if ($_POST['desc_de4'] != ""){
								$de4 = $funcoes->sanearValor($_POST['desc_de4']);
								$this->campo_formula["DESC_DE4"] = $de4;
								$ate4 = $funcoes->sanearValor($_POST['desc_ate4']);
								$this->campo_formula["DESC_ATE4"] = $ate4;
								$comissao4 = $funcoes->sanearValor($_POST['desc_comissao4']);
								$this->campo_formula["DESC_COMISSAO4"] = $comissao4;
							}
							if ($_POST['desc_de5'] != ""){
								$de5 = $funcoes->sanearValor($_POST['desc_de5']);
								$this->campo_formula["DESC_DE5"] = $de5;
								$ate5 = $funcoes->sanearValor($_POST['desc_ate5']);
								$this->campo_formula["DESC_ATE5"] = $ate2;
								$comissao5 = $funcoes->sanearValor($_POST['desc_comissao5']);
								$this->campo_formula["DESC_COMISSAO5"] = $comissao5;
							}
							$this->campo_formula["META_VEICULO"] = $_POST['meta_veiculo'];
						}elseif ($_POST['faturamento'] == 'M'){
							$de1 = $funcoes->sanearValor($_POST['marg_de1']);
							$this->campo_formula["MARG_DE1"] = $de1;
							$ate1 = $funcoes->sanearValor($_POST['marg_ate1']);
							$this->campo_formula["MARG_ATE1"] = $ate1;
							$comissao1 = $funcoes->sanearValor($_POST['marg_comissao1']);
							$this->campo_formula["MARG_COMISSAO1"] = $comissao1;
							if ($_POST['marg_de2'] != ""){
								$de2 = $funcoes->sanearValor($_POST['marg_de2']);
								$this->campo_formula["MARG_DE2"] = $de2;
								$ate2 = $funcoes->sanearValor($_POST['marg_ate2']);
								$this->campo_formula["MARG_ATE2"] = $ate2;
								$comissao2 = $funcoes->sanearValor($_POST['marg_comissao2']);
								$this->campo_formula["MARG_COMISSAO2"] = $comissao2;
							}
							if ($_POST['marg_de3'] != ""){
								$de3 = $funcoes->sanearValor($_POST['marg_de3']);
								$this->campo_formula["MARG_DE3"] = $de3;
								$ate3 = $funcoes->sanearValor($_POST['marg_ate3']);
								$this->campo_formula["MARG_ATE3"] = $ate3;
								$comissao3 = $funcoes->sanearValor($_POST['marg_comissao3']);
								$this->campo_formula["MARG_COMISSAO3"] = $comissao3;
							}
							if ($_POST['marg_de4'] != ""){
								$de4 = $funcoes->sanearValor($_POST['marg_de4']);
								$this->campo_formula["MARG_DE4"] = $de4;
								$ate4 = $funcoes->sanearValor($_POST['marg_ate4']);
								$this->campo_formula["MARG_ATE4"] = $ate4;
								$comissao4 = $funcoes->sanearValor($_POST['marg_comissao4']);
								$this->campo_formula["MARG_COMISSAO4"] = $comissao4;
							}
							if ($_POST['marg_de5'] != ""){
								$de5 = $funcoes->sanearValor($_POST['marg_de5']);
								$this->campo_formula["MARG_DE5"] = $de5;
								$ate5 = $funcoes->sanearValor($_POST['marg_ate5']);
								$this->campo_formula["MARG_ATE5"] = $ate2;
								$comissao5 = $funcoes->sanearValor($_POST['marg_comissao5']);
								$this->campo_formula["MARG_COMISSAO5"] = $comissao5;
							}
							if (isset($_POST['meta_novos'])){
								$this->campo_formula["META_NOVOS"] = $_POST['meta_novos'];
							}
							if (isset($_POST['meta_usados'])){
								$this->campo_formula["META_USADOS"] = $_POST['meta_usados'];
							}
							if (isset($_POST['meta_direto'])){
								$this->campo_formula["META_DIRETO"] = $_POST['meta_direto'];
							}
							if (isset($_POST['meta_consorcio'])){
								$this->campo_formula["META_CONSORCIO"] = $_POST['meta_consorcio'];
							}
							if (isset($_POST['meta_pecas'])){
								$this->campo_formula["META_PECAS"] = $_POST['meta_pecas'];
							}
							if (isset($_POST['meta_maodeobra'])){
								$this->campo_formula["META_MAODEOBRA"] = $_POST['meta_maodeobra'];
							}
						}
						if ($cnh == 'sim'){
							$venda = $funcoes->sanearValor($_POST['comissao_venda']);
							$this->campo_formula["COMISSAO_VENDA"] = $venda;
							if ($_POST['comissao_parcela1'] != ""){
								$parc1 = $funcoes->sanearValor($_POST['comissao_parcela1']);
								$this->campo_formula["COMISSAO_PARCELA1"] = $parc1;
								$this->campo_formula["NRO_PARCELA1"] = $_POST['nro_parcela1'];
							}
							if ($_POST['comissao_parcela2'] != ""){
								$parc2 = $funcoes->sanearValor($_POST['comissao_parcela2']);
								$this->campo_formula["COMISSAO_PARCELA2"] = $parc2;
								$this->campo_formula["NRO_PARCELA2"] = $_POST['nro_parcela2'];
							}
							if ($_POST['comissao_parcela3'] != ""){
								$parc3 = $funcoes->sanearValor($_POST['comissao_parcela3']);
								$this->campo_formula["COMISSAO_PARCELA3"] = $parc3;
								$this->campo_formula["NRO_PARCELA3"] = $_POST['nro_parcela3'];
							}
							$this->campo_formula["META_CONSORCIO"] = $_POST['meta_consorcio'];
							$this->campo_formula["META_PARCELA"] = $_POST['meta_parcela'];
						}
					}elseif ($_POST['faturamento'] == 'B' || $_POST['faturamento'] == 'L'){
						if ($_POST['por'] == "OBJ"){
							$de1 = $funcoes->sanearValor($_POST['obj_de1']);
							$this->campo_formula["OBJ_DE1"] = $de1;
							$ate1 = $funcoes->sanearValor($_POST['obj_ate1']);
							$this->campo_formula["OBJ_ATE1"] = $ate1;
							$comissao1 = $funcoes->sanearValor($_POST['obj_comissao1']);
							$this->campo_formula["OBJ_COMISSAO1"] = $comissao1;
							if ($_POST['obj_de2'] != ""){
								$de2 = $funcoes->sanearValor($_POST['obj_de2']);
								$this->campo_formula["OBJ_DE2"] = $de2;
								$ate2 = $funcoes->sanearValor($_POST['obj_ate2']);
								$this->campo_formula["OBJ_ATE2"] = $ate2;
								$comissao2 = $funcoes->sanearValor($_POST['obj_comissao2']);
								$this->campo_formula["OBJ_COMISSAO2"] = $comissao2;
							}
							if ($_POST['obj_de3'] != ""){
								$de3 = $funcoes->sanearValor($_POST['obj_de3']);
								$this->campo_formula["OBJ_DE3"] = $de3;
								$ate3 = $funcoes->sanearValor($_POST['obj_ate3']);
								$this->campo_formula["OBJ_ATE3"] = $ate3;
								$comissao3 = $funcoes->sanearValor($_POST['obj_comissao3']);
								$this->campo_formula["OBJ_COMISSAO3"] = $comissao3;
							}
							if ($_POST['obj_de4'] != ""){
								$de4 = $funcoes->sanearValor($_POST['obj_de4']);
								$this->campo_formula["OBJ_DE4"] = $de4;
								$ate4 = $funcoes->sanearValor($_POST['obj_ate4']);
								$this->campo_formula["OBJ_ATE4"] = $ate4;
								$comissao4 = $funcoes->sanearValor($_POST['obj_comissao4']);
								$this->campo_formula["OBJ_COMISSAO4"] = $comissao4;
							}
							if ($_POST['obj_de5'] != ""){
								$de5 = $funcoes->sanearValor($_POST['obj_de5']);
								$this->campo_formula["OBJ_DE5"] = $de5;
								$ate5 = $funcoes->sanearValor($_POST['obj_ate5']);
								$this->campo_formula["OBJ_ATE5"] = $ate2;
								$comissao5 = $funcoes->sanearValor($_POST['obj_comissao5']);
								$this->campo_formula["OBJ_COMISSAO5"] = $comissao5;
							}
							$this->campo_formula["OBJ_VENDA"] = $_POST['obj_venda'];
							if (isset($_POST['meta_novos'])){
								$this->campo_formula["META_NOVOS"] = $_POST['meta_novos'];
							}
							if (isset($_POST['meta_usados'])){
								$this->campo_formula["META_USADOS"] = $_POST['meta_usados'];
							}
							if (isset($_POST['meta_direto'])){
								$this->campo_formula["META_DIRETO"] = $_POST['meta_direto'];
							}
							if (isset($_POST['meta_consorcio'])){
								$this->campo_formula["META_CONSORCIO"] = $_POST['meta_consorcio'];
							}
							if (isset($_POST['meta_pecas'])){
								$this->campo_formula["META_PECAS"] = $_POST['meta_pecas'];
							}
							if (isset($_POST['meta_maodeobra'])){
								$this->campo_formula["META_MAODEOBRA"] = $_POST['meta_maodeobra'];
							}
						}elseif ($_POST['por'] == "FAI"){
							if (isset($_POST['fai_auto'])){
								$this->campo_formula["FAI_AUTO"] = 'S';
							}
							$de1 = $funcoes->sanearValor($_POST['fai_de1']);
							$this->campo_formula["FAI_DE1"] = $de1;
							$ate1 = $funcoes->sanearValor($_POST['fai_ate1']);
							$this->campo_formula["FAI_ATE1"] = $ate1;
							$comissao1 = $funcoes->sanearValor($_POST['fai_comissao1']);
							$this->campo_formula["FAI_COMISSAO1"] = $comissao1;
							if ($_POST['premio1'] != ""){
								$premio1 = $funcoes->sanearValor($_POST['premio1']);
								$this->campo_formula["PREMIO1"] = $premio1;
							}
							if ($_POST['fai_de2'] != ""){
								$de2 = $funcoes->sanearValor($_POST['fai_de2']);
								$this->campo_formula["FAI_DE2"] = $de2;
								$ate2 = $funcoes->sanearValor($_POST['fai_ate2']);
								$this->campo_formula["FAI_ATE2"] = $ate2;
								$comissao2 = $funcoes->sanearValor($_POST['fai_comissao2']);
								$this->campo_formula["FAI_COMISSAO2"] = $comissao2;
								if ($_POST['premio2'] != ""){
									$premio2 = $funcoes->sanearValor($_POST['premio2']);
									$this->campo_formula["PREMIO2"] = $premio2;
								}
							}
							if ($_POST['fai_de3'] != ""){
								$de3 = $funcoes->sanearValor($_POST['fai_de3']);
								$this->campo_formula["FAI_DE3"] = $de3;
								$ate3 = $funcoes->sanearValor($_POST['fai_ate3']);
								$this->campo_formula["FAI_ATE3"] = $ate3;
								$comissao3 = $funcoes->sanearValor($_POST['fai_comissao3']);
								$this->campo_formula["FAI_COMISSAO3"] = $comissao3;
								if ($_POST['premio3'] != ""){
									$premio3 = $funcoes->sanearValor($_POST['premio3']);
									$this->campo_formula["PREMIO3"] = $premio3;
								}
							}
							if ($_POST['fai_de4'] != ""){
								$de4 = $funcoes->sanearValor($_POST['fai_de4']);
								$this->campo_formula["FAI_DE4"] = $de4;
								$ate4 = $funcoes->sanearValor($_POST['fai_ate4']);
								$this->campo_formula["FAI_ATE4"] = $ate4;
								$comissao4 = $funcoes->sanearValor($_POST['fai_comissao4']);
								$this->campo_formula["FAI_COMISSAO4"] = $comissao4;
								if ($_POST['premio4'] != ""){
									$premio4 = $funcoes->sanearValor($_POST['premio4']);
									$this->campo_formula["PREMIO4"] = $premio4;
								}
							}
							if ($_POST['fai_de5'] != ""){
								$de5 = $funcoes->sanearValor($_POST['fai_de5']);
								$this->campo_formula["FAI_DE5"] = $de5;
								$ate5 = $funcoes->sanearValor($_POST['fai_ate5']);
								$this->campo_formula["FAI_ATE5"] = $ate2;
								$comissao5 = $funcoes->sanearValor($_POST['fai_comissao5']);
								$this->campo_formula["FAI_COMISSAO5"] = $comissao5;
							}
							if (isset($_POST['meta_novos'])){
								$this->campo_formula["META_NOVOS"] = $_POST['meta_novos'];
							}
							if (isset($_POST['meta_usados'])){
								$this->campo_formula["META_USADOS"] = $_POST['meta_usados'];
							}
							if (isset($_POST['meta_direto'])){
								$this->campo_formula["META_DIRETO"] = $_POST['meta_direto'];
							}
							if (isset($_POST['meta_consorcio'])){
								$this->campo_formula["META_CONSORCIO"] = $_POST['meta_consorcio'];
							}
							if (isset($_POST['meta_pecas'])){
								$this->campo_formula["META_PECAS"] = $_POST['meta_pecas'];
							}
							if (isset($_POST['meta_maodeobra'])){
								$this->campo_formula["META_MAODEOBRA"] = $_POST['meta_maodeobra'];
							}
							if (isset($_POST['meta_premio'])){
								$this->campo_formula["META_PREMIO"] = $_POST['meta_premio'];
							}
						}elseif ($_POST['por'] == "TIP"){
							if (isset($_POST['comissao_novos'])){
								$com = $funcoes->sanearValor($_POST['comissao_novos']);
								$this->campo_formula["COMISSAO_NOVOS"] = $com;
								$this->campo_formula["META_NOVOS"] = $_POST['meta_novos'];
							}
							if (isset($_POST['comissao_usados'])){
								$com = $funcoes->sanearValor($_POST['comissao_usados']);
								$this->campo_formula["COMISSAO_USADOS"] = $com;
								$this->campo_formula["META_USADOS"] = $_POST['meta_usados'];
							}
							if (isset($_POST['comissao_direto'])){
								$com = $funcoes->sanearValor($_POST['comissao_direto']);
								$this->campo_formula["COMISSAO_DIRETO"] = $com;
								$this->campo_formula["META_DIRETO"] = $_POST['meta_direto'];
							}
							if (isset($_POST['comissao_consorcio'])){
								$com = $funcoes->sanearValor($_POST['comissao_consorcio']);
								$this->campo_formula["COMISSAO_CONSORCIO"] = $com;
								$this->campo_formula["META_CONSORCIO"] = $_POST['meta_consorcio'];
							}
							if (isset($_POST['comissao_pecas'])){
								$com = $funcoes->sanearValor($_POST['comissao_pecas']);
								$this->campo_formula["COMISSAO_PECAS"] = $com;
								$this->campo_formula["META_PECAS"] = $_POST['meta_pecas'];
							}
							if (isset($_POST['comissao_maodeobra'])){
								$com = $funcoes->sanearValor($_POST['comissao_maodeobra']);
								$this->campo_formula["COMISSAO_MAODEOBRA"] = $com;
								$this->campo_formula["META_MAODEOBRA"] = $_POST['meta_maodeobra'];
							}
						}
					}
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		
		$this->view();
	}
	
	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Altera��o de Grupo";
		$grupo = new Grupo();
		$grupo->grupo = $this->getParams(0);
		$grupo->empresa = $_SESSION['empresa_sessao'];
		$apiGrupo = new apiGrupo();
		$this->dados = array('grupo' => $apiGrupo->getGrupo($grupo));
		if (!isset($this->dados['grupo'])){
			header('location:' .APP_ROOT. 'com/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		$apiApollo = new apiApollo();
		$this->vendedores = $apiApollo->getVendedoresapollo($_SESSION['empresa_sessao']);
		if ($this->dados['grupo']->TIPO == 3){
			$this->empresas = $apiApollo->getAllempresaapollo();
		}else{
			$this->empresas = $apiApollo->getEmpresaapollo($_SESSION['empresa_sessao']);
		}
		$apiEmpresa = new apiEmpresa();
		$this->emp = $apiEmpresa->geEmpresarevenda($_SESSION['empresa_sessao']);
		$apiTipo = new apiTipo();
		$this->tipo = $apiTipo->filtroTipo('1','3','ativo', '1');
		foreach ($this->tipo as $rs){
			$strVal = explode(';;', $rs->LEIAUTE);
			foreach ($strVal as $i){
				@list($k, $v) = explode('||', $i);
				$leiaute[$k] = $v;
			}
			@$this->considerar[$rs->TIPO]= explode(",", $leiaute["CONSIDERAR"]);
			@$this->sobre[$rs->TIPO] = explode(",", $leiaute["SOBRE"]);
		}
		$strVal = explode(';;', $this->dados['grupo']->CAMPO_FORMULA);
		foreach ($strVal as $rs){
			@list($k, $v) = explode('||', $rs);
			$this->campo_formula[$k] = $v;
		}
		@$this->empresa = explode(",", str_replace(".", "", $this->campo_formula["EMPRESA"]));
		@$this->vendedor = explode(",", $this->campo_formula["VENDEDOR"]);
		if (in_array("EQ", $this->sobre[$this->dados['grupo']->TIPO])){
			if ($this->empresas[0]->EMPRESA == 13){
				if ($this->dados['grupo']->TIPO == 3){
					@$this->equipe = explode(",", $this->campo_formula["EQUIPE"]);
					@$this->equipen = explode(",", $this->campo_formula["EQUIPEN"]);
					@$this->equipeu = explode(",", $this->campo_formula["EQUIPEU"]);
					@$this->equiped = explode(",", $this->campo_formula["EQUIPED"]);
				}else{
					@$this->equipe = explode(",", $this->campo_formula["EQUIPE"]);
				}	
			}else{
				@$this->equipe = explode(",", $this->campo_formula["EQUIPE"]);
			}
		}
		if (in_array("IV", $this->sobre[$this->dados['grupo']->TIPO])){
			@$this->ignorar_vendedor = explode(",", $this->campo_formula["IGNORAR_VENDEDOR"]);
		}
		if (in_array("DP", $this->sobre[$this->dados['grupo']->TIPO])){
			@$this->departamento = explode(",", $this->campo_formula["DEPARTAMENTO"]);
		}
		$this->considerado = explode(",", $this->campo_formula["CONSIDERAR"]);
		$apiCampanha = new apiCampanha();
		$this->campanha = $apiCampanha->filtroCampanha('3',$this->emp->EMPRESA);
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$anterior = "";
			$atual = "::";
			$campo_formula = "";
			$funcoes = new Funcoes();
			$Post = new Grupo();
			$Post->grupo = $this->getParams(0);
			$apiGrupo = new apiGrupo();
			$rs = $apiGrupo->filtroGrupo('4',$_SESSION['empresa_sessao'],'des_grupo', strtoupper($funcoes->retiraAcentos(trim($_POST['des_grupo']))), $this->dados['grupo']->TIPO);
			if ((is_array($rs) ? count($rs) : 0) > 0 && ($rs[0]->DES_GRUPO != $this->dados['grupo']->DES_GRUPO)){
				$this->dados['grupo']->DES_GRUPO = $_POST['des_grupo'];
				$this->Alert = "J� existe um grupo com esse nome cadastrado!";
			}else{
				if ($this->dados['grupo']->DES_GRUPO != strtoupper($funcoes->retiraAcentos(trim($_POST['des_grupo'])))){
					$Post->des_grupo = strtoupper($funcoes->retiraAcentos(trim($_POST['des_grupo'])));
					$anterior .= "DES_GRUPO||{$this->dados['grupo']->DES_GRUPO};;";
					$atual .= "DES_GRUPO||{$Post->des_grupo};;";
				}
				if ($this->dados['grupo']->DES_FORMULA != $_POST['des_formula']){
					$Post->des_formula = $_POST['des_formula'];
					$anterior .= "DES_FORMULA||{$this->dados['grupo']->DES_FORMULA};;";
					$atual .= "DES_FORMULA||{$Post->des_formula};;";
				}
				
				$empresa = "";
				foreach ($_POST['empresa'] as $rs){
					$empresa .= "{$rs},";
				}
				$empresa = substr($empresa,0,-1);
				$campo_formula = "EMPRESA||{$empresa};;";
				$vendedor = "";
				foreach ($_POST['vendedor'] as $rs){
					$vendedor .= "{$rs},";
				}
				$vendedor = substr($vendedor,0,-1);
				$campo_formula .= "VENDEDOR||{$vendedor};;";
				if (isset($_POST['equipe'])){
					$equipe = "";
					foreach ($_POST['equipe'] as $rs){
						$equipe .= "{$rs},";
					}
					$equipe = substr($equipe,0,-1);
					$campo_formula .= "EQUIPE||{$equipe};;";
				}
				if (isset($_POST['equipen'])){
					$equipen = "";
					foreach ($_POST['equipen'] as $rs){
						$equipen .= "{$rs},";
					}
					$equipen = substr($equipen,0,-1);
					$campo_formula .= "EQUIPEN||{$equipen};;";
				}
				if (isset($_POST['equipeu'])){
					$equipeu = "";
					foreach ($_POST['equipeu'] as $rs){
						$equipeu .= "{$rs},";
					}
					$equipeu = substr($equipeu,0,-1);
					$campo_formula .= "EQUIPEU||{$equipeu};;";
				}
				if (isset($_POST['equiped'])){
					$equiped = "";
					foreach ($_POST['equiped'] as $rs){
						$equiped .= "{$rs},";
					}
					$equiped = substr($equiped,0,-1);
					$campo_formula .= "EQUIPED||{$equiped};;";
				}
				if (isset($_POST['ignorar_vendedor'])){
					$ivendedor = "";
					foreach ($_POST['ignorar_vendedor'] as $rs){
						$ivendedor .= "{$rs},";
					}
					$ivendedor = substr($ivendedor,0,-1);
					$campo_formula .= "IGNORAR_VENDEDOR||{$ivendedor};;";
				}
				if (isset($_POST['departamento'])){
					$departamento = "";
					foreach ($_POST['departamento'] as $rs){
						$departamento .= "{$rs},";
					}
					$departamento = substr($departamento,0,-1);
					$campo_formula .= "DEPARTAMENTO||{$departamento};;";
				}
				$considerar = "";
				$cnh = "";
				foreach ($_POST['considerar'] as $rs){
					if ($rs == 'C'){
						$cnh = "sim";
					}
					$considerar .= "{$rs},";
				}
				$considerar = substr($considerar,0,-1);
				$campo_formula .= "CONSIDERAR||{$considerar};;";
				$campo_formula .= "FATURAMENTO||{$_POST['faturamento']};;";
				$campo_formula .= "POR||{$_POST['por']};;";
				$campo_formula .= "CAMPANHA||{$_POST['campanha']};;";
				$campo_formula .= "CAMPANHA_DE||{$_POST['campanha_de']};;";
				$campo_formula .= "CAMPANHA_ATE||{$_POST['campanha_ate']};;";
				if ($_POST['faturamento'] == 'D' || $_POST['faturamento'] == 'M'){
					if ($_POST['faturamento'] == 'D'){
						$de1 = $funcoes->sanearValor($_POST['desc_de1']);
						$campo_formula .= "DESC_DE1||{$de1};;";
						$ate1 = $funcoes->sanearValor($_POST['desc_ate1']);
						$campo_formula .= "DESC_ATE1||{$ate1};;";
						$comissao1 = $funcoes->sanearValor($_POST['desc_comissao1']);
						$campo_formula .= "DESC_COMISSAO1||{$comissao1};;";
						if ($_POST['desc_de2'] != ""){
							$de2 = $funcoes->sanearValor($_POST['desc_de2']);
							$campo_formula .= "DESC_DE2||{$de2};;";
							$ate2 = $funcoes->sanearValor($_POST['desc_ate2']);
							$campo_formula .= "DESC_ATE2||{$ate2};;";
							$comissao2 = $funcoes->sanearValor($_POST['desc_comissao2']);
							$campo_formula .= "DESC_COMISSAO2||{$comissao2};;";
						}
						if ($_POST['desc_de3'] != ""){
							$de3 = $funcoes->sanearValor($_POST['desc_de3']);
							$campo_formula .= "DESC_DE3||{$de3};;";
							$ate3 = $funcoes->sanearValor($_POST['desc_ate3']);
							$campo_formula .= "DESC_ATE3||{$ate3};;";
							$comissao3 = $funcoes->sanearValor($_POST['desc_comissao3']);
							$campo_formula .= "DESC_COMISSAO3||{$comissao3};;";
						}
						if ($_POST['desc_de4'] != ""){
							$de4 = $funcoes->sanearValor($_POST['desc_de4']);
							$campo_formula .= "DESC_DE4||{$de4};;";
							$ate4 = $funcoes->sanearValor($_POST['desc_ate4']);
							$campo_formula .= "DESC_ATE4||{$ate4};;";
							$comissao4 = $funcoes->sanearValor($_POST['desc_comissao4']);
							$campo_formula .= "DESC_COMISSAO4||{$comissao4};;";
						}
						if ($_POST['desc_de5'] != ""){
							$de5 = $funcoes->sanearValor($_POST['desc_de5']);
							$campo_formula .= "DESC_DE5||{$de5};;";
							$ate5 = $funcoes->sanearValor($_POST['desc_ate5']);
							$campo_formula .= "DESC_ATE5||{$ate2};;";
							$comissao5 = $funcoes->sanearValor($_POST['desc_comissao5']);
							$campo_formula .= "DESC_COMISSAO5||{$comissao5};;";
						}
						$campo_formula .= "META_VEICULO||{$_POST['meta_veiculo']};;";
					}elseif ($_POST['faturamento'] == 'M'){
						$de1 = $funcoes->sanearValor($_POST['marg_de1']);
						$campo_formula .= "MARG_DE1||{$de1};;";
						$ate1 = $funcoes->sanearValor($_POST['marg_ate1']);
						$campo_formula .= "MARG_ATE1||{$ate1};;";
						$comissao1 = $funcoes->sanearValor($_POST['marg_comissao1']);
						$campo_formula .= "MARG_COMISSAO1||{$comissao1};;";
						if ($_POST['marg_de2'] != ""){
							$de2 = $funcoes->sanearValor($_POST['marg_de2']);
							$campo_formula .= "MARG_DE2||{$de2};;";
							$ate2 = $funcoes->sanearValor($_POST['marg_ate2']);
							$campo_formula .= "MARG_ATE2||{$ate2};;";
							$comissao2 = $funcoes->sanearValor($_POST['marg_comissao2']);
							$campo_formula .= "MARG_COMISSAO2||{$comissao2};;";
						}
						if ($_POST['marg_de3'] != ""){
							$de3 = $funcoes->sanearValor($_POST['marg_de3']);
							$campo_formula .= "MARG_DE3||{$de3};;";
							$ate3 = $funcoes->sanearValor($_POST['marg_ate3']);
							$campo_formula .= "MARG_ATE3||{$ate3};;";
							$comissao3 = $funcoes->sanearValor($_POST['marg_comissao3']);
							$campo_formula .= "MARG_COMISSAO3||{$comissao3};;";
						}
						if ($_POST['marg_de4'] != ""){
							$de4 = $funcoes->sanearValor($_POST['marg_de4']);
							$campo_formula .= "MARG_DE4||{$de4};;";
							$ate4 = $funcoes->sanearValor($_POST['marg_ate4']);
							$campo_formula .= "MARG_ATE4||{$ate4};;";
							$comissao4 = $funcoes->sanearValor($_POST['marg_comissao4']);
							$campo_formula .= "MARG_COMISSAO4||{$comissao4};;";
						}
						if ($_POST['marg_de5'] != ""){
							$de5 = $funcoes->sanearValor($_POST['marg_de5']);
							$campo_formula .= "MARG_DE5||{$de5};;";
							$ate5 = $funcoes->sanearValor($_POST['marg_ate5']);
							$campo_formula .= "MARG_ATE5||{$ate2};;";
							$comissao5 = $funcoes->sanearValor($_POST['marg_comissao5']);
							$campo_formula .= "MARG_COMISSAO5||{$comissao5};;";
						}
						if (isset($_POST['meta_novos'])){
							$campo_formula .= "META_NOVOS||{$_POST['meta_novos']};;";
						}
						if (isset($_POST['meta_usados'])){
							$campo_formula .= "META_USADOS||{$_POST['meta_usados']};;";
						}
						if (isset($_POST['meta_direto'])){
							$campo_formula .= "META_DIRETO||{$_POST['meta_direto']};;";
						}
						if (isset($_POST['meta_consorcio'])){
							$campo_formula .= "META_CONSORCIO||{$_POST['meta_consorcio']};;";
						}
						if (isset($_POST['meta_pecas'])){
							$campo_formula .= "META_PECAS||{$_POST['meta_pecas']};;";
						}
						if (isset($_POST['meta_maodeobra'])){
							$campo_formula .= "META_MAODEOBRA||{$_POST['meta_maodeobra']};;";
						}
					}
					if ($cnh == 'sim'){
						$venda = $funcoes->sanearValor($_POST['comissao_venda']);
						$campo_formula .= "COMISSAO_VENDA||{$venda};;";
						if ($_POST['comissao_parcela1'] != ""){
							$parc1 = $funcoes->sanearValor($_POST['comissao_parcela1']);
							$campo_formula .= "COMISSAO_PARCELA1||{$parc1};;";
							$campo_formula .= "NRO_PARCELA1||{$_POST['nro_parcela1']};;";
						}
						if ($_POST['comissao_parcela2'] != ""){
							$parc2 = $funcoes->sanearValor($_POST['comissao_parcela2']);
							$campo_formula .= "COMISSAO_PARCELA2||{$parc2};;";
							$campo_formula .= "NRO_PARCELA2||{$_POST['nro_parcela2']};;";
						}
						if ($_POST['comissao_parcela3'] != ""){
							$parc3 = $funcoes->sanearValor($_POST['comissao_parcela3']);
							$campo_formula .= "COMISSAO_PARCELA3||{$parc3};;";
							$campo_formula .= "NRO_PARCELA3||{$_POST['nro_parcela3']};;";
						}
						$campo_formula .= "META_CONSORCIO||{$_POST['meta_consorcio']};;";
						$campo_formula .= "META_PARCELA||{$_POST['meta_parcela']};;";
					}
				}elseif ($_POST['faturamento'] == 'B' || $_POST['faturamento'] == 'L'){
					if ($_POST['por'] == "OBJ"){
						$de1 = $funcoes->sanearValor($_POST['obj_de1']);
						$campo_formula .= "OBJ_DE1||{$de1};;";
						$ate1 = $funcoes->sanearValor($_POST['obj_ate1']);
						$campo_formula .= "OBJ_ATE1||{$ate1};;";
						$comissao1 = $funcoes->sanearValor($_POST['obj_comissao1']);
						$campo_formula .= "OBJ_COMISSAO1||{$comissao1};;";
						if ($_POST['obj_de2'] != ""){
							$de2 = $funcoes->sanearValor($_POST['obj_de2']);
							$campo_formula .= "OBJ_DE2||{$de2};;";
							$ate2 = $funcoes->sanearValor($_POST['obj_ate2']);
							$campo_formula .= "OBJ_ATE2||{$ate2};;";
							$comissao2 = $funcoes->sanearValor($_POST['obj_comissao2']);
							$campo_formula .= "OBJ_COMISSAO2||{$comissao2};;";
						}
						if ($_POST['obj_de3'] != ""){
							$de3 = $funcoes->sanearValor($_POST['obj_de3']);
							$campo_formula .= "OBJ_DE3||{$de3};;";
							$ate3 = $funcoes->sanearValor($_POST['obj_ate3']);
							$campo_formula .= "OBJ_ATE3||{$ate3};;";
							$comissao3 = $funcoes->sanearValor($_POST['obj_comissao3']);
							$campo_formula .= "OBJ_COMISSAO3||{$comissao3};;";
						}
						if ($_POST['obj_de4'] != ""){
							$de4 = $funcoes->sanearValor($_POST['obj_de4']);
							$campo_formula .= "OBJ_DE4||{$de4};;";
							$ate4 = $funcoes->sanearValor($_POST['obj_ate4']);
							$campo_formula .= "OBJ_ATE4||{$ate4};;";
							$comissao4 = $funcoes->sanearValor($_POST['obj_comissao4']);
							$campo_formula .= "OBJ_COMISSAO4||{$comissao4};;";
						}
						if ($_POST['obj_de5'] != ""){
							$de5 = $funcoes->sanearValor($_POST['obj_de5']);
							$campo_formula .= "OBJ_DE5||{$de5};;";
							$ate5 = $funcoes->sanearValor($_POST['obj_ate5']);
							$campo_formula .= "OBJ_ATE5||{$ate2};;";
							$comissao5 = $funcoes->sanearValor($_POST['obj_comissao5']);
							$campo_formula .= "OBJ_COMISSAO5||{$comissao5};;";
						}
						$campo_formula .= "OBJ_VENDA||{$_POST['obj_venda']};;";
						if (isset($_POST['meta_novos'])){
							$campo_formula .= "META_NOVOS||{$_POST['meta_novos']};;";
						}
						if (isset($_POST['meta_usados'])){
							$campo_formula .= "META_USADOS||{$_POST['meta_usados']};;";
						}
						if (isset($_POST['meta_direto'])){
							$campo_formula .= "META_DIRETO||{$_POST['meta_direto']};;";
						}
						if (isset($_POST['meta_consorcio'])){
							$campo_formula .= "META_CONSORCIO||{$_POST['meta_consorcio']};;";
						}
						if (isset($_POST['meta_pecas'])){
							$campo_formula .= "META_PECAS||{$_POST['meta_pecas']};;";
						}
						if (isset($_POST['meta_maodeobra'])){
							$campo_formula .= "META_MAODEOBRA||{$_POST['meta_maodeobra']};;";
						}
					}elseif ($_POST['por'] == "FAI"){
						if (isset($_POST['fai_auto'])){
							if ($this->emp->EMPRESA == 13){
								if ($this->dados['grupo']->TIPO == 5 || $this->dados['grupo']->TIPO == 7){
									$apiIndex = new apiIndex();
									$campo_formula .= "FAI_AUTO||{$_POST['fai_auto']};;";
									$de = date('d/m/Y');
									$exp = explode('/',$de);
									
									$emprev = "{$this->emp->EMPRESA}.{$this->emp->REVENDA}";
									$parametros = $apiIndex->getParametros($emprev,"{$exp[1]}/{$exp[2]}");
									$prcmao = str_replace(",", ".", $parametros->MAODEOBRA);
									$produtividade = ($funcoes->horasTrabalhadas($this->emp->EMPRESA, $this->emp->REVENDA, $exp[1], $exp[2])) * $prcmao;
									
									if ($Post->tipo == 5){
										$per1 = ($parametros->MEC_PROD1 > 0) ? ($parametros->MEC_PROD1/100) : 0;
										$per2 = ($parametros->MEC_PROD2 > 0) ? ($parametros->MEC_PROD2/100) : 0;
										$per3 = ($parametros->MEC_PROD3 > 0) ? ($parametros->MEC_PROD3/100) : 0;
										$per4 = ($parametros->MEC_PROD4 > 0) ? ($parametros->MEC_PROD4/100) : 0;
									}else{
										$per1 = ($parametros->ELE_PROD1 > 0) ? ($parametros->ELE_PROD1/100) : 0;
										$per2 = ($parametros->ELE_PROD2 > 0) ? ($parametros->ELE_PROD2/100) : 0;
										$per3 = ($parametros->ELE_PROD3 > 0) ? ($parametros->ELE_PROD3/100) : 0;
										$per4 = ($parametros->ELE_PROD4 > 0) ? ($parametros->ELE_PROD4/100) : 0;
									}
									$fai_de1 = 0;
									$fai_ate1 = $produtividade * $per1;
									$fai_de2 = ($produtividade * $per1) + 1;
									$fai_ate2 = $produtividade * $per2;
									$fai_de3 = ($produtividade * $per2) + 1;
									$fai_ate3 = $produtividade * $per3;
									$fai_de4 = ($produtividade * $per3) + 1;
									$fai_ate4 = $produtividade;
									
									$campo_formula .= "FAI_DE1||{$fai_de1};;";
									$campo_formula .= "FAI_ATE1||{$fai_ate1};;";
									$comissao1 = $funcoes->sanearValor($_POST['fai_comissao1']);
									$campo_formula .= "FAI_COMISSAO1||{$comissao1};;";
									if ($_POST['premio1'] != ""){
										$premio1 = $funcoes->sanearValor($_POST['premio1']);
										$campo_formula  .= "PREMIO1||{$premio1};;";
									}
									$campo_formula .= "FAI_DE2||{$fai_de2};;";
									$campo_formula .= "FAI_ATE2||{$fai_ate2};;";
									$comissao2 = $funcoes->sanearValor($_POST['fai_comissao2']);
									$campo_formula .= "FAI_COMISSAO2||{$comissao2};;";
									if ($_POST['premio2'] != ""){
										$premio2 = $funcoes->sanearValor($_POST['premio2']);
										$campo_formula  .= "PREMIO2||{$premio2};;";
									}
									$campo_formula .= "FAI_DE3||{$fai_de3};;";
									$campo_formula .= "FAI_ATE3||{$fai_ate3};;";
									$comissao3 = $funcoes->sanearValor($_POST['fai_comissao3']);
									$campo_formula .= "FAI_COMISSAO3||{$comissao3};;";
									if ($_POST['premio3'] != ""){
										$premio3 = $funcoes->sanearValor($_POST['premio3']);
										$campo_formula  .= "PREMIO3||{$premio3};;";
									}
									$campo_formula .= "FAI_DE4||{$fai_de4};;";
									$campo_formula .= "FAI_ATE4||{$fai_ate4};;";
									$comissao4 = $funcoes->sanearValor($_POST['fai_comissao4']);
									$campo_formula .= "FAI_COMISSAO4||{$comissao4};;";
									if ($_POST['premio4'] != ""){
										$premio4 = $funcoes->sanearValor($_POST['premio4']);
										$campo_formula  .= "PREMIO4||{$premio4};;";
									}
								}elseif ($this->dados['grupo']->TIPO == 4){
									$apiIndex = new apiIndex();
									$campo_formula .= "FAI_AUTO||{$_POST['fai_auto']};;";
									$de = date('d/m/Y');
									$exp = explode('/',$de);
									
									$emprev = "{$this->emp->EMPRESA}.{$this->emp->REVENDA}";
									$parametros = $apiIndex->getParametros($emprev,"{$exp[1]}/{$exp[2]}");
									$prcmao = str_replace(",", ".", $parametros->MAODEOBRA);
									$produtividade = ($funcoes->horasTrabalhadas($this->emp->EMPRESA, $this->emp->REVENDA, $exp[1], $exp[2])) * $prcmao;
									
									$m1 = ($parametros->MEC_PROD1 > 0) ? ($parametros->MEC_PROD1/100) : 0;
									$mv1 = (($produtividade * $m1) * $parametros->QTD_MECA);
									$m2 = ($parametros->MEC_PROD2 > 0) ? ($parametros->MEC_PROD2/100) : 0;
									$mv2 = (($produtividade * $m2) * $parametros->QTD_MECA);
									$m3 = ($parametros->MEC_PROD3 > 0) ? ($parametros->MEC_PROD3/100) : 0;
									$mv3 = (($produtividade * $m3) * $parametros->QTD_MECA);
									$m4 = ($parametros->MEC_PROD4 > 0) ? ($parametros->MEC_PROD4/100) : 0;
									$mv4 = (($produtividade * $m4) * $parametros->QTD_MECA);
									$e1 = ($parametros->ELE_PROD1 > 0) ? ($parametros->ELE_PROD1/100) : 0;
									$ev1 = (($produtividade * $e1) * $parametros->QTD_ELET);
									$e2 = ($parametros->ELE_PROD2 > 0) ? ($parametros->ELE_PROD2/100) : 0;
									$ev2 = (($produtividade * $e2) * $parametros->QTD_ELET);
									$e3 = ($parametros->ELE_PROD3 > 0) ? ($parametros->ELE_PROD3/100) : 0;
									$ev3 = (($produtividade * $e3) * $parametros->QTD_ELET);
									$e4 = ($parametros->ELE_PROD4 > 0) ? ($parametros->ELE_PROD4/100) : 0;
									$ev4 = (($produtividade * $e4) * $parametros->QTD_ELET);
									
									$fai_de1 = 0;
									$fai_ate1 = (($mv1 + $ev1)/$parametros->QTD_CONS);
									$fai_de2 = (($mv1 + $ev1)/$parametros->QTD_CONS) + 1;
									$fai_ate2 = (($mv2 + $ev2)/$parametros->QTD_CONS);
									$fai_de3 = (($mv2 + $ev2)/$parametros->QTD_CONS) + 1;
									$fai_ate3 = (($mv3 + $ev3)/$parametros->QTD_CONS);
									$fai_de4 = (($mv3 + $ev3)/$parametros->QTD_CONS) + 1;
									$fai_ate4 = (($mv4 + $ev4)/$parametros->QTD_CONS);			
									
									$campo_formula .= "FAI_DE1||{$fai_de1};;";
									$campo_formula .= "FAI_ATE1||{$fai_ate1};;";
									$comissao1 = $funcoes->sanearValor($_POST['fai_comissao1']);
									$campo_formula .= "FAI_COMISSAO1||{$comissao1};;";
									if ($_POST['premio1'] != ""){
										$premio1 = $funcoes->sanearValor($_POST['premio1']);
										$campo_formula  .= "PREMIO1||{$premio1};;";
									}
									$campo_formula .= "FAI_DE2||{$fai_de2};;";
									$campo_formula .= "FAI_ATE2||{$fai_ate2};;";
									$comissao2 = $funcoes->sanearValor($_POST['fai_comissao2']);
									$campo_formula .= "FAI_COMISSAO2||{$comissao2};;";
									if ($_POST['premio2'] != ""){
										$premio2 = $funcoes->sanearValor($_POST['premio2']);
										$campo_formula  .= "PREMIO2||{$premio2};;";
									}
									$campo_formula .= "FAI_DE3||{$fai_de3};;";
									$campo_formula .= "FAI_ATE3||{$fai_ate3};;";
									$comissao3 = $funcoes->sanearValor($_POST['fai_comissao3']);
									$campo_formula .= "FAI_COMISSAO3||{$comissao3};;";
									if ($_POST['premio3'] != ""){
										$premio3 = $funcoes->sanearValor($_POST['premio3']);
										$campo_formula  .= "PREMIO3||{$premio3};;";
									}
									$campo_formula .= "FAI_DE4||{$fai_de4};;";
									$campo_formula .= "FAI_ATE4||{$fai_ate4};;";
									$comissao4 = $funcoes->sanearValor($_POST['fai_comissao4']);
									$campo_formula .= "FAI_COMISSAO4||{$comissao4};;";
									if ($_POST['premio4'] != ""){
										$premio4 = $funcoes->sanearValor($_POST['premio4']);
										$campo_formula  .= "PREMIO4||{$premio4};;";
									}
								}
							}
						}else{
							$de1 = $funcoes->sanearValor($_POST['fai_de1']);
							$campo_formula .= "FAI_DE1||{$de1};;";
							$ate1 = $funcoes->sanearValor($_POST['fai_ate1']);
							$campo_formula .= "FAI_ATE1||{$ate1};;";
							$comissao1 = $funcoes->sanearValor($_POST['fai_comissao1']);
							$campo_formula .= "FAI_COMISSAO1||{$comissao1};;";
							if ($_POST['premio1'] != ""){
								$premio1 = $funcoes->sanearValor($_POST['premio1']);
								$campo_formula  .= "PREMIO1||{$premio1};;";
							}
							if ($_POST['fai_de2'] != ""){
								$de2 = $funcoes->sanearValor($_POST['fai_de2']);
								$campo_formula .= "FAI_DE2||{$de2};;";
								$ate2 = $funcoes->sanearValor($_POST['fai_ate2']);
								$campo_formula .= "FAI_ATE2||{$ate2};;";
								$comissao2 = $funcoes->sanearValor($_POST['fai_comissao2']);
								$campo_formula .= "FAI_COMISSAO2||{$comissao2};;";
								if ($_POST['premio2'] != ""){
									$premio2 = $funcoes->sanearValor($_POST['premio2']);
									$campo_formula  .= "PREMIO2||{$premio2};;";
								}
							}
							if ($_POST['fai_de3'] != ""){
								$de3 = $funcoes->sanearValor($_POST['fai_de3']);
								$campo_formula .= "FAI_DE3||{$de3};;";
								$ate3 = $funcoes->sanearValor($_POST['fai_ate3']);
								$campo_formula .= "FAI_ATE3||{$ate3};;";
								$comissao3 = $funcoes->sanearValor($_POST['fai_comissao3']);
								$campo_formula .= "FAI_COMISSAO3||{$comissao3};;";
								if ($_POST['premio3'] != ""){
									$premio3 = $funcoes->sanearValor($_POST['premio3']);
									$campo_formula  .= "PREMIO3||{$premio3};;";
								}
							}
							if ($_POST['fai_de4'] != ""){
								$de4 = $funcoes->sanearValor($_POST['fai_de4']);
								$campo_formula .= "FAI_DE4||{$de4};;";
								$ate4 = $funcoes->sanearValor($_POST['fai_ate4']);
								$campo_formula .= "FAI_ATE4||{$ate4};;";
								$comissao4 = $funcoes->sanearValor($_POST['fai_comissao4']);
								$campo_formula .= "FAI_COMISSAO4||{$comissao4};;";
								if ($_POST['premio4'] != ""){
									$premio4 = $funcoes->sanearValor($_POST['premio4']);
									$campo_formula  .= "PREMIO4||{$premio4};;";
								}
							}
							if ($_POST['fai_de5'] != ""){
								$de5 = $funcoes->sanearValor($_POST['fai_de5']);
								$campo_formula .= "FAI_DE5||{$de5};;";
								$ate5 = $funcoes->sanearValor($_POST['fai_ate5']);
								$campo_formula .= "FAI_ATE5||{$ate2};;";
								$comissao5 = $funcoes->sanearValor($_POST['fai_comissao5']);
								$campo_formula .= "FAI_COMISSAO5||{$comissao5};;";
							}
						}
						if (isset($_POST['meta_novos'])){
							$campo_formula .= "META_NOVOS||{$_POST['meta_novos']};;";
						}
						if (isset($_POST['meta_usados'])){
							$campo_formula .= "META_USADOS||{$_POST['meta_usados']};;";
						}
						if (isset($_POST['meta_direto'])){
							$campo_formula .= "META_DIRETO||{$_POST['meta_direto']};;";
						}
						if (isset($_POST['meta_consorcio'])){
							$campo_formula .= "META_CONSORCIO||{$_POST['meta_consorcio']};;";
						}
						if (isset($_POST['meta_pecas'])){
							$campo_formula .= "META_PECAS||{$_POST['meta_pecas']};;";
						}
						if (isset($_POST['meta_maodeobra'])){
							$campo_formula .= "META_MAODEOBRA||{$_POST['meta_maodeobra']};;";
						}
						if (isset($_POST['meta_premio'])){
							$campo_formula .= "META_PREMIO||{$_POST['meta_premio']};;";
						}
					}elseif ($_POST['por'] == "TIP"){
						if (isset($_POST['comissao_novos'])){
							$com = $funcoes->sanearValor($_POST['comissao_novos']);
							$campo_formula .= "COMISSAO_NOVOS||{$com};;";
							$campo_formula .= "META_NOVOS||{$_POST['meta_novos']};;";
						}
						if (isset($_POST['comissao_usados'])){
							$com = $funcoes->sanearValor($_POST['comissao_usados']);
							$campo_formula .= "COMISSAO_USADOS||{$com};;";
							$campo_formula .= "META_USADOS||{$_POST['meta_usados']};;";
						}
						if (isset($_POST['comissao_direto'])){
							$com = $funcoes->sanearValor($_POST['comissao_direto']);
							$campo_formula .= "COMISSAO_DIRETO||{$com};;";
							$campo_formula .= "META_DIRETO||{$_POST['meta_direto']};;";
						}
						if (isset($_POST['comissao_consorcio'])){
							$com = $funcoes->sanearValor($_POST['comissao_consorcio']);
							$campo_formula .= "COMISSAO_CONSORCIO||{$com};;";
							$campo_formula .= "META_CONSORCIO||{$_POST['meta_consorcio']};;";
						}
						if (isset($_POST['comissao_pecas'])){
							$com = $funcoes->sanearValor($_POST['comissao_pecas']);
							$campo_formula .= "COMISSAO_PECAS||{$com};;";
							$campo_formula .= "META_PECAS||{$_POST['meta_pecas']};;";
						}
						if (isset($_POST['comissao_maodeobra'])){
							$com = $funcoes->sanearValor($_POST['comissao_maodeobra']);
							$campo_formula .= "COMISSAO_MAODEOBRA||{$com};;";
							$campo_formula .= "META_MAODEOBRA||{$_POST['meta_maodeobra']};;";
						}
					}
				}
				if ($this->dados['grupo']->CAMPO_FORMULA != $campo_formula){
					$Post->campo_formula = $campo_formula;
					$anterior .= "CAMPO_FORMULA||".str_replace(";;", ">>", str_replace("||", "<<", $this->dados['grupo']->CAMPO_FORMULA)).";;";
					$atual .= "CAMPO_FORMULA||".str_replace(";;", ">>", str_replace("||", "<<", $Post->campo_formula)).";;";
				}
				$sql[$i] = $apiGrupo->editGrupo($Post);
				if ($anterior != ""){
					$i = $i+1;
					$log = new Log();
					$log->usuario = $_SESSION['usuario_sessao'];
					$log->modulo = $this->getModule()['modulo'];
					$log->controle = $this->getController()['controle'];
					$log->acao = $this->getAction()['acao'];
					$log->empresa = $_SESSION['empresa_sessao'];
					$log->tipo = "A";
					$log->dta_registro = date("d/m/Y H:i:s");
					$log->historico = substr($anterior,0,-2);
					$log->historico .= substr($atual,0,-2);
					$apiLog = new apiLog();
					$sql[$i] = $apiLog->addLog($log);
				}
				$rs = $apiGrupo->executeSQL($sql);
				if (isset($rs[4])){
					if (@$rs[4] == 'sucesso') {
						if (isset($this->PaginaAtual)) {
							header('location:' .APP_ROOT. 'com/grupo/index/pagina/'.$this->PaginaAtual.'/sucesso');
						}else {
							header('location:' .APP_ROOT. 'com/grupo/index/sucesso');
						}
					}else{
						$this->dados['grupo']->DES_GRUPO = $_POST['des_grupo'];
						$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
						$erro = str_replace($retirar, "", $rs[2]);
						$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
					}
				}else{
					header('location:' .APP_ROOT. 'com/grupo/index/insucesso');
				}
				
			}
		}
		$this->view();
	}
	public function excluir() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Exclus�o de Grupo";
		$grupo = new Grupo();
		$grupo->grupo = $this->getParams(0);
		$grupo->empresa = $_SESSION['empresa_sessao'];
		$apiGrupo = new apiGrupo();
		$this->dados = array('grupo' => $apiGrupo->getGrupo($grupo));
		if (!isset($this->dados['grupo'])){
			header('location:' .APP_ROOT. 'com/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$sql[$i] = $apiGrupo->delGrupo($grupo);
			$i = $i+1;
			$log = new Log();
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "E";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico = "TIPO||{$this->dados['grupo']->TIPO};;EMPRESA||{$this->dados['grupo']->EMPRESA};;GRUPO||{$this->dados['grupo']->GRUPO};;DES_GRUPO||{$this->dados['grupo']->DES_GRUPO};;CAMPO_FORMULA||{$this->dados['grupo']->CAMPO_FORMULA}";
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiGrupo->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'com/grupo/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'com/grupo/index/sucesso');
				}
			}else{
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}
		$this->view();
	}
}