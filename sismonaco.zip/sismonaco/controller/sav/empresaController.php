<?php

namespace controller\sav;

use lib\Controller;
use helper\Security;
use api\sav\apiEmpresa;
use helper\Paginator;
use obj\sav\Empresa;
use obj\geral\Log;
use api\geral\apiLog;
use helper\Funcoes;

class empresaController extends Controller {
	
	public function __construct() {
		
		parent::__construct();
		
		new Security($this->getModule(),$this->getController(),$this->getAction());
	}
	
	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Lista de Empresas";
		$apiEmpresa = new apiEmpresa();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$busca = array(
				'1' => array('c' => '1', 'coluna' => 'dn', 'valor' => @$_POST['busca_valor']),
				'2' => array('c' => '2', 'coluna' => 'descricao', 'valor' => @$_POST['busca_valor']),
				'3' => array('c' => '3', 'coluna' => "",'valor' => "")
			);
			if(isset($busca[$_POST['busca']])){
				$this->dados = array('empresa' => $apiEmpresa->filtroEmpresa($busca[$_POST['busca']]['c'], $busca[$_POST['busca']]['coluna'], $busca[$_POST['busca']]['valor']));
				$_SESSION['filtro_sessao'] = array('c' => $busca[$_POST['busca']]['c'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'busca_valor' => $busca[$_POST['busca']]['valor'], 'busca' => $_POST['busca'] );
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'sav/index/index/acessonegado');
				die();
			}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				$this->dados = array('empresa' => $apiEmpresa->filtroEmpresa($_SESSION['filtro_sessao']['c'],$_SESSION['filtro_sessao']['coluna'], $_SESSION['filtro_sessao']['busca_valor']));
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('empresa' => $apiEmpresa->filtroEmpresa('3','',''));
					$_SESSION['filtro_sessao'] = array('c' => '3', 'coluna' => '' , 'busca_valor' => '', 'busca' => '3');
					$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}
			
		}
		$TotalItem = (is_array($this->dados['empresa']) ? count($this->dados['empresa']) : 0);
		$this->dados['empresa'] = array_chunk($this->dados['empresa'], $ItemPorPagina);
		@$this->dados['empresa'] = $this->dados['empresa'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->view();
	}
	
	public function adicionar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Cadastro de Empresa";
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		$apiEmp = new \api\geral\apiEmpresa();
		$this->empresa = $apiEmp->filtroEmpresa("1","3","ativo","1");
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$funcoes = new Funcoes();
			$Post = new Empresa('POST');
			$exp1 = explode("-", $_POST['gerente_novos']);
			$Post->gerente_novos = $exp1[0];
			$exp2 = explode("-", $_POST['gerente_usados']);
			$Post->gerente_usados = $exp2[0];
			$exp3 = explode("-", $_POST['diretor']);
			$Post->diretor = $exp3[0];
			$apiEmpresa = new apiEmpresa();
			$rs = $apiEmpresa->filtroEmpresa("1","empresa",$Post->empresa);
			if ((is_array($rs) ? count($rs) : 0) > 0){
				$this->rollback = new Empresa('POST');
				$this->Alert = "Essa empresa j� est� cadastrada no sav";
			}else{
				$sql[$i] = $apiEmpresa->addEmpresa($Post);
				$i = $i+1;
				$log = new Log();
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico = "EMPRESA||{$Post->empresa};;GERENTE_NOVOS||{$Post->gerente_novos};;GERENTE_USADOS||{$Post->gerente_usados};;DIRETOR||{$Post->diretor};;EMPRESA_APOLLO||{$Post->empresa_apollo};;REVENDA_APOLLO||{$Post->revenda_apollo};;DN||{$Post->dn};;DESCRICAO||{$Post->descricao};;UF||{$Post->uf};;CIDADE||{$Post->cidade}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiEmpresa->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'sav/empresa/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'sav/empresa/index/sucesso');
					}
				}else{
					$this->rollback = new Empresa('POST');
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		
		$this->view();
	}
	
	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Altera��o de Empresa";
		$empresa = new Empresa();
		$empresa->empresa = $this->getParams(0);
		$apiEmpresa = new apiEmpresa();
		$this->dados = array('empresa' => $apiEmpresa->getEmpresa($empresa));
		if (!isset($this->dados['empresa'])){
			header('location:' .APP_ROOT. 'sav/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$funcoes = new Funcoes();
			$Post = new Empresa('POST');
			$Post->empresa = $this->getParams(0);;
			$exp1 = explode("-", $_POST['gerente_novos']);
			$Post->gerente_novos = $exp1[0];
			$exp2 = explode("-", $_POST['gerente_usados']);
			$Post->gerente_usados = $exp2[0];
			$exp3 = explode("-", $_POST['diretor']);
			$Post->diretor = $exp3[0];
			$log = new Log();
			$log->historico = "GERENTE_NOVOS||{$this->dados['empresa']->GERENTE_NOVOS};;GERENTE_USADOS||{$this->dados['empresa']->GERENTE_USADOS};;DIRETOR||{$this->dados['empresa']->DIRETOR};;EMPRESA_APOLLO||{$this->dados['empresa']->EMPRESA_APOLLO};;REVENDA_APOLLO||{$this->dados['empresa']->REVENDA_APOLLO};;DN||{$this->dados['empresa']->DN};;DESCRICAO||{$this->dados['empresa']->DESCRICAO};;UF||{$this->dados['empresa']->UF};;CIDADE||{$this->dados['empresa']->CIDADE}";
			$sql[$i] = $apiEmpresa->editEmpresa($Post);
			$i = $i+1;
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "A";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico = "::GERENTE_NOVOS||{$Post->gerente_novos};;GERENTE_USADOS||{$Post->gerente_usados};;DIRETOR||{$Post->diretor};;EMPRESA_APOLLO||{$Post->empresa_apollo};;REVENDA_APOLLO||{$Post->revenda_apollo};;DN||{$Post->dn};;DESCRICAO||{$Post->descricao};;UF||{$Post->uf};;CIDADE||{$Post->cidade}";
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiEmpresa->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'sav/empresa/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'sav/empresa/index/sucesso');
				}
			}else{
				$this->dados['empresa']->EMPRESA_APOLLO = $Post->empresa_apollo;
				$this->dados['empresa']->REVENDA_APOLLO = $Post->revenda_apollo;
				$this->dados['empresa']->DN = $Post->dn;
				$this->dados['empresa']->DESCRICAO = $Post->descricao;
				$this->dados['empresa']->UF = $Post->uf;
				$this->dados['empresa']->CIDADE = $Post->cidade;
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}
		
		$this->view();
	}
	public function excluir() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Exclus�o de Empresa";
		$empresa = new Empresa();
		$empresa->empresa = $this->getParams(0);
		$apiEmpresa = new apiEmpresa();
		$this->dados = array('empresa' => $apiEmpresa->getEmpresa($empresa));
		$this->funcoes = new Funcoes();
		if (!isset($this->dados['empresa'])){
			header('location:' .APP_ROOT. 'sav/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$sql[$i] = $apiEmpresa->delEmpresa($empresa);
			$i = $i+1;
			$log = new Log();
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "E";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico = "EMPRESA||{$this->dados['empresa']->EMPRESA};;GERENTE_NOVOS||{$this->dados['empresa']->GERENTE_NOVOS};;GERENTE_USADOS||{$this->dados['empresa']->GERENTE_USADOS};;DIRETOR||{$this->dados['empresa']->DIRETOR};;EMPRESA_APOLLO||{$this->dados['empresa']->EMPRESA_APOLLO};;REVENDA_APOLLO||{$this->dados['empresa']->REVENDA_APOLLO};;DN||{$this->dados['empresa']->DN};;DESCRICAO||{$this->dados['empresa']->DESCRICAO};;UF||{$this->dados['empresa']->UF};;CIDADE||{$this->dados['empresa']->CIDADE}";
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiEmpresa->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'sav/empresa/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'sav/empresa/index/sucesso');
				}
			}else{
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}
		$this->view();
	}
}