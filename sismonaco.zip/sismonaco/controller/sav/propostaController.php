<?php

namespace controller\sav;

use lib\Controller;
use helper\Security;
use api\sav\apiProposta;
use helper\Paginator;
use obj\sav\Proposta;
use helper\Funcoes;
use obj\geral\Log;
use api\geral\apiLog;
use api\geral\apiApollo;
use api\sav\apiEmpresa;
use api\adm\apiUsuario;
use classes\FPDF;

include 'classes/FPDF/fpdf.php';

class propostaController extends Controller {
	
	public function __construct() {
		
		parent::__construct();
		
		new Security($this->getModule(),$this->getController(),$this->getAction());
	}
	
	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Lista de Proposta";
		$apiProposta = new apiProposta();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$busca = array(
				'1' => array('situacao' => $_POST['situacao'], 'c' => '1', 'coluna' => 'proposta', 'valor' => @$_POST['busca_valor']),
				'2' => array('situacao' => $_POST['situacao'], 'c' => '1', 'coluna' => 'proposta_apollo', 'valor' => @$_POST['busca_valor']),
				'3' => array('situacao' => $_POST['situacao'], 'c' => '5', 'coluna' => "", 'valor' => ""),
				'4' => array('situacao' => $_POST['situacao'], 'c' => '4', 'coluna' => 'dta_inclusao', 'valor' => @$_POST['busca_valor'], 'de' => @$_POST['busca_de'], 'ate' => @$_POST['busca_ate']),
				'5' => array('situacao' => $_POST['situacao'], 'c' => '4', 'coluna' => 'dta_conclusao', 'valor' => @$_POST['busca_valor'], 'de' => @$_POST['busca_de'], 'ate' => @$_POST['busca_ate']),
				'6' => array('situacao' => $_POST['situacao'], 'c' => '3', 'coluna' => "", 'valor' => "")
			);
			if(isset($busca[$_POST['busca']])){
				$this->dados = array('proposta' => $apiProposta->filtroProposta($busca[$_POST['busca']]['situacao'], $busca[$_POST['busca']]['c'], $_SESSION['empresa_sessao'], $busca[$_POST['busca']]['coluna'], $busca[$_POST['busca']]['valor'], @$busca[$_POST['busca']]['de'], @$busca[$_POST['busca']]['ate']));
				$_SESSION['filtro_sessao'] = array('situacao' => $busca[$_POST['busca']]['situacao'], 'c' => $busca[$_POST['busca']]['c'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'busca_valor' => $busca[$_POST['busca']]['valor'], 'de' => isset($_POST['busca_de']) ? $_POST['busca_de'] : "", 'ate' => isset($_POST['busca_ate']) ? $_POST['busca_ate'] : "", 'busca' => $_POST['busca'] );
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'sav/index/index/acessonegado');
				die();
			}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso" || end($endereco) == "atualizar"){
				$this->dados = array('proposta' => $apiProposta->filtroProposta($_SESSION['filtro_sessao']['situacao'], $_SESSION['filtro_sessao']['c'], $_SESSION['empresa_sessao'], $_SESSION['filtro_sessao']['coluna'], $_SESSION['filtro_sessao']['busca_valor'], @$_SESSION['filtro_sessao']['de'], @$_SESSION['filtro_sessao']['ate']));
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('proposta' => $apiProposta->filtroProposta('tudo','3', $_SESSION['empresa_sessao']));
					$_SESSION['filtro_sessao'] = array('situacao' => 'tudo', 'c' => '3', 'coluna' => '' , 'busca_valor' => '', 'busca' => '6');
					$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}
		}
		$TotalItem = (is_array($this->dados['proposta']) ? count($this->dados['proposta']) : 0);
		$this->dados['proposta'] = array_chunk($this->dados['proposta'], $ItemPorPagina);
		@$this->dados['proposta'] = $this->dados['proposta'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->view();
	}
	
	public function adicionar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Cadastro de Proposta";
		$apiProposta = new apiProposta();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$apiEmpresa = new apiEmpresa();
			$capa = $apiEmpresa->filtroEmpresa("1","empresa",$_SESSION['empresa_sessao']);
			$Post = new Proposta();
			$funcoes = new Funcoes();
			$info = "";
			$Post->empresa = $_SESSION['empresa_sessao'];
			$info .= "EMPRESA||{$Post->empresa};;";
			$Post->usuario = $_SESSION['usuario_sessao'];
			$info .= "USUARIO||{$Post->usuario};;";
			$Post->tipo_venda = $_POST['tipo_venda'];
			$info .= "TIPO_VENDA||{$Post->tipo_venda};;";
			if ($Post->tipo_venda == "U"){
				$Post->gerente = $capa[0]->GERENTE_USADOS;
				$gerente = strtoupper($capa[0]->NOME_USADOS);
				$gerente_cpf = $funcoes->mask(str_pad($capa[0]->CPF_USADOS, 11, "0", STR_PAD_LEFT),"###.###.###-##");
			}else{
				$Post->gerente = $capa[0]->GERENTE_NOVOS;
				$gerente = strtoupper($capa[0]->NOME_NOVOS);
				$gerente_cpf = $funcoes->mask(str_pad($capa[0]->CPF_NOVOS, 11, "0", STR_PAD_LEFT),"###.###.###-##");
			}
			$info .= "GERENTE||{$Post->gerente};;";
			$Post->vendedor_nome = strtoupper($funcoes->retiraAcentos(trim($_POST['vendedor_nome'])));
			$info .= "VENDEDOR_NOME||{$Post->vendedor_nome};;";
			$Post->cliente_nome = strtoupper($funcoes->retiraAcentos(trim($_POST['cliente_nome'])));
			$info .= "CLIENTE_NOME||{$Post->cliente_nome};;";
			$Post->chassi = strtoupper($funcoes->retiraAcentos(trim($_POST['chassi'])));
			$info .= "CHASSI||{$Post->chassi};;";
			$Post->modelo = strtoupper($funcoes->retiraAcentos(trim($_POST['modelo'])));
			$info .= "MODELO||{$Post->modelo};;";
			if ($Post->tipo_venda == 'N'){
				$Post->val_emissao_nf = $funcoes->sanearValor($_POST['val_emissao_nf']);
				$info .= "VAL_EMISSAO_NF||{$Post->val_emissao_nf};;";
				$Post->val_venda = $funcoes->sanearValor($_POST['val_venda']);
				$info .= "VAL_VENDA||{$Post->val_venda};;";
				$Post->val_outras_receitas_op = $funcoes->sanearValor($_POST['val_outras_receitas_op']);
				$info .= "VAL_OUTRAS_RECEITAS_OP||{$Post->val_outras_receitas_op};;";
				$Post->perc_icms = $funcoes->sanearValor($_POST['perc_icms']);
				$info .= "PERC_ICMS||{$Post->perc_icms};;";
				$Post->val_icms = $funcoes->sanearValor($_POST['val_icms']);
				$info .= "VAL_ICMS||{$Post->val_icms};;";
				$Post->val_custo_operacional = $funcoes->sanearValor($_POST['val_custo_operacional']);
				$info .= "VAL_CUSTO_OPERACIONAL||{$Post->val_custo_operacional};;";
				$Post->val_frete = $funcoes->sanearValor($_POST['val_frete']);
				$info .= "VAL_FRETE||{$Post->val_frete};;";
				$Post->val_outros_custos = $funcoes->sanearValor($_POST['val_outros_custos']);
				$info .= "VAL_OUTROS_CUSTOS||{$Post->val_outros_custos};;";
				$Post->cmv = $funcoes->sanearValor($_POST['cmv']);
				$info .= "CMV||{$Post->cmv};;";
				$Post->lucro_bruto = $funcoes->sanearValor($_POST['lucro_bruto']);
				$info .= "LUCRO_BRUTO||{$Post->lucro_bruto};;";
				$Post->perc_lucro = $funcoes->sanearValor($_POST['perc_lucro']);
				$info .= "PERC_LUCRO||{$Post->perc_lucro};;";
				$Post->val_fabrica = $funcoes->sanearValor($_POST['val_fabrica']);
				$info .= "VAL_FABRICA||{$Post->val_fabrica};;";
				$Post->perc_credito_icms = $funcoes->sanearValor($_POST['perc_credito_icms']);
				$info .= "PERC_CREDITO_ICMS||{$Post->perc_credito_icms};;";
				$Post->val_credito_icms = $funcoes->sanearValor($_POST['val_credito_icms']);
				$info .= "VAL_CREDITO_ICMS||{$Post->val_credito_icms};;";
				$Post->val_implemento = $funcoes->sanearValor($_POST['val_implemento']);
				$info .= "VAL_IMPLEMENTO||{$Post->val_implemento};;";
				$Post->perc_icms_imp = $funcoes->sanearValor($_POST['perc_icms_imp']);
				$info .= "PERC_ICMS_IMP||{$Post->perc_icms_imp};;";
				$Post->val_icms_imp = $funcoes->sanearValor($_POST['val_icms_imp']);
				$info .= "VAL_ICMS_IMP||{$Post->val_icms_imp};;";
				$Post->perc_bonus_fab = $funcoes->sanearValor($_POST['perc_bonus_fab']);
				$info .= "PERC_BONUS_FAB||{$Post->perc_bonus_fab};;";
				$Post->credito_bonus = $funcoes->sanearValor($_POST['credito_bonus']);
				$info .= "CREDITO_BONUS||{$Post->credito_bonus};;";
				$Post->bonus_fabrica = $funcoes->sanearValor($_POST['bonus_fabrica']);
				$info .= "BONUS_FABRICA||{$Post->bonus_fabrica};;";
				$Post->custo_veiculo = $funcoes->sanearValor($_POST['custo_veiculo']);
				$info .= "CUSTO_VEICULO||{$Post->custo_veiculo};;";
				$Post->desconto_comissao = $funcoes->sanearValor($_POST['desconto_comissao']);
				$info .= "DESCONTO_COMISSAO||{$Post->desconto_comissao};;";
				$Post->base_calculo = $funcoes->sanearValor($_POST['base_calculo']);
				$info .= "BASE_CALCULO||{$Post->base_calculo};;";
				$Post->perc_comissao = $funcoes->sanearValor($_POST['perc_comissao']);
				$info .= "PERC_COMISSAO||{$Post->perc_comissao};;";
				$Post->bonificacao = $funcoes->sanearValor($_POST['bonificacao']);
				$info .= "BONIFICACAO||{$Post->bonificacao};;";
				$Post->comissao = $funcoes->sanearValor($_POST['comissao']);
				$info .= "COMISSAO||{$Post->comissao};;";
				
				$val_pag = $_POST['valor_pagamento'];
				foreach ($_POST['des_pagamento'] as $key => $r) {
					$Post->des_pagamento .=  ($r != NULL || $val_pag{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_pag{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_pag{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
				}
				$info .= "DES_PAGAMENTO||{$Post->des_pagamento};;";
				
				$val_fre = $_POST['valor_frete'];
				foreach ($_POST['des_frete'] as $key => $r) {
					$Post->des_frete.=  ($r != NULL || $val_fre{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_fre{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_fre{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
				}
				$info .= "DES_FRETE||{$Post->des_frete};;";
				
				$val_out = $_POST['valor_outros_custos'];
				foreach ($_POST['des_outros_custos'] as $key => $r) {
					$Post->des_outros_custos .=  ($r != NULL || $val_out{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_out{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_out{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
				}
				$info .= "DES_OUTROS_CUSTOS||{$Post->des_outros_custos};;";
				
				$val_imp = $_POST['valor_implemento'];
				foreach ($_POST['des_implemento'] as $key => $r) {
					$Post->des_implemento .=  ($r != NULL || $val_imp{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_imp{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_imp{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
				}
				$info .= "DES_IMPLEMENTO||{$Post->des_implemento};;";
				
				$val_vei = $_POST['valor_veiculo_usado'];
				foreach ($_POST['des_veiculo_usado'] as $key => $r) {
					$Post->des_veiculo_usado .=  ($r != NULL || $val_vei{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_vei{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "MARCA: ".str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 43, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_vei{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
				}
				$info .= "DES_VEICULO_USADO||{$Post->des_veiculo_usado};;";
				
				$val_bo = $_POST['valor_bonus'];
				foreach ($_POST['des_bonus'] as $key => $r) {
					$Post->des_bonus .=  ($r != NULL || $val_bo{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_bo{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_bo{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
				}
				$info .= "DES_BONUS||{$Post->des_bonus};;";
				
				$Post->des_vendedor .= "VENDEDOR: {$Post->vendedor_nome}\r\n"."GERENTE: ".$gerente." CPF: ".$gerente_cpf;
				$info .= "DES_VENDEDOR||{$Post->des_vendedor};;";
				
				$Post->obs1 = strtoupper(trim($_POST['obs1']));
				$info .= "OBS1||{$Post->obs1};;";
				$Post->obs2 = strtoupper(trim($_POST['obs2']));
				$info .= "OBS2||{$Post->obs2};;";
				$Post->obs3 = strtoupper(trim($_POST['obs3']));
				$info .= "OBS3||{$Post->obs3};;";
			}elseif ($Post->tipo_venda == 'U'){
				$Post->val_emissao_nf = $funcoes->sanearValor($_POST['val_emissao_nf']);
				$info .= "VAL_EMISSAO_NF||{$Post->val_emissao_nf};;";
				$Post->val_venda = $funcoes->sanearValor($_POST['val_venda']);
				$info .= "VAL_VENDA||{$Post->val_venda};;";
				$Post->val_outras_receitas_op = $funcoes->sanearValor($_POST['val_outras_receitas_op']);
				$info .= "VAL_OUTRAS_RECEITAS_OP||{$Post->val_outras_receitas_op};;";
				$Post->perc_icms = $funcoes->sanearValor($_POST['perc_icms']);
				$info .= "PERC_ICMS||{$Post->perc_icms};;";
				$Post->val_icms = $funcoes->sanearValor($_POST['val_icms']);
				$info .= "VAL_ICMS||{$Post->val_icms};;";
				$Post->val_pis_cofins_compra = $funcoes->sanearValor($_POST['val_pis_cofins_compra']);
				$info .= "VAL_PIS_COFINS_COMPRA||{$Post->val_pis_cofins_compra};;";
				$Post->val_frete = $funcoes->sanearValor($_POST['val_frete']);
				$info .= "VAL_FRETE||{$Post->val_frete};;";
				$Post->custo_veiculo = $funcoes->sanearValor($_POST['custo_veiculo']);
				$info .= "CUSTO_VEICULO||{$Post->custo_veiculo};;";
				$Post->val_outros_custos = $funcoes->sanearValor($_POST['val_outros_custos']);
				$info .= "VAL_OUTROS_CUSTOS||{$Post->val_outros_custos};;";
				$Post->cmv = $funcoes->sanearValor($_POST['cmv']);
				$info .= "CMV||{$Post->cmv};;";
				$Post->lucro_bruto = $funcoes->sanearValor($_POST['lucro_bruto']);
				$info .= "LUCRO_BRUTO||{$Post->lucro_bruto};;";
				$Post->perc_lucro = $funcoes->sanearValor($_POST['perc_lucro']);
				$info .= "PERC_LUCRO||{$Post->perc_lucro};;";
				$Post->desconto_comissao = $funcoes->sanearValor($_POST['desconto_comissao']);
				$info .= "DESCONTO_COMISSAO||{$Post->desconto_comissao};;";
				$Post->base_calculo = $funcoes->sanearValor($_POST['base_calculo']);
				$info .= "BASE_CALCULO||{$Post->base_calculo};;";
				$Post->perc_comissao = $funcoes->sanearValor($_POST['perc_comissao']);
				$info .= "PERC_COMISSAO||{$Post->perc_comissao};;";
				$Post->comissao = $funcoes->sanearValor($_POST['comissao']);
				$info .= "COMISSAO||{$Post->comissao};;";
				
				$val_pag = $_POST['valor_pagamento'];
				foreach ($_POST['des_pagamento'] as $key => $r) {
					$Post->des_pagamento .=  ($r != NULL || $val_pag{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_pag{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_pag{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
				}
				$info .= "DES_PAGAMENTO||{$Post->des_pagamento};;";
				
				$val_fre = $_POST['valor_frete'];
				foreach ($_POST['des_frete'] as $key => $r) {
					$Post->des_frete.=  ($r != NULL || $val_fre{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_fre{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_fre{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
				}
				$info .= "DES_FRETE||{$Post->des_frete};;";
				
				$val_out = $_POST['valor_outros_custos'];
				foreach ($_POST['des_outros_custos'] as $key => $r) {
					$Post->des_outros_custos .=  ($r != NULL || $val_out{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_out{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_out{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
				}
				$info .= "DES_OUTROS_CUSTOS||{$Post->des_outros_custos};;";
				
				$val_bo = $_POST['valor_bonus'];
				foreach ($_POST['des_bonus'] as $key => $r) {
					$Post->des_bonus .=  ($r != NULL || $val_bo{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_bo{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_bo{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
				}
				$info .= "DES_BONUS||{$Post->des_bonus};;";
				
				$Post->des_vendedor .= "VENDEDOR: {$Post->vendedor_nome}\r\n"."GERENTE: ".$gerente." CPF: ".$gerente_cpf;
				$info .= "DES_VENDEDOR||{$Post->des_vendedor};;";
				
				$Post->obs1 = strtoupper(trim($_POST['obs1']));
				$info .= "OBS1||{$Post->obs1};;";
				$Post->obs2 = strtoupper(trim($_POST['obs2']));
				$info .= "OBS2||{$Post->obs2};;";
				$Post->obs3 = strtoupper(trim($_POST['obs3']));
				$info .= "OBS3||{$Post->obs3};;";
			}else{
				$Post->val_nf_fabrica = $funcoes->sanearValor($_POST['val_nf_fabrica']);
				$info .= "VAL_NF_FABRICA||{$Post->val_nf_fabrica};;";
				$Post->val_venda = $funcoes->sanearValor($_POST['val_venda']);
				$info .= "VAL_VENDA||{$Post->val_venda};;";
				$Post->comissao_fabrica = $funcoes->sanearValor($_POST['comissao_fabrica']);
				$info .= "COMISSAO_FABRICA||{$Post->comissao_fabrica};;";
				$Post->val_comissao_fabrica= $funcoes->sanearValor($_POST['val_comissao_fabrica']);
				$info .= "VAL_COMISSAO_FABRICA||{$Post->val_comissao_fabrica};;";
				$Post->val_dif_nffabrica_nfvenda = $funcoes->sanearValor($_POST['val_dif_nffabrica_nfvenda']);
				$info .= "VAL_DIF_NFFABRICA_NFVENDA||{$Post->val_dif_nffabrica_nfvenda};;";
				$Post->val_outras_receitas_op = $funcoes->sanearValor($_POST['val_outras_receitas_op']);
				$info .= "VAL_OUTRAS_RECEITAS_OP||{$Post->val_outras_receitas_op};;";
				$Post->lucro_bruto = $funcoes->sanearValor($_POST['lucro_bruto']);
				$info .= "LUCRO_BRUTO||{$Post->lucro_bruto};;";
				$Post->val_custo_operacional = $funcoes->sanearValor($_POST['val_custo_operacional']);
				$info .= "VAL_CUSTO_OPERACIONAL||{$Post->val_custo_operacional};;";
				$Post->val_outros_custos = $funcoes->sanearValor($_POST['val_outros_custos']);
				$info .= "VAL_OUTROS_CUSTOS||{$Post->val_outros_custos};;";
				$Post->val_juros_op_cheque= $funcoes->sanearValor($_POST['val_juros_op_cheque']);
				$info .= "VAL_JUROS_OP_CHEQUE||{$Post->val_juros_op_cheque};;";
				$Post->val_frete = $funcoes->sanearValor($_POST['val_frete']);
				$info .= "VAL_FRETE||{$Post->val_frete};;";
				$Post->lucro_liquido = $funcoes->sanearValor($_POST['lucro_liquido']);
				$info .= "LUCRO_LIQUIDO||{$Post->lucro_liquido};;";
				$Post->perc_lucro = $funcoes->sanearValor($_POST['perc_lucro']);
				$info .= "PERC_LUCRO||{$Post->perc_lucro};;";
				$Post->desconto_comissao = $funcoes->sanearValor($_POST['desconto_comissao']);
				$info .= "DESCONTO_COMISSAO||{$Post->desconto_comissao};;";
				$Post->base_calculo = $funcoes->sanearValor($_POST['base_calculo']);
				$info .= "BASE_CALCULO||{$Post->base_calculo};;";
				$Post->perc_comissao = $funcoes->sanearValor($_POST['perc_comissao']);
				$info .= "PERC_COMISSAO||{$Post->perc_comissao};;";
				$Post->comissao = $funcoes->sanearValor($_POST['comissao']);
				$info .= "COMISSAO||{$Post->comissao};;";
				
				$val_pag = $_POST['valor_pagamento'];
				foreach ($_POST['des_pagamento'] as $key => $r) {
					$Post->des_pagamento .=  ($r != NULL || $val_pag{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_pag{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_pag{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
				}
				$info .= "DES_PAGAMENTO||{$Post->des_pagamento};;";
				
				$val_fre = $_POST['valor_frete'];
				foreach ($_POST['des_frete'] as $key => $r) {
					$Post->des_frete.=  ($r != NULL || $val_fre{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_fre{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_fre{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
				}
				$info .= "DES_FRETE||{$Post->des_frete};;";
				
				$val_out = $_POST['valor_outros_custos'];
				foreach ($_POST['des_outros_custos'] as $key => $r) {
					$Post->des_outros_custos .=  ($r != NULL || $val_out{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_out{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_out{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
				}
				$info .= "DES_OUTROS_CUSTOS||{$Post->des_outros_custos};;";
				
				$val_imp = $_POST['valor_implemento'];
				foreach ($_POST['des_implemento'] as $key => $r) {
					$Post->des_implemento .=  ($r != NULL || $val_imp{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_imp{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_imp{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
				}
				$info .= "DES_IMPLEMENTO||{$Post->des_implemento};;";
				
				$val_vei = $_POST['valor_veiculo_usado'];
				foreach ($_POST['des_veiculo_usado'] as $key => $r) {
					$Post->des_veiculo_usado .=  ($r != NULL || $val_vei{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_vei{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "MARCA: ".str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 43, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_vei{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
				}
				$info .= "DES_VEICULO_USADO||{$Post->des_veiculo_usado};;";
				
				$val_bo = $_POST['valor_bonus'];
				foreach ($_POST['des_bonus'] as $key => $r) {
					$Post->des_bonus .=  ($r != NULL || $val_bo{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_bo{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_bo{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
				}
				$info .= "DES_BONUS||{$Post->des_bonus};;";
				
				$Post->des_vendedor .= "VENDEDOR: {$Post->vendedor_nome}\r\n"."GERENTE: ".$gerente." CPF: ".$gerente_cpf;
				$info .= "DES_VENDEDOR||{$Post->des_vendedor};;";
				
				$Post->obs1 = strtoupper(trim($_POST['obs1']));
				$info .= "OBS1||{$Post->obs1};;";
				$Post->obs2 = strtoupper(trim($_POST['obs2']));
				$info .= "OBS2||{$Post->obs2};;";
				$Post->obs3 = strtoupper(trim($_POST['obs3']));
				$info .= "OBS3||{$Post->obs3};;";
			}
			$Post->dta_inclusao = date("d/m/Y H:i:s");
			$info .= "DTA_INCLUSAO||{$Post->dta_inclusao};;";
			$Post->situacao = 0;
			$info .= "SITUACAO||{$Post->situacao};;";
			$apiProposta = new apiProposta();
			$sql[$i] = $apiProposta->addProposta($Post);
			$i = $i+1;
			$log = new Log();
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "I";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico = substr($info,0,-2);
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiProposta->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'sav/proposta/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'sav/proposta/index/sucesso');
				}
			}else{
				$this->rollback = new Proposta('POST');
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		
		}
		
		$this->view();
	}
	
	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Altera��o de Proposta";
		$exp = explode(",", $this->getParams(0));
		$proposta = new Proposta();
		$proposta->proposta = $this->proposta = $exp[0];
		$proposta->empresa = $this->empresa = $exp[1];
		$apiProposta = new apiProposta();
		$this->dados = array('proposta' => $apiProposta->getProposta($proposta));
		if (!isset($this->dados['proposta'])){
			header('location:' .APP_ROOT. 'sav/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->des_pagamento = explode("\r\n", trim($this->dados['proposta']->DES_PAGAMENTO));
		$this->des_frete = explode("\r\n", trim($this->dados['proposta']->DES_FRETE));
		$this->des_outros_custos = explode("\r\n", trim($this->dados['proposta']->DES_OUTROS_CUSTOS));
		$this->des_implemento = explode("\r\n", trim($this->dados['proposta']->DES_IMPLEMENTO));
		$this->des_veiculo_usado = explode("\r\n", trim($this->dados['proposta']->DES_VEICULO_USADO));
		$this->des_bonus = explode("\r\n", trim($this->dados['proposta']->DES_BONUS));
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$apiEmpresa = new apiEmpresa();
			$capa = $apiEmpresa->filtroEmpresa("1","empresa",$_SESSION['empresa_sessao']);
			$funcoes = new Funcoes();
			if ($_POST['submeter'] == "imprimir"){
				if ($this->dados['proposta']->TIPO_VENDA == "N"){
					$pdf = new FPDF();
					$pdf->AddPage();
					$pdf->SetLineWidth(0.4);
					$pdf->Rect(4, 10, 202, 270, 'D');
					$pdf->SetMargins(4, 4, 4);
					//Cabe�alho
					$pdf->Image(APP_ROOT."content/geral/img/monalog.png",15,11,15,14);
					$pdf->Image(APP_ROOT."content/geral/img/logovw.png",30,8,26,20);
					$pdf->Ln(2);
					$pdf->SetFont('arial','B',15);
					$pdf->Cell(185,9,"{$capa[0]->DESCRICAO}. N�: {$this->dados['proposta']->PROPOSTA}",0,1,'C');
					$pdf->Cell(185,1,"DN {$capa[0]->DN} - {$capa[0]->CIDADE} - {$capa[0]->UF}",0,0,'C');
					$pdf->Image(APP_ROOT."content/geral/img/logoman.png",175,11,15,14);
					$pdf->Ln(6);
					$pdf->Cell(0,0,"","B",0,'C');
					$pdf->Ln(0);
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(185,4,"PLANILHA DE RENTABILIDADE - VENDA ESTOQUE",0,0,'C');
					$pdf->Ln(4);
					$pdf->Cell(0,0,"","B",0,'C');
					$pdf->Ln(0);
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(15,4,"CLIENTE:",1,0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(84,4,"{$this->dados['proposta']->CLIENTE_NOME}",1,0,'C');
					$pdf->Cell(5,4,"",0,0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(20,4,"NF F�BRICA:",1,0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(78,4,"{$this->dados['proposta']->NF_ENTRADA}",1,1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(15,4,"MODELO",1,0,'L');
					$pdf->Cell(14,4,"CHASSI:",1,0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(35,4,"{$this->dados['proposta']->MODELO}",1,0,'C');
					$pdf->Cell(35,4,"{$this->dados['proposta']->CHASSI}",1,0,'C');
					$pdf->Cell(5,4,"",0,0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"OBSERVA��ES",1,1,'C');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"VALOR VENDA:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->VAL_VENDA), 2, ",", ".")."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"VALOR EMISS�O NF:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->VAL_EMISSAO_NF), 2, ",", ".")."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"OUTRAS RECEITAS OPERACIONAIS:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".($this->dados['proposta']->VAL_OUTRAS_RECEITAS_OP > 0) ? number_format(str_replace(",", ".", $this->dados['proposta']->VAL_OUTRAS_RECEITAS_OP), 2, ",", ".") : "-    "."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					if ($this->dados['proposta']->PERC_ICMS > 0){
						$pdf->Cell(60,4,"ICMS ".number_format(str_replace(",", ".", $this->dados['proposta']->PERC_ICMS), 2, ",", ".")."% S/VLR.NF:","B",0,'L');
					}else{
						$pdf->Cell(60,4,"ICMS S/VLR.NF: ISENTO","B",0,'L');
					}
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".($this->dados['proposta']->VAL_ICMS > 0) ? number_format(str_replace(",", ".", $this->dados['proposta']->VAL_ICMS), 2, ",", ".") : "-    "."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"CUSTOS OPERACIONAIS:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->VAL_CUSTO_OPERACIONAL), 2, ",", ".")."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"FRETE:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".($this->dados['proposta']->VAL_FRETE > 0) ? number_format(str_replace(",", ".", $this->dados['proposta']->VAL_FRETE), 2, ",", ".") : "-    "."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"OUTROS CUSTOS:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".($this->dados['proposta']->VAL_OUTROS_CUSTOS > 0) ? number_format(str_replace(",", ".", $this->dados['proposta']->VAL_OUTROS_CUSTOS), 2, ",", ".") : "-    "."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"CMV:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->CMV), 2, ",", ".")."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"CUSTO VE�CULO:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->CUSTO_VEICULO), 2, ",", ".")."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"LUCRO BRUTO:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->LUCRO_BRUTO), 2, ",", ".")."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(65,4,"% LUCRO:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->PERC_LUCRO), 2, ",", ".")."%","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->Cell(99,4,"",0,0,'L');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(99,4,"CUSTO DO VE�CULO",0,0,'C');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->Cell(99,4,"","B",0,'L');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"VALOR F�BRICA:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->VAL_FABRICA), 2, ",", ".")."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,($this->dados['proposta']->PERC_CREDITO_ICMS > 0) ? "CREDITO ICMS ".number_format(str_replace(",", ".", $this->dados['proposta']->PERC_CREDITO_ICMS), 2, ",", ".")."%:" : "CREDITO ICMS %:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".($this->dados['proposta']->VAL_CREDITO_ICMS > 0) ? number_format(str_replace(",", ".", $this->dados['proposta']->VAL_CREDITO_ICMS), 2, ",", ".") : "-    "."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"VALOR IMPLEMENTO:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".($this->dados['proposta']->VAL_IMPLEMENTO > 0) ? number_format(str_replace(",", ".", $this->dados['proposta']->VAL_IMPLEMENTO), 2, ",", ".") : "-    "."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4, ($this->dados['proposta']->PERC_ICMS_IMP > 0) ? "CREDITO ICMS IMPLEMENTO ".number_format(str_replace(",", ".", $this->dados['proposta']->PERC_ICMS_IMP), 2, ",", ".")."%:" : "CREDITO ICMS %:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".($this->dados['proposta']->VAL_ICMS_IMP > 0) ? number_format(str_replace(",", ".", $this->dados['proposta']->VAL_ICMS_IMP), 2, ",", ".") : "-    "."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(65,4,"B�NUS F�BRICA %:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(34,4,"".($this->dados['proposta']->PERC_BONUS_FAB > 0) ? number_format(str_replace(",", ".", $this->dados['proposta']->PERC_BONUS_FAB), 2, ",", ".")."%" : "-    "."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"CR�DITO B�NUS:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".($this->dados['proposta']->CREDITO_BONUS > 0) ? number_format(str_replace(",", ".", $this->dados['proposta']->CREDITO_BONUS), 2, ",", ".") : "-    "."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(65,4,"B�NUS F�BRICA:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(34,4,"".($this->dados['proposta']->BONUS_FABRICA > 0) ? number_format(str_replace(",", ".", $this->dados['proposta']->BONUS_FABRICA), 2, ",", ".") : "-    "."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"CUSTO VE�CULO:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->CUSTO_VEICULO), 2, ",", ".")."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->Cell(99,4,"",0,0,'L');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(99,4,"C�LCULO COMISS�O",0,0,'C');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->Cell(99,4,"","B",0,'L');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"VENDA COMISS�O:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->VAL_VENDA), 2, ",", ".")."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"DESCONTOS:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".($this->dados['proposta']->DESCONTO_COMISSAO > 0) ? number_format(str_replace(",", ".", $this->dados['proposta']->DESCONTO_COMISSAO), 2, ",", ".") : "-    "."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"BASE DE C�LCULO:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->BASE_CALCULO), 2, ",", ".")."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(65,4,"PERCENTUAL:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->PERC_COMISSAO), 2, ",", ".")."%","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');;
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"VALOR EMISS�O NF:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->COMISSAO), 2, ",", ".")."","B",0,'R');
					$pdf->Cell(4,4,"","L",0,'L');
					$pdf->Cell(1,4,"","R",0,'L');
					$pdf->Cell(98,4,"","B",1,'L');
					$pdf->Cell(190,4,"",0,1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->MultiCell(202,4,"Declaro para os devidos fins que atesto a retid�o dos dados constantes nesta planilha, os quais foram inseridos de acordo com a negocia��o por mim realizada junto ao cliente",0,'L',false);
					$pdf->Cell(190,4,"",0,1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(99,4,"CIENTE E DE ACORDO:",1,0,'C');
					$pdf->Cell(5,4,"",0,0,'L');
					$pdf->Cell(51,4,"VISTO",1,0,'C');
					$pdf->Cell(47,4,"VISTO",1,1,'C');
					$pdf->Cell(99,4,"","R",0,'L');
					$pdf->Cell(5,4,"","R",0,'L');
					$pdf->Cell(51,4,"","R",0,'L');
					$pdf->Cell(47,4,"","R",1,'L');
					$pdf->Cell(99,4,"","R",0,'L');
					$pdf->Cell(5,4,"","R",0,'L');
					$pdf->Cell(51,4,"","R",0,'L');
					$pdf->Cell(47,4,"","R",1,'L');
					$pdf->Cell(99,4,"VENDEDOR","B",0,'C');
					$pdf->Cell(4,4,"","L",0,'L');
					$pdf->Cell(1,4,"","R",0,'L');
					$pdf->Cell(51,4,"GERENTE DE VENDAS","B",0,'C');
					$pdf->Cell(1,4,"","L",0,'L');
					$pdf->Cell(-1,4,"","B",0,'L');
					$pdf->Cell(47,4,"DIRETORIA","B",1,'C');
					$pdf->Cell(202,4,"",0,1,'L');
					if ($this->dados['proposta']->OBS1 != ""){
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(10,4,"OBS 1:",0,0,'L');
						$pdf->SetFont('arial','',8);
						$pdf->Cell(192,4,"{$this->dados['proposta']->OBS1}",0,1,'L');
						$pdf->Cell(202,4,"",0,1,'L');
					}
					if ($this->dados['proposta']->OBS2 != ""){
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(10,4,"OBS 2:",0,0,'L');
						$pdf->SetFont('arial','',8);
						$pdf->Cell(192,4,"{$this->dados['proposta']->OBS2}",0,1,'L');
						$pdf->Cell(202,4,"",0,1,'L');
					}
					if ($this->dados['proposta']->OBS3 != ""){
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(10,4,"OBS 3:",0,0,'L');
						$pdf->SetFont('arial','',8);
						$pdf->Cell(192,4,"{$this->dados['proposta']->OBS3}",0,1,'L');
						$pdf->Cell(202,4,"",0,1,'L');
					}
					$pdf->SetXY(108,39);
					if (trim($this->dados['proposta']->DES_PAGAMENTO) != ""){
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(98,4,"PAGAMENTO:","L",1,'L');
						$pdf->Cell(104,0,"",0,0,'L');
						$pdf->SetFont('arial','',7);
						$pdf->MultiCell(98,4,$this->dados['proposta']->DES_PAGAMENTO,0,'L',false);
						$pdf->Cell(104,0,"",0,0,'L');
						$pdf->Cell(98,0,"","B",1,'L');
					}else{
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(98,4,"PAGAMENTO:","B",1,'L');
					}
					if (trim($this->dados['proposta']->DES_FRETE) != ""){
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(98,4,"FRETE:","L",1,'L');
						$pdf->SetFont('arial','',7);
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->MultiCell(98,4,$this->dados['proposta']->DES_FRETE,0,'L',false);
						$pdf->Cell(104,0,"",0,0,'L');
						$pdf->Cell(98,0,"","B",1,'L');
					}else{
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->Cell(98,4,"FRETE:","B",1,'L');
					}
					if (trim($this->dados['proposta']->DES_OUTROS_CUSTOS) != ""){
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(98,4,"OUTROS CUSTOS:","L",1,'L');
						$pdf->SetFont('arial','',7);
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->MultiCell(98,4,$this->dados['proposta']->DES_OUTROS_CUSTOS,0,'L',false);
						$pdf->Cell(104,0,"",0,0,'L');
						$pdf->Cell(98,0,"","B",1,'L');
					}else{
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->Cell(98,4,"OUTROS CUSTOS:","B",1,'L');
					}
					if (trim($this->dados['proposta']->DES_IMPLEMENTO) != ""){
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(98,4,"IMPLEMENTO:","L",1,'L');
						$pdf->SetFont('arial','',7);
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->MultiCell(98,4,$this->dados['proposta']->DES_IMPLEMENTO,0,'L',false);
						$pdf->Cell(104,0,"",0,0,'L');
						$pdf->Cell(98,0,"","B",1,'L');
					}else{
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->Cell(98,4,"IMPLEMENTO:","B",1,'L');
					}
					if (trim($this->dados['proposta']->DES_VEICULO_USADO) != ""){
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(98,4,"VE�CULO USADO:","L",1,'L');
						$pdf->SetFont('arial','',7);
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->MultiCell(98,4,$this->dados['proposta']->DES_VEICULO_USADO,0,'L',false);
						$pdf->Cell(104,0,"",0,0,'L');
						$pdf->Cell(98,0,"","B",1,'L');
					}else{
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->Cell(98,4,"VE�CULO USADO:","B",1,'L');
					}
					if (trim($this->dados['proposta']->DES_BONUS) != ""){
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(98,4,"B�NUS:","L",1,'L');
						$pdf->SetFont('arial','',7);
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->MultiCell(98,4,$this->dados['proposta']->DES_BONUS,0,'L',false);
						$pdf->Cell(104,0,"",0,0,'L');
						$pdf->Cell(98,0,"","B",1,'L');
					}else{
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->Cell(98,4,"B�NUS:","B",1,'L');
					}
					$pdf->Cell(104,4,"",0,0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"VENDEDOR:","L",1,'L');
					$pdf->SetFont('arial','',7);
					$pdf->Cell(104,4,"",0,0,'L');
					$pdf->MultiCell(98,4,$this->dados['proposta']->DES_VENDEDOR,0,'L',false);
					$pdf->Cell(104,0,"",0,0,'L');
					$pdf->Cell(98,0,"","B",1,'L');
					
					$pdf->Output("Proposta-{$this->dados['proposta']->PROPOSTA}-".date("d-m-Y").".pdf","D");
					
				}elseif ($this->dados['proposta']->TIPO_VENDA == "U"){
					$pdf = new FPDF();
					$pdf->AddPage();
					$pdf->SetLineWidth(0.4);
					$pdf->Rect(4, 10, 202, 270, 'D');
					$pdf->SetMargins(4, 4, 4);
					//Cabe�alho
					$pdf->Image(APP_ROOT."content/geral/img/monalog.png",15,11,15,14);
					$pdf->Image(APP_ROOT."content/geral/img/logovw.png",30,8,26,20);
					$pdf->Ln(2);
					$pdf->SetFont('arial','B',15);
					$pdf->Cell(185,9,"{$capa[0]->DESCRICAO}. N�: {$this->dados['proposta']->PROPOSTA}",0,1,'C');
					$pdf->Cell(185,1,"DN {$capa[0]->DN} - {$capa[0]->CIDADE} - {$capa[0]->UF}",0,0,'C');
					$pdf->Image(APP_ROOT."content/geral/img/logoman.png",175,11,15,14);
					$pdf->Ln(6);
					$pdf->Cell(0,0,"","B",0,'C');
					$pdf->Ln(0);
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(185,4,"PLANILHA DE RENTABILIDADE - SEMI-NOVOS",0,0,'C');
					$pdf->Ln(4);
					$pdf->Cell(0,0,"","B",0,'C');
					$pdf->Ln(0);
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(15,4,"CLIENTE:",1,0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(84,4,"{$this->dados['proposta']->CLIENTE_NOME}",1,1,'C');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(15,4,"MODELO",1,0,'L');
					$pdf->Cell(14,4,"CHASSI:",1,0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(35,4,"{$this->dados['proposta']->MODELO}",1,0,'C');
					$pdf->Cell(35,4,"{$this->dados['proposta']->CHASSI}",1,0,'C');
					$pdf->Cell(5,4,"",0,0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"OBSERVA��ES",1,1,'C');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"VALOR VENDA:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->VAL_VENDA), 2, ",", ".")."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"VALOR EMISS�O NF:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->VAL_EMISSAO_NF), 2, ",", ".")."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"OUTRAS RECEITAS OPERACIONAIS:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".($this->dados['proposta']->VAL_OUTRAS_RECEITAS_OP > 0) ? number_format(str_replace(",", ".", $this->dados['proposta']->VAL_OUTRAS_RECEITAS_OP), 2, ",", ".") : "-    "."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					if ($this->dados['proposta']->PERC_ICMS > 0){
						$pdf->Cell(60,4,"ICMS ".number_format(str_replace(",", ".", $this->dados['proposta']->PERC_ICMS), 2, ",", ".")."% S/VLR.NF:","B",0,'L');
					}else{
						$pdf->Cell(60,4,"ICMS S/VLR.NF: ISENTO","B",0,'L');
					}
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".($this->dados['proposta']->VAL_ICMS > 0) ? number_format(str_replace(",", ".", $this->dados['proposta']->VAL_ICMS), 2, ",", ".") : "-    "."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"PIS E COFINS 3,65% S/ DIF.COMPRA/VD:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".($this->dados['proposta']->VAL_PIS_COFINS_COMPRA > 0) ? number_format(str_replace(",", ".", $this->dados['proposta']->VAL_PIS_COFINS_COMPRA), 2, ",", ".") : "-    "."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"FRETE:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".($this->dados['proposta']->VAL_FRETE > 0) ? number_format(str_replace(",", ".", $this->dados['proposta']->VAL_FRETE), 2, ",", ".") : "-    "."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"CUSTO VE�CULO:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->CUSTO_VEICULO), 2, ",", ".")."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"OUTROS CUSTOS:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".($this->dados['proposta']->VAL_OUTROS_CUSTOS > 0) ? number_format(str_replace(",", ".", $this->dados['proposta']->VAL_OUTROS_CUSTOS), 2, ",", ".") : "-    "."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"CMV:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->CMV), 2, ",", ".")."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"LUCRO BRUTO:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->LUCRO_BRUTO), 2, ",", ".")."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"% LUCRO:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->PERC_LUCRO), 2, ",", ".")."%","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->Cell(99,4,"",0,0,'L');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->Cell(99,4,"",0,0,'L');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(99,4,"C�LCULO COMISS�O",0,0,'C');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->Cell(99,4,"",0,0,'L');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->Cell(99,4,"","B",0,'L');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"VENDA COMISS�O:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->VAL_VENDA), 2, ",", ".")."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"DESCONTOS:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".($this->dados['proposta']->DESCONTO_COMISSAO > 0) ? number_format(str_replace(",", ".", $this->dados['proposta']->DESCONTO_COMISSAO), 2, ",", ".") : "-    "."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"BASE DE C�LCULO:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->BASE_CALCULO), 2, ",", ".")."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(65,4,"PERCENTUAL:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->PERC_COMISSAO), 2, ",", ".")."%","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');;
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"VALOR EMISS�O NF:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->COMISSAO), 2, ",", ".")."","B",0,'R');
					$pdf->Cell(4,4,"","L",0,'L');
					$pdf->Cell(1,4,"","R",0,'L');
					$pdf->Cell(98,4,"","B",1,'L');
					$pdf->Cell(190,4,"",0,1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->MultiCell(202,4,"Declaro para os devidos fins que atesto a retid�o dos dados constantes nesta planilha, os quais foram inseridos de acordo com a negocia��o por mim realizada junto ao cliente",0,'L',false);
					$pdf->Cell(190,4,"",0,1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(99,4,"CIENTE E DE ACORDO:",1,0,'C');
					$pdf->Cell(5,4,"",0,0,'L');
					$pdf->Cell(51,4,"VISTO",1,0,'C');
					$pdf->Cell(47,4,"VISTO",1,1,'C');
					$pdf->Cell(99,4,"","R",0,'L');
					$pdf->Cell(5,4,"","R",0,'L');
					$pdf->Cell(51,4,"","R",0,'L');
					$pdf->Cell(47,4,"","R",1,'L');
					$pdf->Cell(99,4,"","R",0,'L');
					$pdf->Cell(5,4,"","R",0,'L');
					$pdf->Cell(51,4,"","R",0,'L');
					$pdf->Cell(47,4,"","R",1,'L');
					$pdf->Cell(99,4,"VENDEDOR","B",0,'C');
					$pdf->Cell(4,4,"","L",0,'L');
					$pdf->Cell(1,4,"","R",0,'L');
					$pdf->Cell(51,4,"GERENTE DE VENDAS","B",0,'C');
					$pdf->Cell(1,4,"","L",0,'L');
					$pdf->Cell(-1,4,"","B",0,'L');
					$pdf->Cell(47,4,"DIRETORIA","B",1,'C');
					$pdf->Cell(202,4,"",0,1,'L');
					if ($this->dados['proposta']->OBS1 != ""){
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(10,4,"OBS 1:",0,0,'L');
						$pdf->SetFont('arial','',8);
						$pdf->Cell(192,4,"{$this->dados['proposta']->OBS1}",0,1,'L');
						$pdf->Cell(202,4,"",0,1,'L');
					}
					if ($this->dados['proposta']->OBS2 != ""){
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(10,4,"OBS 2:",0,0,'L');
						$pdf->SetFont('arial','',8);
						$pdf->Cell(192,4,"{$this->dados['proposta']->OBS2}",0,1,'L');
						$pdf->Cell(202,4,"",0,1,'L');
					}
					if ($this->dados['proposta']->OBS3 != ""){
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(10,4,"OBS 3:",0,0,'L');
						$pdf->SetFont('arial','',8);
						$pdf->Cell(192,4,"{$this->dados['proposta']->OBS3}",0,1,'L');
						$pdf->Cell(202,4,"",0,1,'L');
					}
					$pdf->SetXY(108,39);
					if (trim($this->dados['proposta']->DES_PAGAMENTO) != ""){
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(98,4,"PAGAMENTO:","L",1,'L');
						$pdf->Cell(104,0,"",0,0,'L');
						$pdf->SetFont('arial','',7);
						$pdf->MultiCell(98,4,$this->dados['proposta']->DES_PAGAMENTO,0,'L',false);
						$pdf->Cell(104,0,"",0,0,'L');
						$pdf->Cell(98,0,"","B",1,'L');
					}else{
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(98,4,"PAGAMENTO:","B",1,'L');
					}
					if (trim($this->dados['proposta']->DES_FRETE) != ""){
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(98,4,"FRETE:","L",1,'L');
						$pdf->SetFont('arial','',7);
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->MultiCell(98,4,$this->dados['proposta']->DES_FRETE,0,'L',false);
						$pdf->Cell(104,0,"",0,0,'L');
						$pdf->Cell(98,0,"","B",1,'L');
					}else{
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->Cell(98,4,"FRETE:","B",1,'L');
					}
					if (trim($this->dados['proposta']->DES_OUTROS_CUSTOS) != ""){
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(98,4,"OUTROS CUSTOS:","L",1,'L');
						$pdf->SetFont('arial','',7);
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->MultiCell(98,4,$this->dados['proposta']->DES_OUTROS_CUSTOS,0,'L',false);
						$pdf->Cell(104,0,"",0,0,'L');
						$pdf->Cell(98,0,"","B",1,'L');
					}else{
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->Cell(98,4,"OUTROS CUSTOS:","B",1,'L');
					}
					if (trim($this->dados['proposta']->DES_BONUS) != ""){
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(98,4,"B�NUS:","L",1,'L');
						$pdf->SetFont('arial','',7);
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->MultiCell(98,4,$this->dados['proposta']->DES_BONUS,0,'L',false);
						$pdf->Cell(104,0,"",0,0,'L');
						$pdf->Cell(98,0,"","B",1,'L');
					}else{
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->Cell(98,4,"B�NUS:","B",1,'L');
					}
					$pdf->Cell(104,4,"",0,0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"VENDEDOR:","L",1,'L');
					$pdf->SetFont('arial','',7);
					$pdf->Cell(104,4,"",0,0,'L');
					$pdf->MultiCell(98,4,$this->dados['proposta']->DES_VENDEDOR,0,'L',false);
					$pdf->Cell(104,0,"",0,0,'L');
					$pdf->Cell(98,0,"","B",1,'L');
					
					$pdf->Output("Proposta-{$this->dados['proposta']->PROPOSTA}-".date("d-m-Y").".pdf","D");
					
				}elseif ($this->dados['proposta']->TIPO_VENDA == "D"){
					$pdf = new FPDF();
					$pdf->AddPage();
					$pdf->SetLineWidth(0.4);
					$pdf->Rect(4, 10, 202, 270, 'D');
					$pdf->SetMargins(4, 4, 4);
					//Cabe�alho
					$pdf->Image(APP_ROOT."content/geral/img/monalog.png",15,11,15,14);
					$pdf->Image(APP_ROOT."content/geral/img/logovw.png",30,8,26,20);
					$pdf->Ln(2);
					$pdf->SetFont('arial','B',15);
					$pdf->Cell(185,9,"{$capa[0]->DESCRICAO}. N�: {$this->dados['proposta']->PROPOSTA}",0,1,'C');
					$pdf->Cell(185,1,"DN {$capa[0]->DN} - {$capa[0]->CIDADE} - {$capa[0]->UF}",0,0,'C');
					$pdf->Image(APP_ROOT."content/geral/img/logoman.png",175,11,15,14);
					$pdf->Ln(6);
					$pdf->Cell(0,0,"","B",0,'C');
					$pdf->Ln(0);
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(185,4,"PLANILHA DE RENTABILIDADE - VENDA DIRETA",0,0,'C');
					$pdf->Ln(4);
					$pdf->Cell(0,0,"","B",0,'C');
					$pdf->Ln(0);
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(15,4,"CLIENTE:",1,0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(84,4,"{$this->dados['proposta']->CLIENTE_NOME}",1,0,'C');
					$pdf->Cell(5,4,"",0,0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(20,4,"NF F�BRICA:",1,0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(78,4,"{$this->dados['proposta']->NF_DIRETA}",1,1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(15,4,"MODELO",1,0,'L');
					$pdf->Cell(14,4,"CHASSI:",1,0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(35,4,"{$this->dados['proposta']->MODELO}",1,0,'C');
					$pdf->Cell(35,4,"{$this->dados['proposta']->CHASSI}",1,0,'C');
					$pdf->Cell(5,4,"",0,0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"OBSERVA��ES",1,1,'C');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"NOTA FISCAL F�BRICA:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->VAL_NF_FABRICA), 2, ",", ".")."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"VALOR VENDA:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->VAL_VENDA), 2, ",", ".")."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->Cell(65,4,"% COMISS�O DE F�BRICA:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(34,4,"".($this->dados['proposta']->COMISSAO_FABRICA > 0) ? number_format(str_replace(",", ".", $this->dados['proposta']->COMISSAO_FABRICA), 2, ",", ".")."%": "-    "."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"VALOR COMISS�O F�BRICA:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".($this->dados['proposta']->VAL_COMISSAO_FABRICA > 0) ? number_format(str_replace(",", ".", $this->dados['proposta']->VAL_COMISSAO_FABRICA), 2, ",", ".") : "-    "."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"DIFEREN�A VLR VENDA / NF:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".($this->dados['proposta']->VAL_DIF_NFFABRICA_NFVENDA > 0) ? number_format(str_replace(",", ".", $this->dados['proposta']->VAL_DIF_NFFABRICA_NFVENDA), 2, ",", ".") : "-    "."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"OUTRAS RECEITAS OPERACIONAIS:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".($this->dados['proposta']->VAL_OUTRAS_RECEITAS_OP > 0) ? number_format(str_replace(",", ".", $this->dados['proposta']->VAL_OUTRAS_RECEITAS_OP), 2, ",", ".") : "-    "."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"LUCRO BRUTO:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->LUCRO_BRUTO), 2, ",", ".")."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"CUSTOS OPERACIONAIS:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->VAL_CUSTO_OPERACIONAL), 2, ",", ".")."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"OUTROS CUSTOS:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".($this->dados['proposta']->VAL_OUTROS_CUSTOS > 0) ? number_format(str_replace(",", ".", $this->dados['proposta']->VAL_OUTROS_CUSTOS), 2, ",", ".") : "-    "."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"JUROS SOBRE OPERA��O DE CHEQUES:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".($this->dados['proposta']->VAL_JUROS_OP_CHEQUE > 0) ? number_format(str_replace(",", ".", $this->dados['proposta']->VAL_JUROS_OP_CHEQUE), 2, ",", ".") : "-    "."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"VALOR DO FRETE:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".($this->dados['proposta']->VAL_FRETE > 0) ? number_format(str_replace(",", ".", $this->dados['proposta']->VAL_FRETE), 2, ",", ".") : "-    "."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"LUCRO L�QUIDO:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->LUCRO_LIQUIDO), 2, ",", ".")."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(65,4,"% LUCRO:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->PERC_LUCRO), 2, ",", ".")."%","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->Cell(99,4,"",0,0,'L');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(99,4,"C�LCULO COMISS�O",0,0,'C');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->Cell(99,4,"","B",0,'L');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"VENDA COMISS�O:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->VAL_VENDA), 2, ",", ".")."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"DESCONTOS:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".($this->dados['proposta']->DESCONTO_COMISSAO > 0) ? number_format(str_replace(",", ".", $this->dados['proposta']->DESCONTO_COMISSAO), 2, ",", ".") : "-    "."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"BASE DE C�LCULO:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->BASE_CALCULO), 2, ",", ".")."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(65,4,"PERCENTUAL:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(34,4,"".($this->dados['proposta']->PERC_COMISSAO > 0) ? number_format(str_replace(",", ".", $this->dados['proposta']->PERC_COMISSAO), 2, ",", ".")."%" : "M�NIMO GARANTIDO"."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');;
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(60,4,"VALOR EMISS�O NF:","B",0,'L');
					$pdf->SetFont('arial','',8);
					$pdf->Cell(5,4,"R$","B",0,'L');
					$pdf->Cell(34,4,"".number_format(str_replace(",", ".", $this->dados['proposta']->COMISSAO), 2, ",", ".")."","B",0,'R');
					$pdf->Cell(5,4,"","L",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->Cell(99,4,"",0,0,'L');
					$pdf->Cell(5,4,"",0,0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(99,4,'"Declaro para os devidos fins que atesto a retid�o dos dados constantes',0,0,'C');
					$pdf->Cell(5,4,"","R",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(99,4,'nesta planilha, os quais foram inseridos de acordo com a negocia��o',0,0,'C');
					$pdf->Cell(5,4,"","R",0,'L');
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(99,4,'realizada por mim junto ao cliente"',0,0,'C');
					$pdf->Cell(5,4,"",0,0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"","L",1,'L');
					$pdf->Cell(99,4,"",0,0,'L');
					$pdf->Cell(4,4,"",0,0,'L');
					$pdf->Cell(1,4,"","R",0,'L');
					$pdf->Cell(98,4,"","B",1,'L');
					$pdf->Cell(190,4,"",0,1,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(99,4,"CIENTE E DE ACORDO:",1,0,'C');
					$pdf->Cell(5,4,"",0,0,'L');
					$pdf->Cell(51,4,"VISTO",1,0,'C');
					$pdf->Cell(47,4,"VISTO",1,1,'C');
					$pdf->Cell(99,4,"","R",0,'L');
					$pdf->Cell(5,4,"","R",0,'L');
					$pdf->Cell(51,4,"","R",0,'L');
					$pdf->Cell(47,4,"","R",1,'L');
					$pdf->Cell(99,4,"","R",0,'L');
					$pdf->Cell(5,4,"","R",0,'L');
					$pdf->Cell(51,4,"","R",0,'L');
					$pdf->Cell(47,4,"","R",1,'L');
					$pdf->Cell(99,4,"VENDEDOR","B",0,'C');
					$pdf->Cell(4,4,"","L",0,'L');
					$pdf->Cell(1,4,"","R",0,'L');
					$pdf->Cell(51,4,"GERENTE DE VENDAS","B",0,'C');
					$pdf->Cell(1,4,"","L",0,'L');
					$pdf->Cell(-1,4,"","B",0,'L');
					$pdf->Cell(47,4,"DIRETORIA","B",1,'C');
					$pdf->Cell(202,4,"",0,1,'L');
					if ($this->dados['proposta']->OBS1 != ""){
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(10,4,"OBS 1:",0,0,'L');
						$pdf->SetFont('arial','',8);
						$pdf->Cell(192,4,"{$this->dados['proposta']->OBS1}",0,1,'L');
						$pdf->Cell(202,4,"",0,1,'L');
					}
					if ($this->dados['proposta']->OBS2 != ""){
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(10,4,"OBS 2:",0,0,'L');
						$pdf->SetFont('arial','',8);
						$pdf->Cell(192,4,"{$this->dados['proposta']->OBS2}",0,1,'L');
						$pdf->Cell(202,4,"",0,1,'L');
					}
					if ($this->dados['proposta']->OBS3 != ""){
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(10,4,"OBS 3:",0,0,'L');
						$pdf->SetFont('arial','',8);
						$pdf->Cell(192,4,"{$this->dados['proposta']->OBS3}",0,1,'L');
						$pdf->Cell(202,4,"",0,1,'L');
					}
					$pdf->SetXY(108,39);
					if (trim($this->dados['proposta']->DES_PAGAMENTO) != ""){
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(98,4,"PAGAMENTO:","L",1,'L');
						$pdf->Cell(104,0,"",0,0,'L');
						$pdf->SetFont('arial','',7);
						$pdf->MultiCell(98,4, $this->dados['proposta']->DES_PAGAMENTO, 0,'L',false);
						$pdf->Cell(104,0,"",0,0,'L');
						$pdf->Cell(98,0,"","B",1,'L');
					}else{
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(98,4,"PAGAMENTO:","B",1,'L');
					}
					if (trim($this->dados['proposta']->DES_FRETE) != ""){
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(98,4,"FRETE:","L",1,'L');
						$pdf->SetFont('arial','',7);
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->MultiCell(98,4,$this->dados['proposta']->DES_FRETE,0,'L',false);
						$pdf->Cell(104,0,"",0,0,'L');
						$pdf->Cell(98,0,"","B",1,'L');
					}else{
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->Cell(98,4,"FRETE:","B",1,'L');
					}
					if (trim($this->dados['proposta']->DES_OUTROS_CUSTOS) != ""){
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(98,4,"OUTROS CUSTOS:","L",1,'L');
						$pdf->SetFont('arial','',7);
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->MultiCell(98,4,$this->dados['proposta']->DES_OUTROS_CUSTOS,0,'L',false);
						$pdf->Cell(104,0,"",0,0,'L');
						$pdf->Cell(98,0,"","B",1,'L');
					}else{
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->Cell(98,4,"OUTROS CUSTOS:","B",1,'L');
					}
					if (trim($this->dados['proposta']->DES_IMPLEMENTO) != ""){
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(98,4,"IMPLEMENTO:","L",1,'L');
						$pdf->SetFont('arial','',7);
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->MultiCell(98,4,$this->dados['proposta']->DES_IMPLEMENTO,0,'L',false);
						$pdf->Cell(104,0,"",0,0,'L');
						$pdf->Cell(98,0,"","B",1,'L');
					}else{
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->Cell(98,4,"IMPLEMENTO:","B",1,'L');
					}
					if (trim($this->dados['proposta']->DES_VEICULO_USADO) != ""){
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(98,4,"VE�CULO USADO:","L",1,'L');
						$pdf->SetFont('arial','',7);
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->MultiCell(98,4,$this->dados['proposta']->DES_VEICULO_USADO,0,'L',false);
						$pdf->Cell(104,0,"",0,0,'L');
						$pdf->Cell(98,0,"","B",1,'L');
					}else{
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->Cell(98,4,"VE�CULO USADO:","B",1,'L');
					}
					if (trim($this->dados['proposta']->DES_BONUS) != ""){
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(98,4,"B�NUS:","L",1,'L');
						$pdf->SetFont('arial','',7);
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->MultiCell(98,4,$this->dados['proposta']->DES_BONUS,0,'L',false);
						$pdf->Cell(104,0,"",0,0,'L');
						$pdf->Cell(98,0,"","B",1,'L');
					}else{
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(104,4,"",0,0,'L');
						$pdf->Cell(98,4,"B�NUS:","B",1,'L');
					}
					$pdf->Cell(104,4,"",0,0,'L');
					$pdf->SetFont('arial','B',8);
					$pdf->Cell(98,4,"VENDEDOR:","L",1,'L');
					$pdf->SetFont('arial','',7);
					$pdf->Cell(104,4,"",0,0,'L');
					$pdf->MultiCell(98,4,$this->dados['proposta']->DES_VENDEDOR,0,'L',false);
					$pdf->Cell(104,0,"",0,0,'L');
					$pdf->Cell(98,0,"","B",1,'L');
					
					$pdf->Output("Proposta-{$this->dados['proposta']->PROPOSTA}-".date("d-m-Y").".pdf","D");
				}
			}else{
				if(($this->dados['proposta']->SITUACAO != 7) && ($this->dados['proposta']->SITUACAO != 9)){
					$anterior = "";
					$atual = "::";
					$Post = new Proposta();
					if ($this->dados['proposta']->PROPOSTA_APOLLO != $_POST['proposta_apollo']){
						$rs = $apiProposta->filtroProposta("tudo", "1", $_SESSION['empresa_sessao'],"proposta_apollo",$_POST['proposta_apollo']);
						if ((is_array($rs) ? count($rs) : 0) > 0){
							$this->Alert = "Essa proposta {$_POST['proposta_apollo']} do apollo j� est� vinculada na proposta {$rs[0]->PROPOSTA} do sistema";
						}else{
							$Post->proposta_apollo = $_POST['proposta_apollo'];
							$anterior .= "PROPOSTA_APOLLO||{$this->dados['proposta']->PROPOSTA_APOLLO};;";
							$atual .= "PROPOSTA_APOLLO||{$_POST['proposta_apollo']};;";
							$apiApollo = new apiApollo();
							$apollo = $apiApollo->getPropostaApollo($capa[0]->EMPRESA_APOLLO, $capa[0]->REVENDA_APOLLO, $Post->proposta_apollo);
							$apiUsuario = new apiUsuario();
							$usuario = $apiUsuario->filtroUsuario("1", "3", "u.cpf", str_pad($apollo->CPF_VENDEDOR, 11, "0", STR_PAD_LEFT));
							if (isset($usuario[0]->USUARIO)){
								if ($this->dados['proposta']->VENDEDOR != $usuario[0]->USUARIO){
									$Post->vendedor = $usuario[0]->USUARIO;
									$anterior .= "VENDEDOR||{$this->dados['proposta']->VENDEDOR};;";
									$atual .= "VENDEDOR||{$Post->vendedor};;";
								}
							}
							if ($this->dados['proposta']->VENDEDOR_NOME != $apollo->NOME_VENDEDOR){
								$Post->vendedor_nome = $apollo->NOME_VENDEDOR;
								$anterior .= "VENDEDOR_NOME||{$this->dados['proposta']->VENDEDOR_NOME};;";
								$atual .= "VENDEDOR||{$Post->vendedor};;";
								$Post->des_vendedor = "VENDEDOR: ".$Post->vendedor_nome." CPF: ".$funcoes->mask(str_pad($apollo->CPF_VENDEDOR, 11, "0", STR_PAD_LEFT),"###.###.###-##")."\r\n"."GERENTE: ".strtoupper($this->dados['proposta']->NOME_GERENTE)." CPF: ".$funcoes->mask($this->dados['proposta']->CPF_GERENTE,"###.###.###-##");
								$anterior .= "DES_VENDEDOR||{$this->dados['proposta']->DES_VENDEDOR};;";
								$atual .= "DES_VENDEDOR||{$Post->des_vendedor};;";
							}
							if ($this->dados['proposta']->CLIENTE != $apollo->CLIENTE){
								$Post->cliente = $apollo->CLIENTE;
								$anterior .= "CLIENTE||{$this->dados['proposta']->CLENTE};;";
								$atual .= "CLIENTE||{$Post->cliente};;";
							}
							if ($this->dados['proposta']->CLIENTE_NOME != $apollo->NOME){
								$Post->cliente_nome = $apollo->NOME;
								$anterior .= "CLIENTE_NOME||{$this->dados['proposta']->CLENTE_NOME};;";
								$atual .= "CLIENTE_NOME||{$Post->cliente_nome};;";
							}
							if ($this->dados['proposta']->NF_ENTRADA != $apollo->NF_ENTRADA){
								$Post->nf_entrada = $apollo->NF_ENTRADA;
								$anterior .= "NF_ENTRADA||{$this->dados['proposta']->NF_ENTRADA};;";
								$atual .= "NF_ENTRADA||{$Post->nf_entrada};;";
							}
							if ($this->dados['proposta']->NF_SAIDA != $apollo->NF_SAIDA){
								$Post->nf_saida = $apollo->NF_SAIDA;
								$anterior .= "NF_SAIDA||{$this->dados['proposta']->NF_SAIDA};;";
								$atual .= "NF_SAIDA||{$Post->nf_saida};;";
							}
							if ($this->dados['proposta']->NF_DIRETA != $apollo->NF_DIRETA){
								$Post->nf_direta = $apollo->NF_DIRETA;
								$anterior .= "NF_DIRETA||{$this->dados['proposta']->NF_DIRETA};;";
								$atual .= "NF_DIRETA||{$Post->nf_direta};;";
							}
							if (($apollo->TIPO_RENAVAM != NULL) && (($apollo->TIPO_RENAVAM == 8) || ($apollo->TIPO_RENAVAM == 14))){
								if ($this->dados['proposta']->TIPO_RENAVAM != $apollo->TIPO_RENAVAM){
									$Post->tipo_renavam = $apollo->TIPO_RENAVAM;
									$anterior .= "TIPO_RENAVAM||{$this->dados['proposta']->TIPO_RENAVAM};;";
									$atual .= "TIPO_RENAVAM||{$Post->tipo_renavam};;";
								}
							}else{
								if ($this->dados['proposta']->TIPO_RENAVAM != $_POST['tipo_renavam']){
									$Post->tipo_renavam = $_POST['tipo_renavam'];
									$anterior .= "TIPO_RENAVAM||{$this->dados['proposta']->TIPO_RENAVAM};;";
									$atual .= "TIPO_RENAVAM||{$Post->tipo_renavam};;";
								}
							}
							if ($this->dados['proposta']->CHASSI != $apollo->CHASSI){
								$Post->chassi = $apollo->CHASSI;
								$anterior .= "CHASSI||{$this->dados['proposta']->CHASSI};;";
								$atual .= "CHASSI||{$Post->chassi};;";
							}
							if ($this->dados['proposta']->MODELO != $apollo->DES_MODELO){
								$Post->modelo = $apollo->DES_MODELO;
								$anterior .= "MODELO||{$this->dados['proposta']->MODELO};;";
								$atual .= "MODELO||{$Post->modelo};;";
							}
							$Post->situacao = $apollo->SITUACAO;
							if (($apollo->SITUACAO == 7) || ($apollo->SITUACAO == 9)){
								
								if ($this->dados['proposta']->DTA_CONCLUSAO != $apollo->DTA_VENDA){
									$Post->dta_conclusao = $apollo->DTA_VENDA;
									$anterior .= "DTA_CONCLUSAO||{$this->dados['proposta']->DTA_CONCLUSAO};;";
									$atual .= "DTA_CONCLUSAO||{$Post->dta_conclusao};;";
								}
							}
						}
					}else{
						if ($this->dados['proposta']->TIPO_RENAVAM != $_POST['tipo_renavam']){
							$Post->tipo_renavam = $_POST['tipo_renavam'];
							$anterior .= "TIPO_RENAVAM||{$this->dados['proposta']->TIPO_RENAVAM};;";
							$atual .= "TIPO_RENAVAM||{$Post->tipo_renavam};;";
						}
						if ($this->dados['proposta']->VENDEDOR_NOME != strtoupper($funcoes->retiraAcentos(trim($_POST['vendedor_nome'])))){
							$Post->vendedor_nome = strtoupper($funcoes->retiraAcentos(trim($_POST['vendedor_nome'])));
							$anterior .= "VENDEDOR_NOME||{$this->dados['proposta']->VENDEDOR_NOME};;";
							$atual .= "VENDEDOR_NOME||{$Post->vendedor_nome};;";
							$Post->des_vendedor = "VENDEDOR: ".$Post->vendedor_nome."\r\n"."GERENTE: ".strtoupper($this->dados['proposta']->NOME_GERENTE)." CPF: ".$funcoes->mask($this->dados['proposta']->CPF_GERENTE,"###.###.###-##");
							$anterior .= "DES_VENDEDOR||{$this->dados['proposta']->DES_VENDEDOR};;";
							$atual .= "DES_VENDEDOR||{$Post->des_vendedor};;";
						}
						if ($this->dados['proposta']->CLIENTE_NOME != strtoupper($funcoes->retiraAcentos(trim($_POST['cliente_nome'])))){
							$Post->cliente_nome = strtoupper($funcoes->retiraAcentos(trim($_POST['cliente_nome'])));
							$anterior .= "CLIENTE_NOME||{$this->dados['proposta']->CLIENTE_NOME};;";
							$atual .= "CLIENTE_NOME||{$Post->cliente_nome};;";
						}
						if ($this->dados['proposta']->CHASSI != strtoupper($funcoes->retiraAcentos(trim($_POST['chassi'])))){
							$Post->chassi = strtoupper($funcoes->retiraAcentos(trim($_POST['chassi'])));
							$anterior .= "CHASSI||{$this->dados['proposta']->CHASSI};;";
							$atual .= "CHASSI||{$Post->chassi};;";
						}
						if ($this->dados['proposta']->MODELO != strtoupper($funcoes->retiraAcentos(trim($_POST['modelo'])))){
							$Post->modelo = strtoupper($funcoes->retiraAcentos(trim($_POST['modelo'])));
							$anterior .= "MODELO||{$this->dados['proposta']->MODELO};;";
							$atual .= "MODELO||{$Post->modelo};;";
						}
					}
					if ($this->dados['proposta']->TIPO_VENDA == 'N'){
						if ($this->dados['proposta']->VAL_EMISSAO_NF != $funcoes->sanearValor($_POST['val_emissao_nf'])){
							$Post->val_emissao_nf = $funcoes->sanearValor($_POST['val_emissao_nf']);
							$anterior .= "VAL_EMISSAO_NF||{$this->dados['proposta']->VAL_EMISSAO_NF};;";
							$atual .= "VAL_EMISSAO_NF||{$_POST['val_emissao_nf']};;";
						}
						if ($this->dados['proposta']->VAL_VENDA != $funcoes->sanearValor($_POST['val_venda'])){
							$Post->val_venda = $funcoes->sanearValor($_POST['val_venda']);
							$anterior .= "VAL_VENDA||{$this->dados['proposta']->VAL_VENDA};;";
							$atual .= "VAL_VENDA||{$_POST['val_venda']};;";
						}
						if ($this->dados['proposta']->VAL_OUTRAS_RECEITAS_OP != $funcoes->sanearValor($_POST['val_outras_receitas_op'])){
							$Post->val_outras_receitas_op = $funcoes->sanearValor($_POST['val_outras_receitas_op']);
							$anterior .= "VAL_OUTRAS_RECEITAS_OP||{$this->dados['proposta']->VAL_OUTRAS_RECEITAS_OP};;";
							$atual .= "VAL_OUTRAS_RECEITAS_OP||{$_POST['val_outras_receitas_op']};;";
						}
						if ($this->dados['proposta']->PERC_ICMS != $funcoes->sanearValor($_POST['perc_icms'])){
							$Post->perc_icms = $funcoes->sanearValor($_POST['perc_icms']);
							$anterior .= "PERC_ICMS||{$this->dados['proposta']->PERC_ICMS};;";
							$atual .= "PERC_ICMS||{$_POST['perc_icms']};;";
						}
						if ($this->dados['proposta']->VAL_ICMS != $funcoes->sanearValor($_POST['val_icms'])){
							$Post->val_icms = $funcoes->sanearValor($_POST['val_icms']);
							$anterior .= "VAL_ICMS||{$this->dados['proposta']->VAL_ICMS};;";
							$atual .= "VAL_ICMS||{$_POST['val_icms']};;";
						}
						if ($this->dados['proposta']->VAL_CUSTO_OPERACIONAL != $funcoes->sanearValor($_POST['val_custo_operacional'])){
							$Post->val_custo_operacional = $funcoes->sanearValor($_POST['val_custo_operacional']);
							$anterior .= "VAL_CUSTO_OPERACIONAL||{$this->dados['proposta']->VAL_CUSTO_OPERACIONAL};;";
							$atual .= "VAL_CUSTO_OPERACIONAL||{$_POST['val_custo_operacional']};;";
						}
						if ($this->dados['proposta']->VAL_FRETE != $funcoes->sanearValor($_POST['val_frete'])){
							$Post->val_frete = $funcoes->sanearValor($_POST['val_frete']);
							$anterior .= "VAL_FRETE||{$this->dados['proposta']->VAL_FRETE};;";
							$atual .= "VAL_FRETE||{$_POST['val_frete']};;";
						}
						if ($this->dados['proposta']->VAL_OUTROS_CUSTOS != $funcoes->sanearValor($_POST['val_outros_custos'])){
							$Post->val_outros_custos = $funcoes->sanearValor($_POST['val_outros_custos']);
							$anterior .= "VAL_OUTROS_CUSTOS||{$this->dados['proposta']->VAL_OUTROS_CUSTOS};;";
							$atual .= "VAL_OUTROS_CUSTOS||{$_POST['val_outros_custos']};;";
						}
						if ($this->dados['proposta']->CMV != $funcoes->sanearValor($_POST['cmv'])){
							$Post->cmv = $funcoes->sanearValor($_POST['cmv']);
							$anterior .= "CMV||{$this->dados['proposta']->CMV};;";
							$atual .= "CMV||{$_POST['cmv']};;";	
						}
						if ($this->dados['proposta']->LUCRO_BRUTO != $funcoes->sanearValor($_POST['lucro_bruto'])){
							$Post->lucro_bruto = $funcoes->sanearValor($_POST['lucro_bruto']);
							$anterior .= "LUCRO_BRUTO||{$this->dados['proposta']->LUCRO_BRUTO};;";
							$atual .= "LUCRO_BRUTO||{$_POST['lucro_bruto']};;";
						}
						if ($this->dados['proposta']->PERC_LUCRO != $funcoes->sanearValor($_POST['perc_lucro'])){
							$Post->perc_lucro = $funcoes->sanearValor($_POST['perc_lucro']);
							$anterior .= "PERC_LUCRO||{$this->dados['proposta']->PERC_LUCRO};;";
							$atual .= "PERC_LUCRO||{$_POST['perc_lucro']};;";
						}
						if ($this->dados['proposta']->VAL_FABRICA != $funcoes->sanearValor($_POST['val_fabrica'])){
							$Post->val_fabrica = $funcoes->sanearValor($_POST['val_fabrica']);
							$anterior .= "VAL_FABRICA||{$this->dados['proposta']->VAL_FABRICA};;";
							$atual .= "VAL_FABRICA||{$_POST['val_fabrica']};;";
						}
						if ($this->dados['proposta']->PERC_CREDITO_ICMS != $funcoes->sanearValor($_POST['perc_credito_icms'])){
							$Post->perc_credito_icms = $funcoes->sanearValor($_POST['perc_credito_icms']);
							$anterior .= "PERC_CREDITO_ICMS||{$this->dados['proposta']->PERC_CREDITO_ICMS};;";
							$atual .= "PERC_CREDITO_ICMS||{$_POST['perc_credito_icms']};;";
						}
						if ($this->dados['proposta']->VAL_CREDITO_ICMS != $funcoes->sanearValor($_POST['val_credito_icms'])){
							$Post->val_credito_icms = $funcoes->sanearValor($_POST['val_credito_icms']);
							$anterior .= "VAL_CREDITO_ICMS||{$this->dados['proposta']->VAL_CREDITO_ICMS};;";
							$atual .= "VAL_CREDITO_ICMS||{$_POST['val_credito_icms']};;";
						}
						if ($this->dados['proposta']->VAL_IMPLEMENTO != $funcoes->sanearValor($_POST['val_implemento'])){
							$Post->val_implemento = $funcoes->sanearValor($_POST['val_implemento']);
							$anterior .= "VAL_IMPLEMENTO||{$this->dados['proposta']->VAL_IMPLEMENTO};;";
							$atual .= "VAL_IMPLEMENTO||{$_POST['val_implemento']};;";
						}
						if ($this->dados['proposta']->PERC_ICMS_IMP != $funcoes->sanearValor($_POST['perc_icms_imp'])){
							$Post->perc_icms_imp = $funcoes->sanearValor($_POST['perc_icms_imp']);
							$anterior .= "PERC_ICMS_IMP||{$this->dados['proposta']->PERC_ICMS_IMP};;";
							$atual .= "PERC_ICMS_IMP||{$_POST['perc_icms_imp']};;";
						}
						if ($this->dados['proposta']->VAL_ICMS_IMP != $funcoes->sanearValor($_POST['val_icms_imp'])){
							$Post->val_icms_imp = $funcoes->sanearValor($_POST['val_icms_imp']);
							$anterior .= "VAL_ICMS_IMP||{$this->dados['proposta']->VAL_ICMS_IMP};;";
							$atual .= "VAL_ICMS_IMP||{$_POST['val_icms_imp']};;";
						}
						if ($this->dados['proposta']->PERC_BONUS_FAB != $funcoes->sanearValor($_POST['perc_bonus_fab'])){
							$Post->perc_bonus_fab = $funcoes->sanearValor($_POST['perc_bonus_fab']);
							$anterior .= "PERC_BONUS_FAB||{$this->dados['proposta']->PERC_BONUS_FAB};;";
							$atual .= "PERC_BONUS_FAB||{$_POST['perc_bonus_fab']};;";
						}
						if ($this->dados['proposta']->CREDITO_BONUS != $funcoes->sanearValor($_POST['credito_bonus'])){
							$Post->credito_bonus = $funcoes->sanearValor($_POST['credito_bonus']);
							$anterior .= "CREDITO_BONUS||{$this->dados['proposta']->CREDITO_BONUS};;";
							$atual .= "CREDITO_BONUS||{$_POST['credito_bonus']};;";
						}
						if ($this->dados['proposta']->BONUS_FABRICA != $funcoes->sanearValor($_POST['bonus_fabrica'])){
							$Post->bonus_fabrica = $funcoes->sanearValor($_POST['bonus_fabrica']);
							$anterior .= "BONUS_FABRICA||{$this->dados['proposta']->BONUS_FABRICA};;";
							$atual .= "BONUS_FABRICA||{$_POST['bonus_fabrica']};;";
						}
						if ($this->dados['proposta']->CUSTO_VEICULO != $funcoes->sanearValor($_POST['custo_veiculo'])){
							$Post->custo_veiculo = $funcoes->sanearValor($_POST['custo_veiculo']);
							$anterior .= "CUSTO_VEICULO||{$this->dados['proposta']->CUSTO_VEICULO};;";
							$atual .= "CUSTO_VEICULO||{$_POST['custo_veiculo']};;";
						}
						if ($this->dados['proposta']->DESCONTO_COMISSAO != $funcoes->sanearValor($_POST['desconto_comissao'])){
							$Post->desconto_comissao = $funcoes->sanearValor($_POST['desconto_comissao']);
							$anterior .= "DESCONTO_COMISSAO||{$this->dados['proposta']->DESCONTO_COMISSAO};;";
							$atual .= "DESCONTO_COMISSAO||{$_POST['desconto_comissao']};;";
						}
						if ($this->dados['proposta']->BASE_CALCULO != $funcoes->sanearValor($_POST['base_calculo'])){
							$Post->base_calculo = $funcoes->sanearValor($_POST['base_calculo']);
							$anterior .= "BASE_CALCULO||{$this->dados['proposta']->BASE_CALCULO};;";
							$atual .= "BASE_CALCULO||{$_POST['base_calculo']};;";
						}
						if (($ant = number_format(str_replace(",", ".", $this->dados['proposta']->PERC_COMISSAO), 2, ",", "."))!= $_POST['perc_comissao']){
							$Post->perc_comissao = $_POST['perc_comissao'];
							$anterior .= "PERC_COMISSAO||{$ant};;";
							$atual .= "PERC_COMISSAO||{$_POST['perc_comissao']};;";
						}
						if ($this->dados['proposta']->BONIFICACAO != $funcoes->sanearValor($_POST['bonificacao'])){
							$Post->bonificacao = $funcoes->sanearValor($_POST['bonificacao']);
							$anterior .= "BONIFICACAO||{$this->dados['proposta']->BONIFICACAO};;";
							$atual .= "BONIFICACAO||{$_POST['bonificacao']};;";
						}
						if ($this->dados['proposta']->COMISSAO != $funcoes->sanearValor($_POST['comissao'])){
							$Post->comissao = $funcoes->sanearValor($_POST['comissao']);
							$anterior .= "COMISSAO||{$this->dados['proposta']->COMISSAO};;";
							$atual .= "COMISSAO||{$_POST['comissao']};;";
						}
						
						if (isset($_POST['valor_pagamento'])){
							$val_pag = $_POST['valor_pagamento'];
							foreach ($_POST['des_pagamento'] as $key => $r) {
								$des_pagamento .=  ($r != NULL || $val_pag{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_pag{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_pag{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
							}
							if ($this->dados['proposta']->DES_PAGAMENTO != $des_pagamento ){
								$Post->des_pagamento = $des_pagamento;
								$anterior .= "DES_PAGAMENTO||{$this->dados['proposta']->DES_PAGAMENTO};;";
								$atual .= "DES_PAGAMENTO||{$des_pagamento};;";
							}
						}else{
							if ($this->dados['proposta']->DES_PAGAMENTO != "" ){
								$Post->des_pagamento = "excluir";
								$anterior .= "DES_PAGAMENTO||{$this->dados['proposta']->DES_PAGAMENTO};;";
								$atual .= "DES_PAGAMENTO||NULL;;";
							}
						}
						
						if (isset($_POST['valor_frete'])){
							$val_fre = $_POST['valor_frete'];
							foreach ($_POST['des_frete'] as $key => $r) {
								$des_frete .=  ($r != NULL || $val_fre{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_fre{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_fre{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
							}
							if ($this->dados['proposta']->DES_FRETE != $des_frete){
								$Post->des_frete =  $des_frete;
								$anterior .= "DES_FRETE||{$this->dados['proposta']->DES_FRETE};;";
								$atual .= "DES_FRETE||{$des_frete};;";
							}
						}else{
							if ($this->dados['proposta']->DES_FRETE != ""){
								$Post->des_frete =  "excluir";
								$anterior .= "DES_FRETE||{$this->dados['proposta']->DES_FRETE};;";
								$atual .= "DES_FRETE||NULL;;";
							}
						}
						
						if (isset($_POST['valor_outros_custos'])){
							$val_out = $_POST['valor_outros_custos'];
							foreach ($_POST['des_outros_custos'] as $key => $r) {
								$des_outros_custos .=  ($r != NULL || $val_out{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_out{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_out{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
							}
							if ($this->dados['proposta']->DES_OUTROS_CUSTOS != $des_outros_custos){
								$Post->des_outros_custos =  $des_outros_custos;
								$anterior .= "DES_OUTROS_CUSTOS||{$this->dados['proposta']->DES_OUTROS_CUSTOS};;";
								$atual .= "DES_OUTROS_CUSTOS||{$des_outros_custos};;";
							}
						}else{
							if ($this->dados['proposta']->DES_OUTROS_CUSTOS != ""){
								$Post->des_outros_custos =  "excluir";
								$anterior .= "DES_OUTROS_CUSTOS||{$this->dados['proposta']->DES_OUTROS_CUSTOS};;";
								$atual .= "DES_OUTROS_CUSTOS||NULL;;";
							}
						}
						
						if (isset($_POST['valor_implemento'])){
							$val_imp = $_POST['valor_implemento'];
							foreach ($_POST['des_implemento'] as $key => $r) {
								$des_implemento .=  ($r != NULL || $val_imp{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_imp{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_imp{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
							}
							if ($this->dados['proposta']->DES_IMPLEMENTO != $des_implemento){
								$Post->des_implemento =  $des_implemento;
								$anterior .= "DES_IMPLEMENTO||{$this->dados['proposta']->DES_IMPLEMENTO};;";
								$atual .= "DES_IMPLEMENTO||{$des_implemento};;";
							}
						}else{
							if ($this->dados['proposta']->DES_IMPLEMENTO != ""){
								$Post->des_implemento =  "excluir";
								$anterior .= "DES_IMPLEMENTO||{$this->dados['proposta']->DES_IMPLEMENTO};;";
								$atual .= "DES_IMPLEMENTO||NULL;;";
							}
						}
						
						if (isset($_POST['valor_veiculo_usado'])){
							$val_vei = $_POST['valor_veiculo_usado'];
							foreach ($_POST['des_veiculo_usado'] as $key => $r) {
								$des_veiculo_usado .=  ($r != NULL || $val_vei{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_vei{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "MARCA: ".str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 43, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_vei{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
							}
							if ($this->dados['proposta']->DES_VEICULO_USADO != $des_veiculo_usado){
								$Post->des_veiculo_usado =  $des_veiculo_usado;
								$anterior .= "DES_VEICULO_USADO||{$this->dados['proposta']->DES_VEICULO_USADO};;";
								$atual .= "DES_VEICULO_USADO||{$des_veiculo_usado};;";
							}
						}else{
							if ($this->dados['proposta']->DES_VEICULO_USADO != ""){
								$Post->des_veiculo_usado =  "excluir";
								$anterior .= "DES_VEICULO_USADO||{$this->dados['proposta']->DES_VEICULO_USADO};;";
								$atual .= "DES_VEICULO_USADO||NULL;;";
							}
						}
						
						if (isset($_POST['valor_bonus'])){
							$val_bo = $_POST['valor_bonus'];
							foreach ($_POST['des_bonus'] as $key => $r) {
								$des_bonus .=  ($r != NULL || $val_bo{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_bo{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_bo{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
							}
							if ($this->dados['proposta']->DES_BONUS != $des_bonus){
								$Post->des_bonus = $des_bonus;
								$anterior .= "DES_BONUS||{$this->dados['proposta']->DES_BONUS};;";
								$atual .= "DES_BONUS||{$des_bonus};;";
							}
						}else{
							if ($this->dados['proposta']->DES_BONUS != ""){
								$Post->des_bonus = "excluir";
								$anterior .= "DES_BONUS||{$this->dados['proposta']->DES_BONUS};;";
								$atual .= "DES_BONUS||NULL;;";
							}
						}
						
						if ($this->dados['proposta']->OBS1 != strtoupper(trim($_POST['obs1']))){
							$Post->obs1 = strtoupper(trim($_POST['obs1']));
							$anterior .= "OBS1||{$this->dados['proposta']->OBS1};;";
							$atual .= "OBS1||{$Post->obs1};;";
						}
						if ($this->dados['proposta']->OBS2 != strtoupper(trim($_POST['obs2']))){
							$Post->obs2 = strtoupper(trim($_POST['obs2']));
							$anterior .= "OBS2||{$this->dados['proposta']->OBS2};;";
							$atual .= "OBS2||{$Post->obs2};;";
						}
						if ($this->dados['proposta']->OBS3 != strtoupper(trim($_POST['obs3']))){
							$Post->obs3 = strtoupper(trim($_POST['obs3']));
							$anterior .= "OBS3||{$this->dados['proposta']->OBS3};;";
							$atual .= "OBS3||{$Post->obs3};;";
						}
					}elseif ($this->dados['proposta']->TIPO_VENDA== 'U'){
						if ($this->dados['proposta']->VAL_EMISSAO_NF != $funcoes->sanearValor($_POST['val_emissao_nf'])){
							$Post->val_emissao_nf = $funcoes->sanearValor($_POST['val_emissao_nf']);
							$anterior .= "VAL_EMISSAO_NF||{$this->dados['proposta']->VAL_EMISSAO_NF};;";
							$atual .= "VAL_EMISSAO_NF||{$_POST['val_emissao_nf']};;";
						}
						if ($this->dados['proposta']->VAL_VENDA != $funcoes->sanearValor($_POST['val_venda'])){
							$Post->val_venda = $funcoes->sanearValor($_POST['val_venda']);
							$anterior .= "VAL_VENDA||{$this->dados['proposta']->VAL_VENDA};;";
							$atual .= "VAL_VENDA||{$_POST['val_venda']};;";
						}
						if ($this->dados['proposta']->VAL_OUTRAS_RECEITAS_OP != $funcoes->sanearValor($_POST['val_outras_receitas_op'])){
							$Post->val_outras_receitas_op = $funcoes->sanearValor($_POST['val_outras_receitas_op']);
							$anterior .= "VAL_OUTRAS_RECEITAS_OP||{$this->dados['proposta']->VAL_OUTRAS_RECEITAS_OP};;";
							$atual .= "VAL_OUTRAS_RECEITAS_OP||{$_POST['val_outras_receitas_op']};;";
						}
						if ($this->dados['proposta']->PERC_ICMS != $funcoes->sanearValor($_POST['perc_icms'])){
							$Post->perc_icms = $funcoes->sanearValor($_POST['perc_icms']);
							$anterior .= "PERC_ICMS||{$this->dados['proposta']->PERC_ICMS};;";
							$atual .= "PERC_ICMS||{$_POST['perc_icms']};;";
						}
						if ($this->dados['proposta']->VAL_ICMS != $funcoes->sanearValor($_POST['val_icms'])){
							$Post->val_icms = $funcoes->sanearValor($_POST['val_icms']);
							$anterior .= "VAL_ICMS||{$this->dados['proposta']->VAL_ICMS};;";
							$atual .= "VAL_ICMS||{$_POST['val_icms']};;";
						}
						if ($this->dados['proposta']->VAL_PIS_COFINS_COMPRA != $funcoes->sanearValor($_POST['val_pis_cofins_compra'])){
							$Post->val_pis_cofins_compra = $funcoes->sanearValor($_POST['val_pis_cofins_compra']);
							$anterior .= "VAL_PIS_COFINS_COMPRA||{$this->dados['proposta']->VAL_PIS_COFINS_COMPRA};;";
							$atual .= "VAL_PIS_COFINS_COMPRA||{$_POST['val_pis_cofins_compra']};;";
						}
						if ($this->dados['proposta']->VAL_FRETE != $funcoes->sanearValor($_POST['val_frete'])){
							$Post->val_frete = $funcoes->sanearValor($_POST['val_frete']);
							$anterior .= "VAL_FRETE||{$this->dados['proposta']->VAL_FRETE};;";
							$atual .= "VAL_FRETE||{$_POST['val_frete']};;";
						}
						if ($this->dados['proposta']->CUSTO_VEICULO != $funcoes->sanearValor($_POST['custo_veiculo'])){
							$Post->custo_veiculo = $funcoes->sanearValor($_POST['custo_veiculo']);
							$anterior .= "CUSTO_VEICULO||{$this->dados['proposta']->CUSTO_VEICULO};;";
							$atual .= "CUSTO_VEICULO||{$_POST['custo_veiculo']};;";
						}
						if ($this->dados['proposta']->VAL_OUTROS_CUSTOS != $funcoes->sanearValor($_POST['val_outros_custos'])){
							$Post->val_outros_custos = $funcoes->sanearValor($_POST['val_outros_custos']);
							$anterior .= "VAL_OUTROS_CUSTOS||{$this->dados['proposta']->VAL_OUTROS_CUSTOS};;";
							$atual .= "VAL_OUTROS_CUSTOS||{$_POST['val_outros_custos']};;";
						}			
						if ($this->dados['proposta']->CMV != $funcoes->sanearValor($_POST['cmv'])){
							$Post->cmv = $funcoes->sanearValor($_POST['cmv']);
							$anterior .= "CMV||{$this->dados['proposta']->CMV};;";
							$atual .= "CMV||{$_POST['cmv']};;";
						}
						if ($this->dados['proposta']->LUCRO_BRUTO != $funcoes->sanearValor($_POST['lucro_bruto'])){
							$Post->lucro_bruto = $funcoes->sanearValor($_POST['lucro_bruto']);
							$anterior .= "LUCRO_BRUTO||{$this->dados['proposta']->LUCRO_BRUTO};;";
							$atual .= "LUCRO_BRUTO||{$_POST['lucro_bruto']};;";
						}
						if ($this->dados['proposta']->PERC_LUCRO != $funcoes->sanearValor($_POST['perc_lucro'])){
							$Post->perc_lucro = $funcoes->sanearValor($_POST['perc_lucro']);
							$anterior .= "PERC_LUCRO||{$this->dados['proposta']->PERC_LUCRO};;";
							$atual .= "PERC_LUCRO||{$_POST['perc_lucro']};;";
						}
						if ($this->dados['proposta']->DESCONTO_COMISSAO != $funcoes->sanearValor($_POST['desconto_comissao'])){
							$Post->desconto_comissao = $funcoes->sanearValor($_POST['desconto_comissao']);
							$anterior .= "DESCONTO_COMISSAO||{$this->dados['proposta']->DESCONTO_COMISSAO};;";
							$atual .= "DESCONTO_COMISSAO||{$_POST['desconto_comissao']};;";
						}
						if ($this->dados['proposta']->BASE_CALCULO != $funcoes->sanearValor($_POST['base_calculo'])){
							$Post->base_calculo = $funcoes->sanearValor($_POST['base_calculo']);
							$anterior .= "BASE_CALCULO||{$this->dados['proposta']->BASE_CALCULO};;";
							$atual .= "BASE_CALCULO||{$_POST['base_calculo']};;";
						}
						if (($ant = number_format(str_replace(",", ".", $this->dados['proposta']->PERC_COMISSAO), 2, ",", ".")) != $_POST['perc_comissao']){
							$Post->perc_comissao = $_POST['perc_comissao'];
							$anterior .= "PERC_COMISSAO||{$ant};;";
							$atual .= "PERC_COMISSAO||{$_POST['perc_comissao']};;";
						}
						if ($this->dados['proposta']->COMISSAO != $funcoes->sanearValor($_POST['comissao'])){
							$Post->comissao = $funcoes->sanearValor($_POST['comissao']);
							$anterior .= "COMISSAO||{$this->dados['proposta']->COMISSAO};;";
							$atual .= "COMISSAO||{$_POST['comissao']};;";
						}
						
						if (isset($_POST['valor_pagamento'])){
							$val_pag = $_POST['valor_pagamento'];
							foreach ($_POST['des_pagamento'] as $key => $r) {
								$des_pagamento .=  ($r != NULL || $val_pag{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_pag{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_pag{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
							}
							if ($this->dados['proposta']->DES_PAGAMENTO != $des_pagamento ){
								$Post->des_pagamento = $des_pagamento;
								$anterior .= "DES_PAGAMENTO||{$this->dados['proposta']->DES_PAGAMENTO};;";
								$atual .= "DES_PAGAMENTO||{$des_pagamento};;";
							}
						}else{
							if ($this->dados['proposta']->DES_PAGAMENTO != "" ){
								$Post->des_pagamento = "excluir";
								$anterior .= "DES_PAGAMENTO||{$this->dados['proposta']->DES_PAGAMENTO};;";
								$atual .= "DES_PAGAMENTO||NULL;;";
							}
						}
						
						if (isset($_POST['valor_frete'])){
							$val_fre = $_POST['valor_frete'];
							foreach ($_POST['des_frete'] as $key => $r) {
								$des_frete .=  ($r != NULL || $val_fre{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_fre{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_fre{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
							}
							if ($this->dados['proposta']->DES_FRETE != $des_frete){
								$Post->des_frete =  $des_frete;
								$anterior .= "DES_FRETE||{$this->dados['proposta']->DES_FRETE};;";
								$atual .= "DES_FRETE||{$des_frete};;";
							}
						}else{
							if ($this->dados['proposta']->DES_FRETE != ""){
								$Post->des_frete =  "excluir";
								$anterior .= "DES_FRETE||{$this->dados['proposta']->DES_FRETE};;";
								$atual .= "DES_FRETE||NULL;;";
							}
						}
						
						if (isset($_POST['valor_outros_custos'])){
							$val_out = $_POST['valor_outros_custos'];
							foreach ($_POST['des_outros_custos'] as $key => $r) {
								$des_outros_custos .=  ($r != NULL || $val_out{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_out{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_out{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
							}
							if ($this->dados['proposta']->DES_OUTROS_CUSTOS != $des_outros_custos){
								$Post->des_outros_custos =  $des_outros_custos;
								$anterior .= "DES_OUTROS_CUSTOS||{$this->dados['proposta']->DES_OUTROS_CUSTOS};;";
								$atual .= "DES_OUTROS_CUSTOS||{$des_outros_custos};;";
							}
						}else{
							if ($this->dados['proposta']->DES_OUTROS_CUSTOS != ""){
								$Post->des_outros_custos =  "excluir";
								$anterior .= "DES_OUTROS_CUSTOS||{$this->dados['proposta']->DES_OUTROS_CUSTOS};;";
								$atual .= "DES_OUTROS_CUSTOS||NULL;;";
							}
						}
						
						if (isset($_POST['valor_bonus'])){
							$val_bo = $_POST['valor_bonus'];
							foreach ($_POST['des_bonus'] as $key => $r) {
								$des_bonus .=  ($r != NULL || $val_bo{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_bo{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_bo{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
							}
							if ($this->dados['proposta']->DES_BONUS != $des_bonus){
								$Post->des_bonus = $des_bonus;
								$anterior .= "DES_BONUS||{$this->dados['proposta']->DES_BONUS};;";
								$atual .= "DES_BONUS||{$des_bonus};;";
							}
						}else{
							if ($this->dados['proposta']->DES_BONUS != ""){
								$Post->des_bonus = "excluir";
								$anterior .= "DES_BONUS||{$this->dados['proposta']->DES_BONUS};;";
								$atual .= "DES_BONUS||NULL;;";
							}
						}
						
						if ($this->dados['proposta']->OBS1 != strtoupper(trim($_POST['obs1']))){
							$Post->obs1 = strtoupper(trim($_POST['obs1']));
							$anterior .= "OBS1||{$this->dados['proposta']->OBS1};;";
							$atual .= "OBS1||{$Post->obs1};;";
						}
						if ($this->dados['proposta']->OBS2 != strtoupper(trim($_POST['obs2']))){
							$Post->obs2 = strtoupper(trim($_POST['obs2']));
							$anterior .= "OBS2||{$this->dados['proposta']->OBS2};;";
							$atual .= "OBS2||{$Post->obs2};;";
						}
						if ($this->dados['proposta']->OBS3 != strtoupper(trim($_POST['obs3']))){
							$Post->obs3 = strtoupper(trim($_POST['obs3']));
							$anterior .= "OBS3||{$this->dados['proposta']->OBS3};;";
							$atual .= "OBS3||{$Post->obs3};;";
						}
					}else{
						if ($this->dados['proposta']->VAL_NF_FABRICA != $funcoes->sanearValor($_POST['val_nf_fabrica'])){
							$Post->val_nf_fabrica = $funcoes->sanearValor($_POST['val_nf_fabrica']);
							$anterior .= "VAL_NF_FABRICA||{$this->dados['proposta']->VAL_NF_FABRICA};;";
							$atual .= "VAL_NF_FABRICA||{$_POST['val_nf_fabrica']};;";
						}
						if ($this->dados['proposta']->VAL_VENDA != $funcoes->sanearValor($_POST['val_venda'])){
							$Post->val_venda = $funcoes->sanearValor($_POST['val_venda']);
							$anterior .= "VAL_VENDA||{$this->dados['proposta']->VAL_VENDA};;";
							$atual .= "VAL_VENDA||{$_POST['val_venda']};;";
						}
						if ($this->dados['proposta']->COMISSAO_FABRICA != $funcoes->sanearValor($_POST['comissao_fabrica'])){
							$Post->comissao_fabrica = $funcoes->sanearValor($_POST['comissao_fabrica']);
							$anterior .= "COMISSAO_FABRICA||{$this->dados['proposta']->COMISSAO_FABRICA};;";
							$atual .= "COMISSAO_FABRICA||{$_POST['comissao_fabrica']};;";
						}
						if ($this->dados['proposta']->VAL_COMISSAO_FABRICA !=  $funcoes->sanearValor($_POST['val_comissao_fabrica'])){
							$Post->val_comissao_fabrica =  $funcoes->sanearValor($_POST['val_comissao_fabrica']);
							$anterior .= "VAL_COMISSAO_FABRICA||{$this->dados['proposta']->VAL_COMISSAO_FABRICA};;";
							$atual .= "VAL_COMISSAO_FABRICA||{$_POST['comissao_fabrica']};;";
						}
						if ($this->dados['proposta']->VAL_DIF_NFFABRICA_NFVENDA !=  $funcoes->sanearValor($_POST['val_dif_nffabrica_nfvenda'])){
							$Post->val_dif_nffabrica_nfvenda =  $funcoes->sanearValor($_POST['val_dif_nffabrica_nfvenda']);
							$anterior .= "VAL_DIF_NFFABRICA_NFVENDA||{$this->dados['proposta']->VAL_DIF_NFFABRICA_NFVENDA};;";
							$atual .= "VAL_DIF_NFFABRICA_NFVENDA||{$_POST['val_dif_nffabrica_nfvenda']};;";
						}
						if ($this->dados['proposta']->VAL_OUTRAS_RECEITAS_OP != $funcoes->sanearValor($_POST['val_outras_receitas_op'])){
							$Post->val_outras_receitas_op = $funcoes->sanearValor($_POST['val_outras_receitas_op']);
							$anterior .= "VAL_OUTRAS_RECEITAS_OP||{$this->dados['proposta']->VAL_OUTRAS_RECEITAS_OP};;";
							$atual .= "VAL_OUTRAS_RECEITAS_OP||{$_POST['val_outras_receitas_op']};;";
						}
						if ($this->dados['proposta']->LUCRO_BRUTO != $funcoes->sanearValor($_POST['lucro_bruto'])){
							$Post->lucro_bruto = $funcoes->sanearValor($_POST['lucro_bruto']);
							$anterior .= "LUCRO_BRUTO||{$this->dados['proposta']->LUCRO_BRUTO};;";
							$atual .= "LUCRO_BRUTO||{$_POST['lucro_bruto']};;";
						}
						if ($this->dados['proposta']->VAL_CUSTO_OPERACIONAL != $funcoes->sanearValor($_POST['val_custo_operacional'])){
							$Post->val_custo_operacional = $funcoes->sanearValor($_POST['val_custo_operacional']);
							$anterior .= "VAL_CUSTO_OPERACIONAL||{$this->dados['proposta']->VAL_CUSTO_OPERACIONAL};;";
							$atual .= "VAL_CUSTO_OPERACIONAL||{$_POST['val_custo_operacional']};;";
						}
						if ($this->dados['proposta']->VAL_OUTROS_CUSTOS != $funcoes->sanearValor($_POST['val_outros_custos'])){
							$Post->val_outros_custos = $funcoes->sanearValor($_POST['val_outros_custos']);
							$anterior .= "VAL_OUTROS_CUSTOS||{$this->dados['proposta']->VAL_OUTROS_CUSTOS};;";
							$atual .= "VAL_OUTROS_CUSTOS||{$_POST['val_outros_custos']};;";
						}
						if ($this->dados['proposta']->VAL_JUROS_OP_CHEQUE != $funcoes->sanearValor($_POST['val_juros_op_cheque'])){
							$Post->val_juros_op_cheque = $funcoes->sanearValor($_POST['val_juros_op_cheque']);
							$anterior .= "VAL_JUROS_OP_CHEQUE||{$this->dados['proposta']->VAL_JUROS_OP_CHEQUE};;";
							$atual .= "VAL_JUROS_OP_CHEQUE||{$_POST['val_juros_op_cheque']};;";
						}
						if ($this->dados['proposta']->VAL_FRETE != $funcoes->sanearValor($_POST['val_frete'])){
							$Post->val_frete = $funcoes->sanearValor($_POST['val_frete']);
							$anterior .= "VAL_FRETE||{$this->dados['proposta']->VAL_FRETE};;";
							$atual .= "VAL_FRETE||{$_POST['val_frete']};;";
						}
						if ($this->dados['proposta']->LUCRO_LIQUIDO != $funcoes->sanearValor($_POST['lucro_liquido'])){
							$Post->lucro_liquido = $funcoes->sanearValor($_POST['lucro_liquido	']);
							$anterior .= "LUCRO_LIQUIDO||{$this->dados['proposta']->LUCRO_LIQUIDO};;";
							$atual .= "LUCRO_LIQUIDO||{$_POST['lucro_liquido']};;";
						}
						if ($this->dados['proposta']->PERC_LUCRO != $funcoes->sanearValor($_POST['perc_lucro'])){
							$Post->perc_lucro = $funcoes->sanearValor($_POST['perc_lucro']);
							$anterior .= "PERC_LUCRO||{$this->dados['proposta']->PERC_LUCRO};;";
							$atual .= "PERC_LUCRO||{$_POST['perc_lucro']};;";
						}
						if ($this->dados['proposta']->DESCONTO_COMISSAO != $funcoes->sanearValor($_POST['desconto_comissao'])){
							$Post->desconto_comissao = $funcoes->sanearValor($_POST['desconto_comissao']);
							$anterior .= "DESCONTO_COMISSAO||{$this->dados['proposta']->DESCONTO_COMISSAO};;";
							$atual .= "DESCONTO_COMISSAO||{$_POST['desconto_comissao']};;";
						}
						if ($this->dados['proposta']->BASE_CALCULO != $funcoes->sanearValor($_POST['base_calculo'])){
							$Post->base_calculo = $funcoes->sanearValor($_POST['base_calculo']);
							$anterior .= "BASE_CALCULO||{$this->dados['proposta']->BASE_CALCULO};;";
							$atual .= "BASE_CALCULO||{$_POST['base_calculo']};;";
						}
						if (($ant = number_format(str_replace(",", ".", $this->dados['proposta']->PERC_COMISSAO), 2, ",", ".")) != $_POST['perc_comissao']){
							$Post->perc_comissao = $_POST['perc_comissao'];
							$anterior .= "PERC_COMISSAO||{$ant};;";
							$atual .= "PERC_COMISSAO||{$_POST['perc_comissao']};;";
						}
						if ($this->dados['proposta']->COMISSAO != $funcoes->sanearValor($_POST['comissao'])){
							$Post->comissao = $funcoes->sanearValor($_POST['comissao']);
							$anterior .= "COMISSAO||{$this->dados['proposta']->COMISSAO};;";
							$atual .= "COMISSAO||{$_POST['comissao']};;";
						}
						
						if (isset($_POST['valor_pagamento'])){
							$val_pag = $_POST['valor_pagamento'];
							foreach ($_POST['des_pagamento'] as $key => $r) {
								$des_pagamento .=  ($r != NULL || $val_pag{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_pag{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_pag{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
							}
							if ($this->dados['proposta']->DES_PAGAMENTO != $des_pagamento ){
								$Post->des_pagamento = $des_pagamento;
								$anterior .= "DES_PAGAMENTO||{$this->dados['proposta']->DES_PAGAMENTO};;";
								$atual .= "DES_PAGAMENTO||{$des_pagamento};;";
							}
						}else{
							if ($this->dados['proposta']->DES_PAGAMENTO != "" ){
								$Post->des_pagamento = "excluir";
								$anterior .= "DES_PAGAMENTO||{$this->dados['proposta']->DES_PAGAMENTO};;";
								$atual .= "DES_PAGAMENTO||NULL;;";
							}
						}
						
						if (isset($_POST['valor_frete'])){
							$val_fre = $_POST['valor_frete'];
							foreach ($_POST['des_frete'] as $key => $r) {
								$des_frete .=  ($r != NULL || $val_fre{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_fre{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_fre{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
							}
							if ($this->dados['proposta']->DES_FRETE != $des_frete){
								$Post->des_frete =  $des_frete;
								$anterior .= "DES_FRETE||{$this->dados['proposta']->DES_FRETE};;";
								$atual .= "DES_FRETE||{$des_frete};;";
							}
						}else{
							if ($this->dados['proposta']->DES_FRETE != ""){
								$Post->des_frete =  "excluir";
								$anterior .= "DES_FRETE||{$this->dados['proposta']->DES_FRETE};;";
								$atual .= "DES_FRETE||NULL;;";
							}
						}
						
						if (isset($_POST['valor_outros_custos'])){
							$val_out = $_POST['valor_outros_custos'];
							foreach ($_POST['des_outros_custos'] as $key => $r) {
								$des_outros_custos .=  ($r != NULL || $val_out{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_out{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_out{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
							}
							if ($this->dados['proposta']->DES_OUTROS_CUSTOS != $des_outros_custos){
								$Post->des_outros_custos =  $des_outros_custos;
								$anterior .= "DES_OUTROS_CUSTOS||{$this->dados['proposta']->DES_OUTROS_CUSTOS};;";
								$atual .= "DES_OUTROS_CUSTOS||{$des_outros_custos};;";
							}
						}else{
							if ($this->dados['proposta']->DES_OUTROS_CUSTOS != ""){
								$Post->des_outros_custos =  "excluir";
								$anterior .= "DES_OUTROS_CUSTOS||{$this->dados['proposta']->DES_OUTROS_CUSTOS};;";
								$atual .= "DES_OUTROS_CUSTOS||NULL;;";
							}
						}
						
						if (isset($_POST['valor_implemento'])){
							$val_imp = $_POST['valor_implemento'];
							foreach ($_POST['des_implemento'] as $key => $r) {
								$des_implemento .=  ($r != NULL || $val_imp{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_imp{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_imp{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
							}
							if ($this->dados['proposta']->DES_IMPLEMENTO != $des_implemento){
								$Post->des_implemento =  $des_implemento;
								$anterior .= "DES_IMPLEMENTO||{$this->dados['proposta']->DES_IMPLEMENTO};;";
								$atual .= "DES_IMPLEMENTO||{$des_implemento};;";
							}
						}else{
							if ($this->dados['proposta']->DES_IMPLEMENTO != ""){
								$Post->des_implemento =  "excluir";
								$anterior .= "DES_IMPLEMENTO||{$this->dados['proposta']->DES_IMPLEMENTO};;";
								$atual .= "DES_IMPLEMENTO||NULL;;";
							}
						}
						
						if (isset($_POST['valor_veiculo_usado'])){
							$val_vei = $_POST['valor_veiculo_usado'];
							foreach ($_POST['des_veiculo_usado'] as $key => $r) {
								$des_veiculo_usado .=  ($r != NULL || $val_vei{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_vei{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "MARCA: ".str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 43, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_vei{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
							}
							if ($this->dados['proposta']->DES_VEICULO_USADO != $des_veiculo_usado){
								$Post->des_veiculo_usado =  $des_veiculo_usado;
								$anterior .= "DES_VEICULO_USADO||{$this->dados['proposta']->DES_VEICULO_USADO};;";
								$atual .= "DES_VEICULO_USADO||{$des_veiculo_usado};;";
							}
						}else{
							if ($this->dados['proposta']->DES_VEICULO_USADO != ""){
								$Post->des_veiculo_usado =  "excluir";
								$anterior .= "DES_VEICULO_USADO||{$this->dados['proposta']->DES_VEICULO_USADO};;";
								$atual .= "DES_VEICULO_USADO||NULL;;";
							}
						}
						
						if (isset($_POST['valor_bonus'])){
							$val_bo = $_POST['valor_bonus'];
							foreach ($_POST['des_bonus'] as $key => $r) {
								$des_bonus .=  ($r != NULL || $val_bo{$key} != NULL) ? ($r == NULL) ? str_pad("", 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_bo{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : str_pad(strtoupper($funcoes->retiraAcentos(trim($r))), 50, " ", STR_PAD_RIGHT)."  R$ ".str_pad($val_bo{$key}, 10, " ", STR_PAD_LEFT)."\r\n" : "";
							}
							if ($this->dados['proposta']->DES_BONUS != $des_bonus){
								$Post->des_bonus = $des_bonus;
								$anterior .= "DES_BONUS||{$this->dados['proposta']->DES_BONUS};;";
								$atual .= "DES_BONUS||{$des_bonus};;";
							}
						}else{
							if ($this->dados['proposta']->DES_BONUS != ""){
								$Post->des_bonus = "excluir";
								$anterior .= "DES_BONUS||{$this->dados['proposta']->DES_BONUS};;";
								$atual .= "DES_BONUS||NULL;;";
							}
						}
						
						if ($this->dados['proposta']->OBS1 != strtoupper(trim($_POST['obs1']))){
							$Post->obs1 = strtoupper(trim($_POST['obs1']));
							$anterior .= "OBS1||{$this->dados['proposta']->OBS1};;";
							$atual .= "OBS1||{$Post->obs1};;";
						}
						if ($this->dados['proposta']->OBS2 != strtoupper(trim($_POST['obs2']))){
							$Post->obs2 = strtoupper(trim($_POST['obs2']));
							$anterior .= "OBS2||{$this->dados['proposta']->OBS2};;";
							$atual .= "OBS2||{$Post->obs2};;";
						}
						if ($this->dados['proposta']->OBS3 != strtoupper(trim($_POST['obs3']))){
							$Post->obs3 = strtoupper(trim($_POST['obs3']));
							$anterior .= "OBS3||{$this->dados['proposta']->OBS3};;";
							$atual .= "OBS3||{$Post->obs3};;";
						}
					}
					$obj = (array) $Post;
					$obj = array_filter($obj, function($v){return !is_null($v);});
					if ($obj != NULL){
						$Post->proposta = $this->proposta;
						$Post->empresa = $this->empresa;
						$Post->dta_ult_alteracao = date("d/m/Y H:i:s");
						$sql[$i] = $apiProposta->editProposta($Post);
						$i = $i+1;
						$log = new Log();
						$log->historico = substr($anterior,0,-2);
						$log->usuario = $_SESSION['usuario_sessao'];
						$log->modulo = $this->getModule()['modulo'];
						$log->controle = $this->getController()['controle'];
						$log->acao = $this->getAction()['acao'];
						$log->empresa = $_SESSION['empresa_sessao'];
						$log->tipo = "A";
						$log->dta_registro = date("d/m/Y H:i:s");
						$log->historico .= substr($atual,0,-2);
						$apiLog = new apiLog();
						$sql[$i] = $apiLog->addLog($log);
						$rs = $apiProposta->executeSQL($sql);
						if (@$rs[4] == 'sucesso') {
							if (isset($this->PaginaAtual)) {
								header('location:' .APP_ROOT. 'sav/proposta/index/pagina/'.$this->PaginaAtual.'/sucesso');
							}else {
								header('location:' .APP_ROOT. 'sav/proposta/index/sucesso');
							}
						}else{
							$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
							$erro = str_replace($retirar, "", $rs[2]);
							$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
						}
					}else{
						if (!isset($this->Alert)){
							if (isset($this->PaginaAtual)) {
								header('location:' .APP_ROOT. 'sav/proposta/index/pagina/'.$this->PaginaAtual.'/insucesso');
							}else {
								header('location:' .APP_ROOT. 'sav/proposta/index/insucesso');
							}
						}
					}
				}else{
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'sav/proposta/index/pagina/'.$this->PaginaAtual.'/insucesso');
					}else {
						header('location:' .APP_ROOT. 'sav/proposta/index/insucesso');
					}
				}
			}
		}
		$this->view();
	}
	public function excluir() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Exclus�o de Proposta";
		$exp = explode(",", $this->getParams(0));
		$proposta = new Proposta();
		$proposta->proposta = $this->chamado = $exp[0];
		$proposta->empresa = $this->ambiente = $exp[1];
		$apiProposta = new apiProposta();
		$this->dados = array('proposta' => $apiProposta->getProposta($proposta));
		if (!isset($this->dados['proposta'])){
			header('location:' .APP_ROOT. 'sav/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$sql[$i] = $apiProposta->delProposta($proposta);
			$i = $i+1;
			$log = new Log();
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "E";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico = "TIPO_VENDA||{$this->dados['proposta']->TIPO_VENDA};;PROPOSTA||{$this->dados['proposta']->PROPOSTA};;PROPOSTA_APOLLO||{$this->dados['proposta']->PROPOSTA_APOLLO};;EMPRESA||{$this->dados['proposta']->EMPRESA};;VAL_VENDA||{$this->dados['proposta']->VAL_VENDA};;CHASSI||{$this->dados['proposta']->CHASSI};;MODELO||{$this->dados['proposta']->MODELO};;CLIENTE_NOME||{$this->dados['proposta']->CLIENTE_NOME}";
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiProposta->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'sav/proposta/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'sav/proposta/index/sucesso');
				}
			}else{
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}
		$this->view();
	}
}