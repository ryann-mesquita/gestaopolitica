<?php

namespace controller\sav;

use lib\Controller;
use helper\Security;

class indexController extends Controller {
	
	public function __construct() {
		
		parent::__construct();
		
		new Security($this->getModule(),$this->getController(),$this->getAction());
	}
	
	public function index() {
		unset($_SESSION['filtro_sessao']);
		unset($_SESSION['consulta_sessao']);
		unset($_SESSION['filtro_dashboard']);
		unset($_SESSION['consulta_dashboard']);
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Sistema de Administra��o de Vendas";
		$this->view();
	}
}