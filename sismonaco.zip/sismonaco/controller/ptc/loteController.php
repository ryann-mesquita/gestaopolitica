<?php

namespace controller\ptc;

use lib\Controller;
use helper\Security;
use api\ptc\apiLote;
use api\ptc\apiOrigem;
use api\ptc\apiMotivo;
use helper\Paginator;
use obj\ptc\Lote;
use obj\ptc\Origem;
use obj\ptc\Motivo;
use obj\adm\Usuario;
use api\adm\apiUsuario;
use obj\geral\Log;
use api\geral\apiLog;
use helper\Funcoes;
use api\geral\apiEmpresa;
use api\geral\apiApollo;
use obj\ptc\Cheque;
use api\ptc\apiCheque;
use api\adm\apiPermissao;
use obj\adm\Permissao;
use obj\geral\Empresa;


include 'classes/FPDF/html2pdf.php';

class loteController extends Controller {
	
	public function __construct() {
		
		parent::__construct();
		
		new Security($this->getModule(),$this->getController(),$this->getAction());
	}
	
	public function index() {
		$this->title  	= "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header 	= "Manunten��o de Lotes";
		$this->usuario = $_SESSION['usuario_sessao'];
		$this->empresa	= $_SESSION['empresa_sessao'];
		$apiLote =  new apiLote();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		$usuario   = new Usuario();
		$apiUsuario = new apiUsuario();
		$usuario->usuario   = $this->usuario;
		$rs = $apiUsuario->getUsuario($usuario);
		if (isset($rs)) {
			if ($rs->ATIVO == '0'){
				header('location:' .APP_ROOT. 'lote/index/index/acessonegado');
				die();
			}
		}else{
			header('location:' .APP_ROOT. 'lote/index/index/acessonegado');
			die();
		}
		$this->empresa_padrao = $rs->EMPRESA;
		$apiPermissao = new apiPermissao();
		$apiEmpresa = new apiEmpresa();
		$this->select_empresa = $apiEmpresa->filtroEmpresa('1','3','ativo', '1');
		$permissao = new Permissao();
		$permissao->usuario = $this->usuario;
		$this->perm_empresa = $apiPermissao->permEmpresa($permissao);
		(!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])) ? $a = '6' : $a = '3';
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$busca = array(
					'1' => array('c' => '1','a' => $a,'coluna' => 'situacao', 'valor' => '0', 'empresa'=> $_SESSION['empresa_sessao']),
					'2' => array('c' => '1','a' => $a,'coluna' => 'situacao', 'valor' => '1', 'empresa'=> $_SESSION['empresa_sessao']),
					'3' => array('c' => '1','a' => "6",'coluna' => 'lote', 'valor' => @$_POST['busca_valor'], 'empresa'=> $_SESSION['empresa_sessao']),
					'4' => array('c' => '2','a' => "6",'coluna' => 'empresa_destino', 'valor' => @$_POST['busca_valor'], 'empresa'=> $_SESSION['empresa_sessao']),
					'5' => array('c' => '4','a' => "6",'coluna' => 'dta_criacao', 'valor' => @$_POST['busca_valor'], 'de' => @$_POST['busca_de'], 'ate' => @$_POST['busca_ate'], 'empresa'=> $_SESSION['empresa_sessao']),
					'6' => array('c' => '1','a' => "6",'coluna' => 'usuario_criacao', 'valor' => @$_POST['busca_valor'], 'empresa'=> $_SESSION['empresa_sessao']),
					'7' => array('c' => '1','a' => "6",'coluna' => 'n_cheque', 'valor' => @$_POST['busca_valor'], 'empresa'=> $_SESSION['empresa_sessao']),
					'8' => array('c' => '5','a' => "8",'coluna' => 'situacao', 'valor' =>(is_array(@$_POST['busca_valor'])) ? implode("," , $_POST['busca_valor']) : "", 'empresa'=> $_SESSION['empresa_sessao']),
					'9' => array('c' => '7','a' => "8",'coluna' => '',  'valor'=> (is_array(@$_POST['busca_valor'])) ? implode("," , $_POST['busca_valor']): "",'empresa'=> $_SESSION['empresa_sessao']),
					'10' => array('c' => '6','a' => "8",'coluna' => '','valor' => '', 'empresa'=> $_SESSION['empresa_sessao'])	
		);
	//	var_dump($busca[$_POST['busca']]);die();
		if(isset($busca[$_POST['busca']])){
			$this->dados = array('lote' => $apiLote->filtroLote($busca[$_POST['busca']]['c'], $busca[$_POST['busca']]['a'], $busca[$_POST['busca']]['coluna'], $busca[$_POST['busca']]['valor'], @$busca[$_POST['busca']]['de'],@$busca[$_POST['busca']]['ate'], $_SESSION['empresa_sessao']));
			$_SESSION['filtro_sessao'] = array('c' => $busca[$_POST['busca']]['c'], 'a' => $busca[$_POST['busca']]['a'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'busca_valor' => $busca[$_POST['busca']]['valor'], 'de' => isset($_POST['busca_de']) ? $_POST['busca_de'] : "", 'ate' => isset($_POST['busca_ate']) ? $_POST['busca_ate'] : "",'busca' => $_POST['busca']);
			$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
		}else{
			unset($_SESSION['filtro_sessao']);
			unset($_SESSION['consulta_sessao']);
			header('location:' .APP_ROOT. 'ptc/index/index/acessonegado');
			die();
		}
	}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				$this->dados = array('lote' => $apiLote->filtroLote($_SESSION['filtro_sessao']['c'],$_SESSION['filtro_sessao']['a'],$_SESSION['filtro_sessao']['coluna'], $_SESSION['filtro_sessao']['busca_valor'], $_SESSION['filtro_sessao']['de'], $_SESSION['filtro_sessao']['ate'], $_SESSION['empresa_sessao']));
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('lote' => $apiLote->filtroLote('7','8','',$_SESSION['empresa_sessao']));		
					$_SESSION['filtro_sessao'] = array('c' => '7', 'a' => '8', 'coluna' => '' , 'busca_valor' => $_SESSION['empresa_sessao'], 'de' => "", 'ate' => "", 'busca' => '10');
					$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}
		}
		$TotalItem = (is_array($this->dados['lote']) ? count($this->dados['lote']) : 0);
		$this->dados['lote'] = array_chunk($this->dados['lote'], $ItemPorPagina);
		@$this->dados['lote'] = $this->dados['lote'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		    
		}

		$this->view();
	}
	
	public function adicionar(){
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Cadastro de Lote";
		$apiUsuario = new apiUsuario();
		$this->usuario = $apiUsuario->filtroUsuario('1','1','usuario', $_SESSION['usuario_sessao']);
		$apiEmpresa = new apiEmpresa();
		$this->empresa = $apiEmpresa->filtroEmpresa('3', '1','','');
		$empresa = new Empresa();
		$empresa->empresa = $_SESSION['empresa_sessao'];
		$this->empresa_sessao = $apiEmpresa->getEmpresa($empresa);
		$this->des_empresa = $this->empresa_sessao->DES_EMPRESA;
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$Post = new Lote('POST');
			$Post->empresa_origem  = $_SESSION['empresa_sessao'];
			$Post->dta_criacao     = date("d/m/Y");
			$Post->usuario_criacao = $_SESSION['usuario_sessao'];
			$Post->situacao        = '0';
			$apiLote = new apiLote();
			$rs = $apiLote->filtroLote('1','6','lote',$Post->lote);
			if($Post->empresa_destino == $Post->empresa_origem){
				$this->rollback = new Lote('POST');
				$this->Alert = "Empresa de Origem igual a empresa de Destino";
			}elseif ((is_array($rs) ? count($rs) : 0) > 0){
				$this->rollback = new Lote('POST');
				$this->Alert = "J� existe um Lote com esse id cadastrado!";
			}else{	
				$sql[$i] = $apiLote->addLote($Post);
				$i = $i+1;
				$log = new Log();
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico = "LOTE||{$Post->lote};;SITUACAO||{$Post->situacao};;N_CHEQUES||{$Post->n_cheque};;EMPRESA_DESTINO||{$Post->empresa_destino}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiLote->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'ptc/lote/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'ptc/lote/index/sucesso');
					}
				}else{
					$this->rollback = new Lote('POST');
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		
		$this->view();
	}
	
	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Altera��o de Lote";
		$lote = new Lote();
		$lote->lote = $this->getParams(0);
		$this->getParams(0);
		$apiLote = new apiLote();
		$this->dados = array('lote' => $apiLote->getLote($lote));
		$origem = new Origem();
		$apiOrigem = new apiOrigem();
		$this->origem =  $apiOrigem->getOrigem();
		$motivo = new Motivo();
		$apiMotivo = new apiMotivo();
		$this->motivo = $apiMotivo->getMotivo();
		$this->usuario = $_SESSION['usuario_sessao'];
		$this->empresa = $_SESSION['empresa_sessao'];
		//--------------------Adicionar Cheque-----------------//
		$apiCheque = new apiCheque();
		$this->cheque = $apiCheque->getCheque($lote);
		if( $this->usuario == $this->dados['lote']->USUARIO_CRIACAO && $this->empresa == $this->dados['lote']->EMPRESA_ORIGEM){
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$anterior = "";
			$atual = "::";
			$funcoes = new Funcoes();
			$sql = array();
			$Post = new Lote();
			$Post_cheque = new Cheque();
			$Post->lote = $this->getParams(0);
			$this->lote =  $apiLote->getLote($lote);

		    if ($_POST['submeter'] == "alterar"){
		    	$tamanho = (is_array($_POST['cmc7']) ? count($_POST['cmc7']) : 0);
				if($tamanho > 0){
					for ($a = 0; $a < $tamanho; $a++){
						$funcoes = new Funcoes();
						$Post_cheque->cheque           	= "<str>".str_replace(" ", "", $_POST['cmc7'][$a]);
						$Post_cheque->cliente_cpfcnpj  	= "<str>". $funcoes->naoNumerico($_POST['cpf_cnpj'][$a]);
						$Post_cheque->valor 		    = $funcoes->sanearValor($_POST['valor'][$a]);
						$Post_cheque->origem		 	= $_POST['origem'][$a];
						$Post_cheque->motivo 			= $_POST['motivo'][$a];
						$Post_cheque->dta_vencimento	= $_POST['date'][$a];
						$Post_cheque->conciliado        = 'n';
						$Post_cheque->cliente_nome      = $funcoes->retiraAcentos($_POST['cliente'][$a]);
						if (is_numeric($Post_cheque->cliente_nome)){
							$apiApollo = new apiApollo();
							$cliente_nome  = $apiApollo->getClienteApollo($Post_cheque->cliente_nome);
							$Post_cheque->cliente_nome  = $cliente_nome[0]->NOME;
						}
						$Post_cheque->forma = $_POST['forma'][$a];
						@$valortotal = $valortotal + $Post_cheque->valor;
						$Post_cheque->lote  = $this->getParams(0);
						$sql[$i] = $apiCheque->addCheque($Post_cheque);
						$i = $i+1;
						$val_lote = $funcoes->sanearValor($this->lote->VAL_LOTE);
						$valortotal = $val_lote + @$valortotal;
						$lote->val_lote = $valortotal;
						$sql[$i] = $apiLote->valorLote($lote);
						$i = $i+1;
						$log = new Log();
						$log->usuario = $_SESSION['usuario_sessao'];
						$log->modulo = $this->getModule()['modulo'];
						$log->controle = $this->getController()['controle'];
						$log->acao = $this->getAction()['acao'];
						$log->empresa = $_SESSION['empresa_sessao'];
						$log->tipo = "A";
						$log->dta_registro = date("d/m/Y H:i:s");
						$log->historico = "LOTE||{$lote->lote};;CHEQUE||{$Post_cheque->cheque};;
						VALOR{$Post_cheque->valor};;VAL_LOTE||{$lote->val_lote};;VAL_RECEPCAO||{$lote->val_recepcao};;
						ORIGEM||{$Post_cheque->origem};;MOTIVO||{$Post_cheque->motivo}";
						$apiLog = new apiLog();
						$sql[$i] = $apiLog->addLog($log);
						$i= $i+1;
						$rs = $apiCheque->executeSQL($sql);
						if (@$rs[4] == 'sucesso') {
							header('location:' .APP_ROOT. 'ptc/lote/alterar/'.$this->dados['lote']->LOTE.'/sucesso');
						}else{
							$this->rollback = new Cheque();
							$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
							$erro = str_replace($retirar, "", $rs[2]);
							$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
						}
					}
					
					
				}
		    }elseif ($_POST['submeter'] == "fechar"){
		    $count_cheque = $apiCheque->countCheque($lote);
		    $count_cheque['0']->COUNT_CHEQUE;
		    $this->dados['lote']->N_CHEQUE;
		    if($this->dados['lote']->N_CHEQUE > $count_cheque['0']->COUNT_CHEQUE){
		        $this->Alert = "A quantidade de cheques informados ({$this->dados['lote']->N_CHEQUE}) no lote n�o corresponde a quantidade de cheques inseridas ({$count_cheque['0']->COUNT_CHEQUE})";  
		    }elseif($this->dados['lote']->N_CHEQUE < $count_cheque['0']->COUNT_CHEQUE){
		    	$this->Alert = "A quantidade de cheques informados ({$this->dados['lote']->N_CHEQUE}) no lote n�o corresponde a quantidade de cheques inseridas ({$count_cheque['0']->COUNT_CHEQUE})";
		    }else{
		    	$lote->situacao = '1';
		    	$sql[$i] = $apiLote->fechamentoLote($lote);
		    	$rs = $apiCheque->executeSQL($sql);
		    	if (@$rs[4] == 'sucesso') {
		    		header('location:' .APP_ROOT. 'ptc/lote/index/'.$this->dados['lote']->LOTE.'/sucesso');
		    	}else {
		    		header('location:' .APP_ROOT. 'ptc/lote/index/insucesso');
		    	}
		    }
		    }elseif ($_POST['submeter'] == "imprimir"){
		    	$qtd_diferente = $this->dados['lote']->N_CHEQUE - $this->dados['lote']->N_CHEQUE_RECEPCAO;
		    	$val_lote = number_format(str_replace(",", ".", $this->dados['lote']->VAL_LOTE), 2, ",", ".");
		    	if($this->dados['lote']->VAL_RECEPCAO != NULL){
		    	$val_recepcao = number_format(str_replace(",", ".", $this->dados['lote']->VAL_RECEPCAO), 2, ",", ".");
		    	}else{
		    		$val_recepcao = '0';
		    	}
		    	$val_diferente = $funcoes->sanearValor($val_lote) - $funcoes->sanearValor($val_recepcao);
		    	$val_diferente = number_format(str_replace(",", ".", $val_diferente), 2, ",", ".");
		    	$situacao = $this->dados['lote']->SITUACAO;
		    	if($situacao == '0'){
		    		$situacao = "Aberto";
		    	}else if($situacao == '1'){
		    		$situacao = "Fechado";
		    	}else if($situacao == '2'){
		    		$situacao = "Pendente";
		    	}else if($situacao == '3'){
		    		$situacao = "Concluido";
		    	}else{
		    		$situacao = "Cancelado";
		    	}
		    	$pdf = new \PDF_HTML();
		    	$pdf->AddPage();
		    	$pdf->SetLineWidth(0.4);
		    	$pdf->Rect(4, 10, 202, 270, 'D');
		    	$pdf->SetMargins(4, 4, 4);
		    	//-----------Cabe�alho------------------//
		    	$pdf->Image(APP_ROOT."content/geral/img/gmf.png",90,15,31,33);
		    	$pdf->Ln(45);
		    	$pdf->SetFont('arial','B',15);
		    	$pdf->Cell(202,6,"LOTE",0,0,'C');
		    	$pdf->Ln(20);
		    	//---------------Informa��es do Lote-------//
		    	//-------------------Origem----------------//
		    	$pdf->Cell(0,0,"","T",1,'L');
		    	
		    	$pdf->SetFont("arial", "B",10);
		    	$pdf->Cell(76,4,"ORIGEM","B",0,'L');

		    	$pdf->SetFont("arial", "B",10);
		    	$pdf->Cell(70,4,"DESTINO","B",0,'L');

		    	$pdf->SetFont("arial", "B",10);
		    	$pdf->Cell(41,4,"SITUACAO","B",1,'L');
		        
		    	$pdf->Cell(0,0,"","T",1,'L');
		    	$pdf->Ln(2);
		    	
		    	$pdf->SetFont("arial","B",10);
		    	$pdf->Cell(12,4,"Lote:",0,0,'L');
		    	$pdf->SetFont("arial",'',9);
		    	$pdf->Cell(64,4,"{$this->dados['lote']->LOTE}",0,0,'L');
		    	
		    	$pdf->SetFont("arial","B",10);
		    	$pdf->Cell(10,4,"Lote:",0,0,'L');
		    	$pdf->SetFont("arial",'',9);
		    	$pdf->Cell(54,4,"{$this->dados['lote']->LOTE}",0,1,'L');

		    	$pdf->SetFont("arial","B",10);
		    	$pdf->Cell(47,4,"Qtd de Cheques Enviados:",0,0,'L');
		    	$pdf->SetFont("arial",'',9);
		    	$pdf->Cell(29,4,"{$this->dados['lote']->N_CHEQUE}",0,0,'L');
		    	
		    	$pdf->SetFont("arial","B",10);
		    	$pdf->Cell(48,4,"Qtd de Cheques Recebidos:",0,0,'L');
		    	$pdf->SetFont("arial",'',9);
		    	$pdf->Cell(45,4,"{$this->dados['lote']->N_CHEQUE_RECEPCAO}",0,1,'L');
		    	
		    	$pdf->SetFont("arial","B",10);
		    	$pdf->Cell(18,4,"Empresa:",0,0,'L');
		    	$pdf->SetFont("arial",'',9);
		    	$pdf->Cell(58,4,"{$this->dados['lote']->DES_EMPRESA_ORIGEM}",0,0,'L');
		    	
		    	$pdf->SetFont("arial","B",10);
		    	$pdf->Cell(18,4,"Empresa:",0,0,'L');
		    	$pdf->SetFont("arial",'',9);
		    	$pdf->Cell(52,4,"{$this->dados['lote']->DES_EMPRESA_DESTINO}",0,0,'L');
		    	
		    	$pdf->SetFont("arial","B",10);
		    	$pdf->Cell(18,4,"Situacao:",0,0,'L');
		    	$pdf->SetFont("arial",'',9);
		    	$pdf->Cell(26,4,"{$situacao}",0,1,'L');
		    	
		    	$pdf->SetFont("arial","B",10);
		    	$pdf->Cell(15,4,"Data:",0,0,'L');
		    	$pdf->SetFont("arial",'',9);
		    	$pdf->Cell(61,4,"{$this->dados['lote']->DTA_CRIACAO}",0,0,'L');
		    	
		    	$pdf->SetFont("arial","B",10);
		    	$pdf->Cell(15,4,"Data:",0,0,'L');
		    	$pdf->SetFont("arial",'',9);
		    	$pdf->Cell(55,4,"{$this->dados['lote']->DTA_RECEPCAO}",0,0,'L');
		    	
		    	$pdf->SetFont("arial","B",10);
		    	$pdf->Cell(24,4,"Qtd diferente:",0,0,'L');
		    	$pdf->SetFont("arial",'',9);
		    	$pdf->Cell(45,4,"{$qtd_diferente}",0,1,'L');
		    	
		    	$pdf->SetFont("arial","B",10);
		    	$pdf->Cell(16,4,"Usuario:",0,0,'L');
		    	$pdf->SetFont("arial",'',9);
		    	$pdf->Cell(60,4,"{$this->dados['lote']->USUARIO_CRIACAO}",0,0,'L');
		    	
		    	$pdf->SetFont("arial","B",10);
		    	$pdf->Cell(15,4,"Usuario:",0,0,'L');
		    	$pdf->SetFont("arial",'',9);
		    	$pdf->Cell(55,4,"{$this->dados['lote']->USUARIO_RECEPCAO}",0,0,'L');
		    	
		    	$pdf->SetFont("arial","B",10);
		    	$pdf->Cell(27,4,"Valor diferente:",0,0,'L');
		    	$pdf->SetFont("arial",'',9);
		    	$pdf->Cell(45,4,"{$val_diferente}",0,1,'L');
		    	
		    	$pdf->SetFont("arial","B",10);
		    	$pdf->Cell(25,4,"Valor do Lote:",0,0,'L');
		    	$pdf->SetFont("arial",'',9);
		    	$pdf->Cell(51,4,"{$val_lote}",0,0,'L');
		    	
		    	$pdf->SetFont("arial","B",10);
		    	$pdf->Cell(28,4,"Valor Recebido:",0,0,'L');
		    	$pdf->SetFont("arial",'',9);
		    	$pdf->Cell(45,4,"{$val_recepcao}",0,1,'L');
		    	$pdf->Ln(2);
		    	$pdf->Cell(0,0,"","B",1,'L');
		    	$pdf->Ln(30);
		    	
		    	//-----------Tabela---------------//
		    	$pdf->Ln(3);
		    	$pdf->SetMargins(14, 14, 14);
		    	$pdf->SetWidths(array(20,20,20,20,20,27,27,27));
		    	$pdf->Row(array());
		    	$pdf->Row(array('N�Cheque','Cliente','Valor','Origem','Vencimento','Data Concilia��o','Motivo','Situacao'),'arial',8,'B');
		    	foreach($this->cheque as $cheque){
		    		if($cheque->CONCILIADO == 's'){
		    			$cheque->CONCILIADO = 'CONCILIADO';
		    		}else{
		    			$cheque->CONCILIADO = 'N�O CONCILIADO';
		    		}
		    		$valor = number_format(str_replace(",", ".", $cheque->VALOR), 2, ",", ".");
		    		$pdf->Row(array($cheque->CHEQUE, $cheque->CLIENTE_NOME, $valor, $cheque->DES_ORIGEM, $cheque->DTA_VENCIMENTO, $cheque->DTA_VENCIMENTO, $cheque->DES_MOTIVO, $cheque->CONCILIADO),'arial',7,'');
		    	}
    	
		    /*	$pdf->SetMargins(16, 16, 16);
		    	$pdf->SetFont("arial","B",14);
		    	$pdf->Cell(202,4, "CHEQUES", 0, 1, 'C');
		    	$pdf->SetFont("arial","B", 9);
		    	$hmtl = '<img src="http://teste.com.br/sismonaco/content/geral/img/checked.png';
		    	$html ='<table>
							<thead>
								<tr>
								    <td><b>N� DO CHEQUE</b></td>
								    <td>CLIENTE</td>
								    <td>VALOR</td>
								    <td>ORIGEM</td>
								    <td>VENCIMENTO</td>
									<td>DATA CONCILIACAO</td>
									<td>MOTIVO</td>
									<td>SITUACAO</td>
								</tr>
		    				</thead>';
		    	$valortotal = 0;
		    	if ((is_array($this->cheque) ? count($this->cheque) : 0) > 0) {
		    	foreach($this->cheque as $cheque){
		    		if($cheque->CONCILIADO == 's'){
		    			$cheque->CONCILIADO = 'CONCILIADO';
		    		}else{
		    			$cheque->CONCILIADO = 'N�O CONCILIADO';
		    		}
		    		$valor = number_format(str_replace(",", ".", $cheque->VALOR), 2, ",", ".");
		    		$html .="<tr>
		    		<td>{$cheque->CHEQUE}</td>
		    		<td>{$cheque->CLIENTE_NOME}</td>
		    		<td>{$valor}</td>
		    		<td>{$cheque->DES_ORIGEM}</td>
		    		<td>{$cheque->DTA_VENCIMENTO}</td>
		    		<td>{$cheque->DTA_CONCILIACAO}</td>
		    		<td>{$cheque->DES_MOTIVO}</td>
		    		<td>{$cheque->CONCILIADO}</td>
		    		</tr>";
		    	}
		    	}
		    	$html .= '</table>';*/
		    //	$pdf->WriteHTML($html);
		    	//$pdf->WriteHTML($html, $parsed);
		    	//$pdf->MultiCell(194,4,$parsed,0,'C',false);
		    	//$pdf->WriteHTML($html);
		    	
		    	$pdf->Output("{$this->dados['lote']->LOTE}-".date("d-m-Y").".pdf","D");
		    }	
			}
		}elseif ($this->dados['lote']->SITUACAO == '1' || $this->dados['lote']->SITUACAO == '2' || $this->dados['lote']->SITUACAO == '3' && ($this->usuario != $this->dados['lote']->USUARIO_CRIACAO && $this->empresa == $this->dados['lote']->EMPRESA_DESTINO)){
		$this->header = "Recebimento de Lotes";
		$apiCheque = new apiCheque();
		$cheque    = new Cheque();
		$apiLote   = new apiLote();
		$lote = new Lote();
		$lote->lote = $this->getParams(0);//Pega o Id do Lote
		$this->dados = array('lote' => $apiLote->getLote($lote));//Pega os dados do Lote e coloca em um array
		$this->cheque = array('cheque' => $apiCheque->getCheque($lote));//Pega os dados do Lote e coloca em um array
		$apiUsuario = new apiUsuario();
		$this->usuario = $_SESSION['usuario_sessao'];//Pega o Id do usu�rio Logado
		$apiEmpresa = new apiEmpresa();
		$this->empresa = $_SESSION['empresa_sessao'];//Pega o Id da empresa que o usu�rio t� logado
		$ItemPorPagina = 1;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		
		if ($_SERVER['REQUEST_METHOD'] === 'POST' ) {
			$i = 0;
			$sql = array();
			$funcoes = new Funcoes();
			$cheque->lote   = $_POST['id'];
			$n_campos = $_POST["n_campos"];
			$lote->lote = $cheque->lote;
			$rs_lote = $apiLote->getLote($lote);
			$cont = 0;
			$valor = 0;
			//Conta o n�mero de campos para conciliar
			if($n_campos > 0){
				for ($t = 0; $t<$n_campos; $t++){
					$cont = $cont + 1;
					$cheque->cheque = $_POST['cheq'][$t];
					$rs_cheque = $apiCheque->getChequeUnidade($cheque,$lote);
					$valor = $funcoes->sanearValor($rs_cheque['0']->VALOR) + $funcoes->sanearValor($valor);
					
					$cheque->conciliado = "s";
					$cheque->dta_conciliacao = date("d/m/Y");
					$sql[$i]= $apiCheque->conciliaCheque($cheque);
					$i = $i+1;
					//$rs = $apiCheque->executeSQL($sql);
				}
				if($rs_lote->DTA_RECEPCAO != NULL){
					$lote->n_cheque_recepcao = ($rs_lote->N_CHEQUE_RECEPCAO + $cont);
					$lote->val_recepcao = $funcoes->sanearValor($rs_lote->VAL_RECEPCAO) + $funcoes->sanearValor($valor);
				//	var_dump($lote->val_recepcao);die();
					$conciliacao = $apiCheque->checarConciliacao($lote);
					$i=$i+1;
					$resultado = (is_array($conciliacao) ? count($conciliacao) : 0);
					$sql[$i] = $apiLote->loteRecebido($lote);
					$i=$i+1;
				//	var_dump($cont);die();
					if($resultado != $cont){
						$lote->situacao = "2";
						$sql[$i]=$apiLote->situacaoLote($lote);
						$i=$i+1;
					}else{
						$lote->situacao = "3";
						$sql[$i] = $apiLote->situacaoLote($lote);
						$i=$i+1;
					}
					
				}else{
					$lote->n_cheque_recepcao = $cont;
					$lote->val_recepcao = $valor;
					$conciliacao = $apiCheque->checarConciliacao($lote);
					$resultado = (is_array($conciliacao) ? count($conciliacao) : 0);
					$lote->dta_recepcao = date("d/m/Y");
					$lote->usuario_recepcao = $_SESSION['usuario_sessao'];
					$sql[$i] = $apiLote->loteRecebido($lote);
					$i=$i+1;
				//	var_dump($cont);die();
					if($resultado != $cont){
						$lote->situacao = "2";
						$sql[$i] = $apiLote->situacaoLote($lote);
					}else{
						$lote->situacao = "3";
						$sql[$i] = $apiLote->situacaoLote($lote);
						
					}
				}
				$rs = $apiLote->executeSQL($sql);
				//	var_dump($rs3);die();
				if(@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)){
						header('location:' .APP_ROOT. 'ptc/lote/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else{
						header('location:' .APP_ROOT. 'ptc/lote/index/sucesso');
					}
				}else{
					$this->rollback = new LOTE('POST');
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}else{
				header('location:' .APP_ROOT. 'ptc/lote/index/insucesso');
			}
		}else{
			//$id = $this->getParams(0);
			$rs = $apiLote->getLote($lote);
			if($rs->EMPRESA_DESTINO == $this->empresa){
				$this->rs_cheque = $apiCheque->getCheque($lote);
				$this->lote = $rs;
			}else{
				header('location:' .APP_ROOT. 'ptc/lote/index/sucesso');
			}
		}
		$TotalItem = (is_array($this->dados['cheque']) ? count($this->dados['cheque']) : 0);
		$this->cheque['cheque'] = array_chunk($this->cheque['cheque'], $ItemPorPagina);
		@$this->cheque['cheque'] = $this->cheque['cheque'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
	}
		
		$this->view();
	}
	
	public function excluir() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Cancelamento de Lote";
		$lote = new Lote();
		$lote->lote = $this->getParams(0);
		$apiLote = new apiLote();
		$this->dados = array('lote' => $apiLote->getLote($lote));
		
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
			
		}
		
		if ($_SERVER['REQUEST_METHOD'] === 'POST'){
			$i = 0;
			$sql = array();
			$lote->situacao = '4';
			$sql[$i] = $apiLote->cancelaLote($lote);
			$i = $i+1;
			$log = new Log();
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "E";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico = "LOTE||{$this->dados['lote']->LOTE};;USUARIO_CRIACAO||{$this->dados['lote']->USUARIO_CRIACAO};;VALOR||{$this->dados['lote']->VAL_LOTE}";
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiLote->executeSQL($sql);
			if (@$rs[4] == 'sucesso'){
				if (isset($this->PaginaAtual)){
				    header('location:' .APP_ROOT. 'ptc/lote/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'ptc/lote/index/sucesso');
				}
			}else{
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}
		//var_dump($this->dados);die();
		$this->view();
	}
	
	public function cliente() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Consulta de Cliente";
		$this->acao = $this->getParams(0);
		$this->id = substr($this->getParams(0), 3);
		$apiApollo = new apiApollo();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$this->id   = $_POST['id'];
			$filtro = $_POST["filtro"];
			$campo  = $_POST["campo"];
			$this->dados = array('cliente' => $apiApollo->filtroClienteApollo($campo, $filtro));
		}
		
		
		
		
		$this->view();
	}
	
}

