<?php

namespace controller\ptc;

use lib\Controller;
use helper\Security;

class indexController extends Controller {

	public function __construct() {

		parent::__construct();

		new Security($this->getModule(),$this->getController(),$this->getAction());
	}

	public function index() {

		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Protocolo de Transfer�ncia de Cheques";
		unset($_SESSION['filtro_sessao']);
		unset($_SESSION['consulta_sessao']);
		$this->view();
		
	}
}