<?php

namespace controller\help;

use lib\Controller;
use helper\Security;
use api\help\apiSubcategoria;
use api\help\apiTecnico;
use helper\Paginator;
use obj\help\Subcategoria;
use obj\geral\Log;
use api\geral\apiLog;
use api\help\apiCategoria;
use helper\Funcoes;


class subcategoriaController extends Controller {
	
	public function __construct() {
		
		parent::__construct();
		
		new Security($this->getModule(),$this->getController(),$this->getAction());
	}
	
	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Lista de Subcategoria";
		$apiSubcategoria = new apiSubcategoria();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		$apiTecnico = new apiTecnico();
		$this->tecnico = $apiTecnico->filtroTecnico('1', '3', 't.tecnico', $_SESSION['usuario_sessao'],'tudo');
		foreach ($this->tecnico as $rs){
			$this->ambiente[$rs->AMBIENTE] = array('ambiente' => $rs->AMBIENTE, 'des_ambiente' => $rs->DES_AMBIENTE);
		}	
		(!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])) ? $a = '1' : $a = '3';
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$busca = array(
				'1' => array('c' => '1','a' => $a,'coluna' => 's.ativo', 'valor' => '1', 'ambiente' =>  $_POST['ambiente']),
				'2' => array('c' => '1','a' => $a,'coluna' => 's.ativo', 'valor' => '0', 'ambiente' =>  $_POST['ambiente']),
				'3' => array('c' => '2','a' => $a,'coluna' => 's.des_subcategoria', 'valor' => @$_POST['busca_valor'], 'ambiente' =>  $_POST['ambiente']),
				'4' => array('c' => '2','a' => $a,'coluna' => 'c.des_categoria', 'valor' => @$_POST['busca_valor'], 'ambiente' =>  $_POST['ambiente'])
			);
			if(isset($busca[$_POST['busca']])){
				$this->dados = array('subcategoria' => $apiSubcategoria->filtroSubcategoria($busca[$_POST['busca']]['c'], $busca[$_POST['busca']]['a'], $busca[$_POST['busca']]['coluna'], $busca[$_POST['busca']]['valor'], $busca[$_POST['busca']]['ambiente']));
				$_SESSION['filtro_sessao'] = array('c' => $busca[$_POST['busca']]['c'], 'a' => $busca[$_POST['busca']]['a'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'busca_valor' => $busca[$_POST['busca']]['valor'], 'ambiente' => $busca[$_POST['busca']]['ambiente'], 'busca' => $_POST['busca']);
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'help/index/index/acessonegado');
				die();
			}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				$this->dados = array('subcategoria' => $apiSubcategoria->filtroSubcategoria($_SESSION['filtro_sessao']['c'],$_SESSION['filtro_sessao']['a'],$_SESSION['filtro_sessao']['coluna'], $_SESSION['filtro_sessao']['busca_valor'], $_SESSION['filtro_sessao']['ambiente']));
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('subcategoria' => $apiSubcategoria->filtroSubcategoria('1','3','s.ativo', '1', @$this->ambiente[$this->tecnico[0]->AMBIENTE]['ambiente']));
					$_SESSION['filtro_sessao'] = array('c' => '1', 'a' => '3', 'coluna' => 's.ativo' , 'busca_valor' => '1', 'ambiente' => @$this->ambiente[$this->tecnico[0]->AMBIENTE]['ambiente'],'busca' => '1');
					$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}
		}
		$TotalItem = (is_array($this->dados['subcategoria']) ? count($this->dados['subcategoria']) : 0);
		$this->dados['subcategoria'] = array_chunk($this->dados['subcategoria'], $ItemPorPagina);
		@$this->dados['subcategoria'] = $this->dados['subcategoria'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->view();
	}
	
	public function adicionar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Cadastro de Subcategoria";
		$apiSubcategoria = new apiSubcategoria();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		$apiTecnico = new apiTecnico();
		$this->tecnico = $apiTecnico->filtroTecnico('1', '3', 't.tecnico', $_SESSION['usuario_sessao'],'tudo');
		foreach ($this->tecnico as $rs){
			$this->ambiente[$rs->AMBIENTE] = array('ambiente' => $rs->AMBIENTE, 'des_ambiente' => $rs->DES_AMBIENTE);
		}
		$va = "('".implode("','", array_keys((array) $this->ambiente))."')";
		$apiCategoria = new apiCategoria();
		$this->categoria = $apiCategoria->filtroCategoria('4','3','c.ambiente', $va,'tudo');
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$array = array();
			$funcoes = new Funcoes();
			$categoria = $_POST['categoria'];
			$des_subcategoria = $_POST['des_subcategoria'];
			$tempo_atendimento = $_POST['tempo_atendimento'];
			$apiSubcategoria = new apiSubcategoria();
			$subcategoria = new Subcategoria();
			$condicao = "";
			$a = 0;
			foreach ($categoria as $rs => $va) {
				$des_sub = strtoupper($funcoes->retiraAcentos(trim($des_subcategoria[$rs])));
				$condicao .= "(s.categoria = '{$va}' AND UPPER(s.des_subcategoria) = '{$des_sub}') OR ";
				$this->rollback[$a] = array('categoria' => $va, 'des_subcategoria' => $des_sub, 'tempo_atendimento' => $tempo_atendimento[$rs]);
				$a = $a + 1;
			}
			$rs = $apiSubcategoria->consultaSubcategoria(substr($condicao,0,-3));
			if ((is_array($rs) ? count($rs) : 0) > 0){
				$this->Alert = "<br>";
				foreach ($rs as $rs) {
					$this->Alert .= "J� existe a Sub-Categoria: {$rs->DES_SUBCATEGORIA} Cadastrada nessa Categoria: {$rs->DES_CATEGORIA}! <br>";
				}
			}else{
				$log = new Log();
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				$apiLog = new apiLog();
				$subcategoria->ativo = 1;
				foreach ($this->rollback as $rs) {
					$subcategoria->categoria = $rs['categoria'];
					$subcategoria->des_subcategoria = $rs['des_subcategoria'];
					$subcategoria->tempo_atendimento = $rs['tempo_atendimento'];
					$sql[$i] = $apiSubcategoria->addSubcategoria($subcategoria);
					$i = $i+1;
					$log->historico = "DES_SUBCATEGORIA||{$subcategoria->des_subcategoria};;CATEGORIA||{$subcategoria->categoria};;TEMPO_ATENDIMENTO||{$subcategoria->tempo_atendimento};;ATIVO||{$subcategoria->ativo}";
					$sql[$i] = $apiLog->addLog($log);
					$i = $i+1;
				}
				$rs = $apiSubcategoria->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'help/subcategoria/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'help/subcategoria/index/sucesso');
					}
				}else{
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		
		$this->view();
	}
	
	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Altera��o de Subcategoria";
		$subcategoria = new Subcategoria();
		$subcategoria->subcategoria = $this->getParams(0);
		$apiSubcategoria = new apiSubcategoria();
		$this->dados = array('subcategoria' => $apiSubcategoria->getSubcategoria($subcategoria));
		if (isset($this->dados['subcategoria'])){
			if ($this->dados['subcategoria']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'help/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'help/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		$apiTecnico = new apiTecnico();
		$this->tecnico = $apiTecnico->filtroTecnico('1', '3', 't.tecnico', $_SESSION['usuario_sessao'],'tudo');
		foreach ($this->tecnico as $rs){
			$this->ambiente[$rs->AMBIENTE] = array('ambiente' => $rs->AMBIENTE, 'des_ambiente' => $rs->DES_AMBIENTE);
		}
		$va = "('".implode("','", array_keys((array) $this->ambiente))."')";
		$apiCategoria = new apiCategoria();
		$this->categoria = $apiCategoria->filtroCategoria('4','3','c.ambiente', $va,'tudo');
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$Post = new Subcategoria('POST');
			$Post->subcategoria = $this->getParams(0);
			$rs = $apiSubcategoria->filtroSubcategoria('1','3','des_subcategoria',$Post->des_subcategoria, $Post->categoria);
			$log = new Log();
			$log->historico = "DES_SUBCATEGORIA||{$this->dados['subcategoria']->DES_SUBCATEGORIA};;CATEGORIA||{$this->dados['subcategoria']->CATEGORIA};;TEMPO_ATENDIMENTO||{$this->dados['subcategoria']->TEMPO_ATENDIMENTO};;ATIVO||{$this->dados['subcategoria']->ATIVO}";
			if ((is_array($rs) ? count($rs) : 0) > 0 && ($rs[0]->DES_SUBCATEGORIA != $this->dados['subcategoria']->DES_SUBCATEGORIA || $rs[0]->CATEGORIA != $this->dados['subcategoria']->CATEGORIA)){
				$this->dados['subcategoria']->DES_SUBCATEGORIA = $Post->des_subcategoria;
				$this->dados['subcategoria']->CATEGORIA = $Post->categoria;
				$this->dados['subcategoria']->ATIVO = $Post->ativo;
				$this->Alert = "J� existe uma subcategoria com esse nome vinculada a essa categoria cadastrada!";
			}else{
				$sql[$i] = $apiSubcategoria->editSubcategoria($Post);
				$i = $i+1;
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "A";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico .= "::DES_SUBCATEGORIA||{$Post->des_subcategoria};;CATEGORIA||{$Post->categoria};;TEMPO_ATENDIMENTO||{$Post->tempo_atendimento};;ATIVO||{$Post->ativo}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiSubcategoria->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'help/subcategoria/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'help/subcategoria/index/sucesso');
					}
				}else{
					$this->dados['subcategoria']->DES_SUBCATEGORIA = $Post->des_subcategoria;
					$this->dados['subcategoria']->CATEGORIA = $Post->categoria;
					$this->dados['subcategoria']->ATIVO = $Post->ativo;
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		$this->view();
	}
	public function excluir() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Exclus�o de Subcategoria";
		$subcategoria = new Subcategoria();
		$subcategoria->subcategoria = $this->getParams(0);
		$apiSubcategoria = new apiSubcategoria();
		$this->dados = array('subcategoria' => $apiSubcategoria->getSubcategoria($subcategoria));
		if (isset($this->dados['subcategoria'])){
			if ($this->dados['subcategoria']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'help/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'help/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$sql[$i] = $apiSubcategoria->delSubcategoria($subcategoria);
			$i = $i+1;
			$log = new Log();
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "E";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico = "SUBCATEGORIA||{$this->dados['subcategoria']->SUBCATEGORIA};;DES_SUBCATEGORIA||{$this->dados['subcategoria']->DES_SUBCATEGORIA};;CATEGORIA||{$this->dados['subcategoria']->CATEGORIA};;TEMPO_ATENDIMENTO||{$this->dados['subcategoria']->TEMPO_ATENDIMENTO};;ATIVO||{$this->dados['subcategoria']->ATIVO}";
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiSubcategoria->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'help/subcategoria/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'help/subcategoria/index/sucesso');
				}
			}else{
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}
		$this->view();
	}
}