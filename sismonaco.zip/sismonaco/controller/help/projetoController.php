<?php

namespace controller\help;

use lib\Controller;
use helper\Security;
use api\help\apiProjeto;
use helper\Paginator;
use obj\help\Projeto;
use obj\geral\Log;
use api\geral\apiLog;
use api\help\apiTecnico;

class projetoController extends Controller {
	
	public function __construct() {
		
		parent::__construct();
		
		new Security($this->getModule(),$this->getController(),$this->getAction());
	}
	
	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Lista de Projeto";
		$apiProjeto = new apiProjeto();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		$apiTecnico = new apiTecnico();
		$this->tecnico = $apiTecnico->filtroTecnico('1', '3', 't.ativo', '1', '1');
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$busca = array(
				'1' => array('c' => '1', 'ano' => @$_POST['ano'], 'mes' => @$_POST['mes'], 'tecnico' => @$_POST['tecnico']),
				'2' => array('c' => '2', 'ano' => @$_POST['ano'], 'mes' => @$_POST['mes']),
				'3' => array('c' => '3', 'tecnico' => @$_POST['tecnico']),
				'4' => array('c' => '4', 'ano' => "", 'mes' => "", 'tecnico' => "")
			);
			if(isset($busca[$_POST['busca']])){
				$this->dados = array('projeto' => $apiProjeto->filtroProjeto($busca[$_POST['busca']]['c'], $busca[$_POST['busca']]['ano'], $busca[$_POST['busca']]['mes'], $busca[$_POST['busca']]['tecnico']));
				$_SESSION['filtro_sessao'] = array('c' => $busca[$_POST['busca']]['c'], 'ano' => $busca[$_POST['busca']]['ano'], 'mes' => $busca[$_POST['busca']]['mes'], 'tecnico' => $busca[$_POST['busca']]['tecnico'], 'busca' => $_POST['busca']);
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'help/index/index/acessonegado');
				die();
			}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				$this->dados = array('projeto' => $apiProjeto->filtroProjeto($_SESSION['filtro_sessao']['c'], $_SESSION['filtro_sessao']['ano'], $_SESSION['filtro_sessao']['mes'], $_SESSION['filtro_sessao']['tecnico']));
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('projeto' => $apiProjeto->filtroProjeto('4'));
					$_SESSION['filtro_sessao'] = array('c' => '4', 'ano' => '', 'mes' => '', 'busca' => '4', 'tecnico' => '');
					$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}
		}
		$TotalItem = (is_array($this->dados['projeto']) ? count($this->dados['projeto']) : 0);
		$this->dados['projeto'] = array_chunk($this->dados['projeto'], $ItemPorPagina);
		@$this->dados['projeto'] = $this->dados['projeto'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->view();
	}
	
	public function adicionar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Cadastro de Projeto";
		$apiProjeto = new apiProjeto();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		$apiTecnico = new apiTecnico();
		$this->tecnico = $apiTecnico->filtroTecnico('1', '3', 't.ativo', '1', '1');
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$array = array();
			$condicao = "";
			$a = 0;
			$ano = $_POST['ano'];
			$mes = $_POST['mes'];
			$tecnico = $_POST['tecnico'];
			$projeto = $_POST['projeto'];
			foreach ($ano as $key => $val){
				$condicao .= "(p.ano = '{$val}' AND p.mes = '{$mes[$key]}' AND p.tecnico = '{$tecnico[$key]}') OR ";
				$this->rollback[$a] = array('ano' => $val, 'mes' => $mes[$key], 'tecnico' => $tecnico[$key], 'projeto' => $projeto[$key]);
				$a = $a + 1;	
			}
			$rs = $apiProjeto->filtroProjeto('5',substr($condicao,0,-3));
			if ((is_array($rs) ? count($rs) : 0) > 0){
				$this->Alert = "<br>";
				foreach ($rs as $rs) {
					$this->Alert .= "J� existe o ano: {$rs->ANO}, m�s: {$rs->MES} e t�cnico: {$rs->NOME} cadastrado! <br>";
				}
			}else{				
				$Post = new Projeto('POST');
				$Post->dta_cadastro = date('d/m/Y H:i:s');
				$log = new Log();
				$apiLog = new apiLog();
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				foreach ($this->rollback as $rs){
					$Post->ano = $rs['ano'];
					$Post->mes = $rs['mes'];
					$Post->tecnico = $rs['tecnico'];
					$Post->projeto = $rs['projeto'];
					$sql[$i] = $apiProjeto->addProjeto($Post);
					$i = $i+1;
					$log->historico = "ANO||{$Post->ano};;MES||{$Post->mes};;TECNICO||{$Post->tecnico};;PROJETO||{$Post->projeto};;DTA_CADASTRO||{$Post->dta_cadastro}";
					$sql[$i] = $apiLog->addLog($log);
					$i = $i+1;
				}
				$rs = $apiProjeto->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'help/projeto/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'help/projeto/index/sucesso');
					}
				}else{
					$this->rollback = new Projeto('POST');
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		
		$this->view();
	}
	
	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Altera��o de Projeto";
		$projeto = new Projeto();
		$exp = explode(",", $this->getParams(0));
		$projeto->ano = $exp[0];
		$projeto->mes = $exp[1];
		$projeto->tecnico = $exp[2];
		$apiProjeto = new apiProjeto();
		$this->dados = array('projeto' => $apiProjeto->getProjeto($projeto));
		if (!isset($this->dados['projeto'])){
			header('location:' .APP_ROOT. 'help/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$anterior = "";
			$atual = "::";
			$Post = new Projeto();
			if ($this->dados['projeto']->PROJETO != $_POST['projeto']){
				$Post->projeto = $_POST['projeto'];
				$anterior .= "PROJETO||{$this->dados['projeto']->PROJETO};;";
				$atual .= "PROJETO||{$Post->projeto};;";
			}
			$obj = (array) $Post;
			$obj = array_filter($obj, function($v){return !is_null($v);});
			if ($obj != NULL){
				$Post->ano = $exp[0];
				$Post->mes = $exp[1];
				$Post->tecnico = $exp[2];
				$sql[$i] = $apiProjeto->editProjeto($Post);
				$i = $i+1;
				$log = new Log();
				$log->historico = substr($anterior,0,-2);
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "A";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico .= substr($atual,0,-2);
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiProjeto->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'help/projeto/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'help/projeto/index/sucesso');
					}
				}else{
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}else{
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'help/projeto/index/pagina/'.$this->PaginaAtual.'/insucesso');
				}else {
					header('location:' .APP_ROOT. 'help/projeto/index/insucesso');
				}
			}
		}
		$this->view();
	}
	public function excluir() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Exclus�o de Projeto";
		$projeto = new Projeto();
		$exp = explode(",", $this->getParams(0));
		$projeto->ano = $exp[0];
		$projeto->mes = $exp[1];
		$projeto->tecnico = $exp[2];
		$apiProjeto = new apiProjeto();
		$this->dados = array('projeto' => $apiProjeto->getProjeto($projeto));
		if (!isset($this->dados['projeto'])){
			header('location:' .APP_ROOT. 'help/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$sql[$i] = $apiProjeto->delProjeto($projeto);
			$i = $i+1;
			$log = new Log();
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "E";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico = "ANO||{$this->dados['projeto']->ANO};;MES||{$this->dados['projeto']->MES};;TECNICO||{$this->dados['projeto']->TECNICO};;PROJETO||{$this->dados['projeto']->PROJETO}";
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiProjeto->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'help/projeto/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'help/projeto/index/sucesso');
				}
			}else{
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}
		$this->view();
	}
}