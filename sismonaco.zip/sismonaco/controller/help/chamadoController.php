<?php

namespace controller\help;

use lib\Controller;
use helper\Security;
use api\help\apiChamado;
use helper\Paginator;
use obj\help\Chamado;
use api\help\apiStatus;
use api\help\apiTecnico;
use api\help\apiAmbiente;
use api\help\apiSubcategoria;
use api\adm\apiCargo;
use api\help\apiTipo;
use api\adm\apiDepartamento;
use api\adm\apiUsuario;
use api\help\apiTecempsubcategoria;
use helper\Funcoes;
use api\help\apiCalendario;
use obj\help\Adicional;
use api\geral\apiEmpresa;
use obj\help\Movimento;
// use classes\PHPMailer;
use obj\geral\Padrao;
use api\geral\apiPadrao;
use obj\help\Chamadonf;
use obj\adm\Usuario;
use classes\FPDF;
use obj\help\Autorizacao;

include 'classes/FPDF/fpdf.php';
// include 'classes/PHPMailer/class.phpmailer.php';

class chamadoController extends Controller {
	
	public function __construct() {
		
		parent::__construct();
		
		new Security($this->getModule(),$this->getController(),$this->getAction());
	}
	
	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Chamados";
		$apiTecnico = new apiTecnico();
		$this->usuario = $apiTecnico->filtroTecnico('1', '3', 't.tecnico',$_SESSION['usuario_sessao'],'tudo');
		if ((is_array($this->usuario) ? count($this->usuario) : 0) > 0) {
			if (isset($_SESSION["padrao_sessao"]["{$this->getModule()['modulo']}-{$this->getController()['controle']}-{$this->getAction()['acao']}"]) && !isset($_SESSION["colunas{$this->getModule()['modulo']}-{$this->getController()['controle']}-{$this->getAction()['acao']}"]['#'])){
				$val = $_SESSION["padrao_sessao"]["{$this->getModule()['modulo']}-{$this->getController()['controle']}-{$this->getAction()['acao']}"];
				$strVal = explode(';;', $val);
				foreach ($strVal as $rs){
					list($k, $v) = explode('||', $rs);
					$_SESSION["colunas{$this->getModule()['modulo']}-{$this->getController()['controle']}-{$this->getAction()['acao']}"][$k] = $v;
				}
			}
			$apiChamado = new apiChamado();
			$ItemPorPagina = 10;
			$PaginaAtual = 1;
			if ($this->getParams(1) > $PaginaAtual) {
				$PaginaAtual = $this->getParams(1);
			}
			$apiStatus = new apiStatus();
			$this->status = $apiStatus->filtroStatus('1','3','ativo', '1');
			$apiTecnico = new apiTecnico();
			$tecnico = $apiTecnico->filtroTecnico('1', '3', 't.ativo', '1', 'tudo');
			foreach ($tecnico as $rs){
				$this->tecnico[$rs->AMBIENTE][$rs->N_LINHA] = array('tecnico' => $rs->TECNICO, 'nome' => $rs->NOME);
				$this->ambiente[$rs->TECNICO][$rs->AMBIENTE] = array('ambiente' => $rs->AMBIENTE, 'des_ambiente' => $rs->DES_AMBIENTE);
			}
			if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-16"])){
				$apiAmbiente = new apiAmbiente();
				$amb = $apiAmbiente->filtroAmbiente('1', '3', 'ativo', '1');
				unset($this->ambiente);
				foreach ($amb as $rs){
					$this->ambiente[$_SESSION['usuario_sessao']][$rs->AMBIENTE] = array('ambiente' => $rs->AMBIENTE, 'des_ambiente' => $rs->DES_AMBIENTE);
				}
			}
			if ($_SERVER['REQUEST_METHOD'] === 'POST') {
				if (isset($_POST['padrao'])) {
					$sql = array();
					$padrao = new Padrao();
					$padrao->modulo = $this->getModule()['modulo'];
					$padrao->controle = $this->getController()['controle'];
					$padrao->acao = $this->getAction()['acao'];
					$padrao->usuario = $_SESSION['usuario_sessao'];
					$padrao->padrao = isset($_POST['#']) ? "#||S;;" : "#||N;;";
					$padrao->padrao .= isset($_POST['des_empresa']) ? "des_empresa||S;;" : "des_empresa||N;;";
					$padrao->padrao .= isset($_POST['#_externo']) ? "#_externo||S;;" : "#_externo||N;;";
					$padrao->padrao .= isset($_POST['#_dvi']) ? "#_dvi||S;;" : "#_dvi||N;;";
					$padrao->padrao .= isset($_POST['dta_abertura']) ? "dta_abertura||S;;" : "dta_abertura||N;;";
					$padrao->padrao .= isset($_POST['dta_vencimento']) ? "dta_vencimento||S;;" : "dta_vencimento||N;;";
					$padrao->padrao .= isset($_POST['assunto']) ? "assunto||S;;" : "assunto||N;;";
					$padrao->padrao .= isset($_POST['departamento']) ? "departamento||S;;" : "departamento||N;;";
					$padrao->padrao .= isset($_POST['solicitante']) ? "solicitante||S;;" : "solicitante||N;;";
					$padrao->padrao .= isset($_POST['tec']) ? "tecnico||S;;" : "tecnico||N;;";
					$padrao->padrao .= isset($_POST['subcategoria']) ? "subcategoria||S;;" : "subcategoria||N;;";
					$padrao->padrao .= isset($_POST['stat']) ? "status||S;;" : "status||N;;";
					$padrao->padrao .= isset($_POST['dta_fechamento']) ? "dta_fechamento||S;;" : "dta_fechamento||N;;";
					$padrao->padrao .= isset($_POST['dta_ult_movimento']) ? "dta_ult_movimento||S;;" : "dta_ult_movimento||N;;";
					$padrao->padrao .= isset($_POST['tempo']) ? "tempo||S" : "tempo||N";
					$strVal = explode(';;', $padrao->padrao);
					foreach ($strVal as $rs){
						list($k, $v) = explode('||', $rs);
						$_SESSION["colunas{$this->getModule()['modulo']}-{$this->getController()['controle']}-{$this->getAction()['acao']}"][$k] = $v;
					}
					$apiPadrao = new apiPadrao();
					$rs = $apiPadrao->getPadrao($padrao);
					if ((is_array($rs) ? count($rs) : 0) > 0) {
						$sql[0] = $apiPadrao->editPadrao($padrao);	
					}else{
						$sql[0] = $apiPadrao->addPadrao($padrao);
					}
					$apiPadrao->executeSQL($sql);
				}
				$busca = array(
					'1' => array('c' => '3', 'tecnico' => isset($_POST['tecnico']) ? $_POST['tecnico'] : NULL, 'status' => $_POST['status'], 'ambiente' =>  isset($_POST['ambiente']) ? $_POST['ambiente'] : @$this->usuario[0]->AMBIENTE, 'coluna' => "", 'valor' => ""),
					'2' => array('c' => '1', 'tecnico' => isset($_POST['tecnico']) ? $_POST['tecnico'] : NULL, 'status' => $_POST['status'], 'ambiente' => isset($_POST['ambiente']) ? $_POST['ambiente'] : @$this->usuario[0]->AMBIENTE, 'coluna' => 'c.chamado',  'valor' => @$_POST['busca_valor']),
					'3' => array('c' => '2', 'tecnico' => isset($_POST['tecnico']) ? $_POST['tecnico'] : NULL, 'status' => $_POST['status'], 'ambiente' =>  isset($_POST['ambiente']) ? $_POST['ambiente'] : @$this->usuario[0]->AMBIENTE, 'coluna' => 'c.assunto', 'valor' => @$_POST['busca_valor']),
					'4' => array('c' => '2', 'tecnico' => isset($_POST['tecnico']) ? $_POST['tecnico'] : NULL, 'status' => $_POST['status'], 'ambiente' =>  isset($_POST['ambiente']) ? $_POST['ambiente'] : @$this->usuario[0]->AMBIENTE, 'coluna' => 'c.des_chamado', 'valor' => @$_POST['busca_valor']),
					'5' => array('c' => '4', 'tecnico' => isset($_POST['tecnico']) ? $_POST['tecnico'] : NULL, 'status' => $_POST['status'], 'ambiente' =>  isset($_POST['ambiente']) ? $_POST['ambiente'] : @$this->usuario[0]->AMBIENTE, 'coluna' => 'c.dta_abertura', 'de' => @$_POST['busca_de'], 'ate' => @$_POST['busca_ate']),
					'6' => array('c' => '4', 'tecnico' => isset($_POST['tecnico']) ? $_POST['tecnico'] : NULL, 'status' => $_POST['status'], 'ambiente' =>  isset($_POST['ambiente']) ? $_POST['ambiente'] : @$this->usuario[0]->AMBIENTE, 'coluna' => 'c.dta_vencimento', 'de' => @$_POST['busca_de'], 'ate' => @$_POST['busca_ate']),
					'7' => array('c' => '4', 'tecnico' => isset($_POST['tecnico']) ? $_POST['tecnico'] : NULL, 'status' => $_POST['status'], 'ambiente' =>  isset($_POST['ambiente']) ? $_POST['ambiente'] : @$this->usuario[0]->AMBIENTE, 'coluna' => 'c.dta_fechamento', 'de' => @$_POST['busca_de'], 'ate' => @$_POST['busca_ate']),
					'8' => array('c' => '2', 'tecnico' => isset($_POST['tecnico']) ? $_POST['tecnico'] : NULL, 'status' => $_POST['status'], 'ambiente' =>  isset($_POST['ambiente']) ? $_POST['ambiente'] : @$this->usuario[0]->AMBIENTE, 'coluna' => 'u.nome', 'valor' => @$_POST['busca_valor']),
					'9' => array('c' => '1', 'tecnico' => isset($_POST['tecnico']) ? $_POST['tecnico'] : NULL, 'status' => $_POST['status'], 'ambiente' =>  isset($_POST['ambiente']) ? $_POST['ambiente'] : @$this->usuario[0]->AMBIENTE, 'coluna' => 'c.chamado_externo', 'valor' => @$_POST['busca_valor']),
					'10' => array('c' => '1', 'tecnico' => isset($_POST['tecnico']) ? $_POST['tecnico'] : NULL, 'status' => $_POST['status'], 'ambiente' =>  isset($_POST['ambiente']) ? $_POST['ambiente'] : @$this->usuario[0]->AMBIENTE, 'coluna' => 'c.chamado_dvi', 'valor' => @$_POST['busca_valor']),
					'11' => array('c' => '2', 'tecnico' => isset($_POST['tecnico']) ? $_POST['tecnico'] : NULL, 'status' => $_POST['status'], 'ambiente' =>  isset($_POST['ambiente']) ? $_POST['ambiente'] : @$this->usuario[0]->AMBIENTE, 'coluna' => 'c.cod_empresa', 'valor' => @$_POST['busca_valor']),
					'12' => array('c' => '1', 'tecnico' => isset($_POST['tecnico']) ? $_POST['tecnico'] : NULL, 'status' => $_POST['status'], 'ambiente' =>  isset($_POST['ambiente']) ? $_POST['ambiente'] : @$this->usuario[0]->AMBIENTE, 'coluna' => 'cn.nota_fiscal', 'valor' => @$_POST['busca_valor']),
					'13' => array('c' => '1', 'tecnico' => 'tudo', 'status' => $_POST['status'], 'ambiente' => 'tudo', 'coluna' => 'c.solicitante', 'valor' => $_SESSION['usuario_sessao']),
					'14' => array('c' => '1', 'tecnico' => 'tudo', 'status' => $_POST['status'], 'ambiente' => 'tudo', 'coluna' => 'caut.destinatario', 'valor' => $_SESSION['usuario_sessao'])
				);
				if(isset($busca[$_POST['busca']])){
					$this->dados = array('chamado' => $apiChamado->consultaChamado($busca[$_POST['busca']]['c'], $busca[$_POST['busca']]['tecnico'], $busca[$_POST['busca']]['status'], $busca[$_POST['busca']]['ambiente'], $busca[$_POST['busca']]['coluna'], @$busca[$_POST['busca']]['valor'], @$busca[$_POST['busca']]['de'], @$busca[$_POST['busca']]['ate']));
					$_SESSION['filtro_chamado'] = array('c' => $busca[$_POST['busca']]['c'], 'tecnico' => $busca[$_POST['busca']]['tecnico'], 'status' => $busca[$_POST['busca']]['status'], 'ambiente' => $busca[$_POST['busca']]['ambiente'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'valor' => @$busca[$_POST['busca']]['valor'], 'de' => @$busca[$_POST['busca']]['de'], 'ate' => @$busca[$_POST['busca']]['ate'],'filtro' => $_POST['busca']);
					$_SESSION['consulta_chamado'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
					
				}else{
					unset($_SESSION['filtro_chamado']);
					unset($_SESSION['consulta_chamado']);
					header('location:' .APP_ROOT. 'help/index/index/acessonegado');
					die();
				}
			}else{
				$endereco = explode('/', $_SERVER ['REQUEST_URI']);
				if((end($endereco) == "sucesso") || (end($endereco) == "atualizar")){
					$this->dados = array('chamado' => $apiChamado->consultaChamado($_SESSION['filtro_chamado']['c'], $_SESSION['filtro_chamado']['tecnico'], $_SESSION['filtro_chamado']['status'], $_SESSION['filtro_chamado']['ambiente'], $_SESSION['filtro_chamado']['coluna'], $_SESSION['filtro_chamado']['valor'], @$_SESSION['filtro_chamado']['de'], @$_SESSION['filtro_chamado']['ate']));
					$_SESSION['consulta_chamado'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}else{
					if (isset($_SESSION['consulta_chamado'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']])){
						$this->dados = $_SESSION['consulta_chamado'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']];
					}else{
						unset($_SESSION['filtro_chamado']);
						unset($_SESSION['consulta_chamado']);
						$this->dados = array('chamado' => $apiChamado->consultaChamado(3,NULL,"andamento", @$this->usuario[0]->AMBIENTE,""));
						$_SESSION['filtro_chamado'] = array('c' => 3, 'tecnico' => isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-2"]) ? $_SESSION['usuario_sessao'] : NULL, 'status' => 'andamento', 'ambiente' => $this->usuario[0]->AMBIENTE, 'coluna' => "", 'valor' => "", 'de' => "", 'ate' => "",  'filtro' => 1);
						$_SESSION['consulta_chamado'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
					}
				}
			}
			$TotalItem = (is_array($this->dados['chamado']) ? count($this->dados['chamado']) : 0);
			$this->dados['chamado'] = array_chunk($this->dados['chamado'], $ItemPorPagina);
			@$this->dados['chamado'] = $this->dados['chamado'][$PaginaAtual - 1];
			if ($TotalItem > $ItemPorPagina) {
				$paginator = new Paginator();
				$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
				$this->PaginaAtual = $PaginaAtual;
			}
		}else{
			$apiUsuario = new apiUsuario();
			$this->usuario = $apiUsuario->filtroUsuario('1', '3', 'usuario',$_SESSION['usuario_sessao']);
			$apiChamado = new apiChamado();
			$apiStatus = new apiStatus();
			$this->status = $apiStatus->filtroStatus('1','3','ativo', '1');
			$ItemPorPagina = 10;
			$PaginaAtual = 1;
			if ($this->getParams(1) > $PaginaAtual) {
				$PaginaAtual = $this->getParams(1);
			}
			if ($_SERVER['REQUEST_METHOD'] === 'POST') {
				$busca = array(
					'1' => array('c' => '3', 'solicitante' => $_SESSION['usuario_sessao'], 'status' => $_POST['status'],'coluna' => "", 'valor' => ""),
					'2' => array('c' => '1', 'solicitante' => $_SESSION['usuario_sessao'], 'status' => $_POST['status'],'coluna' => 'c.chamado',  'valor' => @$_POST['busca_valor']),
					'3' => array('c' => '2', 'solicitante' => $_SESSION['usuario_sessao'], 'status' => $_POST['status'],'coluna' => 'c.assunto', 'valor' => @$_POST['busca_valor']),
					'4' => array('c' => '2', 'solicitante' => $_SESSION['usuario_sessao'], 'status' => $_POST['status'],'coluna' => 'c.des_chamado', 'valor' => @$_POST['busca_valor']),
					'5' => array('c' => '4', 'solicitante' => $_SESSION['usuario_sessao'], 'status' => $_POST['status'],'coluna' => 'c.dta_abertura', 'de' => @$_POST['busca_de'], 'ate' => @$_POST['busca_ate']),
					'6' => array('c' => '4', 'solicitante' => $_SESSION['usuario_sessao'], 'status' => $_POST['status'],'coluna' => 'c.dta_vencimento', 'de' => @$_POST['busca_de'], 'ate' => @$_POST['busca_ate']),
					'7' => array('c' => '4', 'solicitante' => $_SESSION['usuario_sessao'], 'status' => $_POST['status'],'coluna' => 'c.dta_fechamento', 'de' => @$_POST['busca_de'], 'ate' => @$_POST['busca_ate'])	
				);
				if(isset($busca[$_POST['busca']])){
					$this->dados = array('chamado' => $apiChamado->consultaSolicitantechamado($busca[$_POST['busca']]['c'], $busca[$_POST['busca']]['solicitante'], $busca[$_POST['busca']]['status'], $busca[$_POST['busca']]['coluna'], @$busca[$_POST['busca']]['valor'], @$busca[$_POST['busca']]['de'], @$busca[$_POST['busca']]['ate']));
					$_SESSION['filtro_chamado'] = array('c' => $busca[$_POST['busca']]['c'], 'solicitante' => $busca[$_POST['busca']]['solicitante'], 'status' => $busca[$_POST['busca']]['status'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'valor' => @$busca[$_POST['busca']]['valor'], 'de' => @$busca[$_POST['busca']]['de'], 'ate' => @$busca[$_POST['busca']]['ate'],'filtro' => $_POST['busca']);
					$_SESSION['consulta_chamado'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
					
				}else{
					unset($_SESSION['filtro_chamado']);
					unset($_SESSION['consulta_chamado']);
					header('location:' .APP_ROOT. 'help/index/index/acessonegado');
					die();
				}
			}else{
				$endereco = explode('/', $_SERVER ['REQUEST_URI']);
				if((end($endereco) == "sucesso") || (end($endereco) == "atualizar")){
					$this->dados = array('chamado' => $apiChamado->consultaSolicitantechamado($_SESSION['filtro_chamado']['c'], $_SESSION['filtro_chamado']['solicitante'], $_SESSION['filtro_chamado']['status'], $_SESSION['filtro_chamado']['coluna'], $_SESSION['filtro_chamado']['valor'], @$_SESSION['filtro_chamado']['de'], @$_SESSION['filtro_chamado']['ate']));
					$_SESSION['consulta_chamado'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}else{
					if (isset($_SESSION['consulta_chamado'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']])){
						$this->dados = $_SESSION['consulta_chamado'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']];
					}else{
						unset($_SESSION['filtro_chamado']);
						unset($_SESSION['consulta_chamado']);
						$this->dados = array('chamado' => $apiChamado->consultaSolicitantechamado(3, $_SESSION['usuario_sessao'], "andamento",""));
						$_SESSION['filtro_chamado'] = array('c' => 3, 'solicitante' => $_SESSION['usuario_sessao'], 'status' => 'andamento', 'coluna' => "", 'valor' => "", 'de' => "", 'ate' => "", 'filtro' => 1);
						$_SESSION['consulta_chamado'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
					}
				}
			}
			$TotalItem = (is_array($this->dados['chamado']) ? count($this->dados['chamado']) : 0);
			$this->dados['chamado'] = array_chunk($this->dados['chamado'], $ItemPorPagina);
			@$this->dados['chamado'] = $this->dados['chamado'][$PaginaAtual - 1];
			if ($TotalItem > $ItemPorPagina) {
				$paginator = new Paginator();
				$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
				$this->PaginaAtual = $PaginaAtual;
			}
		}
		$this->view();
	}
	
	public function adicionar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Abertura de Chamado";
		$apiChamado = new apiChamado();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		$funcoes = new Funcoes();
		$this->semana = $funcoes->retiraAcentos(str_replace("-feira", "", strtolower(strftime('%A'))));
		$apiCalendario = new apiCalendario();
		$plantao = $apiCalendario->getPlantao(date('j'));
		if ($this->semana == 'domingo'){
			if (isset($this->PaginaAtual)) {
				header('location:' .APP_ROOT. 'help/chamado/index/pagina/'.$this->PaginaAtual.'/indisponivel');
				die();
			}else {
				header('location:' .APP_ROOT. 'help/chamado/index/indisponivel');
				die();
			}
		}
		$this->hora = date('H:i:s');
		$fixo = strtotime($this->hora);
		/*if ($plantao == 1){
			$ini = strtotime("07:00:00");
			$fim = strtotime("23:59:59");
		}else{
			$ini = strtotime("07:30:00");
			$fim = strtotime("19:00:00");
		}*/
		
		/*if (($fixo < $ini) || ($fixo > $fim)){
			if (isset($this->PaginaAtual)) {
				header('location:' .APP_ROOT. 'help/chamado/index/pagina/'.$this->PaginaAtual.'/indisponivel');
				die();
			}else {
				header('location:' .APP_ROOT. 'help/chamado/index/indisponivel');
				die();
			}
		}*/
		
		$apiUsuario = new apiUsuario();
		$this->usuario = $apiUsuario->filtroUsuario('1', '3', 'usuario',$_SESSION['usuario_sessao']);
		$apiTecnico = new apiTecnico();
		$tec_amb = $apiTecnico->filtroTecnico('1', '3', 't.tecnico', $_SESSION['usuario_sessao'],'tudo');
		foreach ($tec_amb as $rs){
			$this->tec_amb[$rs->AMBIENTE] = true;
		}
		$tecnico = $apiTecnico->filtroTecnico('1','3','t.ativo', '1', 'tudo');
		foreach ($tecnico as $rs){
			$this->tecnico[$rs->AMBIENTE][$rs->N_LINHA] = array('tecnico' => $rs->TECNICO, 'nome' => $rs->NOME);
		}
		$apiSubcategoria = new apiSubcategoria();
		$subcategoria = $apiSubcategoria->filtroSubcategoria('1','3','s.ativo', '1','tudo');
		foreach ($subcategoria as $rs){
			$this->ambiente[$rs->AMBIENTE] = array('ambiente' => $rs->AMBIENTE, 'des_ambiente' => $rs->DES_AMBIENTE);
			$this->categoria[$rs->AMBIENTE][$rs->DES_CATEGORIA] = array('categoria' => $rs->CATEGORIA, 'des_categoria' => $rs->DES_CATEGORIA, 'ambiente' => $rs->AMBIENTE, 'des_ambiente' => $rs->DES_AMBIENTE);
			$this->sub[$rs->CATEGORIA][$rs->N_LINHA] = array('subcategoria' => $rs->SUBCATEGORIA, 'des_subcategoria' => $rs->DES_SUBCATEGORIA, 'tempo_atendimento' => $rs->TEMPO_ATENDIMENTO);
			$this->subcategoria[$rs->CATEGORIA][$rs->SUBCATEGORIA] = array('subcategoria' => $rs->SUBCATEGORIA, 'des_subcategoria' => $rs->DES_SUBCATEGORIA, 'tempo_atendimento' => $rs->TEMPO_ATENDIMENTO);
		}
		if (($this->usuario[0]->TIPO != 3) && ($this->usuario[0]->TIPO != 4) && ($this->usuario[0]->TIPO != 5)){
			unset($this->ambiente[2]);
		}
		$apiEmpresa = new apiEmpresa();
		$this->empresa = $apiEmpresa->filtroEmpresa('1','3','ativo', '1');
		$apiCargo = new apiCargo();
		$this->cargo = $apiCargo->filtroCargo('1','3','ativo', '1');
		$apiTipo = new apiTipo();
		$this->tipo = $apiTipo->filtroTipo('1','3','ativo', '1');
		$apiStatus = new apiStatus();
		$this->status = $apiStatus->filtroStatus('1','3','ativo', '1');
		$apiDepartamento = new apiDepartamento();
		$this->departamento = $apiDepartamento->filtroDepartamento('1','3','d.ativo', '1');
		$apiTecempsubcategoria = new apiTecempsubcategoria();
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$Post = new Chamado('POST');
			$Post->des_chamado = str_replace("\r\n","<br>",$Post->des_chamado);
			if(isset($_POST['funcionario'])){
				$expo = explode("-", $_POST['funcionario']);
				$Post->funcionario = $expo[0];
			}
			if ($_POST['subcategoria'] == 59){
				$funcionario = $apiUsuario->filtroUsuario('1', '3', 'usuario',$Post->funcionario);
				$datetime = new \DateTime(implode("-",array_reverse(explode("/",$funcionario[0]->DTA_ADMISSAO))));
				$diff = $datetime->diff( new \DateTime(date('Y-m-d')));
				$Post->tempo_funcao = $diff->y.' ANO, '.$diff->m .' M�S E '. $diff->d .' DIA.';
				if (isset($_POST['m_cargo'])){
					$Post->an_cargo = $funcionario[0]->CARGO;
				}
				if (isset($_POST['m_departamento'])){
					$Post->an_departamento = $funcionario[0]->DEPARTAMENTO;
				}
				if (isset($_POST['m_empresa'])){
					$Post->an_empresa = $funcionario[0]->EMPRESA;
				}
			}
			if(isset($_POST['funcionario_substituido'])){
				$expo = explode("-", $_POST['funcionario_substituido']);
				$Post->funcionario_substituido = $expo[0];
				if ($_POST['subcategoria'] == 5){
					$Post->n_vaga = 1;
				}
			}
			if(isset($_POST['solicitante'])){
				$expo = explode("-", $_POST['solicitante']);
				$Post->solicitante = $expo[0];
				$usuario = new Usuario();
				$usuario->usuario = $expo[0];
				$tipo = $apiUsuario->getUsuario($usuario)->TIPO;
			}else{
				$Post->solicitante = $this->usuario[0]->USUARIO;
				$tipo = $this->usuario[0]->TIPO;
			}
			if (!isset($_POST['departamento'])){
				$Post->departamento = $this->usuario[0]->DEPARTAMENTO;
			}
			$Post->empresa = $_SESSION['empresa_sessao'];
			$Post->dta_ult_movimento = date('d/m/Y H:i:s');
			$Post->dta_abertura = date('d/m/Y H:i:s');
			$novo = mktime(date('H')+$this->subcategoria[$_POST['categoria']][$Post->subcategoria]['tempo_atendimento'],date('i'),date('s'),date('n'),date('j'),date('Y'));
			$Post->dta_vencimento = date('d/m/Y H:i:s',$novo);
			if (!isset($_POST['tecnico'])){
				$tec = $apiTecempsubcategoria->tecnicoVez($Post->empresa, $Post->subcategoria, $this->hora, $plantao->PLANTAO);
				
				if ((is_array($tec) ? count($tec) : 0) > 0){
					$Post->tecnico = $tec[0]->TECNICO;
					if ($Post->status == NULL){
						$Post->status = 2;
					}
				}else{
					$tec = $apiTecempsubcategoria->tecnicoVez($Post->empresa, $Post->subcategoria, $this->hora, "ignoraplantao","ignorahorario");
					if ((is_array($tec) ? count($tec) : 0) > 0){
						if ($fixo < strtotime($tec[0]->HORA_INICIO)){
							if ($this->semana == 'sabado'){
								$condicao = 0;
								$d = 2;
								$dia = date('j', strtotime("+{$d} days"));
								while ($condicao == 0){
									$r = $apiCalendario->getPlantao($dia);
									if ($r->FERIADO == 0){
										$condicao = 1;
									}else{
										$d = $d+1;
										$dia = date('j', strtotime("+{$d} days"));
									}
								}
								$Post->tecnico = $tec[0]->TECNICO;
								$Post->status = 2;
								$Post->dta_abertura = date('d/m/Y', strtotime("+{$d} days"))." ".$tec[0]->HORA_INICIO;
								$Post->dta_ult_movimento = $Post->dta_abertura;
								$t = explode(":", $tec[0]->HORA_INICIO);
								$novo = mktime($t[0]+$this->subcategoria[$_POST['categoria']][$Post->subcategoria]['tempo_atendimento'],$t[1],$t[2],date('n', strtotime("+{$d} days")),date('j', strtotime("+{$d} days")),date('Y', strtotime("+{$d} days")));
								$Post->dta_vencimento = date('d/m/Y H:i:s',$novo);
							}elseif ($this->semana == 'domingo'){
								$condicao = 0;
								$d = 1;
								$dia = date('j', strtotime("+{$d} days"));
								while ($condicao == 0){
									$r = $apiCalendario->getPlantao($dia);
									if ($r->FERIADO == 0){
										$condicao = 1;
									}else{
										$d = $d+1;
										$dia = date('j', strtotime("+{$d} days"));
									}
								}
								$Post->tecnico = $tec[0]->TECNICO;
								$Post->status = 2;
								$Post->dta_abertura = date('d/m/Y', strtotime("+{$d} days"))." ".$tec[0]->HORA_INICIO;
								$Post->dta_ult_movimento = $Post->dta_abertura;
								$t = explode(":", $tec[0]->HORA_INICIO);
								$novo = mktime($t[0]+$this->subcategoria[$_POST['categoria']][$Post->subcategoria]['tempo_atendimento'],$t[1],$t[2],date('n', strtotime("+{$d} days")),date('j', strtotime("+{$d} days")),date('Y', strtotime("+{$d} days")));
								$Post->dta_vencimento = date('d/m/Y H:i:s',$novo);
							}else{
								$condicao = 0;
								$d = 0;
								$dia = date('j', strtotime("+{$d} days"));
								while ($condicao == 0){
									$r = $apiCalendario->getPlantao($dia);
									if ($r->FERIADO == 0){
										$condicao = 1;
									}else{
										$d = $d+1;
										$dia = date('j', strtotime("+{$d} days"));
									}
								}
								$Post->tecnico = $tec[0]->TECNICO;
								$Post->status = 2;
								$Post->dta_abertura = date('d/m/Y', strtotime("+{$d} days"))." ".$tec[0]->HORA_INICIO;
								$Post->dta_ult_movimento = $Post->dta_abertura;
								$t = explode(":", $tec[0]->HORA_INICIO);
								$novo = mktime($t[0]+$this->subcategoria[$_POST['categoria']][$Post->subcategoria]['tempo_atendimento'],$t[1],$t[2],date('n', strtotime("+{$d} days")),date('j', strtotime("+{$d} days")),date('Y', strtotime("+{$d} days")));
								$Post->dta_vencimento = date('d/m/Y H:i:s',$novo);
							}
							
						}elseif ($fixo > strtotime($tec[0]->HORA_FIM)){
							if ($this->semana == 'sabado'){
								$condicao = 0;
								$d = 2;
								$dia = date('j', strtotime("+{$d} days"));
								while ($condicao == 0){
									$r = $apiCalendario->getPlantao($dia);
									if ($r->FERIADO == 0){
										$condicao = 1;
									}else{
										$d = $d+1;
										$dia = date('j', strtotime("+{$d} days"));
									}
								}
								$Post->tecnico = $tec[0]->TECNICO;
								$Post->status = 2;
								$Post->dta_abertura = date('d/m/Y', strtotime("+{$d} days"))." ".$tec[0]->HORA_INICIO;
								$Post->dta_ult_movimento = $Post->dta_abertura;
								$t = explode(":", $tec[0]->HORA_INICIO);
								$novo = mktime($t[0]+$this->subcategoria[$_POST['categoria']][$Post->subcategoria]['tempo_atendimento'],$t[1],$t[2],date('n', strtotime("+{$d} days")),date('j', strtotime("+{$d} days")),date('Y', strtotime("+{$d} days")));
								$Post->dta_vencimento = date('d/m/Y H:i:s',$novo);
							}else{
								$condicao = 0;
								$d = 1;
								$dia = date('j', strtotime("+{$d} days"));
								while ($condicao == 0){
									$r = $apiCalendario->getPlantao($dia);
									if ($r->FERIADO == 0){
										$condicao = 1;
									}else{
										$d = $d+1;
										$dia = date('j', strtotime("+{$d} days"));
									}
								}
								$Post->tecnico = $tec[0]->TECNICO;
								$Post->status = 2;
								$Post->dta_abertura = date('d/m/Y', strtotime("+{$d} days"))." ".$tec[0]->HORA_INICIO;
								$Post->dta_ult_movimento = $Post->dta_abertura;
								$t = explode(":", $tec[0]->HORA_INICIO);
								$novo = mktime($t[0]+$this->subcategoria[$_POST['categoria']][$Post->subcategoria]['tempo_atendimento'],$t[1],$t[2],date('n', strtotime("+{$d} days")),date('j', strtotime("+{$d} days")),date('Y', strtotime("+{$d} days")));
								$Post->dta_vencimento = date('d/m/Y H:i:s',$novo);
							}
						}else{
							$Post->tecnico = $tec[0]->TECNICO;
							$Post->status = 2;
						}
					}else{
						$this->rollback = new Chamado();
						$this->rollback->assunto = $_POST['assunto'];
						$this->rollback->des_chamado = str_replace("<br><br>","<br>",$_POST["des_chamado"]);
						$this->Alert = "N�o h� tecnico dispon�vel para essa subcategoria: {$this->subcategoria[$_POST['categoria']][$_POST['subcategoria']]['des_subcategoria']} contate o administrador.";
						$this->view();
						exit();
					}
				}
			}
			if (!isset($_POST['tipo'])){
				$Post->tipo = 2;
			}
			if (isset($_POST['salario'])){
				$Post->salario = $funcoes->sanearValor($_POST['salario']);
			}
			if (isset($_POST['m_salario'])){
				$Post->m_salario = $funcoes->sanearValor($_POST['m_salario']);
			}
			if (isset($_POST['comissao'])){
				$Post->comissao = strtoupper($_POST['comissao']);
			}
			if (isset($_FILES['anexo']['name'][0])) {
				$ex = explode(".", $_FILES['anexo']['name'][0]);
				$exp = end($ex);
				$Post->anexo1 = "{$Post->empresa}-{$Post->ambiente}-{$_SESSION['usuario_sessao']}-Anexo1".date('dmY-His').".{$exp}";
			}
			if (isset($_FILES['anexo']['name'][1])) {
				$ex = explode(".", $_FILES['anexo']['name'][1]);
				$exp = end($ex);
				$Post->anexo2 = "{$Post->empresa}-{$Post->ambiente}-{$_SESSION['usuario_sessao']}-Anexo2".date('dmY-His').".{$exp}";
			}
			if (isset($_FILES['anexo']['name'][2])) {
				$ex = explode(".", $_FILES['anexo']['name'][2]);
				$exp = end($ex);
				$Post->anexo3 = "{$Post->empresa}-{$Post->ambiente}-{$_SESSION['usuario_sessao']}-Anexo3".date('dmY-His').".{$exp}";
			}
			if ($_POST['subcategoria'] == 5 || $_POST['subcategoria'] == 59){
				$Post->aut_situacao = 0;
			}elseif ($_POST['subcategoria'] == 60){
				if($tipo == 4 || $tipo == 5){
					$Post->aut_situacao = 3;
				}else{
					$Post->aut_situacao = 2;
				}
			}
			$gestores = $apiTecempsubcategoria->gestoresAmbiente("1",$_SESSION['empresa_sessao'], $Post->ambiente);
			if (isset($Post->sigiloso) && $Post->sigiloso == 'S'){
				if ($_POST['subcategoria'] == 5 || $_POST['subcategoria'] == 59){
					$Post->tecnico = $gestores[0]->GERENTE_DHO;
				}elseif ($_POST['subcategoria'] == 60){
					$Post->tecnico = $gestores[0]->GERENTE_DP;
				}
			}
			
			$apiChamado = new apiChamado();
			$sql[$i] = $apiChamado->addChamado($Post);
			//aqui prepara a solicita��o de autoriza��o.
			if ($_POST['subcategoria'] == 5 || $_POST['subcategoria'] == 59){
				if ($tipo == 5){
					$destinatario = $Post->solicitante;
				}else{
					$destinatario = $_POST['destinatario'];
				}
				$i = $i + 1;
				$chamado = array('coluna' => 'chamado','tabela' => "help_chamado_{$Post->ambiente}");
				$autorizacao = new Autorizacao();
				$autorizacao->ambiente = $Post->ambiente;
				$autorizacao->situacao = 0;
				$autorizacao->destinatario = $Post->tecnico;
				$autorizacao->dta_solicitacao = date("d/m/Y H:i:s");
				$sql[$i] = $apiChamado->addAutorizacao($autorizacao,$chamado);
				$i = $i + 1;
				$autorizacao = new Autorizacao();
				$autorizacao->ambiente = $Post->ambiente;
				$autorizacao->situacao = 1;
				$autorizacao->destinatario = $destinatario;
				$sql[$i] = $apiChamado->addAutorizacao($autorizacao,$chamado);
			}elseif ($_POST['subcategoria'] == 60){
				$autorizacao = new Autorizacao();
				if ($tipo == 5){
					$destinatario = $Post->solicitante;
					$autorizacao->situacao = 3;
				}else if ($tipo == 4){
					$destinatario = $_POST['destinatario'];
					$autorizacao->situacao = 3;
				}else{
					$destinatario = $_POST['destinatario'];
					$autorizacao->situacao = 2;
				}
				$i = $i + 1;
				$chamado = array('coluna' => 'chamado','tabela' => "help_chamado_{$Post->ambiente}");
				$autorizacao->ambiente = $Post->ambiente;
				$autorizacao->destinatario = $destinatario;
				$autorizacao->dta_solicitacao = date("d/m/Y H:i:s");
				$sql[$i] = $apiChamado->addAutorizacao($autorizacao,$chamado);
			}
			//------------------------------------------------------ Termina o chamado
			
			//--------Insere o Anexos
			$rs = $apiChamado->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				if (isset($_FILES['anexo']['tmp_name'][0])) {
					move_uploaded_file($_FILES['anexo']['tmp_name'][0], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/chamado/".$Post->anexo1);
				}
				if (isset($_FILES['anexo']['tmp_name'][1])) {
					move_uploaded_file($_FILES['anexo']['tmp_name'][1], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/chamado/".$Post->anexo2);
				}
				if (isset($_FILES['anexo']['tmp_name'][2])) {
					move_uploaded_file($_FILES['anexo']['tmp_name'][2], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/chamado/".$Post->anexo3);
				}
				$this->dados = array('chamado' => $apiChamado->numeroChamado($Post));
				$exp_s = explode(" ", $this->dados['chamado']->NOME_SOLICITANTE);
				$exp_s[1] = end($exp_s);
				$exp_t = explode(" ", $this->dados['chamado']->NOME_TECNICO);
				$exp_t[1] = end($exp_t);
				
				$Host = "email-ssl.com.br";
				$IsHTML = true;
				$SMTPAuth = true;
				$SMTPSecure = "ssl";
				$Username = 'helpdesk@grupomonaco.com.br';
				$Password = '4dM.grup0.D0mR';
				$Port = 465;
				
				$email = new PHPMailer();
				$email->IsSMTP();
				$email->Host = $Host;
				$email->IsHTML($IsHTML);
				$email->SMTPAuth = $SMTPAuth;
				$email->SMTPSecure = $SMTPSecure;
				
				$email->Username = $Username;
				$email->Password = $Password;
				$email->Port = $Port;
				
				$email->From = $Username;
				$email->FromName  = "SisMonaco - HelpDesk";
				$email->Subject   = ($this->dados['chamado']->STATUS != 4) ? ($this->dados['chamado']->SUBCATEGORIA == 60) ? "[Chamado #{$this->dados['chamado']->CHAMADO}] DESLIGAMENTO: {$this->dados['chamado']->DES_EMPRESA}, FUNCION�RIO: {$this->dados['chamado']->NOME_FUNCIONARIO}" : "[Chamado #{$this->dados['chamado']->CHAMADO}] {$this->dados['chamado']->ASSUNTO}" : "[Chamado #{$this->dados['chamado']->CHAMADO}] NOVO STATUS: {$this->dados['chamado']->DES_STATUS}";
				if ($this->dados['chamado']->STATUS == 4){
					$ag = 	"<tr>
									<td colspan='2' style='padding: 9px; color: #000000; background: #ffff00;'>
										<img src='' />
										<br>
										<p align='center' style='margin-top:0px;margin-bottom:0px;font-size: 20px; font-style: italic;'>STATUS AGUARDANDO O USU�RIO SER� ENCERRADO CASO N�O SEJA RESPONDIDO EM 2 DIAS POR FALTA DE RETORNO.</p>
									</td>
								</tr>";
				}else{
					$ag = "";
				}
				if ($_POST['subcategoria'] == 60){
					$email_destinatario = $this->dados['chamado']->EMAIL_DESTINATARIO;
					$desl = "<strong>Empresa:</strong> {$this->dados['chamado']->DES_EMPRESA}<br />
							<br />
							<strong>Departamento:</strong> {$this->dados['chamado']->DEPARTAMENTO_FUNCIONARIO}<br />
							<br />
							<strong>Desligado:</strong> {$this->dados['chamado']->NOME_FUNCIONARIO}<br />
							<br />
							<strong>Cargo:</strong> {$this->dados['chamado']->CARGO_FUNCIONARIO}<br />
							<br />";

				}else{
					$desl = "";
				}
				$mensagem = "<html>
								<head></head>
								<body style='margin:0px; padding:0px; border: 0 none; font-size: 9px; font-family: verdana, sans-serif; background-color: #efefef;'>
									<style type='text/css'>
										td p{margin-bottom: 10px;}
										body.ticket {margin:0px; padding:0px; border: 0 none; font-size: 9px; font-family: verdana, sans-serif; background-color: #efefef;}
										h1.title {margin-bottom:0px;}
										p.subtitle {color: #ccc;margin-top:0px;margin-bottom:0px;font-style: italic;}
										table.content {width: 700px; margin: 50px auto 50px auto; border: 1px #ccc solid; background: #fff; font-size: 11px; font-family: verdana, sans-serif;}
										td.uppercontent {border:0px;padding: 9px; color: #fff; background: #070075;}
										tr.lowercontent {padding: 10px;}
										td.leftcolumn {width: 400px; padding: 15px 0px 0px 18px; vertical-align: top;}
										td.rightcolumn {width: 240px; vertical-align: top;}
										div.rightcolumndiv{margin:15px 8px 15px;padding: 9px; border: 1px #ccc solid; font-size: 10px;}
										p.rcmessage {margin-top:5px;}
										a.links {color:#0000FF; text-decoration: none;}
										hr.rcdivider {height: 1px; color: #ccc;}
										p.tickethistory {margin-bottom:10px; margin-top:2px; font-style: italic;color: #606060;}
										table.ticket-sum-hist {border: 1px #ccc solid; background: #eee; width: 394px; font-size: 11px; font-family: verdana, sans-serif;}
										div.ticket-sum-histdiv {margin: 9px;}
										h2.ticket-sum-hist-titles {margin-bottom:5px; margin-top:10px; font-size:12px;}
										p.date {font-style: italic;margin-bottom:10px;}
									</style>
									<table style='width: 800px; margin: 50px auto 50px auto; border: 1px #ccc solid; background: #fff; font-size: 11px; font-family: verdana, sans-serif;' align='center'>
									<tbody>
										<tr>
											<td colspan='2' style='padding: 9px; color: #fff; background: #000000;'>
												<img src='' />
												<br>
												<p style='margin-top:0px;margin-bottom:0px;font-style: italic;'>Notifica��o do Help Desk.</p>
											</td>
										</tr>
										{$ag}
										<tr style='padding: 10px;'>
											<td style='width: 240px; vertical-align: top;'>
												<div style='margin:15px 8px 15px;padding: 9px; border: 1px #ccc solid; font-size: 10px;'>
													<strong>Chamado: </strong>{$this->dados['chamado']->CHAMADO}
													<hr style='height: 1px; color: #ccc;' />
													<strong>Data de Abertura:</strong> {$this->dados['chamado']->DTA_ABERTURA}<br />
													<br />
													<strong>Criado por:</strong> <a style='color:#0000FF; text-decoration: none;' href='mailto:{$this->dados['chamado']->EMAIL_SOLICITANTE}?subject=[Chamado #{$this->dados['chamado']->CHAMADO}] {$this->dados['chamado']->ASSUNTO}'>{$exp_s[0]} {$exp_s[1]}</a><br />
													<br />
													<strong>Assunto:</strong> {$this->dados['chamado']->ASSUNTO}<br />
													<br />
													{$desl}
													<strong>Subcategoria:</strong> {$this->dados['chamado']->DES_SUBCATEGORIA}<br  />
													<br />
													<strong>Status:</strong> {$this->dados['chamado']->DES_STATUS}<br  />
													<br />
													<strong>Vencimento:</strong> {$this->dados['chamado']->DTA_VENCIMENTO}<br  />
													<br />
													<strong>Telefone:</strong>".($this->dados['chamado']->TELEFONE_SOLICITANTE != "" ? $funcoes->mask($this->dados['chamado']->TELEFONE_SOLICITANTE,'(##)####-####'): "")."<br />
										            <br />
										            <strong>Celular:</strong>".($this->dados['chamado']->CELULAR_SOLICITANTE != "" ? $funcoes->mask($this->dados['chamado']->CELULAR_SOLICITANTE,'(##)#####-####'): "")."<br />
										            <br />
										            <strong>Chamado URL:</strong> <a style='color:#0000FF; text-decoration: none;' href='".APP_ROOT."help/chamado/alterar/{$this->dados['chamado']->CHAMADO},{$this->dados['chamado']->AMBIENTE}'>Chamado {$this->dados['chamado']->CHAMADO}</a><br />
										            <br />
										            <strong>T�cnico:</strong> <a style='color:#0000FF; text-decoration: none;' href='mailto:{$this->dados['chamado']->EMAIL_TECNICO}?subject=[Chamado #{$this->dados['chamado']->CHAMADO}] {$this->dados['chamado']->ASSUNTO}'>{$exp_t[0]} {$exp_t[1]}</a><br />
										            <br />
										            <hr style='height: 1px; color: #ccc;' />
										            <p style='margin-top:5px;'>se voc� tiver alguma informa��o adicional referente
										            ao chamado <strong>{$this->dados['chamado']->CHAMADO}</strong> Por favor acesse o helpdesk
										            <a style='color:#0000FF; text-decoration: none;' href='".APP_ROOT."help/chamado/'>
										            aqui</a> e movimente ou veja outros chamados.</p>
										   		</div>
										 	</td>
										    <td style='width: 400px; padding: 15px 0px 0px 18px; vertical-align: top;'>
									     		<p style='margin-bottom: 10px;'>{$exp_s[0]} {$exp_s[1]},</p>
									     		<p style='font-style: italic;margin-bottom:10px;'>O chamado: {$this->dados['chamado']->CHAMADO} foi aberto em {$this->dados['chamado']->DTA_ABERTURA} para o t�cnico {$this->dados['chamado']->NOME_TECNICO}.</p>
									            <br>
									            <br>
									            <br />
										    	<table style='border: 1px #ccc solid; background: #eee; width: 394px; font-size: 11px; font-family: verdana, sans-serif;'>
										        	<tr>
										            	<td>
										            		<div style='margin: 9px;'>
													            <h2 style='margin-bottom:5px; margin-top:10px; font-size:12px;'>Chamado: {$this->dados['chamado']->CHAMADO}</h2>
													            <p style='margin-bottom: 10px;'><strong>Assunto:</strong> {$this->dados['chamado']->ASSUNTO}</p>
													            <p style='margin-bottom: 10px;'><strong>Descri��o:</strong></p>{$this->dados['chamado']->DES_CHAMADO}
										            		</div>
										            	</td>
										            </tr>
										        </table>
										        <br />
										        <br />
											</td>
								        </tr>
									</tbody>
									</table>
								</body>
							</html>";
	            $email->MsgHTML($mensagem);
	            $email->AddAddress("{$this->dados['chamado']->EMAIL_SOLICITANTE}");
	            if (($this->dados['chamado']->AMBIENTE == 2) && (($this->dados['chamado']->SUBCATEGORIA == 5) || ($this->dados['chamado']->SUBCATEGORIA == 59) || ($this->dados['chamado']->SUBCATEGORIA == 60))){
	            	if (isset($_POST['sigiloso'])){
	            		if ($_POST['sigiloso'] != 'S'){
			            	$apiTecempsubcategoria = new apiTecempsubcategoria();
			            	$env = $apiTecempsubcategoria->envolvidosAmbiente("1", $this->dados['chamado']->EMPRESA, $this->dados['chamado']->AMBIENTE);
			            	$sub = array();
			            	foreach ($env as $rs){
			            		unset($sub);
			            		$sub = explode(",", $rs->SUBCATEGORIA);
			            		if (in_array("{$this->dados['chamado']->SUBCATEGORIA}", $sub)){
			            			$email->AddCC("{$rs->EMAIL}");
			            		}
			            	}
	            		}
	            	}else{
	            		$apiTecempsubcategoria = new apiTecempsubcategoria();
	            		$env = $apiTecempsubcategoria->envolvidosAmbiente("1", $this->dados['chamado']->EMPRESA, $this->dados['chamado']->AMBIENTE);
	            		$sub = array();
	            		foreach ($env as $rs){
	            			unset($sub);
	            			$sub = explode(",", $rs->SUBCATEGORIA);
	            			if (in_array("{$this->dados['chamado']->SUBCATEGORIA}", $sub)){
	            				$email->AddCC("{$rs->EMAIL}");
	            			}
	            		}
	            	}
	            }
	            
	            if(isset($email_destinatario)){
	            	$email->AddCC($email_destinatario);
	            }
	            $email->AddCC("{$this->dados['chamado']->EMAIL_TECNICO}");
	            $email->Send();
	            $email->ClearAllRecipients();
	            $email->ClearAttachments();
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'help/chamado/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'help/chamado/index/sucesso');
				}
			}else{
				$this->rollback = new Chamado();
				$this->rollback->assunto = $_POST['assunto'];
				$this->rollback->des_chamado = $_POST['des_chamado'];
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}
		
		$this->view();
	}
	
	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "";
		$chamado = new Chamado();
		$exp = explode(",", $this->getParams(0));
		$chamado->chamado = $this->chamado = $exp[0];
		$chamado->ambiente = $this->ambiente = $exp[1];
		$apiChamado = new apiChamado();
		$this->dados = array('chamado' => $apiChamado->getChamado($chamado));
		$apiTecnico = new apiTecnico();
		//TECNICO
		$this->usuario = $apiTecnico->filtroTecnico('1', '3', 't.tecnico',$_SESSION['usuario_sessao'], $chamado->ambiente);
		$this->funcoes = new Funcoes();
		$this->movimento = $apiChamado->getMovimento($this->chamado, $this->ambiente);
		if (($this->dados['chamado']->AMBIENTE == 3) && (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-14"]))){
			$this->notafiscal = $apiChamado->getNotafiscal($this->chamado, $this->ambiente);
		}
		
		$apiTecnico = new apiTecnico();
		$tecnico = $apiTecnico->filtroTecnico('1','3','t.ativo', '1','tudo');
		foreach ($tecnico as $rs){
			$this->tec[$rs->AMBIENTE][$rs->N_LINHA] = array('tecnico' => $rs->TECNICO, 'nome' => $rs->NOME);
			$this->tecnico[$rs->TECNICO] = array('tecnico' => $rs->TECNICO, 'nome' => $rs->NOME);
		}
		$apiSubcategoria = new apiSubcategoria();
		$subcategoria = $apiSubcategoria->filtroSubcategoria('1','3','s.ativo', '1','tudo');
		foreach ($subcategoria as $rs){
			$this->categoria[$rs->AMBIENTE][$rs->DES_CATEGORIA] = array('categoria' => $rs->CATEGORIA, 'des_categoria' => $rs->DES_CATEGORIA, 'ambiente' => $rs->AMBIENTE, 'des_ambiente' => $rs->DES_AMBIENTE);
			$this->sub[$rs->CATEGORIA][$rs->N_LINHA] = array('subcategoria' => $rs->SUBCATEGORIA, 'des_subcategoria' => $rs->DES_SUBCATEGORIA, 'tempo_atendimento' => $rs->TEMPO_ATENDIMENTO);
			$this->subcategoria[$rs->CATEGORIA][$rs->SUBCATEGORIA] = array('subcategoria' => $rs->SUBCATEGORIA, 'des_subcategoria' => $rs->DES_SUBCATEGORIA, 'tempo_atendimento' => $rs->TEMPO_ATENDIMENTO);
		}
		$apiTipo = new apiTipo();
		$tipo = $apiTipo->filtroTipo('1','3','ativo', '1');
		foreach ($tipo as $rs){
			$this->tipo[$rs->TIPO] = array('tipo' => $rs->TIPO, 'des_tipo' => $rs->DES_TIPO);
		}
		$apiStatus = new apiStatus();
		$status = $apiStatus->filtroStatus('1','3','ativo', '1');
		foreach ($status as $rs){
			if (($rs->SITUACAO != 'C') && ($rs->SITUACAO != 'P')){
				$this->status[$rs->STATUS] = array('status' => $rs->STATUS, 'des_status' => $rs->DES_STATUS, 'situacao' => $rs->SITUACAO);
			}
		}
		$apiDepartamento = new apiDepartamento();
		$departamento = $apiDepartamento->filtroDepartamento('1','3','d.ativo', '1');
		foreach ($departamento as $rs){
			$this->departamento[$rs->DEPARTAMENTO] = array('departamento' => $rs->DEPARTAMENTO, 'des_departamento' => $rs->DES_DEPARTAMENTO);
		}
		$apiEmpresa = new apiEmpresa();
		$empresa = $apiEmpresa->filtroEmpresa('1','3','ativo', '1');
		foreach ($empresa as $rs){
			$this->empresa[$rs->EMPRESA] = array('empresa' => $rs->EMPRESA, 'des_empresa' => $rs->DES_EMPRESA);
		}
		$apiCargo = new apiCargo();
		$cargo = $apiCargo->filtroCargo('1','3','ativo', '1');
		foreach ($cargo as $rs){
			$this->cargo[$rs->CARGO] = array('cargo' => $rs->CARGO, 'des_cargo' => $rs->DES_CARGO);
		}
		//GET STATUS DA AUTORIZA��O
		$this->autorizacao = $apiChamado->getChamadoautorizacao($chamado);
		$apiTecempsubcategoria = new apiTecempsubcategoria();
		$i = 0;
		$sql = array();
		$Post = new Chamado();
		$Post->chamado = $this->chamado;
		$Post->ambiente = $this->ambiente;
		$des_movimento = "";
		$mov_fim = "";
		$env = "";
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}

		if ((is_array($this->usuario) ? count($this->usuario) : 0) > 0 || (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-16"]))) {
			if (isset($this->dados['chamado'])){
				if (($this->dados['chamado']->SOLICITANTE != $_SESSION['usuario_sessao']) && ($this->dados['chamado']->TECNICO != $_SESSION['usuario_sessao']) && ($this->dados['chamado']->DESTINATARIO != $_SESSION['usuario_sessao'])){
					if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-2"])){
						header('location:' .APP_ROOT. 'help/chamado/index/atualizar');
						die();
					}else{
						if ($this->dados['chamado']->AMBIENTE != @$this->usuario[0]->AMBIENTE){
							if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-16"])){
								header('location:' .APP_ROOT. 'help/index/index/acessonegado');
								die();
							}
						}
					}
				}
			}else{
				header('location:' .APP_ROOT. 'help/index/index/acessonegado');
				die();
			}
			$cc[100] = "Ve�culos novos";
			$cc[200] = "Ve�culos Seminovos";
			$cc[300] = "Pe�as ";
			$cc[400] = "Assist�ncia T�cnica";
			$cc[500] = "Administrativo";
			$cc[900] = "Holding";
			
				
			if ($_SERVER['REQUEST_METHOD'] === 'POST') {
				if ($_POST['submeter'] == "reabrir"){
					if ($this->dados['chamado']->SITUACAO == 'C'){
						$Post->dta_reabertura = date("d/m/Y H:i:s");
						$Post->dta_ult_movimento = date("d/m/Y H:i:s");
						$Post->status = 2;
						$des_movimento = "<b>Chamado Reaberto:</b> {$Post->dta_reabertura} <b>Por:</b> {$this->usuario[0]->NOME}<br><br>";
						$des_movimento .= "<b>De Status:</b> CONCLUIDO <b>Para Status:</b> EM ATENDIMENTO<br><br>";
						if ($this->dados['chamado']->TECNICO != $_SESSION['usuario_sessao']){
							$Post->tecnico = $_SESSION['usuario_sessao'];
							$des_movimento .= "<b>De T�cnico:</b> {$this->dados['chamado']->NOME_TECNICO} <b>Para T�cnico:</b> {$this->usuario[0]->NOME}<br><br>";
						}
						$novo = mktime(date('H')+$this->subcategoria[$this->dados['chamado']->CATEGORIA][$this->dados['chamado']->SUBCATEGORIA]['tempo_atendimento'],date('i'),date('s'),date('n'),date('j'),date('Y'));
						$Post->dta_vencimento = date('d/m/Y H:i:s',$novo);
						$sql[$i] = $apiChamado->editChamado($Post);
						$i = $i+1;
						$movimento = new Movimento();
						$movimento->chamado = $this->chamado;
						$movimento->ambiente = $this->ambiente;
						$movimento->usuario = $_SESSION['usuario_sessao'];
						$movimento->des_movimento = $des_movimento;
						$movimento->dta_movimento = date("d/m/Y H:i:s");
						$sql[$i] = $apiChamado->addMovimento($movimento);
						$rs = $apiChamado->executeSQL($sql);
						if (@$rs[4] == 'sucesso') {
							$env = "O chamado: {$this->chamado} foi reaberto em {$Post->dta_reabertura}";
						}
						
					}	
				}elseif ($_POST['submeter'] == "notafiscal"){
					$chamadonf = new Chamadonf();
					$chamadonf->chamado = $this->chamado;
					$chamadonf->ambiente = $this->ambiente;
					$sql[$i] = $apiChamado->delNotafiscal($chamadonf);
					$i = $i+1;
					$nota_fiscal = $_POST["nota_fiscal"];
					$fornecedor = $_POST["fornecedor"];
					$valor = $_POST["valor"];
					$dta_repasse = $_POST["dta_repasse"];
					foreach ($nota_fiscal as $key => $nf) {
						$chamadonf->nota_fiscal = $nf;
						$chamadonf->fornecedor = $this->funcoes->naoNumerico($fornecedor{$key});
						$chamadonf->valor = $this->funcoes->sanearValor($valor{$key});
						$chamadonf->dta_repasse = $dta_repasse{$key};
						$chamadonf->situacao = "EM";
						$sql[$i] = $apiChamado->addNotafiscal($chamadonf);
						$i = $i+1;
					}
					$rs = $apiChamado->executeSQL($sql);
					if (@$rs[4] == 'sucesso') {
						if (isset($this->PaginaAtual)) {
							header('location:' .APP_ROOT. 'help/chamado/alterar/'.$this->chamado.','.$this->ambiente.'/'.$this->PaginaAtual.'/sucesso');
							die();
						}else {
							header('location:' .APP_ROOT. 'help/chamado/alterar/'.$this->chamado.','.$this->ambiente.'/sucesso');
							die();
						}
					}
				}elseif (isset($_POST['fechar'])){
					$vencimento = "{$_POST['dta_vencimento']} {$_POST['tempo_vencimento']}";
					if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-10"]) && ($this->dados['chamado']->DTA_VENCIMENTO != $vencimento)){
						$Post->dta_vencimento = $vencimento;
						$des_movimento .= "<b>De Vencimento :</b> {$this->dados['chamado']->DTA_VENCIMENTO} <b>Para Vencimento:</b> {$vencimento}<br><br>";
					}
					if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-7"]) && ($this->dados['chamado']->TECNICO != $_POST['tecnico'])){
					 	$Post->tecnico = $_POST['tecnico'];
						$des_movimento .= "<b>De T�cnico:</b> {$this->dados['chamado']->NOME_TECNICO} <b>Para T�cnico:</b> {$this->tecnico[$_POST['tecnico']]['nome']}<br><br>";
					}
					if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-8"]) && ($this->dados['chamado']->AMBIENTE != 2) && ($this->dados['chamado']->SUBCATEGORIA != $_POST['subcategoria'])){
						$Post->subcategoria = $_POST['subcategoria'];
					 	$des_movimento .= "<b>De Subcategoria:</b> {$this->dados['chamado']->DES_SUBCATEGORIA} <b>Para Subcategoria:</b> {$this->subcategoria[$_POST['categoria']][$_POST['subcategoria']]['des_subcategoria']}<br><br>";
					}
					if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-5"]) && ($this->dados['chamado']->TIPO != $_POST['tipo'])){
					 	$Post->tipo = $_POST['tipo'];
						$des_movimento .= "<b>De Tipo:</b> {$this->dados['chamado']->DES_TIPO} <b>Para Tipo:</b> {$this->tipo[$_POST['tipo']]['des_tipo']}<br><br>";
					}
					if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-4"]) && ($this->dados['chamado']->DEPARTAMENTO != $_POST['departamento'])){
						$Post->departamento = $_POST['departamento'];
						$des_movimento .= "<b>De Departamento:</b> {$this->dados['chamado']->DES_DEPARTAMENTO} <b>Para Departamento:</b> {$this->departamento[$_POST['departamento']]['des_departamento']} <br><br>";
					}
					if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-9"]) && ($this->dados['chamado']->EMPRESA != $_POST['empresa'])){
						$Post->empresa = $_POST['empresa'];
						$des_movimento .= "<b>De Empresa:</b> {$this->dados['chamado']->DES_EMPRESA} <b>Para Empresa:</b> {$this->empresa[$_POST['empresa']]['des_empresa']}<br><br>";
					}
					if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-18"]) && ($this->dados['chamado']->DEPARTAMENTO_SOLICITANTE != $_POST['departamento_solicitante'])){
						$cadusuario = new Usuario();
						$apiUsuario = new apiUsuario();
						$cadusuario->usuario = $this->dados['chamado']->SOLICITANTE;
						$cadusuario->departamento = $_POST['departamento_solicitante'];
						$des_movimento .= "<b>De Departamento Solicitante:</b> {$this->dados['chamado']->DESDEPARTAMENTO_SOLICITANTE} <b>Para Departamento Solicitante:</b> {$this->departamento[$_POST['departamento_solicitante']]['des_departamento']}<br><br>";
						$sql[$i] = $apiUsuario->editUsuario($cadusuario);
						$i=$i+1;
					}
					if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-19"]) && ($this->dados['chamado']->CARGO_SOLICITANTE != $_POST['cargo_solicitante'])){
						$cadusuario = new Usuario();
						$apiUsuario = new apiUsuario();
						$cadusuario->usuario = $this->dados['chamado']->SOLICITANTE;
						$cadusuario->cargo = $_POST['cargo_solicitante'];
						$des_movimento .= "<b>De Cargo Solicitante:</b> {$this->dados['chamado']->DESCARGO_SOLICITANTE} <b>Para Cargo Solicitante:</b> {$this->cargo[$_POST['cargo_solicitante']]['des_cargo']}<br><br>";
						$sql[$i] = $apiUsuario->editUsuario($cadusuario);
						$i=$i+1;
					}
					//rh
					if ($this->dados['chamado']->AMBIENTE == '2'){
						if (isset($_POST['obs'])){
							if ($this->dados['chamado']->OBS != $_POST['obs']){
								$Post->obs = $_POST['obs'];
							}
						}
						if ($this->dados['chamado']->SUBCATEGORIA == 60 && $this->dados['chamado']->AUT_SITUACAO == '0'){
							$expo = explode("-", $_POST['funcionario']);
							if ($this->dados['chamado']->FUNCIONARIO != $expo[0]){
								$Post->funcionario = $expo[0];
								$des_movimento .= "<b>De Funcion�rio MD:</b> {$this->dados['chamado']->NOME_FUNCIONARIO} <b>Para Funcion�rio MD:</b> {$expo[1]}<br><br>";
							}
							if ($this->dados['chamado']->DTA_ADMISSAO != $_POST['dta_admissao']){
								$Post->dta_admissao = $_POST['dta_admissao'];
								$des_movimento .= "<b>De Admiss�o MD:</b> {$this->dados['chamado']->DTA_ADMISSAO} <b>Para Admiss�o MD:</b> {$_POST['dta_admissao']}<br><br>";
							}
							if ($this->dados['chamado']->DTA_DEMISSAO != $_POST['dta_demissao']){
								$Post->dta_demissao = $_POST['dta_demissao'];
								$des_movimento .= "<b>De Demiss�o MD:</b> {$this->dados['chamado']->DTA_DEMISSAO} <b>Para Demiss�o MD:</b> {$_POST['dta_demissao']}<br><br>";
							}
						}
						
						if ($this->dados['chamado']->SUBCATEGORIA == 59){
							$cadusuario = new Usuario();
							$apiUsuario = new apiUsuario();
							if ($this->dados['chamado']->AUT_SITUACAO == '0'){
								$expo = explode("-", $_POST['funcionario']);
								if ($this->dados['chamado']->FUNCIONARIO != $expo[0]){
									$Post->funcionario = $expo[0];
									$des_movimento .= "<b>De Funcion�rio MP:</b> {$this->dados['chamado']->NOME_FUNCIONARIO} <b>Para Funcion�rio MP:</b> {$expo[1]}<br><br>";
								}
								if ($this->dados['chamado']->DTA_ADMISSAO != $_POST['dta_admissao']){
									$Post->dta_admissao = $_POST['dta_admissao'];
									$des_movimento .= "<b>De Admiss�o MP:</b> {$this->dados['chamado']->DTA_ADMISSAO} <b>Para Admiss�o MP:</b> {$_POST['dta_admissao']}<br><br>";
								}
								if ($this->dados['chamado']->DTA_VIGENCIA != $_POST['dta_vigencia']){
									$Post->dta_vigencia = $_POST['dta_vigencia'];
									$des_movimento .= "<b>De Vig�ncia MP:</b> {$this->dados['chamado']->DTA_VIGENCIA} <b>Para Vig�ncia MP:</b> {$_POST['dta_vigencia']}<br><br>";
								}
								$expo = explode("-", $_POST['funcionario_substituido']);
								if ($this->dados['chamado']->FUNCIONARIO_SUBSTITUIDO != $expo[0]){
									$Post->funcionario_substituido = $expo[0];
									$des_movimento .= "<b>De Funcion�rio Substituido MP:</b> {$this->dados['chamado']->NOME_SUBSTITUIDO} <b>Para Funcion�rio Substituido MP:</b> {$expo[1]}<br><br>";
								}
								if (isset($_POST['m_cargo'])){
									if ($this->dados['chamado']->AN_CARGO != $_POST['an_cargo']){
										$Post->an_cargo= $_POST['an_cargo'];
										$des_movimento .= "<b>De Cargo Usu�rio:</b> {$this->dados['chamado']->AN_DESCARGO} <b>Para Cargo Usu�rio:</b> {$this->cargo[$_POST['an_cargo']]['des_cargo']}<br><br>";
									}
									
									if ($this->dados['chamado']->M_CARGO != $_POST['m_cargo']){
										$Post->m_cargo = $_POST['m_cargo'];
										$cadusuario->cargo = $_POST['m_cargo'];
										$des_movimento .= "<b>De Cargo MP:</b> {$this->dados['chamado']->M_DESCARGO} <b>Para Cargo MP:</b> {$this->cargo[$_POST['m_cargo']]['des_cargo']}<br><br>";
									}else{
										$cadusuario->cargo = $_POST['m_cargo'];
									}
								}
								if (isset($_POST['m_departamento'])){
									if ($this->dados['chamado']->AN_DEPARTAMENTO != $_POST['an_departamento']){
										$Post->an_departamento = $_POST['an_departamento'];
										$des_movimento .= "<b>De Departamento Usu�rio:</b> {$this->dados['chamado']->AN_DESDEPARTAMENTO} <b>Para Departamento Usu�rio:</b> {$this->departamento[$_POST['an_departamento']]['des_departamento']}<br><br>";
									}
									if ($this->dados['chamado']->M_DEPARTAMENTO != $_POST['m_departamento']){
										$Post->m_departamento = $_POST['m_departamento'];
										$cadusuario->departamento = $_POST['m_departamento'];
										$des_movimento .= "<b>De Departamento MP:</b> {$this->dados['chamado']->M_DESDEPARTAMENTO} <b>Para Departamento MP:</b> {$this->departamento[$_POST['m_departamento']]['des_departamento']}<br><br>";
									}else{
										$cadusuario->departamento = $_POST['m_departamento'];
									}
								}
								$salario = $this->funcoes->sanearValor($_POST['salario']);
								if ($this->dados['chamado']->SALARIO != $salario){
									$Post->salario = $salario;
									$des_movimento .= "<b>De Sal�rio:</b> {$this->dados['chamado']->SALARIO} <b>Para Sal�rio:</b> {$salario}<br><br>";
								}
								$m_salario = $this->funcoes->sanearValor($_POST['m_salario']);
								if ($this->dados['chamado']->M_SALARIO != $m_salario){
									$Post->m_salario = $m_salario;
									$des_movimento .= "<b>De Sal�rio MP:</b> {$this->dados['chamado']->M_SALARIO} <b>Para Sal�rio MP:</b> {$m_salario}<br><br>";
								}
								if (isset($_POST['comissao'])){
									$comissao = strtoupper($_POST['comissao']);
									if ($this->dados['chamado']->COMISSAO != $comissao){
										$Post->comissao = $comissao;
										$des_movimento .= "<b>De Comiss�o MP:</b> {$this->dados['chamado']->COMISSAO} <b>Para Comiss�o MP:</b> {$comissao}<br><br>";
									}
								}
								if (isset($_POST['m_empresa'])){
									if ($this->dados['chamado']->AN_EMPRESA != $_POST['an_empresa']){
										$Post->an_empresa = $_POST['an_empresa'];
										$des_movimento .= "<b>De Empresa Usu�rio:</b> {$this->dados['chamado']->AN_DESEMPRESA} <b>Para Empresa Usu�rio:</b> {$this->empresa[$_POST['an_empresa']]['des_empresa']}<br><br>";
									}
									if ($this->dados['chamado']->M_EMPRESA != $_POST['m_empresa']){
										$Post->m_empresa = $_POST['m_empresa'];
										$cadusuario->empresa = $_POST['m_empresa'];
										$des_movimento .= "<b>De Empresa MP:</b> {$this->dados['chamado']->M_DESEMPRESA} <b>Para Empresa MP:</b> {$this->empresa[$_POST['m_empresa']]['des_empresa']}<br><br>";
									}else{
										$cadusuario->empresa = $_POST['m_empresa'];
									}
								}
								if ($this->dados['chamado']->MOTIVO != $_POST['motivo']){
									$Post->motivo = $_POST['motivo'];
									$des_movimento .= "<b>De Motivo MP:</b> {$this->dados['chamado']->MOTIVO} <b>Para Motivo MP:</b> {$_POST['motivo']}<br><br>";
								}
								if ($this->dados['chamado']->AVALIACAO != $_POST['avaliacao']){
									$Post->avaliacao = $_POST['avaliacao'];
									$des_movimento .= "<b>De Avalia��o MP:</b> {$this->dados['chamado']->AVALIACAO} <b>Para Avalia��o MP:</b> {$_POST['m_empresa']}<br><br>";
								}
								if ($this->dados['chamado']->SIGILOSO != $_POST['sigiloso']){
									$Post->sigiloso = $_POST['sigiloso'];
									$des_movimento .= "<b>De Sigiloso MP:</b> {$this->dados['chamado']->SIGILOSO} <b>Para Sigiloso MP:</b> {$_POST['sigiloso']}<br><br>";
								}
								if (($cadusuario->cargo != "") || ($cadusuario->departamento != "") || ($cadusuario->empresa != "")){
									if ($Post->funcionario != ""){
										$cadusuario->usuario = $Post->funcionario;
										$sql[$i] = $apiUsuario->editUsuario($cadusuario);
										$i=$i+1;
									}else{
										$cadusuario->usuario = $this->dados['chamado']->FUNCIONARIO;
										$sql[$i] = $apiUsuario->editUsuario($cadusuario);
										$i=$i+1;
									}
								}
							}else{
								if ($this->dados['chamado']->M_CARGO != ""){
									$cadusuario->cargo = $this->dados['chamado']->M_CARGO;	
								}
								if ($this->dados['chamado']->M_DEPARTAMENTO != ""){
									$cadusuario->departamento = $this->dados['chamado']->M_DEPARTAMENTO;	
								}
								if ($this->dados['chamado']->M_EMPRESA != ""){					
									$cadusuario->empresa = $_POST['m_empresa'];
								}
								if (($cadusuario->cargo != "") || ($cadusuario->departamento != "") || ($cadusuario->empresa != "")){
									if ($Post->funcionario != ""){
										$cadusuario->usuario = $Post->funcionario;
										$sql[$i] = $apiUsuario->editUsuario($cadusuario);
										$i=$i+1;
									}else{
										$cadusuario->usuario = $this->dados['chamado']->FUNCIONARIO;
										$sql[$i] = $apiUsuario->editUsuario($cadusuario);
										$i=$i+1;
									}
								}
							}
						}
						if ($this->dados['chamado']->SUBCATEGORIA == 5 && $this->dados['chamado']->AUT_SITUACAO == '0'){
							if ($this->dados['chamado']->M_CARGO != $_POST['m_cargo']){
								$Post->m_cargo = $_POST['m_cargo'];
								$des_movimento .= "<b>De Cargo RP:</b> {$this->dados['chamado']->M_DESCARGO} <b>Para Cargo RP:</b> {$this->cargo[$_POST['m_cargo']]['des_cargo']}<br><br>";
							}
							if ($this->dados['chamado']->M_DEPARTAMENTO != $_POST['m_departamento']){
								$Post->m_departamento = $_POST['m_departamento'];
								$des_movimento .= "<b>De Departamento RP:</b> {$this->dados['chamado']->M_DESDEPARTAMENTO} <b>Para Departamento RP:</b> {$this->departamento[$_POST['m_departamento']]['des_departamento']}<br><br>";
							}
							if ($this->dados['chamado']->SIGILOSO != $_POST['sigiloso']){
								$Post->sigiloso = $_POST['sigiloso'];
								$des_movimento .= "<b>De Sigiloso RP:</b> {$this->dados['chamado']->SIGILOSO} <b>Para Sigiloso RP:</b> {$_POST['sigiloso']}<br><br>";
							}
							if ($this->dados['chamado']->LOJA != $_POST['loja']){
								$Post->loja = $_POST['loja'];
								$des_movimento .= "<b>De Loja RP:</b> {$this->dados['chamado']->LOJA} <b>Para Loja RP:</b> {$_POST['loja']}<br><br>";
							}
							if ($this->dados['chamado']->N_VAGA != $_POST['n_vaga']){
								$Post->n_vaga = $_POST['n_vaga'];
								$des_movimento .= "<b>De N� Vaga RP:</b> {$this->dados['chamado']->LOJA} <b>Para N� Vaga RP:</b> {$_POST['n_vaga']}<br><br>";
							}
							if ($this->dados['chamado']->DTA_ADMISSAO != $_POST['dta_admissao']){
								$Post->dta_admissao = $_POST['dta_admissao'];
								$des_movimento .= "<b>De Admiss�o RP:</b> {$this->dados['chamado']->DTA_ADMISSAO} <b>Para Admiss�o RP:</b> {$_POST['dta_admissao']}<br><br>";
							}
							if ($this->dados['chamado']->GENERO != $_POST['genero']){
								$Post->genero = $_POST['genero'];
								$des_movimento .= "<b>De Genero RP:</b> {$this->dados['chamado']->GENERO} <b>Para Admiss�o RP:</b> {$_POST['genero']}<br><br>";
							}
							if ($this->dados['chamado']->IDADE != $_POST['idade']){
								$Post->idade = $_POST['dta_admissao'];
								$des_movimento .= "<b>De Idade RP:</b> {$this->dados['chamado']->IDADE} <b>Para Idade RP:</b> {$_POST['idade']}<br><br>";
							}
							if ($this->dados['chamado']->ESTADO_CIVIL != $_POST['estado_civil']){
								$Post->estado_civil = $_POST['estado_civil'];
								$des_movimento .= "<b>De Estado Civil RP:</b> {$this->dados['chamado']->ESTADO_CIVIL} <b>Para Estado Civil RP:</b> {$_POST['estado_civil']}<br><br>";
							}
							if ($this->dados['chamado']->PERFIL != $_POST['perfil']){
								$Post->perfil = $_POST['perfil'];
								$des_movimento .= "<b>De Perfil RP:</b> {$this->dados['chamado']->PERFIL} <b>Para Perfil RP:</b> {$_POST['perfil']}<br><br>";
							}
							$salario = $this->funcoes->sanearValor($_POST['salario']);
							if ($this->dados['chamado']->SALARIO != $salario){
								$Post->salario =  $salario;
								$des_movimento .= "<b>De Sal�rio RP:</b> {$this->dados['chamado']->SALARIO} <b>Para Sal�rio RP:</b> {$salario}<br><br>";
							}
							if (isset($_POST['comissao'])){
								$comissao = strtoupper($_POST['comissao']);
								if ($this->dados['chamado']->COMISSAO != $comissao){
									$Post->comissao = $comissao;
									$des_movimento .= "<b>De Comiss�o RP:</b> {$this->dados['chamado']->COMISSAO} <b>Para Comiss�o RP:</b> {$comissao}<br><br>";
								}
							}
							if ($this->dados['chamado']->HORARIO != $_POST['horario']){
								$Post->horario = $_POST['horario'];
								$des_movimento .= "<b>De Hor�rio RP:</b> {$this->dados['chamado']->HORARIO} <b>Para Hor�rio RP:</b> {$_POST['horario']}<br><br>";
							}
							if ($view_chamado->JUSTIFICATIVA == 'S'){
								$expo = explode("-", $_POST['funcionario_substituido']);
								if ($this->dados['chamado']->FUNCIONARIO_SUBSTITUIDO != $expo[0]){
									$Post->funcionario_substituido = $expo[0];
									$des_movimento .= "<b>De Funcion�rio Substituido MP:</b> {$this->dados['chamado']->NOME_SUBSTITUIDO} <b>Para Funcion�rio Substituido MP:</b> {$expo[1]}<br><br>";
								}
								if ($this->dados['chamado']->DTA_DEMISSAO != $_POST['dta_demissao']){
									$Post->dta_demissao = $_POST['dta_demissao'];
									$des_movimento .= "<b>De Demiss�o RP:</b> {$this->dados['chamado']->DTA_DEMISSAO} <b>Para Demiss�o RP:</b> {$_POST['dta_demissao']}<br><br>";
								}
							}
						}
					}
					if (($this->dados['chamado']->AMBIENTE == '3') && ($this->dados['chamado']->CAMPANHA != $_POST['campanha'])){
						$Post->campanha = strtoupper($this->funcoes->retiraAcentos(trim($_POST['campanha'])));
						$des_movimento .= "<b>De Campanha:</b> ".($this->dados['chamado']->CAMPANHA != "" ? $this->dados['chamado']->CAMPANHA : "NAO INFORMADA")." <b> Para Campanha:</b> ".$Post->campanha."<br><br>";
					}
					
					if ($this->dados['chamado']->AMBIENTE == '5'){
						if ($this->dados['chamado']->SUBCATEGORIA == '61'){
							if ($this->dados['chamado']->DTA_INICIO != $_POST['dta_inicio']){
								$Post->dta_inicio = $_POST['dta_inicio'];
								$des_movimento .= "<b>De Inicio de Viagem:</b> {$this->dados['chamado']->DTA_INICIO} <b>Para Inicio de Viagem:</b> {$_POST['dta_inicio']}<br><br>";
							}
							if ($this->dados['chamado']->DTA_FIM != $_POST['dta_fim']){
								$Post->dta_fim = $_POST['dta_fim'];
								$des_movimento .= "<b>De Fim de Viagem:</b> {$this->dados['chamado']->DTA_FIM} <b>Para Fim de Viagem:</b> {$_POST['dta_fim']}<br><br>";
							}
							if ($this->dados['chamado']->DESTINO != $_POST['destino']){
								$Post->destino = $_POST['destino'];
								$des_movimento .= "<b>De Destino:</b> {$this->dados['chamado']->DESTINO} <b>Para Destino:</b> {$_POST['destino']}<br><br>";
							}
						}
						if ($this->dados['chamado']->SUBCATEGORIA == '62'){
							if ($this->dados['chamado']->DTA_INICIO != $_POST['dta_inicio']){
								$Post->dta_inicio = $_POST['dta_inicio'];
								$des_movimento .= "<b>De Data Inicio:</b> {$this->dados['chamado']->DTA_INICIO} <b>Para Data Inicio:</b> {$_POST['dta_inicio']}<br><br>";
							}
							if ($this->dados['chamado']->DTA_FIM != $_POST['dta_fim']){
								$Post->dta_fim = $_POST['dta_fim'];
								$des_movimento .= "<b>De Data Fim:</b> {$this->dados['chamado']->DTA_FIM} <b>Para Data Fim:</b> {$_POST['dta_fim']}<br><br>";
							}
							if ($this->dados['chamado']->CC != $_POST['cc']){
								$Post->cc = $_POST['cc'];
								$des_movimento .= "<b>De CC:</b> {$cc[$this->dados['chamado']->CC]}<b>Para CC:</b> {$cc[$_POST['cc']]}<br><br>";
							}
						}
						if ($this->dados['chamado']->SUBCATEGORIA == '66'){
							if ($this->dados['chamado']->DTA_INICIO != $_POST['dta_inicio']){
								$Post->dta_inicio = $_POST['dta_inicio'];
								$des_movimento .= "<b>De Data Inicio:</b> {$this->dados['chamado']->DTA_INICIO} <b>Para Data Inicio:</b> {$_POST['dta_inicio']}<br><br>";
							}
							if ($this->dados['chamado']->DTA_FIM != $_POST['dta_fim']){
								$Post->dta_fim = $_POST['dta_fim'];
								$des_movimento .= "<b>De Data Fim:</b> {$this->dados['chamado']->DTA_FIM} <b>Para Data Fim:</b> {$_POST['dta_fim']}<br><br>";
							}
							if ($this->dados['chamado']->MOTIVO != $_POST['motivo']){
								$Post->motivo = $_POST['motivo'];
								$motan = ($this->dados['chamado']->MOTIVO == "L") ? "Loja" : "Pv";
								$motatu = ($_POST['motivo'] == "L") ? "Loja" : "Pv";
								$des_movimento .= "<b>De Motivo:</b> {$motan}<b>Para Motivo:</b> {$motatu}<br><br>";
							}
						}
					}
					$Post->dta_fechamento = date("d/m/Y H:i:s");
					$movimento = new Movimento();
					$movimento->chamado = $this->chamado;
					$movimento->ambiente = $this->ambiente;
					$movimento->usuario = $_SESSION['usuario_sessao'];
					if ($_POST['status'] == 9){
						$Post->status = 9;
						$des_movimento .= "<b>De Status:</b> {$this->dados['chamado']->DES_STATUS} <b>Para Status:</b> CANCELAMENTO<br><br>";
						$movimento->des_movimento = "<b>Chamado Cancelado:</b> ".str_replace("\r\n","<br>",$_POST["des_movimento"])."<br><br>".$des_movimento;
					}elseif ($_POST['status'] == 10){
						$Post->status = 10;
						$des_movimento .= "<b>De Status:</b> {$this->dados['chamado']->DES_STATUS} <b>Para Status:</b> SEM RETORNO<br><br>";
						$movimento->des_movimento = "<b>Chamado Sem Retorno:</b> ".str_replace("\r\n","<br>",$_POST["des_movimento"])."<br><br>".$des_movimento;
					}else{
						$Post->status = 7;
						$des_movimento .= "<b>De Status:</b> {$this->dados['chamado']->DES_STATUS} <b>Para Status:</b> CONCLUIDO<br><br>";
						$movimento->des_movimento = "<b>Chamado Finalizado:</b> ".str_replace("\r\n","<br>",$_POST["des_movimento"])."<br><br>".$des_movimento;
					}
					$semana = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
					$semana = strtotime(date("m/d/Y", strtotime($semana)));
					$semana = $this->funcoes->retiraAcentos(str_replace("-feira", "", strtolower(strftime('%A',$semana))));
					if ($semana == "segunda"){
						$dia = 1;
					}elseif ($semana == "terca"){
						$dia = 2;
					}elseif ($semana == "quarta"){
						$dia = 3;
					}elseif ($semana == "quinta"){
						$dia = 4;
					}elseif ($semana == "sexta"){
						$dia = 5;
					}elseif ($semana == "sabado"){
						$dia = 6;
					}else{
						$dia = 7;
					}
					$atual = strtotime(date('Y-m-d'));
					$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
					$ult_mov = strtotime(date("Y-m-d", strtotime($ult_mov)));
					$calc_dias = $atual - $ult_mov;
					$dias_mov = round($calc_dias/(60 * 60 * 24));
					
					if ($dias_mov == 0){
						$atual = strtotime(date('Y-m-d H:i:s'));
						$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
						$ult_mov = strtotime(date("Y-m-d H:i:s", strtotime($ult_mov)));
						$duracao = $atual - $ult_mov;
						$duracao = round($duracao/60);
					}else{
						for ($i=0; $i <= $dias_mov; $i++){
							if ($i == 0){
								$fim_exp =  strtotime($this->dados['chamado']->HORA_FIM);
								$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
								$ult_mov = strtotime(date("H:i:s", strtotime($ult_mov)));
								$tempo = $fim_exp - $ult_mov;
								$duracao = round($tempo/60);
							}elseif ($i == $dias_mov){
								$ini_exp =  strtotime($this->dados['chamado']->HORA_INICIO);
								$mov =  strtotime(date('H:i:s'));
								$tempo = $mov - $ini_exp;
								$duracao = $duracao + round($tempo/60);
							}else{
								if ($dia == 6){
									$duracao = $duracao + 240;
								}elseif ($dia == 7){
									$duracao = $duracao;
									$dia = 0;
								}else{
									$duracao = $duracao + 528;
								}
							}
							$dia = $dia + 1;
						}
					}
					if ($this->dados['chamado']->SITUACAO == 'EA'){
						$Post->tempo_atendimento = ($this->dados['chamado']->TEMPO_ATENDIMENTO + $duracao);
					}elseif ($this->dados['chamado']->SITUACAO == 'AU'){
						$Post->tempo_aguardando = ($this->dados['chamado']->TEMPO_AGUARDANDO + $duracao);
					}else{
						$Post->tempo_outros = ($this->dados['chamado']->TEMPO_OUTROS + $duracao);
					}
					$Post->dta_ult_movimento = $Post->dta_fechamento;
					$sql[$i] = $apiChamado->editChamado($Post);
					$i = $i+1;
					$movimento->dta_movimento = date("d/m/Y H:i:s");
					if (isset($_FILES['anexo']['name'][0])) {
						$ex = explode(".", $_FILES['anexo']['name'][0]);
						$exp = end($ex);
						$movimento->anexo1 = "{$_SESSION['empresa_sessao']}-{$_SESSION['usuario_sessao']}-{$this->chamado}-{$this->ambiente}-Anexo1".date('dmY-His').".{$exp}";
					}
					if (isset($_FILES['anexo']['name'][1])) {
						$ex = explode(".", $_FILES['anexo']['name'][1]);
						$exp = end($ex);
						$movimento->anexo2 = "{$_SESSION['empresa_sessao']}-{$_SESSION['usuario_sessao']}-{$this->chamado}-{$this->ambiente}-Anexo2".date('dmY-His').".{$exp}";
					}
					if (isset($_FILES['anexo']['name'][2])) {
						$ex = explode(".", $_FILES['anexo']['name'][2]);
						$exp = end($ex);
						$movimento->anexo3 = "{$_SESSION['empresa_sessao']}-{$_SESSION['usuario_sessao']}-{$this->chamado}-{$this->ambiente}-Anexo3".date('dmY-His').".{$exp}";
					}
					$sql[$i] = $apiChamado->addMovimento($movimento);
					$rs = $apiChamado->executeSQL($sql);
					if (@$rs[4] == 'sucesso') {
						if (isset($_FILES['anexo']['tmp_name'][0])) {
							move_uploaded_file($_FILES['anexo']['tmp_name'][0], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/chamado/".$movimento->anexo1);
						}
						if (isset($_FILES['anexo']['tmp_name'][1])) {
							move_uploaded_file($_FILES['anexo']['tmp_name'][1], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/chamado/".$movimento->anexo2);
						}
						if (isset($_FILES['anexo']['tmp_name'][2])) {
							move_uploaded_file($_FILES['anexo']['tmp_name'][2], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/chamado/".$movimento->anexo3);
						}
						if($Post->status == 7){
							$env = "O chamado: {$this->chamado} foi fechado em {$Post->dta_fechamento}";
						}elseif($Post->status == 9){
							$env = "O chamado: {$this->chamado} foi cancelado em {$Post->dta_fechamento}";
						}else{
							$env = "O chamado: {$this->chamado} foi fechado sem retorno em {$Post->dta_fechamento}";
						}
					}
				}elseif ($_POST['submeter'] == "imprimir"){
					$funcoes = new Funcoes();
					$ex = explode(" ", $this->dados['chamado']->DTA_ABERTURA);
					$data_atual = $ex[0];
					//Dados da Empresa
					$razao = $this->dados['chamado']->RAZAO_SOCIAL;
					$nome = strtoupper($this->dados['chamado']->NOME_SOLICITANTE);
					if ($this->dados['chamado']->SUBCATEGORIA == 60){
						$funcionario = strtoupper($this->dados['chamado']->NOME_FUNCIONARIO);
						$dta_admissao = $this->dados['chamado']->DTA_ADMISSAO;
						$dta_demissao = $this->dados['chamado']->DTA_DEMISSAO;
						$motivo = str_replace("<br>","\r\n", $this->dados['chamado']->DES_CHAMADO);
						$pdf = new FPDF();
						$pdf->AddPage();
						$pdf->Rect(8, 10, 194, 265, 'D');
						$pdf->SetMargins(8, 8, 8);
						//Cabe�alho
						$pdf->Image(APP_ROOT."content/geral/img/monalog.png",10,11,16,14);
						$pdf->SetFont('arial','B',10);
						$pdf->Cell(172,6,"DATA",0,0,'R');
						$pdf->SetFont('arial','B',15);
						$pdf->Ln(6);
						$pdf->Cell(30,6,"",0,0,'L');
						$pdf->Cell(85,6,"MOVIMENTA��O DE PESSOAL - ",0,0,'L');
						$pdf->Cell(56,6,"N�: {$this->dados['chamado']->CHAMADO}",0,0,'L');
						$pdf->Image(APP_ROOT."content/geral/img/rhlog.jpg",150,11,16,14);
						$pdf->Line(170, 10, 170, 26);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(15,16,"{$data_atual}",0,0,'R');
						$pdf->Ln(10);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',13);
						$pdf->Cell(185,4,"Demiss�o",0,0,'C');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(2);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(4,4,"1",0,0,'L');
						$pdf->Line(12, 39, 12, 32);
						$pdf->Cell(18,4,"EMPRESA: ",0,0,'L');
						$pdf->SetFont('arial','',8);
						$pdf->Cell(150,4,"{$razao}",0,0,'L');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(2);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(23,4,"SOLICITANTE: ",0,0,'L');
						$pdf->SetFont('arial','',8);
						$pdf->Cell(194,4,"{$nome}",0,0,'L');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(2);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(5,4,"2",0,0,'L');
						$pdf->Line(12, 53, 12, 46);
						$pdf->Cell(187,4,"DADOS PESSOAIS",0,0,'C');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(48,4,"NOME COLABORADOR",0,0,'L');
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(80,12,"{$funcionario}",0,0,'C');
						$pdf->Ln(8);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(2);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(19,4,"ADMISS�O: ",0,0,'L');
						$pdf->SetFont('arial','',9);
						$pdf->Cell(56,4,"{$dta_admissao}",0,0,'L');
						$pdf->Line(100, 69, 100, 62);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(38,4,"DEMISS�O: ",0,0,'R');
						$pdf->SetFont('arial','',9);
						$pdf->Cell(16,4,"{$dta_demissao}",0,0,'R');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(5,4,"MOTIVO DETALHADO: ",0,0,'L');
						$pdf->Ln(4);
						$pdf->SetFont('arial','',10);
						$pdf->MultiCell(194,4,$motivo,0,'L',false);
						$pdf->Ln(2);
						$pdf->MultiCell(194,4,@$this->dados['chamado']->OBS,0,'L',false);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->SetXY(8, 248);
						$pdf->SetFont('arial','B',9);
						$pdf->Ln(4);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->Cell(194,4,"Assinatura para Aprova��o desta movimenta��o (Gerente Geral/Diretor):",0,1,'C');
						$pdf->Ln(1);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(11);
						$pdf->Cell(194,4,"Data:___/___/______  ____________________________________",0,0,'L');
						
						$pdf->Output("MPD-".date("d-m-Y").".pdf","D");
					}
					
					if ($this->dados['chamado']->SUBCATEGORIA == 59){
						$funcionario = strtoupper($this->dados['chamado']->NOME_FUNCIONARIO);
						$dta_admissao = $this->dados['chamado']->DTA_ADMISSAO;
						$motivo = str_replace("<br>","\r\n", $this->dados['chamado']->DES_CHAMADO);
						$pdf = new FPDF();
						$pdf->AddPage();
						$pdf->Rect(8, 10, 194, 265, 'D');
						$pdf->SetMargins(8, 8, 8);
						//Cabe�alho
						$pdf->Image(APP_ROOT."content/geral/img/monalog.png",10,11,16,14);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(172,6,"DATA",0,0,'R');
						$pdf->SetFont('arial','B',15);
						$pdf->Ln(6);
						$pdf->Cell(30,6,"",0,0,'L');
						$pdf->Cell(85,6,"MOVIMENTA��O DE PESSOAL - ",0,0,'L');
						$pdf->Cell(56,6,"N�: {$this->dados['chamado']->CHAMADO}",0,0,'L');
						$pdf->Image(APP_ROOT."content/geral/img/rhlog.jpg",150,11,16,14);
						$pdf->Line(170, 10, 170, 26);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(15,16,"{$data_atual}",0,0,'R');
						$pdf->Ln(10);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',13);
						$pdf->Cell(194,4,"Movimenta��o",0,0,'C');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(2);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(4,4,"1",0,0,'L');
						$pdf->Line(12, 39, 12, 32);
						$pdf->Cell(18,4,"EMPRESA: ",0,0,'L');
						$pdf->SetFont('arial','',8);
						$pdf->Cell(194,4,"{$razao}",0,0,'L');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(2);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(23,4,"SOLICITANTE: ",0,0,'L');
						$pdf->SetFont('arial','',8);
						$pdf->Cell(125,4,"{$nome}",0,0,'L');
						if ($this->dados['chamado']->SIGILOSO == 'S'){
							$sigiloso = 'SIM';
						}else{
							$sigiloso = 'N�O';
						}
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(36,4,"PROCESSO SIGILOSO:",0,0,'L');
						$pdf->SetFont('arial','',8);
						$pdf->Cell(70,4,"{$sigiloso}",0,0,'L');
						$pdf->Line(156, 46, 156, 39);
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(2);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(5,4,"2",0,0,'L');
						$pdf->Line(12, 53, 12, 46);
						$pdf->Cell(187,4,"DADOS PESSOAIS",0,0,'C');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(48,4,"NOME COLABORADOR",0,0,'L');
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(80,12,"{$this->dados['chamado']->CONTRATO} - {$funcionario}",0,0,'C');
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(62,3,"Data de Admiss�o:",0,0,'R');
						$pdf->SetFont('arial','',9);
						$pdf->Cell(-28,12,"{$dta_admissao}",0,0,'C');
						$pdf->Line(170, 62, 170, 53);
						$pdf->Ln(8);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(2);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(5,4,"3",0,0,'L');
						$pdf->Line(12, 69, 12, 62);
						$pdf->Cell(180,4,"ALTERA��O SOLICITADA",0,0,'C');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						if (isset($this->dados['chamado']->M_CARGO)){
							$pdf->SetFont('arial','B',9);
							$pdf->Cell(19,4,"DE CARGO: ",0,0,'L');
							$pdf->SetFont('arial','',8);
							$pdf->Cell(80,4,"{$this->dados['chamado']->AN_DESCARGO}",0,0,'L');
							$pdf->SetFont('arial','B',9);
							$pdf->Cell(11,4,"PARA: ",0,0,'L');
							$pdf->SetFont('arial','',8);
							$pdf->Cell(88,4,"{$this->dados['chamado']->M_DESCARGO}",0,0,'L');
							$pdf->Ln(5);
							$pdf->Cell(0,0,"","B",0,'C');
							$pdf->Ln(1);
						}
						if (isset($this->dados['chamado']->M_DEPARTAMENTO)){
							$pdf->SetFont('arial','B',9);
							$pdf->Cell(16,4,"DE DEPT.: ",0,0,'L');
							$pdf->SetFont('arial','',8);
							$pdf->Cell(83,4,"{$this->dados['chamado']->AN_DESDEPARTAMENTO}",0,0,'L');
							$pdf->SetFont('arial','B',9);
							$pdf->Cell(11,4,"PARA: ",0,0,'L');
							$pdf->SetFont('arial','',8);
							$pdf->Cell(88,4,"{$this->dados['chamado']->M_DESDEPARTAMENTO}",0,0,'L');
							$pdf->Ln(5);
							$pdf->Cell(0,0,"","B",0,'C');
							$pdf->Ln(1);
						}
						if (isset($this->dados['chamado']->M_SALARIO)){
							$pdf->SetFont('arial','B',9);
							$pdf->Cell(21,4,"DE SAL�RIO: ",0,0,'L');
							$pdf->SetFont('arial','',8);
							$pdf->Cell(78,4,"R$ ".number_format(str_replace(",", ".", $this->dados['chamado']->SALARIO), 2, ",", ".")."",0,0,'L');
							$pdf->SetFont('arial','B',9);
							$pdf->Cell(11,4,"PARA: ",0,0,'L');
							$pdf->SetFont('arial','',8);
							$pdf->Cell(88,4,"R$ ".number_format(str_replace(",", ".", $this->dados['chamado']->M_SALARIO), 2, ",", ".")."",0,0,'L');
							$pdf->Ln(5);
							$pdf->Cell(0,0,"","B",0,'C');
							$pdf->Ln(1);
						}
						if (isset($this->dados['chamado']->M_EMPRESA)){
							$pdf->SetFont('arial','B',9);
							$pdf->Cell(23,4,"DE EMPRESA: ",0,0,'L');
							$pdf->SetFont('arial','',8);
							$pdf->Cell(76,4,"{$this->dados['chamado']->AN_DESEMPRESA}",0,0,'L');
							$pdf->SetFont('arial','B',9);
							$pdf->Cell(11,4,"PARA: ",0,0,'L');
							$pdf->SetFont('arial','',8);
							$pdf->Cell(88,4,"{$this->dados['chamado']->M_DESEMPRESA}",0,0,'L');
							$pdf->Ln(5);
							$pdf->Cell(0,0,"","B",0,'C');
							$pdf->Ln(1);
						}
						if (isset($this->dados['chamado']->FUNCIONARIO_SUBSTITUIDO)){
							$substituido = strtoupper($funcoes->retiraAcentos(trim($this->dados['chamado']->NOME_SUBSTITUIDO)));
							$pdf->SetFont('arial','B',9);
							$pdf->Cell(65,4,"SUBSTITUI��O DO COLABORADOR: ",0,0,'L');
							$pdf->SetFont('arial','',8);
							$pdf->Cell(100,4,"{$substituido}",0,0,'L');
							$pdf->Ln(5);
							$pdf->Cell(0,0,"","B",0,'C');
							$pdf->Ln(1);
						}
						if ($this->dados['chamado']->COMISSAO != ""){
							$pdf->SetFont('arial','B',9);
							$pdf->Cell(20,4,"COMISS�O:",0,0,'L');
							$pdf->SetFont('arial','',8);
							$pdf->Cell(100,4,"{$this->dados['chamado']->COMISSAO}",0,0,'L');
							$pdf->Ln(5);
							$pdf->Cell(0,0,"","B",0,'C');
							$pdf->Ln(1);
						}
						$pdf->SetFont('arial','B',9);
						$pdf->Ln(-1);
						$pdf->Cell(4,5,"4",'R',0,'L');
						$pdf->Cell(180,5,"INFORMA��ES COMPLEMENTARES",0,0,'C');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(41,4,"MOTIVA��O PROMO��O:",0,0,'L');
						if ($this->dados['chamado']->MOTIVO == 'E'){
							$promocao = "ESPONT�NEO";
						}elseif ($this->dados['chamado']->MOTIVO == 'M'){
							$promocao = "M�RITO";
						}else{
							$promocao = "AVALIA��O DE DESEMPENHO";
						}
						$pdf->SetFont('arial','',8);
						$pdf->Cell(100,4,"{$promocao}",0,0,'L');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						if ($this->dados['chamado']->AVALIACAO == 'S'){
							$avaliacao = "SIM";
						}else{
							$avaliacao = "N�O";
						}
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(84,4,"O COLABORADOR PASSOU POR AVALIA��O NO RH: ",0,0,'L');
						$pdf->SetFont('arial','',8);
						$pdf->Cell(0,4,"{$avaliacao}",0,0,'L');
						$pdf->Ln(3);
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(1,5,"(Entrevistas e Testes)",0,0,'L');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(0);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(51,5,"TEMPO NA FUN��O ANTERIOR: ",0,0,'L');
						$tempo_funcao = $this->dados['chamado']->TEMPO_FUNCAO;
						$pdf->SetFont('arial','',8);
						$pdf->Cell(95,5,"{$tempo_funcao}",0,0,'L');
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(27,5,"Data da Vig�ncia: ","L",0,'R');
						$pdf->SetFont('arial','',9);
						$pdf->Cell(16,5,"{$this->dados['chamado']->DTA_VIGENCIA}",0,0,'R');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(5,4,"MOTIVO DETALHADO: ",0,0,'L');
						$pdf->Ln(4);
						$pdf->SetFont('arial','',10);
						$pdf->MultiCell(194,4,$motivo,0,'L',false);
						$pdf->Ln(2);
						$pdf->MultiCell(194,4,@$this->dados['chamado']->OBS,0,'L',false);
						//$pdf->Cell(0,0,"","B",0,'C');
						$pdf->SetXY(8, 190);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->Cell(194,4,"Autoriza��es da Requisi��o:",0,0,'C');
						$pdf->Ln(4);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(65,4,"Autoriza��o do Analista",0,0,'L');
						$pdf->Cell(65,4,"Autoriza��o do Gestor",0,0,'L');
						$pdf->Cell(65,4,"Autoriza��o do Gerente DHO",0,1,'L');
						$pdf->SetFont('arial','',7);
						//1
						sort($this->autorizacao);
						if (isset($this->autorizacao[0]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Data Solicita��o: {$this->autorizacao[0]->DTA_SOLICITACAO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Data Solicita��o: {$this->autorizacao[1]->DTA_SOLICITACAO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[2]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Data Solicita��o: {$this->autorizacao[2]->DTA_SOLICITACAO}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//2
						if (isset($this->autorizacao[0]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Situa��o: Aprova��o do Analista",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Situa��o: Aprova��o do Gestor",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[2]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Situa��o: Aprova��o do Gerente DHO",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//3
						if (isset($this->autorizacao[0]->DESTINATARIO)){
							$pdf->Cell(65,3,"Destinat�rio: {$this->autorizacao[0]->NOME_DESTINATARIO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->DESTINATARIO)){
							$pdf->Cell(65,3,"Destinat�rio: {$this->autorizacao[1]->NOME_DESTINATARIO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[2]->DESTINATARIO)){
							$pdf->Cell(65,3,"Destinat�rio: {$this->autorizacao[2]->NOME_DESTINATARIO}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//4
						if (isset($this->autorizacao[0]->AUTORIZANTE)){
							$pdf->Cell(65,3,"Autorizante: {$this->autorizacao[0]->NOME_AUTORIZANTE}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->AUTORIZANTE)){
							$pdf->Cell(65,3,"Autorizante: {$this->autorizacao[1]->NOME_AUTORIZANTE}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[2]->AUTORIZANTE)){
							$pdf->Cell(65,3,"Autorizante: {$this->autorizacao[2]->NOME_AUTORIZANTE}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//5
						if (isset($this->autorizacao[0]->DTA_ACAO)){
							$pdf->Cell(65,3,"Data A��o: {$this->autorizacao[0]->DTA_ACAO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->DTA_ACAO)){
							$pdf->Cell(65,3,"Data A��o: {$this->autorizacao[1]->DTA_ACAO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[2]->DTA_ACAO)){
							$pdf->Cell(65,3,"Data A��o: {$this->autorizacao[2]->DTA_ACAO}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//6
						if (isset($this->autorizacao[0]->AUTORIZADO)){
							$autorizado = ($this->autorizacao[0]->AUTORIZADO == 'S') ? 'Sim' : 'N�o';
							$pdf->Cell(65,3,"Autorizado: {$autorizado}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->AUTORIZADO)){
							$autorizado = ($this->autorizacao[1]->AUTORIZADO == 'S') ? 'Sim' : 'N�o';
							$pdf->Cell(65,3,"Autorizado: {$autorizado}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[2]->AUTORIZADO)){
							$autorizado = ($this->autorizacao[2]->AUTORIZADO == 'S') ? 'Sim' : 'N�o';
							$pdf->Cell(65,3,"Autorizado: {$autorizado}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(65,4,"Autoriza��o do Analista",0,0,'L');
						$pdf->Cell(65,4,"Autoriza��o do Gestor DP",0,1,'L');
						$pdf->SetFont('arial','',7);
						
						//1
						if (isset($this->autorizacao[3]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Data Solicita��o: {$this->autorizacao[3]->DTA_SOLICITACAO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[4]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Data Solicita��o: {$this->autorizacao[4]->DTA_SOLICITACAO}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//2
						if (isset($this->autorizacao[3]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Situa��o: Aprova��o do Analista",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[4]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Situa��o: Aprova��o do Analista",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//3
						if (isset($this->autorizacao[3]->DESTINATARIO)){
							$pdf->Cell(65,3,"Destinat�rio: {$this->autorizacao[3]->NOME_DESTINATARIO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[4]->DESTINATARIO)){
							$pdf->Cell(65,3,"Destinat�rio: {$this->autorizacao[4]->NOME_DESTINATARIO}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//4
						if (isset($this->autorizacao[3]->AUTORIZANTE)){
							$pdf->Cell(65,3,"Autorizante: {$this->autorizacao[3]->NOME_AUTORIZANTE}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[4]->AUTORIZANTE)){
							$pdf->Cell(65,3,"Autorizante: {$this->autorizacao[4]->NOME_AUTORIZANTE}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//5
						if (isset($this->autorizacao[3]->DTA_ACAO)){
							$pdf->Cell(65,3,"Data A��o: {$this->autorizacao[3]->DTA_ACAO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[4]->DTA_ACAO)){
							$pdf->Cell(65,3,"Data A��o: {$this->autorizacao[4]->DTA_ACAO}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//6
						if (isset($this->autorizacao[3]->AUTORIZADO)){
							$autorizado = ($this->autorizacao[3]->AUTORIZADO == 'S') ? 'Sim' : 'N�o';
							$pdf->Cell(65,3,"Autorizado: {$autorizado}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[4]->AUTORIZADO)){
							$autorizado = ($this->autorizacao[4]->AUTORIZADO == 'S') ? 'Sim' : 'N�o';
							$pdf->Cell(65,3,"Autorizado: {$autorizado}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						$pdf->SetFont('arial','B',9);
						$pdf->Ln(4);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->Cell(194,4,"Assinatura para Aprova��o desta movimenta��o (Gerente Geral/Diretor):",0,1,'C');
						$pdf->Ln(1);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(11);
						$pdf->Cell(194,4,"Data:___/___/______  ____________________________________",0,0,'L');
						
						$pdf->Output("MPM-".date("d-m-Y").".pdf","D");
					}
					
					if ($this->dados['chamado']->SUBCATEGORIA == 5){
						$pdf = new FPDF();
						$pdf->AddPage();
						$pdf->Rect(8, 10, 194, 265, 'D');
						$pdf->SetMargins(8, 8, 8);
						//Cabe�alho
						$pdf->Image(APP_ROOT."content/geral/img/monalog.png",10,11,16,14);
						$pdf->SetFont('arial','B',15);
						$pdf->Ln(6);
						$pdf->Cell(45,6,"",0,0,'L');
						$pdf->Cell(75,6,"REQUISI��O DE PESSOAL - ",0,0,'L');
						$pdf->Cell(56,6,"N�: {$this->dados['chamado']->CHAMADO}",0,0,'L');
						$pdf->Image(APP_ROOT."content/geral/img/rhlog.jpg",182,11,16,14);
						$pdf->Ln(10);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(26,4,"REQUISITANTE:",0,0,'L');
						$pdf->SetFont('arial','',7);
						$pdf->Cell(59,4,"{$razao}",0,0,'L');
						$pdf->Line(156, 32, 156, 26);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(83,4,"TELEFONE:",0,0,'R');
						$pdf->SetFont('arial','',7);
						$pdf->Cell(17,4,"{$this->funcoes->mask($this->dados['chamado']->TELEFONE_SOLICITANTE,'(##)####-####')}",0,0,'R');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(23,4,"SOLICITANTE: ",0,0,'L');
						$pdf->SetFont('arial','',8);
						$pdf->Cell(150,4,"{$nome}",0,0,'L');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(36,4,"CARGO SOLICITANTE:",0,0,'L');
						$pdf->SetFont('arial','',7);
						$pdf->Cell(66,4,"{$this->dados['chamado']->M_DESCARGO}",0,0,'L');
						$pdf->Line(110, 38, 110, 32);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(13,4,"SETOR: ",0,0,'L');
						$pdf->SetFont('arial','',7);
						$pdf->Cell(60,4,"{$this->dados['chamado']->M_DESDEPARTAMENTO}",0,0,'L');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(37,4,"PROCESSO SIGILOSO:",0,0,'L');
						$pdf->SetFont('arial','',7);
						if ($this->dados['chamado']->SIGILOSO == 'S'){
							$sigiloso = 'SIM';
						}else{
							$sigiloso = 'N�O';
						}
						$pdf->Cell(65,4,"{$sigiloso}",0,0,'L');
						$pdf->Line(110, 44, 110, 38);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(14,4,"PONTO: ",0,0,'L');
						$pdf->SetFont('arial','',7);
						$ponto_venda = strtoupper(trim($this->dados['chamado']->LOJA));
						$pdf->Cell(60,4,"{$ponto_venda}",0,0,'L');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(23,4,"N� DE VAGAS:",0,0,'L');
						$pdf->SetFont('arial','',7);
						$n_vaga = trim($this->dados['chamado']->N_VAGA);
						$pdf->Cell(29,4,"{$n_vaga}",0,0,'L');
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(29,4,"DATA ADMISS�O:",0,0,'L');
						$pdf->SetFont('arial','',7);
						$dta_admissao = $this->dados['chamado']->DTA_ADMISSAO;
						$pdf->Cell(21,4,"$dta_admissao",0,0,'L');
						$pdf->Line(60, 50, 60, 44);
						$pdf->Line(110, 50, 110, 44);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(32,4,"DATA REQUISI��O:",0,0,'L');
						$pdf->SetFont('arial','',7);
						$pdf->Cell(60,4,"{$data_atual}",0,0,'L');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(102,4,"JUSTIFICATIVA DA REQUISI��O:",0,0,'L');
						$pdf->Cell(34,4,"PERFIL SOLICITADO:",0,1,'L');
						$pdf->SetFont('arial','',7);
						if ($this->dados['chamado']->JUSTIFICATIVA == 'A'){
							$justificativa = 'AMPLIA��O DO QUADRO';
						}else{
							$justificativa = 'SUBSTITUI��O';
						}
						$pdf->Cell(102,4,"{$justificativa}",0,0,'L');
						$pdf->SetFont('arial','',9);
						if ($this->dados['chamado']->GENERO == 'I'){
							$genero = 'INDIFERENTE';
						}elseif ($this->dados['chamado']->GENERO == 'M'){
							$genero = 'MASCULINO';
						}else{
							$genero = 'FEMININO';
						}
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(11,4,"SEXO: ",0,0,'L');
						$pdf->SetFont('arial','',7);
						$pdf->Cell(39,4,"{$genero}",0,1,'L');
						if ($this->dados['chamado']->JUSTIFICATIVA == 'S'){
							$substituido = strtoupper(trim($this->dados['chamado']->NOME_SUBSTITUIDO));
							$pdf->SetFont('arial','B',9);
							$pdf->Cell(24,4,"SUBSTITUIDO:",0,0,'L');
							$pdf->SetFont('arial','',7);
							$pdf->Cell(78,4,"{$substituido}",0,0,'L');
						}else{
							$pdf->Cell(102,4,"",0,0,'L');
						}
						if (isset($this->dados['chamado']->IDADE)){
							$pdf->SetFont('arial','B',9);
							$pdf->Cell(12,4,"IDADE: ",0,0,'L');
							$pdf->SetFont('arial','',7);
							$pdf->Cell(38,4,"{$this->dados['chamado']->IDADE}",0,1,'L');
						}else{
							$pdf->SetFont('arial','B',9);
							$pdf->Cell(12,4,"IDADE: ",0,0,'L');
							$pdf->SetFont('arial','',7);
							$pdf->Cell(38,4,"N�O INFORMADO",0,1,'L');
						}
						if ($this->dados['chamado']->JUSTIFICATIVA == 'S'){
							$dta_demissao = $this->dados['chamado']->DTA_DEMISSAO;
							$pdf->SetFont('arial','B',9);
							$pdf->Cell(37,4,"DATA DESLIGAMENTO:",0,0,'L');
							$pdf->SetFont('arial','',7);
							$pdf->Cell(65,4,"{$dta_demissao}",0,0,'L');
						}else{
							$pdf->Cell(102,4,"",0,0,'L');
						}
						if ($this->dados['chamado']->ESTADO_CIVIL == 'I'){
							$estado_civil = "INDIFERENTE";
						}elseif ($this->dados['chamado']->ESTADO_CIVIL== 'S'){
							$estado_civil = "SOLTEIRO";
						}elseif ($this->dados['chamado']->ESTADO_CIVIL== 'C'){
							$estado_civil = "CASADO";
						}elseif ($this->dados['chamado']->ESTADO_CIVIL== 'U'){
							$estado_civil = "UNI�O EST�VEL";
						}else{
							$estado_civil = "DIVORCIADO";
						}
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(24,4,"ESTADO CIVIL: ",0,0,'L');
						$pdf->SetFont('arial','',7);
						$pdf->Cell(60,4,"{$estado_civil}",0,1,'L');
						$pdf->Cell(102,4,"",0,0,'L');
						if ($this->dados['chamado']->PERFIL == 'I'){
							$perfil = "INDIFERENTE";
						}elseif ($this->dados['chamado']->PERFIL == 'J'){
							$perfil = "JUNIOR";
						}elseif ($this->dados['chamado']->PERFIL == 'P'){
							$perfil = "PLENO";
						}else{
							$perfil = "S�NIOR";
						}
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(13,4,"PERFIL: ",0,0,'L');
						$pdf->SetFont('arial','',7);
						$pdf->Cell(60,4,"{$perfil}",0,1,'L');
						$pdf->Line(110, 71, 110, 50);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(194,4,"DADOS DO CARGO:",0,0,'C');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(27,4,"REMUNERA��O:",0,0,'L');
						$pdf->SetFont('arial','',7);
						$pdf->Cell(35,4,"R$ ".number_format(str_replace(",", ".", $this->dados['chamado']->SALARIO), 2, ",", ".")."",0,0,'L');
						$pdf->Cell(40,4,"",0,0,'L');
						$pdf->Line(110, 77, 110, 71);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(17,4,"HOR�RIO:",0,0,'L');
						$pdf->SetFont('arial','',7);
						$horario = $this->dados['chamado']->HORARIO;
						$pdf->Cell(83,4,"{$horario}",0,0,'L');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						if ($this->dados['chamado']->COMISSAO != ""){
							$pdf->SetFont('arial','B',9);
							$pdf->Cell(20,4,"COMISS�O:",0,0,'L');
							$pdf->SetFont('arial','',7);
							$pdf->Cell(100,4,"{$this->dados['chamado']->COMISSAO}",0,0,'L');
							$pdf->Ln(5);
							$pdf->Cell(0,0,"","B",0,'C');
							$pdf->Ln(1);
						}
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(5,4,"COMPET�NCIAS ADICIONAIS: ",0,0,'L');
						$pdf->Ln(4);
						$competencia = str_replace("<br>","\r\n", $this->dados['chamado']->DES_CHAMADO);
						$pdf->SetFont('arial','',10);
						$pdf->MultiCell(194,4,$competencia,0,'L',false);
						$pdf->Ln(2);
						$pdf->MultiCell(194,4,@$this->dados['chamado']->OBS,0,'L',false);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->SetXY(8, 220);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->Cell(194,4,"Autoriza��es da Requisi��o:",0,0,'C');
						$pdf->Ln(4);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(65,4,"Autoriza��o do Analista",0,0,'L');
						$pdf->Cell(65,4,"Autoriza��o do Gestor",0,0,'L');
						$pdf->Cell(65,4,"Autoriza��o do Gerente DHO",0,1,'L');
						$pdf->SetFont('arial','',7);
						//1
						sort($this->autorizacao);
						if (isset($this->autorizacao[0]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Data Solicita��o: {$this->autorizacao[0]->DTA_SOLICITACAO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Data Solicita��o: {$this->autorizacao[1]->DTA_SOLICITACAO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[2]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Data Solicita��o: {$this->autorizacao[2]->DTA_SOLICITACAO}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//2
						if (isset($this->autorizacao[0]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Situa��o: Aprova��o do Analista",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Situa��o: Aprova��o do Gestor",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[2]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Situa��o: Aprova��o do Gerente DHO",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//3
						if (isset($this->autorizacao[0]->DESTINATARIO)){
							$pdf->Cell(65,3,"Destinat�rio: {$this->autorizacao[0]->NOME_DESTINATARIO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->DESTINATARIO)){
							$pdf->Cell(65,3,"Destinat�rio: {$this->autorizacao[1]->NOME_DESTINATARIO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[2]->DESTINATARIO)){
							$pdf->Cell(65,3,"Destinat�rio: {$this->autorizacao[2]->NOME_DESTINATARIO}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//4
						if (isset($this->autorizacao[0]->AUTORIZANTE)){
							$pdf->Cell(65,3,"Autorizante: {$this->autorizacao[0]->NOME_AUTORIZANTE}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->AUTORIZANTE)){
							$pdf->Cell(65,3,"Autorizante: {$this->autorizacao[1]->NOME_AUTORIZANTE}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[2]->AUTORIZANTE)){
							$pdf->Cell(65,3,"Autorizante: {$this->autorizacao[2]->NOME_AUTORIZANTE}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//5
						if (isset($this->autorizacao[0]->DTA_ACAO)){
							$pdf->Cell(65,3,"Data A��o: {$this->autorizacao[0]->DTA_ACAO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->DTA_ACAO)){
							$pdf->Cell(65,3,"Data A��o: {$this->autorizacao[1]->DTA_ACAO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[2]->DTA_ACAO)){
							$pdf->Cell(65,3,"Data A��o: {$this->autorizacao[2]->DTA_ACAO}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//6
						if (isset($this->autorizacao[0]->AUTORIZADO)){
							$autorizado = ($this->autorizacao[0]->AUTORIZADO == 'S') ? 'Sim' : 'N�o';
							$pdf->Cell(65,3,"Autorizado: {$autorizado}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->AUTORIZADO)){
							$autorizado = ($this->autorizacao[1]->AUTORIZADO == 'S') ? 'Sim' : 'N�o';
							$pdf->Cell(65,3,"Autorizado: {$autorizado}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[2]->AUTORIZADO)){
							$autorizado = ($this->autorizacao[2]->AUTORIZADO == 'S') ? 'Sim' : 'N�o';
							$pdf->Cell(65,3,"Autorizado: {$autorizado}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						$pdf->SetFont('arial','B',9);
						$pdf->Ln(4);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->Cell(194,4,"Assinatura e Aprova��o para aumento de quadro (Gerente Geral/Diretor):",0,1,'C');
						$pdf->Ln(1);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(11);
						$pdf->Cell(194,4,"Data:___/___/______  ____________________________________",0,0,'L');
						
						$pdf->Output("RP-".date("d-m-Y").".pdf","D");
					}
					
				}else{
					if ($this->dados['chamado']->SITUACAO == 'C'){
						if (isset($this->PaginaAtual)) {
							header('location:' .APP_ROOT. 'help/chamado/index/pagina/'.$this->PaginaAtual.'/atualizar');
							die();
						}else {
							header('location:' .APP_ROOT. 'help/chamado/index/atualizar');
							die();
						}
					}
					$vencimento = "{$_POST['dta_vencimento']} {$_POST['tempo_vencimento']}";
					if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-10"]) && ($this->dados['chamado']->DTA_VENCIMENTO != $vencimento)){
						$Post->dta_vencimento = $vencimento;
						$des_movimento .= "<b>De Vencimento :</b> {$this->dados['chamado']->DTA_VENCIMENTO} <b>Para Vencimento:</b> {$vencimento}<br><br>";
					}
					if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-7"]) && ($this->dados['chamado']->TECNICO != $_POST['tecnico'])){
					 	$Post->tecnico = $_POST['tecnico'];
						$des_movimento .= "<b>De T�cnico:</b> {$this->dados['chamado']->NOME_TECNICO} <b>Para T�cnico:</b> {$this->tecnico[$_POST['tecnico']]['nome']}<br><br>";
					}
					if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-8"]) && ($this->dados['chamado']->AMBIENTE != 2) && ($this->dados['chamado']->SUBCATEGORIA != $_POST['subcategoria'])){
						$Post->subcategoria = $_POST['subcategoria'];
					 	$des_movimento .= "<b>De Subcategoria:</b> {$this->dados['chamado']->DES_SUBCATEGORIA} <b>Para Subcategoria:</b> {$this->subcategoria[$_POST['categoria']][$_POST['subcategoria']]['des_subcategoria']}<br><br>";
					}
					if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-5"]) && ($this->dados['chamado']->TIPO != $_POST['tipo'])){
					 	$Post->tipo = $_POST['tipo'];
						$des_movimento .= "<b>De Tipo:</b> {$this->dados['chamado']->DES_TIPO} <b>Para Tipo:</b> {$this->tipo[$_POST['tipo']]['des_tipo']}<br><br>";
					}
					if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-4"]) && ($this->dados['chamado']->DEPARTAMENTO != $_POST['departamento'])){
						$Post->departamento = $_POST['departamento'];
						$des_movimento .= "<b>De Departamento:</b> {$this->dados['chamado']->DES_DEPARTAMENTO} <b>Para Departamento:</b> {$this->departamento[$_POST['departamento']]['des_departamento']} <br><br>";
					}
					if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-9"]) && ($this->dados['chamado']->EMPRESA != $_POST['empresa'])){
						$Post->empresa = $_POST['empresa'];
						$des_movimento .= "<b>De Empresa:</b> {$this->dados['chamado']->DES_EMPRESA} <b>Para Empresa:</b> {$this->empresa[$_POST['empresa']]['des_empresa']}<br><br>";
					}
					if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-18"]) && ($this->dados['chamado']->DEPARTAMENTO_SOLICITANTE != $_POST['departamento_solicitante'])){
						$cadusuario = new Usuario();
						$apiUsuario = new apiUsuario();
						$cadusuario->usuario = $this->dados['chamado']->SOLICITANTE;
						$cadusuario->departamento = $_POST['departamento_solicitante'];
						$des_movimento .= "<b>De Departamento Solicitante:</b> {$this->dados['chamado']->DESDEPARTAMENTO_SOLICITANTE} <b>Para Departamento Solicitante:</b> {$this->departamento[$_POST['departamento_solicitante']]['des_departamento']}<br><br>";
						$sql[$i] = $apiUsuario->editUsuario($cadusuario);
						$i=$i+1;
					}
					if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-19"]) && ($this->dados['chamado']->CARGO_SOLICITANTE != $_POST['cargo_solicitante'])){
						$cadusuario = new Usuario();
						$apiUsuario = new apiUsuario();
						$cadusuario->usuario = $this->dados['chamado']->SOLICITANTE;
						$cadusuario->cargo = $_POST['cargo_solicitante'];
						$des_movimento .= "<b>De Cargo Solicitante:</b> {$this->dados['chamado']->DESCARGO_SOLICITANTE} <b>Para Cargo Solicitante:</b> {$this->cargo[$_POST['cargo_solicitante']]['des_cargo']}<br><br>";
						$sql[$i] = $apiUsuario->editUsuario($cadusuario);
						$i=$i+1;
					}
					//RH
					if ($this->dados['chamado']->AMBIENTE == '2'){
						if ($this->dados['chamado']->SUBCATEGORIA == 60){
							$expo = explode("-", $_POST['funcionario']);
							if ($this->dados['chamado']->FUNCIONARIO != $expo[0]){
								$Post->funcionario = $expo[0];
								$des_movimento .= "<b>De Funcion�rio MD:</b> {$this->dados['chamado']->NOME_FUNCIONARIO} <b>Para Funcion�rio MD:</b> {$expo[1]}<br><br>";
							}
							if ($this->dados['chamado']->DTA_ADMISSAO != $_POST['dta_admissao']){
								$Post->dta_admissao = $_POST['dta_admissao'];
								$des_movimento .= "<b>De Admiss�o MD:</b> {$this->dados['chamado']->DTA_ADMISSAO} <b>Para Admiss�o MD:</b> {$_POST['dta_admissao']}<br><br>";
							}
							if ($this->dados['chamado']->DTA_DEMISSAO != $_POST['dta_demissao']){
								$Post->dta_demissao = $_POST['dta_demissao'];
								$des_movimento .= "<b>De Demiss�o MD:</b> {$this->dados['chamado']->DTA_DEMISSAO} <b>Para Demiss�o MD:</b> {$_POST['dta_demissao']}<br><br>";
							}
						}
						
						if ($this->dados['chamado']->SUBCATEGORIA == 59 && $this->dados['chamado']->AUT_SITUACAO == '0'){
							$cadusuario = new Usuario();
							$apiUsuario = new apiUsuario();
							$expo = explode("-", $_POST['funcionario']);
							if ($this->dados['chamado']->FUNCIONARIO != $expo[0]){
								$Post->funcionario = $expo[0];
								$des_movimento .= "<b>De Funcion�rio MP:</b> {$this->dados['chamado']->NOME_FUNCIONARIO} <b>Para Funcion�rio MP:</b> {$expo[1]}<br><br>";
							}
							if ($this->dados['chamado']->DTA_ADMISSAO != $_POST['dta_admissao']){
								$Post->dta_admissao = $_POST['dta_admissao'];
								$des_movimento .= "<b>De Admiss�o MP:</b> {$this->dados['chamado']->DTA_ADMISSAO} <b>Para Admiss�o MP:</b> {$_POST['dta_admissao']}<br><br>";
							}
							if ($this->dados['chamado']->DTA_VIGENCIA != $_POST['dta_vigencia']){
								$Post->dta_vigencia = $_POST['dta_vigencia'];
								$des_movimento .= "<b>De Vig�ncia MP:</b> {$this->dados['chamado']->DTA_VIGENCIA} <b>Para Vig�ncia MP:</b> {$_POST['dta_vigencia']}<br><br>";
							}
							if (isset($_POST['funcionario_substituido'])){
								$expo = explode("-", $_POST['funcionario_substituido']);
								if ($this->dados['chamado']->FUNCIONARIO_SUBSTITUIDO != $expo[0]){
									$Post->funcionario_substituido = $expo[0];
									$des_movimento .= "<b>De Funcion�rio Substituido MP:</b> {$this->dados['chamado']->NOME_SUBSTITUIDO} <b>Para Funcion�rio Substituido MP:</b> {$expo[1]}<br><br>";
								}
							}
							if (isset($_POST['m_cargo'])){
								if ($this->dados['chamado']->AN_CARGO != $_POST['an_cargo']){
									$cadusuario->cargo = $_POST['an_cargo'];
									$Post->an_cargo = $_POST['an_cargo'];
									$des_movimento .= "<b>De Cargo Usu�rio:</b> {$this->dados['chamado']->AN_DESCARGO} <b>Para Cargo Usu�rio:</b> {$this->cargo[$_POST['an_cargo']]['des_cargo']}<br><br>";
								}
								if ($this->dados['chamado']->M_CARGO != $_POST['m_cargo']){
									$Post->m_cargo = $_POST['m_cargo'];
									$des_movimento .= "<b>De Cargo MP:</b> {$this->dados['chamado']->M_DESCARGO} <b>Para Cargo MP:</b> {$this->cargo[$_POST['m_cargo']]['des_cargo']}<br><br>";
								}
							}
							if (isset($_POST['m_departamento'])){
								if ($this->dados['chamado']->AN_DEPARTAMENTO != $_POST['an_departamento']){
									$cadusuario->departamento = $_POST['an_departamento'];
									$Post->an_departamento = $_POST['an_departamento'];
									$des_movimento .= "<b>De Departamento Usu�rio:</b> {$this->dados['chamado']->AN_DESDEPARTAMENTO} <b>Para Departamento Usu�rio:</b> {$this->departamento[$_POST['an_departamento']]['des_departamento']}<br><br>";
								}
								if ($this->dados['chamado']->M_DEPARTAMENTO != $_POST['m_departamento']){
									$Post->m_departamento = $_POST['m_departamento'];
									$des_movimento .= "<b>De Departamento MP:</b> {$this->dados['chamado']->M_DESDEPARTAMENTO} <b>Para Departamento MP:</b> {$this->departamento[$_POST['m_departamento']]['des_departamento']}<br><br>";
								}
							}
							$salario = $this->funcoes->sanearValor($_POST['salario']);
							if ($this->dados['chamado']->SALARIO != $salario){
								$Post->salario = $salario;
								$des_movimento .= "<b>De Sal�rio:</b> {$this->dados['chamado']->SALARIO} <b>Para Sal�rio:</b> {$salario}<br><br>";
							}
							$m_salario = $this->funcoes->sanearValor($_POST['m_salario']);
							if ($this->dados['chamado']->M_SALARIO != $m_salario){
								$Post->m_salario = $m_salario;
								$des_movimento .= "<b>De Sal�rio MP:</b> {$this->dados['chamado']->M_SALARIO} <b>Para Sal�rio MP:</b> {$m_salario}<br><br>";
							}
							if (isset($_POST['comissao'])){
								$comissao = strtoupper($_POST['comissao']);
								if ($this->dados['chamado']->COMISSAO != $comissao){
									$Post->comissao = $comissao;
									$des_movimento .= "<b>De Comiss�o MP:</b> {$this->dados['chamado']->COMISSAO} <b>Para Comiss�o MP:</b> {$comissao}<br><br>";
								}
							}else{
								if ($this->dados['chamado']->COMISSAO != ""){
									$Post->comissao = "";
									$des_movimento .= "<b>De Comiss�o MP:</b> {$this->dados['chamado']->COMISSAO} <b>Para Comiss�o MP:</b> Sem Comiss�o<br><br>";
								}
							}
							if (isset($_POST['m_empresa'])){
								if ($this->dados['chamado']->AN_EMPRESA != $_POST['an_empresa']){
									$cadusuario->empresa = $_POST['an_empresa'];
									$Post->an_empresa = $_POST['an_empresa'];
									$des_movimento .= "<b>De Empresa Usu�rio:</b> {$this->dados['chamado']->AN_DESEMPRESA} <b>Para Empresa Usu�rio:</b> {$this->empresa[$_POST['an_empresa']]['des_empresa']}<br><br>";
								}
								if ($this->dados['chamado']->M_EMPRESA != $_POST['m_empresa']){
									$Post->m_empresa = $_POST['m_empresa'];
									$des_movimento .= "<b>De Empresa MP:</b> {$this->dados['chamado']->M_DESEMPRESA} <b>Para Empresa MP:</b> {$this->empresa[$_POST['m_empresa']]['des_empresa']}<br><br>";
								}
							}
							if ($this->dados['chamado']->MOTIVO != $_POST['motivo']){
								$Post->motivo = $_POST['motivo'];
								$des_movimento .= "<b>De Motivo MP:</b> {$this->dados['chamado']->MOTIVO} <b>Para Motivo MP:</b> {$_POST['motivo']}<br><br>";
							}
							if ($this->dados['chamado']->AVALIACAO != $_POST['avaliacao']){
								$Post->avaliacao = $_POST['avaliacao'];
								$des_movimento .= "<b>De Avalia��o MP:</b> {$this->dados['chamado']->AVALIACAO} <b>Para Avalia��o MP:</b> {$_POST['avaliacao']}<br><br>";
							}
							if ($this->dados['chamado']->SIGILOSO != $_POST['sigiloso']){
								$Post->sigiloso = $_POST['sigiloso'];
								$des_movimento .= "<b>De Sigiloso MP:</b> {$this->dados['chamado']->SIGILOSO} <b>Para Sigiloso MP:</b> {$_POST['sigiloso']}<br><br>";
							}
							if (isset($_POST['obs'])){
								if ($this->dados['chamado']->OBS != $_POST['obs']){
									$Post->obs = $_POST['obs'];
									$des_movimento .= "<b>Inform��o:</b> alterado informa��o no corpo da mp <br><br>";
								}
							}
							if (($cadusuario->cargo != "") || ($cadusuario->departamento != "") || ($cadusuario->empresa != "")){
								if ($Post->funcionario != ""){
									$cadusuario->usuario = $Post->funcionario;
									$sql[$i] = $apiUsuario->editUsuario($cadusuario);
									$i=$i+1;
								}else{
									$cadusuario->usuario = $this->dados['chamado']->FUNCIONARIO;
									$sql[$i] = $apiUsuario->editUsuario($cadusuario);
									$i=$i+1;
								}
							}
						}
						
						if ($this->dados['chamado']->SUBCATEGORIA == 5 && $this->dados['chamado']->AUT_SITUACAO == '0'){
							if ($this->dados['chamado']->M_CARGO != $_POST['m_cargo']){
								$Post->m_cargo = $_POST['m_cargo'];
								$des_movimento .= "<b>De Cargo RP:</b> {$this->dados['chamado']->M_DESCARGO} <b>Para Cargo RP:</b> {$this->cargo[$_POST['m_cargo']]['des_cargo']}<br><br>";
							}
							if ($this->dados['chamado']->M_DEPARTAMENTO != $_POST['m_departamento']){
								$Post->m_departamento = $_POST['m_departamento'];
								$des_movimento .= "<b>De Departamento RP:</b> {$this->dados['chamado']->M_DESDEPARTAMENTO} <b>Para Departamento RP:</b> {$this->departamento[$_POST['m_departamento']]['des_departamento']}<br><br>";
							}
							if ($this->dados['chamado']->SIGILOSO != $_POST['sigiloso']){
								$Post->sigiloso = $_POST['sigiloso'];
								$des_movimento .= "<b>De Sigiloso RP:</b> {$this->dados['chamado']->SIGILOSO} <b>Para Sigiloso RP:</b> {$_POST['sigiloso']}<br><br>";
							}
							if ($this->dados['chamado']->LOJA != $_POST['loja']){
								$Post->loja = $_POST['loja'];
								$des_movimento .= "<b>De Loja RP:</b> {$this->dados['chamado']->LOJA} <b>Para Loja RP:</b> {$_POST['loja']}<br><br>";
							}
							if ($this->dados['chamado']->N_VAGA != $_POST['n_vaga']){
								$Post->n_vaga = $_POST['n_vaga'];
								$des_movimento .= "<b>De N� Vaga RP:</b> {$this->dados['chamado']->LOJA} <b>Para N� Vaga RP:</b> {$_POST['n_vaga']}<br><br>";
							}
							if ($this->dados['chamado']->DTA_ADMISSAO != $_POST['dta_admissao']){
								$Post->dta_admissao = $_POST['dta_admissao'];
								$des_movimento .= "<b>De Admiss�o RP:</b> {$this->dados['chamado']->DTA_ADMISSAO} <b>Para Admiss�o RP:</b> {$_POST['dta_admissao']}<br><br>";
							}
							if ($this->dados['chamado']->GENERO != $_POST['genero']){
								$Post->genero = $_POST['genero'];
								$des_movimento .= "<b>De Genero RP:</b> {$this->dados['chamado']->GENERO} <b>Para Admiss�o RP:</b> {$_POST['genero']}<br><br>";
							}
							if ($this->dados['chamado']->IDADE != $_POST['idade']){
								$Post->idade = $_POST['idade'];
								$des_movimento .= "<b>De Idade RP:</b> {$this->dados['chamado']->IDADE} <b>Para Idade RP:</b> {$_POST['idade']}<br><br>";
							}
							if ($this->dados['chamado']->ESTADO_CIVIL != $_POST['estado_civil']){
								$Post->estado_civil = $_POST['estado_civil'];
								$des_movimento .= "<b>De Estado Civil RP:</b> {$this->dados['chamado']->ESTADO_CIVIL} <b>Para Estado Civil RP:</b> {$_POST['estado_civil']}<br><br>";
							}
							if ($this->dados['chamado']->PERFIL != $_POST['perfil']){
								$Post->perfil = $_POST['perfil'];
								$des_movimento .= "<b>De Perfil RP:</b> {$this->dados['chamado']->PERFIL} <b>Para Perfil RP:</b> {$_POST['perfil']}<br><br>";
							}
							$salario = $this->funcoes->sanearValor($_POST['salario']);
							if ($this->dados['chamado']->SALARIO != $salario){
								$Post->salario =  $salario;
								$des_movimento .= "<b>De Sal�rio RP:</b> {$this->dados['chamado']->SALARIO} <b>Para Sal�rio RP:</b> {$salario}<br><br>";
							}
							if (isset($_POST['comissao'])){
								$comissao = strtoupper($_POST['comissao']);
								if ($this->dados['chamado']->COMISSAO != $comissao){
									$Post->comissao = $comissao;
									$des_movimento .= "<b>De Comiss�o RP:</b> {$this->dados['chamado']->COMISSAO} <b>Para Comiss�o RP:</b> {$comissao}<br><br>";
								}
							}else{
								if ($this->dados['chamado']->COMISSAO != ""){
									$Post->comissao = "";
									$des_movimento .= "<b>De Comiss�o RP:</b> {$this->dados['chamado']->COMISSAO} <b>Para Comiss�o RP:</b> Sem Comiss�o<br><br>";
								}
							}
							if ($this->dados['chamado']->HORARIO != $_POST['horario']){
								$Post->horario = $_POST['horario'];
								$des_movimento .= "<b>De Hor�rio RP:</b> {$this->dados['chamado']->HORARIO} <b>Para Hor�rio RP:</b> {$_POST['horario']}<br><br>";
							}
							if (isset($_POST['obs'])){
								if ($this->dados['chamado']->OBS != $_POST['obs']){
									$Post->obs = $_POST['obs'];
									$des_movimento .= "<b>Inform��o:</b> alterado informa��o no corpo da rp <br><br>";
								}
							}
							if ($view_chamado->JUSTIFICATIVA == 'S'){
								$expo = explode("-", $_POST['funcionario_substituido']);
								if ($this->dados['chamado']->FUNCIONARIO_SUBSTITUIDO != $expo[0]){
									$Post->funcionario_substituido = $expo[0];
									$des_movimento .= "<b>De Funcion�rio Substituido MP:</b> {$this->dados['chamado']->NOME_SUBSTITUIDO} <b>Para Funcion�rio Substituido MP:</b> {$expo[1]}<br><br>";
								}
								if ($this->dados['chamado']->DTA_DEMISSAO != $_POST['dta_demissao']){
									$Post->dta_demissao = $_POST['dta_demissao'];
									$des_movimento .= "<b>De Demiss�o RP:</b> {$this->dados['chamado']->DTA_DEMISSAO} <b>Para Demiss�o RP:</b> {$_POST['dta_demissao']}<br><br>";
								}
							}
						}
					}
					if (($this->dados['chamado']->AMBIENTE == '3') && ($this->dados['chamado']->CAMPANHA != $_POST['campanha'])){
						$Post->campanha = strtoupper($this->funcoes->retiraAcentos(trim($_POST['campanha'])));
						$des_movimento .= "<b>De Campanha:</b> ".($this->dados['chamado']->CAMPANHA != "" ? $this->dados['chamado']->CAMPANHA : "NAO INFORMADA")." <b> Para Campanha:</b> ".$Post->campanha."<br><br>";
					}
					
					if ($this->dados['chamado']->AMBIENTE == '5'){
						if ($this->dados['chamado']->SUBCATEGORIA == '61'){
							if ($this->dados['chamado']->DTA_INICIO != $_POST['dta_inicio']){
								$Post->dta_inicio = $_POST['dta_inicio'];
								$des_movimento .= "<b>De Inicio de Viagem:</b> {$this->dados['chamado']->DTA_INICIO} <b>Para Inicio de Viagem:</b> {$_POST['dta_inicio']}<br><br>";
							}
							if ($this->dados['chamado']->DTA_FIM != $_POST['dta_fim']){
								$Post->dta_fim = $_POST['dta_fim'];
								$des_movimento .= "<b>De Fim de Viagem:</b> {$this->dados['chamado']->DTA_FIM} <b>Para Fim de Viagem:</b> {$_POST['dta_fim']}<br><br>";
							}
							if ($this->dados['chamado']->DESTINO != $_POST['destino']){
								$Post->destino = $_POST['destino'];
								$des_movimento .= "<b>De Destino:</b> {$this->dados['chamado']->DESTINO} <b>Para Destino:</b> {$_POST['destino']}<br><br>";
							}
						}
						if ($this->dados['chamado']->SUBCATEGORIA == '62'){
							if ($this->dados['chamado']->DTA_INICIO != $_POST['dta_inicio']){
								$Post->dta_inicio = $_POST['dta_inicio'];
								$des_movimento .= "<b>De Data Inicio:</b> {$this->dados['chamado']->DTA_INICIO} <b>Para Data Inicio:</b> {$_POST['dta_inicio']}<br><br>";
							}
							if ($this->dados['chamado']->DTA_FIM != $_POST['dta_fim']){
								$Post->dta_fim = $_POST['dta_fim'];
								$des_movimento .= "<b>De Data Fim:</b> {$this->dados['chamado']->DTA_FIM} <b>Para Data Fim:</b> {$_POST['dta_fim']}<br><br>";
							}
							if ($this->dados['chamado']->CC != $_POST['cc']){
								$Post->cc = $_POST['cc'];
								$des_movimento .= "<b>De CC:</b> {$cc[$this->dados['chamado']->CC]}<b>Para CC:</b> {$cc[$_POST['cc']]}<br><br>";
							}
						}
						if ($this->dados['chamado']->SUBCATEGORIA == '66'){
							if ($this->dados['chamado']->DTA_INICIO != $_POST['dta_inicio']){
								$Post->dta_inicio = $_POST['dta_inicio'];
								$des_movimento .= "<b>De Data Inicio:</b> {$this->dados['chamado']->DTA_INICIO} <b>Para Data Inicio:</b> {$_POST['dta_inicio']}<br><br>";
							}
							if ($this->dados['chamado']->DTA_FIM != $_POST['dta_fim']){
								$Post->dta_fim = $_POST['dta_fim'];
								$des_movimento .= "<b>De Data Fim:</b> {$this->dados['chamado']->DTA_FIM} <b>Para Data Fim:</b> {$_POST['dta_fim']}<br><br>";
							}
							if ($this->dados['chamado']->MOTIVO != $_POST['motivo']){
								$Post->motivo = $_POST['motivo'];
								$motan = ($this->dados['chamado']->MOTIVO == "L") ? "Loja" : "Pv";
								$motatu = ($_POST['motivo'] == "L") ? "Loja" : "Pv";
								$des_movimento .= "<b>De Motivo:</b> {$motan}<b>Para Motivo:</b> {$motatu}<br><br>";
							}
						}
					}
					
					if (($this->dados['chamado']->STATUS == 3) && ($_POST['status'] == 3)){
						if ($this->dados['chamado']->DTA_EXTERNO != $_POST['dta_externo']){
							$Post->dta_externo = $_POST['dta_externo'];
							($this->dados['chamado']->DTA_EXTERNO != "") ? $n = $this->dados['chamado']->DTA_EXTERNO : $n = "NAO INFORMADO";
							$des_movimento .= "<b>De Data Externo:</b> {$n} <b>Para Data Externo:</b> {$_POST['dta_externo']}<br><br>";
						}
						if ($this->dados['chamado']->PREVISAO_EXTERNO != $_POST['previsao_externo']){
							$Post->previsao_externo = $_POST['previsao_externo'];
							($this->dados['chamado']->PREVISAO_EXTERNO != "") ? $n = $this->dados['chamado']->PREVISAO_EXTERNO : $n = "NAO INFORMADO";
							$des_movimento .= "<b>De Previs�o Externo:</b> {$n} <b>Para Previs�o Externo:</b> {$_POST['previsao_externo']}<br><br>";
						}
						if ($this->dados['chamado']->CHAMADO_EXTERNO != $_POST['chamado_externo']){
							$Post->chamado_externo = $_POST['chamado_externo'];
							($this->dados['chamado']->CHAMADO_EXTERNO != "") ? $n = $this->dados['chamado']->CHAMADO_EXTERNO : $n = "NAO INFORMADO";
							$des_movimento .= "<b>De Chamado Externo:</b> {$n} <b>Para Chamado Externo:</b> {$_POST['chamado_externo']}<br><br>";
						}
						if($this->dados['chamado']->CHAMADO_DVI != $_POST['chamado_dvi']){
							$Post->chamado_dvi = ($_POST['chamado_dvi'] != "") ? trim($_POST['chamado_dvi']) : "";
							($this->dados['chamado']->CHAMADO_DVI != "") ? $n = $this->dados['chamado']->CHAMADO_DVI : $n = "NAO INFORMADO";
							$des_movimento .= "<b>De Chamado DVI:</b> {$n} <b>Para Chamado DVI:</b> {$Post->chamado_dvi}<br><br>";
						}
						if($this->dados['chamado']->COD_EMPRESA != $_POST['cod_empresa']){
							$Post->cod_empresa = ($_POST['cod_empresa'] != "") ? trim($_POST['cod_empresa']) : "";
							($this->dados['chamado']->COD_EMPRESA != "") ? $n = $this->dados['chamado']->COD_EMPRESA : $n = "NAO INFORMADO";
							$des_movimento .= "<b>De C�digo Empresa:</b> {$n} <b>Para C�digo Empresa:</b> {$Post->cod_empresa}<br><br>";
						}
					}
					
					if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-6"]) && ($this->dados['chamado']->STATUS != $_POST['status'])){
						$Post->status = $_POST['status'];
						$des_movimento .= "<b>De Status:</b> {$this->dados['chamado']->DES_STATUS} <b>Para Status:</b> {$this->status[$_POST['status']]['des_status']}<br><br>";
						if ($Post->status == '3'){
							if ($this->dados['chamado']->DTA_EXTERNO != $_POST['dta_externo']){
								$Post->dta_externo = $_POST['dta_externo'];
								($this->dados['chamado']->DTA_EXTERNO != "") ? $n = $this->dados['chamado']->DTA_EXTERNO : $n = "NAO INFORMADO";
								$des_movimento .= "<b>De Data Externo:</b> {$n} <b>Para Data Externo:</b> {$_POST['dta_externo']}<br><br>";
							}
							if ($this->dados['chamado']->PREVISAO_EXTERNO != $_POST['previsao_externo']){
								$Post->previsao_externo = $_POST['previsao_externo'];
								($this->dados['chamado']->PREVISAO_EXTERNO != "") ? $n = $this->dados['chamado']->PREVISAO_EXTERNO : $n = "NAO INFORMADO";
								$des_movimento .= "<b>De Previs�o Externo:</b> {$n} <b>Para Previs�o Externo:</b> {$_POST['previsao_externo']}<br><br>";
							}
							if ($this->dados['chamado']->CHAMADO_EXTERNO != $_POST['chamado_externo']){
								$Post->chamado_externo = $_POST['chamado_externo'];
								($this->dados['chamado']->CHAMADO_EXTERNO != "") ? $n = $this->dados['chamado']->CHAMADO_EXTERNO : $n = "NAO INFORMADO";
								$des_movimento .= "<b>De Chamado Externo:</b> {$n} <b>Para Chamado Externo:</b> {$_POST['chamado_externo']}<br><br>";
							}
							if($this->dados['chamado']->CHAMADO_DVI != $_POST['chamado_dvi']){
								$Post->chamado_dvi = ($_POST['chamado_dvi'] != "") ? trim($_POST['chamado_dvi']) : "";
								($this->dados['chamado']->CHAMADO_DVI != "") ? $n = $this->dados['chamado']->CHAMADO_DVI : $n = "NAO INFORMADO";
								$des_movimento .= "<b>De Chamado DVI:</b> {$n} <b>Para Chamado DVI:</b> {$Post->chamado_dvi}<br><br>";
							}
							if($this->dados['chamado']->COD_EMPRESA != $_POST['cod_empresa']){
								$Post->cod_empresa = ($_POST['cod_empresa'] != "") ? trim($_POST['cod_empresa']) : "";
								($this->dados['chamado']->COD_EMPRESA != "") ? $n = $this->dados['chamado']->COD_EMPRESA : $n = "NAO INFORMADO";
								$des_movimento .= "<b>De C�digo Empresa:</b> {$n} <b>Para C�digo Empresa:</b> {$Post->cod_empresa}<br><br>";
							}
						}
						$semana = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
						$semana = strtotime(date("m/d/Y", strtotime($semana)));
						$semana = $this->funcoes->retiraAcentos(str_replace("-feira", "", strtolower(strftime('%A',$semana))));
						if ($semana == "segunda"){
							$dia = 1;
						}elseif ($semana == "terca"){
							$dia = 2;
						}elseif ($semana == "quarta"){
							$dia = 3;
						}elseif ($semana == "quinta"){
							$dia = 4;
						}elseif ($semana == "sexta"){
							$dia = 5;
						}elseif ($semana == "sabado"){
							$dia = 6;
						}else{
							$dia = 7;
						}
						$atual = strtotime(date('Y-m-d'));
						$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
						$ult_mov = strtotime(date("Y-m-d", strtotime($ult_mov)));
						$calc_dias = $atual - $ult_mov;
						$dias_mov = round($calc_dias/(60 * 60 * 24));
						
						if ($dias_mov == 0){
							$atual = strtotime(date('Y-m-d H:i:s'));
							$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
							$ult_mov = strtotime(date("Y-m-d H:i:s", strtotime($ult_mov)));
							$duracao = $atual - $ult_mov;
							$duracao = round($duracao/60);
						}else{
							for ($i=0; $i <= $dias_mov; $i++){
								if ($i == 0){
									$fim_exp =  strtotime($this->dados['chamado']->HORA_FIM);
									$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
									$ult_mov = strtotime(date("H:i:s", strtotime($ult_mov)));
									$tempo = $fim_exp - $ult_mov;
									$duracao = round($tempo/60);
								}elseif ($i == $dias_mov){
									$ini_exp =  strtotime($this->dados['chamado']->HORA_INICIO);
									$mov =  strtotime(date('H:i:s'));
									$tempo = $mov - $ini_exp;
									$duracao = $duracao + round($tempo/60);
								}else{
									if ($dia == 6){
										$duracao = $duracao + 240;
									}elseif ($dia == 7){
										$duracao = $duracao;
										$dia = 0;
									}else{
										$duracao = $duracao + 528;
									}
								}
								$dia = $dia + 1;
							}
						}
						if ($this->dados['chamado']->SITUACAO == 'EA'){
							$Post->tempo_atendimento = ($this->dados['chamado']->TEMPO_ATENDIMENTO + $duracao);
						}elseif ($this->dados['chamado']->SITUACAO == 'AU'){
							$Post->tempo_aguardando = ($this->dados['chamado']->TEMPO_AGUARDANDO + $duracao);
						}else{
							$Post->tempo_outros = ($this->dados['chamado']->TEMPO_OUTROS + $duracao);
						}
						$Post->dta_ult_movimento = date("d/m/Y H:i:s");
					}
					$autorizacao = new Autorizacao();
					if ($_POST['submeter'] == "autorizar"){
						$autorizacao->chamado = $Post->chamado;
						$autorizacao->ambiente = $Post->ambiente;
						$autorizacao->situacao = $this->dados['chamado']->AUT_SITUACAO;
						if ($autorizacao->situacao == 0){
							$Post->status = 5;
							$des_movimento .= "<b>De Status:</b> {$this->dados['chamado']->DES_STATUS} <b>Para Status:</b> {$this->status[5]['des_status']}<br><br>";
							$semana = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
							$semana = strtotime(date("m/d/Y", strtotime($semana)));
							$semana = $this->funcoes->retiraAcentos(str_replace("-feira", "", strtolower(strftime('%A',$semana))));
							if ($semana == "segunda"){
								$dia = 1;
							}elseif ($semana == "terca"){
								$dia = 2;
							}elseif ($semana == "quarta"){
								$dia = 3;
							}elseif ($semana == "quinta"){
								$dia = 4;
							}elseif ($semana == "sexta"){
								$dia = 5;
							}elseif ($semana == "sabado"){
								$dia = 6;
							}else{
								$dia = 7;
							}
							$atual = strtotime(date('Y-m-d'));
							$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
							$ult_mov = strtotime(date("Y-m-d", strtotime($ult_mov)));
							$calc_dias = $atual - $ult_mov;
							$dias_mov = round($calc_dias/(60 * 60 * 24));
							
							if ($dias_mov == 0){
								$atual = strtotime(date('Y-m-d H:i:s'));
								$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
								$ult_mov = strtotime(date("Y-m-d H:i:s", strtotime($ult_mov)));
								$duracao = $atual - $ult_mov;
								$duracao = round($duracao/60);
							}else{
								for ($i=0; $i <= $dias_mov; $i++){
									if ($i == 0){
										$fim_exp =  strtotime($this->dados['chamado']->HORA_FIM);
										$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
										$ult_mov = strtotime(date("H:i:s", strtotime($ult_mov)));
										$tempo = $fim_exp - $ult_mov;
										$duracao = round($tempo/60);
									}elseif ($i == $dias_mov){
										$ini_exp =  strtotime($this->dados['chamado']->HORA_INICIO);
										$mov =  strtotime(date('H:i:s'));
										$tempo = $mov - $ini_exp;
										$duracao = $duracao + round($tempo/60);
									}else{
										if ($dia == 6){
											$duracao = $duracao + 240;
										}elseif ($dia == 7){
											$duracao = $duracao;
											$dia = 0;
										}else{
											$duracao = $duracao + 528;
										}
									}
									$dia = $dia + 1;
								}
							}
							if ($this->dados['chamado']->SITUACAO == 'EA'){
								$Post->tempo_atendimento = ($this->dados['chamado']->TEMPO_ATENDIMENTO + $duracao);
							}elseif ($this->dados['chamado']->SITUACAO == 'AU'){
								$Post->tempo_aguardando = ($this->dados['chamado']->TEMPO_AGUARDANDO + $duracao);
							}else{
								$Post->tempo_outros = ($this->dados['chamado']->TEMPO_OUTROS + $duracao);
							}
							$Post->dta_ult_movimento = date("d/m/Y H:i:s");
							$autorizacao->autorizante = $_SESSION['usuario_sessao'];
							$autorizacao->dta_acao = date("d/m/Y H:i:s");
							$autorizacao->autorizado = "S";
							$sql[$i] = $apiChamado->editAutorizacao($autorizacao);
							$i = $i + 1;
							$des_movimento .= "<b>Data Solicita��o:</b> {$this->dados['chamado']->DTA_SOLICITACAO} <br>";
							$des_movimento .= "<b>Situa��o:</b> Autoriza��o Analista <br>";
							$des_movimento .= "<b>Destinat�rio:</b> {$this->dados['chamado']->NOME_DESTINATARIO} <br>";
							$des_movimento .= "<b>Autorizante:</b> {$_SESSION['nome_sessao']} <br>";
							$des_movimento .= "<b>Data A��o:</b> {$autorizacao->dta_acao} <br>";
							$des_movimento .= "<b>Autorizado:</b> Sim <br><br>";
							$Post->aut_situacao = 1;
							$autorizacao = new Autorizacao();
							$autorizacao->chamado = $Post->chamado;
							$autorizacao->ambiente = $Post->ambiente;
							$autorizacao->situacao = 1;
							$autorizacao->dta_solicitacao = date("d/m/Y H:i:s");
							$sql[$i] = $apiChamado->editAutorizacao($autorizacao);
							$i = $i + 1;
							$des_movimento .= "<b>Data Solicita��o:</b> {$autorizacao->dta_solicitacao} <br>";
							$des_movimento .= "<b>Situa��o:</b> Pendente Gerente <br>";
							$des_movimento .= "<b>Destinat�rio:</b> {$this->autorizacao[0]->NOME_DESTINATARIO} <br><br>";
							$email_gerente = "{$this->autorizacao[0]->EMAIL_DESTINATARIO}";
						}elseif ($autorizacao->situacao == 1){
							$Post->status = 2;
							$des_movimento .= "<b>De Status:</b> {$this->dados['chamado']->DES_STATUS} <b>Para Status:</b> {$this->status[2]['des_status']}<br><br>";
							$semana = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
							$semana = strtotime(date("m/d/Y", strtotime($semana)));
							$semana = $this->funcoes->retiraAcentos(str_replace("-feira", "", strtolower(strftime('%A',$semana))));
							if ($semana == "segunda"){
								$dia = 1;
							}elseif ($semana == "terca"){
								$dia = 2;
							}elseif ($semana == "quarta"){
								$dia = 3;
							}elseif ($semana == "quinta"){
								$dia = 4;
							}elseif ($semana == "sexta"){
								$dia = 5;
							}elseif ($semana == "sabado"){
								$dia = 6;
							}else{
								$dia = 7;
							}
							$atual = strtotime(date('Y-m-d'));
							$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
							$ult_mov = strtotime(date("Y-m-d", strtotime($ult_mov)));
							$calc_dias = $atual - $ult_mov;
							$dias_mov = round($calc_dias/(60 * 60 * 24));
							
							if ($dias_mov == 0){
								$atual = strtotime(date('Y-m-d H:i:s'));
								$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
								$ult_mov = strtotime(date("Y-m-d H:i:s", strtotime($ult_mov)));
								$duracao = $atual - $ult_mov;
								$duracao = round($duracao/60);
							}else{
								for ($i=0; $i <= $dias_mov; $i++){
									if ($i == 0){
										$fim_exp =  strtotime($this->dados['chamado']->HORA_FIM);
										$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
										$ult_mov = strtotime(date("H:i:s", strtotime($ult_mov)));
										$tempo = $fim_exp - $ult_mov;
										$duracao = round($tempo/60);
									}elseif ($i == $dias_mov){
										$ini_exp =  strtotime($this->dados['chamado']->HORA_INICIO);
										$mov =  strtotime(date('H:i:s'));
										$tempo = $mov - $ini_exp;
										$duracao = $duracao + round($tempo/60);
									}else{
										if ($dia == 6){
											$duracao = $duracao + 240;
										}elseif ($dia == 7){
											$duracao = $duracao;
											$dia = 0;
										}else{
											$duracao = $duracao + 528;
										}
									}
									$dia = $dia + 1;
								}
							}
							if ($this->dados['chamado']->SITUACAO == 'EA'){
								$Post->tempo_atendimento = ($this->dados['chamado']->TEMPO_ATENDIMENTO + $duracao);
							}elseif ($this->dados['chamado']->SITUACAO == 'AU'){
								$Post->tempo_aguardando = ($this->dados['chamado']->TEMPO_AGUARDANDO + $duracao);
							}else{
								$Post->tempo_outros = ($this->dados['chamado']->TEMPO_OUTROS + $duracao);
							}
							$Post->dta_ult_movimento = date("d/m/Y H:i:s");
							$autorizacao->autorizante = $_SESSION['usuario_sessao'];
							$autorizacao->dta_acao = date("d/m/Y H:i:s");
							$autorizacao->autorizado = "S";
							$sql[$i] = $apiChamado->editAutorizacao($autorizacao);
							$i = $i + 1;
							$des_movimento .= "<b>Data Solicita��o:</b> {$this->dados['chamado']->DTA_SOLICITACAO} <br>";
							$des_movimento .= "<b>Situa��o:</b> Autoriza��o Gerente <br>";
							$des_movimento .= "<b>Destinat�rio:</b> {$this->dados['chamado']->NOME_DESTINATARIO} <br>";
							$des_movimento .= "<b>Autorizante:</b> {$_SESSION['nome_sessao']} <br>";
							$des_movimento .= "<b>Data A��o:</b> {$autorizacao->dta_acao} <br>";
							$des_movimento .= "<b>Autorizado:</b> Sim <br><br>";
							$Post->aut_situacao = 2;
							$autorizacao = new Autorizacao();
							$autorizacao->chamado = $Post->chamado;
							$autorizacao->ambiente = $Post->ambiente;
							$autorizacao->situacao = 2;
							$gestores = $apiTecempsubcategoria->gestoresAmbiente("1",$_SESSION['empresa_sessao'], $Post->ambiente);
							$autorizacao->destinatario = $gestores[0]->GERENTE_DHO;
							$autorizacao->dta_solicitacao = date("d/m/Y H:i:s");
							$sql[$i] = $apiChamado->addAutorizacao($autorizacao);
							$i = $i + 1;
							$des_movimento .= "<b>Data Solicita��o:</b> {$autorizacao->dta_solicitacao} <br>";
							$des_movimento .= "<b>Situa��o:</b> Pendente Gerente DHO <br>";
							$des_movimento .= "<b>Destinat�rio:</b> {$gestores[0]->NOME_GERENTEDHO} <br><br>";
						}elseif ($autorizacao->situacao == 2){
							$Post->status = 5;
							$des_movimento .= "<b>De Status:</b> {$this->dados['chamado']->DES_STATUS} <b>Para Status:</b> {$this->status[5]['des_status']}<br><br>";
							$semana = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
							$semana = strtotime(date("m/d/Y", strtotime($semana)));
							$semana = $this->funcoes->retiraAcentos(str_replace("-feira", "", strtolower(strftime('%A',$semana))));
							if ($semana == "segunda"){
								$dia = 1;
							}elseif ($semana == "terca"){
								$dia = 2;
							}elseif ($semana == "quarta"){
								$dia = 3;
							}elseif ($semana == "quinta"){
								$dia = 4;
							}elseif ($semana == "sexta"){
								$dia = 5;
							}elseif ($semana == "sabado"){
								$dia = 6;
							}else{
								$dia = 7;
							}
							$atual = strtotime(date('Y-m-d'));
							$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
							$ult_mov = strtotime(date("Y-m-d", strtotime($ult_mov)));
							$calc_dias = $atual - $ult_mov;
							$dias_mov = round($calc_dias/(60 * 60 * 24));
							
							if ($dias_mov == 0){
								$atual = strtotime(date('Y-m-d H:i:s'));
								$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
								$ult_mov = strtotime(date("Y-m-d H:i:s", strtotime($ult_mov)));
								$duracao = $atual - $ult_mov;
								$duracao = round($duracao/60);
							}else{
								for ($i=0; $i <= $dias_mov; $i++){
									if ($i == 0){
										$fim_exp =  strtotime($this->dados['chamado']->HORA_FIM);
										$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
										$ult_mov = strtotime(date("H:i:s", strtotime($ult_mov)));
										$tempo = $fim_exp - $ult_mov;
										$duracao = round($tempo/60);
									}elseif ($i == $dias_mov){
										$ini_exp =  strtotime($this->dados['chamado']->HORA_INICIO);
										$mov =  strtotime(date('H:i:s'));
										$tempo = $mov - $ini_exp;
										$duracao = $duracao + round($tempo/60);
									}else{
										if ($dia == 6){
											$duracao = $duracao + 240;
										}elseif ($dia == 7){
											$duracao = $duracao;
											$dia = 0;
										}else{
											$duracao = $duracao + 528;
										}
									}
									$dia = $dia + 1;
								}
							}
							if ($this->dados['chamado']->SITUACAO == 'EA'){
								$Post->tempo_atendimento = ($this->dados['chamado']->TEMPO_ATENDIMENTO + $duracao);
							}elseif ($this->dados['chamado']->SITUACAO == 'AU'){
								$Post->tempo_aguardando = ($this->dados['chamado']->TEMPO_AGUARDANDO + $duracao);
							}else{
								$Post->tempo_outros = ($this->dados['chamado']->TEMPO_OUTROS + $duracao);
							}
							$Post->dta_ult_movimento = date("d/m/Y H:i:s");
							$autorizacao->autorizante = $_SESSION['usuario_sessao'];
							$autorizacao->dta_acao = date("d/m/Y H:i:s");
							$autorizacao->autorizado = "S";
							$sql[$i] = $apiChamado->editAutorizacao($autorizacao);
							$i = $i + 1;
							//DESLIGAMENTO
							if ($this->dados['chamado']->SUBCATEGORIA == 60){
								$apiUsuario = new apiUsuario();
								$usr_destinario = $apiUsuario->getEmailenvolvidos($_POST['destinatario']);
								$des_movimento .= "<b>Data Solicita��o:</b> {$this->dados['chamado']->DTA_SOLICITACAO} <br>";
								$des_movimento .= "<b>Situa��o:</b> Autoriza��o Gerente<br>";
								$des_movimento .= "<b>Destinat�rio:</b> {$this->dados['chamado']->NOME_DESTINATARIO} <br>";
								$des_movimento .= "<b>Autorizante:</b> {$_SESSION['nome_sessao']} <br>";
								$des_movimento .= "<b>Data A��o:</b> {$autorizacao->dta_acao} <br>";
								$des_movimento .= "<b>Autorizado:</b> Sim <br><br>";
								$Post->aut_situacao = 3;
								$autorizacao = new Autorizacao();
								$autorizacao->chamado = $Post->chamado;
								$autorizacao->ambiente = $Post->ambiente;
								$autorizacao->situacao = 3;
								$autorizacao->destinatario = $usr_destinario[0]->USUARIO;
								$autorizacao->dta_solicitacao = date("d/m/Y H:i:s");
								$sql[$i] = $apiChamado->addAutorizacao($autorizacao);
								$i = $i + 1;
								$des_movimento .= "<b>Data Solicita��o:</b> {$autorizacao->dta_solicitacao} <br>";
								$des_movimento .= "<b>Situa��o:</b> Pendente Diretor(a)<br>";
								$des_movimento .= "<b>Destinat�rio:</b> {$usr_destinario[0]->NOME} <br><br>";
							}else if ($this->dados['chamado']->SUBCATEGORIA == 59){
								$des_movimento .= "<b>Data Solicita��o:</b> {$this->dados['chamado']->DTA_SOLICITACAO} <br>";
								$des_movimento .= "<b>Situa��o:</b> Autoriza��o Gerente DHO <br>";
								$des_movimento .= "<b>Destinat�rio:</b> {$this->dados['chamado']->NOME_DESTINATARIO} <br>";
								$des_movimento .= "<b>Autorizante:</b> {$_SESSION['nome_sessao']} <br>";
								$des_movimento .= "<b>Data A��o:</b> {$autorizacao->dta_acao} <br>";
								$des_movimento .= "<b>Autorizado:</b> Sim <br><br>";
								$Post->aut_situacao = 3;
								$autorizacao = new Autorizacao();
								$autorizacao->chamado = $Post->chamado;
								$autorizacao->ambiente = $Post->ambiente;
								$autorizacao->situacao = 3;
								$autorizacao->destinatario = $this->dados['chamado']->TECNICO;
								$autorizacao->dta_solicitacao = date("d/m/Y H:i:s");
								$sql[$i] = $apiChamado->addAutorizacao($autorizacao);
								$i = $i + 1;
								$des_movimento .= "<b>Data Solicita��o:</b> {$autorizacao->dta_solicitacao} <br>";
								$des_movimento .= "<b>Situa��o:</b> Pendente Analista DHO <br>";
								$des_movimento .= "<b>Destinat�rio:</b> {$this->dados['chamado']->NOME_TECNICO} <br><br>";
							}else if ($this->dados['chamado']->SUBCATEGORIA == 5){
								$des_movimento .= "<b>Data Solicita��o:</b> {$this->dados['chamado']->DTA_SOLICITACAO} <br>";
								$des_movimento .= "<b>Situa��o:</b> Autoriza��o Gerente DHO <br>";
								$des_movimento .= "<b>Destinat�rio:</b> {$this->dados['chamado']->NOME_DESTINATARIO} <br>";
								$des_movimento .= "<b>Autorizante:</b> {$_SESSION['nome_sessao']} <br>";
								$des_movimento .= "<b>Data A��o:</b> {$autorizacao->dta_acao} <br>";
								$des_movimento .= "<b>Autorizado:</b> Sim <br><br>";
								$Post->aut_situacao = 3;
								$autorizacao = new Autorizacao();
								$autorizacao->chamado = $Post->chamado;
								$autorizacao->ambiente = $Post->ambiente;
								$autorizacao->situacao = 3;
								$gestores = $apiTecempsubcategoria->gestoresAmbiente("1",$_SESSION['empresa_sessao'], $Post->ambiente);
								$autorizacao->destinatario = $gestores[0]->DIRETOR_DHO;
								$autorizacao->dta_solicitacao = date("d/m/Y H:i:s");
								$sql[$i] = $apiChamado->addAutorizacao($autorizacao);
								$i = $i + 1;
								$des_movimento .= "<b>Data Solicita��o:</b> {$autorizacao->dta_solicitacao} <br>";
								$des_movimento .= "<b>Situa��o:</b> Pendente Diretor(a) DHO <br>";
								$des_movimento .= "<b>Destinat�rio:</b> {$gestores[0]->NOME_DIRETORDHO} <br><br>";
							}
						}elseif ($autorizacao->situacao == 3){
							$autorizacao->autorizante = $_SESSION['usuario_sessao'];
							$autorizacao->dta_acao = date("d/m/Y H:i:s");
							$autorizacao->autorizado = "S";
							//		$autorizacao->situacao = 4;
							$sql[$i] = $apiChamado->editAutorizacao($autorizacao);
							$i = $i + 1;
							$des_movimento .= "<b>Data Solicita��o:</b> {$this->dados['chamado']->DTA_SOLICITACAO} <br>";
							if ($this->dados['chamado']->SUBCATEGORIA == 60){
								$des_movimento .= "<b>Situa��o:</b> Autoriza��o Diretor(a)<br>";
							}else{
								$des_movimento .= "<b>Situa��o:</b> Autoriza��o Analista DHO <br>";
							}
							$des_movimento .= "<b>Destinat�rio:</b> {$this->dados['chamado']->NOME_DESTINATARIO} <br>";
							$des_movimento .= "<b>Autorizante:</b> {$_SESSION['nome_sessao']} <br>";
							$des_movimento .= "<b>Data A��o:</b> {$autorizacao->dta_acao} <br>";
							$des_movimento .= "<b>Autorizado:</b> Sim <br><br>";
						/*	if ($this->dados['chamado']->AMBIENTE == '2'){
								if ($this->dados['chamado']->SUBCATEGORIA == 59){
									$cadusuario = new Usuario();
									$apiUsuario = new apiUsuario();
									$expo = explode("-", $_POST['funcionario']);
									if ($this->dados['chamado']->M_CARGO != ""){
										$cadusuario->cargo = $this->dados['chamado']->M_CARGO;
									}
									if ($this->dados['chamado']->M_DEPARTAMENTO != ""){
										$cadusuario->departamento = $this->dados['chamado']->M_DEPARTAMENTO;
									}
									if ($this->dados['chamado']->M_EMPRESA != ""){
										$cadusuario->empresa = $this->dados['chamado']->M_EMPRESA;
									}
									if (($cadusuario->cargo != "") || ($cadusuario->departamento != "") || ($cadusuario->empresa != "")){
										if ($Post->funcionario != ""){
											$cadusuario->usuario = $Post->funcionario;
											$sql[$i] = $apiUsuario->editUsuario($cadusuario);
											$i=$i+1;
										}else{
											$cadusuario->usuario = $this->dados['chamado']->FUNCIONARIO;
											$sql[$i] = $apiUsuario->editUsuario($cadusuario);
											$i=$i+1;
										}
									}
								}
							}*/
							if ($this->dados['chamado']->SUBCATEGORIA == 5){
								$Post->dta_fechamento = date("d/m/Y H:i:s");
								$des_movimento .= "<b>De Status:</b> {$this->dados['chamado']->DES_STATUS} <b>Para Status:</b> CONCLUIDO<br><br>";
								$mov_fim = "<b>Chamado Finalizado:</b><br><br>";
 								$Post->status = 7;
							}
							
							//		$Post->dta_fechamento = date("d/m/Y H:i:s");
							//		$mov_fim = "<b>Chamado Finalizado:</b><br><br>";
							$semana = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
							$semana = strtotime(date("m/d/Y", strtotime($semana)));
							$semana = $this->funcoes->retiraAcentos(str_replace("-feira", "", strtolower(strftime('%A',$semana))));
							if ($semana == "segunda"){
								$dia = 1;
							}elseif ($semana == "terca"){
								$dia = 2;
							}elseif ($semana == "quarta"){
								$dia = 3;
							}elseif ($semana == "quinta"){
								$dia = 4;
							}elseif ($semana == "sexta"){
								$dia = 5;
							}elseif ($semana == "sabado"){
								$dia = 6;
							}else{
								$dia = 7;
							}
							$atual = strtotime(date('Y-m-d'));
							$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
							$ult_mov = strtotime(date("Y-m-d", strtotime($ult_mov)));
							$calc_dias = $atual - $ult_mov;
							$dias_mov = round($calc_dias/(60 * 60 * 24));
							
							if ($dias_mov == 0){
								$atual = strtotime(date('Y-m-d H:i:s'));
								$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
								$ult_mov = strtotime(date("Y-m-d H:i:s", strtotime($ult_mov)));
								$duracao = $atual - $ult_mov;
								$duracao = round($duracao/60);
							}else{
								for ($i=0; $i <= $dias_mov; $i++){
									if ($i == 0){
										$fim_exp =  strtotime($this->dados['chamado']->HORA_FIM);
										$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
										$ult_mov = strtotime(date("H:i:s", strtotime($ult_mov)));
										$tempo = $fim_exp - $ult_mov;
										$duracao = round($tempo/60);
									}elseif ($i == $dias_mov){
										$ini_exp =  strtotime($this->dados['chamado']->HORA_INICIO);
										$mov =  strtotime(date('H:i:s'));
										$tempo = $mov - $ini_exp;
										$duracao = $duracao + round($tempo/60);
									}else{
										if ($dia == 6){
											$duracao = $duracao + 240;
										}elseif ($dia == 7){
											$duracao = $duracao;
											$dia = 0;
										}else{
											$duracao = $duracao + 528;
										}
									}
									$dia = $dia + 1;
								}
							}
							if ($this->dados['chamado']->SITUACAO == 'EA'){
								$Post->tempo_atendimento = ($this->dados['chamado']->TEMPO_ATENDIMENTO + $duracao);
							}elseif ($this->dados['chamado']->SITUACAO == 'AU'){
								$Post->tempo_aguardando = ($this->dados['chamado']->TEMPO_AGUARDANDO + $duracao);
							}else{
								$Post->tempo_outros = ($this->dados['chamado']->TEMPO_OUTROS + $duracao);
							}
							$Post->dta_ult_movimento = $Post->dta_fechamento;
							
							if ($this->dados['chamado']->SUBCATEGORIA == 60){
								$apiUsuario = new apiUsuario();
								$usr_destinario = $apiUsuario->getEmailenvolvidos($_POST['destinatario']);
								$Post->aut_situacao = 4;
								$Post->status = 5;
								$autorizacao = new Autorizacao();
								$autorizacao->chamado = $Post->chamado;
								$autorizacao->ambiente = $Post->ambiente;
								$autorizacao->situacao = 4;
								$autorizacao->destinatario = $usr_destinario[0]->USUARIO;
								$autorizacao->dta_solicitacao = date("d/m/Y H:i:s");
								$sql[$i] = $apiChamado->addAutorizacao($autorizacao);
								$i = $i + 1;
								$des_movimento .= "<b>De Status:</b> {$this->dados['chamado']->DES_STATUS} <b>Para Status:</b> {$this->status[5]['des_status']}<br><br>";
								$des_movimento .= "<b>Data Solicita��o:</b> {$autorizacao->dta_solicitacao} <br>";
								$des_movimento .= "<b>Situa��o:</b> Pendente Analista DHO(a)<br>";
								$des_movimento .= "<b>Destinat�rio:</b> {$usr_destinario[0]->NOME} <br><br>";
							}elseif($this->dados['chamado']->SUBCATEGORIA == 59){
								$apiUsuario = new apiUsuario();
								$usr_destinario = $apiUsuario->getEmailenvolvidos($_POST['destinatario']);
								$gestores = $apiTecempsubcategoria->gestoresAmbiente("1",$_SESSION['empresa_sessao'], $Post->ambiente);
								$Post->aut_situacao = 4;
								$Post->status = 5;
								$autorizacao = new Autorizacao();
								$autorizacao->chamado = $Post->chamado;
								$autorizacao->ambiente = $Post->ambiente;
								$autorizacao->situacao = 4;
								$autorizacao->destinatario = $usr_destinario[0]->USUARIO;
								$autorizacao->dta_solicitacao = date("d/m/Y H:i:s");
								$sql[$i] = $apiChamado->addAutorizacao($autorizacao);
								$i = $i + 1;
								$des_movimento .= "<b>De Status:</b> {$this->dados['chamado']->DES_STATUS} <b>Para Status:</b> {$this->status[5]['des_status']}<br><br>";
								$des_movimento .= "<b>Data Solicita��o:</b> {$autorizacao->dta_solicitacao} <br>";
								$des_movimento .= "<b>Situa��o:</b> Pendente Gestor(a) DHO <br>";
								$des_movimento .= "<b>Destinat�rio:</b> {$usr_destinario[0]->NOME} <br><br>";
							}
						}elseif ($autorizacao->situacao == 4){
							$autorizacao->autorizante = $_SESSION['usuario_sessao'];
							$autorizacao->dta_acao = date("d/m/Y H:i:s");
							$autorizacao->autorizado = "S";
							$sql[$i] = $apiChamado->editAutorizacao($autorizacao);
							$i = $i + 1;
							$des_movimento .= "<b>Data Solicita��o:</b> {$this->dados['chamado']->DTA_SOLICITACAO} <br>";
							if ($this->dados['chamado']->SUBCATEGORIA == 60){
								$des_movimento .= "<b>Situa��o:</b> Autoriza��o Analista DHO<br>";
							}else{
								$des_movimento .= "<b>Situa��o:</b> Autoriza��o Gestor(a) DHO <br>";
							}
							$des_movimento .= "<b>Destinat�rio:</b> {$this->dados['chamado']->NOME_DESTINATARIO} <br>";
							$des_movimento .= "<b>Autorizante:</b> {$_SESSION['nome_sessao']} <br>";
							$des_movimento .= "<b>Data A��o:</b> {$autorizacao->dta_acao} <br>";
							$des_movimento .= "<b>Autorizado:</b> Sim <br><br>";
							if ($this->dados['chamado']->AMBIENTE == '2'){
								if ($this->dados['chamado']->SUBCATEGORIA == 59){
									$cadusuario = new Usuario();
									$apiUsuario = new apiUsuario();
									$expo = explode("-", $_POST['funcionario']);
									if ($this->dados['chamado']->M_CARGO != ""){
										$cadusuario->cargo = $this->dados['chamado']->M_CARGO;
									}
									if ($this->dados['chamado']->M_DEPARTAMENTO != ""){
										$cadusuario->departamento = $this->dados['chamado']->M_DEPARTAMENTO;
									}
									if ($this->dados['chamado']->M_EMPRESA != ""){
										$cadusuario->empresa = $this->dados['chamado']->M_EMPRESA;
									}
									if (($cadusuario->cargo != "") || ($cadusuario->departamento != "") || ($cadusuario->empresa != "")){
										if ($Post->funcionario != ""){
											$cadusuario->usuario = $Post->funcionario;
											$sql[$i] = $apiUsuario->editUsuario($cadusuario);
											$i=$i+1;
										}else{
											$cadusuario->usuario = $this->dados['chamado']->FUNCIONARIO;
											$sql[$i] = $apiUsuario->editUsuario($cadusuario);
											$i=$i+1;
										}
									}
								}
							}
							$Post->dta_fechamento = date("d/m/Y H:i:s");
							$Post->status = 7;
							$des_movimento .= "<b>De Status:</b> {$this->dados['chamado']->DES_STATUS} <b>Para Status:</b> CONCLUIDO<br><br>";
							$mov_fim = "<b>Chamado Finalizado:</b><br><br>";
							$semana = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
							$semana = strtotime(date("m/d/Y", strtotime($semana)));
							$semana = $this->funcoes->retiraAcentos(str_replace("-feira", "", strtolower(strftime('%A',$semana))));
							if ($semana == "segunda"){
								$dia = 1;
							}elseif ($semana == "terca"){
								$dia = 2;
							}elseif ($semana == "quarta"){
								$dia = 3;
							}elseif ($semana == "quinta"){
								$dia = 4;
							}elseif ($semana == "sexta"){
								$dia = 5;
							}elseif ($semana == "sabado"){
								$dia = 6;
							}else{
								$dia = 7;
							}
							$atual = strtotime(date('Y-m-d'));
							$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
							$ult_mov = strtotime(date("Y-m-d", strtotime($ult_mov)));
							$calc_dias = $atual - $ult_mov;
							$dias_mov = round($calc_dias/(60 * 60 * 24));
							
							if ($dias_mov == 0){
								$atual = strtotime(date('Y-m-d H:i:s'));
								$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
								$ult_mov = strtotime(date("Y-m-d H:i:s", strtotime($ult_mov)));
								$duracao = $atual - $ult_mov;
								$duracao = round($duracao/60);
							}else{
								for ($i=0; $i <= $dias_mov; $i++){
									if ($i == 0){
										$fim_exp =  strtotime($this->dados['chamado']->HORA_FIM);
										$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
										$ult_mov = strtotime(date("H:i:s", strtotime($ult_mov)));
										$tempo = $fim_exp - $ult_mov;
										$duracao = round($tempo/60);
									}elseif ($i == $dias_mov){
										$ini_exp =  strtotime($this->dados['chamado']->HORA_INICIO);
										$mov =  strtotime(date('H:i:s'));
										$tempo = $mov - $ini_exp;
										$duracao = $duracao + round($tempo/60);
									}else{
										if ($dia == 6){
											$duracao = $duracao + 240;
										}elseif ($dia == 7){
											$duracao = $duracao;
											$dia = 0;
										}else{
											$duracao = $duracao + 528;
										}
									}
									$dia = $dia + 1;
								}
							}
							if ($this->dados['chamado']->SITUACAO == 'EA'){
								$Post->tempo_atendimento = ($this->dados['chamado']->TEMPO_ATENDIMENTO + $duracao);
							}elseif ($this->dados['chamado']->SITUACAO == 'AU'){
								$Post->tempo_aguardando = ($this->dados['chamado']->TEMPO_AGUARDANDO + $duracao);
							}else{
								$Post->tempo_outros = ($this->dados['chamado']->TEMPO_OUTROS + $duracao);
							}
							$Post->dta_ult_movimento = $Post->dta_fechamento;
						}
					}elseif ($_POST['submeter'] == "desautorizar"){
						$autorizacao->chamado = $Post->chamado;
						$autorizacao->ambiente = $Post->ambiente;
						$autorizacao->situacao = $this->dados['chamado']->AUT_SITUACAO;
						if ($autorizacao->situacao == 0){
							$situacao = "Autoriza��o Analista";
						}elseif ($autorizacao->situacao == 1){
							$situacao = "Autoriza��o Gerente";
						}elseif ($autorizacao->situacao == 2){
							if ($this->dados['chamado']->SUBCATEGORIA == 60){
								$situacao = "Autoriza��o Gerente";
							}else{
								$situacao = "Autoriza��o Gerente DHO";
							}
						}elseif ($autorizacao->situacao == 3){
							if ($this->dados['chamado']->SUBCATEGORIA == 60){
								$situacao = "Autoriza��o Diretor(a)";
							}else{
								$situacao = "Autoriza��o Diretor(a) DHO";
							}
						}
						$autorizacao->autorizante = $_SESSION['usuario_sessao'];
						$autorizacao->dta_acao = date("d/m/Y H:i:s");
						$autorizacao->autorizado = "N";
						$sql[$i] = $apiChamado->editAutorizacao($autorizacao);
						$i = $i + 1;
						$des_movimento .= "<b>Data Solicita��o:</b> {$this->dados['chamado']->DTA_SOLICITACAO} <br>";
						$des_movimento .= "<b>Situa��o:</b> {$situacao} <br>";
						$des_movimento .= "<b>Destinat�rio:</b> {$this->dados['chamado']->NOME_DESTINATARIO} <br>";
						$des_movimento .= "<b>Autorizante:</b> {$_SESSION['nome_sessao']} <br>";
						$des_movimento .= "<b>Data A��o:</b> {$autorizacao->dta_acao} <br>";
						$des_movimento .= "<b>Autorizado:</b> N�o <br><br>";
				
						$Post->dta_fechamento = date("d/m/Y H:i:s");
						$Post->status = 9;
						$des_movimento .= "<b>De Status:</b> {$this->dados['chamado']->DES_STATUS} <b>Para Status:</b> CANCELAMENTO<br><br>";
						$mov_fim = "<b>Chamado N�o Autorizado:</b><br><br>";
						
						$semana = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
						$semana = strtotime(date("m/d/Y", strtotime($semana)));
						$semana = $this->funcoes->retiraAcentos(str_replace("-feira", "", strtolower(strftime('%A',$semana))));
						if ($semana == "segunda"){
							$dia = 1;
						}elseif ($semana == "terca"){
							$dia = 2;
						}elseif ($semana == "quarta"){
							$dia = 3;
						}elseif ($semana == "quinta"){
							$dia = 4;
						}elseif ($semana == "sexta"){
							$dia = 5;
						}elseif ($semana == "sabado"){
							$dia = 6;
						}else{
							$dia = 7;
						}
						$atual = strtotime(date('Y-m-d'));
						$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
						$ult_mov = strtotime(date("Y-m-d", strtotime($ult_mov)));
						$calc_dias = $atual - $ult_mov;
						$dias_mov = round($calc_dias/(60 * 60 * 24));
						
						if ($dias_mov == 0){
							$atual = strtotime(date('Y-m-d H:i:s'));
							$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
							$ult_mov = strtotime(date("Y-m-d H:i:s", strtotime($ult_mov)));
							$duracao = $atual - $ult_mov;
							$duracao = round($duracao/60);
						}else{
							for ($i=0; $i <= $dias_mov; $i++){
								if ($i == 0){
									$fim_exp =  strtotime($this->dados['chamado']->HORA_FIM);
									$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
									$ult_mov = strtotime(date("H:i:s", strtotime($ult_mov)));
									$tempo = $fim_exp - $ult_mov;
									$duracao = round($tempo/60);
								}elseif ($i == $dias_mov){
									$ini_exp =  strtotime($this->dados['chamado']->HORA_INICIO);
									$mov =  strtotime(date('H:i:s'));
									$tempo = $mov - $ini_exp;
									$duracao = $duracao + round($tempo/60);
								}else{
									if ($dia == 6){
										$duracao = $duracao + 240;
									}elseif ($dia == 7){
										$duracao = $duracao;
										$dia = 0;
									}else{
										$duracao = $duracao + 528;
									}
								}
								$dia = $dia + 1;
							}
						}
						if ($this->dados['chamado']->SITUACAO == 'EA'){
							$Post->tempo_atendimento = ($this->dados['chamado']->TEMPO_ATENDIMENTO + $duracao);
						}elseif ($this->dados['chamado']->SITUACAO == 'AU'){
							$Post->tempo_aguardando = ($this->dados['chamado']->TEMPO_AGUARDANDO + $duracao);
						}else{
							$Post->tempo_outros = ($this->dados['chamado']->TEMPO_OUTROS + $duracao);
						}
						$Post->dta_ult_movimento = $Post->dta_fechamento;
					}
					if (($des_movimento != "") || ($_POST['des_movimento'] != "")){
						if (($apiChamado->editChamado($Post)) != ""){
							$sql[$i] = $apiChamado->editChamado($Post);
							$i = $i+1;
						}
						$movimento = new Movimento();
						$movimento->chamado = $this->chamado;
						$movimento->ambiente = $this->ambiente;
						$movimento->des_movimento = ($_POST["des_movimento"] != "" ? $mov_fim.str_replace("\r\n","<br>",$_POST["des_movimento"])."<br><br>":"{$mov_fim}").$des_movimento;
						$movimento->usuario = $_SESSION['usuario_sessao'];
						$movimento->dta_movimento = date("d/m/Y H:i:s");
						if (isset($_FILES['anexo']['name'][0])) {
							$ex = explode(".", $_FILES['anexo']['name'][0]);
							$exp = end($ex);
							$movimento->anexo1 = "{$_SESSION['empresa_sessao']}-{$_SESSION['usuario_sessao']}-{$this->chamado}-{$this->ambiente}-Anexo1".date('dmY-His').".{$exp}";
						}
						if (isset($_FILES['anexo']['name'][1])) {
							$ex = explode(".", $_FILES['anexo']['name'][1]);
							$exp = end($ex);
							$movimento->anexo2 = "{$_SESSION['empresa_sessao']}-{$_SESSION['usuario_sessao']}-{$this->chamado}-{$this->ambiente}-Anexo2".date('dmY-His').".{$exp}";
						}
						if (isset($_FILES['anexo']['name'][2])) {
							$ex = explode(".", $_FILES['anexo']['name'][2]);
							$exp = end($ex);
							$movimento->anexo3 = "{$_SESSION['empresa_sessao']}-{$_SESSION['usuario_sessao']}-{$this->chamado}-{$this->ambiente}-Anexo3".date('dmY-His').".{$exp}";
						}
						$sql[$i] = $apiChamado->addMovimento($movimento);
						$rs = $apiChamado->executeSQL($sql);
						if (@$rs[4] == 'sucesso') {
							if (isset($_FILES['anexo']['tmp_name'][0])) {
								move_uploaded_file($_FILES['anexo']['tmp_name'][0], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/chamado/".$movimento->anexo1);
							}
							if (isset($_FILES['anexo']['tmp_name'][1])) {
								move_uploaded_file($_FILES['anexo']['tmp_name'][1], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/chamado/".$movimento->anexo2);
							}
							if (isset($_FILES['anexo']['tmp_name'][2])) {
								move_uploaded_file($_FILES['anexo']['tmp_name'][2], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/chamado/".$movimento->anexo3);
							}
							$env = "O chamado: {$this->chamado} foi movimentado";
						}
					}elseif (isset($_FILES['anexo']['name'][0]) || isset($_FILES['anexo']['name'][1]) || isset($_FILES['anexo']['name'][2])){
						$movimento = new Movimento();
						$movimento->chamado = $this->chamado;
						$movimento->ambiente = $this->ambiente;
						$movimento->des_movimento = "Arquivo anexado no chamado<br><br>";
						$movimento->usuario = $_SESSION['usuario_sessao'];
						$movimento->dta_movimento = date("d/m/Y H:i:s");
						if (isset($_FILES['anexo']['name'][0])) {
							$ex = explode(".", $_FILES['anexo']['name'][0]);
							$exp = end($ex);
							$movimento->anexo1 = "{$_SESSION['empresa_sessao']}-{$_SESSION['usuario_sessao']}-{$this->chamado}-{$this->ambiente}-Anexo1".date('dmY-His').".{$exp}";
						}
						if (isset($_FILES['anexo']['name'][1])) {
							$ex = explode(".", $_FILES['anexo']['name'][1]);
							$exp = end($ex);
							$movimento->anexo2 = "{$_SESSION['empresa_sessao']}-{$_SESSION['usuario_sessao']}-{$this->chamado}-{$this->ambiente}-Anexo2".date('dmY-His').".{$exp}";
						}
						if (isset($_FILES['anexo']['name'][2])) {
							$ex = explode(".", $_FILES['anexo']['name'][2]);
							$exp = end($ex);
							$movimento->anexo3 = "{$_SESSION['empresa_sessao']}-{$_SESSION['usuario_sessao']}-{$this->chamado}-{$this->ambiente}-Anexo3".date('dmY-His').".{$exp}";
						}
						$sql[$i] = $apiChamado->addMovimento($movimento);
						$rs = $apiChamado->executeSQL($sql);
						if (@$rs[4] == 'sucesso') {
							if (isset($_FILES['anexo']['tmp_name'][0])) {
								move_uploaded_file($_FILES['anexo']['tmp_name'][0], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/chamado/".$movimento->anexo1);
							}
							if (isset($_FILES['anexo']['tmp_name'][1])) {
								move_uploaded_file($_FILES['anexo']['tmp_name'][1], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/chamado/".$movimento->anexo2);
							}
							if (isset($_FILES['anexo']['tmp_name'][2])) {
								move_uploaded_file($_FILES['anexo']['tmp_name'][2], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/chamado/".$movimento->anexo3);
							}
							$env = "O chamado: {$this->chamado} foi movimentado";
						}
					}else{
						if (isset($this->PaginaAtual)) {
							header('location:' .APP_ROOT. 'help/chamado/alterar/'.$this->chamado.','.$this->ambiente.'/'.$this->PaginaAtual.'/sucesso');
							die();
						}else {
							header('location:' .APP_ROOT. 'help/chamado/alterar/'.$this->chamado.','.$this->ambiente.'/sucesso');
							die();
						}
					}
				}
				if ($env != "") {
					$this->dados = array('chamado' => $apiChamado->getChamado($chamado));
					$exp_s = explode(" ", $this->dados['chamado']->NOME_SOLICITANTE);
					$exp_s[1] = end($exp_s);
					$exp_t = explode(" ", $this->dados['chamado']->NOME_TECNICO);
					$exp_t[1] = end($exp_t);
					
					$mov = "";
					$this->movimento = $apiChamado->getMovimento($this->chamado, $this->ambiente);
					foreach ($this->movimento as $rs){
						$mov .= "<hr /><p style='margin-bottom:10px; margin-top:2px; font-style: italic;color: #606060;'>Em {$rs->DTA_MOVIMENTO}<br>Autor: {$rs->NOME}</p>{$rs->DES_MOVIMENTO}";
					}
					$Host = "email-ssl.com.br";
					$IsHTML = true;
					$SMTPAuth = true;
					$SMTPSecure = "ssl";
					$Username = 'helpdesk@grupomonaco.com.br';
					$Password = '4dM.grup0.D0mR';
					$Port = 465;
					
					$email = new PHPMailer();
					$email->IsSMTP();
					$email->Host = $Host;
					$email->IsHTML($IsHTML);
					$email->SMTPAuth = $SMTPAuth;
					$email->SMTPSecure = $SMTPSecure;
					
					$email->Username = $Username;
					$email->Password = $Password;
					$email->Port = $Port;
					
					
					$email->From = $Username;
					$email->FromName  = "SisMonaco - HelpDesk";
					$email->Subject   = ($this->dados['chamado']->STATUS != 4) ? ($this->dados['chamado']->SUBCATEGORIA == 60) ? "[Chamado #{$this->dados['chamado']->CHAMADO}] DESLIGAMENTO: {$this->dados['chamado']->DES_EMPRESA}, FUNCION�RIO: {$this->dados['chamado']->NOME_FUNCIONARIO}" : "[Chamado #{$this->dados['chamado']->CHAMADO}] {$this->dados['chamado']->ASSUNTO}" : "[Chamado #{$this->dados['chamado']->CHAMADO}] NOVO STATUS: {$this->dados['chamado']->DES_STATUS}";
					if ($this->dados['chamado']->STATUS == 4){
						$ag = 	"<tr>
									<td colspan='2' style='padding: 9px; color: #000000; background: #ffff00;'>
										<img src='' />
										<br>
										<p align='center' style='margin-top:0px;margin-bottom:0px;font-size: 20px; font-style: italic;'>STATUS AGUARDANDO O USU�RIO SER� ENCERRADO CASO N�O SEJA RESPONDIDO EM 2 DIAS POR FALTA DE RETORNO.</p>
									</td>
								</tr>";
					}else{
						$ag = "";
					}
					
					//EMAIL DESLIGAMENTO
					
					if ($this->dados['chamado']->SUBCATEGORIA == 60){
						$desl = "<strong>Empresa:</strong> {$this->dados['chamado']->DES_EMPRESA}<br />
						<br />
						<strong>Departamento:</strong> {$this->dados['chamado']->DEPARTAMENTO_FUNCIONARIO}<br />
						<br />
						<strong>Desligado:</strong> {$this->dados['chamado']->NOME_FUNCIONARIO}<br />
						<br />
						<strong>Cargo:</strong> {$this->dados['chamado']->CARGO_FUNCIONARIO}<br />
						<br />";
					}else{
						$desl = "";
					}
					
					$mensagem = "<html>
									<head></head>
									<body style='margin:0px; padding:0px; border: 0 none; font-size: 9px; font-family: verdana, sans-serif; background-color: #efefef;'>
										<style type='text/css'>
										    td p{margin-bottom: 10px;}
										    body.ticket {margin:0px; padding:0px; border: 0 none; font-size: 9px; font-family: verdana, sans-serif; background-color: #efefef;}
										    h1.title {margin-bottom:0px;}
										    p.subtitle {color: #ccc;margin-top:0px;margin-bottom:0px;font-style: italic;}
										    table.content {width: 700px; margin: 50px auto 50px auto; border: 1px #ccc solid; background: #fff; font-size: 11px; font-family: verdana, sans-serif;}
										    td.uppercontent {border:0px;padding: 9px; color: #fff; background: #070075;}
										    tr.lowercontent {padding: 10px;}
										    td.leftcolumn {width: 400px; padding: 15px 0px 0px 18px; vertical-align: top;}
										    td.rightcolumn {width: 240px; vertical-align: top;}
										    div.rightcolumndiv{margin:15px 8px 15px;padding: 9px; border: 1px #ccc solid; font-size: 10px;}
										    p.rcmessage {margin-top:5px;}
										    a.links {color:#0000FF; text-decoration: none;}
										    hr.rcdivider {height: 1px; color: #ccc;}
										    p.tickethistory {margin-bottom:10px; margin-top:2px; font-style: italic;color: #606060;}
										    table.ticket-sum-hist {border: 1px #ccc solid; background: #eee; width: 394px; font-size: 11px; font-family: verdana, sans-serif;}
										    div.ticket-sum-histdiv {margin: 9px;}
										    h2.ticket-sum-hist-titles {margin-bottom:5px; margin-top:10px; font-size:12px;}
										    p.date {font-style: italic;margin-bottom:10px;}
										</style>
										<table style='width: 800px; margin: 50px auto 50px auto; border: 1px #ccc solid; background: #fff; font-size: 11px; font-family: verdana, sans-serif;' align='center'>
										<tbody>
											<tr>
												<td colspan='2' style='padding: 9px; color: #fff; background: #000000;'>
													<img src='' />
													<br>
													<p style='margin-top:0px;margin-bottom:0px;font-style: italic;'>Notifica��o do Help Desk.</p>
												</td>
											</tr>
											{$ag}
											<tr style='padding: 10px;'>
	        									<td style='width: 240px; vertical-align: top;'>
	          										<div style='margin:15px 8px 15px;padding: 9px; border: 1px #ccc solid; font-size: 10px;'>
		            									<strong>Chamado: </strong>{$this->dados['chamado']->CHAMADO}
		            									<hr style='height: 1px; color: #ccc;' />
		            									<strong>Data de Abertura:</strong> {$this->dados['chamado']->DTA_ABERTURA}<br />
		           										<br />
		           										<strong>Criado por:</strong> <a style='color:#0000FF; text-decoration: none;' href='mailto:{$this->dados['chamado']->EMAIL_SOLICITANTE}?subject=[Chamado #{$this->dados['chamado']->CHAMADO}] {$this->dados['chamado']->ASSUNTO}'>{$exp_s[0]} {$exp_s[1]}</a><br />
		            									<br />
		           		 								<strong>Assunto:</strong> {$this->dados['chamado']->ASSUNTO}<br />
											            <br />
														{$desl}
											            <strong>Subcategoria:</strong> {$this->dados['chamado']->DES_SUBCATEGORIA}<br  />
											            <br />
											            <strong>Status:</strong> {$this->dados['chamado']->DES_STATUS}<br  />
											            <br />
											            <strong>Vencimento:</strong> {$this->dados['chamado']->DTA_VENCIMENTO}<br  />
											            <br />
											            <strong>Telefone:</strong>".($this->dados['chamado']->TELEFONE_SOLICITANTE != "" ? $this->funcoes->mask($this->dados['chamado']->TELEFONE_SOLICITANTE,'(##)####-####'): "")."<br />
											            <br />
											            <strong>Celular:</strong>".($this->dados['chamado']->CELULAR_SOLICITANTE != "" ? $this->funcoes->mask($this->dados['chamado']->CELULAR_SOLICITANTE,'(##)#####-####'): "")."<br />
											            <br />
											            <strong>Chamado URL:</strong> <a style='color:#0000FF; text-decoration: none;' href='".APP_ROOT."help/chamado/alterar/{$this->dados['chamado']->CHAMADO},{$this->dados['chamado']->AMBIENTE}'>Chamado {$this->dados['chamado']->CHAMADO}</a><br />
											            <br />
		            									<strong>T�cnico:</strong> <a style='color:#0000FF; text-decoration: none;' href='mailto:{$this->dados['chamado']->EMAIL_TECNICO}?subject=[Chamado #{$this->dados['chamado']->CHAMADO}] {$this->dados['chamado']->ASSUNTO}'>{$exp_t[0]} {$exp_t[1]}</a><br />
		            									<br />
		            									<hr style='height: 1px; color: #ccc;' />
											            <p style='margin-top:5px;'>se voc� tiver alguma informa��o adicional referente
											            ao chamado <strong>{$this->dados['chamado']->CHAMADO}</strong> Por favor acesse o helpdesk 
											            <a style='color:#0000FF; text-decoration: none;' href='".APP_ROOT."help/chamado/'>
											            aqui</a> e movimente ou veja outros chamados.</p>
											        </div>
	        									</td>
												<td style='width: 400px; padding: 15px 0px 0px 18px; vertical-align: top;'>
	          										<p style='margin-bottom: 10px;'>{$exp_s[0]} {$exp_s[1]},</p>
	          										<p style='font-style: italic;margin-bottom:10px;'>{$env}.</p>
													<br>
													<br>
													<br />
	         										<table style='border: 1px #ccc solid; background: #eee; width: 394px; font-size: 11px; font-family: verdana, sans-serif;'>
	           		 									<tr>
	              											<td>
	                											<div style='margin: 9px;'>
																	<h2 style='margin-bottom:5px; margin-top:10px; font-size:12px;'>Chamado: {$this->dados['chamado']->CHAMADO}</h2>
																	<p style='margin-bottom: 10px;'><strong>Assunto:</strong> {$this->dados['chamado']->ASSUNTO}</p>
																	<p style='margin-bottom: 10px;'><strong>Descri��o:</strong></p>{$this->dados['chamado']->DES_CHAMADO}
																	<hr />
																	<br>
																	<br>
	                 												<h2 style='margin-bottom:5px; margin-top:10px; font-size:12px;'>Atualiza��es do Chamado & Hist�rico</h2>
					  												{$mov}			
																</div>
	              											</td>
	            										</tr>
	          										</table>
			  										<br />
	          										<br />
	        									</td>
	      									</tr>
	    								</tbody>
	 								 	</table>
									</body>
								</html>";
					$email->MsgHTML($mensagem);
					$email->AddAddress("{$this->dados['chamado']->EMAIL_SOLICITANTE}");
					if (($this->dados['chamado']->AMBIENTE == 2) && (($this->dados['chamado']->SUBCATEGORIA == 5) || ($this->dados['chamado']->SUBCATEGORIA == 59) || ($this->dados['chamado']->SUBCATEGORIA == 60))){
						if (isset($this->dados['chamado']->SIGILOSO)){
							if ($this->dados['chamado']->SIGILOSO != 'S'){
								$apiTecempsubcategoria = new apiTecempsubcategoria();
								$env = $apiTecempsubcategoria->envolvidosAmbiente("1", $this->dados['chamado']->EMPRESA, $this->dados['chamado']->AMBIENTE);
								$sub = array();
								foreach ($env as $rs){
									unset($sub);
									$sub = explode(",", $rs->SUBCATEGORIA);
									if (in_array("{$this->dados['chamado']->SUBCATEGORIA}", $sub)){
										$email->AddCC("{$rs->EMAIL}");
									}
								}
							}
						}else{
							$apiTecempsubcategoria = new apiTecempsubcategoria();
							$env = $apiTecempsubcategoria->envolvidosAmbiente("1", $this->dados['chamado']->EMPRESA, $this->dados['chamado']->AMBIENTE);
							$sub = array();
							foreach ($env as $rs){
								unset($sub);
								$sub = explode(",", $rs->SUBCATEGORIA);
								if (in_array("{$this->dados['chamado']->SUBCATEGORIA}", $sub)){
									$email->AddCC("{$rs->EMAIL}");
								}
							}
						}
					}
					if (isset($email_gerente)){
						$email->AddCC("{$email_gerente}");
					}
					$email->AddCC("{$this->dados['chamado']->EMAIL_TECNICO}");	
					$email->Send();
					$email->ClearAllRecipients();
					$email->ClearAttachments();
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'help/chamado/alterar/'.$this->chamado.','.$this->ambiente.'/'.$this->PaginaAtual.'/sucesso');
						die();
					}else {
						header('location:' .APP_ROOT. 'help/chamado/alterar/'.$this->chamado.','.$this->ambiente.'/sucesso');
						die();
					}
				}else{
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
	
		}else{
			$apiUsuario = new apiUsuario();
			$this->usuario = $apiUsuario->filtroUsuario('1', '3', 'usuario',$_SESSION['usuario_sessao']);
			if (isset($this->dados['chamado'])){
				if (($this->dados['chamado']->SOLICITANTE != $_SESSION['usuario_sessao']) && ($this->dados['chamado']->DESTINATARIO != $_SESSION['usuario_sessao'])){		
					header('location:' .APP_ROOT. 'help/index/index/acessonegado');
					die();		
				}
			}else{
				header('location:' .APP_ROOT. 'help/index/index/acessonegado');
				die();
			}
			if ($_SERVER['REQUEST_METHOD'] === 'POST') {
				$i = 0;
				$sql = array();
				$des_movimento = "";
				if ($_POST['submeter'] == "imprimir"){
					$funcoes = new Funcoes();
					$ex = explode(" ", $this->dados['chamado']->DTA_ABERTURA);
					$data_atual = $ex[0];
					//Dados da Empresa
					$razao = $this->dados['chamado']->RAZAO_SOCIAL;
					$nome = strtoupper($this->dados['chamado']->NOME_SOLICITANTE);
					if ($this->dados['chamado']->SUBCATEGORIA == 60){
						$funcionario = strtoupper($this->dados['chamado']->NOME_FUNCIONARIO);
						$dta_admissao = $this->dados['chamado']->DTA_ADMISSAO;
						$dta_demissao = $this->dados['chamado']->DTA_DEMISSAO;
						$motivo = str_replace("<br>","\r\n", $this->dados['chamado']->DES_CHAMADO);
						$pdf = new FPDF();
						$pdf->AddPage();
						$pdf->Rect(8, 10, 194, 265, 'D');
						$pdf->SetMargins(8, 8, 8);
						//Cabe�alho
						$pdf->Image(APP_ROOT."content/geral/img/monalog.png",10,11,16,14);
						$pdf->SetFont('arial','B',10);
						$pdf->Cell(172,6,"DATA",0,0,'R');
						$pdf->SetFont('arial','B',15);
						$pdf->Ln(6);
						$pdf->Cell(30,6,"",0,0,'L');
						$pdf->Cell(85,6,"MOVIMENTA��O DE PESSOAL - ",0,0,'L');
						$pdf->Cell(56,6,"N�: {$this->dados['chamado']->CHAMADO}",0,0,'L');
						$pdf->Image(APP_ROOT."content/geral/img/rhlog.jpg",150,11,16,14);
						$pdf->Line(170, 10, 170, 26);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(15,16,"{$data_atual}",0,0,'R');
						$pdf->Ln(10);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',13);
						$pdf->Cell(185,4,"Demiss�o",0,0,'C');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(2);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(4,4,"1",0,0,'L');
						$pdf->Line(12, 39, 12, 32);
						$pdf->Cell(18,4,"EMPRESA: ",0,0,'L');
						$pdf->SetFont('arial','',8);
						$pdf->Cell(150,4,"{$razao}",0,0,'L');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(2);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(23,4,"SOLICITANTE: ",0,0,'L');
						$pdf->SetFont('arial','',8);
						$pdf->Cell(194,4,"{$nome}",0,0,'L');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(2);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(5,4,"2",0,0,'L');
						$pdf->Line(12, 53, 12, 46);
						$pdf->Cell(187,4,"DADOS PESSOAIS",0,0,'C');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(48,4,"NOME COLABORADOR",0,0,'L');
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(80,12,"{$funcionario}",0,0,'C');
						$pdf->Ln(8);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(2);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(19,4,"ADMISS�O: ",0,0,'L');
						$pdf->SetFont('arial','',9);
						$pdf->Cell(56,4,"{$dta_admissao}",0,0,'L');
						$pdf->Line(100, 69, 100, 62);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(38,4,"DEMISS�O: ",0,0,'R');
						$pdf->SetFont('arial','',9);
						$pdf->Cell(16,4,"{$dta_demissao}",0,0,'R');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(5,4,"MOTIVO DETALHADO: ",0,0,'L');
						$pdf->Ln(4);
						$pdf->SetFont('arial','',10);
						$pdf->MultiCell(194,4,$motivo,0,'L',false);
						$pdf->Ln(2);
						$pdf->MultiCell(194,4,@$this->dados['chamado']->OBS,0,'L',false);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->SetXY(8, 248);
						$pdf->SetFont('arial','B',9);
						$pdf->Ln(4);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->Cell(194,4,"Assinatura para Aprova��o desta movimenta��o (Gerente Geral/Diretor):",0,1,'C');
						$pdf->Ln(1);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(11);
						$pdf->Cell(194,4,"Data:___/___/______  ____________________________________",0,0,'L');
						
						$pdf->Output("MPD-".date("d-m-Y").".pdf","D");
					}
					
					if ($this->dados['chamado']->SUBCATEGORIA == 59){
						$funcionario = strtoupper($this->dados['chamado']->NOME_FUNCIONARIO);
						$dta_admissao = $this->dados['chamado']->DTA_ADMISSAO;
						$motivo = str_replace("<br>","\r\n", $this->dados['chamado']->DES_CHAMADO);
						$pdf = new FPDF();
						$pdf->AddPage();
						$pdf->Rect(8, 10, 194, 265, 'D');
						$pdf->SetMargins(8, 8, 8);
						//Cabe�alho
						$pdf->Image(APP_ROOT."content/geral/img/monalog.png",10,11,16,14);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(172,6,"DATA",0,0,'R');
						$pdf->SetFont('arial','B',15);
						$pdf->Ln(6);
						$pdf->Cell(30,6,"",0,0,'L');
						$pdf->Cell(85,6,"MOVIMENTA��O DE PESSOAL - ",0,0,'L');
						$pdf->Cell(56,6,"N�: {$this->dados['chamado']->CHAMADO}",0,0,'L');
						$pdf->Image(APP_ROOT."content/geral/img/rhlog.jpg",150,11,16,14);
						$pdf->Line(170, 10, 170, 26);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(15,16,"{$data_atual}",0,0,'R');
						$pdf->Ln(10);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',13);
						$pdf->Cell(194,4,"Movimenta��o",0,0,'C');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(2);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(4,4,"1",0,0,'L');
						$pdf->Line(12, 39, 12, 32);
						$pdf->Cell(18,4,"EMPRESA: ",0,0,'L');
						$pdf->SetFont('arial','',8);
						$pdf->Cell(194,4,"{$razao}",0,0,'L');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(2);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(23,4,"SOLICITANTE: ",0,0,'L');
						$pdf->SetFont('arial','',8);
						$pdf->Cell(125,4,"{$nome}",0,0,'L');
						if ($this->dados['chamado']->SIGILOSO == 'S'){
							$sigiloso = 'SIM';
						}else{
							$sigiloso = 'N�O';
						}
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(36,4,"PROCESSO SIGILOSO:",0,0,'L');
						$pdf->SetFont('arial','',8);
						$pdf->Cell(70,4,"{$sigiloso}",0,0,'L');
						$pdf->Line(156, 46, 156, 39);
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(2);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(5,4,"2",0,0,'L');
						$pdf->Line(12, 53, 12, 46);
						$pdf->Cell(187,4,"DADOS PESSOAIS",0,0,'C');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(48,4,"NOME COLABORADOR",0,0,'L');
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(80,12,"{$this->dados['chamado']->CONTRATO} - {$funcionario}",0,0,'C');
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(62,3,"Data de Admiss�o:",0,0,'R');
						$pdf->SetFont('arial','',9);
						$pdf->Cell(-28,12,"{$dta_admissao}",0,0,'C');
						$pdf->Line(170, 62, 170, 53);
						$pdf->Ln(8);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(2);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(5,4,"3",0,0,'L');
						$pdf->Line(12, 69, 12, 62);
						$pdf->Cell(180,4,"ALTERA��O SOLICITADA",0,0,'C');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						if (isset($this->dados['chamado']->M_CARGO)){
							$pdf->SetFont('arial','B',9);
							$pdf->Cell(19,4,"DE CARGO: ",0,0,'L');
							$pdf->SetFont('arial','',8);
							$pdf->Cell(80,4,"{$this->dados['chamado']->AN_DESCARGO}",0,0,'L');
							$pdf->SetFont('arial','B',9);
							$pdf->Cell(11,4,"PARA: ",0,0,'L');
							$pdf->SetFont('arial','',8);
							$pdf->Cell(88,4,"{$this->dados['chamado']->M_DESCARGO}",0,0,'L');
							$pdf->Ln(5);
							$pdf->Cell(0,0,"","B",0,'C');
							$pdf->Ln(1);
						}
						if (isset($this->dados['chamado']->M_DEPARTAMENTO)){
							$pdf->SetFont('arial','B',9);
							$pdf->Cell(16,4,"DE DEPT.: ",0,0,'L');
							$pdf->SetFont('arial','',8);
							$pdf->Cell(83,4,"{$this->dados['chamado']->AN_DESDEPARTAMENTO}",0,0,'L');
							$pdf->SetFont('arial','B',9);
							$pdf->Cell(11,4,"PARA: ",0,0,'L');
							$pdf->SetFont('arial','',8);
							$pdf->Cell(88,4,"{$this->dados['chamado']->M_DESDEPARTAMENTO}",0,0,'L');
							$pdf->Ln(5);
							$pdf->Cell(0,0,"","B",0,'C');
							$pdf->Ln(1);
						}
						if (isset($this->dados['chamado']->M_SALARIO)){
							$pdf->SetFont('arial','B',9);
							$pdf->Cell(21,4,"DE SAL�RIO: ",0,0,'L');
							$pdf->SetFont('arial','',8);
							$pdf->Cell(78,4,"R$ ".number_format(str_replace(",", ".", $this->dados['chamado']->SALARIO), 2, ",", ".")."",0,0,'L');
							$pdf->SetFont('arial','B',9);
							$pdf->Cell(11,4,"PARA: ",0,0,'L');
							$pdf->SetFont('arial','',8);
							$pdf->Cell(88,4,"R$ ".number_format(str_replace(",", ".", $this->dados['chamado']->M_SALARIO), 2, ",", ".")."",0,0,'L');
							$pdf->Ln(5);
							$pdf->Cell(0,0,"","B",0,'C');
							$pdf->Ln(1);
						}
						if (isset($this->dados['chamado']->M_EMPRESA)){
							$pdf->SetFont('arial','B',9);
							$pdf->Cell(23,4,"DE EMPRESA: ",0,0,'L');
							$pdf->SetFont('arial','',8);
							$pdf->Cell(76,4,"{$this->dados['chamado']->AN_DESEMPRESA}",0,0,'L');
							$pdf->SetFont('arial','B',9);
							$pdf->Cell(11,4,"PARA: ",0,0,'L');
							$pdf->SetFont('arial','',8);
							$pdf->Cell(88,4,"{$this->dados['chamado']->M_DESEMPRESA}",0,0,'L');
							$pdf->Ln(5);
							$pdf->Cell(0,0,"","B",0,'C');
							$pdf->Ln(1);
						}
						if (isset($this->dados['chamado']->FUNCIONARIO_SUBSTITUIDO)){
							$substituido = strtoupper($funcoes->retiraAcentos(trim($this->dados['chamado']->NOME_SUBSTITUIDO)));
							$pdf->SetFont('arial','B',9);
							$pdf->Cell(65,4,"SUBSTITUI��O DO COLABORADOR: ",0,0,'L');
							$pdf->SetFont('arial','',8);
							$pdf->Cell(100,4,"{$substituido}",0,0,'L');
							$pdf->Ln(5);
							$pdf->Cell(0,0,"","B",0,'C');
							$pdf->Ln(1);
						}
						if ($this->dados['chamado']->COMISSAO != ""){
							$pdf->SetFont('arial','B',9);
							$pdf->Cell(20,4,"COMISS�O:",0,0,'L');
							$pdf->SetFont('arial','',8);
							$pdf->Cell(100,4,"{$this->dados['chamado']->COMISSAO}",0,0,'L');
							$pdf->Ln(5);
							$pdf->Cell(0,0,"","B",0,'C');
							$pdf->Ln(1);
						}
						$pdf->SetFont('arial','B',9);
						$pdf->Ln(-1);
						$pdf->Cell(4,5,"4",'R',0,'L');
						$pdf->Cell(180,5,"INFORMA��ES COMPLEMENTARES",0,0,'C');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(41,4,"MOTIVA��O PROMO��O:",0,0,'L');
						if ($this->dados['chamado']->MOTIVO == 'E'){
							$promocao = "ESPONT�NEO";
						}elseif ($this->dados['chamado']->MOTIVO == 'M'){
							$promocao = "M�RITO";
						}else{
							$promocao = "AVALIA��O DE DESEMPENHO";
						}
						$pdf->SetFont('arial','',8);
						$pdf->Cell(100,4,"{$promocao}",0,0,'L');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						if ($this->dados['chamado']->AVALIACAO == 'S'){
							$avaliacao = "SIM";
						}else{
							$avaliacao = "N�O";
						}
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(84,4,"O COLABORADOR PASSOU POR AVALIA��O NO RH: ",0,0,'L');
						$pdf->SetFont('arial','',8);
						$pdf->Cell(0,4,"{$avaliacao}",0,0,'L');
						$pdf->Ln(3);
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(1,5,"(Entrevistas e Testes)",0,0,'L');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(0);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(51,5,"TEMPO NA FUN��O ANTERIOR: ",0,0,'L');
						$tempo_funcao = $this->dados['chamado']->TEMPO_FUNCAO;
						$pdf->SetFont('arial','',8);
						$pdf->Cell(95,5,"{$tempo_funcao}",0,0,'L');
						$pdf->SetFont('arial','B',8);
						$pdf->Cell(27,5,"Data da Vig�ncia: ","L",0,'R');
						$pdf->SetFont('arial','',9);
						$pdf->Cell(16,5,"{$this->dados['chamado']->DTA_VIGENCIA}",0,0,'R');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(5,4,"MOTIVO DETALHADO: ",0,0,'L');
						$pdf->Ln(4);
						$pdf->SetFont('arial','',10);
						$pdf->MultiCell(194,4,$motivo,0,'L',false);
						$pdf->Ln(2);
						$pdf->MultiCell(194,4,@$this->dados['chamado']->OBS,0,'L',false);
						//$pdf->Cell(0,0,"","B",0,'C');
						$pdf->SetXY(8, 220);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->Cell(194,4,"Autoriza��es da Requisi��o:",0,0,'C');
						$pdf->Ln(4);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(65,4,"Autoriza��o do Analista",0,0,'L');
						$pdf->Cell(65,4,"Autoriza��o do Gestor",0,0,'L');
						$pdf->Cell(65,4,"Autoriza��o do Gerente DHO",0,1,'L');
						$pdf->SetFont('arial','',7);
						//1
						sort($this->autorizacao);
						if (isset($this->autorizacao[0]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Data Solicita��o: {$this->autorizacao[0]->DTA_SOLICITACAO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Data Solicita��o: {$this->autorizacao[1]->DTA_SOLICITACAO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[2]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Data Solicita��o: {$this->autorizacao[2]->DTA_SOLICITACAO}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//2
						if (isset($this->autorizacao[0]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Situa��o: Aprova��o do Analista",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Situa��o: Aprova��o do Gestor",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[2]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Situa��o: Aprova��o do Gerente DHO",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//3
						if (isset($this->autorizacao[0]->DESTINATARIO)){
							$pdf->Cell(65,3,"Destinat�rio: {$this->autorizacao[0]->NOME_DESTINATARIO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->DESTINATARIO)){
							$pdf->Cell(65,3,"Destinat�rio: {$this->autorizacao[1]->NOME_DESTINATARIO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[2]->DESTINATARIO)){
							$pdf->Cell(65,3,"Destinat�rio: {$this->autorizacao[2]->NOME_DESTINATARIO}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//4
						if (isset($this->autorizacao[0]->AUTORIZANTE)){
							$pdf->Cell(65,3,"Autorizante: {$this->autorizacao[0]->NOME_AUTORIZANTE}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->AUTORIZANTE)){
							$pdf->Cell(65,3,"Autorizante: {$this->autorizacao[1]->NOME_AUTORIZANTE}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[2]->AUTORIZANTE)){
							$pdf->Cell(65,3,"Autorizante: {$this->autorizacao[2]->NOME_AUTORIZANTE}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//5
						if (isset($this->autorizacao[0]->DTA_ACAO)){
							$pdf->Cell(65,3,"Data A��o: {$this->autorizacao[0]->DTA_ACAO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->DTA_ACAO)){
							$pdf->Cell(65,3,"Data A��o: {$this->autorizacao[1]->DTA_ACAO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[2]->DTA_ACAO)){
							$pdf->Cell(65,3,"Data A��o: {$this->autorizacao[2]->DTA_ACAO}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//6
						if (isset($this->autorizacao[0]->AUTORIZADO)){
							$autorizado = ($this->autorizacao[0]->AUTORIZADO == 'S') ? 'Sim' : 'N�o';
							$pdf->Cell(65,3,"Autorizado: {$autorizado}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->AUTORIZADO)){
							$autorizado = ($this->autorizacao[1]->AUTORIZADO == 'S') ? 'Sim' : 'N�o';
							$pdf->Cell(65,3,"Autorizado: {$autorizado}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[2]->AUTORIZADO)){
							$autorizado = ($this->autorizacao[2]->AUTORIZADO == 'S') ? 'Sim' : 'N�o';
							$pdf->Cell(65,3,"Autorizado: {$autorizado}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(65,4,"Autoriza��o do Analista",0,0,'L');
						$pdf->Cell(65,4,"Autoriza��o do Gestor DP",0,1,'L');
						$pdf->SetFont('arial','',7);

						//1
						if (isset($this->autorizacao[3]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Data Solicita��o: {$this->autorizacao[3]->DTA_SOLICITACAO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[4]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Data Solicita��o: {$this->autorizacao[4]->DTA_SOLICITACAO}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//2
						if (isset($this->autorizacao[3]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Situa��o: Aprova��o do Analista",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[4]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Situa��o: Aprova��o do Analista",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//3
						if (isset($this->autorizacao[3]->DESTINATARIO)){
							$pdf->Cell(65,3,"Destinat�rio: {$this->autorizacao[3]->NOME_DESTINATARIO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[4]->DESTINATARIO)){
							$pdf->Cell(65,3,"Destinat�rio: {$this->autorizacao[4]->NOME_DESTINATARIO}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//4
						if (isset($this->autorizacao[3]->AUTORIZANTE)){
							$pdf->Cell(65,3,"Autorizante: {$this->autorizacao[3]->NOME_AUTORIZANTE}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[4]->AUTORIZANTE)){
							$pdf->Cell(65,3,"Autorizante: {$this->autorizacao[4]->NOME_AUTORIZANTE}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//5
						if (isset($this->autorizacao[3]->DTA_ACAO)){
							$pdf->Cell(65,3,"Data A��o: {$this->autorizacao[3]->DTA_ACAO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[4]->DTA_ACAO)){
							$pdf->Cell(65,3,"Data A��o: {$this->autorizacao[4]->DTA_ACAO}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//6
						if (isset($this->autorizacao[3]->AUTORIZADO)){
							$autorizado = ($this->autorizacao[3]->AUTORIZADO == 'S') ? 'Sim' : 'N�o';
							$pdf->Cell(65,3,"Autorizado: {$autorizado}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[4]->AUTORIZADO)){
							$autorizado = ($this->autorizacao[4]->AUTORIZADO == 'S') ? 'Sim' : 'N�o';
							$pdf->Cell(65,3,"Autorizado: {$autorizado}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}

						$pdf->SetFont('arial','B',9);
						$pdf->Ln(4);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->Cell(194,4,"Assinatura para Aprova��o desta movimenta��o (Gerente Geral/Diretor):",0,1,'C');
						$pdf->Ln(1);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(11);
						$pdf->Cell(194,4,"Data:___/___/______  ____________________________________",0,0,'L');
						
						$pdf->Output("MPM-".date("d-m-Y").".pdf","D");
					}
					
					if ($this->dados['chamado']->SUBCATEGORIA == 5){
						$pdf = new FPDF();
						$pdf->AddPage();
						$pdf->Rect(8, 10, 194, 265, 'D');
						$pdf->SetMargins(8, 8, 8);
						//Cabe�alho
						$pdf->Image(APP_ROOT."content/geral/img/monalog.png",10,11,16,14);
						$pdf->SetFont('arial','B',15);
						$pdf->Ln(6);
						$pdf->Cell(45,6,"",0,0,'L');
						$pdf->Cell(75,6,"REQUISI��O DE PESSOAL - ",0,0,'L');
						$pdf->Cell(56,6,"N�: {$this->dados['chamado']->CHAMADO}",0,0,'L');
						$pdf->Image(APP_ROOT."content/geral/img/rhlog.jpg",182,11,16,14);
						$pdf->Ln(10);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(26,4,"REQUISITANTE:",0,0,'L');
						$pdf->SetFont('arial','',7);
						$pdf->Cell(59,4,"{$razao}",0,0,'L');
						$pdf->Line(156, 32, 156, 26);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(83,4,"TELEFONE:",0,0,'R');
						$pdf->SetFont('arial','',7);
						$pdf->Cell(17,4,"{$this->funcoes->mask($this->dados['chamado']->TELEFONE_SOLICITANTE,'(##)####-####')}",0,0,'R');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(23,4,"SOLICITANTE: ",0,0,'L');
						$pdf->SetFont('arial','',8);
						$pdf->Cell(150,4,"{$nome}",0,0,'L');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(36,4,"CARGO SOLICITANTE:",0,0,'L');
						$pdf->SetFont('arial','',7);
						$pdf->Cell(66,4,"{$this->dados['chamado']->M_DESCARGO}",0,0,'L');
						$pdf->Line(110, 38, 110, 32);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(13,4,"SETOR: ",0,0,'L');
						$pdf->SetFont('arial','',7);
						$pdf->Cell(60,4,"{$this->dados['chamado']->M_DESDEPARTAMENTO}",0,0,'L');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(37,4,"PROCESSO SIGILOSO:",0,0,'L');
						$pdf->SetFont('arial','',7);
						if ($this->dados['chamado']->SIGILOSO == 'S'){
							$sigiloso = 'SIM';
						}else{
							$sigiloso = 'N�O';
						}
						$pdf->Cell(65,4,"{$sigiloso}",0,0,'L');
						$pdf->Line(110, 44, 110, 38);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(14,4,"PONTO: ",0,0,'L');
						$pdf->SetFont('arial','',7);
						$ponto_venda = strtoupper(trim($this->dados['chamado']->LOJA));
						$pdf->Cell(60,4,"{$ponto_venda}",0,0,'L');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(23,4,"N� DE VAGAS:",0,0,'L');
						$pdf->SetFont('arial','',7);
						$n_vaga = trim($this->dados['chamado']->N_VAGA);
						$pdf->Cell(29,4,"{$n_vaga}",0,0,'L');
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(29,4,"DATA ADMISS�O:",0,0,'L');
						$pdf->SetFont('arial','',7);
						$dta_admissao = $this->dados['chamado']->DTA_ADMISSAO;
						$pdf->Cell(21,4,"$dta_admissao",0,0,'L');
						$pdf->Line(60, 50, 60, 44);
						$pdf->Line(110, 50, 110, 44);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(32,4,"DATA REQUISI��O:",0,0,'L');
						$pdf->SetFont('arial','',7);
						$pdf->Cell(60,4,"{$data_atual}",0,0,'L');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(102,4,"JUSTIFICATIVA DA REQUISI��O:",0,0,'L');
						$pdf->Cell(34,4,"PERFIL SOLICITADO:",0,1,'L');
						$pdf->SetFont('arial','',7);
						if ($this->dados['chamado']->JUSTIFICATIVA == 'A'){
							$justificativa = 'AMPLIA��O DO QUADRO';
						}else{
							$justificativa = 'SUBSTITUI��O';
						}
						$pdf->Cell(102,4,"{$justificativa}",0,0,'L');
						$pdf->SetFont('arial','',9);
						if ($this->dados['chamado']->GENERO == 'I'){
							$genero = 'INDIFERENTE';
						}elseif ($this->dados['chamado']->GENERO == 'M'){
							$genero = 'MASCULINO';
						}else{
							$genero = 'FEMININO';
						}
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(11,4,"SEXO: ",0,0,'L');
						$pdf->SetFont('arial','',7);
						$pdf->Cell(39,4,"{$genero}",0,1,'L');
						if ($this->dados['chamado']->JUSTIFICATIVA == 'S'){
							$substituido = strtoupper(trim($this->dados['chamado']->NOME_SUBSTITUIDO));
							$pdf->SetFont('arial','B',9);
							$pdf->Cell(24,4,"SUBSTITUIDO:",0,0,'L');
							$pdf->SetFont('arial','',7);
							$pdf->Cell(78,4,"{$substituido}",0,0,'L');
						}else{
							$pdf->Cell(102,4,"",0,0,'L');
						}
						if (isset($this->dados['chamado']->IDADE)){
							$pdf->SetFont('arial','B',9);
							$pdf->Cell(12,4,"IDADE: ",0,0,'L');
							$pdf->SetFont('arial','',7);
							$pdf->Cell(38,4,"{$this->dados['chamado']->IDADE}",0,1,'L');
						}else{
							$pdf->SetFont('arial','B',9);
							$pdf->Cell(12,4,"IDADE: ",0,0,'L');
							$pdf->SetFont('arial','',7);
							$pdf->Cell(38,4,"N�O INFORMADO",0,1,'L');
						}
						if ($this->dados['chamado']->JUSTIFICATIVA == 'S'){
							$dta_demissao = $this->dados['chamado']->DTA_DEMISSAO;
							$pdf->SetFont('arial','B',9);
							$pdf->Cell(37,4,"DATA DESLIGAMENTO:",0,0,'L');
							$pdf->SetFont('arial','',7);
							$pdf->Cell(65,4,"{$dta_demissao}",0,0,'L');
						}else{
							$pdf->Cell(102,4,"",0,0,'L');
						}
						if ($this->dados['chamado']->ESTADO_CIVIL == 'I'){
							$estado_civil = "INDIFERENTE";
						}elseif ($this->dados['chamado']->ESTADO_CIVIL== 'S'){
							$estado_civil = "SOLTEIRO";
						}elseif ($this->dados['chamado']->ESTADO_CIVIL== 'C'){
							$estado_civil = "CASADO";
						}elseif ($this->dados['chamado']->ESTADO_CIVIL== 'U'){
							$estado_civil = "UNI�O EST�VEL";
						}else{
							$estado_civil = "DIVORCIADO";
						}
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(24,4,"ESTADO CIVIL: ",0,0,'L');
						$pdf->SetFont('arial','',7);
						$pdf->Cell(60,4,"{$estado_civil}",0,1,'L');
						$pdf->Cell(102,4,"",0,0,'L');
						if ($this->dados['chamado']->PERFIL == 'I'){
							$perfil = "INDIFERENTE";
						}elseif ($this->dados['chamado']->PERFIL == 'J'){
							$perfil = "JUNIOR";
						}elseif ($this->dados['chamado']->PERFIL == 'P'){
							$perfil = "PLENO";
						}else{
							$perfil = "S�NIOR";
						}
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(13,4,"PERFIL: ",0,0,'L');
						$pdf->SetFont('arial','',7);
						$pdf->Cell(60,4,"{$perfil}",0,1,'L');
						$pdf->Line(110, 71, 110, 50);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(194,4,"DADOS DO CARGO:",0,0,'C');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(27,4,"REMUNERA��O:",0,0,'L');
						$pdf->SetFont('arial','',7);
						$pdf->Cell(35,4,"R$ ".number_format(str_replace(",", ".", $this->dados['chamado']->SALARIO), 2, ",", ".")."",0,0,'L');
						$pdf->Cell(40,4,"",0,0,'L');
						$pdf->Line(110, 77, 110, 71);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(17,4,"HOR�RIO:",0,0,'L');
						$pdf->SetFont('arial','',7);
						$horario = $this->dados['chamado']->HORARIO;
						$pdf->Cell(83,4,"{$horario}",0,0,'L');
						$pdf->Ln(5);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						if ($this->dados['chamado']->COMISSAO != ""){
							$pdf->SetFont('arial','B',9);
							$pdf->Cell(20,4,"COMISS�O:",0,0,'L');
							$pdf->SetFont('arial','',7);
							$pdf->Cell(100,4,"{$this->dados['chamado']->COMISSAO}",0,0,'L');
							$pdf->Ln(5);
							$pdf->Cell(0,0,"","B",0,'C');
							$pdf->Ln(1);
						}
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(5,4,"COMPET�NCIAS ADICIONAIS: ",0,0,'L');
						$pdf->Ln(4);
						$competencia = str_replace("<br>","\r\n", $this->dados['chamado']->DES_CHAMADO);
						$pdf->SetFont('arial','',10);
						$pdf->MultiCell(194,4,$competencia,0,'L',false);
						$pdf->Ln(2);
						$pdf->MultiCell(194,4,@$this->dados['chamado']->OBS,0,'L',false);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->SetXY(8, 220);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->Cell(194,4,"Autoriza��es da Requisi��o:",0,0,'C');
						$pdf->Ln(4);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->SetFont('arial','B',9);
						$pdf->Cell(65,4,"Autoriza��o do Analista",0,0,'L');
						$pdf->Cell(65,4,"Autoriza��o do Gestor",0,0,'L');
						$pdf->Cell(65,4,"Autoriza��o do Gerente DHO",0,1,'L');
						$pdf->SetFont('arial','',7);
						//1
						sort($this->autorizacao);
						if (isset($this->autorizacao[0]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Data Solicita��o: {$this->autorizacao[0]->DTA_SOLICITACAO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Data Solicita��o: {$this->autorizacao[1]->DTA_SOLICITACAO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[2]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Data Solicita��o: {$this->autorizacao[2]->DTA_SOLICITACAO}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//2
						if (isset($this->autorizacao[0]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Situa��o: Aprova��o do Analista",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Situa��o: Aprova��o do Gestor",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[2]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Situa��o: Aprova��o do Gerente DHO",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//3
						if (isset($this->autorizacao[0]->DESTINATARIO)){
							$pdf->Cell(65,3,"Destinat�rio: {$this->autorizacao[0]->NOME_DESTINATARIO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->DESTINATARIO)){
							$pdf->Cell(65,3,"Destinat�rio: {$this->autorizacao[1]->NOME_DESTINATARIO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[2]->DESTINATARIO)){
							$pdf->Cell(65,3,"Destinat�rio: {$this->autorizacao[2]->NOME_DESTINATARIO}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//4
						if (isset($this->autorizacao[0]->AUTORIZANTE)){
							$pdf->Cell(65,3,"Autorizante: {$this->autorizacao[0]->NOME_AUTORIZANTE}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->AUTORIZANTE)){
							$pdf->Cell(65,3,"Autorizante: {$this->autorizacao[1]->NOME_AUTORIZANTE}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[2]->AUTORIZANTE)){
							$pdf->Cell(65,3,"Autorizante: {$this->autorizacao[2]->NOME_AUTORIZANTE}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//5
						if (isset($this->autorizacao[0]->DTA_ACAO)){
							$pdf->Cell(65,3,"Data A��o: {$this->autorizacao[0]->DTA_ACAO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->DTA_ACAO)){
							$pdf->Cell(65,3,"Data A��o: {$this->autorizacao[1]->DTA_ACAO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[2]->DTA_ACAO)){
							$pdf->Cell(65,3,"Data A��o: {$this->autorizacao[2]->DTA_ACAO}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//6
						if (isset($this->autorizacao[0]->AUTORIZADO)){
							$autorizado = ($this->autorizacao[0]->AUTORIZADO == 'S') ? 'Sim' : 'N�o';
							$pdf->Cell(65,3,"Autorizado: {$autorizado}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->AUTORIZADO)){
							$autorizado = ($this->autorizacao[1]->AUTORIZADO == 'S') ? 'Sim' : 'N�o';
							$pdf->Cell(65,3,"Autorizado: {$autorizado}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[2]->AUTORIZADO)){
							$autorizado = ($this->autorizacao[2]->AUTORIZADO == 'S') ? 'Sim' : 'N�o';
							$pdf->Cell(65,3,"Autorizado: {$autorizado}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						$pdf->SetFont('arial','B',9);
						$pdf->Ln(4);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(1);
						$pdf->Cell(194,4,"Assinatura e Aprova��o para aumento de quadro (Gerente Geral/Diretor):",0,1,'C');
						$pdf->Ln(1);
						$pdf->Cell(0,0,"","B",0,'C');
						$pdf->Ln(11);
						$pdf->Cell(194,4,"Data:___/___/______  ____________________________________",0,0,'L');
						
						$pdf->Output("RP-".date("d-m-Y").".pdf","D");
					}
					
				}elseif ($_POST['submeter'] == "movimento" || $_POST['submeter'] == "autorizar" || $_POST['submeter'] == "desautorizar"){
					if ($this->dados['chamado']->SITUACAO == 'C'){
						if (isset($this->PaginaAtual)) {
							header('location:' .APP_ROOT. 'help/chamado/index/pagina/'.$this->PaginaAtual.'/atualizar');
							die();
						}else {
							header('location:' .APP_ROOT. 'help/chamado/index/atualizar');
							die();
						}
					}
					
					if ($this->dados['chamado']->AMBIENTE == '2'){
						if ($this->dados['chamado']->SUBCATEGORIA == 60){
							$expo = explode("-", $_POST['funcionario']);
							if ($this->dados['chamado']->FUNCIONARIO != $expo[0]){
								$Post->funcionario = $expo[0];
								$des_movimento .= "<b>De Funcion�rio MD:</b> {$this->dados['chamado']->NOME_FUNCIONARIO} <b>Para Funcion�rio MD:</b> {$expo[1]}<br><br>";
							}
							if ($this->dados['chamado']->DTA_ADMISSAO != $_POST['dta_admissao']){
								$Post->dta_admissao = $_POST['dta_admissao'];
								$des_movimento .= "<b>De Admiss�o MD:</b> {$this->dados['chamado']->DTA_ADMISSAO} <b>Para Admiss�o MD:</b> {$_POST['dta_admissao']}<br><br>";
							}
							if ($this->dados['chamado']->DTA_DEMISSAO != $_POST['dta_demissao']){
								$Post->dta_demissao = $_POST['dta_demissao'];
								$des_movimento .= "<b>De Demiss�o MD:</b> {$this->dados['chamado']->DTA_DEMISSAO} <b>Para Demiss�o MD:</b> {$_POST['dta_demissao']}<br><br>";
							}
						}
						
						if ($this->dados['chamado']->SUBCATEGORIA == 59 && $this->dados['chamado']->AUT_SITUACAO == '0'){
							$cadusuario = new Usuario();
							$apiUsuario = new apiUsuario();
							$expo = explode("-", $_POST['funcionario']);
							if ($this->dados['chamado']->FUNCIONARIO != $expo[0]){
								$Post->funcionario = $expo[0];
								$des_movimento .= "<b>De Funcion�rio MP:</b> {$this->dados['chamado']->NOME_FUNCIONARIO} <b>Para Funcion�rio MP:</b> {$expo[1]}<br><br>";
							}
							if ($this->dados['chamado']->DTA_ADMISSAO != $_POST['dta_admissao']){
								$Post->dta_admissao = $_POST['dta_admissao'];
								$des_movimento .= "<b>De Admiss�o MP:</b> {$this->dados['chamado']->DTA_ADMISSAO} <b>Para Admiss�o MP:</b> {$_POST['dta_admissao']}<br><br>";
							}
							if ($this->dados['chamado']->DTA_VIGENCIA != $_POST['dta_vigencia']){
								$Post->dta_vigencia = $_POST['dta_vigencia'];
								$des_movimento .= "<b>De Vig�ncia MP:</b> {$this->dados['chamado']->DTA_VIGENCIA} <b>Para Vig�ncia MP:</b> {$_POST['dta_vigencia']}<br><br>";
							}
							if (isset($_POST['funcionario_substituido'])){
								$expo = explode("-", $_POST['funcionario_substituido']);
								if ($this->dados['chamado']->FUNCIONARIO_SUBSTITUIDO != $expo[0]){
									$Post->funcionario_substituido = $expo[0];
									$des_movimento .= "<b>De Funcion�rio Substituido MP:</b> {$this->dados['chamado']->NOME_SUBSTITUIDO} <b>Para Funcion�rio Substituido MP:</b> {$expo[1]}<br><br>";
								}
							}
							if (isset($_POST['m_cargo'])){
								if ($this->dados['chamado']->AN_CARGO != $_POST['an_cargo']){
									$cadusuario->cargo = $_POST['an_cargo'];
									$Post->an_cargo = $_POST['an_cargo'];
									$des_movimento .= "<b>De Cargo Usu�rio:</b> {$this->dados['chamado']->AN_DESCARGO} <b>Para Cargo Usu�rio:</b> {$this->cargo[$_POST['an_cargo']]['des_cargo']}<br><br>";
								}
								if ($this->dados['chamado']->M_CARGO != $_POST['m_cargo']){
									$Post->m_cargo = $_POST['m_cargo'];
									$des_movimento .= "<b>De Cargo MP:</b> {$this->dados['chamado']->M_DESCARGO} <b>Para Cargo MP:</b> {$this->cargo[$_POST['m_cargo']]['des_cargo']}<br><br>";
								}
							}
							if (isset($_POST['m_departamento'])){
								if ($this->dados['chamado']->AN_DEPARTAMENTO != $_POST['an_departamento']){
									$cadusuario->departamento = $_POST['an_departamento'];
									$Post->an_departamento = $_POST['an_departamento'];
									$des_movimento .= "<b>De Departamento Usu�rio:</b> {$this->dados['chamado']->AN_DESDEPARTAMENTO} <b>Para Departamento Usu�rio:</b> {$this->departamento[$_POST['an_departamento']]['des_departamento']}<br><br>";
								}
								if ($this->dados['chamado']->M_DEPARTAMENTO != $_POST['m_departamento']){
									$Post->m_departamento = $_POST['m_departamento'];
									$des_movimento .= "<b>De Departamento MP:</b> {$this->dados['chamado']->M_DESDEPARTAMENTO} <b>Para Departamento MP:</b> {$this->departamento[$_POST['m_departamento']]['des_departamento']}<br><br>";
								}
							}
							$salario = $this->funcoes->sanearValor($_POST['salario']);
							if ($this->dados['chamado']->SALARIO != $salario){
								$Post->salario = $salario;
								$des_movimento .= "<b>De Sal�rio:</b> {$this->dados['chamado']->SALARIO} <b>Para Sal�rio:</b> {$salario}<br><br>";
							}
							$m_salario = $this->funcoes->sanearValor($_POST['m_salario']);
							if ($this->dados['chamado']->M_SALARIO != $m_salario){
								$Post->m_salario = $m_salario;
								$des_movimento .= "<b>De Sal�rio MP:</b> {$this->dados['chamado']->M_SALARIO} <b>Para Sal�rio MP:</b> {$m_salario}<br><br>";
							}
							if (isset($_POST['comissao'])){
								$comissao = strtoupper($_POST['comissao']);
								if ($this->dados['chamado']->COMISSAO != $comissao){
									$Post->comissao = $comissao;
									$des_movimento .= "<b>De Comiss�o MP:</b> {$this->dados['chamado']->COMISSAO} <b>Para Comiss�o MP:</b> {$comissao}<br><br>";
								}
							}else{
								if ($this->dados['chamado']->COMISSAO != ""){
									$Post->comissao = "";
									$des_movimento .= "<b>De Comiss�o MP:</b> {$this->dados['chamado']->COMISSAO} <b>Para Comiss�o MP:</b> Sem Comiss�o<br><br>";
								}
							}
							if (isset($_POST['m_empresa'])){
								if ($this->dados['chamado']->AN_EMPRESA != $_POST['an_empresa']){
									$cadusuario->empresa = $_POST['an_empresa'];
									$Post->an_empresa = $_POST['an_empresa'];
									$des_movimento .= "<b>De Empresa Usu�rio:</b> {$this->dados['chamado']->AN_DESEMPRESA} <b>Para Empresa Usu�rio:</b> {$this->empresa[$_POST['an_empresa']]['des_empresa']}<br><br>";
								}
								if ($this->dados['chamado']->M_EMPRESA != $_POST['m_empresa']){
									$Post->m_empresa = $_POST['m_empresa'];
									$des_movimento .= "<b>De Empresa MP:</b> {$this->dados['chamado']->M_DESEMPRESA} <b>Para Empresa MP:</b> {$this->empresa[$_POST['m_empresa']]['des_empresa']}<br><br>";
								}
							}
							if ($this->dados['chamado']->MOTIVO != $_POST['motivo']){
								$Post->motivo = $_POST['motivo'];
								$des_movimento .= "<b>De Motivo MP:</b> {$this->dados['chamado']->MOTIVO} <b>Para Motivo MP:</b> {$_POST['motivo']}<br><br>";
							}
							if ($this->dados['chamado']->AVALIACAO != $_POST['avaliacao']){
								$Post->avaliacao = $_POST['avaliacao'];
								$des_movimento .= "<b>De Avalia��o MP:</b> {$this->dados['chamado']->AVALIACAO} <b>Para Avalia��o MP:</b> {$_POST['avaliacao']}<br><br>";
							}
							if ($this->dados['chamado']->SIGILOSO != $_POST['sigiloso']){
								$Post->sigiloso = $_POST['sigiloso'];
								$des_movimento .= "<b>De Sigiloso MP:</b> {$this->dados['chamado']->SIGILOSO} <b>Para Sigiloso MP:</b> {$_POST['sigiloso']}<br><br>";
							}
							if (isset($_POST['obs'])){
								if ($this->dados['chamado']->OBS != $_POST['obs']){
									$Post->obs = $_POST['obs'];
									$des_movimento .= "<b>Inform��o:</b> alterado informa��o no corpo da mp <br><br>";
								}
							}
							if (($cadusuario->cargo != "") || ($cadusuario->departamento != "") || ($cadusuario->empresa != "")){
								if ($Post->funcionario != ""){
									$cadusuario->usuario = $Post->funcionario;
									$sql[$i] = $apiUsuario->editUsuario($cadusuario);
									$i=$i+1;
								}else{
									$cadusuario->usuario = $this->dados['chamado']->FUNCIONARIO;
									$sql[$i] = $apiUsuario->editUsuario($cadusuario);
									$i=$i+1;
								}
							}
						}
						if ($this->dados['chamado']->SUBCATEGORIA == 5 && $this->dados['chamado']->AUT_SITUACAO == '0'){
							if ($this->dados['chamado']->M_CARGO != $_POST['m_cargo']){
								$Post->m_cargo = $_POST['m_cargo'];
								$des_movimento .= "<b>De Cargo RP:</b> {$this->dados['chamado']->M_DESCARGO} <b>Para Cargo RP:</b> {$this->cargo[$_POST['m_cargo']]['des_cargo']}<br><br>";
							}
							if ($this->dados['chamado']->M_DEPARTAMENTO != $_POST['m_departamento']){
								$Post->m_departamento = $_POST['m_departamento'];
								$des_movimento .= "<b>De Departamento RP:</b> {$this->dados['chamado']->M_DESDEPARTAMENTO} <b>Para Departamento RP:</b> {$this->departamento[$_POST['m_departamento']]['des_departamento']}<br><br>";
							}
							if ($this->dados['chamado']->SIGILOSO != $_POST['sigiloso']){
								$Post->sigiloso = $_POST['sigiloso'];
								$des_movimento .= "<b>De Sigiloso RP:</b> {$this->dados['chamado']->SIGILOSO} <b>Para Sigiloso RP:</b> {$_POST['sigiloso']}<br><br>";
							}
							if ($this->dados['chamado']->LOJA != $_POST['loja']){
								$Post->loja = $_POST['loja'];
								$des_movimento .= "<b>De Loja RP:</b> {$this->dados['chamado']->LOJA} <b>Para Loja RP:</b> {$_POST['loja']}<br><br>";
							}
							if ($this->dados['chamado']->N_VAGA != $_POST['n_vaga']){
								$Post->n_vaga = $_POST['n_vaga'];
								$des_movimento .= "<b>De N� Vaga RP:</b> {$this->dados['chamado']->LOJA} <b>Para N� Vaga RP:</b> {$_POST['n_vaga']}<br><br>";
							}
							if ($this->dados['chamado']->DTA_ADMISSAO != $_POST['dta_admissao']){
								$Post->dta_admissao = $_POST['dta_admissao'];
								$des_movimento .= "<b>De Admiss�o RP:</b> {$this->dados['chamado']->DTA_ADMISSAO} <b>Para Admiss�o RP:</b> {$_POST['dta_admissao']}<br><br>";
							}
							if ($this->dados['chamado']->GENERO != $_POST['genero']){
								$Post->genero = $_POST['genero'];
								$des_movimento .= "<b>De Genero RP:</b> {$this->dados['chamado']->GENERO} <b>Para Admiss�o RP:</b> {$_POST['genero']}<br><br>";
							}
							if ($this->dados['chamado']->IDADE != $_POST['idade']){
								$Post->idade =  $_POST['idade'];
								$des_movimento .= "<b>De Idade RP:</b> {$this->dados['chamado']->IDADE} <b>Para Idade RP:</b> {$_POST['idade']}<br><br>";
							}
							if ($this->dados['chamado']->ESTADO_CIVIL != $_POST['estado_civil']){
								$Post->estado_civil = $_POST['estado_civil'];
								$des_movimento .= "<b>De Estado Civil RP:</b> {$this->dados['chamado']->ESTADO_CIVIL} <b>Para Estado Civil RP:</b> {$_POST['estado_civil']}<br><br>";
							}
							if ($this->dados['chamado']->PERFIL != $_POST['perfil']){
								$Post->perfil = $_POST['perfil'];
								$des_movimento .= "<b>De Perfil RP:</b> {$this->dados['chamado']->PERFIL} <b>Para Perfil RP:</b> {$_POST['perfil']}<br><br>";
							}
							$salario = $this->funcoes->sanearValor($_POST['salario']);
							if ($this->dados['chamado']->SALARIO != $salario){
								$Post->salario =  $salario;
								$des_movimento .= "<b>De Sal�rio RP:</b> {$this->dados['chamado']->SALARIO} <b>Para Sal�rio RP:</b> {$salario}<br><br>";
							}
							if (isset($_POST['comissao'])){
								$comissao = strtoupper($_POST['comissao']);
								if ($this->dados['chamado']->COMISSAO != $comissao){
									$Post->comissao = $comissao;
									$des_movimento .= "<b>De Comiss�o RP:</b> {$this->dados['chamado']->COMISSAO} <b>Para Comiss�o RP:</b> {$comissao}<br><br>";
								}
							}else{
								if ($this->dados['chamado']->COMISSAO != ""){
									$Post->comissao = "";
									$des_movimento .= "<b>De Comiss�o RP:</b> {$this->dados['chamado']->COMISSAO} <b>Para Comiss�o RP:</b> Sem Comiss�o<br><br>";
								}
							}
							if ($this->dados['chamado']->HORARIO != $_POST['horario']){
								$Post->horario = $_POST['horario'];
								$des_movimento .= "<b>De Hor�rio RP:</b> {$this->dados['chamado']->HORARIO} <b>Para Hor�rio RP:</b> {$_POST['horario']}<br><br>";
							}
							if (isset($_POST['obs'])){
								if ($this->dados['chamado']->OBS != $_POST['obs']){
									$Post->obs = $_POST['obs'];
									$des_movimento .= "<b>Inform��o:</b> alterado informa��o no corpo da rp <br><br>";
								}
							}
							if ($this->dados['chamado']->JUSTIFICATIVA == 'S'){
								$expo = explode("-", $_POST['funcionario_substituido']);
								if ($this->dados['chamado']->FUNCIONARIO_SUBSTITUIDO != $expo[0]){
									$Post->funcionario_substituido = $expo[0];
									$des_movimento .= "<b>De Funcion�rio Substituido MP:</b> {$this->dados['chamado']->NOME_SUBSTITUIDO} <b>Para Funcion�rio Substituido MP:</b> {$expo[1]}<br><br>";
								}
								if ($this->dados['chamado']->DTA_DEMISSAO != $_POST['dta_demissao']){
									$Post->dta_demissao = $_POST['dta_demissao'];
									$des_movimento .= "<b>De Demiss�o RP:</b> {$this->dados['chamado']->DTA_DEMISSAO} <b>Para Demiss�o RP:</b> {$_POST['dta_demissao']}<br><br>";
								}
							}
						}
						$autorizacao = new Autorizacao();
						if ($_POST['submeter'] == "autorizar"){
							$autorizacao->chamado = $Post->chamado;
							$autorizacao->ambiente = $Post->ambiente;
							$autorizacao->situacao = $this->dados['chamado']->AUT_SITUACAO;
							if ($autorizacao->situacao == 0){
								$Post->status = 5;
								$des_movimento .= "<b>De Status:</b> {$this->dados['chamado']->DES_STATUS} <b>Para Status:</b> {$this->status[5]['des_status']}<br><br>";
								$semana = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
								$semana = strtotime(date("m/d/Y", strtotime($semana)));
								$semana = $this->funcoes->retiraAcentos(str_replace("-feira", "", strtolower(strftime('%A',$semana))));
								if ($semana == "segunda"){
									$dia = 1;
								}elseif ($semana == "terca"){
									$dia = 2;
								}elseif ($semana == "quarta"){
									$dia = 3;
								}elseif ($semana == "quinta"){
									$dia = 4;
								}elseif ($semana == "sexta"){
									$dia = 5;
								}elseif ($semana == "sabado"){
									$dia = 6;
								}else{
									$dia = 7;
								}
								$atual = strtotime(date('Y-m-d'));
								$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
								$ult_mov = strtotime(date("Y-m-d", strtotime($ult_mov)));
								$calc_dias = $atual - $ult_mov;
								$dias_mov = round($calc_dias/(60 * 60 * 24));
								
								if ($dias_mov == 0){
									$atual = strtotime(date('Y-m-d H:i:s'));
									$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
									$ult_mov = strtotime(date("Y-m-d H:i:s", strtotime($ult_mov)));
									$duracao = $atual - $ult_mov;
									$duracao = round($duracao/60);
								}else{
									for ($i=0; $i <= $dias_mov; $i++){
										if ($i == 0){
											$fim_exp =  strtotime($this->dados['chamado']->HORA_FIM);
											$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
											$ult_mov = strtotime(date("H:i:s", strtotime($ult_mov)));
											$tempo = $fim_exp - $ult_mov;
											$duracao = round($tempo/60);
										}elseif ($i == $dias_mov){
											$ini_exp =  strtotime($this->dados['chamado']->HORA_INICIO);
											$mov =  strtotime(date('H:i:s'));
											$tempo = $mov - $ini_exp;
											$duracao = $duracao + round($tempo/60);
										}else{
											if ($dia == 6){
												$duracao = $duracao + 240;
											}elseif ($dia == 7){
												$duracao = $duracao;
												$dia = 0;
											}else{
												$duracao = $duracao + 528;
											}
										}
										$dia = $dia + 1;
									}
								}
								if ($this->dados['chamado']->SITUACAO == 'EA'){
									$Post->tempo_atendimento = ($this->dados['chamado']->TEMPO_ATENDIMENTO + $duracao);
								}elseif ($this->dados['chamado']->SITUACAO == 'AU'){
									$Post->tempo_aguardando = ($this->dados['chamado']->TEMPO_AGUARDANDO + $duracao);
								}else{
									$Post->tempo_outros = ($this->dados['chamado']->TEMPO_OUTROS + $duracao);
								}
								$Post->dta_ult_movimento = date("d/m/Y H:i:s");
								$autorizacao->autorizante = $_SESSION['usuario_sessao'];
								$autorizacao->dta_acao = date("d/m/Y H:i:s");
								$autorizacao->autorizado = "S";
								$sql[$i] = $apiChamado->editAutorizacao($autorizacao);
								$i = $i + 1;
								$des_movimento .= "<b>Data Solicita��o:</b> {$this->dados['chamado']->DTA_SOLICITACAO} <br>";
								$des_movimento .= "<b>Situa��o:</b> Autoriza��o Analista <br>";
								$des_movimento .= "<b>Destinat�rio:</b> {$this->dados['chamado']->NOME_DESTINATARIO} <br>";
								$des_movimento .= "<b>Autorizante:</b> {$_SESSION['nome_sessao']} <br>";
								$des_movimento .= "<b>Data A��o:</b> {$autorizacao->dta_acao} <br>";
								$des_movimento .= "<b>Autorizado:</b> Sim <br><br>";
								$Post->aut_situacao = 1;
								$autorizacao = new Autorizacao();
								$autorizacao->chamado = $Post->chamado;
								$autorizacao->ambiente = $Post->ambiente;
								$autorizacao->situacao = 1;
								$autorizacao->dta_solicitacao = date("d/m/Y H:i:s");
								$sql[$i] = $apiChamado->editAutorizacao($autorizacao);
								$i = $i + 1;
								$des_movimento .= "<b>Data Solicita��o:</b> {$autorizacao->dta_solicitacao} <br>";
								$des_movimento .= "<b>Situa��o:</b> Pendente Gerente <br>";
								$des_movimento .= "<b>Destinat�rio:</b> {$this->autorizacao[0]->NOME_DESTINATARIO} <br><br>";
								$email_gerente = "{$this->autorizacao[0]->EMAIL_DESTINATARIO}";
							}elseif ($autorizacao->situacao == 1){
								$Post->status = 2;
								$des_movimento .= "<b>De Status:</b> {$this->dados['chamado']->DES_STATUS} <b>Para Status:</b> {$this->status[2]['des_status']}<br><br>";
								$semana = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
								$semana = strtotime(date("m/d/Y", strtotime($semana)));
								$semana = $this->funcoes->retiraAcentos(str_replace("-feira", "", strtolower(strftime('%A',$semana))));
								if ($semana == "segunda"){
									$dia = 1;
								}elseif ($semana == "terca"){
									$dia = 2;
								}elseif ($semana == "quarta"){
									$dia = 3;
								}elseif ($semana == "quinta"){
									$dia = 4;
								}elseif ($semana == "sexta"){
									$dia = 5;
								}elseif ($semana == "sabado"){
									$dia = 6;
								}else{
									$dia = 7;
								}
								$atual = strtotime(date('Y-m-d'));
								$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
								$ult_mov = strtotime(date("Y-m-d", strtotime($ult_mov)));
								$calc_dias = $atual - $ult_mov;
								$dias_mov = round($calc_dias/(60 * 60 * 24));
								
								if ($dias_mov == 0){
									$atual = strtotime(date('Y-m-d H:i:s'));
									$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
									$ult_mov = strtotime(date("Y-m-d H:i:s", strtotime($ult_mov)));
									$duracao = $atual - $ult_mov;
									$duracao = round($duracao/60);
								}else{
									for ($i=0; $i <= $dias_mov; $i++){
										if ($i == 0){
											$fim_exp =  strtotime($this->dados['chamado']->HORA_FIM);
											$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
											$ult_mov = strtotime(date("H:i:s", strtotime($ult_mov)));
											$tempo = $fim_exp - $ult_mov;
											$duracao = round($tempo/60);
										}elseif ($i == $dias_mov){
											$ini_exp =  strtotime($this->dados['chamado']->HORA_INICIO);
											$mov =  strtotime(date('H:i:s'));
											$tempo = $mov - $ini_exp;
											$duracao = $duracao + round($tempo/60);
										}else{
											if ($dia == 6){
												$duracao = $duracao + 240;
											}elseif ($dia == 7){
												$duracao = $duracao;
												$dia = 0;
											}else{
												$duracao = $duracao + 528;
											}
										}
										$dia = $dia + 1;
									}
								}
								if ($this->dados['chamado']->SITUACAO == 'EA'){
									$Post->tempo_atendimento = ($this->dados['chamado']->TEMPO_ATENDIMENTO + $duracao);
								}elseif ($this->dados['chamado']->SITUACAO == 'AU'){
									$Post->tempo_aguardando = ($this->dados['chamado']->TEMPO_AGUARDANDO + $duracao);
								}else{
									$Post->tempo_outros = ($this->dados['chamado']->TEMPO_OUTROS + $duracao);
								}
								$Post->dta_ult_movimento = date("d/m/Y H:i:s");
								$autorizacao->autorizante = $_SESSION['usuario_sessao'];
								$autorizacao->dta_acao = date("d/m/Y H:i:s");
								$autorizacao->autorizado = "S";
								$sql[$i] = $apiChamado->editAutorizacao($autorizacao);
								$i = $i + 1;
								$des_movimento .= "<b>Data Solicita��o:</b> {$this->dados['chamado']->DTA_SOLICITACAO} <br>";
								$des_movimento .= "<b>Situa��o:</b> Autoriza��o Gerente <br>";
								$des_movimento .= "<b>Destinat�rio:</b> {$this->dados['chamado']->NOME_DESTINATARIO} <br>";
								$des_movimento .= "<b>Autorizante:</b> {$_SESSION['nome_sessao']} <br>";
								$des_movimento .= "<b>Data A��o:</b> {$autorizacao->dta_acao} <br>";
								$des_movimento .= "<b>Autorizado:</b> Sim <br><br>";
								$Post->aut_situacao = 2;
								$autorizacao = new Autorizacao();
								$autorizacao->chamado = $Post->chamado;
								$autorizacao->ambiente = $Post->ambiente;
								$autorizacao->situacao = 2;
								$gestores = $apiTecempsubcategoria->gestoresAmbiente("1",$_SESSION['empresa_sessao'], $Post->ambiente);
								$autorizacao->destinatario = $gestores[0]->GERENTE_DHO;
								$autorizacao->dta_solicitacao = date("d/m/Y H:i:s");
								$sql[$i] = $apiChamado->addAutorizacao($autorizacao);
								$i = $i + 1;
								$des_movimento .= "<b>Data Solicita��o:</b> {$autorizacao->dta_solicitacao} <br>";
								$des_movimento .= "<b>Situa��o:</b> Pendente Gerente DHO <br>";
								$des_movimento .= "<b>Destinat�rio:</b> {$gestores[0]->NOME_GERENTEDHO} <br><br>";				
							}elseif ($autorizacao->situacao == 2){
								$Post->status = 5;
								$des_movimento .= "<b>De Status:</b> {$this->dados['chamado']->DES_STATUS} <b>Para Status:</b> {$this->status[5]['des_status']}<br><br>";
								$semana = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
								$semana = strtotime(date("m/d/Y", strtotime($semana)));
								$semana = $this->funcoes->retiraAcentos(str_replace("-feira", "", strtolower(strftime('%A',$semana))));
								if ($semana == "segunda"){
									$dia = 1;
								}elseif ($semana == "terca"){
									$dia = 2;
								}elseif ($semana == "quarta"){
									$dia = 3;
								}elseif ($semana == "quinta"){
									$dia = 4;
								}elseif ($semana == "sexta"){
									$dia = 5;
								}elseif ($semana == "sabado"){
									$dia = 6;
								}else{
									$dia = 7;
								}
								$atual = strtotime(date('Y-m-d'));
								$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
								$ult_mov = strtotime(date("Y-m-d", strtotime($ult_mov)));
								$calc_dias = $atual - $ult_mov;
								$dias_mov = round($calc_dias/(60 * 60 * 24));
								
								if ($dias_mov == 0){
									$atual = strtotime(date('Y-m-d H:i:s'));
									$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
									$ult_mov = strtotime(date("Y-m-d H:i:s", strtotime($ult_mov)));
									$duracao = $atual - $ult_mov;
									$duracao = round($duracao/60);
								}else{
									for ($i=0; $i <= $dias_mov; $i++){
										if ($i == 0){
											$fim_exp =  strtotime($this->dados['chamado']->HORA_FIM);
											$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
											$ult_mov = strtotime(date("H:i:s", strtotime($ult_mov)));
											$tempo = $fim_exp - $ult_mov;
											$duracao = round($tempo/60);
										}elseif ($i == $dias_mov){
											$ini_exp =  strtotime($this->dados['chamado']->HORA_INICIO);
											$mov =  strtotime(date('H:i:s'));
											$tempo = $mov - $ini_exp;
											$duracao = $duracao + round($tempo/60);
										}else{
											if ($dia == 6){
												$duracao = $duracao + 240;
											}elseif ($dia == 7){
												$duracao = $duracao;
												$dia = 0;
											}else{
												$duracao = $duracao + 528;
											}
										}
										$dia = $dia + 1;
									}
								}
								if ($this->dados['chamado']->SITUACAO == 'EA'){
									$Post->tempo_atendimento = ($this->dados['chamado']->TEMPO_ATENDIMENTO + $duracao);
								}elseif ($this->dados['chamado']->SITUACAO == 'AU'){
									$Post->tempo_aguardando = ($this->dados['chamado']->TEMPO_AGUARDANDO + $duracao);
								}else{
									$Post->tempo_outros = ($this->dados['chamado']->TEMPO_OUTROS + $duracao);
								}
								$Post->dta_ult_movimento = date("d/m/Y H:i:s");
								$autorizacao->autorizante = $_SESSION['usuario_sessao'];
								$autorizacao->dta_acao = date("d/m/Y H:i:s");
								$autorizacao->autorizado = "S";
								$sql[$i] = $apiChamado->editAutorizacao($autorizacao);
								$i = $i + 1;
								if ($this->dados['chamado']->SUBCATEGORIA == 60){
									$apiUsuario = new apiUsuario();
									$usr_destinario = $apiUsuario->getEmailenvolvidos($_POST['destinatario']);
									$des_movimento .= "<b>Data Solicita��o:</b> {$this->dados['chamado']->DTA_SOLICITACAO} <br>";
									$des_movimento .= "<b>Situa��o:</b> Autoriza��o Gerente<br>";
									$des_movimento .= "<b>Destinat�rio:</b> {$this->dados['chamado']->NOME_DESTINATARIO} <br>";
									$des_movimento .= "<b>Autorizante:</b> {$_SESSION['nome_sessao']} <br>";
									$des_movimento .= "<b>Data A��o:</b> {$autorizacao->dta_acao} <br>";
									$des_movimento .= "<b>Autorizado:</b> Sim <br><br>";
									$Post->aut_situacao = 3;
									$autorizacao = new Autorizacao();
									$autorizacao->chamado = $Post->chamado;
									$autorizacao->ambiente = $Post->ambiente;
									$autorizacao->situacao = 3;
									$autorizacao->destinatario = $usr_destinario[0]->USUARIO;
									$autorizacao->dta_solicitacao = date("d/m/Y H:i:s");
									$sql[$i] = $apiChamado->addAutorizacao($autorizacao);
									$i = $i + 1;
									$des_movimento .= "<b>Data Solicita��o:</b> {$autorizacao->dta_solicitacao} <br>";
									$des_movimento .= "<b>Situa��o:</b> Pendente Diretor(a)<br>";
									$des_movimento .= "<b>Destinat�rio:</b> {$usr_destinario[0]->NOME} <br><br>";
								}else if ($this->dados['chamado']->SUBCATEGORIA == 59){
									$des_movimento .= "<b>Data Solicita��o:</b> {$this->dados['chamado']->DTA_SOLICITACAO} <br>";
									$des_movimento .= "<b>Situa��o:</b> Autoriza��o Gerente DHO <br>";
									$des_movimento .= "<b>Destinat�rio:</b> {$this->dados['chamado']->NOME_DESTINATARIO} <br>";
									$des_movimento .= "<b>Autorizante:</b> {$_SESSION['nome_sessao']} <br>";
									$des_movimento .= "<b>Data A��o:</b> {$autorizacao->dta_acao} <br>";
									$des_movimento .= "<b>Autorizado:</b> Sim <br><br>";
									$Post->aut_situacao = 3;
									$autorizacao = new Autorizacao();
									$autorizacao->chamado = $Post->chamado;
									$autorizacao->ambiente = $Post->ambiente;
									$autorizacao->situacao = 3;
									$autorizacao->destinatario = $this->dados['chamado']->TECNICO;
									$autorizacao->dta_solicitacao = date("d/m/Y H:i:s");
									$sql[$i] = $apiChamado->addAutorizacao($autorizacao);
									$i = $i + 1;
									$des_movimento .= "<b>Data Solicita��o:</b> {$autorizacao->dta_solicitacao} <br>";
									$des_movimento .= "<b>Situa��o:</b> Pendente Analista DHO <br>";
									$des_movimento .= "<b>Destinat�rio:</b> {$this->dados['chamado']->NOME_TECNICO} <br><br>";
								}else if ($this->dados['chamado']->SUBCATEGORIA == 5){
									$des_movimento .= "<b>Data Solicita��o:</b> {$this->dados['chamado']->DTA_SOLICITACAO} <br>";
									$des_movimento .= "<b>Situa��o:</b> Autoriza��o Gerente DHO <br>";
									$des_movimento .= "<b>Destinat�rio:</b> {$this->dados['chamado']->NOME_DESTINATARIO} <br>";
									$des_movimento .= "<b>Autorizante:</b> {$_SESSION['nome_sessao']} <br>";
									$des_movimento .= "<b>Data A��o:</b> {$autorizacao->dta_acao} <br>";
									$des_movimento .= "<b>Autorizado:</b> Sim <br><br>";
									$Post->aut_situacao = 3;
									$autorizacao = new Autorizacao();
									$autorizacao->chamado = $Post->chamado;
									$autorizacao->ambiente = $Post->ambiente;
									$autorizacao->situacao = 3;
									$gestores = $apiTecempsubcategoria->gestoresAmbiente("1",$_SESSION['empresa_sessao'], $Post->ambiente);
									$autorizacao->destinatario = $gestores[0]->DIRETOR_DHO;
									$autorizacao->dta_solicitacao = date("d/m/Y H:i:s");
									$sql[$i] = $apiChamado->addAutorizacao($autorizacao);
									$i = $i + 1;
									$des_movimento .= "<b>Data Solicita��o:</b> {$autorizacao->dta_solicitacao} <br>";
									$des_movimento .= "<b>Situa��o:</b> Pendente Diretor(a) DHO <br>";
									$des_movimento .= "<b>Destinat�rio:</b> {$gestores[0]->NOME_DIRETORDHO} <br><br>";
								}
							}elseif ($autorizacao->situacao == 3){
								$autorizacao->autorizante = $_SESSION['usuario_sessao'];
								$autorizacao->dta_acao = date("d/m/Y H:i:s");
								$autorizacao->autorizado = "S";
						//		$autorizacao->situacao = 4;
								$sql[$i] = $apiChamado->editAutorizacao($autorizacao);
								$i = $i + 1;
								$des_movimento .= "<b>Data Solicita��o:</b> {$this->dados['chamado']->DTA_SOLICITACAO} <br>";
								if ($this->dados['chamado']->SUBCATEGORIA == 60){
									$des_movimento .= "<b>Situa��o:</b> Autoriza��o Diretor(a)<br>";
								}else{
									$des_movimento .= "<b>Situa��o:</b> Autoriza��o Analista DHO <br>";
								}
								$des_movimento .= "<b>Destinat�rio:</b> {$this->dados['chamado']->NOME_DESTINATARIO} <br>";
								$des_movimento .= "<b>Autorizante:</b> {$_SESSION['nome_sessao']} <br>";
								$des_movimento .= "<b>Data A��o:</b> {$autorizacao->dta_acao} <br>";
								$des_movimento .= "<b>Autorizado:</b> Sim <br><br>";
								/*if ($this->dados['chamado']->AMBIENTE == '2'){
									if ($this->dados['chamado']->SUBCATEGORIA == 59){
										$cadusuario = new Usuario();
										$apiUsuario = new apiUsuario();
										$expo = explode("-", $_POST['funcionario']);
										if ($this->dados['chamado']->M_CARGO != ""){
											$cadusuario->cargo = $this->dados['chamado']->M_CARGO;
										}
										if ($this->dados['chamado']->M_DEPARTAMENTO != ""){
											$cadusuario->departamento = $this->dados['chamado']->M_DEPARTAMENTO;
										}
										if ($this->dados['chamado']->M_EMPRESA != ""){
											$cadusuario->empresa = $this->dados['chamado']->M_EMPRESA;
										}
										if (($cadusuario->cargo != "") || ($cadusuario->departamento != "") || ($cadusuario->empresa != "")){
											if ($Post->funcionario != ""){
												$cadusuario->usuario = $Post->funcionario;
												$sql[$i] = $apiUsuario->editUsuario($cadusuario);
												$i=$i+1;
											}else{
												$cadusuario->usuario = $this->dados['chamado']->FUNCIONARIO;
												$sql[$i] = $apiUsuario->editUsuario($cadusuario);
												$i=$i+1;
											}
										}
									}
								}*/
								if ($this->dados['chamado']->SUBCATEGORIA == 5){
									$Post->dta_fechamento = date("d/m/Y H:i:s");
									$des_movimento .= "<b>De Status:</b> {$this->dados['chamado']->DES_STATUS} <b>Para Status:</b> CONCLUIDO<br><br>";
									$mov_fim = "<b>Chamado Finalizado:</b><br><br>";
									$Post->status = 7;
								}
						//		$Post->dta_fechamento = date("d/m/Y H:i:s");
						//		$mov_fim = "<b>Chamado Finalizado:</b><br><br>";			
								$semana = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
								$semana = strtotime(date("m/d/Y", strtotime($semana)));
								$semana = $this->funcoes->retiraAcentos(str_replace("-feira", "", strtolower(strftime('%A',$semana))));
								if ($semana == "segunda"){
									$dia = 1;
								}elseif ($semana == "terca"){
									$dia = 2;
								}elseif ($semana == "quarta"){
									$dia = 3;
								}elseif ($semana == "quinta"){
									$dia = 4;
								}elseif ($semana == "sexta"){
									$dia = 5;
								}elseif ($semana == "sabado"){
									$dia = 6;
								}else{
									$dia = 7;
								}
								$atual = strtotime(date('Y-m-d'));
								$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
								$ult_mov = strtotime(date("Y-m-d", strtotime($ult_mov)));
								$calc_dias = $atual - $ult_mov;
								$dias_mov = round($calc_dias/(60 * 60 * 24));
								
								if ($dias_mov == 0){
									$atual = strtotime(date('Y-m-d H:i:s'));
									$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
									$ult_mov = strtotime(date("Y-m-d H:i:s", strtotime($ult_mov)));
									$duracao = $atual - $ult_mov;
									$duracao = round($duracao/60);
								}else{
									for ($i=0; $i <= $dias_mov; $i++){
										if ($i == 0){
											$fim_exp =  strtotime($this->dados['chamado']->HORA_FIM);
											$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
											$ult_mov = strtotime(date("H:i:s", strtotime($ult_mov)));
											$tempo = $fim_exp - $ult_mov;
											$duracao = round($tempo/60);
										}elseif ($i == $dias_mov){
											$ini_exp =  strtotime($this->dados['chamado']->HORA_INICIO);
											$mov =  strtotime(date('H:i:s'));
											$tempo = $mov - $ini_exp;
											$duracao = $duracao + round($tempo/60);
										}else{
											if ($dia == 6){
												$duracao = $duracao + 240;
											}elseif ($dia == 7){
												$duracao = $duracao;
												$dia = 0;
											}else{
												$duracao = $duracao + 528;
											}
										}
										$dia = $dia + 1;
									}
								}
								if ($this->dados['chamado']->SITUACAO == 'EA'){
									$Post->tempo_atendimento = ($this->dados['chamado']->TEMPO_ATENDIMENTO + $duracao);
								}elseif ($this->dados['chamado']->SITUACAO == 'AU'){
									$Post->tempo_aguardando = ($this->dados['chamado']->TEMPO_AGUARDANDO + $duracao);
								}else{
									$Post->tempo_outros = ($this->dados['chamado']->TEMPO_OUTROS + $duracao);
								}
								$Post->dta_ult_movimento = $Post->dta_fechamento;
								
							 if ($this->dados['chamado']->SUBCATEGORIA == 60){
								$apiUsuario = new apiUsuario();
								$usr_destinario = $apiUsuario->getEmailenvolvidos($_POST['destinatario']);
								$Post->aut_situacao = 4;
								$Post->status = 5;
								$autorizacao = new Autorizacao();
								$autorizacao->chamado = $Post->chamado;
								$autorizacao->ambiente = $Post->ambiente;
								$autorizacao->situacao = 4;
								$autorizacao->destinatario = $usr_destinario[0]->USUARIO;
								$autorizacao->dta_solicitacao = date("d/m/Y H:i:s");
								$sql[$i] = $apiChamado->addAutorizacao($autorizacao);
								$i = $i + 1;
								$des_movimento .= "<b>De Status:</b> {$this->dados['chamado']->DES_STATUS} <b>Para Status:</b> {$this->status[5]['des_status']}<br><br>";
								$des_movimento .= "<b>Data Solicita��o:</b> {$autorizacao->dta_solicitacao} <br>";
								$des_movimento .= "<b>Situa��o:</b> Pendente Analista DHO(a)<br>";
								$des_movimento .= "<b>Destinat�rio:</b> {$usr_destinario[0]->NOME} <br><br>";
							 } elseif($this->dados['chamado']->SUBCATEGORIA == 59){
							 	$apiUsuario = new apiUsuario();
							 	$usr_destinario = $apiUsuario->getEmailenvolvidos($_POST['destinatario']);
							 	$gestores = $apiTecempsubcategoria->gestoresAmbiente("1",$_SESSION['empresa_sessao'], $Post->ambiente);
							 	$Post->aut_situacao = 4;
							 	$Post->status = 5;
							 	$autorizacao = new Autorizacao();
							 	$autorizacao->chamado = $Post->chamado;
							 	$autorizacao->ambiente = $Post->ambiente;
							 	$autorizacao->situacao = 4;
							 	$autorizacao->destinatario = $usr_destinario[0]->USUARIO;
							 	$autorizacao->dta_solicitacao = date("d/m/Y H:i:s");
							 	$sql[$i] = $apiChamado->addAutorizacao($autorizacao);
							 	$i = $i + 1;
							 	$des_movimento .= "<b>De Status:</b> {$this->dados['chamado']->DES_STATUS} <b>Para Status:</b> {$this->status[5]['des_status']}<br><br>";
							 	$des_movimento .= "<b>Data Solicita��o:</b> {$autorizacao->dta_solicitacao} <br>";
							 	$des_movimento .= "<b>Situa��o:</b> Pendente Gestor(a) DHO <br>";
							 	$des_movimento .= "<b>Destinat�rio:</b> {$usr_destinario[0]->NOME} <br><br>";
							 }
						//---------------------NOVO---------------------
						}elseif ($autorizacao->situacao == 4){
							$autorizacao->autorizante = $_SESSION['usuario_sessao'];
							$autorizacao->dta_acao = date("d/m/Y H:i:s");
							$autorizacao->autorizado = "S";
							$sql[$i] = $apiChamado->editAutorizacao($autorizacao);
							$i = $i + 1;
							$des_movimento .= "<b>Data Solicita��o:</b> {$this->dados['chamado']->DTA_SOLICITACAO} <br>";
							if ($this->dados['chamado']->SUBCATEGORIA == 60){
								$des_movimento .= "<b>Situa��o:</b> Autoriza��o Analista DHO<br>";
							}else{
								$des_movimento .= "<b>Situa��o:</b> Autoriza��o Gestor(a) DHO <br>";
							}
							$des_movimento .= "<b>Destinat�rio:</b> {$this->dados['chamado']->NOME_DESTINATARIO} <br>";
							$des_movimento .= "<b>Autorizante:</b> {$_SESSION['nome_sessao']} <br>";
							$des_movimento .= "<b>Data A��o:</b> {$autorizacao->dta_acao} <br>";
							$des_movimento .= "<b>Autorizado:</b> Sim <br><br>";
							if ($this->dados['chamado']->AMBIENTE == '2'){
								if ($this->dados['chamado']->SUBCATEGORIA == 59){
									$cadusuario = new Usuario();
									$apiUsuario = new apiUsuario();
									$expo = explode("-", $_POST['funcionario']);
									if ($this->dados['chamado']->M_CARGO != ""){
										$cadusuario->cargo = $this->dados['chamado']->M_CARGO;
									}
									if ($this->dados['chamado']->M_DEPARTAMENTO != ""){
										$cadusuario->departamento = $this->dados['chamado']->M_DEPARTAMENTO;
									}
									if ($this->dados['chamado']->M_EMPRESA != ""){
										$cadusuario->empresa = $this->dados['chamado']->M_EMPRESA;
									}
									if (($cadusuario->cargo != "") || ($cadusuario->departamento != "") || ($cadusuario->empresa != "")){
										if ($Post->funcionario != ""){
											$cadusuario->usuario = $Post->funcionario;
											$sql[$i] = $apiUsuario->editUsuario($cadusuario);
											$i=$i+1;
										}else{
											$cadusuario->usuario = $this->dados['chamado']->FUNCIONARIO;
											$sql[$i] = $apiUsuario->editUsuario($cadusuario);
											$i=$i+1;
										}
									}
								}
							}
							$Post->dta_fechamento = date("d/m/Y H:i:s");
							$Post->status = 7;
							$des_movimento .= "<b>De Status:</b> {$this->dados['chamado']->DES_STATUS} <b>Para Status:</b> CONCLUIDO<br><br>";
							$mov_fim = "<b>Chamado Finalizado:</b><br><br>";
							$semana = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
							$semana = strtotime(date("m/d/Y", strtotime($semana)));
							$semana = $this->funcoes->retiraAcentos(str_replace("-feira", "", strtolower(strftime('%A',$semana))));
							if ($semana == "segunda"){
								$dia = 1;
							}elseif ($semana == "terca"){
								$dia = 2;
							}elseif ($semana == "quarta"){
								$dia = 3;
							}elseif ($semana == "quinta"){
								$dia = 4;
							}elseif ($semana == "sexta"){
								$dia = 5;
							}elseif ($semana == "sabado"){
								$dia = 6;
							}else{
								$dia = 7;
							}
							$atual = strtotime(date('Y-m-d'));
							$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
							$ult_mov = strtotime(date("Y-m-d", strtotime($ult_mov)));
							$calc_dias = $atual - $ult_mov;
							$dias_mov = round($calc_dias/(60 * 60 * 24));
							
							if ($dias_mov == 0){
								$atual = strtotime(date('Y-m-d H:i:s'));
								$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
								$ult_mov = strtotime(date("Y-m-d H:i:s", strtotime($ult_mov)));
								$duracao = $atual - $ult_mov;
								$duracao = round($duracao/60);
							}else{
								for ($i=0; $i <= $dias_mov; $i++){
									if ($i == 0){
										$fim_exp =  strtotime($this->dados['chamado']->HORA_FIM);
										$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
										$ult_mov = strtotime(date("H:i:s", strtotime($ult_mov)));
										$tempo = $fim_exp - $ult_mov;
										$duracao = round($tempo/60);
									}elseif ($i == $dias_mov){
										$ini_exp =  strtotime($this->dados['chamado']->HORA_INICIO);
										$mov =  strtotime(date('H:i:s'));
										$tempo = $mov - $ini_exp;
										$duracao = $duracao + round($tempo/60);
									}else{
										if ($dia == 6){
											$duracao = $duracao + 240;
										}elseif ($dia == 7){
											$duracao = $duracao;
											$dia = 0;
										}else{
											$duracao = $duracao + 528;
										}
									}
									$dia = $dia + 1;
								}
							}
							if ($this->dados['chamado']->SITUACAO == 'EA'){
								$Post->tempo_atendimento = ($this->dados['chamado']->TEMPO_ATENDIMENTO + $duracao);
							}elseif ($this->dados['chamado']->SITUACAO == 'AU'){
								$Post->tempo_aguardando = ($this->dados['chamado']->TEMPO_AGUARDANDO + $duracao);
							}else{
								$Post->tempo_outros = ($this->dados['chamado']->TEMPO_OUTROS + $duracao);
							}
							$Post->dta_ult_movimento = $Post->dta_fechamento;
						}
						}elseif ($_POST['submeter'] == "desautorizar"){
							$autorizacao->chamado = $Post->chamado;
							$autorizacao->ambiente = $Post->ambiente;
							$autorizacao->situacao = $this->dados['chamado']->AUT_SITUACAO;
							if ($autorizacao->situacao == 0){
								$situacao = "Autoriza��o Analista";
							}elseif ($autorizacao->situacao == 1){
								$situacao = "Autoriza��o Gerente";
							}elseif ($autorizacao->situacao == 2){
								if ($this->dados['chamado']->SUBCATEGORIA == 60){
									$situacao = "Autoriza��o Gerente";
								}else{
									$situacao = "Autoriza��o Gerente DHO";
								}
							}elseif ($autorizacao->situacao == 3){
								if ($this->dados['chamado']->SUBCATEGORIA == 60){
									$situacao = "Autoriza��o Diretor(a)";
								}else{
									$situacao = "Autoriza��o Diretor(a) DHO";
								}
							}
							$autorizacao->autorizante = $_SESSION['usuario_sessao'];
							$autorizacao->dta_acao = date("d/m/Y H:i:s");
							$autorizacao->motivo = str_replace("\r\n","<br>",$_POST["motivo"]);
							$autorizacao->autorizado = "N";
							$sql[$i] = $apiChamado->editAutorizacao($autorizacao);
							$i = $i + 1;
							$des_movimento .= "<b>Data Solicita��o:</b> {$this->dados['chamado']->DTA_SOLICITACAO} <br>";
							$des_movimento .= "<b>Situa��o:</b> {$situacao} <br>";
							$des_movimento .= "<b>Destinat�rio:</b> {$this->dados['chamado']->NOME_DESTINATARIO} <br>";
							$des_movimento .= "<b>Autorizante:</b> {$_SESSION['nome_sessao']} <br>";
							$des_movimento .= "<b>Data A��o:</b> {$autorizacao->dta_acao} <br>";
							$des_movimento .= "<b>Autorizado:</b> N�o <br>";
							$des_movimento .= "<b>Motivo:</b> {$autorizacao->motivo} <br><br>";
							
							$Post->dta_fechamento = date("d/m/Y H:i:s");
							$Post->status = 9;
							$des_movimento .= "<b>De Status:</b> {$this->dados['chamado']->DES_STATUS} <b>Para Status:</b> CANCELAMENTO<br><br>";
							$mov_fim = "<b>Chamado N�o Autorizado:</b><br><br>";
							
							$semana = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
							$semana = strtotime(date("m/d/Y", strtotime($semana)));
							$semana = $this->funcoes->retiraAcentos(str_replace("-feira", "", strtolower(strftime('%A',$semana))));
							if ($semana == "segunda"){
								$dia = 1;
							}elseif ($semana == "terca"){
								$dia = 2;
							}elseif ($semana == "quarta"){
								$dia = 3;
							}elseif ($semana == "quinta"){
								$dia = 4;
							}elseif ($semana == "sexta"){
								$dia = 5;
							}elseif ($semana == "sabado"){
								$dia = 6;
							}else{
								$dia = 7;
							}
							$atual = strtotime(date('Y-m-d'));
							$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
							$ult_mov = strtotime(date("Y-m-d", strtotime($ult_mov)));
							$calc_dias = $atual - $ult_mov;
							$dias_mov = round($calc_dias/(60 * 60 * 24));
							
							if ($dias_mov == 0){
								$atual = strtotime(date('Y-m-d H:i:s'));
								$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
								$ult_mov = strtotime(date("Y-m-d H:i:s", strtotime($ult_mov)));
								$duracao = $atual - $ult_mov;
								$duracao = round($duracao/60);
							}else{
								for ($i=0; $i <= $dias_mov; $i++){
									if ($i == 0){
										$fim_exp =  strtotime($this->dados['chamado']->HORA_FIM);
										$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
										$ult_mov = strtotime(date("H:i:s", strtotime($ult_mov)));
										$tempo = $fim_exp - $ult_mov;
										$duracao = round($tempo/60);
									}elseif ($i == $dias_mov){
										$ini_exp =  strtotime($this->dados['chamado']->HORA_INICIO);
										$mov =  strtotime(date('H:i:s'));
										$tempo = $mov - $ini_exp;
										$duracao = $duracao + round($tempo/60);
									}else{
										if ($dia == 6){
											$duracao = $duracao + 240;
										}elseif ($dia == 7){
											$duracao = $duracao;
											$dia = 0;
										}else{
											$duracao = $duracao + 528;
										}
									}
									$dia = $dia + 1;
								}
							}
							if ($this->dados['chamado']->SITUACAO == 'EA'){
								$Post->tempo_atendimento = ($this->dados['chamado']->TEMPO_ATENDIMENTO + $duracao);
							}elseif ($this->dados['chamado']->SITUACAO == 'AU'){
								$Post->tempo_aguardando = ($this->dados['chamado']->TEMPO_AGUARDANDO + $duracao);
							}else{
								$Post->tempo_outros = ($this->dados['chamado']->TEMPO_OUTROS + $duracao);
							}
							$Post->dta_ult_movimento = $Post->dta_fechamento;
						}
					}
					if ($this->dados['chamado']->AMBIENTE == '5'){
						if ($this->dados['chamado']->SUBCATEGORIA == '61'){
							if ($this->dados['chamado']->DTA_INICIO != $_POST['dta_inicio']){
								$Post->dta_inicio = $_POST['dta_inicio'];
								$des_movimento .= "<b>De Inicio de Viagem:</b> {$this->dados['chamado']->DTA_INICIO} <b>Para Inicio de Viagem:</b> {$_POST['dta_inicio']}<br><br>";
							}
							if ($this->dados['chamado']->DTA_FIM != $_POST['dta_fim']){
								$Post->dta_fim = $_POST['dta_fim'];
								$des_movimento .= "<b>De Fim de Viagem:</b> {$this->dados['chamado']->DTA_FIM} <b>Para Fim de Viagem:</b> {$_POST['dta_fim']}<br><br>";
							}
							if ($this->dados['chamado']->DESTINO != $_POST['destino']){
								$Post->destino = $_POST['destino'];
								$des_movimento .= "<b>De Destino:</b> {$this->dados['chamado']->DESTINO} <b>Para Destino:</b> {$_POST['destino']}<br><br>";
							}
						}
						if ($this->dados['chamado']->SUBCATEGORIA == '62'){
							if ($this->dados['chamado']->DTA_INICIO != $_POST['dta_inicio']){
								$Post->dta_inicio = $_POST['dta_inicio'];
								$des_movimento .= "<b>De Data Inicio:</b> {$this->dados['chamado']->DTA_INICIO} <b>Para Data Inicio:</b> {$_POST['dta_inicio']}<br><br>";
							}
							if ($this->dados['chamado']->DTA_FIM != $_POST['dta_fim']){
								$Post->dta_fim = $_POST['dta_fim'];
								$des_movimento .= "<b>De Data Fim:</b> {$this->dados['chamado']->DTA_FIM} <b>Para Data Fim:</b> {$_POST['dta_fim']}<br><br>";
							}
							if ($this->dados['chamado']->CC != $_POST['cc']){
								$Post->cc = $_POST['cc'];
								$des_movimento .= "<b>De CC:</b> {$cc[$this->dados['chamado']->CC]}<b>Para CC:</b> {$cc[$_POST['cc']]}<br><br>";
							}
						}
						if ($this->dados['chamado']->SUBCATEGORIA == '66'){
							if ($this->dados['chamado']->DTA_INICIO != $_POST['dta_inicio']){
								$Post->dta_inicio = $_POST['dta_inicio'];
								$des_movimento .= "<b>De Data Inicio:</b> {$this->dados['chamado']->DTA_INICIO} <b>Para Data Inicio:</b> {$_POST['dta_inicio']}<br><br>";
							}
							if ($this->dados['chamado']->DTA_FIM != $_POST['dta_fim']){
								$Post->dta_fim = $_POST['dta_fim'];
								$des_movimento .= "<b>De Data Fim:</b> {$this->dados['chamado']->DTA_FIM} <b>Para Data Fim:</b> {$_POST['dta_fim']}<br><br>";
							}
							if ($this->dados['chamado']->MOTIVO != $_POST['motivo']){
								$Post->motivo = $_POST['motivo'];
								$motan = ($this->dados['chamado']->MOTIVO == "L") ? "Loja" : "Pv";
								$motatu = ($_POST['motivo'] == "L") ? "Loja" : "Pv";
								$des_movimento .= "<b>De Motivo:</b> {$motan}<b>Para Motivo:</b> {$motatu}<br><br>";
							}
						}
					}
					if (($_POST['des_movimento'] != "") && ($des_movimento == "")){
						if (($this->dados['chamado']->SITUACAO == "AU") && ($_POST["des_movimento"] != "")){
							$semana = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
							$semana = strtotime(date("m/d/Y", strtotime($semana)));
							$semana = $this->funcoes->retiraAcentos(str_replace("-feira", "", strtolower(strftime('%A',$semana))));
							if ($semana == "segunda"){
								$dia = 1;
							}elseif ($semana == "terca"){
								$dia = 2;
							}elseif ($semana == "quarta"){
								$dia = 3;
							}elseif ($semana == "quinta"){
								$dia = 4;
							}elseif ($semana == "sexta"){
								$dia = 5;
							}elseif ($semana == "sabado"){
								$dia = 6;
							}else{
								$dia = 7;
							}
							$atual = strtotime(date('Y-m-d'));
							$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
							$ult_mov = strtotime(date("Y-m-d", strtotime($ult_mov)));
							$calc_dias = $atual - $ult_mov;
							$dias_mov = round($calc_dias/(60 * 60 * 24));
							
							if ($dias_mov == 0){
								$atual = strtotime(date('Y-m-d H:i:s'));
								$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
								$ult_mov = strtotime(date("Y-m-d H:i:s", strtotime($ult_mov)));
								$duracao = $atual - $ult_mov;
								$duracao = round($duracao/60);
							}else{
								for ($i=0; $i <= $dias_mov; $i++){
									if ($i == 0){
										$fim_exp =  strtotime($this->dados['chamado']->HORA_FIM);
										$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
										$ult_mov = strtotime(date("H:i:s", strtotime($ult_mov)));
										$tempo = $fim_exp - $ult_mov;
										$duracao = round($tempo/60);
									}elseif ($i == $dias_mov){
										$ini_exp =  strtotime($this->dados['chamado']->HORA_INICIO);
										$mov =  strtotime(date('H:i:s'));
										$tempo = $mov - $ini_exp;
										$duracao = $duracao + round($tempo/60);
									}else{
										if ($dia == 6){
											$duracao = $duracao + 240;
										}elseif ($dia == 7){
											$duracao = $duracao;
											$dia = 0;
										}else{
											$duracao = $duracao + 528;
										}
									}
									$dia = $dia + 1;
								}
							}
							$Post = new Chamado();
							$Post->chamado = $this->chamado;
							$Post->ambiente = $this->ambiente;
							$Post->tempo_aguardando = ($this->dados['chamado']->TEMPO_AGUARDANDO + $duracao);
							$Post->status = 8;
							$Post->dta_ult_movimento = date("d/m/Y H:i:s");
							$des_movimento .= "<b>De Status:</b> {$this->dados['chamado']->DES_STATUS} <b>Para Status:</b> RETORNO DO USUARIO<br><br>";
							$sql[$i] = $apiChamado->editChamado($Post);
							$i = $i+1;
						}
						$movimento = new Movimento();
						$movimento->chamado = $this->chamado;
						$movimento->ambiente = $this->ambiente;
						$movimento->des_movimento = ($_POST["des_movimento"] != "" ? str_replace("\r\n","<br>",$_POST["des_movimento"])."<br><br>":"").$des_movimento;
						$movimento->usuario = $_SESSION['usuario_sessao'];
						$movimento->dta_movimento = date("d/m/Y H:i:s");
						if (isset($_FILES['anexo']['name'][0])) {
							$ex = explode(".", $_FILES['anexo']['name'][0]);
							$exp = end($ex);
							$movimento->anexo1 = "{$_SESSION['empresa_sessao']}-{$_SESSION['usuario_sessao']}-{$this->chamado}-{$this->ambiente}-Anexo1".date('dmY-His').".{$exp}";
						}
						if (isset($_FILES['anexo']['name'][1])) {
							$ex = explode(".", $_FILES['anexo']['name'][1]);
							$exp = end($ex);
							$movimento->anexo2 = "{$_SESSION['empresa_sessao']}-{$_SESSION['usuario_sessao']}-{$this->chamado}-{$this->ambiente}-Anexo2".date('dmY-His').".{$exp}";
						}
						if (isset($_FILES['anexo']['name'][2])) {
							$ex = explode(".", $_FILES['anexo']['name'][2]);
							$exp = end($ex);
							$movimento->anexo3 = "{$_SESSION['empresa_sessao']}-{$_SESSION['usuario_sessao']}-{$this->chamado}-{$this->ambiente}-Anexo3".date('dmY-His').".{$exp}";
						}
						$sql[$i] = $apiChamado->addMovimento($movimento);
						$rs = $apiChamado->executeSQL($sql);
						
						if (@$rs[4] == 'sucesso') {
							if (isset($_FILES['anexo']['tmp_name'][0])) {
								move_uploaded_file($_FILES['anexo']['tmp_name'][0], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/chamado/".$movimento->anexo1);
							}
							if (isset($_FILES['anexo']['tmp_name'][1])) {
								move_uploaded_file($_FILES['anexo']['tmp_name'][1], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/chamado/".$movimento->anexo2);
							}
							if (isset($_FILES['anexo']['tmp_name'][2])) {
								move_uploaded_file($_FILES['anexo']['tmp_name'][2], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/chamado/".$movimento->anexo3);
							}
							$env = "O chamado: {$this->chamado} foi movimentado";
						}else{
							$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
							$erro = str_replace($retirar, "", $rs[2]);
							$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
						}
					}elseif ($des_movimento != ""){
						if (($apiChamado->editChamado($Post)) != ""){
							$sql[$i] = $apiChamado->editChamado($Post);
							$i = $i+1;
						}
						$movimento = new Movimento();
						$movimento->chamado = $this->chamado;
						$movimento->ambiente = $this->ambiente;
						$movimento->des_movimento = ($_POST["des_movimento"] != "" ? $mov_fim.str_replace("\r\n","<br>",$_POST["des_movimento"])."<br><br>":"{$mov_fim}").$des_movimento;
						$movimento->usuario = $_SESSION['usuario_sessao'];
						$movimento->dta_movimento = date("d/m/Y H:i:s");
						if (isset($_FILES['anexo']['name'][0])) {
							$ex = explode(".", $_FILES['anexo']['name'][0]);
							$exp = end($ex);
							$movimento->anexo1 = "{$_SESSION['empresa_sessao']}-{$_SESSION['usuario_sessao']}-{$this->chamado}-{$this->ambiente}-Anexo1".date('dmY-His').".{$exp}";
						}
						if (isset($_FILES['anexo']['name'][1])) {
							$ex = explode(".", $_FILES['anexo']['name'][1]);
							$exp = end($ex);
							$movimento->anexo2 = "{$_SESSION['empresa_sessao']}-{$_SESSION['usuario_sessao']}-{$this->chamado}-{$this->ambiente}-Anexo2".date('dmY-His').".{$exp}";
						}
						if (isset($_FILES['anexo']['name'][2])) {
							$ex = explode(".", $_FILES['anexo']['name'][2]);
							$exp = end($ex);
							$movimento->anexo3 = "{$_SESSION['empresa_sessao']}-{$_SESSION['usuario_sessao']}-{$this->chamado}-{$this->ambiente}-Anexo3".date('dmY-His').".{$exp}";
						}
						$sql[$i] = $apiChamado->addMovimento($movimento);
						$rs = $apiChamado->executeSQL($sql);
						if (@$rs[4] == 'sucesso') {
							if (isset($_FILES['anexo']['tmp_name'][0])) {
								move_uploaded_file($_FILES['anexo']['tmp_name'][0], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/chamado/".$movimento->anexo1);
							}
							if (isset($_FILES['anexo']['tmp_name'][1])) {
								move_uploaded_file($_FILES['anexo']['tmp_name'][1], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/chamado/".$movimento->anexo2);
							}
							if (isset($_FILES['anexo']['tmp_name'][2])) {
								move_uploaded_file($_FILES['anexo']['tmp_name'][2], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/chamado/".$movimento->anexo3);
							}
							$env = "O chamado: {$this->chamado} foi movimentado";
						}else{
							$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
							$erro = str_replace($retirar, "", $rs[2]);
							$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
						}
					}elseif (isset($_FILES['anexo']['name'][0]) || isset($_FILES['anexo']['name'][1]) || isset($_FILES['anexo']['name'][2])){
						if ($this->dados['chamado']->SITUACAO == "AU"){
							$semana = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
							$semana = strtotime(date("m/d/Y", strtotime($semana)));
							$semana = $this->funcoes->retiraAcentos(str_replace("-feira", "", strtolower(strftime('%A',$semana))));
							if ($semana == "segunda"){
								$dia = 1;
							}elseif ($semana == "terca"){
								$dia = 2;
							}elseif ($semana == "quarta"){
								$dia = 3;
							}elseif ($semana == "quinta"){
								$dia = 4;
							}elseif ($semana == "sexta"){
								$dia = 5;
							}elseif ($semana == "sabado"){
								$dia = 6;
							}else{
								$dia = 7;
							}
							$atual = strtotime(date('Y-m-d'));
							$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
							$ult_mov = strtotime(date("Y-m-d", strtotime($ult_mov)));
							$calc_dias = $atual - $ult_mov;
							$dias_mov = round($calc_dias/(60 * 60 * 24));
							
							if ($dias_mov == 0){
								$atual = strtotime(date('Y-m-d H:i:s'));
								$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
								$ult_mov = strtotime(date("Y-m-d H:i:s", strtotime($ult_mov)));
								$duracao = $atual - $ult_mov;
								$duracao = round($duracao/60);
							}else{
								for ($i=0; $i <= $dias_mov; $i++){
									if ($i == 0){
										$fim_exp =  strtotime($this->dados['chamado']->HORA_FIM);
										$ult_mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
										$ult_mov = strtotime(date("H:i:s", strtotime($ult_mov)));
										$tempo = $fim_exp - $ult_mov;
										$duracao = round($tempo/60);
									}elseif ($i == $dias_mov){
										$ini_exp =  strtotime($this->dados['chamado']->HORA_INICIO);
										$mov =  strtotime(date('H:i:s'));
										$tempo = $mov - $ini_exp;
										$duracao = $duracao + round($tempo/60);
									}else{
										if ($dia == 6){
											$duracao = $duracao + 240;
										}elseif ($dia == 7){
											$duracao = $duracao;
											$dia = 0;
										}else{
											$duracao = $duracao + 528;
										}
									}
									$dia = $dia + 1;
								}
							}
							$Post = new Chamado();
							$Post->chamado = $this->chamado;
							$Post->ambiente = $this->ambiente;
							$Post->tempo_aguardando = ($this->dados['chamado']->TEMPO_AGUARDANDO + $duracao);
							$Post->status = 8;
							$Post->dta_ult_movimento = date("d/m/Y H:i:s");
							$des_movimento .= "<b>De Status:</b> {$this->dados['chamado']->DES_STATUS} <b>Para Status:</b> RETORNO DO USUARIO<br><br>";
							$sql[$i] = $apiChamado->editChamado($Post);
							$i = $i+1;
						}
						$movimento = new Movimento();
						$movimento->chamado = $this->chamado;
						$movimento->ambiente = $this->ambiente;
						$movimento->des_movimento = "{$des_movimento}Arquivo anexado no chamado<br><br>";
						$movimento->usuario = $_SESSION['usuario_sessao'];
						$movimento->dta_movimento = date("d/m/Y H:i:s");
						if (isset($_FILES['anexo']['name'][0])) {
							$ex = explode(".", $_FILES['anexo']['name'][0]);
							$exp = end($ex);
							$movimento->anexo1 = "{$_SESSION['empresa_sessao']}-{$_SESSION['usuario_sessao']}-{$this->chamado}-{$this->ambiente}-Anexo1".date('dmY-His').".{$exp}";
						}
						if (isset($_FILES['anexo']['name'][1])) {
							$ex = explode(".", $_FILES['anexo']['name'][1]);
							$exp = end($ex);
							$movimento->anexo2 = "{$_SESSION['empresa_sessao']}-{$_SESSION['usuario_sessao']}-{$this->chamado}-{$this->ambiente}-Anexo2".date('dmY-His').".{$exp}";
						}
						if (isset($_FILES['anexo']['name'][2])) {
							$ex = explode(".", $_FILES['anexo']['name'][2]);
							$exp = end($ex);
							$movimento->anexo3 = "{$_SESSION['empresa_sessao']}-{$_SESSION['usuario_sessao']}-{$this->chamado}-{$this->ambiente}-Anexo3".date('dmY-His').".{$exp}";
						}
						$sql[$i] = $apiChamado->addMovimento($movimento);
						$rs = $apiChamado->executeSQL($sql);
						if (@$rs[4] == 'sucesso') {
							if (isset($_FILES['anexo']['tmp_name'][0])) {
								move_uploaded_file($_FILES['anexo']['tmp_name'][0], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/chamado/".$movimento->anexo1);
							}
							if (isset($_FILES['anexo']['tmp_name'][1])) {
								move_uploaded_file($_FILES['anexo']['tmp_name'][1], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/chamado/".$movimento->anexo2);
							}
							if (isset($_FILES['anexo']['tmp_name'][2])) {
								move_uploaded_file($_FILES['anexo']['tmp_name'][2], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/chamado/".$movimento->anexo3);
							}
							$env = "O chamado: {$this->chamado} foi movimentado";
						}else{
							$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
							$erro = str_replace($retirar, "", $rs[2]);
							$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
						}
					}
					if ($env != "") {
						$this->dados = array('chamado' => $apiChamado->getChamado($chamado));
						$exp_s = explode(" ", $this->dados['chamado']->NOME_SOLICITANTE);
						$exp_s[1] = end($exp_s);
						$exp_t = explode(" ", $this->dados['chamado']->NOME_TECNICO);
						$exp_t[1] = end($exp_t);
						//$ms = "O chamado: {$this->dados['chamado']->CHAMADO} foi movimentado";
						$mov = "";
						$this->movimento = $apiChamado->getMovimento($this->chamado, $this->ambiente);
						foreach ($this->movimento as $rs){
							$mov .= "<hr /><p style='margin-bottom:10px; margin-top:2px; font-style: italic;color: #606060;'>Em {$rs->DTA_MOVIMENTO}<br>Autor: {$rs->NOME}</p>{$rs->DES_MOVIMENTO}";
						}
						
						
						$Host = "email-ssl.com.br";
						$IsHTML = true;
						$SMTPAuth = true;
						$SMTPSecure = "ssl";
						$Username = 'helpdesk@grupomonaco.com.br';
						$Password = '4dM.grup0.D0mR';
						$Port = 465;
						
						$email = new PHPMailer();
						$email->IsSMTP();
						$email->Host = $Host;
						$email->IsHTML($IsHTML);
						$email->SMTPAuth = $SMTPAuth;
						$email->SMTPSecure = $SMTPSecure;
						
						$email->Username = $Username;
						$email->Password = $Password;
						$email->Port = $Port;
						
						
						$email->From = $Username;
						$email->FromName  = "SisMonaco - HelpDesk";
						$email->Subject   = ($this->dados['chamado']->STATUS != 4) ? ($this->dados['chamado']->SUBCATEGORIA == 60) ? "[Chamado #{$this->dados['chamado']->CHAMADO}] DESLIGAMENTO: {$this->dados['chamado']->DES_EMPRESA}, FUNCION�RIO: {$this->dados['chamado']->NOME_FUNCIONARIO}" : "[Chamado #{$this->dados['chamado']->CHAMADO}] {$this->dados['chamado']->ASSUNTO}" : "[Chamado #{$this->dados['chamado']->CHAMADO}] NOVO STATUS: {$this->dados['chamado']->DES_STATUS}";
						if ($this->dados['chamado']->STATUS == 4){
							$ag = 	"<tr>
									<td colspan='2' style='padding: 9px; color: #000000; background: #ffff00;'>
										<img src='' />
										<br>
										<p align='center' style='margin-top:0px;margin-bottom:0px;font-size: 20px; font-style: italic;'>STATUS AGUARDANDO O USU�RIO SER� ENCERRADO CASO N�O SEJA RESPONDIDO EM 2 DIAS POR FALTA DE RETORNO.</p>
									</td>
								</tr>";
						}else{
							$ag = "";
						}
						
						if ($this->dados['chamado']->SUBCATEGORIA == 60){
							$desl = "<strong>Empresa:</strong> {$this->dados['chamado']->DES_EMPRESA}<br />
							<br />
							<strong>Departamento:</strong> {$this->dados['chamado']->DEPARTAMENTO_FUNCIONARIO}<br />
							<br />
							<strong>Desligado:</strong> {$this->dados['chamado']->NOME_FUNCIONARIO}<br />
							<br />
							<strong>Cargo:</strong> {$this->dados['chamado']->CARGO_FUNCIONARIO}<br />
							<br />";
						}else{
							$desl = "";
						}		
						
						$mensagem = "<html>
										<head></head>
										<body style='margin:0px; padding:0px; border: 0 none; font-size: 9px; font-family: verdana, sans-serif; background-color: #efefef;'>
											<style type='text/css'>
												td p{margin-bottom: 10px;}
												body.ticket {margin:0px; padding:0px; border: 0 none; font-size: 9px; font-family: verdana, sans-serif; background-color: #efefef;}
												h1.title {margin-bottom:0px;}
												p.subtitle {color: #ccc;margin-top:0px;margin-bottom:0px;font-style: italic;}
												table.content {width: 700px; margin: 50px auto 50px auto; border: 1px #ccc solid; background: #fff; font-size: 11px; font-family: verdana, sans-serif;}
												td.uppercontent {border:0px;padding: 9px; color: #fff; background: #070075;}
												tr.lowercontent {padding: 10px;}
												td.leftcolumn {width: 400px; padding: 15px 0px 0px 18px; vertical-align: top;}
												td.rightcolumn {width: 240px; vertical-align: top;}
												div.rightcolumndiv{margin:15px 8px 15px;padding: 9px; border: 1px #ccc solid; font-size: 10px;}
												p.rcmessage {margin-top:5px;}
												a.links {color:#0000FF; text-decoration: none;}
												hr.rcdivider {height: 1px; color: #ccc;}
												p.tickethistory {margin-bottom:10px; margin-top:2px; font-style: italic;color: #606060;}
												table.ticket-sum-hist {border: 1px #ccc solid; background: #eee; width: 394px; font-size: 11px; font-family: verdana, sans-serif;}
												div.ticket-sum-histdiv {margin: 9px;}
												h2.ticket-sum-hist-titles {margin-bottom:5px; margin-top:10px; font-size:12px;}
												p.date {font-style: italic;margin-bottom:10px;}
											</style>
											<table style='width: 800px; margin: 50px auto 50px auto; border: 1px #ccc solid; background: #fff; font-size: 11px; font-family: verdana, sans-serif;' align='center'>
											<tbody>
												<tr>
													<td colspan='2' style='padding: 9px; color: #fff; background: #000000;'>
														<img src='' />
														<br>
														<p style='margin-top:0px;margin-bottom:0px;font-style: italic;'>Notifica��o do Help Desk.</p>
													</td>
												</tr>
												{$ag}
												<tr style='padding: 10px;'>
													<td style='width: 240px; vertical-align: top;'>
														<div style='margin:15px 8px 15px;padding: 9px; border: 1px #ccc solid; font-size: 10px;'>
															<strong>Chamado: </strong>{$this->dados['chamado']->CHAMADO}
															<hr style='height: 1px; color: #ccc;' />
															<strong>Data de Abertura:</strong> {$this->dados['chamado']->DTA_ABERTURA}<br />
															<br />
															<strong>Criado por:</strong> <a style='color:#0000FF; text-decoration: none;' href='mailto:{$this->dados['chamado']->EMAIL_SOLICITANTE}?subject=[Chamado #{$this->dados['chamado']->CHAMADO}] {$this->dados['chamado']->ASSUNTO}'>{$exp_s[0]} {$exp_s[1]}</a><br />
															<br />
															<strong>Assunto:</strong> {$this->dados['chamado']->ASSUNTO}<br />
															<br />
															{$desl}
															<strong>Subcategoria:</strong> {$this->dados['chamado']->DES_SUBCATEGORIA}<br  />
															<br />
															<strong>Status:</strong> {$this->dados['chamado']->DES_STATUS}<br  />
															<br />
															<strong>Vencimento:</strong> {$this->dados['chamado']->DTA_VENCIMENTO}<br  />
															<br />
															<strong>Telefone:</strong>".($this->dados['chamado']->TELEFONE_SOLICITANTE != "" ? $this->funcoes->mask($this->dados['chamado']->TELEFONE_SOLICITANTE,'(##)####-####'): "")."<br />
												            <br />
												            <strong>Celular:</strong>".($this->dados['chamado']->CELULAR_SOLICITANTE != "" ? $this->funcoes->mask($this->dados['chamado']->CELULAR_SOLICITANTE,'(##)#####-####'): "")."<br />
												            <br />
												            <strong>Chamado URL:</strong> <a style='color:#0000FF; text-decoration: none;' href='".APP_ROOT."help/chamado/alterar/{$this->dados['chamado']->CHAMADO}'>Chamado {$this->dados['chamado']->CHAMADO}</a><br />
												            <br />
												            <strong>T�cnico:</strong> <a style='color:#0000FF; text-decoration: none;' href='mailto:{$this->dados['chamado']->EMAIL_TECNICO}?subject=[Chamado #{$this->dados['chamado']->CHAMADO}] {$this->dados['chamado']->ASSUNTO}'>{$exp_t[0]} {$exp_t[1]}</a><br />
												            <br />
												            <hr style='height: 1px; color: #ccc;' />
												            <p style='margin-top:5px;'>se voc� tiver alguma informa��o adicional referente
												            ao chamado <strong>{$this->dados['chamado']->CHAMADO}</strong> Por favor acesse o helpdesk
												            <a style='color:#0000FF; text-decoration: none;' href='".APP_ROOT."help/chamado/'>
												            aqui</a> e movimente ou veja outros chamados.</p>
											            </div>
											       	</td>
											        <td style='width: 400px; padding: 15px 0px 0px 18px; vertical-align: top;'>
											       		<p style='margin-bottom: 10px;'>{$exp_s[0]} {$exp_s[1]},</p>
											            <p style='font-style: italic;margin-bottom:10px;'>{$env}.</p>
											            <br>
											            <br>
											            <br />
											            <table style='border: 1px #ccc solid; background: #eee; width: 394px; font-size: 11px; font-family: verdana, sans-serif;'>
											            	<tr>
											            		<td>
														            <div style='margin: 9px;'>
															            <h2 style='margin-bottom:5px; margin-top:10px; font-size:12px;'>Chamado: {$this->dados['chamado']->CHAMADO}</h2>
															            <p style='margin-bottom: 10px;'><strong>Assunto:</strong> {$this->dados['chamado']->ASSUNTO}</p>
															            <p style='margin-bottom: 10px;'><strong>Descri��o:</strong></p>{$this->dados['chamado']->DES_CHAMADO}
															            <hr />
															            <br>
															            <br>
															            <h2 style='margin-bottom:5px; margin-top:10px; font-size:12px;'>Atualiza��es do Chamado & Hist�rico</h2>
															            {$mov}
														            </div>
											            		</td>
											            	</tr>
											            </table>
											            <br />
											            <br />
											        </td>
											   	</tr>
											</tbody>
											</table>
										</body>
									</html>";
						            $email->MsgHTML($mensagem);
						            $email->AddAddress("{$this->dados['chamado']->EMAIL_SOLICITANTE}");
						            if (($this->dados['chamado']->AMBIENTE == 2) && (($this->dados['chamado']->SUBCATEGORIA == 5) || ($this->dados['chamado']->SUBCATEGORIA == 59) || ($this->dados['chamado']->SUBCATEGORIA == 60))){
						            	if (isset($this->dados['chamado']->SIGILOSO)){
						            		if ($this->dados['chamado']->SIGILOSO != 'S'){
						            			$apiTecempsubcategoria = new apiTecempsubcategoria();
						            			$env = $apiTecempsubcategoria->envolvidosAmbiente("1", $this->dados['chamado']->EMPRESA, $this->dados['chamado']->AMBIENTE);
						            			$sub = array();
						            			foreach ($env as $rs){
						            				unset($sub);
						            				$sub = explode(",", $rs->SUBCATEGORIA);
						            				if (in_array("{$this->dados['chamado']->SUBCATEGORIA}", $sub)){
						            					$email->AddCC("{$rs->EMAIL}");
						            				}
						            			}
						            		}
						            	}else{
						            		$apiTecempsubcategoria = new apiTecempsubcategoria();
						            		$env = $apiTecempsubcategoria->envolvidosAmbiente("1", $this->dados['chamado']->EMPRESA, $this->dados['chamado']->AMBIENTE);
						            		$sub = array();
						            		foreach ($env as $rs){
						            			unset($sub);
						            			$sub = explode(",", $rs->SUBCATEGORIA);
						            			if (in_array("{$this->dados['chamado']->SUBCATEGORIA}", $sub)){
						            				$email->AddCC("{$rs->EMAIL}");
						            			}
						            		}
						            	}
						            }
						            if (isset($email_gerente)){
						            	$email->AddCC("{$email_gerente}");
						            }
						            $email->AddCC("{$this->dados['chamado']->EMAIL_TECNICO}");						            					            
						            $email->Send();
						            $email->ClearAllRecipients();
						            $email->ClearAttachments(); 

						            if ($this->dados['chamado']->AUT_SITUACAO == "1" || $this->dados['chamado']->AUT_SITUACAO == "2"){
						            	if (isset($this->PaginaAtual)) {
						            		header('location:' .APP_ROOT. 'help/chamado/index/pagina/'.$this->PaginaAtual.'/sucesso');
						            	}else {
						            		header('location:' .APP_ROOT. 'help/chamado/index/sucesso');
						            	}
						            }else{
							            if (isset($this->PaginaAtual)) {
							            	header('location:' .APP_ROOT. 'help/chamado/alterar/'."{$this->chamado},{$this->ambiente}".'/'.$this->PaginaAtual.'/sucesso');
							            	die();
							            }else {
							            	header('location:' .APP_ROOT. 'help/chamado/alterar/'."{$this->chamado},{$this->ambiente}".'/sucesso');
							            	die();
							            }
						            }
					}else{
						if (isset($this->PaginaAtual)) {
							header('location:' .APP_ROOT. 'help/chamado/alterar/'."{$this->chamado},{$this->ambiente}".'/'.$this->PaginaAtual);
							die();
						}else {
							header('location:' .APP_ROOT. 'help/chamado/alterar/'."{$this->chamado},{$this->ambiente}");
							die();
						}
					}
				}else{
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'help/chamado/alterar/'."{$this->chamado},{$this->ambiente}".'/'.$this->PaginaAtual);
						die();
					}else {
						header('location:' .APP_ROOT. 'help/chamado/alterar/'."{$this->chamado},{$this->ambiente}");
						die();
					}
				}
			}
		}
		$this->view();
	}
}