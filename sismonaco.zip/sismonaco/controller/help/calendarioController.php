<?php

namespace controller\help;

use lib\Controller;
use helper\Security;
use api\help\apiCalendario;
use helper\Funcoes;
use obj\help\Calendario;
use obj\geral\Log;
use api\geral\apiLog;

class calendarioController extends Controller {
	
	public function __construct() {
		
		parent::__construct();
		
		new Security($this->getModule(),$this->getController(),$this->getAction());
	}
	
	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Planejamento Mensal";
		$apiCalendario = new apiCalendario();
		$this->dados = array('calendario' => $apiCalendario->getCalendario());
		$this->view();
	}
	
	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Calend�rio de Plant�es";
		$this->funcoes = new Funcoes();
		$apiCalendario = new apiCalendario();
		$this->dados = array('calendario' => $apiCalendario->getCalendario());
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$anterior = "";
			$atual = "::";
			for($c=1; $c <32;$c++){
				$calendario = new Calendario();
				if($this->dados['calendario'][$c-1]->PLANTAO != $_POST["plantao{$c}"]){
					$calendario->calendario = $this->dados['calendario'][$c-1]->CALENDARIO;
					$anterior .= "CALENDARIO||{$this->dados['calendario'][$c-1]->CALENDARIO};;";
					$atual .= "CALENDARIO||{$this->dados['calendario'][$c-1]->CALENDARIO};;";
					if ($this->dados['calendario'][$c-1]->FERIADO != $_POST["feriado{$c}"]){
						$calendario->plantao = $_POST["plantao{$c}"];
						$anterior .= "PLANTAO||{$this->dados['calendario'][$c-1]->PLANTAO};;";
						$atual .= "PLANTAO||{$calendario->plantao};;";
						$calendario->feriado = $_POST["feriado{$c}"];
						$anterior .= "FERIADO||{$this->dados['calendario'][$c-1]->FERIADO};;";
						$atual .= "FERIADO||{$calendario->feriado};;";
						$sql[$i] = $apiCalendario->editCalendario($calendario);
						$i = $i+1;
					}else{
						$calendario->plantao = $_POST["plantao{$c}"];
						$anterior .= "PLANTAO||{$this->dados['calendario'][$c-1]->PLANTAO};;";
						$atual .= "PLANTAO||{$calendario->plantao};;";
						$sql[$i] = $apiCalendario->editCalendario($calendario);
						$i = $i+1;
					}
				}elseif ($this->dados['calendario'][$c-1]->FERIADO != $_POST["feriado{$c}"]){
					$calendario->calendario = $this->dados['calendario'][$c-1]->CALENDARIO;
					$anterior .= "CALENDARIO||{$this->dados['calendario'][$c-1]->CALENDARIO};;";
					$atual .= "CALENDARIO||{$this->dados['calendario'][$c-1]->CALENDARIO};;";
					$calendario->feriado = $_POST["feriado{$c}"];
					$anterior .= "FERIADO||{$this->dados['calendario'][$c-1]->FERIADO};;";
					$atual .= "FERIADO||{$calendario->feriado};;";
					$sql[$i] = $apiCalendario->editCalendario($calendario);
					$i = $i+1;
				}
			}
			if ((is_array($sql) ? count($sql) : 0) > 0){
				$log = new Log();
				$log->historico = substr($anterior,0,-2);
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "A";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico .= substr($atual,0,-2);
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiCalendario->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'help/calendario/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'help/calendario/index/sucesso');
					}
				}else{
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}else{
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'help/calendario/index/pagina/'.$this->PaginaAtual);
				}else {
					header('location:' .APP_ROOT. 'help/calendario/index/');
				}
			}
		}
		$this->view();
	}
}