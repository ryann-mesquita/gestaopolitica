<?php

namespace controller\help;

use lib\Controller;
use helper\Security;
use api\help\apiConsolidado;
use helper\Paginator;
use obj\help\Consolidado;
use obj\geral\Log;
use api\geral\apiLog;

class consolidadoController extends Controller {
	
	public function __construct() {
		
		parent::__construct();
		
		new Security($this->getModule(),$this->getController(),$this->getAction());
	}
	
	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Lista de Consolidado";
		$apiConsolidado = new apiConsolidado();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$busca = array(
				'1' => array('c' => '1', 'ano' => @$_POST['ano'], 'mes' => @$_POST['mes']),
				'2' => array('c' => '2', 'ano' => "", 'mes' => "")
			);
			if(isset($busca[$_POST['busca']])){
				$this->dados = array('consolidado' => $apiConsolidado->filtroConsolidado($busca[$_POST['busca']]['c'], $busca[$_POST['busca']]['ano'], $busca[$_POST['busca']]['mes']));
				$_SESSION['filtro_sessao'] = array('c' => $busca[$_POST['busca']]['c'], 'ano' => $busca[$_POST['busca']]['ano'], 'mes' => $busca[$_POST['busca']]['mes'],  'busca' => $_POST['busca']);
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'help/index/index/acessonegado');
				die();
			}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				$this->dados = array('consolidado' => $apiConsolidado->filtroConsolidado($_SESSION['filtro_sessao']['c'], $_SESSION['filtro_sessao']['ano'], $_SESSION['filtro_sessao']['mes']));
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('consolidado' => $apiConsolidado->filtroConsolidado('2'));
					$_SESSION['filtro_sessao'] = array('c' => '2', 'ano' => '', 'mes' => '', 'busca' => '2');
					$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}
		}
		$TotalItem = (is_array($this->dados['consolidado']) ? count($this->dados['consolidado']) : 0);
		$this->dados['consolidado'] = array_chunk($this->dados['consolidado'], $ItemPorPagina);
		@$this->dados['consolidado'] = $this->dados['consolidado'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->view();
	}
	
	public function adicionar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Cadastro de Consolidado";
		$apiConsolidado = new apiConsolidado();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$Post = new Consolidado('POST');
			$Post->dta_cadastro = date('d/m/Y H:i:s');
			$apiConsolidado = new apiConsolidado();
			$rs = $apiConsolidado->filtroConsolidado('1',$Post->ano, $Post->mes);
			if ((is_array($rs) ? count($rs) : 0) > 0){
				$this->rollback = new Consolidado('POST');
				$this->Alert = "J� existe um consolidado para esse ano e m�s!";
			}else{
				$sql[$i] = $apiConsolidado->addConsolidado($Post);
				$i = $i+1;
				$log = new Log();
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico = "ANO||{$Post->ano};;MES||{$Post->mes};;ABERTO||{$Post->aberto};;NOPRAZO||{$Post->noprazo};;COMATRASO||{$Post->comatraso};;EXTERNO||{$Post->externo};;SEMFEEDBACK||{$Post->semfeedback};;PONTOS||{$Post->pontos};;TEMPOINICIO||{$Post->tempoinicio};;TEMPOCONCLUSAO||{$Post->tempoconclusao};;DTA_CADASTRO||{$Post->dta_cadastro}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiConsolidado->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'help/consolidado/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'help/consolidado/index/sucesso');
					}
				}else{
					$this->rollback = new Consolidado('POST');
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		
		$this->view();
	}
	
	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Altera��o de Consolidado";
		$consolidado = new Consolidado();
		$exp = explode(",", $this->getParams(0));
		$consolidado->ano = $exp[0];
		$consolidado->mes = $exp[1];
		$apiConsolidado = new apiConsolidado();
		$this->dados = array('consolidado' => $apiConsolidado->getConsolidado($consolidado));
		if (!isset($this->dados['consolidado'])){
			header('location:' .APP_ROOT. 'help/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$anterior = "";
			$atual = "::";
			$Post = new Consolidado();
			if ($this->dados['consolidado']->ABERTO != $_POST['aberto']){
				$Post->aberto = $_POST['aberto'];
				$anterior .= "ABERTO||{$this->dados['consolidado']->ABERTO};;";
				$atual .= "ABERTO||{$Post->aberto};;";
			}
			if ($this->dados['consolidado']->NOPRAZO != $_POST['noprazo']){
				$Post->noprazo = $_POST['noprazo'];
				$anterior .= "NOPRAZO||{$this->dados['consolidado']->NOPRAZO};;";
				$atual .= "NOPRAZO||{$Post->noprazo};;";
			}
			if ($this->dados['consolidado']->COMATRASO != $_POST['comatraso']){
				$Post->comatraso = $_POST['comatraso'];
				$anterior .= "COMATRASO||{$this->dados['consolidado']->COMATRASO};;";
				$atual .= "COMATRASO||{$Post->comatraso};;";
			}
			if ($this->dados['consolidado']->EXTERNO != $_POST['externo']){
				$Post->externo = $_POST['externo'];
				$anterior .= "EXTERNO||{$this->dados['consolidado']->EXTERNO};;";
				$atual .= "EXTERNO||{$Post->externo};;";
			}
			if ($this->dados['consolidado']->EXTERNO != $_POST['externo']){
				$Post->externo = $_POST['externo'];
				$anterior .= "EXTERNO||{$this->dados['consolidado']->EXTERNO};;";
				$atual .= "EXTERNO||{$Post->externo};;";
			}
			if ($this->dados['consolidado']->SEMFEEDBACK != $_POST['semfeedback']){
				$Post->semfeedback = $_POST['semfeedback'];
				$anterior .= "SEMFEEDBACK||{$this->dados['consolidado']->SEMFEEDBACK};;";
				$atual .= "SEMFEEDBACK||{$Post->semfeedback};;";
			}
			if ($this->dados['consolidado']->PONTOS != $_POST['pontos']){
				$Post->pontos = $_POST['pontos'];
				$anterior .= "PONTOS||{$this->dados['consolidado']->PONTOS};;";
				$atual .= "PONTOS||{$Post->pontos};;";
			}
			if ($this->dados['consolidado']->TEMPOINICIO != $_POST['tempoinicio']){
				$Post->tempoinicio = $_POST['tempoinicio'];
				$anterior .= "TEMPOINICIO||{$this->dados['consolidado']->TEMPOINICIO};;";
				$atual .= "TEMPOINICIO||{$Post->tempoinicio};;";
			}
			if ($this->dados['consolidado']->TEMPOCONCLUSAO != $_POST['tempoconclusao']){
				$Post->tempoconclusao = $_POST['tempoconclusao'];
				$anterior .= "TEMPOCONCLUSAO||{$this->dados['consolidado']->TEMPOCONCLUSAO};;";
				$atual .= "TEMPOCONCLUSAO||{$Post->tempoconclusao};;";
			}
			$obj = (array) $Post;
			$obj = array_filter($obj, function($v){return !is_null($v);});
			if ($obj != NULL){
				$Post->ano = $exp[0];
				$Post->mes = $exp[1];
				$sql[$i] = $apiConsolidado->editConsolidado($Post);
				$i = $i+1;
				$log = new Log();
				$log->historico = substr($anterior,0,-2);
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "A";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico .= substr($atual,0,-2);
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiConsolidado->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'help/consolidado/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'help/consolidado/index/sucesso');
					}
				}else{
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}else{
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'help/consolidado/index/pagina/'.$this->PaginaAtual.'/insucesso');
				}else {
					header('location:' .APP_ROOT. 'help/consolidado/index/insucesso');
				}
			}
		}
		$this->view();
	}
	public function excluir() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Exclus�o de Consolidado";
		$consolidado = new Consolidado();
		$exp = explode(",", $this->getParams(0));
		$consolidado->ano = $exp[0];
		$consolidado->mes = $exp[1];
		$apiConsolidado = new apiConsolidado();
		$this->dados = array('consolidado' => $apiConsolidado->getConsolidado($consolidado));
		if (!isset($this->dados['consolidado'])){
			header('location:' .APP_ROOT. 'help/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$sql[$i] = $apiConsolidado->delConsolidado($consolidado);
			$i = $i+1;
			$log = new Log();
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "E";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico = "ANO||{$this->dados['consolidado']->ANO};;MES||{$this->dados['consolidado']->MES};;NOPRAZO||{$this->dados['consolidado']->NOPRAZO};;COMATRASO||{$this->dados['consolidado']->COMATRASO};;SEMFEEDBACK||{$this->dados['consolidado']->SEMFEEDBACK};;PONTOS||{$this->dados['consolidado']->PONTOS};;TEMPOINICIO||{$this->dados['consolidado']->TEMPOINICIO};;TEMPOCONCLUSAO||{$this->dados['consolidado']->TEMPOCONCLUSAO};;DTA_CADASTRO||{$this->dados['consolidado']->DTA_CADASTRO}";
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiConsolidado->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'help/consolidado/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'help/consolidado/index/sucesso');
				}
			}else{
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}
		$this->view();
	}
}