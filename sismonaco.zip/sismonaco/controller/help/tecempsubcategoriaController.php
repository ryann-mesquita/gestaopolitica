<?php

namespace controller\help;

use lib\Controller;
use helper\Security;
use api\help\apiTecnico;
use api\help\apiAmbiente;
use helper\Paginator;
use obj\help\Tecnico;
use api\geral\apiEmpresa;
use api\help\apiSubcategoria;
use api\help\apiTecempsubcategoria;
use obj\help\Tecempsubcategoria;
use api\adm\apiUsuario;
use obj\help\Envolvidos;
use api\adm\apiPermissao;
use obj\adm\Permissao;
use obj\help\Gestores;

class tecempsubcategoriaController extends Controller {
	
	public function __construct() {
		
		parent::__construct();
		
		new Security($this->getModule(),$this->getController(),$this->getAction());
	}
	
	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Lista de T�cnicos";
		$apiTecnico = new apiTecnico();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-16"])){
			$apiAmbiente = new apiAmbiente();
			$amb = $apiAmbiente->filtroAmbiente('1', '3', 'ativo', '1');
			foreach ($amb as $rs){
				$this->ambiente[$rs->AMBIENTE] = array('ambiente' => $rs->AMBIENTE, 'des_ambiente' => $rs->DES_AMBIENTE);
			}
			$apiTecnico = new apiTecnico();
			$this->tecnico = $apiTecnico->filtroTecnico('1', '3', 't.tecnico', $_SESSION['usuario_sessao'],'tudo');
		}else{
			$apiTecnico = new apiTecnico();
			$this->tecnico = $apiTecnico->filtroTecnico('1', '3', 't.tecnico', $_SESSION['usuario_sessao'],'tudo');
			foreach ($this->tecnico as $rs){
				$this->ambiente[$rs->AMBIENTE] = array('ambiente' => $rs->AMBIENTE, 'des_ambiente' => $rs->DES_AMBIENTE);
			}
		}
		(!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])) ? $a = '1' : $a = '3';
		$apiEmpresa = new apiEmpresa();
		$this->empresa = $apiEmpresa->filtroEmpresa('1','3','ativo', '1');
		$apiUsuario = new apiUsuario();
		$this->usuario = $apiUsuario->filtroUsuario('1','3','u.ativo', '1');
		$apiSubcategoria = new apiSubcategoria();
		$this->subcategoria = $apiSubcategoria->filtroSubcategoria('1','3','s.ativo', '1','tudo');
		$apiTecempsubcategoria = new apiTecempsubcategoria();
		$apiPermissao = new apiPermissao();
		$permissao = new Permissao();
		$permissao->modulo = $this->getModule()['modulo'];
		$permissao->controle = $this->getController()['controle'];
		$permissao->acao = $this->getAction()['acao'];
		$permissao->usuario = $_SESSION['usuario_sessao'];
		$this->empresas_permitidas = $apiPermissao->permEmpresascontroleacao($permissao);
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$busca = array(
				'1' => array('c' => '1','a' => $a,'coluna' => 't.ativo', 'valor' => '1', 'ambiente' =>  $_POST['ambiente']),
				'2' => array('c' => '1','a' => $a,'coluna' => 't.ativo', 'valor' => '0', 'ambiente' =>  $_POST['ambiente']),
				'3' => array('c' => '1','a' => $a,'coluna' => 't.plantao', 'valor' => '1', 'ambiente' => $_POST['ambiente']),
				'4' => array('c' => '2','a' => $a,'coluna' => 'u.nome', 'valor' => @$_POST['busca_valor'], 'ambiente' => $_POST['ambiente'])
			);
			if(isset($busca[$_POST['busca']])){
				$this->dados = array('tecnico' => $apiTecnico->filtroTecnico($busca[$_POST['busca']]['c'], $busca[$_POST['busca']]['a'], $busca[$_POST['busca']]['coluna'], $busca[$_POST['busca']]['valor'], $busca[$_POST['busca']]['ambiente']));
				$_SESSION['filtro_sessao'] = array('c' => $busca[$_POST['busca']]['c'], 'a' => $busca[$_POST['busca']]['a'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'busca_valor' => $busca[$_POST['busca']]['valor'], 'ambiente' => $busca[$_POST['busca']]['ambiente'], 'busca' => $_POST['busca']);
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'help/index/index/acessonegado');
				die();
			}
			if (isset($_SESSION['filtro_sessao']['ambiente'])){
				$ambiente = $_SESSION['filtro_sessao']['ambiente'];
			}else{
				$ambiente = $this->ambiente[$this->tecnico[0]->AMBIENTE]['ambiente'];
			}
			if ($_POST["submeter"] == "alterar"){
				$en = $apiTecempsubcategoria->envolvidosAmbiente("3",$_SESSION['empresa_sessao'], $ambiente);
				foreach ($en as $rs){
					$env["{$rs->EMPRESA}"]["{$rs->USUARIO}"] = ($rs->SUBCATEGORIA != "") ? $rs->SUBCATEGORIA : false;
				}
				$empresa = $_POST["empresa"];
				@$usuario = $_POST["usuario"];
				$sql = array();
				$i = 0;
				if ((is_array($empresa) ? count($empresa) : 0) > 0){
					foreach ($empresa as $rs){
						/*if (count(@$env["{$rs}"]) > 0){
							foreach ($env["{$rs}"] as $key => $i1){
								if (!in_array("{$key}", $usuario)){
									$envolvidos = new Envolvidos();
									$envolvidos->ambiente = $ambiente;
									$envolvidos->empresa = $rs;
									$envolvidos->usuario = $key;
									$sql[$i] = $apiTecempsubcategoria->delEnvolvido($envolvidos);
									$i = $i + 1;
								}
							}
						}*/
						if (isset($usuario)){
							foreach ($usuario as $key => $i2){
								if (!isset($env["{$rs}"]["{$i2}"])){
									$envolvidos = new Envolvidos();
									$envolvidos->ambiente = $ambiente;
									$envolvidos->empresa = $rs;
									$envolvidos->usuario = $i2;
									$envolvidos->subcategoria = implode(",", $_POST["subcategoria{$key}"]);
									$sql[$i] = $apiTecempsubcategoria->addEnvolvido($envolvidos);
									$i = $i + 1;
								}elseif (isset($env["{$rs}"]["{$i2}"])){
									$envolvidos = new Envolvidos();
									$envolvidos->ambiente = $ambiente;
									$envolvidos->empresa = $rs;
									$envolvidos->usuario = $i2;
									$envolvidos->subcategoria = implode(",", $_POST["subcategoria{$key}"]);
									if ($env["{$rs}"]["{$i2}"] == false){
										$sql[$i] = $apiTecempsubcategoria->delEnvolvido($envolvidos);
										$i = $i + 1;
									}elseif ($env["{$rs}"]["{$i2}"] != $envolvidos->subcategoria){
										$sql[$i] = $apiTecempsubcategoria->editEnvolvido($envolvidos);
										$i = $i + 1;
									}
								}
							}
						}
					}
				}
				$apiTecempsubcategoria->executeSQL($sql);
				if ($PaginaAtual > 1) {
					header('location:' .APP_ROOT. 'help/tecempsubcategoria/index/pagina/'.$PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'help/tecempsubcategoria/index/sucesso');
				}
			}elseif ($_POST["submeter"] == "alterar2"){
				if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-17"])){
					$ge = $apiTecempsubcategoria->gestoresAmbiente("2",$_SESSION['empresa_sessao'], $ambiente);
					foreach ($ge as $rs){
						$ges["{$rs->EMPRESA}"] = $rs;
					}
					$empresa = $_POST["empresa2"];
					$sql = array();
					$i = 0;
					$gestores = new Gestores();
					$gestores->ambiente = $ambiente;
					if ((is_array($empresa) ? count($empresa) : 0) > 0){
						foreach ($empresa as $rs){
							$gestores->empresa = $rs;
							$gerente = explode("-", $_POST['gerente_dho'])[0];
							$diretor = explode("-", $_POST['diretor_dho'])[0];
							$gerentedp = explode("-", $_POST['gerente_dp'])[0];
							if (isset($ges["{$rs}"])){
								//edit ou del
								if ($gerente == "" && $diretor == "" && $gerentedp == ""){
									$sql[$i] = $apiTecempsubcategoria->delGestores($gestores);
									$i = $i+1;
								}else{
									$gestores->gerente_dho = $gerente;
									$gestores->diretor_dho = $diretor;
									$gestores->gerente_dp = $gerentedp;
									$sql[$i] = $apiTecempsubcategoria->editGestores($gestores);
									$i = $i+1;
								}	
							}else{
								$gestores->gerente_dho = $gerente;
								$gestores->diretor_dho = $diretor;
								$gestores->gerente_dp = $gerentedp;
								$sql[$i] = $apiTecempsubcategoria->addGestores($gestores);
								$i = $i+1;
							}
						}
					}
					$apiTecempsubcategoria->executeSQL($sql);
					if ($PaginaAtual > 1) {
						header('location:' .APP_ROOT. 'help/tecempsubcategoria/index/pagina/'.$PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'help/tecempsubcategoria/index/sucesso');
					}
				}
			}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				$this->dados = array('tecnico' => $apiTecnico->filtroTecnico($_SESSION['filtro_sessao']['c'],$_SESSION['filtro_sessao']['a'],$_SESSION['filtro_sessao']['coluna'], $_SESSION['filtro_sessao']['busca_valor'], $_SESSION['filtro_sessao']['ambiente']));
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('tecnico' => $apiTecnico->filtroTecnico('1','3','t.ativo', '1', @$this->ambiente[$this->tecnico[0]->AMBIENTE]['ambiente']));
					$_SESSION['filtro_sessao'] = array('c' => '1', 'a' => '3', 'coluna' => 'c.ativo' , 'busca_valor' => '1', 'ambiente' => @$this->ambiente[$this->tecnico[0]->AMBIENTE]['ambiente'], 'busca' => '1');
					$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}
		}
		if (isset($_SESSION['filtro_sessao']['ambiente'])){
			$ambiente = $_SESSION['filtro_sessao']['ambiente'];
		}else{
			$ambiente = $this->ambiente[$this->tecnico[0]->AMBIENTE]['ambiente'];
		}
		$result = $apiTecempsubcategoria->envolvidosAmbiente("1",$_SESSION['empresa_sessao'], $ambiente);
		foreach ($result as $rs){
			$this->usuarios_ambiente[] = array('usuario' => $rs->USUARIO, 'nome' => $rs->NOME, 'subcategoria' => explode(",", $rs->SUBCATEGORIA));
		}
		$this->gestores = $apiTecempsubcategoria->gestoresAmbiente("1", $_SESSION['empresa_sessao'], $ambiente);
		$TotalItem = (is_array($this->dados['tecnico']) ? count($this->dados['tecnico']) : 0);
		$this->dados['tecnico'] = array_chunk($this->dados['tecnico'], $ItemPorPagina);
		@$this->dados['tecnico'] = $this->dados['tecnico'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->view();
	}
	
	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$tecnico = new Tecnico();
		$exp = explode(",", $this->getParams(0));
		$tecnico->tecnico = $exp[0];
		$this->tecnico = $tecnico->tecnico;
		$this->ambiente = $exp[1];
		$apiTecnico = new apiTecnico();
		$this->dados = array('tecnico' => $apiTecnico->getTecnico($tecnico));
		$this->header = "Vincular Subcategoria ao T�cnico";
		if (isset($this->dados['tecnico'])){
			if ($this->dados['tecnico']->ATIVO == '0'){
				header('location:' .APP_ROOT. 'help/index/index/acessonegado');
				die();
			}
		}else{
			header('location:' .APP_ROOT. 'help/index/index/acessonegado');
			die();
		}
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		$apiTecempsubcategoria = new apiTecempsubcategoria();
		$vinculo = $apiTecempsubcategoria->vinculoTecnico($this->tecnico, $_SESSION['empresa_sessao']);
		if ((is_array($vinculo) ? count($vinculo) : 0) > 0) {
			foreach ($vinculo as $v){
				$vin[$v->SUBCATEGORIA] = true;
			}
			$this->vinculo = $vin;
		}
		$apiEmpresa = new apiEmpresa();
		$this->empresa = $apiEmpresa->filtroEmpresa('1','3','ativo', '1');
		$apiSubcategoria = new apiSubcategoria();
		$subcategoria = $apiSubcategoria->filtroSubcategoria('1','3','s.ativo', '1',$this->ambiente);
		foreach ($subcategoria as $rs){
			$this->subcategoria[$rs->CATEGORIA][$rs->SUBCATEGORIA] = array('subcategoria' => $rs->SUBCATEGORIA, 'des_subcategoria' => $rs->DES_SUBCATEGORIA);
			$this->categoria[$rs->CATEGORIA] = array('categoria' => $rs->CATEGORIA, 'des_categoria' => $rs->DES_CATEGORIA);
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$in = 0;
			$sql = array();
			$empresa = $_POST['empresa'];
			$tamanho_empresa = sizeof($empresa);
			$tecempsubcategoria = new Tecempsubcategoria();
			$tecempsubcategoria->tecnico = $this->tecnico;
			for($i=0;$i<$tamanho_empresa;$i++) {
				foreach ($this->categoria as $categoria){
					foreach ($this->subcategoria[$categoria['categoria']] as $rs){
						$tecempsubcategoria->empresa = $empresa[$i];
						$tecempsubcategoria->subcategoria = $rs['subcategoria'];
						$vinculo = $apiTecempsubcategoria->getTecempsubcategoria($tecempsubcategoria);
						if(isset($_POST[$rs['subcategoria']])) {
							if($vinculo == NULL){
								$sql[$in] = $apiTecempsubcategoria->addTecempsubcategoria($tecempsubcategoria);
								$in = $in+1;
							}
						}elseif(!isset($_POST[$rs['subcategoria']])){
							if($vinculo != NULL){
								$sql[$in] = $apiTecempsubcategoria->delTecempsubcategoria($tecempsubcategoria);
								$in = $in+1;
							}
						}
					}
				}
			}
			$v = $apiTecempsubcategoria->executeSQL($sql);
			if (isset($v[4])){
				if ($v[4] == 'sucesso'){
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'help/tecempsubcategoria/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'help/tecempsubcategoria/index/sucesso');
					}
				}
			}else{
				header('location:' .APP_ROOT. 'help/tecempsubcategoria/index/insucesso');
			}
		}
		$this->view();
	}
}