<?php

namespace controller\help;

use lib\Controller;
use helper\Security;
use api\help\apiTecnico;
use api\help\apiChamado;
use helper\Paginator;

class indexController extends Controller {
	
	public function __construct() {
		
		parent::__construct();
		
		new Security($this->getModule(),$this->getController(),$this->getAction());
	}
	
	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Notifica��es";
		if (isset($_SESSION["padrao_sessao"][$_SESSION['empresa_sessao']."0".$this->getModule()['modulo']."401"]) && !isset($_SESSION["colunas".$_SESSION['empresa_sessao']."0".$this->getModule()['modulo']."401"]['#'])){
			$val = $_SESSION["padrao_sessao"][$_SESSION['empresa_sessao']."0".$this->getModule()['modulo']."401"];
			$strVal = explode(';;', $val);
			foreach ($strVal as $rs){
				list($k, $v) = explode('||', $rs);
				$_SESSION["colunas".$_SESSION['empresa_sessao']."0".$this->getModule()['modulo']."401"][$k] = $v;
			}
		}
		$apiChamado = new apiChamado();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		unset($_SESSION['filtro_sessao']);
		unset($_SESSION['consulta_sessao']);
		$apiTecnico = new apiTecnico();
		$this->usuario = $apiTecnico->filtroTecnico('1', '3', 't.tecnico',$_SESSION['usuario_sessao'], 'tudo');
		if ((is_array($this->usuario) ? count($this->usuario) : 0) > 0) {
			$_SESSION['filtro_chamado'] = array('c' => 3, 'tecnico' => isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-2"]) ? $_SESSION['usuario_sessao'] : NULL, 'status' => 'tudo', 'ambiente' => $this->usuario[0]->AMBIENTE, 'coluna' => "", 'valor' => "", 'de' => "", 'ate' => "",  'filtro' => 1);
		}else{
			$_SESSION['filtro_chamado'] = array('c' => 3, 'solicitante' => $_SESSION['usuario_sessao'], 'status' => 'tudo', 'coluna' => "", 'valor' => "", 'de' => "", 'ate' => "", 'filtro' => 1);
		}
		$apiChamado = new apiChamado();
		$this->dados = array('chamado' => $apiChamado->notificacaoChamado($_SESSION['usuario_sessao']));
		$TotalItem = (is_array($this->dados['chamado']) ? count($this->dados['chamado']) : 0);
		$this->dados['chamado'] = array_chunk($this->dados['chamado'], $ItemPorPagina);
		@$this->dados['chamado'] = $this->dados['chamado'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->view();
	}
}