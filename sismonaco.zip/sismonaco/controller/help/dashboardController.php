<?php

namespace controller\help;

use lib\Controller;
use helper\Security;
use api\help\apiDashboard;
use api\help\apiAmbiente;
use api\help\apiTecnico;
use helper\Funcoes;

include 'classes/PHPExcel.php';

class dashboardController extends Controller {
	
	public function __construct() {
		
		parent::__construct();
		
		new Security($this->getModule(),$this->getController(),$this->getAction());
	}
	
	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Dashboard";
		$apiDashboard = new apiDashboard();
		$funcoes = new Funcoes();
        if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-16"])){
			$apiAmbiente = new apiAmbiente();
			$amb = $apiAmbiente->filtroAmbiente('1', '3', 'ativo', '1');
			foreach ($amb as $rs){
				$this->ambiente[$rs->AMBIENTE] = array('ambiente' => $rs->AMBIENTE, 'des_ambiente' => $rs->DES_AMBIENTE);
			}
        }else{
        	$apiTecnico = new apiTecnico();
        	$this->tecnico = $apiTecnico->filtroTecnico('1', '3', 't.tecnico', $_SESSION['usuario_sessao'],'tudo');
        	foreach ($this->tecnico as $rs){
        		$this->ambiente[$rs->AMBIENTE] = array('ambiente' => $rs->AMBIENTE, 'des_ambiente' => $rs->DES_AMBIENTE);
        	}
        }
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			if ($_POST['submeter'] == "gerar"){
				unset($_SESSION['filtro_dashboard']);
				unset($_SESSION['consulta_dashboard']);
				$ambiente = $_POST['ambiente'];
				$dashboard = $_POST['dashboard'];
				$ano = $_POST['ano'];
				$mes = $_POST['mes'];
				$data = "{$mes}/{$ano}";
				$this->dados = array('dashboard' => $apiDashboard->dashboard($ambiente,$dashboard,$data));
				$_SESSION['filtro_dashboard'] = array('ambiente' => $ambiente, 'dashboard' => $dashboard, 'ano' => $ano, 'mes' => $mes);
				$_SESSION['consulta_dashboard'] = $this->dados;
			}elseif ($_POST['submeter'] == "imprimir"){
				$this->dados = $_SESSION['consulta_dashboard'];
				$this->mes = ucfirst(strtolower(strftime('%B',strtotime("{$_SESSION['filtro_dashboard']['mes']}/01/{$_SESSION['filtro_dashboard']['ano']}"))));
				if ($_SESSION['filtro_dashboard']['dashboard'] == "produtividade"){
					$consolidado = $apiDashboard->getCapaconsolidado($_SESSION['filtro_dashboard']['ano'],$_SESSION['filtro_dashboard']['mes']);
					$projeto = $apiDashboard->getProjetos($_SESSION['filtro_dashboard']['ano'], $_SESSION['filtro_dashboard']['mes']);
					$mensal = $apiDashboard->getCapamesatual($_SESSION['filtro_dashboard']['ambiente'], $_SESSION['filtro_dashboard']['ano'], $_SESSION['filtro_dashboard']['mes']);
					$tecnico = $apiDashboard->getTecnicos($_SESSION['filtro_dashboard']['ambiente'], $_SESSION['filtro_dashboard']['ano'], $_SESSION['filtro_dashboard']['mes']);
					$categoria = $apiDashboard->getCategoria($_SESSION['filtro_dashboard']['ambiente'], $_SESSION['filtro_dashboard']['ano'], $_SESSION['filtro_dashboard']['mes']);
					$departamento = $apiDashboard->getDepartamento($_SESSION['filtro_dashboard']['ambiente'], $_SESSION['filtro_dashboard']['ano'], $_SESSION['filtro_dashboard']['mes']);
					$tipo = $apiDashboard->getTipo($_SESSION['filtro_dashboard']['ambiente'], $_SESSION['filtro_dashboard']['ano'], $_SESSION['filtro_dashboard']['mes']);
					
					$proj = array();
					foreach ($projeto as $p) {
						$proj[$p->TECNICO] = array('projeto' => $p->PROJETO);
					}
					
					$i = 0;
					$m = intval($_SESSION['filtro_dashboard']['mes']) - 1;
					// Create new PHPExcel obj
					$objPHPExcel = new \PHPExcel();
					
					$objPHPExcel->setActiveSheetIndex($i);
					
					$objPHPExcel->getActiveSheet()->getPageSetup()->setOrientation(\PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
					$objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(\PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
					$objPHPExcel->getActiveSheet()->setShowGridlines(true);
					$objPHPExcel->getActiveSheet()->getPageSetup()->setFitToPage(true);
					$objPHPExcel->getActiveSheet()->getSheetView()->setZoomScale(100);
					
					$objPHPExcel->getActiveSheet()->mergeCells('A1:V1');
					$objPHPExcel->getActiveSheet()->getStyle('A1:V1')->getFont()->setSize(12)->setName('Courier New')->setBold(true);
					$objPHPExcel->getActiveSheet()->mergeCells('A2:V2');
					$objPHPExcel->getActiveSheet()->getStyle('A2:V2')->getFont()->setSize(9)->setName('Courier New')->setBold(true)->getColor()->setRGB('FFFFFF');
					$objPHPExcel->getActiveSheet()->getStyle('A2:V2')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
					$styleArray = array('fill' => array('type' => \PHPExcel_Style_Fill::FILL_SOLID,'color' => array('rgb' => '99CC66')));
					$objPHPExcel->getActiveSheet()->getStyle("A2:V2")->applyFromArray($styleArray);
					$objPHPExcel->getActiveSheet()->mergeCells('A3:V3');
					$objPHPExcel->getActiveSheet()->getStyle('A4:M4')->getFont()->setSize(8)->setName('Courier New')->setBold(true)->getColor()->setRGB('FFFFFF');
					$objPHPExcel->getActiveSheet()->getStyle('A4')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
					$objPHPExcel->getActiveSheet()->getStyle('B4')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
					$objPHPExcel->getActiveSheet()->getStyle('C4')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
					$objPHPExcel->getActiveSheet()->getStyle('D4')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
					$objPHPExcel->getActiveSheet()->getStyle('E4')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
					$objPHPExcel->getActiveSheet()->getStyle('F4')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
					$objPHPExcel->getActiveSheet()->getStyle('G4')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
					$objPHPExcel->getActiveSheet()->getStyle('H4')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
					$objPHPExcel->getActiveSheet()->getStyle('I4')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
					$objPHPExcel->getActiveSheet()->getStyle('J4')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
					$objPHPExcel->getActiveSheet()->getStyle('K4')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
					$objPHPExcel->getActiveSheet()->getStyle('L4')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
					$objPHPExcel->getActiveSheet()->getStyle('M4')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
					$objPHPExcel->getActiveSheet()->getStyle('A5:M5')->getFont()->setSize(8)->setName('Courier New');
					$objPHPExcel->getActiveSheet()->getStyle('B5:M5')->getNumberFormat()->setFormatCode('0');
					$objPHPExcel->getActiveSheet()->getStyle('A6:M6')->getFont()->setSize(8)->setName('Courier New');
					$objPHPExcel->getActiveSheet()->getStyle('B6:M6')->getNumberFormat()->setFormatCode('0');
					$objPHPExcel->getActiveSheet()->getStyle('A7:M7')->getFont()->setSize(8)->setName('Courier New')->setBold(true)->getColor()->setRGB('0070C0');
					$objPHPExcel->getActiveSheet()->getStyle('B7:M7')->getNumberFormat()->setFormatCode('0');
					$objPHPExcel->getActiveSheet()->getStyle('A8:M8')->getFont()->setSize(8)->setName('Courier New')->setBold(true)->getColor()->setRGB('FF0000');
					$objPHPExcel->getActiveSheet()->getStyle('B8:M8')->getNumberFormat()->setFormatCode('0');
					$objPHPExcel->getActiveSheet()->mergeCells('N4:O8');
					$objPHPExcel->getActiveSheet()->mergeCells('P4:R6');
					$objPHPExcel->getActiveSheet()->mergeCells('P7:R7');
					$objPHPExcel->getActiveSheet()->mergeCells('P8:R8');
					$objPHPExcel->getActiveSheet()->getStyle('P4:R6')->getFont()->setSize(10)->setName('Comic Sans MS')->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('P4:R6')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER)->setWrapText(true);
					$objPHPExcel->getActiveSheet()->getStyle('P8:R8')->getFont()->setSize(10)->setName('Comic Sans MS')->getColor()->setRGB('C00000');
					$objPHPExcel->getActiveSheet()->getStyle('P8:R8')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER)->setWrapText(true);
					$objPHPExcel->getActiveSheet()->mergeCells('S4:S8');
					$objPHPExcel->getActiveSheet()->mergeCells('T4:V6');
					$objPHPExcel->getActiveSheet()->getStyle('T4:V6')->getFont()->setSize(10)->setName('Comic Sans MS')->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('T4:V6')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER)->setWrapText(true);
					$objPHPExcel->getActiveSheet()->getStyle('T8:V8')->getFont()->setSize(10)->setName('Comic Sans MS')->getColor()->setRGB('C00000');
					$objPHPExcel->getActiveSheet()->getStyle('T8:V8')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER)->setWrapText(true);
					$objPHPExcel->getActiveSheet()->mergeCells('T7:V7');
					$objPHPExcel->getActiveSheet()->mergeCells('T8:V8');
					$objPHPExcel->getActiveSheet()->mergeCells('A23:V23');
					$objPHPExcel->getActiveSheet()->getStyle('A23:V23')->getFont()->setSize(9)->setName('Courier New')->setBold(true)->getColor()->setRGB('FFFFFF');
					$objPHPExcel->getActiveSheet()->getStyle('A23:V23')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
					$styleArray = array('fill' => array('type' => \PHPExcel_Style_Fill::FILL_SOLID,'color' => array('rgb' => '99CC66')));
					$objPHPExcel->getActiveSheet()->getStyle("A42:V42")->applyFromArray($styleArray);
					$objPHPExcel->getActiveSheet()->mergeCells('A42:V42');
					$objPHPExcel->getActiveSheet()->getStyle('A42:V42')->getFont()->setSize(9)->setName('Courier New')->setBold(true)->getColor()->setRGB('FFFFFF');
					$objPHPExcel->getActiveSheet()->getStyle('A42:V42')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
					$styleArray = array('fill' => array('type' => \PHPExcel_Style_Fill::FILL_SOLID,'color' => array('rgb' => '99CC66')));
					$objPHPExcel->getActiveSheet()->getStyle("A42:V42")->applyFromArray($styleArray);
					$objPHPExcel->getActiveSheet()->getStyle('A44:M44')->getFont()->setSize(8)->setName('Courier New')->setBold(true)->getColor()->setRGB('FFFFFF');
					$objPHPExcel->getActiveSheet()->getStyle('B63:M63')->getFont()->setSize(8)->setName('Courier New')->setBold(true)->getColor()->setRGB('FFFFFF');
					$objPHPExcel->getActiveSheet()->getStyle('A45:M64')->getFont()->setSize(8)->setName('Courier New')->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('H45:J62')->getFont()->getColor()->setRGB('C00000');
					$objPHPExcel->getActiveSheet()->getStyle('A45:D47')->getFont()->getColor()->setRGB('0070C0');
					$objPHPExcel->getActiveSheet()->mergeCells('A43:V43');
					$objPHPExcel->getActiveSheet()->mergeCells('N44:O64');
					$objPHPExcel->getActiveSheet()->mergeCells('A64:M64');
					$objPHPExcel->getActiveSheet()->mergeCells('P44:V47');
					$objPHPExcel->getActiveSheet()->getStyle('P44:V47')->getFont()->setSize(10)->setName('Comic Sans MS')->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('P44:V47')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER)->setWrapText(true);
					
					$objPHPExcel->getActiveSheet()->getRowDimension(2)->setRowHeight(12.75);
					$objPHPExcel->getActiveSheet()->getRowDimension(3)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(4)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(5)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(6)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(7)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(8)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(9)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(10)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(11)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(12)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(13)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(14)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(15)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(16)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(17)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(18)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(19)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(20)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(21)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(22)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(23)->setRowHeight(12.75);
					$objPHPExcel->getActiveSheet()->getRowDimension(24)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(25)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(26)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(27)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(28)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(29)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(30)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(31)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(32)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(33)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(34)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(35)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(36)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(37)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(38)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(39)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(40)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(41)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(42)->setRowHeight(12.75);
					$objPHPExcel->getActiveSheet()->getRowDimension(43)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(44)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(45)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(46)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(47)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(48)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(49)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(50)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(51)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(52)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(53)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(54)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(55)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(56)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(57)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(58)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(59)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(60)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(61)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(62)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(63)->setRowHeight(11.25);
					$objPHPExcel->getActiveSheet()->getRowDimension(64)->setRowHeight(11.25);
				
					$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(26.40);
					$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(5);
					$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(5);
					$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(5);
					$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(5);
					$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(5);
					$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(5);
					$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(5);
					$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(5);
					$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(5);
					$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(5);
					$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(5);
					$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(5);
					$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(9.71);
					$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(9.71);
					$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(9.71);
					$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(9.71);
					$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(9.71);
					$objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth(9.71);
					$objPHPExcel->getActiveSheet()->getColumnDimension('T')->setWidth(9.71);
					$objPHPExcel->getActiveSheet()->getColumnDimension('U')->setWidth(9.71);
					$objPHPExcel->getActiveSheet()->getColumnDimension('V')->setWidth(9.71);
					
					$styleArray = array('fill' => array('type' => \PHPExcel_Style_Fill::FILL_SOLID,'color' => array('rgb' => '99CC66')));
					$objPHPExcel->getActiveSheet()->getStyle("A4:M4")->applyFromArray($styleArray);
					
					$styleArray = array('fill' => array('type' => \PHPExcel_Style_Fill::FILL_SOLID,'color' => array('rgb' => '99CC66')));
					$objPHPExcel->getActiveSheet()->getStyle("A2:V2")->applyFromArray($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A4:M8')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A2:V2')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN,'color' => array('rgb' => 'FFFFFF'))));
					$objPHPExcel->getActiveSheet()->getStyle('A4:A8')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN,'color' => array('rgb' => 'FFFFFF'))));
					$objPHPExcel->getActiveSheet()->getStyle('B4:B8')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN,'color' => array('rgb' => 'FFFFFF'))));
					$objPHPExcel->getActiveSheet()->getStyle('C4:C8')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN,'color' => array('rgb' => 'FFFFFF'))));
					$objPHPExcel->getActiveSheet()->getStyle('D4:D8')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN,'color' => array('rgb' => 'FFFFFF'))));
					$objPHPExcel->getActiveSheet()->getStyle('E4:E8')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN,'color' => array('rgb' => 'FFFFFF'))));
					$objPHPExcel->getActiveSheet()->getStyle('F4:F8')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN,'color' => array('rgb' => 'FFFFFF'))));
					$objPHPExcel->getActiveSheet()->getStyle('G4:G8')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN,'color' => array('rgb' => 'FFFFFF'))));
					$objPHPExcel->getActiveSheet()->getStyle('H4:H8')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN,'color' => array('rgb' => 'FFFFFF'))));
					$objPHPExcel->getActiveSheet()->getStyle('I4:I8')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN,'color' => array('rgb' => 'FFFFFF'))));
					$objPHPExcel->getActiveSheet()->getStyle('J4:J8')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN,'color' => array('rgb' => 'FFFFFF'))));
					$objPHPExcel->getActiveSheet()->getStyle('K4:K8')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN,'color' => array('rgb' => 'FFFFFF'))));
					$objPHPExcel->getActiveSheet()->getStyle('L4:L8')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('P4:R8')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('T4:V8')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('fill' => array('type' => \PHPExcel_Style_Fill::FILL_SOLID,'color' => array('rgb' => '99CC66')));
					$objPHPExcel->getActiveSheet()->getStyle("A23:V23")->applyFromArray($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A23:V23')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('fill' => array('type' => \PHPExcel_Style_Fill::FILL_SOLID,'color' => array('rgb' => '99CC66')));
					$objPHPExcel->getActiveSheet()->getStyle("A42:V42")->applyFromArray($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A42:V42')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A44:M63')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('bottom' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('B44:M44')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A45')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A46')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A47')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A48')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A49')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A50')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A51')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A52')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A53')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A54')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A55')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A56')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A57')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A58')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A59')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A60')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A61')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A62')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('bottom' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('B62:M62')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A63')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('fill' => array('type' => \PHPExcel_Style_Fill::FILL_SOLID,'color' => array('rgb' => 'FFFF00')));
					$objPHPExcel->getActiveSheet()->getStyle("P44:V47")->applyFromArray($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('P44:V47')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('fill' => array('type' => \PHPExcel_Style_Fill::FILL_SOLID,'color' => array('rgb' => '99CC66')));
					$objPHPExcel->getActiveSheet()->getStyle("A44:M44")->applyFromArray($styleArray);
					
					$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN,'color' => array('rgb' => 'FFFFFF'))));
					$objPHPExcel->getActiveSheet()->getStyle('A44')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN,'color' => array('rgb' => 'FFFFFF'))));
					$objPHPExcel->getActiveSheet()->getStyle('D44:D63')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN,'color' => array('rgb' => 'FFFFFF'))));
					$objPHPExcel->getActiveSheet()->getStyle('G44:G63')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN,'color' => array('rgb' => 'FFFFFF'))));
					$objPHPExcel->getActiveSheet()->getStyle('J44:J63')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('fill' => array('type' => \PHPExcel_Style_Fill::FILL_SOLID,'color' => array('rgb' => '99CC66')));
					$objPHPExcel->getActiveSheet()->getStyle("B63:M63")->applyFromArray($styleArray);
					
					$gdImage = imagecreatefromjpeg($_SERVER["DOCUMENT_ROOT"] . "/sismonaco/content/geral/img/logomonacom.jpg");
					$objDrawing = new \PHPExcel_Worksheet_MemoryDrawing();
					$objDrawing->setName('Monaco');
					$objDrawing->setDescription('Logo Monaco');
					$objDrawing->setImageResource($gdImage);
					$objDrawing->setRenderingFunction(\PHPExcel_Worksheet_MemoryDrawing::RENDERING_JPEG);
					$objDrawing->setMimeType(\PHPExcel_Worksheet_MemoryDrawing::MIMETYPE_JPEG);
					$objDrawing->setCoordinates('A1');
					$objDrawing->setOffsetX(2);
					$objDrawing->setOffsetY(2);
					$objDrawing->setResizeProportional(false);
					$objDrawing->setWidth(25);
					$objDrawing->setHeight(20);
					$objDrawing->setWorksheet($objPHPExcel->getActiveSheet());
					
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('A1', utf8_encode("   Grupo M�naco - Acompanhamento de Helpdesk ({$this->mes}/{$_SESSION['filtro_dashboard']['ano']})") );
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('A2', "RESUMO DO ATENDIMENTO" );
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('A4', utf8_encode("Descri��o"));
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('B4', "Jan");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('C4', "Fev");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('D4', "Mar");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('E4', "Abr");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('F4', "Mai");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('G4', "Jun");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H4', "Jul");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('I4', "Ago");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('J4', "Set");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('K4', "Out");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L4', "Nov");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('M4', "Dez");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('A5', utf8_encode("Chamados Abertos no M�s"));
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('A6', "Atendidos no Prazo");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('A7', "Aguardando atend.externo");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('A8', "Fora do Prazo");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('P4', utf8_encode("Tempo M�dio para In�cio de Atendimento"));
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('T4', utf8_encode("Tempo M�dio para Concluir o Chamado"));
					
					if(isset($consolidado[0]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('B5', $consolidado[0]->ABERTO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('B6', $consolidado[0]->NOPRAZO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('B7', $consolidado[0]->EXTERNO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('B8', $consolidado[0]->COMATRASO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 1){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('B5', $mensal[0]->ABERTO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('B6', $mensal[0]->NOPRAZO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('B7', $mensal[0]->EXTERNO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('B8', $mensal[0]->COMATRASO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}
					if(isset($consolidado[1]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('C5', $consolidado[1]->ABERTO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('C6', $consolidado[1]->NOPRAZO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('C7', $consolidado[1]->EXTERNO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('C8', $consolidado[1]->COMATRASO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 2){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('C5', $mensal[0]->ABERTO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('C6', $mensal[0]->NOPRAZO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('C7', $mensal[0]->EXTERNO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('C8', $mensal[0]->COMATRASO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}
					if(isset($consolidado[2]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('D5', $consolidado[2]->ABERTO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('D6', $consolidado[2]->NOPRAZO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('D7', $consolidado[2]->EXTERNO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('D8', $consolidado[2]->COMATRASO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 3){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('D5', $mensal[0]->ABERTO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('D6', $mensal[0]->NOPRAZO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('D7', $mensal[0]->EXTERNO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('D8', $mensal[0]->COMATRASO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}
					if(isset($consolidado[3]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('E5', $consolidado[3]->ABERTO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('E6', $consolidado[3]->NOPRAZO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('E7', $consolidado[3]->EXTERNO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('E8', $consolidado[3]->COMATRASO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 4){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('E5', $mensal[0]->ABERTO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('E6', $mensal[0]->NOPRAZO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('E7', $mensal[0]->EXTERNO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('E8', $mensal[0]->COMATRASO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}
					if(isset($consolidado[4]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('F5', $consolidado[4]->ABERTO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('F6', $consolidado[4]->NOPRAZO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('F7', $consolidado[4]->EXTERNO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('F8', $consolidado[4]->COMATRASO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 5){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('F5', $mensal[0]->ABERTO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('F6', $mensal[0]->NOPRAZO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('F7', $mensal[0]->EXTERNO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('F8', $mensal[0]->COMATRASO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}
					if(isset($consolidado[5]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('G5', $consolidado[5]->ABERTO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('G6', $consolidado[5]->NOPRAZO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('G7', $consolidado[5]->EXTERNO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('G8', $consolidado[5]->COMATRASO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 6){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('G5', $mensal[0]->ABERTO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('G6', $mensal[0]->NOPRAZO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('G7', $mensal[0]->EXTERNO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('G8', $mensal[0]->COMATRASO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}
					if(isset($consolidado[6]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H5', $consolidado[6]->ABERTO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H6', $consolidado[6]->NOPRAZO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H7', $consolidado[6]->EXTERNO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H8', $consolidado[6]->COMATRASO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 7){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H5', $mensal[0]->ABERTO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H6', $mensal[0]->NOPRAZO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H7', $mensal[0]->EXTERNO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H8', $mensal[0]->COMATRASO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}
					if(isset($consolidado[7]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('I5', $consolidado[7]->ABERTO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('I6', $consolidado[7]->NOPRAZO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('I7', $consolidado[7]->EXTERNO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('I8', $consolidado[7]->COMATRASO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 8){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('I5', $mensal[0]->ABERTO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('I6', $mensal[0]->NOPRAZO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('I7', $mensal[0]->EXTERNO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('I8', $mensal[0]->COMATRASO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}
					if(isset($consolidado[8]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('J5', $consolidado[8]->ABERTO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('J6', $consolidado[8]->NOPRAZO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('J7', $consolidado[8]->EXTERNO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('J8', $consolidado[8]->COMATRASO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 9){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('J5', $mensal[0]->ABERTO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('J6', $mensal[0]->NOPRAZO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('J7', $mensal[0]->EXTERNO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('J8', $mensal[0]->COMATRASO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}
					if(isset($consolidado[9]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('K5', $consolidado[9]->ABERTO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('K6', $consolidado[9]->NOPRAZO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('K7', $consolidado[9]->EXTERNO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('K8', $consolidado[9]->COMATRASO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 10){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('K5', $mensal[0]->ABERTO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('K6', $mensal[0]->NOPRAZO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('K7', $mensal[0]->EXTERNO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('K8', $mensal[0]->COMATRASO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}
					if(isset($consolidado[10]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L5', $consolidado[10]->ABERTO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L6', $consolidado[10]->NOPRAZO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L7', $consolidado[10]->EXTERNO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L8', $consolidado[10]->COMATRASO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 11){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L5', $mensal[0]->ABERTO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L6', $mensal[0]->NOPRAZO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L7', $mensal[0]->EXTERNO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L8', $mensal[0]->COMATRASO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}
					if(isset($consolidado[11]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('M5', $consolidado[11]->ABERTO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('M6', $consolidado[11]->NOPRAZO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('M7', $consolidado[11]->EXTERNO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('M8', $consolidado[11]->COMATRASO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 12){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('M5', $mensal[0]->ABERTO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('M6', $mensal[0]->NOPRAZO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('M7', $mensal[0]->EXTERNO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('M8', $mensal[0]->COMATRASO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}
					if (isset($consolidado[$m]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('P8', $consolidado[$m]->TEMPOINICIO);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('T8', $consolidado[$m]->TEMPOCONCLUSAO);
					}else{
						$ti = explode(",", $mensal[0]->TEMPOINICIO);
						$tih = $ti[0];
						$tim = $ti[1];
						if ($tim > 59){
							$tih = $tih + 1;
							$tim = $tim - 60;
						}
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('P8', "{$tih}h {$tim}min");
						
						$tc = explode(",", $mensal[0]->TEMPOCONCLUSAO);
						$tch = $tc[0];
						$tcm = $tc[1];
						if ($tcm > 59){
							$tch = $tch + 1;
							$tcm = $tcm - 60;
						}
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('T8', "{$tch}h {$tcm}min");
					}
					
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('A23', utf8_encode("CLASSIFICA��O DOS CHAMADOS"));
					
					//Label
					$lb1 = array(
						new \PHPExcel_Chart_DataSeriesValues('String', 'HDESKGRAFICO!$A$5', null, 12),
					);
					$lb2 = array(
						new \PHPExcel_Chart_DataSeriesValues('String', 'HDESKGRAFICO!$A$8', null, 12),
					);
					$lb3 = array(
						new \PHPExcel_Chart_DataSeriesValues('String', 'HDESKGRAFICO!$A$6', null, 12),
					);
					
					//Meses
					$xAxisTickValues= array(
						new \PHPExcel_Chart_DataSeriesValues('String', 'HDESKGRAFICO!$B$4:$M$4', null, 12),
					);
					
					//Valores
					$val1 = array(
						new \PHPExcel_Chart_DataSeriesValues('Number', 'HDESKGRAFICO!$B$5:$M$5', null, 12),
					);
					$val2 = array(
						new \PHPExcel_Chart_DataSeriesValues('Number', 'HDESKGRAFICO!$B$8:$M$8', null, 12),
					);
					$val3 = array(
						new \PHPExcel_Chart_DataSeriesValues('Number', 'HDESKGRAFICO!$B$6:$M$6', null, 12),
					);
		
					//Chart
					$ds = new \PHPExcel_Chart_DataSeries(
						\PHPExcel_Chart_DataSeries::TYPE_BARCHART,       // plotType
						\PHPExcel_Chart_DataSeries::GROUPING_CLUSTERED,  // plotGrouping
						array(0),                                        // plotOrder
						$lb1,                                            // plotLabel
						$xAxisTickValues,                                // plotCategory
						$val1                                            // plotValues
					);
					$ds->setPlotDirection(\PHPExcel_Chart_DataSeries::DIRECTION_COL);
					
					$ds2 = new \PHPExcel_Chart_DataSeries(
						\PHPExcel_Chart_DataSeries::TYPE_AREACHART,     // plotType
						\PHPExcel_Chart_DataSeries::GROUPING_STANDARD,  // plotGrouping
						array(0),                                       // plotOrder
						$lb2,                                           // plotLabel
						NULL,                                           // plotCategory
						$val2                                           // plotValues
					);
					
					$ds3 = new \PHPExcel_Chart_DataSeries(
						\PHPExcel_Chart_DataSeries::TYPE_LINECHART,     // plotType
						\PHPExcel_Chart_DataSeries::GROUPING_STANDARD,  // plotGrouping
						array(0),                                       // plotOrder
						$lb3,                                           // plotLabel
						NULL,                                           // plotCategory
						$val3                                           // plotValues
					);
					
					$layout = new \PHPExcel_Chart_Layout();
					$layout->setShowVal(true);
					$pa=new \PHPExcel_Chart_PlotArea($layout, array($ds,$ds2,$ds3));
					$title = new \PHPExcel_Chart_Title(utf8_encode('Chamados Abertos no Per�odo'));
					$legend=new \PHPExcel_Chart_Legend(\PHPExcel_Chart_Legend::POSITION_BOTTOM, NULL, false);
					
					$chart= new \PHPExcel_Chart(
						'Grafico1',
						$title,
						$legend,
						$pa,
						true,
						0,
						NULL,
						NULL
					);
					
					$chart->setTopLeftPosition('A9');
					$chart->setBottomRightPosition('M22',40,30);
					$objPHPExcel->getActiveSheet()->addChart($chart);
					
					$lb1 = array(
						new \PHPExcel_Chart_DataSeriesValues('String', 'HDESKTABELA!$H$13', null, 12),
					);
					
					$xAxisTickValues= array(
						new \PHPExcel_Chart_DataSeriesValues('String', 'HDESKTABELA!$E$14:$E$25', null, 12),
					);
					
					$val1 = array(
						new \PHPExcel_Chart_DataSeriesValues('Number', 'HDESKTABELA!$H$14:$H$25', null, 12),
					);
					
					$ds = new \PHPExcel_Chart_DataSeries(
						\PHPExcel_Chart_DataSeries::TYPE_BARCHART,       // plotType
						\PHPExcel_Chart_DataSeries::GROUPING_CLUSTERED,  // plotGrouping
						array(0),                                        // plotOrder
						$lb1,                                            // plotLabel
						$xAxisTickValues,                                // plotCategory
						$val1                                            // plotValues
					);
					$ds->setPlotDirection(\PHPExcel_Chart_DataSeries::DIRECTION_COL);
					
					$layout = new \PHPExcel_Chart_Layout();
					$layout->setShowVal(true);
					$pa=new \PHPExcel_Chart_PlotArea($layout, array($ds));
					$title = new \PHPExcel_Chart_Title(utf8_encode('Conclu�dos Aguardando Usu�rio'));
					$legend=new \PHPExcel_Chart_Legend(\PHPExcel_Chart_Legend::POSITION_BOTTOM, NULL, false);
					
					$chart= new \PHPExcel_Chart(
						'Grafico2',
						$title,
						$legend,
						$pa,
						true,
						0,
						NULL,
						NULL
					);
					
					$chart->setTopLeftPosition('P9');
					$chart->setBottomRightPosition('V22',67,30);
					$objPHPExcel->getActiveSheet()->addChart($chart);
					
					$lb1 = array(
						new \PHPExcel_Chart_DataSeriesValues('String', 'HDESKTABELA!$D$3', null, 6),
					);
					
					$xAxisTickValues= array(
						new \PHPExcel_Chart_DataSeriesValues('String', 'HDESKTABELA!$A$4:$A$9', null, 6),
					);
					
					$val1 = array(
						new \PHPExcel_Chart_DataSeriesValues('Number', 'HDESKTABELA!$D$4:$D$9', null, 6),
					);
					
					$ds = new \PHPExcel_Chart_DataSeries(
						\PHPExcel_Chart_DataSeries::TYPE_PIECHART_3D,       // plotType
						NULL,                                           // plotGrouping
						array(0),                                         // plotOrder
						$lb1,                                            // plotLabel
						$xAxisTickValues,                                // plotCategory
						$val1                                            // plotValues
					);
					$ds->setPlotDirection(\PHPExcel_Chart_DataSeries::DIRECTION_COL);
					
					$layout = new \PHPExcel_Chart_Layout();
					//$layout->setShowVal(true);
					$layout->setWidth(2);
					$layout->setHeight(2);
					//$layout->setLayoutTarget(2);
					//$layout->setShowSerName(true);
					//$layout->setShowLegendKey(true);
					$layout->setShowPercent(true);
					$pa=new \PHPExcel_Chart_PlotArea($layout, array($ds));
					$title = new \PHPExcel_Chart_Title(utf8_encode('Por Equipe'));
					$legend=new \PHPExcel_Chart_Legend(\PHPExcel_Chart_Legend::POSITION_BOTTOM, $layout, false);
					
					$chart= new \PHPExcel_Chart(
						'Grafico3',
						$title,
						$legend,
						$pa,
						true,
						0,
						NULL,
						NULL
					);
					
					$chart->setTopLeftPosition('A24');
					$chart->setBottomRightPosition('F41',67,30);
					$objPHPExcel->getActiveSheet()->addChart($chart);
					
					$lb1 = array(
						new \PHPExcel_Chart_DataSeriesValues('String', 'HDESKTABELA!$H$3', null, 5),
					);
					
					$xAxisTickValues= array(
						new \PHPExcel_Chart_DataSeriesValues('String', 'HDESKTABELA!$G$4:$G$8', null, 5),
					);
					
					$val1 = array(
						new \PHPExcel_Chart_DataSeriesValues('Number', 'HDESKTABELA!$H$4:$H$8', null, 6),
					);
					
					$ds = new \PHPExcel_Chart_DataSeries(
						\PHPExcel_Chart_DataSeries::TYPE_PIECHART_3D,       // plotType
						NULL,                                           // plotGrouping
						array(0),                                         // plotOrder
						$lb1,                                            // plotLabel
						$xAxisTickValues,                                // plotCategory
						$val1                                            // plotValues
					);
					$ds->setPlotDirection(\PHPExcel_Chart_DataSeries::DIRECTION_COL);
					
					$layout = new \PHPExcel_Chart_Layout();
					//$layout->setShowVal(true);
					$layout->setWidth(2);
					$layout->setHeight(2);
					//$layout->setLayoutTarget(2);
					//$layout->setShowSerName(true);
					//$layout->setShowLegendKey(true);
					$layout->setShowPercent(true);
					$pa=new \PHPExcel_Chart_PlotArea($layout, array($ds));
					$title = new \PHPExcel_Chart_Title(utf8_encode('Por Categoria'));
					$legend=new \PHPExcel_Chart_Legend(\PHPExcel_Chart_Legend::POSITION_BOTTOM, $layout, false);
					
					$chart= new \PHPExcel_Chart(
						'Grafico4',
						$title,
						$legend,
						$pa,
						true,
						0,
						NULL,
						NULL
					);
					
					$chart->setTopLeftPosition('G24');
					$chart->setBottomRightPosition('N41',67,30);
					$objPHPExcel->getActiveSheet()->addChart($chart);
					
					$lb1 = array(
						new \PHPExcel_Chart_DataSeriesValues('String', 'HDESKTABELA!$O$3', null, 5),
					);
					
					$xAxisTickValues= array(
						new \PHPExcel_Chart_DataSeriesValues('String', 'HDESKTABELA!$N$4:$N$9', null, 5),
					);
					
					$val1 = array(
						new \PHPExcel_Chart_DataSeriesValues('Number', 'HDESKTABELA!$O$4:$O$9', null, 6),
					);
					
					$ds = new \PHPExcel_Chart_DataSeries(
						\PHPExcel_Chart_DataSeries::TYPE_PIECHART_3D,       // plotType
						NULL,                                           // plotGrouping
						array(0),                                         // plotOrder
						$lb1,                                            // plotLabel
						$xAxisTickValues,                                // plotCategory
						$val1                                            // plotValues
					);
					$ds->setPlotDirection(\PHPExcel_Chart_DataSeries::DIRECTION_COL);
					
					$layout = new \PHPExcel_Chart_Layout();
					//$layout->setShowVal(true);
					$layout->setWidth(2);
					$layout->setHeight(2);
					//$layout->setLayoutTarget(2);
					//$layout->setShowSerName(true);
					//$layout->setShowLegendKey(true);
					$layout->setShowPercent(true);
					$pa=new \PHPExcel_Chart_PlotArea($layout, array($ds));
					$title = new \PHPExcel_Chart_Title(utf8_encode('Por Departamento'));
					$legend=new \PHPExcel_Chart_Legend(\PHPExcel_Chart_Legend::POSITION_BOTTOM, $layout, false);
					
					$chart= new \PHPExcel_Chart(
						'Grafico5',
						$title,
						$legend,
						$pa,
						true,
						0,
						NULL,
						NULL
					);
					
					$chart->setTopLeftPosition('O24');
					$chart->setBottomRightPosition('R41',67,30);
					$objPHPExcel->getActiveSheet()->addChart($chart);
					
					$lb1 = array(
						new \PHPExcel_Chart_DataSeriesValues('String', 'HDESKTABELA!$B$12', null, 4),
					);
					
					$xAxisTickValues= array(
						new \PHPExcel_Chart_DataSeriesValues('String', 'HDESKTABELA!$A$13:$A$16', null, 4),
					);
					
					$val1 = array(
						new \PHPExcel_Chart_DataSeriesValues('Number', 'HDESKTABELA!$B$13:$B$16', null, 4),
					);
					
					$ds = new \PHPExcel_Chart_DataSeries(
						\PHPExcel_Chart_DataSeries::TYPE_PIECHART_3D,       // plotType
						NULL,                                           // plotGrouping
						array(0),                                         // plotOrder
						$lb1,                                            // plotLabel
						$xAxisTickValues,                                // plotCategory
						$val1                                            // plotValues
					);
					$ds->setPlotDirection(\PHPExcel_Chart_DataSeries::DIRECTION_COL);
					
					$layout = new \PHPExcel_Chart_Layout();
					//$layout->setShowVal(true);
					$layout->setWidth(2);
					$layout->setHeight(2);
					//$layout->setLayoutTarget(2);
					//$layout->setShowSerName(true);
					//$layout->setShowLegendKey(true);
					$layout->setShowPercent(true);
					$pa=new \PHPExcel_Chart_PlotArea($layout, array($ds));
					$title = new \PHPExcel_Chart_Title(utf8_encode('Por Ocorr�ncia'));
					$legend=new \PHPExcel_Chart_Legend(\PHPExcel_Chart_Legend::POSITION_BOTTOM, $layout, false);
					
					$chart= new \PHPExcel_Chart(
						'Grafico6',
						$title,
						$legend,
						$pa,
						true,
						0,
						NULL,
						NULL
					);
					
					$chart->setTopLeftPosition('S24');
					$chart->setBottomRightPosition('V41',67,30);
					$objPHPExcel->getActiveSheet()->addChart($chart);
					
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('A42', utf8_encode("INDICADOR DE PRODUTIVIDADE DA TI"));
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('A44', "Profissional");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('B44', "Atend.");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('E44', "Projeto");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H44', "Atraso");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('K44', "Pontos");
					if (isset($consolidado[$m]->MES)){
						$perc = round(($consolidado[$m]->NOPRAZO * 100) / $consolidado[$m]->ABERTO,0);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('P44',  utf8_encode("Em {$this->mes} de {$_SESSION['filtro_dashboard']['ano']}, a produtividade foi de {$consolidado[$m]->ABERTO} Chamados abertos, sendo {$consolidado[$m]->NOPRAZO}({$perc}%) dos chamados atendidos no prazo."));
					}else{
						$perc = round(($mensal[0]->NOPRAZO * 100) / $mensal[0]->ABERTO,0);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('P44',  utf8_encode("Em {$this->mes} de {$_SESSION['filtro_dashboard']['ano']}, a produtividade foi de {$mensal[0]->ABERTO} Chamados abertos, sendo {$mensal[0]->NOPRAZO}({$perc}%) dos chamados atendidos no prazo."));
					}
					
					
					$local[1] = '(Diesel-PA)';
					$local[4] = '(Moto-PA)';
					$local[8] = '(Diesel-MT)';
					$local[13] = '(Diesel-PI)';
					$local[15] = '(Diesel-MA)';
					$local[19] = '(Moto-MT)';
					$local[27] = '(Moto-AP)';
					$local[35] = '(Fiat-PA)';
					$local[38] = '(Holding)';
					
					$t = 0;
					$it = 45;
					$grupotecnico = array();
					$tprazo = 0;
					$tatraso = 0;
					$ttotal = 0;
					foreach ($tecnico as $rs){
						$nome = explode(" ", $rs->NOME);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue("A{$it}", $nome[0]." ".$local[end($nome)]);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue("B{$it}", $rs->TOTAL,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$qtdproj = isset($proj[$rs->TECNICO]['projeto']) ? $proj[$rs->TECNICO]['projeto'] : 0;
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue("E{$it}", $qtdproj,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue("H{$it}", $rs->COMATRASO,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue("K{$it}", "=B{$it}*2+E{$it}*20-H{$it}*2",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						if ($t > 4){
							$tprazo = $tprazo + $rs->NOPRAZO;
							$tatraso = $tatraso + $rs->COMATRASO;
							$ttotal = $ttotal + $rs->TOTAL;
							$t = $t + 1;
						}else{
							$grupotecnico[$t] = array('nome' => $nome[0]." ".$local[end($nome)], 'noprazo' => $rs->NOPRAZO, 'comatraso' => $rs->COMATRASO, 'total' => $rs->TOTAL);
							$t = $t + 1;	
						}
						$it = $it + 1;
					}
					
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue("B63", "=SUBTOTAL(9,B45:B62)",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue("E63", "=SUBTOTAL(9,E45:E62)",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue("H63", "=SUBTOTAL(9,H45:H62)",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue("K63", "=SUBTOTAL(9,K45:K62)",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue("A64", "Pontos= Prazo*2 + Proj*20 - Atraso*2");
					
					//Label
					$lb1 = array(
						new \PHPExcel_Chart_DataSeriesValues('String', 'HDESKTABELA!$L$3', null, 12),
					);
					
					//Meses
					$xAxisTickValues= array(
						new \PHPExcel_Chart_DataSeriesValues('String', 'HDESKTABELA!$K$4:$K$15', null, 12),
					);
					
					//Valores
					$val1 = array(
						new \PHPExcel_Chart_DataSeriesValues('Number', 'HDESKTABELA!$L$4:$L$15', null, 12),
					);
					
					//Chart
					$ds = new \PHPExcel_Chart_DataSeries(
						\PHPExcel_Chart_DataSeries::TYPE_LINECHART,       // plotType
						\PHPExcel_Chart_DataSeries::GROUPING_STANDARD,  // plotGrouping
						array(0),                                        // plotOrder
						$lb1,                                            // plotLabel
						$xAxisTickValues,                                // plotCategory
						$val1                                            // plotValues
					);
					$ds->setPlotDirection(\PHPExcel_Chart_DataSeries::DIRECTION_COL);
					
					$layout = new \PHPExcel_Chart_Layout();
					$layout->setShowVal(true);
					$pa=new \PHPExcel_Chart_PlotArea($layout, array($ds));
					$title = new \PHPExcel_Chart_Title(utf8_encode('Indicador de Produtividade'));
					$legend=new \PHPExcel_Chart_Legend(\PHPExcel_Chart_Legend::POSITION_BOTTOM, NULL, false);
					
					$chart= new \PHPExcel_Chart(
						'Grafico1',
						$title,
						$legend,
						$pa,
						true,
						0,
						NULL,
						NULL
					);
					
					$chart->setTopLeftPosition('P48');
					$chart->setBottomRightPosition('V64',67,30);
					$objPHPExcel->getActiveSheet()->addChart($chart);
					
					$objPHPExcel->getActiveSheet()->setTitle("HDESKGRAFICO");
					
					$objPHPExcel->createSheet();
					$i = $i+1;
					
					$objPHPExcel->setActiveSheetIndex($i);
					
					$objPHPExcel->getActiveSheet()->getPageSetup()->setOrientation(\PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
					$objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(\PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
					$objPHPExcel->getActiveSheet()->setShowGridlines(true);
					$objPHPExcel->getActiveSheet()->getPageSetup()->setFitToPage(true);
					$objPHPExcel->getActiveSheet()->getSheetView()->setZoomScale(100);
					
					$objPHPExcel->getActiveSheet()->mergeCells('A1:P1');
					$objPHPExcel->getActiveSheet()->getStyle('A1:P1')->getFont()->setSize(9)->setName('Courier New')->setBold(true)->getColor()->setRGB('FFFF00');
					$objPHPExcel->getActiveSheet()->getStyle('A1:P1')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
					$styleArray = array('fill' => array('type' => \PHPExcel_Style_Fill::FILL_SOLID,'color' => array('rgb' => '000000')));
					$objPHPExcel->getActiveSheet()->getStyle("A1:P1")->applyFromArray($styleArray);
					$objPHPExcel->getActiveSheet()->mergeCells('K2:L2');
					$objPHPExcel->getActiveSheet()->getStyle('K2:L2')->getFont()->setSize(8)->setName('Courier New')->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('K2:L2')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
					$styleArray = array('fill' => array('type' => \PHPExcel_Style_Fill::FILL_SOLID,'color' => array('rgb' => 'D9D9D9')));
					$objPHPExcel->getActiveSheet()->getStyle("K2:L2")->applyFromArray($styleArray);
					$objPHPExcel->getActiveSheet()->getStyle('A3:E3')->getFont()->setSize(8)->setName('Courier New')->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('A3:E3')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
					$styleArray = array('fill' => array('type' => \PHPExcel_Style_Fill::FILL_SOLID,'color' => array('rgb' => 'D9D9D9')));
					$objPHPExcel->getActiveSheet()->getStyle("A3:E3")->applyFromArray($styleArray);
					$objPHPExcel->getActiveSheet()->getStyle('A4:E10')->getFont()->setSize(8)->setName('Courier New');
					$objPHPExcel->getActiveSheet()->getStyle('G3:I3')->getFont()->setSize(8)->setName('Courier New')->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('G3:I3')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
					$styleArray = array('fill' => array('type' => \PHPExcel_Style_Fill::FILL_SOLID,'color' => array('rgb' => 'D9D9D9')));
					$objPHPExcel->getActiveSheet()->getStyle("G3:I3")->applyFromArray($styleArray);
					$objPHPExcel->getActiveSheet()->getStyle('G4:I9')->getFont()->setSize(8)->setName('Courier New');
					$objPHPExcel->getActiveSheet()->getStyle('K3:L3')->getFont()->setSize(8)->setName('Courier New')->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('K3:L3')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
					$styleArray = array('fill' => array('type' => \PHPExcel_Style_Fill::FILL_SOLID,'color' => array('rgb' => 'D9D9D9')));
					$objPHPExcel->getActiveSheet()->getStyle("K3:L3")->applyFromArray($styleArray);
					$objPHPExcel->getActiveSheet()->getStyle('K4:L15')->getFont()->setSize(8)->setName('Courier New');
					$objPHPExcel->getActiveSheet()->getStyle('N3:P3')->getFont()->setSize(8)->setName('Courier New')->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('N3:P3')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
					$styleArray = array('fill' => array('type' => \PHPExcel_Style_Fill::FILL_SOLID,'color' => array('rgb' => 'D9D9D9')));
					$objPHPExcel->getActiveSheet()->getStyle("N3:P3")->applyFromArray($styleArray);
					$objPHPExcel->getActiveSheet()->getStyle('N4:P10')->getFont()->setSize(8)->setName('Courier New');
					$objPHPExcel->getActiveSheet()->getStyle('A12:C12')->getFont()->setSize(8)->setName('Courier New')->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('A12:C12')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
					$styleArray = array('fill' => array('type' => \PHPExcel_Style_Fill::FILL_SOLID,'color' => array('rgb' => 'D9D9D9')));
					$objPHPExcel->getActiveSheet()->getStyle("A12:C12")->applyFromArray($styleArray);
					$objPHPExcel->getActiveSheet()->getStyle('A13:C17')->getFont()->setSize(8)->setName('Courier New');
					$objPHPExcel->getActiveSheet()->mergeCells('E12:I12');
					$objPHPExcel->getActiveSheet()->getStyle('E12:I12')->getFont()->setSize(8)->setName('Courier New')->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('E12:I12')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
					$styleArray = array('fill' => array('type' => \PHPExcel_Style_Fill::FILL_SOLID,'color' => array('rgb' => 'D9D9D9')));
					$objPHPExcel->getActiveSheet()->getStyle("E12:I12")->applyFromArray($styleArray);
					$objPHPExcel->getActiveSheet()->getStyle('E13:I13')->getFont()->setSize(8)->setName('Courier New')->setBold(true);
					$objPHPExcel->getActiveSheet()->mergeCells('E13:G13');
					$objPHPExcel->getActiveSheet()->getStyle('E13:G13')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
					$objPHPExcel->getActiveSheet()->mergeCells('H13:I13');
					$objPHPExcel->getActiveSheet()->getStyle('H13:I13')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
					$styleArray = array('fill' => array('type' => \PHPExcel_Style_Fill::FILL_SOLID,'color' => array('rgb' => 'D9D9D9')));
					$objPHPExcel->getActiveSheet()->getStyle("E13:I13")->applyFromArray($styleArray);
					$objPHPExcel->getActiveSheet()->getStyle('E14:I25')->getFont()->setSize(8)->setName('Courier New');
					
					$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(29.60);
					$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(11.60);
					$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(9.10);
					$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(11.00);
					$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(8.00);
					$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(3.71);
					$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(19.30);
					$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(7.10);
					$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(8.00);
					$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(3.71);
					$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(5.30);
					$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(7.10);
					$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(3.71);
					$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(14.10);
					$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(10.30);
					$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(8.00);
					$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(29.60);
					$objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth(8.00);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('K2:L2')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A3:E9')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('G3:I3')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('K3:L3')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('N3:P3')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A4:E4')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A4:A10')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('G4:G9')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('H4:H9')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('K4:K15')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('N4:N10')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('O4:O10')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('B4:B10')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('C4:C10')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('D4:D10')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('G4:I4')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('K4:L4')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('N4:P4')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A5:E5')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('G5:I5')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('K5:L5')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('N5:P5')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A6:E6')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('G6:I6')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('K6:L6')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('N6:P6')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A7:E7')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('G7:I7')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('K7:L7')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('N7:P7')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A8:E8')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('G8:I8')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('K8:L8')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('N8:P8')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('G9:I9')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('K9:L9')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('N9:P9')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A10:E10')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('K10:L10')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('N10:P10')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('K11:L11')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A12:C12')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('E12:I12')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('K12:L12')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A13:C13')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A13:A17')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('B13:B17')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('E13:I13')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('K13:L13')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A14:C14')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('right' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('G14:G25')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('E14:I14')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('K14:L14')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A15:C15')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('E15:I15')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('K15:L15')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A16:C16')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('E16:I16')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('A17:C17')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('E17:I17')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('E18:I18')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('E19:I19')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('E20:I20')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('E21:I21')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('E22:I22')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('E23:I23')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('E24:I24')->applyFromArray($styleArray);
					unset($styleArray);
					
					$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
					$objPHPExcel->getActiveSheet()->getStyle('E25:I25')->applyFromArray($styleArray);
					unset($styleArray);
					
					
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('A1', utf8_encode("INFORMA��O   DEFINITIVA") );
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('K2', "Performance");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('A3', "TI");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('B3', "Noprazo");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('C3', "Atraso");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('D3', "Tot");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('E3', "%Perc");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('G3', "Categoria");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H3', "Tot");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('I3', "%Perc");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('K3', utf8_encode("M�s"));
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L3', "Pontos");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('N3', "Depto");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('O3', "Tot");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('P3', "%Perc");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('A12', "Ocorrencia");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('B12', "Qtd");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('C12', "%Perc");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('E12', utf8_encode("Sem feedback do Usu�rio"));
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('E13', utf8_encode("M�s"));
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H13', "Chamados");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('A10', "Total");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('G9', "Total");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('K4', "Jan");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('K5', "Fev");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('K6', "Mar");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('K7', "Abr");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('K8', "Mai");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('K9', "Jun");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('K10', "Jul");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('K11', "Ago");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('K12', "Set");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('K13', "Out");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('K14', "Nov");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('K15', "Dez");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('N10', "Total");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('A13', utf8_encode("Solicita��o de Servi�o"));
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('A14', utf8_encode("Falha do Usu�rio"));
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('A15', utf8_encode("Incidente/Erro"));
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('A16', utf8_encode("Necessidade de Informa��o"));
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('A17', "Total");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('E14', "Jan");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('E15', "Fev");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('E16', "Mar");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('E17', "Abr");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('E18', "Mai");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('E19', "Jun");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('E20', "Jul");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('E21', "Ago");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('E22', "Set");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('E23', "Out");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('E24', "Nov");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('E25', "Dez");
						
					
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('A4', $grupotecnico[0]['nome']);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('B4', $grupotecnico[0]['noprazo'],\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('C4', $grupotecnico[0]['comatraso'],\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('D4', $grupotecnico[0]['total'],\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('E4', "=D4/D10",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
	
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('A5', $grupotecnico[1]['nome']);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('B5', $grupotecnico[1]['noprazo'],\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('C5', $grupotecnico[1]['comatraso'],\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('D5', $grupotecnico[1]['total'],\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('E5', "=D5/D10",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('A6', $grupotecnico[2]['nome']);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('B6', $grupotecnico[2]['noprazo'],\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('C6', $grupotecnico[2]['comatraso'],\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('D6', $grupotecnico[2]['total'],\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('E6', "=D6/D10",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('A7', $grupotecnico[3]['nome']);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('B7', $grupotecnico[3]['noprazo'],\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('C7', $grupotecnico[3]['comatraso'],\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('D7', $grupotecnico[3]['total'],\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('E7', "=D7/D10",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('A8', $grupotecnico[4]['nome']);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('B8', $grupotecnico[4]['noprazo'],\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('C8', $grupotecnico[4]['comatraso'],\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('D8', $grupotecnico[4]['total'],\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('E8', "=D8/D10",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('A9', "Outros");
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('B9', $tprazo,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('C9', $tatraso,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('D9', $ttotal,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('E9', "=D9/D10",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue("B10", "=SUBTOTAL(9,B4:B9)",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue("C10", "=SUBTOTAL(9,C4:C9)",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue("D10", "=SUBTOTAL(9,D4:D9)",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue("E10", "=SUBTOTAL(9,E4:E9)",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->getActiveSheet()->getStyle("E4:E10")->getNumberFormat()->setFormatCode('00%');
					
					$cat = explode("(", $categoria[0]->CATEGORIA);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('G4', ucfirst(strtolower($cat[0])));
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H4', $categoria[0]->QTD,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('I4', "=H4/H9",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$cat = explode("(", $categoria[1]->CATEGORIA);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('G5', ucfirst(strtolower($cat[0])));
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H5', $categoria[1]->QTD,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('I5', "=H5/H9",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$cat = explode("(", $categoria[2]->CATEGORIA);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('G6', ucfirst(strtolower($cat[0])));
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H6', $categoria[2]->QTD,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('I6', "=H6/H9",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$cat = explode("(", $categoria[3]->CATEGORIA);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('G7', ucfirst(strtolower($cat[0])));
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H7', $categoria[3]->QTD,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('I7', "=H7/H9",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$cat = explode("(", $categoria[4]->CATEGORIA);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('G8', ucfirst(strtolower($cat[0])));
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H8', $categoria[4]->QTD,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('I8', "=H8/H9",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue("H9", "=SUBTOTAL(9,H4:H8)",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue("I9", "=SUBTOTAL(9,I4:I8)",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->getActiveSheet()->getStyle("I4:I9")->getNumberFormat()->setFormatCode('00%');
					
					if(isset($consolidado[0]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L4', $consolidado[0]->PONTOS,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 1){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L4', "=HDESKGRAFICO!K63");
					}
					if(isset($consolidado[1]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L5', $consolidado[1]->PONTOS,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 2){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L5', "=HDESKGRAFICO!K63");
					}if(isset($consolidado[2]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L6', $consolidado[2]->PONTOS,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 3){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L6', "=HDESKGRAFICO!K63");
					}
					if(isset($consolidado[3]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L7', $consolidado[3]->PONTOS,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 4){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L7', "=HDESKGRAFICO!K63");
					}
					if(isset($consolidado[4]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L8', $consolidado[4]->PONTOS,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 5){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L8', "=HDESKGRAFICO!K63");
					}
					if(isset($consolidado[5]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L9', $consolidado[5]->PONTOS,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 6){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L9', "=HDESKGRAFICO!K63");
					}
					if(isset($consolidado[6]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L10', $consolidado[6]->PONTOS,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 7){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L10', "=HDESKGRAFICO!K63");
					}
					if(isset($consolidado[7]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L11', $consolidado[7]->PONTOS,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 8){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L11', "=HDESKGRAFICO!K63");
					}
					if(isset($consolidado[8]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L12', $consolidado[8]->PONTOS,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 9){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L12', "=HDESKGRAFICO!K63");
					}
					if(isset($consolidado[9]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L13', $consolidado[9]->PONTOS,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 10){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L13', "=HDESKGRAFICO!K63");
					}
					if(isset($consolidado[10]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L14', $consolidado[10]->PONTOS,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 11){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L14', "=HDESKGRAFICO!K63");
					}
					if(isset($consolidado[11]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L15', $consolidado[11]->PONTOS,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 12){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('L15', "=HDESKGRAFICO!K63");
					}
					
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('N4', ucfirst(strtolower($departamento[0]->DEPARTAMENTO)));
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('O4', $departamento[0]->QTD,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('P4', "=O4/O10",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('N5', ucfirst(strtolower($departamento[1]->DEPARTAMENTO)));
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('O5', $departamento[1]->QTD,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('P5', "=O5/O10",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('N6', ucfirst(strtolower($departamento[2]->DEPARTAMENTO)));
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('O6', $departamento[2]->QTD,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('P6', "=O6/O10",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('N7', ucfirst(strtolower($departamento[3]->DEPARTAMENTO)));
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('O7', $departamento[3]->QTD,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('P7', "=O7/O10",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('N8', ucfirst(strtolower($departamento[4]->DEPARTAMENTO)));
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('O8', $departamento[4]->QTD,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('P8', "=O8/O10",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('N9', ucfirst(strtolower($departamento[5]->DEPARTAMENTO)));
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('O9', $departamento[5]->QTD,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('P9', "=O9/O10",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue("O10", "=SUBTOTAL(9,O4:O9)",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue("P10", "=SUBTOTAL(9,P4:P9)",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->getActiveSheet()->getStyle("P4:P10")->getNumberFormat()->setFormatCode('00%');
					
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('B13', $tipo[1]->QTD,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('C13', "=B13/B17",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('B14', $tipo[3]->QTD,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('C14', "=B14/B17",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('B15', $tipo[0]->QTD,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('C15', "=B15/B17",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('B16', $tipo[2]->QTD,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue('C16', "=B16/B17",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue("B17", "=SUBTOTAL(9,B13:B16)",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->setActiveSheetIndex($i)->setCellValue("C17", "=SUBTOTAL(9,C13:C16)",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->getActiveSheet()->getStyle("C13:C17")->getNumberFormat()->setFormatCode('00%');

					if(isset($consolidado[0]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H14', $consolidado[0]->SEMFEEDBACK,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 1){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H14', $mensal[0]->SEMFEEDBACK,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}
					if(isset($consolidado[1]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H15', $consolidado[1]->SEMFEEDBACK,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 2){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H15', $mensal[0]->SEMFEEDBACK,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}
					if(isset($consolidado[2]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H16', $consolidado[2]->SEMFEEDBACK,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 3){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H16', $mensal[0]->SEMFEEDBACK,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}
					if(isset($consolidado[3]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H17', $consolidado[3]->SEMFEEDBACK,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 4){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H17', $mensal[0]->SEMFEEDBACK,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}
					if(isset($consolidado[4]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H18', $consolidado[4]->SEMFEEDBACK,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 5){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H18', $mensal[0]->SEMFEEDBACK,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}
					if(isset($consolidado[5]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H19', $consolidado[5]->SEMFEEDBACK,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 6){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H19', $mensal[0]->SEMFEEDBACK,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}
					if(isset($consolidado[6]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H20', $consolidado[6]->SEMFEEDBACK,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 7){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H20', $mensal[0]->SEMFEEDBACK,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}
					if(isset($consolidado[7]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H21', $consolidado[7]->SEMFEEDBACK,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 8){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H21', $mensal[0]->SEMFEEDBACK,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}
					if(isset($consolidado[8]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H22', $consolidado[8]->SEMFEEDBACK,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 9){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H22', $mensal[0]->SEMFEEDBACK,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}
					if(isset($consolidado[9]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H23', $consolidado[9]->SEMFEEDBACK,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 10){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H23', $mensal[0]->SEMFEEDBACK,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}
					if(isset($consolidado[10]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H24', $consolidado[10]->SEMFEEDBACK,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 11){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H24', $mensal[0]->SEMFEEDBACK,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}
					if(isset($consolidado[11]->MES)){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H25', $consolidado[11]->SEMFEEDBACK,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}elseif ($mensal[0]->MES == 12){
						$objPHPExcel->setActiveSheetIndex($i)->setCellValue('H25', $mensal[0]->SEMFEEDBACK,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					}
					
					
					$objPHPExcel->getActiveSheet()->setTitle("HDESKTABELA");
					
					$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
					$objWriter->setIncludeCharts(true);
			
					$nome_arquivo = "HELPDESK-{$_SESSION['filtro_dashboard']['mes']}-{$_SESSION['filtro_dashboard']['ano']}-".date('d-m-Y').".xlsx";
					header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
					header("Content-Disposition: attachment;filename={$nome_arquivo}");
					header("Pragma: no-cache");
					header("Expires: 0");
					
					ob_end_clean();
					$objWriter->save('php://output');
					exit;
				}elseif($_SESSION['filtro_dashboard']['dashboard'] == "atraso"){
					$i = 0;
					$objPHPExcel = new \PHPExcel();
					
					$objPHPExcel->getActiveSheet()->getPageSetup()->setOrientation(\PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
					$objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(\PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
					$objPHPExcel->getActiveSheet()->setShowGridlines(true);
					$objPHPExcel->getActiveSheet()->getPageSetup()->setFitToPage(true);
					$objPHPExcel->getActiveSheet()->getSheetView()->setZoomScale(80);
					
					$objPHPExcel->getActiveSheet()->mergeCells('A1:I1');
					$objPHPExcel->getActiveSheet()->getStyle('A1:I1')->getFont()->setSize(18)->setName('Courier New')->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('A2:I2')->getFont()->setSize(16)->setName('Courier New')->setBold(true);
					
					
					$objPHPExcel->setActiveSheetIndex(0);
					$objPHPExcel->getActiveSheet()->setCellValue("A2", "Empresa" )
					->setCellValue("B2", "Chamado" )
					->setCellValue("C2", "Abertura")
					->setCellValue("D2", "Vencimento")
					->setCellValue("E2", "Assunto")
					->setCellValue("F2",  utf8_encode("T�cnico"))
					->setCellValue("G2", "Solicitante")
					->setCellValue("H2", "Subcategoria")
					->setCellValue("I2", "Status" );
					
					$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(60);
					$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(15);
					$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(33);
					$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(33);
					$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(70);
					$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(54);
					$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(54);
					$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(35);
					$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(40);
					
					$gdImage = imagecreatefromjpeg($_SERVER["DOCUMENT_ROOT"] . "/sismonaco/content/geral/img/logomonacom.jpg");
					$objDrawing = new \PHPExcel_Worksheet_MemoryDrawing();
					$objDrawing->setName('Monaco');
					$objDrawing->setDescription('Logo Monaco');
					$objDrawing->setImageResource($gdImage);
					$objDrawing->setRenderingFunction(\PHPExcel_Worksheet_MemoryDrawing::RENDERING_JPEG);
					$objDrawing->setMimeType(\PHPExcel_Worksheet_MemoryDrawing::MIMETYPE_JPEG);
					$objDrawing->setCoordinates('A1');
					$objDrawing->setOffsetX(2);
					$objDrawing->setOffsetY(2);
					$objDrawing->setResizeProportional(false);
					$objDrawing->setWidth(25);
					$objDrawing->setHeight(20);
					$objDrawing->setWorksheet($objPHPExcel->getActiveSheet());
					
					$objPHPExcel->setActiveSheetIndex()->setCellValue('A1', utf8_encode("   Grupo M�naco - Chamados Em Atraso No M�s De {$this->mes} Do Ano {$_SESSION['filtro_dashboard']['ano']}") );
					$i = 2;
					foreach ($this->dados['dashboard'] as $rs){
						$i = $i + 1;
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, utf8_encode("".ucfirst(strtolower($rs->EMPRESA)).""));
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->CHAMADO);
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->DTA_ABERTURA);
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->DTA_VENCIMENTO);
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, utf8_encode("".ucfirst(strtolower($rs->ASSUNTO)).""));
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, utf8_encode("".ucfirst(strtolower($rs->TECNICO)).""));
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, utf8_encode("".ucfirst(strtolower($rs->SOLICITANTE)).""));
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, utf8_encode("".ucfirst(strtolower($rs->SUBCATEGORIA)).""));
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, utf8_encode("".ucfirst(strtolower($rs->STATUS)).""));
					}
					$objPHPExcel->getActiveSheet()->getStyle("A3:F{$i}")->getFont()->setSize(14)->setName('Courier New');
					
					$objPHPExcel->getActiveSheet()->setTitle( utf8_encode("Chamados em Atraso"));
					
					$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
					$nome_arquivo = "ATRASO-".date('d-m-Y').".xls";
					header('Content-Type: application/vnd.ms-excel');
					header("Content-Disposition: attachment;filename={$nome_arquivo}");
					header("Pragma: no-cache");
					header("Expires: 0");
					
					ob_end_clean();
					$objWriter->save('php://output');
				
				}elseif($_SESSION['filtro_dashboard']['dashboard'] == "externo"){
					$i = 0;
					$objPHPExcel = new \PHPExcel();
					
					$objPHPExcel->getActiveSheet()->getPageSetup()->setOrientation(\PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
					$objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(\PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
					$objPHPExcel->getActiveSheet()->setShowGridlines(true);
					$objPHPExcel->getActiveSheet()->getPageSetup()->setFitToPage(true);
					$objPHPExcel->getActiveSheet()->getSheetView()->setZoomScale(80);
					
					$objPHPExcel->getActiveSheet()->mergeCells('A1:K1');
					$objPHPExcel->getActiveSheet()->getStyle('A1:K1')->getFont()->setSize(18)->setName('Courier New')->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('A2:K2')->getFont()->setSize(16)->setName('Courier New')->setBold(true);
					
					
					$objPHPExcel->setActiveSheetIndex(0);
					$objPHPExcel->getActiveSheet()->setCellValue("A2", "Empresa" )
					->setCellValue("B2", "Chamado" )
					->setCellValue("C2", "Abertura")
					->setCellValue("D2", utf8_encode("Previs�o"))
					->setCellValue("E2", "Chamado Externo")
					->setCellValue("F2", "Chamado DVI")
					->setCellValue("G2", "Cod Empresa")
					->setCellValue("H2", "Assunto")
					->setCellValue("I2", "Criador")
					->setCellValue("J2", utf8_encode("T�cnico") )
					->setCellValue("K2", "Categoria" );
					
					$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(50);
					$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(15);
					$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(20);
					$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(20);
					$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(25);
					$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(25);
					$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(25);
					$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(50);
					$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(40);
					$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(40);
					$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(30);
					
					$gdImage = imagecreatefromjpeg($_SERVER["DOCUMENT_ROOT"] . "/sismonaco/content/geral/img/logomonacom.jpg");
					$objDrawing = new \PHPExcel_Worksheet_MemoryDrawing();
					$objDrawing->setName('Monaco');
					$objDrawing->setDescription('Logo Monaco');
					$objDrawing->setImageResource($gdImage);
					$objDrawing->setRenderingFunction(\PHPExcel_Worksheet_MemoryDrawing::RENDERING_JPEG);
					$objDrawing->setMimeType(\PHPExcel_Worksheet_MemoryDrawing::MIMETYPE_JPEG);
					$objDrawing->setCoordinates('A1');
					$objDrawing->setOffsetX(2);
					$objDrawing->setOffsetY(2);
					$objDrawing->setResizeProportional(false);
					$objDrawing->setWidth(25);
					$objDrawing->setHeight(20);
					$objDrawing->setWorksheet($objPHPExcel->getActiveSheet());
					
					$objPHPExcel->setActiveSheetIndex()->setCellValue('A1', utf8_encode("   Grupo M�naco - Chamados Em Externo No M�s De {$this->mes} Do Ano {$_SESSION['filtro_dashboard']['ano']}") );
					$i = 2;
					foreach ($this->dados['dashboard'] as $rs){
						$i = $i + 1;
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, utf8_encode("".ucfirst(strtolower($rs->EMPRESA)).""));
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->CHAMADO);
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->DTA_EXTERNO);
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->PREVISAO_EXTERNO);
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->CHAMADO_EXTERNO);
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->CHAMADO_DVI);
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, utf8_encode("{$rs->COD_EMPRESA}"));
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, utf8_encode("".ucfirst(strtolower($rs->ASSUNTO)).""));
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, utf8_encode("".ucfirst(strtolower($rs->CRIADOR)).""));
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, utf8_encode("".ucfirst(strtolower($rs->TECNICO)).""));
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, utf8_encode("".ucfirst(strtolower($rs->CATEGORIA)).""));
					}
					$objPHPExcel->getActiveSheet()->getStyle("A3:F{$i}")->getFont()->setSize(14)->setName('Courier New');
					
					$objPHPExcel->getActiveSheet()->setTitle( utf8_encode("Chamados em Externo"));
					
					$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
					$nome_arquivo = "EXTERNO-".date('d-m-Y').".xls";
					header('Content-Type: application/vnd.ms-excel');
					header("Content-Disposition: attachment;filename={$nome_arquivo}");
					header("Pragma: no-cache");
					header("Expires: 0");
					
					ob_end_clean();
					$objWriter->save('php://output');
					
				}elseif($_SESSION['filtro_dashboard']['dashboard'] == "analitico"){
					$i = 0;
					$objPHPExcel = new \PHPExcel();
					
					$objPHPExcel->getActiveSheet()->getPageSetup()->setOrientation(\PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
					$objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(\PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
					$objPHPExcel->getActiveSheet()->setShowGridlines(true);
					$objPHPExcel->getActiveSheet()->getPageSetup()->setFitToPage(true);
					$objPHPExcel->getActiveSheet()->getSheetView()->setZoomScale(80);
					
					$objPHPExcel->getActiveSheet()->mergeCells('A1:S1');
					$objPHPExcel->getActiveSheet()->getStyle('A1:S1')->getFont()->setSize(18)->setName('Courier New')->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('A2:S2')->getFont()->setSize(16)->setName('Courier New')->setBold(true);
					
					
					$objPHPExcel->setActiveSheetIndex(0);
					$objPHPExcel->getActiveSheet()->setCellValue("A2", "Chamado" )
					->setCellValue("B2", "Empresa" )
					->setCellValue("C2", "Assunto")
					->setCellValue("D2", "Criador")
					->setCellValue("E2", utf8_encode("T�cnico"))
					->setCellValue("F2", "Categoria")
					->setCellValue("G2", "Subcategoria")
					->setCellValue("H2", "Departamento")
					->setCellValue("I2", utf8_encode("Ocorr�ncia"))
					->setCellValue("J2", "Status" )
					->setCellValue("K2", "Abertura" )
					->setCellValue("L2", "Primeiro_movimento" )
					->setCellValue("M2", "Vencimento" )
					->setCellValue("N2", "Tempo_Atendimento" )
					->setCellValue("O2", "Tempo_Aguardando" )
					->setCellValue("P2", "Tempo_Outros" )
					->setCellValue("Q2", "Tempo_Subcategoria" )
					->setCellValue("R2", "Fechamento" )
					->setCellValue("S2", "Prazo" );
					
					$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(15);
					$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(65);
					$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(65);
					$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(56);
					$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(56);
					$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(78);
					$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(35);
					$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(30);
					$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(27);
					$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(33);
					$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(19);
					$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(31);
					$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(19);
					$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(30);
					$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(30);
					$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(30);
					$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(30);
					$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(19);
					$objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth(20);
					
					$gdImage = imagecreatefromjpeg($_SERVER["DOCUMENT_ROOT"] . "/sismonaco/content/geral/img/logomonacom.jpg");
					$objDrawing = new \PHPExcel_Worksheet_MemoryDrawing();
					$objDrawing->setName('Monaco');
					$objDrawing->setDescription('Logo Monaco');
					$objDrawing->setImageResource($gdImage);
					$objDrawing->setRenderingFunction(\PHPExcel_Worksheet_MemoryDrawing::RENDERING_JPEG);
					$objDrawing->setMimeType(\PHPExcel_Worksheet_MemoryDrawing::MIMETYPE_JPEG);
					$objDrawing->setCoordinates('A1');
					$objDrawing->setOffsetX(2);
					$objDrawing->setOffsetY(2);
					$objDrawing->setResizeProportional(false);
					$objDrawing->setWidth(25);
					$objDrawing->setHeight(20);
					$objDrawing->setWorksheet($objPHPExcel->getActiveSheet());
					
					$objPHPExcel->setActiveSheetIndex()->setCellValue('A1', utf8_encode("   Grupo M�naco - Chamados Anal�tico No M�s De {$this->mes} Do Ano {$_SESSION['filtro_dashboard']['ano']}") );
					$i = 2;
					foreach ($this->dados['dashboard'] as $rs){
						$i = $i + 1;
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->CHAMADO);
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, utf8_encode("".ucfirst(strtolower($rs->EMPRESA)).""));
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, utf8_encode("".ucfirst(strtolower($rs->ASSUNTO)).""));
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, utf8_encode("".ucfirst(strtolower($rs->CRIADOR)).""));
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, utf8_encode("".ucfirst(strtolower($rs->TECNICO)).""));
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, utf8_encode("".ucfirst(strtolower($rs->CATEGORIA)).""));
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, utf8_encode("".ucfirst(strtolower($rs->SUBCATEGORIA)).""));
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, utf8_encode("".ucfirst(strtolower($rs->DEPARTAMENTO)).""));
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, utf8_encode("".ucfirst(strtolower($rs->OCORRENCIA)).""));
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, utf8_encode("".ucfirst(strtolower($rs->DES_STATUS)).""));
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, $rs->DTA_ABERTURA);
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $i, $rs->PRIMEIRO_MOVIMENTO);
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $i, $rs->DTA_VENCIMENTO);
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $i, $rs->TEMPO_ATENDIMENTO);
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $i, $rs->TEMPO_AGUARDANDO);
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(15, $i, $rs->TEMPO_OUTROS);
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(16, $i, $rs->TEMPO_SUBCATEGORIA);
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(17, $i, $rs->DTA_FECHAMENTO);
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(18, $i, $rs->PRAZO);
					}
					$objPHPExcel->getActiveSheet()->getStyle("A3:F{$i}")->getFont()->setSize(14)->setName('Courier New');
					
					$objPHPExcel->getActiveSheet()->setTitle( utf8_encode("Chamados Anal�tico"));
					
					$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
					$nome_arquivo = "ANALITICO-".date('d-m-Y').".xls";
					header('Content-Type: application/vnd.ms-excel');
					header("Content-Disposition: attachment;filename={$nome_arquivo}");
					header("Pragma: no-cache");
					header("Expires: 0");
					
					ob_end_clean();
					$objWriter->save('php://output');
				}
				
			}
		}else{
			if(isset($_SESSION['filtro_dashboard']['dashboard'])){
				$data = $_SESSION['filtro_dashboard']['mes']."/".$_SESSION['filtro_dashboard']['ano'];
				$this->dados = array('dashboard' => $apiDashboard->dashboard($_SESSION['filtro_dashboard']['ambiente'],$_SESSION['filtro_dashboard']['dashboard'],$data));
			}
		}
		
		$this->view();
	}
}