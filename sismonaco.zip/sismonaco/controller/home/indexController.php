<?php

namespace controller\home;

use lib\Controller;
use helper\Security;
use api\adm\apiPermissao;
use obj\adm\Permissao;
use helper\Funcoes;
use obj\adm\Usuario;
use api\adm\apiUsuario;
use api\home\apiSorteio;
use obj\home\Sorteio;
use obj\home\Codigo;

class indexController extends Controller {
	
	public function __construct(){
		
		parent::__construct();
		
		if (!isset($_SESSION['usuario_sessao']) || empty($_SESSION['usuario_sessao'])) {
			
			new Security($this->getModule(),$this->getController(),$this->getAction());
			
		}else {
			
			if (isset($_SESSION['tempo_sessao'])) {
				
				$duracao_sessao = 1800;
				
				if(((time() - $_SESSION['tempo_sessao']) > $duracao_sessao)){
					session_unset();
					header('location:' .APP_ROOT. 'home/auth/auth');
					exit();
				}else{
					$_SESSION['tempo_sessao'] = $_SESSION['tempo_sessao'] + (time() - $_SESSION['tempo_sessao']);
				}
			}
		}
	}
	
	public function index(){
		/*$apiUsuario =  new apiUsuario();
		$data = "23/03/2020";
		$usuarios = $apiUsuario->retornoferiasForcado($data);
		$sql = array();
		$i = 0;
		if ((is_array($usuarios) ? count($usuarios) : 0) > 0){
			$usuario =  new Usuario();
			$apiApollo = new apiApollo();
			$usuarioapollo = new Usuarioapollo();
			$usuarioapollo->ativo = 'S';
			$usuarioapollo->status = 0;
			$usuarioapollo->usuario_rede = 'AJUSTE DE F�RIAS';
			$usuarioapollo->dta_inativacao = date('d/m/Y');
			foreach ($usuarios as $rs) {
				$usuario->usuario = $rs->USUARIO;
				$usuario->ativo = 1;
				$usuario->dta_ult_alteracao = date("d/m/Y H:i:s");
				$login = explode("@", $rs->EMAIL);
				$result = $apiApollo->getUsuarioapollo(strtoupper(trim($login[0])), $rs->CPF, $rs->EMAIL);
				if (isset($sql[$i])) {
					$i = $i+1;
					$sql[$i] = $apiUsuario->editUsuario($usuario);
				}else{
					$sql[$i] = $apiUsuario->editUsuario($usuario);
				}
				foreach ($result as $ap) {
					$usuarioapollo->usuario = $ap->USUARIO;
					if (isset($sql[$i])) {
						$i = $i+1;
						$sql[$i] = $apiApollo->atualizaUsuario($usuarioapollo);
						$i = $i+1;
						$sql[$i] = $apiApollo->atualizaVendedor($usuarioapollo);
						$i = $i+1;
						$sql[$i] = $apiApollo->atualizaMecanico($usuarioapollo);
					}else{
						$sql[$i] = $apiApollo->atualizaUsuario($usuarioapollo);
						$i = $i+1;
						$sql[$i] = $apiApollo->atualizaVendedor($usuarioapollo);
						$i = $i+1;
						$sql[$i] = $apiApollo->atualizaMecanico($usuarioapollo);
					}
				}
			}
		}
		$rs = $apiUsuario->Execute($sql);
		if ($rs[4] == "sucesso"){
			foreach ($usuarios as $rs) {
				$mail = strtolower(str_replace("'", "", trim($rs->EMAIL)));
				$mail = explode("@", $mail);
				if (end($mail) == "grupomonaco.com.br"){
					$pandion = new Pandion();
					$adldap = new \adLDAP();
					$Username = $mail[0];
					try {
						echo $Username;
						$adldap->user()->modify($Username, array('enabled' => true));
						$pandion->password = $pandion->password = substr(ucfirst($rs->NOME), 0, 2).trim($rs->CPF);
						
					} catch (\adLDAPException $e) {
						echo "n�o foi poss�vel ativar o {$Username} {$e}";
					}
					//Editar Usu�rio Pandion
					$pandion->username = $Username;
					$apiPandion = new apiPandion();
					$apiPandion->editUsuario($pandion);
				}
			}
		}*/
		/*$apiUsuario = new apiUsuario();
		$user = $apiUsuario->filtroUsuario('3','3','', '');
		$sql = array();
		$i = 0 ;
		foreach ($user as $rs){
			$resultado = $apiUsuario->getAtualizausuario($rs->CPF);
			if (isset($resultado->CPF)){
				$usuario = new Usuario();
				if ($resultado->SITUACAO == '4'){
					$usuario->ativo = 0;
				}
				$usuario->usuario = $rs->USUARIO;
				$usuario->empresa = $resultado->EMPRESA;
				$usuario->cargo = $resultado->CARGO;
				$usuario->departamento = $resultado->DEPARTAMENTO;
				$usuario->tipo = $resultado->TIPO;
				$usuario->contrato = $resultado->CONTRATO;
				$usuario->dta_admissao = $resultado->DTA_ADMISSAO;
				$usuario->dta_demissao = $resultado->DTA_DEMISSAO;
				$usuario->dta_nascimento = $resultado->DTA_NASCIMENTO;
				$usuario->dta_ult_ini_ferias = $resultado->DTA_ULT_INI_FERIAS;
				$usuario->dta_ult_fim_ferias = $resultado->DTA_ULT_FIM_FERIAS;
				$usuario->dta_ult_alteracao = date("d/m/Y H:i:s");
				$sql[$i] = $apiUsuario->editUsuario($usuario);
				$i = $i + 1;
 			}
		}
		$r = $apiUsuario->Execute($sql);*/
		
		/*$apiUsuario = new apiUsuario();
		$user = $apiUsuario->dandoPermissao("9", "1", "1");
		$sql = array();
		$i = 0 ;
		foreach ($user as $rs){
			$sql[$i] = "INSERT INTO sis_permissao (usuario,modulo,controle,acao,empresa) VALUES ('{$rs->USUARIO}','9','1','1','{$rs->EMPRESA}')";
			$i = $i + 1;
			$sql[$i] = "INSERT INTO sis_permissao (usuario,modulo,controle,acao,empresa) VALUES ('{$rs->USUARIO}','9','52','1','{$rs->EMPRESA}')";
			$i = $i + 1;
			$sql[$i] = "INSERT INTO sis_permissao (usuario,modulo,controle,acao,empresa) VALUES ('{$rs->USUARIO}','9','52','2','{$rs->EMPRESA}')";
			$i = $i + 1;
			$sql[$i] = "INSERT INTO sis_permissao (usuario,modulo,controle,acao,empresa) VALUES ('{$rs->USUARIO}','9','52','3','{$rs->EMPRESA}')";
			$i = $i + 1;
		 }
		 $r = $apiUsuario->Execute($sql);*/
		
		//echo md5("76".date("dmY"));
		//http://teste.com.br/sismonaco/adm/agendarotina/rotina76/76/3464ab3ef040b77dff430deb578eaab6
		
		
		//Sorteio
		$usuario = new Usuario();
		$sorteio = new Sorteio();
		$codigo  = new Codigo();
		$apiUsuario = new apiUsuario();
		$apiSorteio = new apiSorteio();
		
		//Block Demitidos
		$demitidos = $apiSorteio->retiraDemitidos();
		$demitidos_usuarios = array_column($demitidos, 'USUARIO');
		$this->demitido_block = false;
		foreach($demitidos_usuarios as $demitido){
			if($demitido == $_SESSION['usuario_sessao']){
				$this->demitido_block = true;
			}
		}

		//Block Afastados
		$afastados = $apiSorteio->retiraAfastados();
		$afastados_usuarios = array_column($afastados, 'USUARIO');
		$this->afastado_block = false;
		foreach($afastados_usuarios as $afastado){
			if($afastado == $_SESSION['usuario_sessao']){
				$this->afastado_block = true;
			}
		}
			
		//Block Estagi�rios
		$estagiarios = $apiSorteio->retiraAprendiz();
	 	$estagiario_usuarios = array_column($estagiarios, 'USUARIO');
	 	$this->estagiario_block = false;
		foreach($estagiario_usuarios as $estagiario){
			if($estagiario == $_SESSION['usuario_sessao']){
				$this->estagiario_block = true;
			}
		}
		
		
	//	$this->codigo = $apiSorteio->getCodigo();
		$this->total = $apiSorteio->getTotalUsuarios();
		$this->total = $this->total[0]->TOTAL;
		$codigo->usuario = $_SESSION['usuario_sessao'];
		$usuario->usuario = $_SESSION['usuario_sessao'];
		$this->usuario = $apiUsuario->getUsuario($usuario);
		$this->sorteio = $apiSorteio->getLastIdSorteio($codigo);
		@$this->cod_view = $this->sorteio->CODIGO;
	 //---------------------------------------------------------		
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Sele��o de Modulos";
		$apiPermissao = new apiPermissao();
		$permissao = new Permissao();
		$permissao->usuario = $_SESSION['usuario_sessao'];
		if (!isset($_SESSION['empresa_padrao_sessao'])){
			$_SESSION['empresa_padrao_sessao'] = $_SESSION['empresa_sessao'];
		}
		unset($_SESSION['filtro_sessao']);
		unset($_SESSION['consulta_sessao']);
		unset($_SESSION['atualizar_sessao']);
		//$permissao->empresa = $_SESSION['empresa_padrao_sessao'];
		$this->dados = array('modulo' => $apiPermissao->permModulo($permissao));
		if ($_SERVER['REQUEST_METHOD'] === "POST"){
			$funcoes = new Funcoes();
			$permissao->usuario = $_SESSION['usuario_sessao'];
			$permissao->modulo  = $_POST['modulo'];
			$emp = $apiPermissao->permEmpresa($permissao);
			unset($_SESSION['empresas_modulo']);
			$i = 0;
			$padrao = $emp[0]->EMPRESA;
			foreach ($emp as $rs){
				$_SESSION['empresas_modulo'][$i] = array('empresa' => $rs->EMPRESA,'des_empresa' => $rs->DES_EMPRESA);
				if ($_SESSION['empresa_padrao_sessao'] == $rs->EMPRESA){
					$padrao = $_SESSION['empresa_padrao_sessao'];
				}
				$i = $i + 1;
			}
			$_SESSION['empresa_sessao'] = $padrao;
			header('location:' . APP_ROOT .$funcoes->retiraAcentos(strtolower($emp[0]->MD)));
		}
		$this->view();
	}
	
	public function email(){
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Verificador de E-mail Dispon�vel";
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			
		}
		$this->view();
	}
}