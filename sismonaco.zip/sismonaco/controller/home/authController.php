<?php

namespace controller\home;

use lib\Controller;
use api\home\apiAuth;
use obj\home\Auth;
use helper\EnvioEmail;
use helper\Funcoes;
use obj\geral\Visita;

class authController extends Controller {
	
	public function auth() {
		
		$this->layout = '_layout.login';
		$this->view();
	}
	
	public function fiat(){
		$this->layout = '_layout.fiat';
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$source = $_POST['utm_source'];
			if ($source == 'facebook'){
				$origem = "Facebook";
				$endereco = "http://www.grupomonaco.net.br/sismonaco/auth/fiat/facebook";
			}else{
				$origem = "";
				$endereco = "http://www.grupomonaco.net.br/sismonaco/auth/fiat";
			}
			$nome = $_POST['nome'];
			$celular = $_POST['celular'];
			$cidade = $_POST['cidade'];
			$bairro = $_POST['bairro'];
			$email = $_POST['email'];
			$veiculos = $_POST['veiculos'];
			
			$Envio = new EnvioEmail();
			$data = date('d/m/Y');
			$de  = "SisMonaco - Lead Fiat {$origem} {$data}";
			$assunto   = "Formul�rio Lead {$data}";
			$html = "<p>Um lead do site, de interesse: {$veiculos}</p>";
			$html .= 'Nome: '.$nome.'<br>';
			$html .= 'Celular: ' . $celular. '<br>';
			$html .= 'Email: ' . $email. '<br>';
			$para = array();
			$para[0] = "andreluiz.fiat@grupomonaco.com.br";
			$para[1] = "enildo@grupomonaco.com.br";
			if ($Envio->Envio($de, $assunto, $html, $para, "", "") == "sucesso"){
				$funcoes = new Funcoes();
				$limite = 3600;
				$visita = new Visita();
				$visita->endereco = $endereco;
				$visita->ip = $funcoes->naoNumerico($_SERVER['REMOTE_ADDR']);
				$visita->data = date('d/m/Y');
				$visita->hora = date('H:i');
				$visita->forma_interacao = "F";
				$apiAuth = new apiAuth();
				$sql[0] = $apiAuth->addVisita($visita);
				$rs = $apiAuth->executeSQL($sql);
				/*$result = $apiAuth->getVisita('1', $visita->ip, $visita->data);
				if (count($result) == 0){
					$sql[0] = $apiAuth->addVisita($visita);
					$rs = $apiAuth->executeSQL($sql);
				}else{
					$horaDB = strtotime($result[0]->HORA);
					$horaAtual = strtotime($visita->hora);
					$horaSubtracao = $horaAtual-$horaDB;
					if ($horaSubtracao > $limite){
						$sql[0] = $apiAuth->addVisita($visita);
						$rs = $apiAuth->executeSQL($sql);
					}
				}*/
				$this->enviado = "sim";
			}
		}
		$this->view();
	}
	
	public function login() {
		
		$api = new apiAuth();
		$api->login(new Auth('POST'));
		
	}
	
	public function logout() {
		
		$api = new apiAuth();
		$api->logout();
	}
}