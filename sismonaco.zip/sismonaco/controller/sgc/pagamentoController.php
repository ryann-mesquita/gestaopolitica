<?php

namespace controller\sgc;

use lib\Controller;
use helper\Security;

use api\sgc\apiPagamento;
use helper\Paginator;
use obj\sgc\Pagamento;
use obj\geral\Log;
use api\geral\apiLog;
use helper\Funcoes;

class pagamentoController extends Controller {

	public function __construct() {

		parent::__construct();

		new Security($this->getModule(),$this->getController(),$this->getAction());
	}

	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Lista de Formas de Pagamento";
		$apiPagamento =  new apiPagamento();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		(!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])) ? $a = '1' : $a = '3';
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$busca = array(
				'1' => array('c' => '1','a' => $a,'coluna' => 'ativo', 'valor' => '1'),
				'2' => array('c' => '1','a' => $a,'coluna' => 'ativo', 'valor' => '0'),
				'3' => array('c' => '2','a' => $a,'coluna' => 'des_pagamento', 'valor' => @$_POST['busca_valor']),
				'4' => array('c' => '3','a' => $a,'coluna' => "",'valor' => "")
			);
			if(isset($busca[$_POST['busca']])){
				$this->dados = array('pagamento' => $apiPagamento->filtroPagamento($busca[$_POST['busca']]['c'], $busca[$_POST['busca']]['a'], $busca[$_POST['busca']]['coluna'], $busca[$_POST['busca']]['valor']));
				$_SESSION['filtro_sessao'] = array('c' => $busca[$_POST['busca']]['c'], 'a' => $busca[$_POST['busca']]['a'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'busca_valor' => $busca[$_POST['busca']]['valor'], 'busca' => $_POST['busca']);
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'sgc/index/index/acessonegado');
				die();
			}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				$this->dados = array('pagamento' => $apiPagamento->filtroPagamento($_SESSION['filtro_sessao']['c'],$_SESSION['filtro_sessao']['a'],$_SESSION['filtro_sessao']['coluna'], $_SESSION['filtro_sessao']['busca_valor']));
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('pagamento' => $apiPagamento->filtroPagamento('1','3','ativo', '1'));
					$_SESSION['filtro_sessao'] = array('c' => '1', 'a' => '3', 'coluna' => 'ativo' , 'busca_valor' => '1', 'busca' => '4');
					$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}
		}
		$TotalItem = (is_array($this->dados['pagamento']) ? count($this->dados['pagamento']) : 0);
		$this->dados['pagamento'] = array_chunk($this->dados['pagamento'], $ItemPorPagina);
		@$this->dados['pagamento'] = $this->dados['pagamento'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->view();
	}
	
	
	public function adicionar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Cadastro de Pagamento";
		$apiPagamento = new apiPagamento();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$Post = new Pagamento('POST');
			$apiPagamento = new apiPagamento();
			$rs = $apiPagamento->filtroPagamento('1','3','des_pagamento',$Post->des_pagamento);
			if ((is_array($rs) ? count($rs) : 0) > 0){
				$this->rollback = new Pagamento('POST');
				$this->Alert = "J� existe um pagamento com esse nome cadastrado!";
			}else{
				$sql[$i] = $apiPagamento->addPagamento($Post);
				$i = $i+1;
				$log = new Log();
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico = "DES_PAGAMENTO||{$Post->des_pagamento};;ATIVO||{$Post->ativo}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiPagamento->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'sgc/pagamento/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'sgc/pagamento/index/sucesso');
					}
				}else{
					$this->rollback = new Pagamento('POST');
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		
		$this->view();
	}
	
		
	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Altera��o de Pagamento";
		$pagamento = new Pagamento();
		$this->getParams(0);
		$pagamento->pagamento = $this->getParams(0);
		$apiPagamento = new apiPagamento();
		$this->dados = array('pagamento' => $apiPagamento->getPagamento($pagamento));
		if (isset($this->dados['pagamento'])){
			if ($this->dados['pagamento']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'sgc/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'sgc/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$anterior = "";
			$atual = "::";
			$funcoes = new Funcoes();
			$sql = array();
			$Post = new Pagamento();
			$Post->pagamento = $this->getParams(0);
			$rs = $apiPagamento->filtroPagamento('1','3','des_pagamento',$Post->des_pagamento);
			$log = new Log();
			if ((is_array($rs) ? count($rs) : 0) > 0 && ($rs[0]->DES_PAGAMENTO != $this->dados['pagamento']->DES_PAGAMENTO)){
				$this->dados['pagamento']->DES_PAGAMENTO = $_POST['des_pagamento'];
				$this->dados['pagamento']->CONTA = $_POST['conta'];
				$this->dados['pagamento']->ATIVO = $_POST['ativo'];
				$this->Alert = "J� existe um pagamento com esse nome cadastrado!";
			}else{
				$des_pagamento = strtoupper($funcoes->retiraAcentos(trim($_POST['des_pagamento'])));
				if ($this->dados['pagamento']->DES_PAGAMENTO != $des_pagamento){
					$Post->des_pagamento = $des_pagamento;
					$anterior .= "DES_PAGAMENTO||{$this->dados['pagamento']->DES_PAGAMENTO};;";
					$atual .= "DES_PAGAMENTO||{$Post->des_pagamento};;";
				}
				if ($this->dados['pagamento']->CONTA != $_POST['conta']){
					$Post->conta = $_POST['conta'];
					$anterior .= "CONTA||{$this->dados['pagamento']->CONTA};;";
					$atual .= "CONTA||{$Post->conta};;";
				}
				if ($this->dados['pagamento']->ATIVO != $_POST['ativo']){
					$Post->ativo = $_POST['ativo'];
					$anterior .= "ATIVO||{$this->dados['pagamento']->ATIVO};;";
					$atual .= "ATIVO||{$Post->ativo};;";
				}
				if ($apiPagamento->editPagamento($Post) != ""){
					$sql[$i] = $apiPagamento->editPagamento($Post);
					$i = $i+1;
					$log->usuario = $_SESSION['usuario_sessao'];
					$log->modulo = $this->getModule()['modulo'];
					$log->controle = $this->getController()['controle'];
					$log->acao = $this->getAction()['acao'];
					$log->empresa = $_SESSION['empresa_sessao'];
					$log->tipo = "A";
					$log->dta_registro = date("d/m/Y H:i:s");
					$log->historico = substr($anterior,0,-2);
					$log->historico .= substr($atual,0,-2);
					$apiLog = new apiLog();
					$sql[$i] = $apiLog->addLog($log);
					$rs = $apiPagamento->executeSQL($sql);
					if (@$rs[4] == 'sucesso') {
						if (isset($this->PaginaAtual)) {
							header('location:' .APP_ROOT. 'sgc/pagamento/index/pagina/'.$this->PaginaAtual.'/sucesso');
						}else {
							header('location:' .APP_ROOT. 'sgc/pagamento/index/sucesso');
						}
					}else{
						$this->dados['pagamento']->DES_PAGAMENTO = $_POST['des_pagamento'];
						$this->dados['pagamento']->CONTA = $_POST['conta'];
						$this->dados['pagamento']->ATIVO = $_POST['ativo'];
						$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
						$erro = str_replace($retirar, "", $rs[2]);
						$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
					}
				}else{
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'sgc/pagamento/index/pagina/'.$this->PaginaAtual.'/insucesso');
					}else {
						header('location:' .APP_ROOT. 'sgc/pagamento/index/insucesso');
					}
				}
			}
		}
		$this->view();
	}
	
	public function excluir() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Exclus�o de Pagamento";
		$pagamento = new Pagamento();
		$pagamento->pagamento = $this->getParams(0);
		$apiPagamento = new apiPagamento();
		$this->dados = array('pagamento' => $apiPagamento->getPagamento($pagamento));
		if (isset($this->dados['pagamento'])){
			if ($this->dados['pagamento']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'sgc/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'sgc/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$sql[$i] = $apiPagamento->delPagamento($pagamento);
			$i = $i+1;
			$log = new Log();
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "E";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico = "PAGAMENTO||{$this->dados['pagamento']->PAGAMENTO};;DES_PAGAMENTO||{$this->dados['pagamento']->DES_PAGAMENTO};;CONTA||{$this->dados['pagamento']->CONTA};;ATIVO||{$this->dados['pagamento']->ATIVO}";
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiPagamento->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'sgc/pagamento/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'sgc/pagamento/index/sucesso');
				}
			}else{
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}
		$this->view();
	}
		
		
		
		
	}
