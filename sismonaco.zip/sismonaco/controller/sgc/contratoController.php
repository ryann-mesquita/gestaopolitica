<?php

namespace controller\sgc;

use lib\Controller;
use helper\Security;

use api\sgc\apiContrato;
use helper\Paginator;
use obj\sgc\Contrato;
use obj\adm\Usuario;
use obj\geral\Log;
use api\geral\apiLog;
use api\sgc\apiTipo;
use api\sgc\apiIndice;
use api\sgc\apiPeriodicidade;
use api\sgc\apiPagamento;
use helper\Funcoes;
use api\geral\apiApollo;
use api\adm\apiUsuario;
use obj\sgc\Itemcontrato;
use obj\sgc\Aditivocontrato;

class contratoController extends Controller {

	public function __construct() {

		parent::__construct();

		new Security($this->getModule(),$this->getController(),$this->getAction());
	}

	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Lista de Contratos";
		$apiContrato =  new apiContrato();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		$apiTipo = new apiTipo();
		$this->tipo = $apiTipo->filtroTipo('1','3','ativo', '1');
		(!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])) ? $a = '1' : $a = '3';
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$busca = array(
				'1' => array('c' => '1','a' => $a,'coluna' => 'ativo', 'valor' => '1'),
				'2' => array('c' => '1','a' => $a,'coluna' => 'ativo', 'valor' => '0'),
				'3' => array('c' => '2','a' => $a,'coluna' => 'des_contrato', 'valor' => @$_POST['busca_valor']),
				'4' => array('c' => '2','a' => $a,'coluna' => 'n_contrato', 'valor' => @$_POST['busca_valor']),
				'5' => array('c' => '2','a' => $a,'coluna' => 'cod_contrato', 'valor' => @$_POST['busca_valor']),	
				'6' => array('c' => '4','a' => $a,'coluna' => 'dta_inicio', 'valor' => @$_POST['busca_valor'], 'de' => @$_POST['busca_de'], 'ate' => @$_POST['busca_ate']),
				'7' => array('c' => '4','a' => $a,'coluna' => 'dta_termino', 'valor' => @$_POST['busca_valor'], 'de' => @$_POST['busca_de'], 'ate' => @$_POST['busca_ate']),
				'8' => array('c' => '1','a' => $a,'coluna' => 'tipo', 'valor' => @$_POST['busca_valor']),
				'9' => array('c' => '1','a' => $a,'coluna' => 'contratante', 'valor' => @$_POST['busca_valor']),		
				'10' => array('c' => '1','a' => $a,'coluna' => 'gestor', 'valor' => @$_POST['busca_valor']),
				'11' => array('c' => '1','a' => $a,'coluna' => 'fornecedor', 'valor' => @$_POST['busca_valor']),
				'12' => array('c' => '3','a' => $a,'coluna' => "",'valor' => "")
			);
			if(isset($busca[$_POST['busca']])){
				$this->dados = array('contrato' => $apiContrato->filtroContrato($busca[$_POST['busca']]['c'], $busca[$_POST['busca']]['a'], $busca[$_POST['busca']]['coluna'], $busca[$_POST['busca']]['valor'],@$busca[$_POST['busca']]['de'],@$busca[$_POST['busca']]['ate']));
				$_SESSION['filtro_sessao'] = array('c' => $busca[$_POST['busca']]['c'], 'a' => $busca[$_POST['busca']]['a'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'busca_valor' => $busca[$_POST['busca']]['valor'], 'de' => isset($_POST['busca_de']) ? $_POST['busca_de'] : "", 'ate' => isset($_POST['busca_ate']) ? $_POST['busca_ate'] : "", 'busca' => $_POST['busca']);
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'sgc/index/index/acessonegado');
				die();
			}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				$this->dados = array('contrato' => $apiContrato->filtroContrato($_SESSION['filtro_sessao']['c'],$_SESSION['filtro_sessao']['a'],$_SESSION['filtro_sessao']['coluna'], $_SESSION['filtro_sessao']['busca_valor'], $_SESSION['filtro_sessao']['de'], $_SESSION['filtro_sessao']['ate']));
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('contrato' => $apiContrato->filtroContrato('1','3','ativo', '1'));
					$_SESSION['filtro_sessao'] = array('c' => '1', 'a' => '3', 'coluna' => 'ativo' , 'busca_valor' => '1', 'de' => "", 'ate' => "", 'busca' => '12');
					$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}
		}
		$TotalItem = (is_array($this->dados['contrato']) ? count($this->dados['contrato']) : 0);
		$this->dados['contrato'] = array_chunk($this->dados['contrato'], $ItemPorPagina);
		@$this->dados['contrato'] = $this->dados['contrato'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->view();
	}
	
	public function adicionar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Cadastro de Contrato";
		$apiContrato = new apiContrato();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		$funcoes = new Funcoes();
		$apiTipo = new apiTipo();
		$this->tipo = $apiTipo->filtroTipo('1','1', 'ativo', '1');
		$apiPagamento = new apiPagamento();
		$this->pagamento = $apiPagamento->filtroPagamento('1','1', 'ativo', '1');
		$apiPeriodicidade = new apiPeriodicidade();
		$this->periodicidade = $apiPeriodicidade->filtroPeriodicidade('1','1', 'ativo', '1');
		$apiIndice = new apiIndice();
		$this->indice = $apiIndice->filtroIndice('1','1', 'ativo', '1');
		$codpadrao = $apiContrato->getCodpadrao($_SESSION['empresa_sessao'])->COD;
		@$n_cod = ($apiContrato->getCodsgc($_SESSION['empresa_sessao'])->COD) + 1;
		$this->codpadrao = "{$codpadrao}{$n_cod}";
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$Post = new Contrato();
			$apiContrato = new apiContrato();
			$anexo = $_FILES["anexo"];
			$ane = 1;
			$an = 0;
			$anexos_nomes = array();
			$anexos = "";
			foreach ($anexo['name'] as $key => $v){
				$ex = explode(".", $v);
				$exp = strtolower(end($ex));
				$anexos_nomes[$an] = "{$_SESSION['usuario_sessao']}-Anexo{$ane}-".date('dmY-His').".{$exp}";
				$anexos .= "ANEXO{$ane}||{$_SESSION['usuario_sessao']}-Anexo{$ane}-".date('dmY-His').".{$exp};;";
				$an = $an + 1;
				$ane = $ane + 1;
			}
			$Post->anexo = substr($anexos,0,-2);
			$Post->empresa = $_SESSION['empresa_sessao'];
			$Post->cod_contrato = $this->codpadrao;
			$Post->n_contrato = $_POST['n_contrato'];
			$Post->tipo = $_POST['tipo'];
			$Post->fornecedor = $_POST['fornecedor'];
			$Post->contratante = $_POST['contratante'];
			$Post->gestor = $_POST['gestor'];
			$Post->dta_inicio = $_POST['dta_inicio'];
			$Post->dta_termino = $_POST['dta_termino'];
			$Post->prazo_contrato = strtoupper($_POST['prazo_contrato']);
			$Post->dias_pagamento = $_POST['dias_pagamento'];
			$Post->opcao_pagamento = $_POST['opcao_pagamento'];
			$Post->pagamento = $_POST['pagamento'];
			$Post->periodicidade = $_POST['periodicidade'];
			$Post->indice = $_POST['indice'];
			$Post->valor = $funcoes->sanearValor($_POST['valor']);
			$Post->periodo_valor = $_POST['periodo_valor'];
			$Post->des_contrato = strtoupper($funcoes->retiraAcentos(trim($_POST['des_contrato'])));
			$Post->obs = strtoupper($funcoes->retiraAcentos(trim($_POST['obs'])));
			$Post->alerta1 = $_POST['alerta1'];
			$Post->alerta2 = $_POST['alerta2'];
			$Post->alerta3 = $_POST['alerta3'];
			$Post->alerta4 = $_POST['alerta4'];
			$Post->alerta5 = $_POST['alerta5'];
			$Post->alerta6 = $_POST['alerta6'];
			$Post->dta_criacao = date("d/m/Y H:i:s");
			$Post->ativo = 1;
			$sql[$i] = $apiContrato->addContrato($Post);
			$i = $i+1;
			$log = new Log();
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "I";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico = "EMPRESA||{$Post->empresa};;COD_CONTRATO||{$Post->cod_contrato};;N_CONTRATO||{$Post->n_contrato};;TIPO||{$Post->tipo};;FORNECEDOR||{$Post->fornecedor};;CONTRATANTE||{$Post->contratante};;GESTOR||{$Post->gestor};;DTA_INICIO||{$Post->dta_inicio};;DTA_TERMINO||{$Post->dta_termino};;PRAZO_CONTRATO||{$Post->prazo_contrato};;DIAS_PAGAMENTO||{$Post->dias_pagamento};;OPCAO_PAGAMENTO||{$Post->opcao_pagamento};;PAGAMENTO||{$Post->pagamento};;PERIODICIDADE||{$Post->periodicidade};;INDICE||{$Post->indice};;VALOR||{$Post->valor};;PERIODO_VALOR||{$Post->periodo_valor};;DES_CONTRATO||{$Post->des_contrato};;OBS||{$Post->obs};;ALERTA1||{$Post->alerta1};;ALERTA2||{$Post->alerta2};;ALERTA3||{$Post->alerta3};;ALERTA4||{$Post->alerta4};;ALERTA5||{$Post->alerta5};;ALERTA6||{$Post->alerta6};;DTA_CRIACAO||{$Post->dta_criacao};;ATIVO||{$Post->ativo}";
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$contrato = array('coluna' => 'contrato','tabela' => 'sgc_contrato');
			$ordem = 0;
			$descricao = $_POST["des_item"];
			$valor = $_POST["val_item"];
			$periodo = $_POST["periodo_item"];
			$itemcontrato = new Itemcontrato();
			foreach ($descricao as $key => $des) {
				$i = $i+1;
				$ordem = $ordem + 1;
				$itemcontrato->item = $ordem;
				$itemcontrato->des_item = strtoupper($funcoes->retiraAcentos(trim($des)));
				$itemcontrato->val_item =  $funcoes->sanearValor($valor{$key});
				$itemcontrato->periodo_item = $periodo{$key};
				$sql[$i] = $apiContrato->addItemcontrato($itemcontrato, $contrato);
			}
			$rs = $apiContrato->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				foreach ($anexos_nomes as $key => $v){
					move_uploaded_file($_FILES['anexo']['tmp_name'][$key], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/".$v);
				}
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'sgc/contrato/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'sgc/contrato/index/sucesso');
				}
			}else{
				$this->rollback = new Contrato('POST');
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
	
		}		
		$this->view();
	}
	
	
	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Altera��o de Contrato";
		$contrato = new Contrato();
		$this->getParams(0);
		$contrato->contrato = $this->getParams(0);
		$apiContrato = new apiContrato();
		$this->dados = array('contrato' => $apiContrato->getContrato($contrato));
		if (isset($this->dados['contrato'])){
			if ($this->dados['contrato']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'sgc/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'sgc/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		$apiTipo = new apiTipo();
		$this->tipo = $apiTipo->filtroTipo('1','1', 'ativo', '1');
		$apiPeriodicidade = new apiPeriodicidade();
		$this->periodicidade = $apiPeriodicidade->filtroPeriodicidade('1','1', 'ativo', '1');
		$apiIndice = new apiIndice();
		$this->indice = $apiIndice->filtroIndice('1','1', 'ativo', '1');
		$apiPagamento = new apiPagamento();
		$this->pagamento = $apiPagamento->filtroPagamento('1','1', 'ativo', '1');
		$this->itemcontrato = $apiContrato->getItemcontrato($contrato);
		$this->aditivocontrato = $apiContrato->getAditivocontrato($contrato);
		$codpadrao = $apiContrato->getCodpadrao($_SESSION['empresa_sessao'])->COD;
		$n_cod = ($apiContrato->getCodsgc($_SESSION['empresa_sessao'])->COD) + 1;
		$this->codpadrao = "{$codpadrao}{$n_cod}";
		$strVal = explode(';;', $this->dados['contrato']->ANEXO);
		foreach ($strVal as $va){
			@list($k, $v) = explode('||', $va);
			$this->anexos[$k] = $v;
		}
		rsort($this->anexos);
		$apiUsuario = new apiUsuario();
		$contratante = $this->dados['contrato']->CONTRATANTE;	
		
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$anterior = "";
			$atual = "::";
			$funcoes = new Funcoes();
			$sql = array();
			$Post = new Contrato();
			$Post->contrato = $this->getParams(0);
			/*if ($this->dados['contrato']->COD_CONTRATO != $_POST['cod_contrato']){
				$Post->cod_contrato = $_POST['cod_contrato'];
				$anterior .= "COD_CONTRATO||{$this->dados['contrato']->COD_CONTRATO};;";
				$atual .= "COD_CONTRATO||{$Post->cod_contrato};;";
			}*/
			if ($this->dados['contrato']->N_CONTRATO != $_POST['n_contrato']){
				$Post->n_contrato = $_POST['n_contrato'];
				$anterior .= "N_CONTRATO||{$this->dados['contrato']->N_CONTRATO};;";
				$atual .= "N_CONTRATO||{$Post->n_contrato};;";
			}
			/*if ($this->dados['contrato']->EMPRESA != $_POST['empresa']){
				$Post->empresa = $_POST['empresa'];
				$anterior .= "EMPRESA||{$this->dados['contrato']->EMPRESA};;";
				$atual .= "EMPRESA||{$Post->empresa};;";
			}*/
			if ($this->dados['contrato']->TIPO != $_POST['tipo']){
				$Post->tipo = $_POST['tipo'];
				$anterior .= "TIPO||{$this->dados['contrato']->TIPO};;";
				$atual .= "TIPO||{$Post->tipo};;";
			}
			if ($this->dados['contrato']->FORNECEDOR != $_POST['fornecedor']){
				$Post->fornecedor = $_POST['fornecedor'];
				$anterior .= "FORNECEDOR||{$this->dados['contrato']->FORNECEDOR};;";
				$atual .= "FORNECEDOR||{$Post->fornecedor};;";
			}
			if ($this->dados['contrato']->CONTRATANTE != $_POST['contratante']){
				$Post->contratante = $_POST['contratante'];
				$anterior .= "CONTRATANTE||{$this->dados['contrato']->CONTRATANTE};;";
				$atual .= "CONTRATANTE||{$Post->contratante};;";
			}
			if ($this->dados['contrato']->GESTOR != $_POST['gestor']){
				$Post->gestor = $_POST['gestor'];
				$anterior .= "GESTOR||{$this->dados['contrato']->GESTOR};;";
				$atual .= "GESTOR||{$Post->gestor};;";
			}
			if ($this->dados['contrato']->DTA_INICIO != $_POST['dta_inicio']){
				$Post->dta_inicio = $_POST['dta_inicio'];
				$anterior .= "DTA_INICIO||{$this->dados['contrato']->DTA_INICIO};;";
				$atual .= "DTA_INICIO||{$Post->dta_inicio};;";
			}
			if ($this->dados['contrato']->DTA_TERMINO != $_POST['dta_termino']){
				$Post->dta_termino = $_POST['dta_termino'];
				$anterior .= "DTA_TERMINO||{$this->dados['contrato']->DTA_TERMINO};;";
				$atual .= "DTA_TERMINO||{$Post->dta_termino};;";
			}
			if ($this->dados['contrato']->PRAZO_CONTRATO != $_POST['prazo_contrato']){
				$Post->prazo_contrato = $_POST['prazo_contrato'];
				$anterior .= "PRAZO_CONTRATO||{$this->dados['contrato']->PRAZO_CONTRATO};;";
				$atual .= "PRAZO_CONTRATO||{$Post->prazo_contrato};;";
			}
			if ($this->dados['contrato']->DIAS_PAGAMENTO != $_POST['dias_pagamento']){
				$Post->dias_pagamento = $_POST['dias_pagamento'];
				$anterior .= "DIAS_PAGAMENTO||{$this->dados['contrato']->DIAS_PAGAMENTO};;";
				$atual .= "DIAS_PAGAMENTO||{$Post->dias_pagamento};;";
			}
			if ($this->dados['contrato']->PAGAMENTO != $_POST['pagamento']){
				$Post->pagamento = $_POST['pagamento'];
				$anterior .= "PAGAMENTO||{$this->dados['contrato']->PAGAMENTO};;";
				$atual .= "PAGAMENTO||{$Post->pagamento};;";
			}
			if ($this->dados['contrato']->PERIODICIDADE != $_POST['periodicidade']){
				$Post->periodicidade = $_POST['periodicidade'];
				$anterior .= "PERIODICIDADE||{$this->dados['contrato']->PERIODICIDADE};;";
				$atual .= "PERIODICIDADE||{$Post->periodicidade};;";
			}
			if ($this->dados['contrato']->INDICE != $_POST['indice']){
				$Post->indice = $_POST['indice'];
				$anterior .= "INDICE||{$this->dados['contrato']->INDICE};;";
				$atual .= "INDICE||{$Post->indice};;";
			}
			$valor = $funcoes->sanearValor($_POST['valor']);
			if ($this->dados['contrato']->VALOR != $valor){
				$Post->valor = $valor;
				$anterior .= "VALOR||{$this->dados['contrato']->VALOR};;";
				$atual .= "VALOR||{$Post->valor};;";
			}
			if ($this->dados['contrato']->PERIODO_VALOR != $_POST['periodo_valor']){
				$Post->periodo_valor = $_POST['periodo_valor'];
				$anterior .= "PERIODO_VALOR||{$this->dados['contrato']->PERIODO_VALOR};;";
				$atual .= "PERIODO_VALOR||{$Post->periodo_valor};;";
			}
			$des_contrato = strtoupper($funcoes->retiraAcentos(trim($_POST['des_contrato'])));
			if ($this->dados['contrato']->DES_CONTRATO != $des_contrato){
				$Post->des_contrato = $des_contrato;
				$anterior .= "DES_CONTRATO||{$this->dados['contrato']->DES_CONTRATO};;";
				$atual .= "DES_CONTRATO||{$Post->des_contrato};;";
			}
			$obs = strtoupper($funcoes->retiraAcentos(trim($_POST['obs'])));
			if ($this->dados['contrato']->OBS != $obs){
				$Post->obs = $obs;
				$anterior .= "OBS||{$this->dados['contrato']->OBS};;";
				$atual .= "OBS||{$Post->obs};;";
			}
			if ($this->dados['contrato']->ALERTA1 != $_POST['alerta1']){
				$Post->alerta1 = $_POST['alerta1'];
				$anterior .= "ALERTA1||{$this->dados['contrato']->ALERTA1};;";
				$atual .= "ALERTA1||{$Post->alerta1};;";
			}
			if ($this->dados['contrato']->ALERTA2 != $_POST['alerta2']){
				$Post->alerta2 = $_POST['alerta2'];
				$anterior .= "ALERTA2||{$this->dados['contrato']->ALERTA2};;";
				$atual .= "ALERTA2||{$Post->alerta2};;";
			}
			if ($this->dados['contrato']->ALERTA3 != $_POST['alerta3']){
				$Post->alerta3 = $_POST['alerta3'];
				$anterior .= "ALERTA3||{$this->dados['contrato']->ALERTA3};;";
				$atual .= "ALERTA3||{$Post->alerta3};;";
			}
			if ($this->dados['contrato']->ALERTA4 != $_POST['alerta4']){
				$Post->alerta4 = $_POST['alerta4'];
				$anterior .= "ALERTA4||{$this->dados['contrato']->ALERTA4};;";
				$atual .= "ALERTA4||{$Post->alerta4};;";
			}
			if ($this->dados['contrato']->ALERTA5 != $_POST['alerta5']){
				$Post->alerta5 = $_POST['alerta5'];
				$anterior .= "ALERTA5||{$this->dados['contrato']->ALERTA5};;";
				$atual .= "ALERTA5||{$Post->alerta5};;";
			}
			if ($this->dados['contrato']->ALERTA6 != $_POST['alerta6']){
				$Post->alerta6 = $_POST['alerta6'];
				$anterior .= "ALERTA6||{$this->dados['contrato']->ALERTA6};;";
				$atual .= "ALERTA6||{$Post->alerta6};;";
			}
			if ($_FILES["anexo"]["name"][0] != ""){
				if (isset($this->dados['contrato']->ANEXO)){
					$anexos_comp = "{$this->dados['contrato']->ANEXO};;";
					$ane = (is_array(explode(';;', $this->dados['contrato']->ANEXO)) ? count(explode(';;', $this->dados['contrato']->ANEXO)) : 0) + 1;
					$anterior .= "ANEXO||{$this->dados['contrato']->ANEXO};;";
				}else{
					$anexos_comp = "";
					$ane = 1;
					$anterior .= "ANEXO||SEM ANEXO;;";
				}
				$anexo = $_FILES["anexo"];
				$an = 0;
				$anexos_nomes = array();
				foreach ($anexo['name'] as $key => $v){
					$ex = explode(".", $v);
					$exp = strtolower(end($ex));
					$anexos_nomes[$an] = "{$_SESSION['usuario_sessao']}-{$contrato->contrato}-Anexo{$ane}-".date('dmY-His').".{$exp}";
					$anexos_comp .= "ANEXO{$ane}||{$_SESSION['usuario_sessao']}-{$contrato->contrato}-Anexo{$ane}-".date('dmY-His').".{$exp};;";
					$an = $an + 1;
					$ane = $ane + 1;
				}
				$Post->anexo = substr($anexos_comp,0,-2);
				$atual .= "ANEXO||{$Post->anexo};;";
			}
			$item = 0;
			$descricao = $_POST["des_item"];
			$valor = $_POST["val_item"];
			$periodo = $_POST["periodo_item"];
			foreach ($descricao as $key => $des) {
				if (isset($this->itemcontrato[$item])){
					if (isset($sql[$i])) {
						$i = $i+1;	
					}
					$itemcontrato = new Itemcontrato();
					$itemcontrato->contrato = $this->getParams(0);
					$itemcontrato->item = $item + 1;;
					if ($this->itemcontrato[$item]->DES_ITEM != strtoupper($funcoes->retiraAcentos(trim($des)))){
						$itemcontrato->des_item = strtoupper($funcoes->retiraAcentos(trim($des)));
						$n = $item + 1;
						$anterior .= "DES_ITEM{$n}||{$this->itemcontrato[$item]->DES_ITEM};;";
						$atual .= "DES_ITEM{$n}||{$itemcontrato->des_item};;";
					}
					if ($this->itemcontrato[$item]->VAL_ITEM != $funcoes->sanearValor($valor{$key})){
						$itemcontrato->val_item =  $funcoes->sanearValor($valor{$key});
						$n = $item + 1;
						$anterior .= "VAL_ITEM{$n}||{$this->itemcontrato[$item]->VAL_ITEM};;";
						$atual .= "VAL_ITEM{$n}||{$itemcontrato->val_item};;";
					}
					if($this->itemcontrato[$item]->PERIODO_ITEM != $periodo{$key}){
						$itemcontrato->periodo_item = $periodo{$key};
						$n = $item + 1;
						$anterior .= "PERIODO_ITEM{$n}||{$this->itemcontrato[$item]->PERIODO_ITEM};;";
						$atual .= "PERIODO_ITEM{$n}||{$itemcontrato->periodo_item};;";
					}
					if ($itemcontrato->des_item != "" || $itemcontrato->val_item != "" || $itemcontrato->periodo_item != ""){
						$sql[$i] = $apiContrato->editItemcontrato($itemcontrato);
					}
					$item = $item + 1;
				}else{
					if (isset($sql[$i])) {
						$i = $i+1;
					}
					$itemcontrato = new Itemcontrato();
					$itemcontrato->contrato = $this->getParams(0);
					$item = $item + 1;
					$itemcontrato->item = $item;
					$itemcontrato->des_item = strtoupper($funcoes->retiraAcentos(trim($des)));
					$itemcontrato->val_item =  $funcoes->sanearValor($valor{$key});
					$itemcontrato->periodo_item = $periodo{$key};
					$anterior .= "ITEM{$item}||NAO EXISTIA;;";
					$atual .= "ITEM{$item}||CRIADO;;";
					$sql[$i] = $apiContrato->addItemcontrato($itemcontrato);
				}
			}
			for ($a = $item+1; $a < ((is_array($this->itemcontrato) ? count($this->itemcontrato) : 0) + 1); $a++){
				if (isset($sql[$i])) {
					$i = $i+1;
				}
				$anterior .= "ITEM{$a}||EXISTIA;;";
				$atual .= "ITEM{$a}||EXCLUIDO;;";
				$itemcontrato = new Itemcontrato();
				$itemcontrato->item = $a;
				$itemcontrato->contrato = $this->getParams(0);
				$sql[$i] = $apiContrato->delItemcontrato($itemcontrato);
			}
			if (isset($_POST["des_aditivo"])){
				$aditivo = 0;
				$des_aditivo = $_POST["des_aditivo"];
				$vigencia = $_POST["vigencia"];
				foreach ($des_aditivo as $key => $desa) {
					if (isset($this->aditivocontrato[$aditivo])){
						if (isset($sql[$i])) {
							$i = $i+1;
						}
						$aditivocontrato = new Aditivocontrato();
						$aditivocontrato->contrato = $this->getParams(0);
						$aditivocontrato->aditivo = $aditivo + 1;
						if ($this->aditivocontrato[$aditivo]->DES_ADITIVO != strtoupper($funcoes->retiraAcentos(trim($desa)))){
							$aditivocontrato->des_aditivo = strtoupper($funcoes->retiraAcentos(trim($desa)));
							$n = $aditivo + 1;
							$anterior .= "DES_ADITIVO{$n}||{$this->aditivocontrato[$aditivo]->DES_ADITIVO};;";
							$atual .= "DES_ADITIVO{$n}||{$aditivocontrato->des_aditivo};;";
						}
						echo $vigencia{$key};
						if ($this->aditivocontrato[$aditivo]->VIGENCIA != $vigencia{$key}){
							$aditivocontrato->vigencia = $vigencia{$key};
							$n = $aditivo + 1;
							$anterior .= "VIGENCIA{$n}||{$this->aditivocontrato[$aditivo]->VIGENCIA};;";
							$atual .= "VIGENCIA{$n}||{$aditivocontrato->vigencia};;";
						}
						if ($aditivocontrato->des_aditivo != "" || $aditivocontrato->vigencia != ""){
							$sql[$i] = $apiContrato->editAditivocontrato($aditivocontrato);
						}
						$aditivo = $aditivo + 1;
					}else{
						if (isset($sql[$i])) {
							$i = $i+1;
						}
						$aditivocontrato = new Aditivocontrato();
						$aditivocontrato->contrato = $this->getParams(0);
						$aditivo = $aditivo + 1;
						$aditivocontrato->aditivo = $aditivo;
						$aditivocontrato->des_aditivo = strtoupper($funcoes->retiraAcentos(trim($desa)));
						$aditivocontrato->vigencia = $vigencia{$key};
						$aditivocontrato->dta_aditivo = date('d/m/Y H:i:s');
						$anterior .= "ADITIVO{$aditivo}||NAO EXISTIA;;";
						$atual .= "ADITIVO{$aditivo}||CRIADO;;";
						$sql[$i] = $apiContrato->addAditivocontrato($aditivocontrato);
					}
				}
				for ($a = ($aditivo+1); $a < ((is_array($this->aditivocontrato) ? count($this->aditivocontrato) : 0) + 1); $a++){
					if (isset($sql[$i])) {
						$i = $i+1;
					}
					$anterior .= "ADITIVO{$a}||EXISTIA;;";
					$atual .= "ADITIVO{$a}||EXCLUIDO;;";
					$aditivocontrato = new Aditivocontrato();
					$aditivocontrato->aditivo = $a;
					$aditivocontrato->contrato = $this->getParams(0);
					$sql[$i] = $apiContrato->delAditivocontrato($aditivocontrato);
				}
			}elseif ((is_array($this->aditivocontrato) ? count($this->aditivocontrato) : 0) > 0){
				for ($a = 1; $a < (count($this->aditivocontrato)+1); $a++){
					if (isset($sql[$i])) {
						$i = $i+1;
					}
					$anterior .= "ADITIVO{$a}||EXISTIA;;";
					$atual .= "ADITIVO{$a}||EXCLUIDO;;";
					$aditivocontrato = new Aditivocontrato();
					$aditivocontrato->aditivo = $a;
					$aditivocontrato->contrato = $this->getParams(0);
					$sql[$i] = $apiContrato->delAditivocontrato($aditivocontrato);
				}
			}
	
			if ($apiContrato->editContrato($Post) != ""){
				if (isset($sql[$i])) {
					$i = $i+1;
				}
				$sql[$i] = $apiContrato->editContrato($Post);
			}
			if ($anterior != ""){
				$log = new Log();
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "A";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico = substr($anterior,0,-2);
				$log->historico .= substr($atual,0,-2);
				$apiLog = new apiLog();
				if (isset($sql[$i])) {
					$i = $i+1;
				}
				$sql[$i] = $apiLog->addLog($log);
		      
				$rs = $apiContrato->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if ($_FILES["anexo"]["name"][0] != ""){
						foreach ($anexos_nomes as $key => $v){
							move_uploaded_file($_FILES['anexo']['tmp_name'][$key], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/".$v);
						}
					}
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'sgc/contrato/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'sgc/contrato/index/sucesso');
					}
				}else{
					$this->dados['contrato']->DES_CONTRATO = $_POST['des_contrato'];
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}else{
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'sgc/contrato/index/pagina/'.$this->PaginaAtual.'/insucesso');
				}else {
					header('location:' .APP_ROOT. 'sgc/contrato/index/insucesso');
				}
			}
		}
		$this->view();
	}
	
	public function cliente() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Consulta de Cliente";
		$this->acao = $this->getParams(0);
		$this->getParams(0);
		$apiApollo = new apiApollo();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			unset($_SESSION['filtro_cliente']);
			$filtro = $_POST["filtro"];
			$campo  = $_POST["campo"];
			$this->dados = array('cliente' => $apiApollo->filtroClienteApollo($campo, $filtro));
			$_SESSION['filtro_cliente'] = array('filtro' => $_POST["filtro"], 'campo' => $_POST["campo"]);
		}else{
			unset($_SESSION['filtro_cliente']);
			if(isset($_SESSION['filtro_cliente']['filtro'])){
				$this->dados = array('cliente' => $apiApollo->filtroClienteApollo($_SESSION['filtro_sessao']['campo'], $_SESSION['filtro_sessao']['filtro']));
			}
		}
		
		$this->view();
	}
	
	
	public function excluir() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Exclus�o de Contrato";
		$contrato = new Contrato();
		$contrato->contrato = $this->getParams(0);
		$apiContrato = new apiContrato();
		$this->dados = array('contrato' => $apiContrato->getContrato($contrato));
		if (isset($this->dados['contrato'])){
			if ($this->dados['contrato']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'sgc/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'sgc/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$sql[$i] = $apiContrato->delContrato($contrato);
			$i = $i+1;
			$log = new Log();
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "E";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico = "CONTRATO||{$this->dados['contrato']->CONTRATO};;DES_CONTRATO||{$this->dados['contrato']->DES_CONTRATO};;ATIVO||{$this->dados['contrato']->ATIVO}";
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiContrato->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'sgc/contrato/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'sgc/contrato/index/sucesso');
				}
			}else{
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}
		$this->view();
	}
	
	
	
	
	
}
	