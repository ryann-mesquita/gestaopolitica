<?php

namespace controller\sgc;

use lib\Controller;
use helper\Security;

use api\sgc\apiIndice;
use helper\Paginator;
use obj\sgc\Indice;
use obj\geral\Log;
use api\geral\apiLog;
use helper\Funcoes;

class indiceController extends Controller {

	public function __construct() {

		parent::__construct();

		new Security($this->getModule(),$this->getController(),$this->getAction());
	}

	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Lista de Indice";
		$apiIndice =  new apiIndice();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		(!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])) ? $a = '1' : $a = '3';
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$busca = array(
					'1' => array('c' => '1','a' => $a,'coluna' => 'ativo', 'valor' => '1'),
					'2' => array('c' => '1','a' => $a,'coluna' => 'ativo', 'valor' => '0'),
					'3' => array('c' => '2','a' => $a,'coluna' => 'des_reduzida', 'valor' => $_POST['busca_valor']),
					'4' => array('c' => '3','a' => $a,'coluna' => 'des_indice', 'valor' => @$_POST['busca_valor']),
					'5' => array('c' => '4','a' => $a,'coluna' => "",'valor' => "")
			);
			if(isset($busca[$_POST['busca']])){
				$this->dados = array('indice' => $apiIndice->filtroIndice($busca[$_POST['busca']]['c'], $busca[$_POST['busca']]['a'], $busca[$_POST['busca']]['coluna'], $busca[$_POST['busca']]['valor']));
				$_SESSION['filtro_sessao'] = array('c' => $busca[$_POST['busca']]['c'], 'a' => $busca[$_POST['busca']]['a'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'valor' => $busca[$_POST['busca']]['valor'], 'busca' => $_POST['busca'], 'busca_valor' => isset($_POST['busca_valor']) ? $_POST['busca_valor'] : "");
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'sgc/index/index/acessonegado');
				die();
			}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				$this->dados = array('indice' => $apiIndice->filtroIndice($_SESSION['filtro_sessao']['c'],$_SESSION['filtro_sessao']['a'],$_SESSION['filtro_sessao']['coluna'], $_SESSION['filtro_sessao']['valor']));
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('indice' => $apiIndice->filtroIndice('1','3','ativo', '1'));
					$_SESSION['filtro_sessao'] = array('c' => '1', 'a' => '3', 'coluna' => 'ativo' , 'valor' => '1', 'busca' => '4', 'busca_valor' => '');
					$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}
		}
		$TotalItem = (is_array($this->dados['indice']) ? count($this->dados['indice']) : 0);
		$this->dados['indice'] = array_chunk($this->dados['indice'], $ItemPorPagina);
		@$this->dados['indice'] = $this->dados['indice'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		
		$this->view();
	}
	
	public function adicionar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Cadastro de Indice";
		$apiIndice = new apiIndice();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$Post = new Indice('POST');
			$apiIndice = new apiIndice();
			$rs = $apiIndice->filtroIndice('1','3','des_indice',$Post->des_indice);
			if ((is_array($rs) ? count($rs) : 0) > 0){
				$this->rollback = new Indice('POST');
				$this->Alert = "J� existe um tipo com esse nome cadastrado!";
			}else{
				$sql[$i] = $apiIndice->addIndice($Post);
				$i = $i+1;
				$log = new Log();
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico = "DES_INDICE||{$Post->des_indice};;ATIVO||{$Post->ativo}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiIndice->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'sgc/indice/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'sgc/indice/index/sucesso');
					}
				}else{
					$this->rollback = new Indice('POST');
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		
		$this->view();
	}
	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Altera��o de Indice";
		$indice = new Indice();
		$this->getParams(0);
		$indice->indice = $this->getParams(0);
		$apiIndice = new apiIndice();
		$this->dados = array('indice' => $apiIndice->getIndice($indice));
		if (isset($this->dados['indice'])){
			if ($this->dados['indice']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'sgc/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'sgc/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$anterior = "";
			$atual = "::";
			$funcoes = new Funcoes();
			$sql = array();
			$Post = new Indice();
			$Post->indice = $this->getParams(0);
			$rs = $apiIndice->filtroIndice('1','3','des_indice',$Post->des_indice);
			$log = new Log();
			if ((is_array($rs) ? count($rs) : 0) > 0 && ($rs[0]->DES_INDICE != $this->dados['indice']->DES_INDICE)){
				$this->dados['indice']->DES_INDICE = $_POST['des_indice'];
				$this->dados['indice']->DES_REDUZIDA = $_POST['des_reduzida'];
				$this->dados['indice']->ATIVO = $_POST['ativo'];
				$this->Alert = "J� existe um indice com esse nome cadastrado!";
			}else{
				$des_indice = strtoupper($funcoes->retiraAcentos(trim($_POST['des_indice'])));
				if ($this->dados['indice']->DES_INDICE != $des_indice){
					$Post->des_indice = $des_indice;
					$anterior .= "DES_INDICE||{$this->dados['indice']->DES_INDICE};;";
					$atual .= "DES_INDICE||{$Post->des_indice};;";
				}
				$des_reduzida = strtoupper($funcoes->retiraAcentos(trim($_POST['des_reduzida'])));
				if ($this->dados['indice']->DES_REDUZIDA != $des_reduzida){
					$Post->des_reduzida = $des_reduzida;
					$anterior .= "DES_REDUZIDA||{$this->dados['indice']->DES_REDUZIDA};;";
					$atual .= "DES_REDUZIDA||{$Post->des_reduzida};;";
				}
				if ($this->dados['indice']->ATIVO != $_POST['ativo']){
					$Post->ativo = $_POST['ativo'];
					$anterior .= "ATIVO||{$this->dados['indice']->ATIVO};;";
					$atual .= "ATIVO||{$Post->ativo};;";
				}
				if ($apiIndice->editIndice($Post) != ""){
					$sql[$i] = $apiIndice->editIndice($Post);
					$i = $i+1;
					$log->usuario = $_SESSION['usuario_sessao'];
					$log->modulo = $this->getModule()['modulo'];
					$log->controle = $this->getController()['controle'];
					$log->acao = $this->getAction()['acao'];
					$log->empresa = $_SESSION['empresa_sessao'];
					$log->tipo = "A";
					$log->dta_registro = date("d/m/Y H:i:s");
					$log->historico = substr($anterior,0,-2);
					$log->historico .= substr($atual,0,-2);
					$apiLog = new apiLog();
					$sql[$i] = $apiLog->addLog($log);
					$rs = $apiIndice->executeSQL($sql);
					if (@$rs[4] == 'sucesso') {
						if (isset($this->PaginaAtual)) {
							header('location:' .APP_ROOT. 'sgc/indice/index/pagina/'.$this->PaginaAtual.'/sucesso');
						}else {
							header('location:' .APP_ROOT. 'sgc/indice/index/sucesso');
						}
					}else{
						$this->dados['indice']->DES_INDICE = $_POST['des_indice'];
						$this->dados['indice']->DES_REDUZIDA = $_POST['des_reduzida'];
						$this->dados['indice']->ATIVO = $_POST['ativo'];
						$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
						$erro = str_replace($retirar, "", $rs[2]);
						$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
					}
				}else{
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'sgc/indice/index/pagina/'.$this->PaginaAtual.'/insucesso');
					}else {
						header('location:' .APP_ROOT. 'sgc/indice/index/insucesso');
					}
				}
			}
		}
		$this->view();
	}
		public function excluir() {
			$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
			$this->header = "Exclus�o de Indice";
			$indice = new Indice();
			$indice->indice = $this->getParams(0);
			$apiIndice = new apiIndice();
			$this->dados = array('indice' => $apiIndice->getIndice($indice));
			if (isset($this->dados['indice'])){
				if ($this->dados['indice']->ATIVO == '0'){
					if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
						header('location:' .APP_ROOT. 'sgc/index/index/acessonegado');
						die();
					}
				}
			}else{
				header('location:' .APP_ROOT. 'sgc/index/index/acessonegado');
				die();
			}
			$ItemPorPagina = 10;
			$PaginaAtual = 1;
			if ($this->getParams(1) > $PaginaAtual) {
				$PaginaAtual = $this->getParams(1);
				$this->PaginaAtual = $PaginaAtual;
			}
			if ($_SERVER['REQUEST_METHOD'] === 'POST') {
				$i = 0;
				$sql = array();
				$sql[$i] = $apiIndice->delIndice($indice);
				$i = $i+1;
				$log = new Log();
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "E";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico = "INDICE||{$this->dados['indice']->INDICE};;DES_INDICE||{$this->dados['indice']->DES_INDICE};;ATIVO||{$this->dados['indice']->ATIVO}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiIndice->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'sgc/indice/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'sgc/indice/index/sucesso');
					}
				}else{
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
			$this->view();
		}
	
	
	
	
	
	}
	
