<?php

namespace controller\sgc;

use lib\Controller;
use helper\Security;
use helper\Paginator;
use obj\sgc\Periodicidade;
use obj\geral\Log;
use api\geral\apiLog;
use helper\Funcoes;
use api\sgc\apiPeriodicidade;

class periodicidadeController extends Controller {
	
	public function __construct() {
		
		parent::__construct();
		
		new Security($this->getModule(),$this->getController(),$this->getAction());
	}
	
	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Lista de Periodicidade";
		$apiPeriodicidade =  new apiPeriodicidade();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		(!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])) ? $a = '1' : $a = '3';
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$busca = array(
					'1' => array('c' => '1','a' => $a,'coluna' => 'ativo', 'valor' => '1'),
					'2' => array('c' => '1','a' => $a,'coluna' => 'ativo', 'valor' => '0'),
					'3' => array('c' => '2','a' => $a,'coluna' => 'des_periodicidade', 'valor' => @$_POST['busca_valor']),
					'4' => array('c' => '3','a' => $a,'coluna' => "",'valor' => "")
			);
			if(isset($busca[$_POST['busca']])){
				$this->dados = array('periodicidade' => $apiPeriodicidade->filtroPeriodicidade($busca[$_POST['busca']]['c'], $busca[$_POST['busca']]['a'], $busca[$_POST['busca']]['coluna'], $busca[$_POST['busca']]['valor']));
				$_SESSION['filtro_sessao'] = array('c' => $busca[$_POST['busca']]['c'], 'a' => $busca[$_POST['busca']]['a'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'busca_valor' => $busca[$_POST['busca']]['valor'], 'busca' => $_POST['busca']);
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'sgc/index/index/acessonegado');
				die();
			}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				$this->dados = array('periodicidade' => $apiPeriodicidade->filtroPeriodicidade($_SESSION['filtro_sessao']['c'],$_SESSION['filtro_sessao']['a'],$_SESSION['filtro_sessao']['coluna'], $_SESSION['filtro_sessao']['busca_valor']));
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('periodicidade' => $apiPeriodicidade->filtroPeriodicidade('1','3','ativo', '1'));
					$_SESSION['filtro_sessao'] = array('c' => '1', 'a' => '3', 'coluna' => 'ativo' , 'busca_valor' => '1', 'busca' => '4');
					$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}
		}
		$TotalItem = (is_array($this->dados['periodicidade']) ? count($this->dados['periodicidade']) : 0);
		$this->dados['periodicidade'] = array_chunk($this->dados['periodicidade'], $ItemPorPagina);
		@$this->dados['periodicidade'] = $this->dados['periodicidade'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->view();
	}
	
	public function adicionar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Cadastro de Periodicidade";
		$apiPeriodicidade = new apiPeriodicidade();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$Post = new Periodicidade('POST');
			$apiPeriodicidade = new apiPeriodicidade();
			$rs = $apiPeriodicidade->filtroPeriodicidade('1','3','des_periodicidade',$Post->des_periodicidade);
			if ((is_array($rs) ? count($rs) : 0) > 0 ){
				$this->rollback = new Tipo('POST');
				$this->Alert = "J� existe um periodo com esse nome cadastrado!";
			}else{
				$sql[$i] = $apiPeriodicidade->addPeriodicidade($Post);
				$i = $i+1;
				$log = new Log();
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico = "DES_PERIODICIDADE||{$Post->des_periodicidade};;ATIVO||{$Post->ativo}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiPeriodicidade->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'sgc/periodicidade/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'sgc/periodicidade/index/sucesso');
					}
				}else{
					$this->rollback = new Periodicidade('POST');
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		
		$this->view();
	}
	
	
	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Altera��o de Periodicidade";
		$periodicidade = new Periodicidade();
		$this->getParams(0);
		$periodicidade->periodicidade = $this->getParams(0);
		$apiPeriodicidade = new apiPeriodicidade();
		$this->dados = array('periodicidade' => $apiPeriodicidade->getPeriodicidade($periodicidade));
		if (isset($this->dados['periodicidade'])){
			if ($this->dados['periodicidade']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'sgc/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'sgc/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$anterior = "";
			$atual = "::";
			$funcoes = new Funcoes();
			$sql = array();
			$Post = new Periodicidade();
			$Post->periodicidade = $this->getParams(0);
			$rs = $apiPeriodicidade->filtroPeriodicidade('1','3','des_periodicidade',$Post->des_periodicidade);
			$log = new Log();
			if ((is_array($rs) ? count($rs) : 0) > 0 && ($rs[0]->DES_PERIODICIDADE != $this->dados['periodicidade']->DES_PERIODICIDADE)){
				$this->dados['periodicidade']->DES_PERIODICIDADE = $_POST['des_periodicidade'];
				$this->dados['periodicidade']->ATIVO = $_POST['ativo'];
				$this->Alert = "J� existe um periodo com esse nome cadastrado!";
			}else{
				$des_periodicidade = strtoupper($funcoes->retiraAcentos(trim($_POST['des_periodicidade'])));
				if ($this->dados['periodicidade']->DES_PERIODICIDADE != $des_periodicidade){
					$Post->des_periodicidade = $des_periodicidade;
					$anterior .= "DES_PERIODICIDADE||{$this->dados['periodicidade']->DES_PERIODICIDADE};;";
					$atual .= "DES_PERIODICIDADE||{$Post->des_periodicidade};;";
				}
				if ($this->dados['periodicidade']->ATIVO != $_POST['ativo']){
					$Post->ativo = $_POST['ativo'];
					$anterior .= "ATIVO||{$this->dados['periodicidade']->ATIVO};;";
					$atual .= "ATIVO||{$Post->ativo};;";
				}
				if ($apiPeriodicidade->editPeriodicidade($Post) != ""){
					$sql[$i] = $apiPeriodicidade->editPeriodicidade($Post);
					$i = $i+1;
					$log->usuario = $_SESSION['usuario_sessao'];
					$log->modulo = $this->getModule()['modulo'];
					$log->controle = $this->getController()['controle'];
					$log->acao = $this->getAction()['acao'];
					$log->empresa = $_SESSION['empresa_sessao'];
					$log->tipo = "A";
					$log->dta_registro = date("d/m/Y H:i:s");
					$log->historico = substr($anterior,0,-2);
					$log->historico .= substr($atual,0,-2);
					$apiLog = new apiLog();
					$sql[$i] = $apiLog->addLog($log);
					$rs = $apiPeriodicidade->executeSQL($sql);
					if (@$rs[4] == 'sucesso') {
						if (isset($this->PaginaAtual)) {
							header('location:' .APP_ROOT. 'sgc/periodicidade/index/pagina/'.$this->PaginaAtual.'/sucesso');
						}else {
							header('location:' .APP_ROOT. 'sgc/periodicidade/index/sucesso');
						}
					}else{
						$this->dados['periodicidade']->DES_PERIODICIDADE = $_POST['des_periodicidade'];
						$this->dados['periodicidade']->ATIVO = $_POST['ativo'];
						$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
						$erro = str_replace($retirar, "", $rs[2]);
						$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
					}
				}else{
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'sgc/periodicidade/index/pagina/'.$this->PaginaAtual.'/insucesso');
					}else {
						header('location:' .APP_ROOT. 'sgc/periodicidade/index/insucesso');
					}
				}
			}
		}
		$this->view();
	}
	
	public function excluir() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Exclus�o de Periodicidade";
		$periodicidade = new Periodicidade();
		$periodicidade->periodicidade = $this->getParams(0);
		$apiPeriodicidade = new apiPeriodicidade();
		$this->dados = array('periodicidade' => $apiPeriodicidade->getPeriodicidade($periodicidade));
		if (isset($this->dados['periodicidade'])){
			if ($this->dados['periodicidade']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'sgc/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'sgc/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$sql[$i] = $apiPeriodicidade->delPeriodicidade($periodicidade);
			$i = $i+1;
			$log = new Log();
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "E";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico = "PERIODICIDADE||{$this->dados['periodicidade']->PERIODICIDADE};;DES_PERIODICIDADE||{$this->dados['periodicidade']->DES_PERIODICIDADE};;ATIVO||{$this->dados['periodicidade']->ATIVO}";
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiPeriodicidade->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'sgc/periodicidade/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'sgc/periodicidade/index/sucesso');
				}
			}else{
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}
		$this->view();
	}
	
	
}