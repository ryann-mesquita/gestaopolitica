<?php

namespace controller\geral;

use lib\Controller;
use obj\adm\Usuario;
use obj\ptc\Cheque;
use obj\ptc\Lote;
use api\adm\apiUsuario;
use helper\Funcoes;
use api\geral\apiApollo;
use api\ged\apiGrupo;
use api\monaco\apiDisc;
use api\gpj\apiReclamante;
use api\geral\apiFuncionario;
use obj\geral\Visita;
use api\home\apiAuth;
use api\ptc\apiCheque;
use api\ptc\apiLote;
use obj\sie\Frota;
use obj\sie\Infracao;
use obj\sie\Revisao;
use api\sie\apiFrota;
use api\sie\apiPassagem;
use obj\sie\Taxa;
use obj\sie\Passagem;
use api\sie\apiHospedagem;
use obj\sie\Custo;
use obj\sie\Hospedagem;
use obj\home\Sorteio;
use api\home\apiSorteio;
use obj\home\codigo;
use classes\PHPMailer;
use obj\finan\Rgm;
use api\finan\apiRgm;

include 'classes/PHPMailer/class.phpmailer.php';


class ajaxController extends Controller{

	public function __construct(){

		parent::__construct();
	}

	public function ajaxempresa() {
		$emp = $_POST['emp'];
		unset($_SESSION['empresa_sessao']);
		$_SESSION['empresa_sessao'] = $emp;
		echo $_SESSION['empresa_sessao'];
	}
	
	public function ajaxtempo() {
		if (isset($_POST['tempo'])){
			$_SESSION['tempo_sessao'] = $_SESSION['tempo_sessao'] + (time() - $_SESSION['tempo_sessao']);
		}else{
			echo $_SESSION['tempo_sessao'];
		}
	}
	
	public function ajaxaltsenha() {
		if (!empty($_POST)) {
			$output = '';
			$usuario = new Usuario();
			$usuario->usuario = $_SESSION['usuario_sessao'];
			$apiUsuario = new apiUsuario();
			$rs = $apiUsuario->getUsuario($usuario);
	
			if (md5($_POST['senha_atual']) == $rs->SENHA) {
				$maiusculo = preg_match('@[A-Z]@', $_POST['senha']);
				$minusculo = preg_match('@[a-z]@', $_POST['senha']);
				$numero    = preg_match('@[0-9]@', $_POST['senha']);	
				if(!$maiusculo || !$minusculo || !$numero || strlen($_POST['senha_atual']) < 8) {
					$output .= "<span class='glyphicon glyphicon-exclamation-sign' aria-hidden='true'></span><span class='sr-only center'>Error:</span>A senha n�o possui os requisitos minimos!";
				}else {
					$sql = array();
					$usuario->senha = md5($_POST['senha']);
					$sql[0] = $apiUsuario->editUsuario($usuario);
					$rs = $apiUsuario->executeSQL($sql);
					if ($rs[4] == 'sucesso'){
						$output .= 'sucesso';
					}
				}
			}else {
				$output .= "<span class='glyphicon glyphicon-exclamation-sign' aria-hidden='true'></span><span class='sr-only center'>Error:</span>A senha atual n�o condiz com a senha cadastrada!";
			}
			echo $output;
		}
	}

	public function ajaxusuario() {
		$endereco = explode('=', $_SERVER ['REQUEST_URI']);
		$term = str_replace("+", " ", end($endereco));
		$apiUsuario = new apiUsuario();
		$usuario = $apiUsuario->filtroUsuario("2","1","nome",$term);
		if ((is_array($usuario) ? count($usuario) : 0) > 0){
			$funcoes = new Funcoes();
			$json = array();
			foreach ($usuario as $rs) {
				$json[] = array('label'=>$funcoes->retiraAcentos($rs->NOME."(".$rs->DES_EMPRESA.")"),'value'=>$rs->USUARIO);
			}
			echo json_encode($json);
		}
	}

	public function ajaxclientepf() {
		// Recebe os par�metros enviados via GET
		$endereco = explode('=', $_SERVER ['REQUEST_URI']);
		$funcoes = new Funcoes();
		$term = $funcoes->naoNumerico(str_replace("+", " ", end($endereco)));
		if (strlen($term) > 4) {
			$apiApollo= new apiApollo();
			$cliente = $apiApollo->getClientepf($term);
			if ((is_array($cliente) ? count($cliente) : 0) > 0){	
				$json = array();
				foreach ($cliente as $rs) {
					$json[] = array('label'=>$funcoes->retiraAcentos($rs->NOME." - ".$rs->CPF), 'value'=>$rs->CPF);
				}	
				echo json_encode($json);	
			}
		}
	}
	
	public function ajaxclientepj() {
		// Recebe os par�metros enviados via GET
		$endereco = explode('=', $_SERVER ['REQUEST_URI']);
		$funcoes = new Funcoes();
		$apiApollo = new apiApollo();
		$term = $funcoes->naoNumerico(str_replace("%2F", "", end($endereco)));
		if (strlen($term) > 3) {
			$cliente = $apiApollo->getClientepj($term);
			if (count($cliente) > 0){
				$json = array();
				foreach ($cliente as $rs) {
					$json[] = array('label'=>$funcoes->retiraAcentos($rs->NOME." - ".$rs->CNPJ), 'value'=>$rs->CNPJ);
				}
				echo json_encode($json);
			}
		}
	}
	
	public function ajaxusuariogrupo() {
		$endereco = explode('=', $_SERVER ['REQUEST_URI']);
		$term = str_replace("+", " ", end($endereco));
		$term = urldecode($term);
		if($term[0] == "#"){
			$term = substr($term, 1);
			$apiGrupo = new apiGrupo();
			$grupo = $apiGrupo->filtroGrupo('2','1','des_reduzida',$term);
			if ((is_array($grupo) ? count($grupo) : 0) > 0){
				$json = array();
				foreach ($grupo as $rs) {
					$json[] = array('label'=>$rs->DES_REDUZIDA, 'value'=>"#".$rs->GRUPO);
				}
				echo json_encode($json);	
			}
		}else {
			$apiUsuario = new apiUsuario();
			$usuario = $apiUsuario->filtroUsuario("2","1","nome",$term);
			if ((is_array($usuario) ? count($usuario) : 0) > 0){
				$funcoes = new Funcoes();
				$json = array();
				foreach ($usuario as $rs) {
					$json[] = array('label'=>$funcoes->retiraAcentos($rs->NOME." ".$rs->DES_EMPRESA),'value'=>$rs->USUARIO);
				}
				echo json_encode($json);
			}	
		}
	}
	
	public function ajaxfuncionario() {
		$endereco = explode('=', $_SERVER ['REQUEST_URI']);
		$term = str_replace("+", " ", end($endereco));
		$apiUsuario = new apiUsuario();
		$empresa = $_SESSION['empresa_sessao'];
		$usuario = $apiUsuario->filtroUsuario("2","4","nome",$term,$empresa);
		if ((is_array($usuario) ? count($usuario) : 0) > 0){
			$funcoes = new Funcoes();
			$json = array();
			foreach ($usuario as $rs) {
				$json[] = array('label'=>$funcoes->retiraAcentos($rs->NOME),'value'=>$rs->CPF);
			}
			echo json_encode($json);
		}
	}
	
	public function ajaxavaliado() {
		$endereco = explode('=', $_SERVER ['REQUEST_URI']);
		$term = strtoupper(str_replace("+", " ", end($endereco)));
		$apiDisc = new apiDisc();
		$empresa = $_SESSION['empresa_sessao'];
		$avaliado = $apiDisc->getPessoaavaliada($empresa,$term);
		if ((is_array($avaliado) ? count($avaliado) : 0) > 0){
			$json = array();
			foreach ($avaliado as $rs) {
				$json[] = array('label'=>$rs->NOME,'value'=>$rs->PESSOA);
			}
			echo json_encode($json);
		}
	}
	
	public function ajaxreclamanteinterno() {
		$endereco = explode('=', $_SERVER ['REQUEST_URI']);
		$term = str_replace("+", " ", end($endereco));
		$apiUsuario = new apiUsuario();
		if ($this->getParams(0) == "data") {
			$var = $this->getParams(1);
			$usuario = $apiUsuario->filtroUsuario("1","3","usuario",$var);
			if ((is_array($usuario) ? count($usuario) : 0) > 0){
				$funcoes = new Funcoes();
				$rs = array();
				$rs[0] = $funcoes->retiraAcentos($usuario[0]->NOME);
				$rs[1] = $usuario[0]->DEPARTAMENTO;
				$rs[2] = $usuario[0]->CPF;	
				echo json_encode($rs);
			}
		}else{
			$usuario = $apiUsuario->filtroUsuario("2","3","nome",$term);
			if ((is_array($usuario) ? count($usuario) : 0) > 0){
				$funcoes = new Funcoes();
				$json = array();
				foreach ($usuario as $rs) {
					$json[] = array('label'=>$funcoes->retiraAcentos($rs->NOME),'value'=>$rs->USUARIO);
				}
				echo json_encode($json);
			}
		}
	}
	
	public function ajaxreclamanteexterno() {
		$endereco = explode('=', $_SERVER ['REQUEST_URI']);
		$term = str_replace("+", " ", end($endereco));
		$apiReclamante = new apiReclamante();
		if ($this->getParams(0) == "data") {
			$var = $this->getParams(1);
			$reclamante = $apiReclamante->filtroReclamante("1","3","reclamante",$var);
			if ((is_array($reclamante) ? count($reclamante) : 0) > 0){
				$funcoes = new Funcoes();
				$rs = array();
				$rs[0] = $funcoes->retiraAcentos($reclamante[0]->NOME);
				$rs[1] = $reclamante[0]->DEPARTAMENTO;
				$rs[2] = $reclamante[0]->RECLAMANTE;
				echo json_encode($rs);
			}
		}else{
			$reclamante = $apiReclamante->filtroReclamante("2","3","nome",$term);
			if ((is_array($reclamante) ? count($reclamante) : 0) >= 1){
				$funcoes = new Funcoes();
				$json = array();
				foreach ($reclamante as $rs) {
					$json[] = array('label'=>$funcoes->retiraAcentos($rs->NOME),'value'=>$rs->RECLAMANTE);
				}
				echo json_encode($json);
			}
		}
	}
	
	public function ajaxsolicitante() {
		$endereco = explode('=', $_SERVER ['REQUEST_URI']);
		$term = str_replace("+", " ", end($endereco));
		$apiUsuario = new apiUsuario();
		if ($this->getParams(0) == "data") {
			$var = $this->getParams(1);
			$usuario = $apiUsuario->filtroUsuario("1","3","usuario",$var);
			if ((is_array($usuario) ? count($usuario) : 0) > 0){
				$funcoes = new Funcoes();
				$rs = array();
				$rs[0] = $usuario[0]->DEPARTAMENTO;
				$rs[1] = $usuario[0]->TIPO;
				echo json_encode($rs);
			}
		}else{
			$usuario = $apiUsuario->filtroUsuario("2","1","nome",$term);
			if ((is_array($usuario) ? count($usuario) : 0) > 0){
				$funcoes = new Funcoes();
				$json = array();
				foreach ($usuario as $rs) {
					$json[] = array('label'=>$funcoes->retiraAcentos($rs->NOME),'value'=>$rs->USUARIO);
				}
				echo json_encode($json);
			}
		}
	}
	public function ajaxautorinfracao() {
		$endereco = explode('=', $_SERVER ['REQUEST_URI']);
		$term = str_replace("+", " ", end($endereco));
		$apiUsuario = new apiUsuario();
		if ($this->getParams(0) == "data") {
			$var = $this->getParams(1);
			$usuario = $apiUsuario->filtroUsuario("1","3","usuario",$var);
			if ((is_array($usuario) ? count($usuario) : 0) > 0){
				$funcoes = new Funcoes();
				$rs = array();
				$rs[0] = $usuario[0]->DEPARTAMENTO;
				$rs[1] = $usuario[0]->TIPO;
				echo json_encode($rs);
			}
		}else{
			$usuario = $apiUsuario->filtroUsuario("2","6","nome",$term);
			if ((is_array($usuario) ? count($usuario) : 0) > 0){
				$funcoes = new Funcoes();
				$json = array();
				foreach ($usuario as $rs) {
					$json[] = array('label'=>$funcoes->retiraAcentos($rs->NOME),'value'=>$rs->USUARIO);
				}
				echo json_encode($json);
			}
		}
	}
	
	public function ajaxmprp() {
		$endereco = explode('=', $_SERVER ['REQUEST_URI']);
		$term = str_replace("+", " ", end($endereco));
		$apiUsuario = new apiUsuario();
		if ($this->getParams(0) == "mpd") {
			$var = $this->getParams(1);
			$usuario = $apiUsuario->filtroUsuario("1","3","usuario",$var);
			if ((is_array($usuario) ? count($usuario) : 0) > 0){
				$funcoes = new Funcoes();
				$rs = array();
				$rs[0] = $usuario[0]->NOME;
				$rs[1] = $usuario[0]->DTA_ADMISSAO;
				echo json_encode($rs);
			}
		}elseif ($this->getParams(0) == "mpm"){
			$var = $this->getParams(1);
			$usuario = $apiUsuario->filtroUsuario("1","3","usuario",$var);
			if ((is_array($usuario) ? count($usuario) : 0) > 0){
				$funcoes = new Funcoes();
				$rs = array();
				$rs[0] = $usuario[0]->NOME;
				$rs[1] = $usuario[0]->DTA_ADMISSAO;
				$rs[2] = $usuario[0]->CARGO;
				$rs[3] = $usuario[0]->DEPARTAMENTO;
				$rs[4] = $usuario[0]->EMPRESA;
				echo json_encode($rs);
			}
		}elseif ($this->getParams(0) == "rp"){
			$var = $this->getParams(1);
			$usuario = $apiUsuario->filtroUsuario("1","3","usuario",$var);
			if ((is_array($usuario) ? count($usuario) : 0) > 0){
				$funcoes = new Funcoes();
				$rs = array();
				$rs[0] = $usuario[0]->DTA_ADMISSAO;
				echo json_encode($rs);
			}
		}else{
			$usuario = $apiUsuario->filtroUsuario("2","3","nome",$term);
			if ((is_array($usuario) ? count($usuario) : 0) > 0){
				$funcoes = new Funcoes();
				$json = array();
				foreach ($usuario as $rs) {
					$json[] = array('label'=>$funcoes->retiraAcentos($rs->NOME),'value'=>$rs->USUARIO);
				}
				echo json_encode($json);
			}
		}
	}
	
	public  function ajaxdestinatarios(){
		$val = $this->getParams(0);
		if ($this->getParams(1) != ""){
			$tipo = $this->getParams(1);
		}else{
			$tipo = $_SESSION['tipo_sessao'];
		}
		$apiUsuario = new apiUsuario();
		$usuario = $apiUsuario->getUsuariosdestinatarios($_SESSION['empresa_sessao'], $val, $tipo);		
		echo "<option value=''>Selecione</option>";			
		foreach ($usuario as $rs){
			echo "<option value='{$rs->USUARIO}'>{$rs->NOME}</option>";
		}
	}
	public  function ajaxdestinatariosdp(){
		$val = $this->getParams(0);
		if ($this->getParams(1) != ""){
			$tipo = $this->getParams(1); 
		}else{
			$tipo = $_SESSION['tipo_sessao'];
		}
		$apiUsuario = new apiUsuario();
		$usuario = $apiUsuario->getUsuariosdestinatariosdp($_SESSION['empresa_sessao'], $val, $tipo);
		echo "<option value=''>Selecione</option>";			
		foreach ($usuario as $rs){
			echo "<option value='{$rs->USUARIO}'>{$rs->NOME}</option>";
		}
	}
	
	public function removecheque(){
		$endereco = explode('=', $_SERVER ['REQUEST_URI']);
		$term = str_replace("+", " ", end($endereco));
		$term1 = str_replace("+", " ", $endereco);
		$lote_id   = substr($term1[2],0,-6);
		$cheque_id = substr($term1[1], 0, 30);
		
		//echo substr('abcdef', 1);
		
		$tlote = $term;
		if ($tlote == "lote"){
			$funcoes = new Funcoes();
			$i=0;
			$sql=array();
			$cheque    = new Cheque();
			$lote      = new Lote();
			$lote->empresa_origem = $_SESSION['empresa_sessao'];
			
			$lote->lote =  $lote_id;
			$cheque->cheque = $cheque_id;
			$cheque->lote = $lote_id;
			$apiCheque = new apiCheque();
			$apiLote   = new apiLote();
			$rs1  = $apiCheque->getChequeUnidade($cheque, $lote);
			$rs2 = $apiLote->getLote($lote);
			

			$valortotal = $funcoes->sanearValor($rs2->VAL_LOTE) - $funcoes->sanearValor($rs1[0]->VALOR);
		//	var_dump($valortotal);die();
			$lote->val_lote = $valortotal;
			$sql[$i] = $apiLote->valorLote($lote);
			$i = $i+1;
			$sql[$i] = $apiCheque->delCheque($cheque);
			
			$rs = $apiCheque->executeSQL($sql);
			echo number_format($valortotal, 2, ",", ".");
		}
		
	}
	
	public function removeinfracao(){
		$term = explode('=', $endereco = $_SERVER ['REQUEST_URI']);
		$term = end($term);
		$term = str_replace("+", "", $term);
		$term1 = str_replace("+", " ", explode('=', $endereco = $_SERVER ['REQUEST_URI']));
		$infracao_veiculo = substr($term1[1], 0, -6);
		$veiculo = substr($term1[2], 0, -7);
		
		$tfrota = $term;
		if ($tfrota == "frota"){

		$i=0;
		$sql=array();
		$frota = new Frota();
		$apiFrota = new apiFrota();
		$infracao = new Infracao();
		$infracao->infracao = $infracao_veiculo;
		$infracao->veiculo  = $veiculo;
		$unidadeInfracao = $apiFrota->getUnidadeInfracao($infracao);
		$sql[$i] = $apiFrota->delInfracao($infracao);
		$rs = $apiFrota->Execute($sql);
		unlink($_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/sie/".$unidadeInfracao->ANEXO);
	}
}
	
	public function removerevisao(){
		$term = explode('=', $endereco = $_SERVER ['REQUEST_URI']);
		$term = end($term);
		$term = str_replace("+", "", $term);
		
		$term1 = str_replace("+", " ", explode('=', $endereco = $_SERVER ['REQUEST_URI']));
		$revisao_veiculo = substr($term1[1], 0, -6);
		$veiculo = substr($term1[2], 0, -7);
		$tfrota = $term;
		if ($tfrota == "frota"){
			
			$i=0;
			$sql=array();
			$frota = new Frota();
			$apiFrota = new apiFrota();
			$revisao = new Revisao();
			$revisao->revisao = $revisao_veiculo;
			$revisao->veiculo  = $veiculo;
			
			$unidadeRevisao = $apiFrota->getUnidadeRevisao($revisao);
			$sql[$i] = $apiFrota->delRevisao($revisao);
			$rs = $apiFrota->Execute($sql);
			unlink($_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/sie/".$unidadeRevisao->ANEXO);
			
		}
	}		
	public function removetaxa(){
		$term = explode('=', $endereco = $_SERVER ['REQUEST_URI']);
		$term = end($term);
		$term = str_replace("+", "", $term);
		
		$term1 = str_replace("+", " ", explode('=', $endereco = $_SERVER ['REQUEST_URI']));
		$taxa_passagem = substr($term1[1], 0, -5);
		$pass = substr($term1[2], 0, -6);
		$ttaxa = $term;
		if ($ttaxa == "taxa"){
			$i=0;
			$sql=array();
			$apiPassagem = new apiPassagem();
			$taxa = new Taxa();
			$passagem = new Passagem();
			$passagem->passagem = $pass;
			$passagem= $apiPassagem->getPassagem($passagem);
		
			
			$taxa->taxa = $taxa_passagem;
			$taxa->passagem  = $pass;       
			$taxa_banco = $apiPassagem->getTaxaUnidade($taxa);
		//	var_dump($passagem->TOTAL - $taxa_banco->VALOR);die();
			@$valorTotal = $passagem->TOTAL - $taxa_banco->VALOR;
			$passagem = new Passagem();
			$passagem->total = @$valorTotal;
			$passagem->passagem = $pass;
			$sql[$i] = $apiPassagem->valorTotalPassagem($passagem);
			$i=$i+1;
			$sql[$i] = $apiPassagem->delTaxa($taxa);
			$rs = $apiPassagem->Execute($sql);
		}
	}		
	public function removecusto(){
		$term = explode('=', $endereco = $_SERVER ['REQUEST_URI']);
		$term = end($term);
		$term = str_replace("+", "", $term);
		
		$term1 = str_replace("+", " ", explode('=', $endereco = $_SERVER ['REQUEST_URI']));
		$custo_hospedagem = substr($term1[1], 0, -6);
		$hosp = substr($term1[2], 0, -7);
		$tcusto = $term;
		if ($tcusto == "custo"){
			$i=0;
			$sql=array();
			$apiHospedagem = new apiHospedagem();
			$custo = new Custo();
			$hospedagem = new Hospedagem();
			$hospedagem->hospedagem = $hosp;
			$hospedagem = $apiHospedagem->getHospedagem($hospedagem);
		
			
			$custo->custo = $custo_hospedagem;
			$custo->hospedagem  = $hosp;       
			$custo_banco = $apiHospedagem->getCustoUnidade($custo);
		//	var_dump($passagem->TOTAL - $taxa_banco->VALOR);die();
			@$valorTotal = $hospedagem->TOTAL - $custo_banco->VALOR;
			$hospedagem = new Hospedagem();
			$hospedagem->total = @$valorTotal;
			$hospedagem->hospedagem = $hosp;
			$sql[$i] = $apiHospedagem->valorTotalHospedagem($hospedagem);
			$i=$i+1;
			$sql[$i] = $apiHospedagem->delCusto($custo);
			$rs = $apiHospedagem->Execute($sql);
		}
	}		
	
	public  function ajaxbancousuario(){
		$apiUsuario = new apiUsuario();
		$usuario = $apiUsuario->getUsuariobanco($_SESSION['usuario_sessao']);
		if ((is_array($usuario) ? count($usuario) : 0) > 0){
			$rs = array();
			$rs[0] = $usuario[0]->CPF;
			$rs[1] = $usuario[0]->NOME;
			$rs[2] = $usuario[0]->NROBANCO;
			if ($usuario[0]->NROBANCO == '001'){
				$rs[3] = $usuario[0]->NROAGENCIA."-".$usuario[0]->DIGITOAGENCIA;
				$exp = explode("-", $usuario[0]->CONTACORRENTE);
				$dig = (isset($exp[1])) ?  "-{$exp[1]}" : "";
				$rs[4] = str_pad($exp[0], 8, "0", STR_PAD_LEFT).$dig;
			}elseif ($usuario[0]->NROBANCO == '237'){
				$rs[3] = $usuario[0]->NROAGENCIA."-".$usuario[0]->DIGITOAGENCIA;
				$exp = explode("-", $usuario[0]->CONTACORRENTE);
				$dig = (isset($exp[1])) ?  "-{$exp[1]}" : "";
				$rs[4] = str_pad($exp[0], 7, "0", STR_PAD_LEFT).$dig;
			}elseif ($usuario[0]->NROBANCO == '341'){
				$rs[3] = $usuario[0]->NROAGENCIA;
				$exp = explode("-", $usuario[0]->CONTACORRENTE);
				$dig = (isset($exp[1])) ?  "-{$exp[1]}" : "";
				$rs[4] = str_pad($exp[0], 5, "0", STR_PAD_LEFT).$dig;
			}
			
			echo json_encode($rs);
		}
	}
	public function ajaxvalidaemail(){
		$email = $this->getParams(0);
		$apiFuncionario = new apiFuncionario();
		$rs = $apiFuncionario->validaEmail($email);
		if ((is_array($rs) ? count($rs) : 0) > 0){
			echo "<font color='red'>E-mail J� Utilizado!</font>";
		}else{
			echo "<font color='green'>E-mail Dispon�vel</font>";
		}
	}
	
	public function ajaxvisitalead(){
		$funcoes = new Funcoes();
		$limite = 3600;
		$visita = new Visita();
		$source = $_POST['endereco'];
		if ($source == 'facebook'){
			$endereco = "http://www.grupomonaco.net.br/sismonaco/auth/fiat/facebook";
		}else{
			$endereco = "http://www.grupomonaco.net.br/sismonaco/auth/fiat";
		}
		$visita->endereco = $endereco;
		$visita->ip = $funcoes->naoNumerico($_SERVER['REMOTE_ADDR']);
		$visita->data = date('d/m/Y');
		$visita->hora = date('H:i');
		$visita->forma_interacao = $_POST['forma_interacao'];
		$apiAuth = new apiAuth();
		$sql[0] = $apiAuth->addVisita($visita);
		$rs = $apiAuth->executeSQL($sql);
		
		/*$result = $apiAuth->getVisita('1', $visita->ip, $visita->data);
		if (count($result) == 0){
			$sql[0] = $apiAuth->addVisita($visita);
			$rs = $apiAuth->executeSQL($sql);
		}else{
			$horaDB = strtotime($result[0]->HORA);
			$horaAtual = strtotime($visita->hora);
			$horaSubtracao = $horaAtual-$horaDB;
			if ($horaSubtracao > $limite){
				$sql[0] = $apiAuth->addVisita($visita);
				$rs = $apiAuth->executeSQL($sql);
			}
		}*/
		
	}
	public function ajaxabafinan() {
		$aba = $_POST['aba'];
		unset($_SESSION['aba_finan_sessao']);
		$_SESSION['aba_finan_sessao'] = $aba;
	}
	
	public function ajaxsorteio(){
		$funcoes = new Funcoes();
		$endereco = explode('=', $_SERVER ['REQUEST_URI']);
		$aceito = $endereco[1];
		
		if($aceito == 1){
			$usuario = new Usuario();
			$codigo = new Codigo();
			$apiUsuario = new apiUsuario();
			$apiSorteio = new apiSorteio();
			$funcoes = new Funcoes();
			$i=0;
			$sql=array();
			
			$usuario->usuario = $_SESSION['usuario_sessao'];
			$this->usuario = $apiUsuario->getUsuario($usuario);

			$cod = $apiSorteio->getCodigo();
			$codigo->codigo = $cod[0]->CODIGO;
			$codigo->status = 1;
			$codigo->usuario = $_SESSION['usuario_sessao'];
			$sql[$i] = $apiSorteio->editSorteio($codigo);
			$rs = $apiSorteio->Execute($sql);

			if($rs[4] == 'sucesso'){
				$Host = "email-ssl.com.br";
				$IsHTML = true;
				$SMTPAuth = true;
				$SMTPSecure = "ssl";
				$Username = 'helpdesk@grupomonaco.com.br';
				$Password = '4dM.grup0.D0mR';
				$Port = 465;
				
				$email = new PHPMailer();
				$email->IsSMTP();
				$email->Host = $Host;
				$email->IsHTML($IsHTML);
				$email->SMTPAuth = $SMTPAuth;
				$email->SMTPSecure = $SMTPSecure;
				
				$email->Username = $Username;
				$email->Password = $Password;
				$email->Port = $Port;
				
				$email->From = $Username;
				$email->FromName  = "SisMonaco - HelpDesk";
				$email->Subject = "Sorteio Grupo Monaco";
				
				$mensagem  = "<html>
							  	<head></head>
								<body>
									<style type='text/css'>
										.fieldset {
										  border: 1px solid #ddd;
										  margin-top: 1em;
										  width: 500px;
										}
										.fieldset h3 {
										  font-size: 12px;
										  text-align: center;
										}
										.fieldset h3 span {
										  display: inline;
										  border: 1px solid #ddd;
										  background: #fff;
										  padding: 5px 10px;
										  position: relative;
										  top: -1.3em;
										}
									</style>
									<p><h3><b>Sorteio Grupo Monaco</b></h3></p>";
				$cod = $apiSorteio->getLastIdSorteio($codigo);
				$mensagem .= "<div class='fieldset'><h3><span>C�digo do Sorteio: 1/{$cod->CODIGO}</span></h3>";
				$mensagem .= "<p>CPF: {$this->usuario->CPF}<br>";
				$mensagem .= "Nome: {$this->usuario->NOME}<br>";
				$mensagem .= "Email: {$this->usuario->EMAIL}<br>";
				$mensagem .= "Empresa: {$this->usuario->DES_EMPRESA}<br>";
				$mensagem .= "</div>";
				$mensagem .= "</body></html>";
				
				$email->MsgHTML($mensagem);
				$email->AddAddress("{$this->usuario->EMAIL}");
				$email->Send();
				$email->ClearAllRecipients();
				$email->ClearAttachments();
				
				
				echo json_encode($cod->CODIGO);
			}			
		}
	}
	public function ajaxrgm(){
		$funcoes = new Funcoes();
		$rgm = new Rgm();
		$endereco = explode('=', $_SERVER ['REQUEST_URI']);
		$aceito = $endereco[1];
		if($aceito == 1){
		$i=0;
		$sql=array();
		$usuario = new Usuario();
		$apiUsuario = new apiUsuario();
		$usuario->usuario = $_SESSION['usuario_sessao'];
		$this->usuario = $apiUsuario->getUsuario($usuario);
		
		$rgm->usuario = $this->usuario->USUARIO;
		$rgm->dta_cadastro = date("d/m/Y H:i:s");
		$rgm->rgm = 1;
		$rgm->aceito = $aceito;
		$apiRgm = new apiRgm();
		$sql[$i] = $apiRgm->addRgm($rgm);
		$rs = $apiRgm->Execute($sql);
		echo json_encode($this->usuario->NOME);
	
	}
 }
	
}
