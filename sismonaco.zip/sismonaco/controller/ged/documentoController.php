<?php

namespace controller\ged;

use lib\Controller;
use helper\Security;
use api\ged\apiDocumento;
use helper\Paginator;
use obj\ged\Documento;
use obj\geral\Log;
use api\geral\apiLog;
use api\ged\apiAviso;
use api\ged\apiOrgao;
use helper\Funcoes;

class documentoController extends Controller {
	
	public function __construct() {
		
		parent::__construct();
		
		new Security($this->getModule(),$this->getController(),$this->getAction());
	}
	
	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Lista de Documentos";
		$apiDocumento = new apiDocumento();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		(!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])) ? $a = '1' : $a = '3';
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$busca = array(
					'1' => array('c' => '1','a' => $a,'coluna' => 'ativo', 'valor' => '1'),
					'2' => array('c' => '1','a' => $a,'coluna' => 'ativo', 'valor' => '0'),
					'3' => array('c' => '2','a' => $a,'coluna' => 'documento', 'valor' => $_POST['busca_texto']),
					'4' => array('c' => '2','a' => $a,'coluna' => 'des_documento', 'valor' => $_POST['busca_texto']),
					'5' => array('c' => '3','a' => $a,'coluna' => "",'valor' => "")
			);
			if(isset($busca[$_POST['busca']])){
				$this->dados = array('documento' => $apiDocumento->filtroDocumento($busca[$_POST['busca']]['c'], $busca[$_POST['busca']]['a'], $busca[$_POST['busca']]['coluna'], $busca[$_POST['busca']]['valor'], $_SESSION['empresa_sessao']));
				$_SESSION['filtro_sessao'] = array('c' => $busca[$_POST['busca']]['c'], 'a' => $busca[$_POST['busca']]['a'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'valor' => $busca[$_POST['busca']]['valor']);
				$_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'ged/index/index/acessonegado');
				die();
			}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				$this->dados = array('documento' => $apiDocumento->filtroDocumento($_SESSION['filtro_sessao']['c'],$_SESSION['filtro_sessao']['a'],$_SESSION['filtro_sessao']['coluna'], $_SESSION['filtro_sessao']['valor'], $_SESSION['empresa_sessao']));
				$_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('documento' => $apiDocumento->filtroDocumento('1','3','ativo', '1', $_SESSION['empresa_sessao']));
					$_SESSION['filtro_sessao'] = array('c' => '1', 'a' => '3', 'coluna' => 'ativo' , 'valor' => '1');
					$_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}
		}
		$TotalItem = (is_array($this->dados['documento']) ? count($this->dados['documento']) : 0);
		$this->dados['documento'] = array_chunk($this->dados['documento'], $ItemPorPagina);
		@$this->dados['documento'] = $this->dados['documento'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->view();
	}
	
	public function adicionar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Cadastro de Documento";
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		$apiAviso = new apiAviso();
		$this->aviso = $apiAviso->filtroAviso('1', '1', 'ativo','1');
		$apiOrgao = new apiOrgao();
		$this->orgao = $apiOrgao->filtroOrgao('1', '1', 'ativo', '1',$_SESSION['empresa_sessao']);
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$apiDocumento = new apiDocumento();
			$funcoes = new Funcoes();
			$i = 0;
			$sql = array();
			$Post = new Documento('POST');
			$Post->empresa = $_SESSION['empresa_sessao'];
			$ex = explode(".", $Post->anexo['name']);
			$exp = end($ex);
			$Post->n_referencia = strtoupper($funcoes->retiraAcentos(str_replace(".", "", $Post->n_referencia)));
			$rs = $apiDocumento->filtroDocumento('1','1','n_referencia',$Post->n_referencia,$_SESSION['empresa_sessao']);
			if ((is_array($rs) ? count($rs) : 0) > 0){
				$this->rollback = new Documento('POST');
				$this->Alert = "J� existe um documento com esse n� de refer�ncia cadastrado!";
			}else{
				$Post->anexo  = "{$Post->empresa}-{$Post->n_referencia}-".date('dmY-His').".{$exp}";
				$sql[$i] = $apiDocumento->addDocumento($Post);
				$i = $i+1;
				$log = new Log();
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico = "AVISO;ORGAO;N_REFERENCIA;DES_DOCUMENTO;DTA_EMISSAO;DTA_VENCIMENTO;ANEXO;OBS;EMPRESA;ATIVO|{$Post->aviso};{$Post->orgao};{$Post->n_referencia};{$Post->des_documento};{$Post->dta_emissao};{$Post->dta_vencimento};{$Post->anexo};{$Post->obs};{$Post->empresa};{$Post->ativo}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiDocumento->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					move_uploaded_file($_FILES['anexo']['tmp_name'], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/".$Post->anexo);
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'ged/documento/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'ged/documento/index/sucesso');
					}
				}else{
					$this->rollback = new Documento('POST');
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		
		$this->view();
	}
	
	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Altera��o de Documento";
		$documento = new Documento();
		$documento->documento = $this->getParams(0);
		$documento->empresa = $_SESSION['empresa_sessao'];
		$apiDocumento = new apiDocumento();
		$this->dados = array('documento' => $apiDocumento->getDocumento($documento));
		if (isset($this->dados['documento'])){
			if ($this->dados['documento']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'ged/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'ged/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		$apiAviso = new apiAviso();
		$this->aviso = $apiAviso->filtroAviso('1', '1', 'ativo','1');
		$apiOrgao = new apiOrgao();
		$this->orgao = $apiOrgao->filtroOrgao('1', '1', 'ativo', '1', $_SESSION['empresa_sessao']);
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$apiDocumento = new apiDocumento();
			$funcoes = new Funcoes();
			$i = 0;
			$sql = array();
			$Post = new Documento('POST');
			$Post->documento = $this->getParams(0);
			$Post->empresa = $_SESSION['empresa_sessao'];
			$Post->n_referencia = strtoupper($funcoes->retiraAcentos(str_replace(".", "", $Post->n_referencia)));
			$rs = $apiDocumento->filtroDocumento('1','1','n_referencia',$Post->n_referencia,$_SESSION['empresa_sessao']);
			if ((is_array($rs) ? count($rs) : 0) > 0 && ($rs[0]->N_REFERENCIA != $this->dados['documento']->N_REFERENCIA)){
				$this->dados['documento']->DOCUMENTO = $Post->documento;
				$this->dados['documento']->AVISO = $Post->aviso;
				$this->dados['documento']->ORGAO = $Post->orgao;
				$this->dados['documento']->N_REFERENCIA = $Post->n_referencia;
				$this->dados['documento']->DES_DOCUMENTO = $Post->des_documento;
				$this->dados['documento']->DTA_EMISSAO = $Post->dta_emissao;
				$this->dados['documento']->DTA_VENCIMENTO = $Post->dta_vencimento;
				$this->dados['documento']->OBS = $Post->obs;
				$this->dados['documento']->EMPRESA = $Post->empresa;
				$this->dados['documento']->ATIVO = $Post->ativo;
				$this->Alert = "J� existe um documento com esse n� de refer�ncia cadastrado!";
			}else{
				$log = new Log();
				$log->historico = "DOCUMENTO;AVISO;ORGAO;N_REFERENCIA;DES_DOCUMENTO;DTA_EMISSAO;DTA_VENCIMENTO;ANEXO;OBS;EMPRESA;ATIVO|{$this->dados['documento']->DOCUMENTO};{$this->dados['documento']->AVISO};{$this->dados['documento']->ORGAO};{$this->dados['documento']->N_REFERENCIA};{$this->dados['documento']->DES_DOCUMENTO};{$this->dados['documento']->DTA_EMISSAO};{$this->dados['documento']->DTA_VENCIMENTO};{$this->dados['documento']->ANEXO};{$this->dados['documento']->OBS};{$this->dados['documento']->EMPRESA};{$this->dados['documento']->ATIVO}";
				if ($Post->anexo['tmp_name'] != NULL) {
					$ex = explode(".", $Post->anexo['name']);
					$exp = end($ex);
					$Post->anexo  = "{$Post->empresa}-{$Post->n_referencia}-".date('dmY-His').".{$exp}";
				}elseif ($this->dados['documento']->N_REFERENCIA != $Post->n_referencia){
					$ex = explode(".", $this->dados['documento']->ANEXO);
					$exp = end($ex);
					$novo_nome = "{$Post->empresa}-{$Post->n_referencia}-".date('dmY-His').".{$exp}";
					$Post->anexo = $novo_nome;
				}else{
					$Post->anexo = $this->dados['documento']->ANEXO;
				}
				$sql[$i] = $apiDocumento->editDocumento($Post);
				$i = $i+1;
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "A";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico .= ":DOCUMENTO;AVISO;ORGAO;N_REFERENCIA;DES_DOCUMENTO;DTA_EMISSAO;DTA_VENCIMENTO;ANEXO;OBS;EMPRESA;ATIVO|{$Post->documento};{$Post->aviso};{$Post->orgao};{$Post->n_referencia};{$Post->des_documento};{$Post->dta_emissao};{$Post->dta_vencimento};{$Post->anexo};{$Post->obs};{$Post->empresa};{$Post->ativo}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiDocumento->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if ($_FILES['anexo']['tmp_name'] != NULL){
						echo "entrou como se n�o tivesse vazio";
						unlink($_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/".$this->dados['documento']->ANEXO);
						move_uploaded_file($_FILES['anexo']['tmp_name'], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/".$Post->anexo);
					}elseif ($this->dados['documento']->N_REFERENCIA != $Post->n_referencia){
						$pasta = $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/";
						rename($pasta.$this->dados['documento']->ANEXO, $pasta.$novo_nome);
					}
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'ged/documento/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'ged/documento/index/sucesso');
					}
				}else{
					$this->dados['documento']->DOCUMENTO = $Post->documento;
					$this->dados['documento']->AVISO = $Post->aviso;
					$this->dados['documento']->ORGAO = $Post->orgao;
					$this->dados['documento']->N_REFERENCIA = $Post->n_referencia;
					$this->dados['documento']->DES_DOCUMENTO = $Post->des_documento;
					$this->dados['documento']->DTA_EMISSAO = $Post->dta_emissao;
					$this->dados['documento']->DTA_VENCIMENTO = $Post->dta_vencimento;
					$this->dados['documento']->OBS = $Post->obs;
					$this->dados['documento']->EMPRESA = $Post->empresa;
					$this->dados['documento']->ATIVO = $Post->ativo;
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		$this->view();
	}
	public function excluir() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Exclus�o de Documento";
		$documento = new Documento();
		$documento->documento = $this->getParams(0);
		$documento->empresa = $_SESSION['empresa_sessao'];
		$apiDocumento = new apiDocumento();
		$this->dados = array('documento' => $apiDocumento->getDocumento($documento));
		if (isset($this->dados['documento'])){
			if ($this->dados['documento']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'ged/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'ged/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$sql[$i] = $apiDocumento->delDocumento($documento);
			$i = $i+1;
			$log = new Log();
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "E";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico = "DOCUMENTO;AVISO;ORGAO;N_REFERENCIA;DES_DOCUMENTO;DTA_EMISSAO;DTA_VENCIMENTO;ANEXO;OBS;STATUS_AVISO1;STATUS_AVISO2;STATUS_AVISO3;EMPRESA;ATIVO|{$this->dados['documento']->DOCUMENTO};{$this->dados['documento']->AVISO};{$this->dados['documento']->ORGAO};{$this->dados['documento']->N_REFERENCIA};{$this->dados['documento']->DES_DOCUMENTO};{$this->dados['documento']->DTA_EMISSAO};{$this->dados['documento']->DTA_VENCIMENTO};{$this->dados['documento']->ANEXO};{$this->dados['documento']->OBS};{$this->dados['documento']->STATUS_AVISO1};{$this->dados['documento']->STATUS_AVISO2};{$this->dados['documento']->STATUS_AVISO3};{$this->dados['documento']->EMPRESA};{$this->dados['documento']->ATIVO}";
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiDocumento->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				unlink($_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/".$this->dados['documento']->ANEXO);
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'ged/documento/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'ged/documento/index/sucesso');
				}
			}else{
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}
		$this->view();
	}
}