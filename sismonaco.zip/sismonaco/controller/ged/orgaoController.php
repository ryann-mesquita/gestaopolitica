<?php

namespace controller\ged;

use lib\Controller;
use helper\Security;
use helper\Funcoes;
use api\ged\apiOrgao;
use helper\Paginator;
use api\ged\apiTipo;
use obj\ged\Orgao;
use obj\geral\Log;
use api\geral\apiLog;

class orgaoController extends Controller {
	
	public function __construct() {
		
		parent::__construct();
		
		new Security($this->getModule(),$this->getController(),$this->getAction());
	}
	
	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Lista de �rg�os";
		$this->funcoes = new Funcoes();
		$apiOrgao = new apiOrgao();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		(!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])) ? $a = '1' : $a = '3';
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$busca = array(
				'1' => array('c' => '1','a' => $a,'coluna' => 'ativo', 'valor' => '1'),
				'2' => array('c' => '1','a' => $a,'coluna' => 'ativo', 'valor' => '0'),
				'3' => array('c' => '2','a' => $a,'coluna' => 'des_orgao', 'valor' => $_POST['busca_texto']),
				'4' => array('c' => '3','a' => $a,'coluna' => "",'valor' => "")
			);
			if(isset($busca[$_POST['busca']])){
				$this->dados = array('orgao' => $apiOrgao->filtroOrgao($busca[$_POST['busca']]['c'], $busca[$_POST['busca']]['a'], $busca[$_POST['busca']]['coluna'], $busca[$_POST['busca']]['valor'],$_SESSION['empresa_sessao']));
				$_SESSION['filtro_sessao'] = array('c' => $busca[$_POST['busca']]['c'], 'a' => $busca[$_POST['busca']]['a'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'valor' => $busca[$_POST['busca']]['valor']);
				$_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'ged/index/index/acessonegado');
				die();
			}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				$this->dados = array('orgao' => $apiOrgao->filtroOrgao($_SESSION['filtro_sessao']['c'],$_SESSION['filtro_sessao']['a'],$_SESSION['filtro_sessao']['coluna'], $_SESSION['filtro_sessao']['valor'], $_SESSION['empresa_sessao']));
				$_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('orgao' => $apiOrgao->filtroOrgao('1','3','ativo', '1', $_SESSION['empresa_sessao']));
					$_SESSION['filtro_sessao'] = array('c' => '1', 'a' => '3', 'coluna' => 'ativo' , 'valor' => '1');
					$_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}
		}
		$TotalItem = (is_array($this->dados['orgao']) ? count($this->dados['orgao']) : 0);
		$this->dados['orgao'] = array_chunk($this->dados['orgao'], $ItemPorPagina);
		@$this->dados['orgao'] = $this->dados['orgao'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->view();
	}
	
	public function adicionar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Cadastro de �rg�o";
		$funcoes = new Funcoes();
		$apiOrgao = new apiOrgao();
		$apiTipo = new apiTipo();
		$this->dados = array('tipo' => $apiTipo->filtroTipo('1', '3','ativo','1'));
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$Post = new Orgao('POST');
			$Post->telefone = $funcoes->naoNumerico($Post->telefone);
			$Post->empresa = $_SESSION['empresa_sessao'];
			$apiOrgao = new apiOrgao();
			$rs = $apiOrgao->filtroOrgao('4','3','des_orgao',$Post->des_orgao,$_SESSION['empresa_sessao']);
			if ((is_array($rs) ? count($rs) : 0) > 0){
				$this->rollback = new Orgao('POST');
				$this->Alert = "J� existe um �rg�o com esse nome cadastrado!";
			}else{
				$sql[$i] = $apiOrgao->addOrgao($Post);
				$i = $i+1;
				$log = new Log();
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico = "DES_ORGAO;TIPO;SITE;EMAIL;TELEFONE;CONTATO;ATIVO|{$Post->des_orgao};{$Post->tipo};{$Post->site};{$Post->email};{$Post->telefone};{$Post->contato};{$Post->ativo}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiOrgao->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'ged/orgao/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'ged/orgao/index/sucesso');
					}
				}else{
					$this->rollback = new Orgao('POST');
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		
		$this->view();
	}
	
	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Altera��o de Orgao";
		$funcoes = new Funcoes();
		$orgao = new Orgao();
		$orgao->orgao = $this->getParams(0);
		$orgao->empresa = $_SESSION['empresa_sessao'];
		$apiOrgao = new apiOrgao();
		$this->dados = array('orgao' => $apiOrgao->getOrgao($orgao));
		if (isset($this->dados['orgao'])){
			if ($this->dados['orgao']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'ged/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'ged/index/index/acessonegado');
			die();
		}
		$apiTipo = new apiTipo();
		$this->tipo = $apiTipo->filtroTipo('1', '3','ativo','1');
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$Post = new Orgao('POST');
			$Post->orgao = $this->getParams(0);
			$Post->telefone = $funcoes->naoNumerico($Post->telefone);
			$Post->empresa = $_SESSION['empresa_sessao'];
			$rs = $apiOrgao->filtroOrgao('4','3','des_orgao',$Post->des_orgao,$_SESSION['empresa_sessao']);
			$log = new Log();
			$log->historico = "DES_ORGAO;TIPO;SITE;EMAIL;TELEFONE;CONTATO;ATIVO|{$this->dados['orgao']->DES_ORGAO};{$this->dados['orgao']->TIPO};{$this->dados['orgao']->SITE};{$this->dados['orgao']->EMAIL};{$this->dados['orgao']->TELEFONE};{$this->dados['orgao']->CONTATO};{$this->dados['orgao']->ATIVO}";
			if ((is_array($rs) ? count($rs) : 0) > 0 && ($rs[0]->DES_ORGAO != $this->dados['orgao']->DES_ORGAO)){
				$this->dados['orgao']->DES_ORGAO = $Post->des_orgao;
				$this->dados['orgao']->TIPO = $Post->tipo;
				$this->dados['orgao']->SITE = $Post->site;
				$this->dados['orgao']->EMAIL = $Post->email;
				$this->dados['orgao']->TELEFONE = $Post->telefone;
				$this->dados['orgao']->CONTATO = $Post->contato;
				$this->dados['orgao']->ATIVO = $Post->ativo;
				$this->Alert = "J� existe um orgao com essa descri��o cadastrada!";
			}else{
				$sql[$i] = $apiOrgao->editOrgao($Post);
				$i = $i+1;
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "A";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico .= ":DES_ORGAO;TIPO;SITE;EMAIL;TELEFONE;CONTATO;ATIVO|{$Post->des_orgao};{$Post->tipo};{$Post->site};{$Post->email};{$Post->telefone};{$Post->contato};{$Post->ativo}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiOrgao->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'ged/orgao/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'ged/orgao/index/sucesso');
					}
				}else{
					$this->dados['orgao']->DES_ORGAO = $Post->des_orgao;
					$this->dados['orgao']->TIPO = $Post->tipo;
					$this->dados['orgao']->SITE = $Post->site;
					$this->dados['orgao']->EMAIL = $Post->email;
					$this->dados['orgao']->TELEFONE = $Post->telefone;
					$this->dados['orgao']->CONTATO = $Post->contato;
					$this->dados['orgao']->ATIVO = $Post->ativo;
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		$this->view();
	}
	public function excluir() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Exclus�o de Orgao";
		$funcoes = new Funcoes();
		$orgao = new Orgao();
		$orgao->orgao = $this->getParams(0);
		$orgao->empresa = $_SESSION['empresa_sessao'];
		$apiOrgao = new apiOrgao();
		$this->dados = array('orgao' => $apiOrgao->getOrgao($orgao));
		if (isset($this->dados['orgao'])){
			if ($this->dados['orgao']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'ged/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'ged/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$sql[$i] = $apiOrgao->delOrgao($orgao);
			$i = $i+1;
			$log = new Log();
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "E";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico = "ORGAO;DES_ORGAO;TIPO;SITE;EMAIL;TELEFONE;CONTATO;ATIVO|{$this->dados['orgao']->ORGAO};{$this->dados['orgao']->DES_ORGAO};{$this->dados['orgao']->TIPO};{$this->dados['orgao']->SITE};{$this->dados['orgao']->EMAIL};{$this->dados['orgao']->TELEFONE};{$this->dados['orgao']->CONTATO};{$this->dados['orgao']->ATIVO}";
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiOrgao->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'ged/orgao/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'ged/orgao/index/sucesso');
				}
			}else{
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}
		$this->view();
	}
}