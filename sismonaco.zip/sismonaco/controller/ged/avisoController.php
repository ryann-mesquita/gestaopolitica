<?php

namespace controller\ged;

use lib\Controller;
use helper\Security;
use api\ged\apiAviso;
use helper\Paginator;
use obj\ged\Aviso;
use obj\geral\Log;
use api\geral\apiLog;

class avisoController extends Controller {
	
	public function __construct() {
		
		parent::__construct();
		
		new Security($this->getModule(),$this->getController(),$this->getAction());
	}
	
	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Lista de Avisos";
		$apiAviso = new apiAviso();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		(!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])) ? $a = '1' : $a = '3';
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$busca = array(
					'1' => array('c' => '1','a' => $a,'coluna' => 'ativo', 'valor' => '1'),
					'2' => array('c' => '1','a' => $a,'coluna' => 'ativo', 'valor' => '0'),
					'3' => array('c' => '2','a' => $a,'coluna' => 'des_aviso', 'valor' => $_POST['busca_texto']),
					'4' => array('c' => '3','a' => $a,'coluna' => "",'valor' => "")
			);
			if(isset($busca[$_POST['busca']])){
				$this->dados = array('aviso' => $apiAviso->filtroAviso($busca[$_POST['busca']]['c'], $busca[$_POST['busca']]['a'], $busca[$_POST['busca']]['coluna'], $busca[$_POST['busca']]['valor']));
				$_SESSION['filtro_sessao'] = array('c' => $busca[$_POST['busca']]['c'], 'a' => $busca[$_POST['busca']]['a'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'valor' => $busca[$_POST['busca']]['valor']);
				$_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'ged/index/index/acessonegado');
				die();
			}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				$this->dados = array('aviso' => $apiAviso->filtroAviso($_SESSION['filtro_sessao']['c'],$_SESSION['filtro_sessao']['a'],$_SESSION['filtro_sessao']['coluna'], $_SESSION['filtro_sessao']['valor']));
				$_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('aviso' => $apiAviso->filtroAviso('1','3','ativo', '1'));
					$_SESSION['filtro_sessao'] = array('c' => '1', 'a' => '3', 'coluna' => 'ativo' , 'valor' => '1');
					$_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}
		}
		$TotalItem = (is_array($this->dados['aviso']) ? count($this->dados['aviso']) : 0);
		$this->dados['aviso'] = array_chunk($this->dados['aviso'], $ItemPorPagina);
		@$this->dados['aviso'] = $this->dados['aviso'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->view();
	}
	
	public function adicionar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Cadastro de Aviso";
		$apiAviso = new apiAviso();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$Post = new Aviso('POST');
			$apiAviso = new apiAviso();
			$rs = $apiAviso->filtroAviso('1','3','des_aviso',$Post->des_aviso);
			if ((is_array($rs) ? count($rs) : 0) > 0){
				$this->rollback = new Aviso('POST');
				$this->Alert = "J� existe um aviso com esse nome cadastrado!";
			}else{
				$sql[$i] = $apiAviso->addAviso($Post);
				$i = $i+1;
				$log = new Log();
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico = "DES_AVISO;AVISO1;AVISO2;AVISO3;AVISO_A_CADA;ATIVO|{$Post->des_aviso};{$Post->aviso1};{$Post->aviso2};{$Post->aviso3};{$Post->aviso_a_cada};{$Post->ativo}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiAviso->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'ged/aviso/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'ged/aviso/index/sucesso');
					}
				}else{
					$this->rollback = new Aviso('POST');
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		
		$this->view();
	}
	
	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Altera��o de Aviso";
		$aviso = new Aviso();
		$aviso->aviso = $this->getParams(0);
		$apiAviso = new apiAviso();
		$this->dados = array('aviso' => $apiAviso->getAviso($aviso));
		if (isset($this->dados['aviso'])){
			if ($this->dados['aviso']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'ged/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'ged/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$Post = new Aviso('POST');
			$Post->aviso = $this->getParams(0);
			$rs = $apiAviso->filtroAviso('1','3','des_aviso',$Post->des_aviso);
			$log = new Log();
			$log->historico = "AVISO;DES_AVISO;AVISO1;AVISO2;AVISO3;AVISO_A_CADA;ATIVO|{$this->dados['aviso']->AVISO};{$this->dados['aviso']->DES_AVISO};{$this->dados['aviso']->AVISO1};{$this->dados['aviso']->AVISO2};{$this->dados['aviso']->AVISO3};{$this->dados['aviso']->AVISO_A_CADA};{$this->dados['aviso']->ATIVO}";
			if ((is_array($rs) ? count($rs) : 0) > 0 && ($rs[0]->DES_AVISO != $this->dados['aviso']->DES_AVISO)){
				$this->dados['aviso']->DES_AVISO = $Post->des_aviso;
				$this->dados['aviso']->AVISO1 = $Post->aviso1;
				$this->dados['aviso']->AVISO2 = $Post->aviso2;
				$this->dados['aviso']->AVISO3 = $Post->aviso3;
				$this->dados['aviso']->AVISO_A_CADA = $Post->aviso_a_cada;
				$this->dados['aviso']->ATIVO = $Post->ativo;
				$this->Alert = "J� existe um aviso com essa descri��o cadastrado!";
			}else{
				$sql[$i] = $apiAviso->editAviso($Post);
				$i = $i+1;
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "A";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico .= ":AVISO;DES_AVISO;AVISO1;AVISO2;AVISO3;AVISO_A_CADA;ATIVO|{$Post->aviso};{$Post->des_aviso};{$Post->aviso1};{$Post->aviso2};{$Post->aviso3};{$Post->aviso_a_cada};{$Post->ativo}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiAviso->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'ged/aviso/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'ged/aviso/index/sucesso');
					}
				}else{
					$this->dados['aviso']->DES_AVISO = $Post->des_aviso;
					$this->dados['aviso']->AVISO1 = $Post->aviso1;
					$this->dados['aviso']->AVISO2 = $Post->aviso2;
					$this->dados['aviso']->AVISO3 = $Post->aviso3;
					$this->dados['aviso']->AVISO_A_CADA = $Post->aviso_a_cada;
					$this->dados['aviso']->ATIVO = $Post->ativo;
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		$this->view();
	}
	public function excluir() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Exclus�o de Aviso";
		$aviso = new Aviso();
		$aviso->aviso = $this->getParams(0);
		$apiAviso = new apiAviso();
		$this->dados = array('aviso' => $apiAviso->getAviso($aviso));
		if (isset($this->dados['aviso'])){
			if ($this->dados['aviso']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'ged/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'ged/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$sql[$i] = $apiAviso->delAviso($aviso);
			$i = $i+1;
			$log = new Log();
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "E";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico = "AVISO;DES_AVISO;AVISO1;AVISO2;AVISO3;AVISO_A_CADA;ATIVO|{$this->dados['aviso']->AVISO};{$this->dados['aviso']->DES_AVISO};{$this->dados['aviso']->AVISO1};{$this->dados['aviso']->AVISO2};{$this->dados['aviso']->AVISO3};{$this->dados['aviso']->AVISO_A_CADA};{$this->dados['aviso']->ATIVO}";
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiAviso->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'ged/aviso/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'ged/aviso/index/sucesso');
				}
			}else{
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}
		$this->view();
	}
}
