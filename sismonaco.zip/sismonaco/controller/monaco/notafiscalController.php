<?php

namespace controller\monaco;

use lib\Controller;
use helper\Security;
use api\monaco\apiNotafiscal;
use helper\Funcoes;
use helper\Paginator;
use helper\ServidorArquivo;
use api\geral\apiEmpresa;
use obj\monaco\Notafiscal;
use obj\geral\Log;
use api\geral\apiLog;

class notafiscalController extends  Controller {

	public  function __construct(){

		parent::__construct();

		new Security($this->getModule(),$this->getController(),$this->getAction());
	}

	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Notas Enviadas";
		$apiNotafiscal = new apiNotafiscal();
		$this->funcoes = new Funcoes();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$busca = array(
				'1' => array('c' => '2','de' => @$_POST['de'],'ate' => @$_POST['ate'],'coluna' => 'cliente', 'valor' => $_POST['busca_valor']),
				'2' => array('c' => '2','de' => @$_POST['de'],'ate' => @$_POST['ate'],'coluna' => 'n_nota', 'valor' => $_POST['busca_valor']),
				'3' => array('c' => '1','de' => @$_POST['de'],'ate' => @$_POST['ate'],'coluna' => 'situacao', 'valor' => 'P'),
				'4' => array('c' => '1','de' => @$_POST['de'],'ate' => @$_POST['ate'],'coluna' => 'situacao', 'valor' => 'C'),
				'5' => array('c' => '3','de' => @$_POST['de'],'ate' => @$_POST['ate'],'coluna' => "",'valor' => "")
			);
			if(isset($busca[$_POST['busca']])){
				$this->dados = array('notafiscal' => $apiNotafiscal->filtroNotafiscal($_SESSION['empresa_sessao'],$busca[$_POST['busca']]['c'],$busca[$_POST['busca']]['de'],$busca[$_POST['busca']]['ate'], $busca[$_POST['busca']]['coluna'], $busca[$_POST['busca']]['valor']));
				$_SESSION['filtro_sessao'] = array('c' => $busca[$_POST['busca']]['c'], 'de' => $busca[$_POST['busca']]['de'], 'ate' => $busca[$_POST['busca']]['ate'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'valor' => $busca[$_POST['busca']]['valor'], 'filtro' => $_POST['busca']);
				$_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'adm/index/index/acessonegado');
				die();
			}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				$this->dados = array('notafiscal' => $apiNotafiscal->filtroNotafiscal($_SESSION['empresa_sessao'],$_SESSION['filtro_sessao']['c'],$_SESSION['filtro_sessao']['de'],$_SESSION['filtro_sessao']['ate'],$_SESSION['filtro_sessao']['coluna'], $_SESSION['filtro_sessao']['valor']));
				$_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$ultimo_dia = date("t", mktime(0,0,0,date('m'),'01',date('Y')));
					$this->dados = array('notafiscal' => $apiNotafiscal->filtroNotafiscal($_SESSION['empresa_sessao'],'3',"01/".date('m/Y'),$ultimo_dia."/".date('m/Y')));
					$_SESSION['filtro_sessao'] = array('c' => '3', 'de' => "01/".date('m/Y'), 'ate' => $ultimo_dia."/".date('m/Y'),'coluna' => "" , 'valor' => "", 'filtro' => 5);
					$_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}				
		}
		$TotalItem = (is_array($this->dados['notafiscal']) ? count($this->dados['notafiscal']) : 0);
		$this->dados['notafiscal'] = array_chunk($this->dados['notafiscal'], $ItemPorPagina);
		@$this->dados['notafiscal'] = $this->dados['notafiscal'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->view();
	}

	public function adicionar(){
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Envio de Notas";
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {	
			$ssh = new ServidorArquivo();
			$apiEmpresa = new apiEmpresa();
			$rs = $apiEmpresa->geEmpresarevenda($_SESSION['empresa_sessao']);
			$apiNotafiscal = new apiNotafiscal();
			$notafiscal = new Notafiscal();
			$empresa = $rs->EMPRESA."-".$rs->REVENDA;
			$funcoes = new Funcoes();
			$i = 0;
			$sql = array();
			$cliente = $_POST["cliente"];
			$n_nota = $_POST["n_nota"];
			$s_nota = $_POST["s_nota"];
			$situacao = $_POST["situacao"];
			$anexo = $_FILES["anexo"];
			$this->Alert = "";
			foreach ($cliente as $key => $c) {
				$notafiscal->cliente = $funcoes->naoNumerico($c);
				$notafiscal->n_nota = intval($n_nota{$key});
				$notafiscal->s_nota = str_replace(' ','', strtoupper($s_nota{$key}));
				$notafiscal->empresa = $_SESSION["empresa_sessao"];
				$notafiscal->dta_entrada = date("d/m/Y H:i:s");
				$notafiscal->usuario = $_SESSION["usuario_sessao"];
				$notafiscal->situacao = $situacao{$key};
				$nota = $apiNotafiscal->getNotafiscal($notafiscal);
				if ((is_array($nota) ? count($nota) : 0) > 0){
					$this->Alert .= "J� existe a Nota: {$notafiscal->n_nota} de S�rie: {$notafiscal->s_nota} do Cliente: {$notafiscal->cliente} nessa Empresa <br/>";
				}else{
					$nome_arquivo = str_pad($notafiscal->cliente, 14, "0", STR_PAD_LEFT)."-".$notafiscal->n_nota."-".$notafiscal->s_nota;
					if ($ssh->ImportaNota($anexo['tmp_name']{$key},$nome_arquivo,$empresa,$rs->CNPJ) == 'sucesso'){
						$notafiscal->cliente = "<str>".$notafiscal->cliente;
						$sql[$i] = $apiNotafiscal->addNotafiscal($notafiscal);
						$i = $i+1;
					}
				}
			}
			@$rs = $apiNotafiscal->executeSQL($sql);	
			if ($this->Alert == ""){
				if ($rs[4] == "sucesso") {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'monaco/notafiscal/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'monaco/notafiscal/index/sucesso');
					}
				}else{
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}			
		}
		$this->view();
	}

	public function alterar(){
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Alterar Nota";
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		$exp = explode(",", $this->getParams(0));
		$notafiscal = new Notafiscal();
		$notafiscal->cliente = $this->cliente = $exp[0];
		$notafiscal->n_nota = $this->n_nota = $exp[1];
		$notafiscal->s_nota = $this->s_nota = $exp[2];
		$notafiscal->empresa = $_SESSION["empresa_sessao"];
		$apiNotafiscal = new apiNotafiscal();
		$this->dados = array('notafiscal' => $apiNotafiscal->getNotafiscal($notafiscal));
		if (!isset($this->dados['notafiscal'])){
			header('location:' .APP_ROOT. 'monaco/index/index/acessonegado');
			die();
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$ssh = new ServidorArquivo();
			$apiEmpresa = new apiEmpresa();
			$rs = $apiEmpresa->geEmpresarevenda($_SESSION['empresa_sessao']);
			$empresa = $rs->EMPRESA."-".$rs->REVENDA;
			$funcoes = new Funcoes();
			$i = 0;
			$sql = array();
			$notafiscal->cliente = $funcoes->naoNumerico($_POST["cliente"]);
			$notafiscal->n_nota = intval($_POST["n_nota"]);
			$notafiscal->s_nota = str_replace(' ','', strtoupper($_POST["s_nota"]));
			$notafiscal->empresa = $_SESSION["empresa_sessao"];
			$notafiscal->dta_entrada = $this->dados['notafiscal']->DTA_ENTRADA;
			$notafiscal->situacao = $_POST["situacao"];
			$nota = $apiNotafiscal->getNotafiscal($notafiscal);

			if ((is_array($nota) ? count($nota) : 0) > 0 && ($nota->CLIENTE != $this->dados['notafiscal']->CLIENTE) && ($nota->N_NOTA != $this->dados['notafiscal']->N_NOTA) && ($nota->S_NOTA != $this->dados['notafiscal']->S_NOTA)){
				$this->Alert .= "J� existe a Nota: {$notafiscal->n_nota} de S�rie: {$notafiscal->s_nota} do Cliente: {$notafiscal->cliente} nessa Empresa <br/>";
			}else{
				$nome_antigo = str_pad($this->dados['notafiscal']->CLIENTE, 14, "0", STR_PAD_LEFT)."-".$this->dados['notafiscal']->N_NOTA."-".$this->dados['notafiscal']->S_NOTA;
				$nome_novo = str_pad($notafiscal->cliente, 14, "0", STR_PAD_LEFT)."-".$notafiscal->n_nota."-".$notafiscal->s_nota;
					
				if ($ssh->RenomearNota($nome_antigo,$nome_novo,$empresa,$rs->CNPJ) == 'sucesso'){
					$notafiscal->cliente = "<str>".$notafiscal->cliente;
					$sql[$i] = $apiNotafiscal->editNotafiscal("<str>".$this->dados['notafiscal']->CLIENTE, $this->dados['notafiscal']->N_NOTA, $this->dados['notafiscal']->S_NOTA, $notafiscal);
					$i = $i+1;
					$log = new Log();
					$log->usuario = $_SESSION['usuario_sessao'];
					$log->modulo = $this->getModule()['modulo'];
					$log->controle = $this->getController()['controle'];
					$log->acao = $this->getAction()['acao'];
					$log->empresa = $_SESSION['empresa_sessao'];
					$log->tipo = "A";
					$log->dta_registro = date("d/m/Y H:i:s");
					$log->historico = "CLIENTE||{$this->dados['notafiscal']->CLIENTE};;N_NOTA||{$this->dados['notafiscal']->N_NOTA};;S_NOTA||{$this->dados['notafiscal']->S_NOTA};;SITUACAO||{$this->dados['notafiscal']->SITUACAO}";
					$log->historico .= "::CLIENTE||{$notafiscal->cliente};;N_NOTA||{$notafiscal->n_nota};;S_NOTA||{$notafiscal->s_nota};;SITUACAO||{$notafiscal->situacao}";
					$apiLog = new apiLog();
					$sql[$i] = $apiLog->addLog($log);
					$rs = $apiNotafiscal->executeSQL($sql);
				}else{
					if ($this->dados['notafiscal']->SITUACAO != $notafiscal->situacao){
						$notafiscal->cliente = "<str>".$notafiscal->cliente;
						$sql[$i] = $apiNotafiscal->editNotafiscal($this->dados['notafiscal']->CLIENTE, $this->dados['notafiscal']->N_NOTA, $this->dados['notafiscal']->S_NOTA, $notafiscal);
						$i = $i+1;
						$log = new Log();
						$log->usuario = $_SESSION['usuario_sessao'];
						$log->modulo = $this->getModule()['modulo'];
						$log->controle = $this->getController()['controle'];
						$log->acao = $this->getAction()['acao'];
						$log->empresa = $_SESSION['empresa_sessao'];
						$log->tipo = "A";
						$log->dta_registro = date("d/m/Y H:i:s");
						$log->historico = "CLIENTE||{$this->dados['notafiscal']->CLIENTE};;N_NOTA||{$this->dados['notafiscal']->N_NOTA};;S_NOTA||{$this->dados['notafiscal']->S_NOTA};;SITUACAO||{$this->dados['notafiscal']->SITUACAO}";
						$log->historico .= "::CLIENTE||{$notafiscal->cliente};;N_NOTA||{$notafiscal->n_nota};;S_NOTA||{$notafiscal->s_nota};;SITUACAO||{$notafiscal->situacao}";
						$apiLog = new apiLog();
						$sql[$i] = $apiLog->addLog($log);
						$rs = $apiNotafiscal->executeSQL($sql);
					}else{
						if (isset($this->PaginaAtual)) {
							header('location:' .APP_ROOT. 'monaco/notafiscal/index/pagina/'.$this->PaginaAtual.'/');
						}else {
							header('location:' .APP_ROOT. 'monaco/notafiscal/index/');
						}
					}
				}
				
				if ($rs[4] == "sucesso") {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'monaco/notafiscal/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'monaco/notafiscal/index/sucesso');
					}
				}else{
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		$this->view();
	}

	public function excluir(){
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Excluir Nota";
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		$exp = explode(",", $this->getParams(0));
		$notafiscal = new Notafiscal();
		$notafiscal->cliente = $this->cliente = $exp[0];
		$notafiscal->n_nota = $this->n_nota = $exp[1];
		$notafiscal->s_nota = $this->s_nota = $exp[2];
		$notafiscal->empresa = $_SESSION["empresa_sessao"];
		$apiNotafiscal = new apiNotafiscal();
		$this->dados = array('notafiscal' => $apiNotafiscal->getNotafiscal($notafiscal));
		if (!isset($this->dados['notafiscal'])){
			header('location:' .APP_ROOT. 'monaco/index/index/acessonegado');
			die();
		}
		$this->funcoes = $funcoes = new Funcoes();
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$ssh = new ServidorArquivo();
			$apiEmpresa = new apiEmpresa();
			$r = $apiEmpresa->geEmpresarevenda($_SESSION['empresa_sessao']);
			$empresa = $r->EMPRESA."-".$r->REVENDA;
			$i = 0;
			$sql = array();
			$nome = str_pad($notafiscal->cliente, 14, "0", STR_PAD_LEFT)."-".$notafiscal->n_nota."-".$notafiscal->s_nota;
			if ($ssh->RemoverNota($nome,$empresa,$r->CNPJ) == 'sucesso'){
				$sql[$i] = $apiNotafiscal->delNotafiscal($notafiscal);
				$i = $i+1;
				$log = new Log();
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "E";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico = "CLIENTE||{$this->dados['notafiscal']->CLIENTE};;N_NOTA||{$this->dados['notafiscal']->N_NOTA};;S_NOTA||{$this->dados['notafiscal']->S_NOTA};;EMPRESA||{$this->dados['notafiscal']->EMPRESA};;DTA_ENTRADA||{$this->dados['notafiscal']->DTA_ENTRADA};;USUARIO||{$this->dados['notafiscal']->USUARIO};;SITUACAO||{$this->dados['notafiscal']->SITUACAO}";
				$apiLog = new apiLog();
				$sql[$in] = $apiLog->addLog($log);
				$rs = $apiNotafiscal->executeSQL($sql);
			}
			
			if ($rs[4] == "sucesso") {
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'monaco/notafiscal/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'monaco/notafiscal/index/sucesso');
				}
			}else{
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}
		$this->view();
	}
}