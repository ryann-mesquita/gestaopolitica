<?php

namespace controller\monaco;

use lib\Controller;
use helper\Security;
use helper\Funcoes;
use api\monaco\apiPosvenda;
use api\geral\apiEmpresa;
use obj\geral\Empresa;
use classes\FPDF;

include 'classes/FPDF/fpdf.php';

class posvendaController extends Controller {

	public function __construct() {

		parent::__construct();

		new Security($this->getModule(),$this->getController(),$this->getAction());
	}

	public function index() {

		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "P�s Venda";
		$this->view();

	}

	public function customiza1() {

		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Customiza��o 1";

		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$funcoes = new Funcoes();
			$data = date("d/m/Y H:i:s");
			$apiPosvenda = new apiPosvenda();
			$apiEmpresa = new apiEmpresa();
			$empresa = new Empresa();
			$empresa->empresa = $_SESSION['empresa_sessao'];
			$r = $apiEmpresa->getEmpresa($empresa);
			$emp = $apiPosvenda->getEmpresarevenda($r->CNPJ);
			$os = $_POST['os'];
			$rs = $apiPosvenda->getOs($emp[0]->EMPRESA, $emp[0]->REVENDA, $os);
			if ((is_array($rs) ? count($rs) : 0) > 0) {
				$rs2 = $apiPosvenda->getOsobservacao($emp[0]->EMPRESA, $emp[0]->REVENDA, $os);
				$rs3 = $apiPosvenda->getOsservico($emp[0]->EMPRESA, $emp[0]->REVENDA, $os);
				$rs4 = $apiPosvenda->getOspecas($emp[0]->EMPRESA, $emp[0]->REVENDA, $os);
				$rs5 = $apiPosvenda->getOscondicaopagamento($emp[0]->EMPRESA, $emp[0]->REVENDA, $os);
				//Dados da Empresa
				$razao = $emp[0]->RAZAO_SOCIAL;
				$endereco = $emp[0]->ENDERECO;
				$n = $emp[0]->NRO_ENDERECO;
				$cnpj = $emp[0]->CNPJ;
				$ie = $emp[0]->INSC_ESTADUAL;
				$cidade = $emp[0]->CIDADE;
				$uf =  $emp[0]->UF;
				//Dados da O.S
					
				$pdf = new FPDF();
					
				$pdf->AddPage();
					
				$pdf->SetFont('arial','B',9);
				//Cabe�alho
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(2);
				$pdf->Cell(90,4,"{$razao}",0,0,'L');
				$pdf->Cell(50,4,"ORDEM DE SERVI�O.: $os",0,0,'C');
				$pdf->Cell(50,4,"DATA.: {$data}",0,0,'R');
				$pdf->Ln(6);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(1);
				$pdf->Cell(70,4,"{$endereco} - N� {$n}",0,0,"L");
				$pdf->Cell(50,4,"{$cnpj} / {$ie}",0,0,"C");
				$pdf->Cell(50,4,"{$cidade}-{$uf}",0,0,"R");
				$pdf->Ln(6);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(1);
				//O.S
				$pdf->Cell(70,4,"DADOS DA ORDEM DE SERVI�O - REIMPRESSAO",0,0,'L');
				$pdf->Ln(4);
				$pdf->Cell(70,4,"ABERTURA.: {$rs[0]->DATADEABERTURA}",0,0,'L');
				$pdf->Ln(4);
				$pdf->Cell(50,4,"FATURAMENTO.: {$rs[0]->DATADEFATURAMENTO}",0,0,'L');
				$pdf->Cell(100,4,"NF.: {$rs[0]->NOTAFISCAL}",0,0,'L');
				$pdf->Ln(4);
				$pdf->Cell(40,4,"TIPO OS.: {$rs[0]->FONTEPAGADORA}",0,0,'L');
				$pdf->Cell(115,4,"CONSULTOR.: {$rs[0]->NOMEDOCONSULTOR}",0,0,'L');
				$pdf->Cell(20,4,"STATUS.: FATURADA",0,0,'L');
				$pdf->Ln(5);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(1);
				$pdf->Cell(140,4,"CLIENTE.: {$rs[0]->NOMEDOCLIENTE}",0,0,'L');
				$pdf->Cell(50,4,"PROPRIETARIO.: O MESMO",0,0,'L');
				$pdf->Ln(4);
				$pdf->Cell(140,4,"ENDERECO.: {$rs[0]->ENDERECO}",0,0,'L');
				$pdf->Cell(50,4,"ENDERECO.:",0,0,'L');
				$pdf->Ln(4);
				$pdf->Cell(70,4,"BAIRRO.: {$rs[0]->BAIRRO}",0,0,'L');
				$pdf->Cell(70,4,"COMPL.: {$rs[0]->COMPLEMENTO}",0,0,'L');
				$pdf->Cell(25,4,"BAIRRO.:",0,0,'L');
				$pdf->Cell(25,4,"COMPL.:",0,0,'L');
				$pdf->Ln(4);
				$pdf->Cell(70,4,"CIDADE.: {$rs[0]->CIDADE}",0,0,'L');
				$pdf->Cell(70,4,"UF.: {$rs[0]->UF}",0,0,'L');
				$pdf->Cell(25,4,"CIDADE.:",0,0,'L');
				$pdf->Cell(25,4,"UF.:",0,0,'L');
				$pdf->Ln(4);
				$pdf->Cell(140,4,"CPF/CGC.: {$rs[0]->CGC_CPF}",0,0,'L');
				$pdf->Cell(50,4,"CPF/CGC.: ",0,0,'L');
				$pdf->Ln(4);
				$pdf->Cell(70,4,"TELEFONE.: {$rs[0]->TELEFONE}",0,0,'L');
				$pdf->Cell(70,4,"CELULAR.: {$rs[0]->CELULAR}",0,0,'L');
				$pdf->Cell(25,4,"TELEFONE.: ",0,0,'L');
				$pdf->Cell(25,4,"CELULAR.: ",0,0,'L');
				$pdf->Ln(5);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(1);
				//Ve�culo
				$pdf->Cell(70,4,"DADOS DO VEICULO",0,0,'L');
				$pdf->Ln(4);
				$pdf->Cell(40,4,"PLACA/EQPTO.: {$rs[0]->PLACA}",0,0,'L');
				$pdf->Cell(60,4,"CHASSI/SERIE.: {$rs[0]->CHASSIDOVEICULO}",0,0,'L');
				$pdf->Cell(35,4,"MARCA.: {$rs[0]->MONTADORAVW_MAN}",0,0,'L');
				$pdf->Cell(30,4,"MODELO.: {$rs[0]->MODELODOVEICULO}",0,0,'L');
				$pdf->Ln(4);
				$pdf->Cell(40,4,"FAB/MOD.: {$rs[0]->ANO_FABRICACAO}/{$rs[0]->ANO_MODELO}",0,0,'L');
				$pdf->Cell(60,4,"COR.: {$rs[0]->DES_COR}",0,0,'L');
				if ($rs[0]->COMBUSTIVEL == "D"){
						
					$pdf->Cell(35,4,"COMB.: DIESEL",0,0,'L');
						
				}else{
						
					$pdf->Cell(35,4,"COMB.: GASOLINA",0,0,'L');
						
				}
				$pdf->Cell(30,4,"KM.: {$rs[0]->KILOMETRAGEM}",0,0,'L');
				$pdf->Ln(4);
				$pdf->Cell(60,4,"NRO MOTOR.: {$rs[0]->MOTOR}",0,0,'L');
				$pdf->Cell(60,4,"N SER.: {$rs[0]->NUMERO_SERIE}",0,0,'L');
				$pdf->Cell(45,4,"POT.: {$rs[0]->POTENCIA_MOTOR}",0,0,'L');
				$pdf->Ln(4);
				$pdf->Cell(0,4,"NRO DIFER.: {$rs[0]->DIFERENCIAL}",0,0,'L');
				$pdf->Ln(4);
				$pdf->Cell(120,4,"CILINDRADA.: {$rs[0]->CILINDRADA}",0,0,'L');
				$pdf->Cell(45,4,"RENAVAM.: {$rs[0]->RENAVAM}",0,0,'L');
				$pdf->Ln(5);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(1);
				//Solicitacoes
				$pdf->Cell(70,4,"MENSAGEM/OBSERVACOES DO CLIENTE",0,0,'L');
				$pdf->Ln(4);
				$pdf->SetFont('arial','B',7);
				foreach ($rs2 as $rs2){
						
					$pdf->Cell(0,4,"{$rs2->TIPO_SERVICO}    {$rs2->DES_SOLICITACAO}",0,0,'L');
					$pdf->Ln(3);
						
				}
					
				$pdf->Ln(3);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(1);
				$pdf->SetFont('arial','B',7);
				$pdf->Cell(40,4,"REQUIS SEQ TIPO ORIG ATIV.",0,0,"L");
				$pdf->Cell(15,4,"--QTDE--",0,0,"L");
				$pdf->Cell(30,4,"------CODIGO------",0,0,"L");
				$pdf->Cell(60,4,"-------------DESCRICAO-------------",0,0,"L");
				$pdf->Cell(15,4,"-VLR UNIT-",0,0,"L");
				$pdf->Cell(15,4,"-VR DESC-",0,0,"L");
				$pdf->Cell(15,4,"-VLR TOTAL-",0,0,"L");
				$pdf->Ln(4);
				$pdf->Cell(0,4,"------SERVICOS------",0,0,"L");
				$pdf->Ln(4);
				$valtotals = 0;
				if ((is_array($rs3) ? count($rs3) : 0) > 0){
					foreach ($rs3 as $rs3){
							
						$pdf->Cell(40,4,"{$rs3->NRO_LANCAMENTO}  {$rs3->MODELO_SERVICO}   {$rs3->MAODEOBRA}   {$rs3->TIPO_SERVICO}",0,0,"L");
						if (substr($rs3->QUANTIDADE, 0, 1) == ","){

							$qtd = str_pad($rs3->QUANTIDADE, 3, "0",STR_PAD_LEFT);
							$qtd = str_pad($qtd, 4, "0",STR_PAD_RIGHT);
							$pdf->Cell(15,4,"{$qtd}",0,0,"C");

						}else{

							$pdf->Cell(15,4,"{$rs3->QUANTIDADE}",0,0,"C");
						}
						$pdf->Cell(30,4,"{$rs3->SERVICO}",0,0,"C");
						$pdf->Cell(60,4,"{$rs3->DESCRICAO}",0,0,"L");
						$pdf->Cell(15,4,"{$funcoes->sanearValor($rs3->VAL_SERVICO)}",0,0,"C");
						$pdf->Cell(15,4,"            ",0,0,"C");
						$val = str_replace(",", ".", $rs3->QUANTIDADE) *str_replace(",", ".", $rs3->VAL_SERVICO);
						$valtotals = $valtotals + $val;
						$pdf->Cell(15,4,"{$funcoes->sanearValor($val)}",0,0,"C");
						$pdf->Ln(4);
							
					}
				}
				$pdf->Cell(0,4,"--------PECAS-------",0,0,"L");
				$pdf->Ln(4);
				$valtotalp = 0;
				if ((is_array($rs4) ? count($rs4) : 0) > 0){
					foreach ($rs4 as $rs4){
							
						$pdf->Cell(40,4,"{$rs4->NRO_LANCAMENTO}  {$rs4->ITEM_ESTOQUE}   {$rs4->TIPO_SERVICO} ",0,0,"L");
						$pdf->Cell(15,4,"{$rs4->QUANTIDADE}",0,0,"C");
						$pdf->Cell(30,4,"{$rs4->ITEM_ESTOQUE_PUB}",0,0,"C");
						$pdf->Cell(60,4,"{$rs4->DES_ITEM_ESTOQUE}",0,0,"L");
						$pdf->Cell(15,4,"{$funcoes->sanearValor($rs4->VAL_UNITARIO)}",0,0,"C");
						if (substr($rs4->VAL_DESCONTO, 0, 1) == ","){
								
							$des = str_pad($rs4->VAL_DESCONTO, 4, "0",STR_PAD_LEFT);
							$pdf->Cell(15,4,"{$des}",0,0,"C");
								
						}else{
								
							$pdf->Cell(15,4,"{$rs4->VAL_DESCONTO}",0,0,"C");
						}
						$val = str_replace(",", ".", $rs4->QUANTIDADE) *str_replace(",", ".", $rs4->VAL_UNITARIO) - str_replace(",", ".", $rs4->VAL_DESCONTO);
						$valtotalp = $valtotalp + $val;
						$pdf->Cell(15,4,"{$funcoes->sanearValor($val)}",0,0,"C");
						$pdf->Ln(4);
							
					}
				}
				$pdf->Ln(1);
				$pdf->Cell(135,4,"",0,0,"L");
				$pdf->Cell(40,4,"TOTAL PECAS........................: ",0,0,"L");
				$pdf->Cell(15,4,"{$funcoes->sanearValor($valtotalp)}",0,0,"C");
				$pdf->Ln(4);
				$pdf->Cell(135,4,"",0,0,"L");
				$pdf->Cell(40,4,"      ITENS BASE DESCONTO: ",0,0,"L");
				$pdf->Cell(15,4,"{$funcoes->sanearValor($valtotalp)}",0,0,"C");
				$pdf->Ln(4);
				$pdf->Cell(135,4,"",0,0,"L");
				$pdf->Cell(40,4,"TOTAL SERVICOS..................: ",0,0,"L");
				$pdf->Cell(15,4,"{$funcoes->sanearValor($valtotals)}",0,0,"C");
				$pdf->Ln(4);
				$pdf->Cell(135,4,"",0,0,"L");
				$pdf->Cell(40,4,"TOTAL ORDEM DE SERVICO:",0,0,"L");
				$total = $valtotals + $valtotalp;
				$pdf->Cell(15,4,"{$funcoes->sanearValor($total)}",0,0,"C");
				$pdf->Ln(4);
				//Natureza do Servi�o
				$pdf->Cell(0,4,"CONDICAO DE PAGAMENTO:",0,0,"L");
				$pdf->Ln(4);
				$pdf->Cell(60,4,"FONTE - NATUREZA - CATEGORIA",0,0,"L");
				$pdf->Cell(50,4,"NR NOTA - SERIE",0,0,"L");
				$pdf->Cell(60,4,"CONDICAO DE PAGAMENTO",0,0,"L");
				$pdf->Cell(15,4,"VALOR",0,0,"L");
				$pdf->Ln(4);
				foreach ($rs5 as $rs5){
						
					$pdf->Cell(60,4,"{$rs[0]->FONTEPAGADORA} - {$rs[0]->NATUREZADOSERVICO} - {$rs[0]->CATEGORIADOVEICULO}",0,0,"L");
					$pdf->Cell(50,4,"{$rs5->NOTA}",0,0,"L");
					$pdf->Cell(60,4,"{$rs5->DES_CONDICAO}",0,0,"L");
					$pdf->Cell(15,4,"{$funcoes->sanearValor($rs5->VALOR)}",0,0,"L");
					$pdf->Ln(4);
						
				}
					
					
				$pdf->Output("OS{$os}.pdf","D");
			}else{
				$this->Alert = "OS N�o encontrada Nessa Empresa/Revenda";
			}
		}

		$this->view();
	}
	
	public function customiza2() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Customiza��o 2";
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$empresa = explode(",",$_POST['empresa']);
			$apiPosvenda = new apiPosvenda();
			$dados = $apiPosvenda->getCargainicial($empresa[0], $empresa[1]);
			$cargainicial = "";
			$arquivoanalise = "";
			if ($empresa[1] == 1){
				$lume = "03770;";
				$filial = "00131;";
				$inicial = "Carga-Inicial-BR-".date("d-m-Y");
				$carga = fopen($_SERVER["DOCUMENT_ROOT"] . "/".RAIZ_PATH.$inicial.".txt",'w');
				$analise = "Arquivo-Analise-BR-".date("d-m-Y");
				$arquivo = fopen($_SERVER["DOCUMENT_ROOT"] . "/".RAIZ_PATH.$analise.".txt",'w');
				$zipname = 'FiatBR.zip';
			}else{
				$lume = "90923;";
				$filial = "00132;";
				$inicial = "Carga-Inicial-DOCA-".date("d-m-Y");
				$carga = fopen($_SERVER["DOCUMENT_ROOT"] . "/".RAIZ_PATH.$inicial.".txt",'w');
				$analise = "Arquivo-Analise-DOCA-".date("d-m-Y");
				$arquivo = fopen($_SERVER["DOCUMENT_ROOT"] . "/".RAIZ_PATH.$analise.".txt",'w');
				$zipname = 'FiatDOCA.zip';
			}
			$codfornecedor = "00001;";
			$fornecedor = str_pad("FIAT AUTOMOVEIS S.A", 50, " ", STR_PAD_RIGHT).";";
			$prazo = "00000;";
			$desconto = "00000;";
			$campolivre = "0000000;";
			foreach ($dados as $rs){
				$coditem = str_pad($rs->COD_ITEM_FABRICANTE, 33, " ", STR_PAD_RIGHT).";";
				$descitem = str_pad($rs->NOME_ITEM_FABRICANTE, 50, " ", STR_PAD_RIGHT).";";
				$especitem = str_pad($rs->ESPECIFICACAO_ITEM, 20, " ", STR_PAD_RIGHT).";";
				$abrevitem = str_pad($rs->ABREV_ESPEC_ITEM, 5, " ", STR_PAD_RIGHT).";";
				$ano = date("Y").";";
				$jan = "0000000;";
				$fev = "0000000;";
				$mar = "0000000;";
				$abr = "0000000;";
				$mai = "0000000;";
				$jun = "0000000;";
				$jul = "0000000;";
				$ago = "0000000;";
				$set = "0000000;";
				$out = "0000000;";
				$nov = "0000000;";
				$dez = "0000000";
				$cargainicial .= $lume.$filial.$codfornecedor.$fornecedor.$prazo.$desconto.$campolivre.$coditem.$descitem.$especitem.$abrevitem.$ano.$jan.$fev.$mar.$abr.$mai.$jun.$jul.$ago.$set.$out.$nov.$dez."\r\n";
				$precovenda = str_pad(str_replace(",", "",str_replace(".","",number_format(str_replace(",", ".",$rs->PRECO_PUBLICO_ATUAL),2))), 10, "0", STR_PAD_LEFT).";";
				$customedio = str_pad(str_replace(",", "",str_replace(".","",number_format(str_replace(",", ".",$rs->CUSTO_MEDIO),4))), 10, "0", STR_PAD_LEFT).";";
				$precogarantia = str_pad(str_replace(",", "",str_replace(".","",number_format(str_replace(",", ".",$rs->PRECO_GARANTIA),2))), 10, "0", STR_PAD_LEFT).";";
				$precoreposicao = str_pad(str_replace(",", "",str_replace(".","",number_format(str_replace(",", ".",$rs->PRECO_ALTERNATIVO),2))), 10, "0", STR_PAD_LEFT).";";
				$primeiracompra = implode("",array_reverse(explode("/",$rs->DTA_DO_CADASTRO))).";";
				$ultcompra = implode("",array_reverse(explode("/",$rs->DTA_ULT_ENTRADA))).";";
				$ultvenda = implode("",array_reverse(explode("/",$rs->DTA_SAIDA))).";";
				$localizacao = str_pad($rs->LOCALIZACAO_FISICA, 20, " ", STR_PAD_RIGHT).";";
				$qtddisponivel = str_pad($rs->QTD_DISPONIVEL, 7, "0", STR_PAD_LEFT).";";
				$qtdcontabil = str_pad($rs->QTD_CONTABIL, 7, "0", STR_PAD_LEFT).";";
				$qtdpedida = str_pad($rs->QTD_PEDIDA, 7, "0", STR_PAD_LEFT).";";
				$qtdembalagem = str_pad($rs->QTD_EMBALAGEM, 7, "0", STR_PAD_LEFT).";";
				$demandamesanterior = "0000000;";
				$demandamesatual = "0000000;";
				$codfabricante = "00001;";
				$bloqueado = $rs->ITEM_BLOQUEADO.";";
				$qtdalocada = str_pad($rs->QTD_ALOCADA, 7, "0", STR_PAD_LEFT).";";
				$arquivoanalise .= $lume.$filial."0000000;00001;".($rs->GRUPO_DESCONTO == "*" ? str_pad("", 10, " ", STR_PAD_RIGHT).";" : str_pad($rs->GRUPO_DESCONTO, 10, " ", STR_PAD_RIGHT).";").$precovenda.$customedio.$precogarantia.$precoreposicao.$primeiracompra.$ultcompra.$ultvenda.$localizacao.$qtddisponivel.$qtdcontabil.$qtdpedida.$qtdembalagem.$demandamesanterior.$demandamesatual.$coditem.$codfabricante.$bloqueado."0000000"."\r\n";
			}
			fwrite($carga, $cargainicial);
			fclose($carga);
			fwrite($arquivo, $arquivoanalise);
			fclose($arquivo);
			$files = array($inicial.".txt",$analise.".txt");
			$zip = new \ZipArchive();
			$zip->open($zipname, \ZipArchive::CREATE);
			foreach ($files as $file){
				$zip->addFile($file);
			}
			$zip->close();
			unlink($_SERVER["DOCUMENT_ROOT"] . "/".RAIZ_PATH.$analise.".txt");
			unlink($_SERVER["DOCUMENT_ROOT"] . "/".RAIZ_PATH.$inicial.".txt");
			ob_end_clean();
			header('Content-Type: application/zip');
			header('Content-disposition: attachment; filename='.$zipname);
			header('Content-Length: ' . filesize($zipname));
			readfile($zipname);
			unlink($_SERVER["DOCUMENT_ROOT"] . "/".RAIZ_PATH.$zipname."");
			die();
		}
		
		$this->view();
	}
}