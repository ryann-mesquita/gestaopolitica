<?php

namespace controller\monaco;


use lib\Controller;
use helper\Security;
use api\monaco\apiDisc;
use helper\Funcoes;
use obj\monaco\Pessoa;
use obj\monaco\Resultado;
use api\geral\apiLog;
use obj\geral\Log;
use obj\adm\Usuario;
use api\adm\apiUsuario;
use helper\Paginator;
use api\geral\apiEmpresa;

class discController extends Controller {
	
	public  function __construct(){
		
		parent::__construct();
		
		if ($this->getAction()['des_acao'] != 'adicionar') {
			new Security($this->getModule(),$this->getController(),$this->getAction());
		}else{
			if (!isset($_SESSION['empresa_sessao'])){
				if (($this->getParams(0) > 0) && ($this->getParams(0) < 43)){
					$_SESSION['empresa_sessao'] = $this->getParams(0);
				}else{
					$_SESSION['empresa_sessao'] = 38;
				}
			}else{
				if (($this->getParams(0) > 0) && ($this->getParams(0) < 43)){
					$_SESSION['empresa_sessao'] = $this->getParams(0);
				}
			}
			if (!isset($_SESSION['nome_sessao'])){
				$_SESSION['nome_sessao'] = "CANDIDATO";
			}
			if (!isset($_SESSION['usuario_sessao'])){
				$_SESSION['usuario_sessao'] = 1134;
			}
		}
	}
	
	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Responder";
		$usuario = new Usuario();
		$usuario->usuario = $_SESSION['usuario_sessao'];
		$apiUsuario = new apiUsuario();
		$pessoa = $apiUsuario->getUsuario($usuario);
		$cpf = $pessoa->CPF;
		$apiDisc = new apiDisc();
		$rs = $apiDisc->getPessoa($cpf);
		if ((is_array($rs) ? count($rs) : 0) > 0){
			$this->Alert = "Voc� j� respondeu o DISC!";
		}else{
			$this->D = $apiDisc->getPerfil('1');
			$this->I = $apiDisc->getPerfil('2');
			$this->S = $apiDisc->getPerfil('3');
			$this->C = $apiDisc->getPerfil('4');
			if ($_SERVER['REQUEST_METHOD'] === 'POST') {
				$opcao = $_POST['opcao'];
				$nome = $pessoa->NOME;
				$empresa = $_SESSION['empresa_sessao'];
				$i = 0;
				$sql = array();
				$pessoa = new Pessoa();
				$pessoa->pessoa = $cpf;
				$pessoa->nome = $nome;
				$pessoa->empresa = $empresa;
				$pessoa->dta_cadastro =  date("d/m/Y");
				$sql[$i] = $apiDisc->addPessoa($pessoa);
				$i = $i+1;
				$resultado = new Resultado();
				$resultado->pessoa = $cpf;
				foreach ($opcao as $rs) {
					$resultado->opcao = $rs;
					$sql[$i] = $apiDisc->addResultado($resultado);
					$i = $i+1;
				}
				$log = new Log();
				$log->historico = "PESSOA;NOME;EMPRESa;DTA_CADASTRO|{$pessoa->pessoa};{$pessoa->nome};{$pessoa->empresa};{$pessoa->dta_cadastro}";
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiDisc->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'monaco/disc/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'monaco/disc/index/sucesso');
					}
				}else{
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		
		$this->view();
	}
	
	public function adicionar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Cadastrar DISC";
		$apiDisc = new apiDisc();
		$this->D = $apiDisc->getPerfil('1');
		$this->I = $apiDisc->getPerfil('2');
		$this->S = $apiDisc->getPerfil('3');
		$this->C = $apiDisc->getPerfil('4');
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$funcoes = new Funcoes();
			$opcao = $_POST['opcao'];
			$cpf = $funcoes->naoNumerico($_POST['cpf']);
			$nome = $_POST['nome'];
			$empresa = $_SESSION['empresa_sessao'];
			$rs = $apiDisc->getPessoa($cpf);
			if ((is_array($rs) ? count($rs) : 0) > 0){
				$this->Alert = "J� existe uma pessoa com esse CPF cadastrado!";
			}else{
				$i = 0;
				$sql = array();
				$pessoa = new Pessoa();
				$pessoa->pessoa = $cpf;
				$pessoa->nome = $nome;
				$pessoa->empresa = $empresa;
				$pessoa->dta_cadastro =  date("d/m/Y");
				$sql[$i] = $apiDisc->addPessoa($pessoa);
				$i = $i+1;
				$resultado = new Resultado();
				$resultado->pessoa = $cpf;
				foreach ($opcao as $rs) {
					$resultado->opcao = $rs;
					$sql[$i] = $apiDisc->addResultado($resultado);
					$i = $i+1;
				}
				$log = new Log();
				$log->historico = "PESSOA;NOME;EMPRESa;DTA_CADASTRO|{$pessoa->pessoa};{$pessoa->nome};{$pessoa->empresa};{$pessoa->dta_cadastro}";
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiDisc->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					header('location:' .APP_ROOT. 'home/auth/auth');
				}else{
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		
		$this->view();
	}
	
	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Altera��o de Empresa";
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		$cpf = $this->getParams(0);
		$apiDisc = new apiDisc();
		$this->dados = array('disc' => $apiDisc->filtroDisc($_SESSION['empresa_sessao'],1,'pessoa',$cpf));
		$apiEmpresa = new apiEmpresa();
		$this->empresa = $apiEmpresa->filtroEmpresa('1', '3', 'ativo', '1');
		if ((is_array($this->dados['disc']) ? count($this->dados['disc']) : 0) == 0){
			header('location:' .APP_ROOT. 'monaco/index/index/acessonegado');
			die();
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$Post = new Pessoa('POST');
			$Post->pessoa = $cpf;
			$log = new Log();
			$log->historico = "EMPRESA||{$this->dados['disc'][0]->EMPRESA}";
			$sql[$i] = $apiDisc->editPessoa($Post);
			$i = $i+1;
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "A";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico .= "::EMPRESA||{$Post->empresa}";
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiDisc->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'monaco/disc/visualizar/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'monaco/disc/visualizar/sucesso');
				}
			}
		}
		$this->view();
	}
	public function visualizar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Consulta DISC";
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		
		$apiDisc = new apiDisc();
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$busca = array(
				'1' => array('c' => '2', 'coluna' => 'nome', 'valor' => @$_POST['busca_valor']),
				'2' => array('c' => '4', 'coluna' => 'pessoa', 'valor' => @$_POST['busca_valor']),
				'3' => array('c' => '3', 'coluna' => "",'valor' => "")
			);
			if(isset($busca[$_POST['busca']])){
				$this->dados = array('disc' => $apiDisc->filtroDisc($_SESSION['empresa_sessao'],$busca[$_POST['busca']]['c'], $busca[$_POST['busca']]['coluna'], $busca[$_POST['busca']]['valor']));
				$_SESSION['filtro_sessao'] = array('c' => $busca[$_POST['busca']]['c'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'busca_valor' => $busca[$_POST['busca']]['valor'], 'busca' => $_POST['busca']);
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'help/index/index/acessonegado');
				die();
			}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				if(!isset($_SESSION['filtro_sessao']['c'])){
					$_SESSION['filtro_sessao'] = array('c' => '3');
				}
				$this->dados = array('disc' => $apiDisc->filtroDisc($_SESSION['empresa_sessao'],$_SESSION['filtro_sessao']['c'],$_SESSION['filtro_sessao']['coluna'], $_SESSION['filtro_sessao']['busca_valor']));
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('disc' => $apiDisc->filtroDisc($_SESSION['empresa_sessao'],'3'));
					$_SESSION['filtro_sessao'] = array('c' => '3', 'coluna' => '' , 'busca_valor' => '', 'busca' => '2');
					$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
				
				$cpf = $this->getParams(0);
				$retorno = $apiDisc->getResultado($cpf);
				if ((is_array($retorno) ? count($retorno) : 0) > 0){
					$this->disc = $retorno;
				}
			
			}
		}
		$usuario = $_SESSION['usuario_sessao'];
		$empresa = $_SESSION['empresa_sessao'];
		$this->permissaoexcluir = $apiDisc->getPermissaoExcluir($usuario, $empresa);
		$TotalItem = (is_array($this->dados['disc']) ? count($this->dados['disc']) : 0);
		$this->dados['disc'] = array_chunk($this->dados['disc'], $ItemPorPagina);
		@$this->dados['disc'] = $this->dados['disc'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}

		$this->view();
	}
	
	public function excluir(){
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Exclus�o de DISC";
		$cpf = $this->getParams(0);
		$apiDisc= new apiDisc();
		$this->dados = array('disc' => $apiDisc->getPessoa($cpf));
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$Post = new Pessoa('POST');
			$Post->pessoa = $cpf;
			$log = new Log();
			$log->historico = "EMPRESA||{$this->dados['disc'][0]->EMPRESA}";
			$sql[$i] = $apiDisc->delDiscResultado($Post);
			$i = $i+1;
			$sql[$i] = $apiDisc->delDiscPessoa($Post);
			$i = $i+1;
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "E";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico = "EMPRESA||{$this->dados['disc'][0]->EMPRESA}";
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiDisc->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'monaco/disc/visualizar/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'monaco/disc/visualizar/sucesso');
				}
			}else{
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}
		
		$this->view();
	}
	
	
	
	
	
}