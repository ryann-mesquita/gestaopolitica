<?php

namespace controller\monaco;

use lib\Controller;
use helper\Security;
use api\monaco\apiPesquisaclima;
use helper\Funcoes;
use api\geral\apiEmpresa;
use obj\geral\Empresa;
use api\adm\apiCargo;
use api\adm\apiDepartamento;

include 'classes/FPDF/fpdf.php';

class recursoshumanosController extends Controller {
	
	public function __construct() {
		
		parent::__construct();
		
		new Security($this->getModule(),$this->getController(),$this->getAction());
	}
	
	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Acompanhamento";
		$funcoes = new Funcoes();
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$this->ano = $_POST['ano'];
			$apiPesquisaclima = new apiPesquisaclima();
			$quemrespondeu = $apiPesquisaclima->getQuemrespondeu($this->ano);
			$totalrespostasea = array();
			$totalrespostase = array();
			$totalrespostasga = array();
			$totalrespostasg = array();
			$resp = array();
			foreach ($quemrespondeu as $rs) {
				$totalrespostasea[$rs->EMPRESA][$rs->AREA] = $rs->EA_RESPONDIDOS;
				$totalrespostase[$rs->EMPRESA] = $rs->E_RESPONDIDOS;
				$totalrespostasga[0][$rs->AREA] = $rs->GA_RESPONDIDOS;
				$totalrespostasg[0] = $rs->G_RESPONDIDOS;
			}
			$empresa = $apiPesquisaclima->getTotalpesquisa($this->ano);
			$totalea = array();
			$totale = array();
			$totalga = array();
			$totalg = array();
			$totaleres = array();
			$totalgres = array();
			$concordanciaea = array();
			$concordanciae = array();
			$concordanciaga = array();
			$concordanciag = array();
			$satisfacaoea = array();
			$satisfacaoe = array();
			$satisfacaoga = array();
			$satisfacaog = array();
			foreach ($empresa as $rs) {
				@$totalea[$rs->EMPRESA][$rs->AREA] = $totalea[$rs->EMPRESA][$rs->AREA] + $rs->EA_QUANTIDADE;
				$totaleres[$rs->EMPRESA]["{$rs->VAL_RESPOSTA}"] = $rs->E_QUANTIDADE;
				@$totale[$rs->EMPRESA] = $totaleres[$rs->EMPRESA]['N'] + $totaleres[$rs->EMPRESA]['P'];
				$totalga[0][$rs->AREA] = @$totalga[0][$rs->AREA] + $rs->EA_QUANTIDADE;
				$totalgres["{$rs->VAL_RESPOSTA}"] = $rs->G_QUANTIDADE;
				@$totalg[0] = $totalgres['N'] + $totalgres['P'];
				$concordanciaea[$rs->EMPRESA][$rs->AREA]["{$rs->VAL_RESPOSTA}"] = $rs->EA_QUANTIDADE;
				$concordanciae[$rs->EMPRESA]["{$rs->VAL_RESPOSTA}"] = $rs->E_QUANTIDADE;
				$concordanciaga[0][$rs->AREA]["{$rs->VAL_RESPOSTA}"] = $rs->GA_QUANTIDADE;
				$concordanciag[0]["{$rs->VAL_RESPOSTA}"] = $rs->G_QUANTIDADE;
				@$satisfacaoea[$rs->EMPRESA][$rs->AREA]= round(( $concordanciaea[$rs->EMPRESA][$rs->AREA]["P"] * 100 ) / $totalea[$rs->EMPRESA][$rs->AREA],2);
				@$satisfacaoe[$rs->EMPRESA] = round(( $concordanciae[$rs->EMPRESA]["P"] * 100 ) / $totale[$rs->EMPRESA],2);
				//@$satisfacaoe[$rs->EMPRESA] = round(( $concordanciae[$rs->EMPRESA]["P"] * 100 ) / $totalg[0],2);
				@$satisfacaoga[0][$rs->AREA]= round(( $concordanciaga[0][$rs->AREA]["P"] * 100 ) / $totalga[0][$rs->AREA],2);
				@$satisfacaog[0] = round(( $concordanciag[0]["P"] * 100 ) / $totalg[0],2);
				$this->empresaea[$rs->EMPRESA][$rs->AREA]= array('empresa' => $rs->EMPRESA, 'des_empresa' => $rs->DES_EMPRESA, 'area' => $rs->AREA, 'des_area' => $rs->DES_AREA,'totalrespostas' => $totalrespostasea[$rs->EMPRESA][$rs->AREA], 'satisfacao' => $satisfacaoea[$rs->EMPRESA][$rs->AREA]);
				$this->empresae[$rs->EMPRESA] = array('empresa' => $rs->EMPRESA, 'des_empresa' => $rs->DES_EMPRESA, 'totalrespostas' => $totalrespostase[$rs->EMPRESA], 'satisfacao' => $satisfacaoe[$rs->EMPRESA]);
				$this->empresaga[0][$rs->AREA]= array('empresa' => 0, 'des_empresa' => utf8_encode('GRUPO M�NACO'), 'area' => $rs->AREA, 'des_area' => $rs->DES_AREA, 'totalrespostas' => $totalrespostasga[0][$rs->AREA], 'satisfacao' => $satisfacaoga[0][$rs->AREA]);
				$this->empresag[0] = array('empresa' => 0, 'des_empresa' => 'GRUPO M�NACO', 'totalrespostas' => $totalrespostasg[0], 'satisfacao' => $satisfacaog[0]);
				//$this->satisfacao[$rs->EMPRESA] = array('empresa' => $rs->EMPRESA, 'des_empresa' => $rs->DES_EMPRESA, 'totalrespostas' => $totalrespostase[$rs->EMPRESA], 'satisfacao' => $satisfacaoe[$rs->EMPRESA]);
			}
			$perguntas = $apiPesquisaclima->getPesquisa($this->ano);
			$totaltopicoea = array();
			$totaltopicoe = array();
			$totaltopicoga = array();
			$totaltopicog = array();
			$totalperguntaea = array();
			$totalperguntae = array();
			$totalperguntaga = array();
			$totalperguntag = array();
			foreach ($perguntas as $rs) {
				$totaltopicoea[$rs->EMPRESA][$rs->AREA] = round(( number_format(str_replace(",", ".", $rs->EA_SATISFACAO_TOPICO),2) * 100 ) /$totalrespostasea[$rs->EMPRESA][$rs->AREA],2);
				$totaltopicoe[$rs->EMPRESA] = round(( number_format(str_replace(",", ".", $rs->E_SATISFACAO_TOPICO),2) * 100 ) / $totalrespostase[$rs->EMPRESA],2);
				$totaltopicoga[0][$rs->AREA] = round(( number_format(str_replace(",", ".", $rs->GA_SATISFACAO_TOPICO),2)* 100 ) / $totalrespostasga[0][$rs->AREA],2);
				$totaltopicog[0] = round(( number_format(str_replace(",", ".", $rs->G_SATISFACAO_TOPICO),2)* 100 ) / $totalrespostasg[0],2);
				$this->topicosea[$rs->EMPRESA][$rs->AREA][$rs->TOPICO] = array('area' => $rs->AREA, 'des_area' => $rs->DES_AREA,'topico' => $rs->TOPICO, 'des_topico' => utf8_encode($rs->DES_TOPICO), 'satisfacao' => $totaltopicoea[$rs->EMPRESA][$rs->AREA]);
				$this->topicose[$rs->EMPRESA][$rs->TOPICO] = array('topico' => $rs->TOPICO, 'des_topico' => utf8_encode($rs->DES_TOPICO), 'satisfacao' => $totaltopicoe[$rs->EMPRESA]);
				$this->topicosga[0][$rs->AREA][$rs->TOPICO] = array('topico' => $rs->TOPICO, 'des_topico' => $rs->DES_TOPICO, 'satisfacao' => $totaltopicoga[0][$rs->AREA]);
				$this->topicosg[0][$rs->TOPICO] = array('topico' => $rs->TOPICO, 'des_topico' => $rs->DES_TOPICO, 'satisfacao' => $totaltopicog[0]);
				$totalperguntaea[$rs->EMPRESA][$rs->AREA]= round(( $rs->EA_SATISFACAO_PERGUNTA * 100 ) / $totalrespostasea[$rs->EMPRESA][$rs->AREA],2);
				$totalperguntae[$rs->EMPRESA]= round(( $rs->E_SATISFACAO_PERGUNTA * 100 ) / $totalrespostase[$rs->EMPRESA],2);
				$totalperguntaga[0][$rs->AREA]= round(( $rs->GA_SATISFACAO_PERGUNTA * 100 ) / $totalrespostasga[0][$rs->AREA],2);
				$totalperguntag[0] = round(( $rs->G_SATISFACAO_PERGUNTA * 100 ) / $totalrespostasg[0],2);
				$this->perguntasea[$rs->EMPRESA][$rs->AREA][$rs->TOPICO][$rs->PERGUNTA] = array('pergunta' => $rs->PERGUNTA, 'des_pergunta' => utf8_encode($rs->DES_PERGUNTA), 'satisfacao' => $totalperguntaea[$rs->EMPRESA][$rs->AREA]);
				$this->perguntase[$rs->EMPRESA][$rs->TOPICO][$rs->PERGUNTA] = array('pergunta' => $rs->PERGUNTA, 'des_pergunta' => utf8_encode($rs->DES_PERGUNTA), 'satisfacao' => $totalperguntae[$rs->EMPRESA]);
				$this->perguntasga[0][$rs->AREA][$rs->TOPICO][$rs->PERGUNTA] = array('pergunta' => $rs->PERGUNTA, 'des_pergunta' => utf8_encode($rs->DES_PERGUNTA), 'satisfacao' => $totalperguntaga[0][$rs->AREA]);
				$this->perguntasg[0][$rs->TOPICO][$rs->PERGUNTA] = array('pergunta' => $rs->PERGUNTA, 'des_pergunta' => utf8_encode($rs->DES_PERGUNTA), 'satisfacao' => $totalperguntag[0]);
				$this->respostasea[$rs->EMPRESA][$rs->AREA][$rs->TOPICO][$rs->PERGUNTA][$rs->RESPOSTA] = array('resposta' => $rs->RESPOSTA, 'quantidade' => $rs->EA_QUANTIDADE, 'des_resposta' => $rs->DES_RESPOSTA);
				$this->respostase[$rs->EMPRESA][$rs->TOPICO][$rs->PERGUNTA][$rs->RESPOSTA] = array('resposta' => $rs->RESPOSTA, 'quantidade' => $rs->E_QUANTIDADE, 'des_resposta' => utf8_encode($rs->DES_RESPOSTA));
				$this->respostasga[0][$rs->AREA][$rs->TOPICO][$rs->PERGUNTA][$rs->RESPOSTA] = array('resposta' => $rs->RESPOSTA, 'quantidade' => $rs->GA_QUANTIDADE, 'des_resposta' => $rs->DES_RESPOSTA);
				$this->respostasg[0][$rs->TOPICO][$rs->PERGUNTA][$rs->RESPOSTA] = array('resposta' => $rs->RESPOSTA, 'quantidade' => $rs->G_QUANTIDADE, 'des_resposta' => $rs->DES_RESPOSTA);
			}
		}
		$this->view();
	}
	
	public function visualizar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Acompanhamento";
		$apiPesquisaclima = new apiPesquisaclima();
		$this->empresa = $apiPesquisaclima->getEmpresasugestao();
		
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$empresa = $_POST['empresa'];
			$ano = $_POST['ano'];
			$this->sugestoes = $apiPesquisaclima->getSugestoes($empresa,$ano);
			$_SESSION['filtro_sessao'] = array('empresa' => $empresa, 'ano' => $ano);
		}
		
		$this->view();
	}
	
	public function customiza1() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Requisi��o de MP/RP";
		$apiCargo = new apiCargo();
		$cargo = $apiCargo->filtroCargo('1','3','ativo', '1');
		foreach ($cargo as $rs){
			$this->cargo[$rs->CARGO] = array('cargo' => $rs->CARGO, 'des_cargo' => $rs->DES_CARGO);
		}
		$apiDepartamento = new apiDepartamento();
		$departamento = $apiDepartamento->filtroDepartamento('1','3','ativo', '1');
		foreach ($departamento as $rs){
			$this->departamento[$rs->DEPARTAMENTO] = array('departamento' => $rs->DEPARTAMENTO, 'des_departamento' => $rs->DES_DEPARTAMENTO);
		}
		$apiEmpresa = new apiEmpresa();
		$emp = $apiEmpresa->filtroEmpresa('1','3','ativo', '1');
		foreach ($emp as $rs){
			$this->empresa[$rs->EMPRESA] = array('empresa' => $rs->EMPRESA, 'des_empresa' => $rs->DES_EMPRESA);
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$funcoes = new Funcoes();
			$data_atual = date("d/m/Y");
			$requisicao = $_POST['requisicao'];
			$apiEmpresa = new apiEmpresa();
			$empresa = new Empresa();
			$empresa->empresa = $_SESSION['empresa_sessao'];
			$emp = $apiEmpresa->getEmpresa($empresa);
			//Dados da Empresa
			$razao = $emp->RAZAO_SOCIAL;
			$nome = strtoupper($_SESSION['nome_sessao']);
			if ($requisicao == "mpd"){
				$funcionario = strtoupper($funcoes->retiraAcentos(trim($_POST['funcionario'])));
				$dta_admissao = $_POST['dta_admissao'];
				$dta_demissao = $_POST['dta_demissao'];
				$motivo = $_POST['motivo'];
				$pdf = new \FPDF();
				$pdf->AddPage();
				$pdf->Rect(10, 10, 191, 265, 'D');
				//Cabe�alho
				$pdf->Image(APP_ROOT."content/geral/img/monalog.png",15,11,16,14);
				$pdf->SetFont('arial','B',10);
				$pdf->Cell(172,6,"DATA",0,0,'R');
				$pdf->SetFont('arial','B',15);
				$pdf->Ln(6);
				$pdf->Cell(165,6,"MOVIMENTA��O DE PESSOAL",0,0,'C');
				$pdf->Image(APP_ROOT."content/geral/img/rhlog.jpg",150,11,16,14);
				$pdf->Line(170, 10, 170, 26);
				$pdf->SetFont('arial','B',10);
				$pdf->Cell(19,16,"{$data_atual}",0,0,'R');
				$pdf->Ln(10);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(1);
				$pdf->SetFont('arial','B',13);
				$pdf->Cell(185,4,"Demiss�o",0,0,'C');
				$pdf->Ln(5);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(2);
				$pdf->SetFont('arial','B',10);
				$pdf->Cell(5,4,"1",0,0,'L');
				$pdf->Line(15, 39, 15, 32);
				$pdf->Cell(20,4,"EMPRESA: ",0,0,'L');
				$pdf->Cell(150,4,"{$razao}",0,0,'L');
				$pdf->Ln(5);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(2);
				$pdf->SetFont('arial','B',10);
				$pdf->Cell(17,4,"GESTOR: ",0,0,'L');
				$pdf->Cell(150,4,"{$nome}",0,0,'L');
				$pdf->Ln(5);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(2);
				$pdf->SetFont('arial','B',10);
				$pdf->Cell(5,4,"2",0,0,'L');
				$pdf->Line(15, 53, 15, 46);
				$pdf->Cell(180,4,"DADOS PESSOAIS",0,0,'C');
				$pdf->Ln(5);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(1);
				$pdf->SetFont('arial','B',10);
				$pdf->Cell(40,4,"NOME COLABORADOR",0,0,'L');
				$pdf->Cell(80,12,"{$funcionario}",0,0,'C');
				$pdf->Ln(8);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(2);
				$pdf->SetFont('arial','B',10);
				$pdf->Cell(21,4,"ADMISS�O: ",0,0,'L');
				$pdf->Cell(50,4,"{$dta_admissao}",0,0,'L');
				$pdf->Line(100, 69, 100, 62);
				$pdf->Cell(42,4,"DEMISS�O: ",0,0,'R');
				$pdf->Cell(18,4,"{$dta_demissao}",0,0,'R');
				$pdf->Ln(5);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(1);
				$pdf->SetFont('arial','B',10);
				$pdf->Cell(5,4,"MOTIVO DETALHADO: ",0,0,'L');
				$pdf->Ln(4);
				$pdf->MultiCell(190,4,$motivo,0,'L',false);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->SetXY(10, 255);
				$pdf->SetFont('arial','B',10);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(1);
				$pdf->Cell(180,4,"Assinatura para Aprova��o desta movimenta��o:",0,0,'C');
				$pdf->Ln(4);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(1);
				$pdf->MultiCell(50,3,"SUPERVISOR/GERENTE/ SOLICITANTE","R",'C');
				$pdf->MultiCell(100,-7,"GEST�O COM PESSOAS    ",'R','R');
				$pdf->MultiCell(145,7,"DIRETOR/GG DA �REA    ",'R','R');
				$pdf->MultiCell(185,-7,"DIRETORA DHO  ",0,'R');
				$pdf->Ln(7);
				//$pdf->Cell(50,12,"","R",1,'L');
				$pdf->Cell(50,8,"______________   ___/___/___","R",0,'L');
				$pdf->Cell(50,8,"______________   ___/___/___","R",0,'R');
				$pdf->Cell(45,8,"____________   ___/___/___","R",0,'R');
				$pdf->Cell(45,8,"_______________   ___/___/___",0,0,'R');
			
				$pdf->Output("MPD-".date("d-m-Y").".pdf","D");
			}
			
			if ($requisicao == "mpm"){
				$funcionario = strtoupper($funcoes->retiraAcentos(trim($_POST['funcionario'])));
				$dta_admissao = $_POST['dta_admissao'];
				$motivo = $_POST['motivo'];
				$pdf = new \FPDF();
				$pdf->AddPage();
				$pdf->Rect(10, 10, 191, 265, 'D');
				//Cabe�alho
				$pdf->Image(APP_ROOT."content/geral/img/monalog.png",15,11,16,14);
				$pdf->SetFont('arial','B',10);
				$pdf->Cell(172,6,"DATA",0,0,'R');
				$pdf->SetFont('arial','B',15);
				$pdf->Ln(6);
				$pdf->Cell(165,6,"MOVIMENTA��O DE PESSOAL",0,0,'C');
				$pdf->Image(APP_ROOT."content/geral/img/rhlog.jpg",150,11,16,14);
				$pdf->Line(170, 10, 170, 26);
				$pdf->SetFont('arial','B',10);
				$pdf->Cell(19,16,"{$data_atual}",0,0,'R');
				$pdf->Ln(10);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(1);
				$pdf->SetFont('arial','B',13);
				$pdf->Cell(185,4,"Movimenta��o",0,0,'C');
				$pdf->Ln(5);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(2);
				$pdf->SetFont('arial','B',10);
				$pdf->Cell(5,4,"1",0,0,'L');
				$pdf->Line(15, 39, 15, 32);
				$pdf->Cell(20,4,"EMPRESA: ",0,0,'L');
				$pdf->Cell(150,4,"{$razao}",0,0,'L');
				$pdf->Ln(5);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(2);
				$pdf->SetFont('arial','B',10);
				$pdf->Cell(17,4,"GESTOR: ",0,0,'L');
				$pdf->Cell(150,4,"{$nome}",0,0,'L');
				$pdf->Ln(5);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(2);
				$pdf->SetFont('arial','B',10);
				$pdf->Cell(5,4,"2",0,0,'L');
				$pdf->Line(15, 53, 15, 46);
				$pdf->Cell(180,4,"DADOS PESSOAIS",0,0,'C');
				$pdf->Ln(5);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(1);
				$pdf->SetFont('arial','B',10);
				$pdf->Cell(40,4,"NOME COLABORADOR",0,0,'L');
				$pdf->Cell(80,12,"{$funcionario}",0,0,'C');
				$pdf->SetFont('arial','B',8);
				$pdf->Cell(69,3,"Data de Admiss�o:",0,0,'R');
				$pdf->Cell(-28,12,"{$dta_admissao}",0,0,'C');
				$pdf->Line(170, 62, 170, 53);
				$pdf->Ln(8);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(2);
				$pdf->SetFont('arial','B',10);
				$pdf->Cell(5,4,"3",0,0,'L');
				$pdf->Line(15, 69, 15, 62);
				$pdf->Cell(180,4,"ALTERA��O SOLICITADA",0,0,'C');
				$pdf->Ln(5);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(1);
				if (isset($_POST['de_cargo'])){
					$pdf->Cell(22,4,"DE CARGO: ",0,0,'L');
					$pdf->Cell(80,4,"{$this->cargo[$_POST['de_cargo']]['des_cargo']}",0,0,'L');
					$pdf->Cell(100,4,"PARA: {$this->cargo[$_POST['para_cargo']]['des_cargo']}",0,0,'L');
					$pdf->Ln(5);
					$pdf->Cell(0,0,"","B",0,'C');
					$pdf->Ln(1);
				}
				if (isset($_POST['de_departamento'])){
					$pdf->Cell(22,4,"DE DEPT.: ",0,0,'L');
					$pdf->Cell(80,4,"{$this->departamento[$_POST['de_departamento']]['des_departamento']}",0,0,'L');
					$pdf->Cell(100,4,"PARA: {$this->departamento[$_POST['para_departamento']]['des_departamento']}",0,0,'L');
					$pdf->Ln(5);
					$pdf->Cell(0,0,"","B",0,'C');
					$pdf->Ln(1);
				}
				if (isset($_POST['de_salario'])){
					$pdf->Cell(24,4,"DE SAL�RIO: ",0,0,'L');
					$pdf->Cell(78,4,"R$ {$_POST['de_salario']}",0,0,'L');
					$pdf->Cell(100,4,"PARA: R$ {$_POST['para_salario']}",0,0,'L');
					$pdf->Ln(5);
					$pdf->Cell(0,0,"","B",0,'C');
					$pdf->Ln(1);
				}
				if (isset($_POST['de_empresa'])){
					$pdf->Cell(25,4,"DE EMPRESA: ",0,0,'L');
					$pdf->Cell(77,4,"{$this->empresa[$_POST['de_empresa']]['des_empresa']}",0,0,'L');
					$pdf->Cell(98,4,"PARA: {$this->empresa[$_POST['para_empresa']]['des_empresa']}",0,0,'L');
					$pdf->Ln(5);
					$pdf->Cell(0,0,"","B",0,'C');
					$pdf->Ln(1);
				}
				if (isset($_POST['substituido'])){
					$substituido = strtoupper($funcoes->retiraAcentos(trim($_POST['substituido'])));
					$pdf->Cell(65,4,"SUBSTITUI��O DO COLABORADOR: ",0,0,'L');
					$pdf->Cell(100,4,"{$substituido}",0,0,'L');
					$pdf->Ln(5);
					$pdf->Cell(0,0,"","B",0,'C');
					$pdf->Ln(1);
				}
				$pdf->SetFont('arial','B',10);
				$pdf->Ln(-1);
				$pdf->Cell(5,5,"4",'R',0,'L');
				$pdf->Cell(180,5,"INFORMA��ES COMPLEMENTARES",0,0,'C');
				$pdf->Ln(5);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(1);
				$pdf->SetFont('arial','B',10);
				$pdf->Cell(65,4,"MOTIVA��O PROMO��O: ",0,0,'L');
				if ($_POST['promocao'] == 'E'){
					$promocao = "ESPONT�NEO";
				}elseif ($_POST['promocao'] == 'M'){
					$promocao = "M�RITO";
				}else{
					$promocao = "AVALIA��O DE DESEMPENHO";
				}
				$pdf->Cell(100,4,"{$promocao}",0,0,'C');
				$pdf->Ln(5);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(1);
				if ($_POST['avaliacao'] == 'S'){
					$avaliacao = "SIM";
				}else{
					$avaliacao = "N�O";
				}
				$pdf->SetFont('arial','B',10);
				$pdf->Cell(95,4,"O COLABORADOR PASSOU POR AVALIA��O NO RH: ",0,0,'L');
				$pdf->Cell(0,4,"{$avaliacao}",0,0,'L');
				$pdf->Ln(3);
				$pdf->SetFont('arial','B',8);
				$pdf->Cell(1,5,"(Entevistas e Testes)",0,0,'L');
				$pdf->Ln(5);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(0);
				$pdf->SetFont('arial','B',10);
				$pdf->Cell(57,5,"TEMPO NA FUN��O ANTERIOR: ",0,0,'L');
				$tempo_funcao = strtoupper(trim($_POST['tempo_funcao']));
				$pdf->Cell(84,5,"{$tempo_funcao}",0,0,'L');
				$pdf->Cell(50,5,"Data da Vig�ncia: {$_POST['dta_vigencia']}","L",0,'R');
				$pdf->Ln(5);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(1);
				$pdf->SetFont('arial','B',10);
				$pdf->Cell(5,4,"MOTIVO DETALHADO: ",0,0,'L');
				$pdf->Ln(4);
				$pdf->MultiCell(190,4,$motivo,0,'L',false);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->SetXY(10, 255);
				$pdf->SetFont('arial','B',10);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(1);
				$pdf->Cell(180,4,"Assinatura para Aprova��o desta movimenta��o:",0,0,'C');
				$pdf->Ln(4);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(1);
				$pdf->MultiCell(50,3,"SUPERVISOR/GERENTE/ SOLICITANTE","R",'C');
				$pdf->MultiCell(100,-7,"GEST�O COM PESSOAS    ",'R','R');
				$pdf->MultiCell(145,7,"DIRETOR/GG DA �REA    ",'R','R');
				$pdf->MultiCell(185,-7,"DIRETORA DHO  ",0,'R');
				$pdf->Ln(7);
				//$pdf->Cell(50,12,"","R",1,'L');
				$pdf->Cell(50,8,"______________   ___/___/___","R",0,'L');
				$pdf->Cell(50,8,"______________   ___/___/___","R",0,'R');
				$pdf->Cell(45,8,"____________   ___/___/___","R",0,'R');
				$pdf->Cell(45,8,"_______________   ___/___/___",0,0,'R');
				
				$pdf->Output("MPM-".date("d-m-Y").".pdf","D");
			}
			
			if ($requisicao == "rp"){
				$pdf = new \FPDF();
				$pdf->AddPage();
				$pdf->Rect(10, 10, 191, 265, 'D');
				//Cabe�alho
				$pdf->Image(APP_ROOT."content/geral/img/monalog.png",15,11,16,14);
				$pdf->SetFont('arial','B',15);
				$pdf->Ln(6);
				$pdf->Cell(190,6,"REQUISI��O DE PESSOAL",0,0,'C');
				$pdf->Image(APP_ROOT."content/geral/img/rhlog.jpg",182,11,16,14);
				$pdf->Ln(10);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(1);
				$pdf->SetFont('arial','B',9);
				$pdf->Cell(26,4,"REQUISITANTE:",0,0,'L');
				$pdf->SetFont('arial','',6);
				$pdf->Cell(59,4,"{$razao}",0,0,'L');
				$pdf->Line(110, 32, 110, 26);
				$pdf->SetFont('arial','B',9);
				$pdf->Cell(35,4,"TELEFONE:",0,0,'R');
				$pdf->SetFont('arial','',6);
				$pdf->Cell(15,4,"{$_POST['telefone']}",0,0,'R');
				$pdf->Ln(5);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(1);
				$pdf->SetFont('arial','B',9);
				$pdf->Cell(36,4,"CARGO SOLICITANTE:",0,0,'L');
				$pdf->SetFont('arial','',6);
				$pdf->Cell(64,4,"{$this->cargo[$_POST['cargo']]['des_cargo']}",0,0,'L');
				$pdf->Line(110, 38, 110, 32);
				$pdf->SetFont('arial','B',9);
				$pdf->Cell(13,4,"SETOR: ",0,0,'L');
				$pdf->SetFont('arial','',6);
				$pdf->Cell(60,4,"{$this->departamento[$_POST['departamento']]['des_departamento']}",0,0,'L');
				$pdf->Ln(5);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(1);
				$pdf->SetFont('arial','B',9);
				$pdf->Cell(37,4,"PROCESSO SIGILOSO:",0,0,'L');
				$pdf->SetFont('arial','',6);
				if ($_POST['sigiloso'] == 'S'){
					$sigiloso = 'SIM';
				}else{
					$sigiloso = 'N�O';
				}
				$pdf->Cell(63,4,"{$sigiloso}",0,0,'L');
				$pdf->Line(110, 44, 110, 38);
				$pdf->SetFont('arial','B',9);
				$pdf->Cell(31,4,"PONTO DE VENDA: ",0,0,'L');
				$pdf->SetFont('arial','',6);
				$ponto_venda = strtoupper(trim($_POST['ponto_venda']));
				$pdf->Cell(60,4,"{$ponto_venda}",0,0,'L');
				$pdf->Ln(5);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(1);
				$pdf->SetFont('arial','B',9);
				$pdf->Cell(23,4,"N� DE VAGAS:",0,0,'L');
				$pdf->SetFont('arial','',6);
				$n_vaga = trim($_POST['n_vaga']);
				$pdf->Cell(27,4,"{$n_vaga}",0,0,'L');
				$pdf->SetFont('arial','B',9);
				$pdf->Cell(34,4,"DATA DE ADMISS�O:",0,0,'L');
				$pdf->SetFont('arial','',6);
				$dta_admissao = $_POST['dta_admissao'];
				$pdf->Cell(16,4,"$dta_admissao",0,0,'L');
				$pdf->Line(60, 50, 60, 44);
				$pdf->Line(110, 50, 110, 44);
				$pdf->SetFont('arial','B',9);
				$pdf->Cell(37,4,"DATA DA REQUISI��O:",0,0,'L');
				$pdf->SetFont('arial','',6);
				$pdf->Cell(60,4,"{$data_atual}",0,0,'L');
				$pdf->Ln(5);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(1);
				$pdf->SetFont('arial','B',9);
				$pdf->Cell(100,4,"JUSTIFICATIVA DA REQUISI��O:",0,0,'L');
				$pdf->Cell(34,4,"PERFIL SOLICITADO:",0,1,'L');
				$pdf->SetFont('arial','',6);
				if ($_POST['justificativa'] == 'A'){
					$justificativa = 'AMPLIA��O DO QUADRO';
				}else{
					$justificativa = 'SUBSTITUI��O';
				}
				$pdf->Cell(100,4,"{$justificativa}",0,0,'L');
				$pdf->SetFont('arial','',6);
				if ($_POST['genero'] == 'M'){
					$genero = 'MASCULINO';
				}else{
					$genero = 'FEMININO';
				}
				$pdf->Cell(60,4,"SEXO: {$genero}",0,1,'L');
				if ($_POST['justificativa'] == 'S'){
					$substituido = strtoupper(trim($_POST['substituido']));
					$pdf->Cell(16,4,"SUBSTITUIDO:",0,0,'L');
					$pdf->Cell(84,4,"{$substituido}",0,0,'L');
				}else{
					$pdf->Cell(100,4,"",0,0,'L');
				}
				$pdf->Cell(60,4,"IDADE: {$_POST['idade']}",0,1,'L');
				if ($_POST['justificativa'] == 'S'){
					$dta_demissao = $_POST['dta_demissao'];
					$pdf->Cell(24,4,"DATA DESLIGAMENTO:",0,0,'L');
					$pdf->Cell(76,4,"{$dta_demissao}",0,0,'L');
				}else{
					$pdf->Cell(100,4,"",0,0,'L');
				}
				if ($_POST['estado_civil'] == 'S'){
					$estado_civil = "SOLTEIRO";
				}elseif ($_POST['estado_civil'] == 'C'){
					$estado_civil = "CASADO";
				}elseif ($_POST['estado_civil'] == 'U'){
					$estado_civil = "UNI�O EST�VEL";
				}else{
					$estado_civil = "DIVORCIADO";
				}
				$pdf->Cell(60,4,"ESTADO CIVIL: {$estado_civil}",0,1,'L');
				$pdf->Cell(100,4,"",0,0,'L');
				if ($_POST['perfil'] == 'J'){
					$perfil = "JUNIOR";
				}elseif ($_POST['perfil'] == 'P'){
					$perfil = "PLENO";
				}else{
					$perfil = "S�NIOR";
				}
				$pdf->Cell(60,4,"PERFIL: {$perfil}",0,1,'L');
				$pdf->Line(110, 71, 110, 50);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(1);
				$pdf->SetFont('arial','B',9);
				$pdf->Cell(180,4,"DADOS DO CARGO:",0,0,'C');
				$pdf->Ln(5);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(1);
				$pdf->SetFont('arial','B',9);
				$pdf->Cell(27,4,"REMUNERA��O:",0,0,'L');
				$pdf->SetFont('arial','',6);
				$pdf->Cell(73,4,"R$ {$_POST['remuneracao']}",0,0,'L');
				$pdf->Line(110, 83, 110, 77);
				$pdf->SetFont('arial','B',9);
				$pdf->Cell(17,4,"HOR�RIO:",0,0,'L');
				$pdf->SetFont('arial','',6);
				if ($_POST['horario_trabalho'] == '1'){
					$horario = "07:42 as 17:30 (SEG A SEX)";
				}elseif ($_POST['horario_trabalho'] == '2'){
					$horario = "08:00 as 17:48 (SEG A SEX)";
				}else{
					$horario = "A COMBINAR COM GESTOR";
				}
				$pdf->Cell(83,4,"{$horario}",0,0,'L');
				$pdf->Ln(5);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(1);
				$pdf->Ln(1);
				$pdf->SetFont('arial','B',9);
				$pdf->Cell(5,4,"COMPET�NCIAS ADICIONAIS: ",0,0,'L');
				$pdf->Ln(4);
				$competencia = $_POST['competencia'];
				$pdf->SetFont('arial','',9);
				$pdf->MultiCell(190,4,$competencia,0,'L',false);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->SetXY(10, 243);
				$pdf->SetFont('arial','B',10);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(1);
				$pdf->Cell(180,4,"Assinatura e Aprova��o requisi��o:",0,0,'C');
				$pdf->Ln(4);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(1);
				$pdf->Cell(100,4,"Solicitante da vaga(Gestor):",0,0,'L');
				$pdf->Cell(34,4,"Gerente:",0,1,'L');
				$pdf->Ln(4);
				$pdf->Line(110, 248, 110, 261);
				$pdf->Cell(100,4,"Data:___/___/______  _______________________",0,0,'L');
				$pdf->Cell(100,4,"Data:___/___/______  _______________________",0,0,'L');
				$pdf->Ln(4);
				$pdf->Cell(0,0,"","B",0,'C');
				$pdf->Ln(1);
				$pdf->Cell(180,4,"Assinatura e Aprova��o para aumento de quadro (Gerente Geral/Diretor):",0,1,'C');
				$pdf->Ln(4);
				$pdf->Cell(200,4,"Data:___/___/______  _________________________________",0,0,'L');
				
				$pdf->Output("RP-".date("d-m-Y").".pdf","D");
			}
			
		}
		
		$this->view();
		
	}
}