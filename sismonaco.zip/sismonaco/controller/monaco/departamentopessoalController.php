<?php

namespace controller\monaco;

use lib\Controller;
use helper\Security;
use api\adm\apiPermissao;
use obj\adm\Permissao;
use api\geral\apiFuncionario;

class departamentopessoalController extends Controller {

	public function __construct() {

		parent::__construct();

		new Security($this->getModule(),$this->getController(),$this->getAction());
	}

	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Departamento Pessoal";
		$this->view();
	}

	public function customiza1() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Customiza��o 1";
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$anexo = fopen($_FILES['anexo']['tmp_name'],'r');
			$exporte = "";
			while(!feof($anexo)) {
				$linha = fgets($anexo, 24);
				$verificador = substr($linha, 12, 1);
				if ($verificador == "-"){
					$sequencia = substr($linha, 0, 12)."0".substr($linha, 13, 10)."\r\n";
					if (strlen($sequencia) > 20){
						$exporte .= $sequencia;
					}
				}else{
					$sequencia = substr($linha, 0, 13)."0000000000\r\n";
					if (strlen($sequencia) > 20){
						$exporte .= $sequencia;
					}
				}
			}
			$nome = "Ponto-".date("d-m-Y");
			$arquivo = fopen($_SERVER["DOCUMENT_ROOT"] . "/".RAIZ_PATH.$nome.".txt", "w");
			fwrite($arquivo, $exporte);
			fclose($anexo);
			fclose($arquivo);
			ob_end_clean();
			header('Content-type: text/plain');
			header("Content-Disposition: attachment;filename={$nome}.txt");
			header("Pragma: no-cache");
			header("Expires: 0");
			readfile($_SERVER["DOCUMENT_ROOT"] . "/".RAIZ_PATH.$nome.".txt");
			unlink($_SERVER["DOCUMENT_ROOT"] . "/".RAIZ_PATH.$nome.".txt");
			die();
		}

		$this->view();
	}

	public function customiza2() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Customiza��o 2";
		$apiPermissao = new apiPermissao();
		$permissao = new Permissao();
		$permissao->usuario = $_SESSION['usuario_sessao'];
		$permissao->modulo = $this->getModule()['modulo'];
		$permissao->controle = $this->getController()['controle'];
		$permissao->acao = $this->getAction()['acao'];
		$this->empresa =  $apiPermissao->permEmpresascontroleacao($permissao);
		$apiFuncionario = new apiFuncionario();
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$this->empresa_selecionada = array();
			foreach ($_POST['empresa'] as $rs) {
				$this->empresa_selecionada[$rs] = true;
			}
			$empresa = implode("','", $_POST['empresa']);
			$this->dados = array("email"=>$apiFuncionario->getFuncionariosemail($empresa));		
		}else{
			$this->empresa_selecionada[$_SESSION['empresa_sessao']] = true;
			$this->dados = array("email"=>$apiFuncionario->getFuncionariosemail($_SESSION['empresa_sessao']));
		}
		$this->view();
	}
}