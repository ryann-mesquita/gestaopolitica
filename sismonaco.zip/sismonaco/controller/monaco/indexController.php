<?php

namespace controller\monaco;

use lib\Controller;
use helper\Security;
use obj\adm\Usuario;
use api\adm\apiUsuario;
use api\monaco\apiDisc;
use obj\monaco\Pessoa;
use obj\monaco\Resultado;
use obj\geral\Log;
use api\geral\apiLog;

class indexController extends Controller {
	
	public function __construct() {
		
		parent::__construct();
		
		new Security($this->getModule(),$this->getController(),$this->getAction());
		
	}
	
	public function index() {
		$this->title = "Sismonaco - M�naco";
		$this->header = "Bem Vindo(a)";
		unset($_SESSION['filtro_sessao']);
		unset($_SESSION['consulta_sessao']);
		/*$usuario = new Usuario();
		$usuario->usuario = $_SESSION['usuario_sessao'];
		$apiUsuario = new apiUsuario();
		$us = $apiUsuario->getUsuario($usuario);
		if ($us->EMPRESA <> NULL) {
			$ano = date('Y');
			$apiPesquisaclima = new apiPesquisaclima();
			$resposta = $apiPesquisaclima->getRespostaformulario($usuario->usuario,$ano);
			if (count($resposta) > 0){
				$this->Alert = "O Grupo M�naco Agradece sua participa��o na pesquisa de clima!"; 
			}else{
				$this->dados = array('formulariopergunta' => $apiPesquisaclima->getFormulariopergunta('1'));
				if ($_SERVER['REQUEST_METHOD'] === 'POST') {
					$sql = array();
					$i = 0;
					if ($us->DEPARTAMENTO != $_POST['departamento']){
						$cadusuario = new Usuario();
						$cadusuario->usuario = $_SESSION['usuario_sessao'];
						$cadusuario->departamento = $_POST['departamento'];
						$sql[$i] = $apiUsuario->editUsuario($cadusuario);
						$i = $i+1;
						$apiDepartamento = new apiDepartamento();
						$ar = $apiDepartamento->filtroDepartamento('1','3','d.departamento', $_POST['departamento']);
						$area = $ar[0]->AREA;
					}else{
						$area = $us->AREA;
					}
					$respostaformulario = new Respostaformulario();
					$respostaformulario->usuario = $_SESSION['usuario_sessao'];
					$respostaformulario->area = $area;
					$respostaformulario->formulario = 1;
					$respostaformulario->ano = $ano;
					$respostaformulario->dta_resposta = date("d/m/Y H:i:s");
					$respostaformulario->empresa = $us->EMPRESA;
					foreach ($this->dados['formulariopergunta'] as $rs){
						$exp = explode(",", $_POST["resposta{$rs->PERGUNTA}"]);
						$respostaformulario->pergunta = $exp[0];
						$respostaformulario->resposta = $exp[1];
						$sql[$i] = $apiPesquisaclima->addRespostaformulario($respostaformulario);
						$i = $i + 1;
					}	
					if (!empty($_POST['sugestao'])) {
						$sugestao  = new Sugestao();
						$sugestao->usuario = $_SESSION['usuario_sessao'];
						$sugestao->sugestao = $_POST['sugestao'];
						$sugestao->dta_sugestao = date("d/m/Y H:i:s");
						$sql[$i] = $apiPesquisaclima->addSugestao($sugestao);
					}
					$rs = $apiPesquisaclima->executeSQL($sql);
					if ($rs[4] == 'sucesso') {
						header('location:' .APP_ROOT. 'monaco/index/index/sucesso');
						$this->Alert = "Obrigado Por Responder a Pesquisa!";		
					}
				}else {
					$apiDepartamento = new apiDepartamento();
					$this->departamento = $apiDepartamento->filtroDepartamento('1','3','d.ativo', '1');
					$this->DP = $us->DEPARTAMENTO;
					$pergunta = $apiPesquisaclima->getPerguntaresposta();
					$this->resposta = array();
					foreach ($pergunta as $rs){
						$this->resposta[$rs->PERGUNTA][$rs->RESPOSTA] = array('RESPOSTA' => $rs->RESPOSTA,'DES_RESPOSTA' => $rs->DES_RESPOSTA);
					}
				}
			}			
		}*/
		$usuario = new Usuario();
		$usuario->usuario = $_SESSION['usuario_sessao'];
		$apiUsuario = new apiUsuario();
		$pessoa = $apiUsuario->getUsuario($usuario);
		$cpf = $pessoa->CPF;
		$apiDisc = new apiDisc();
		$rs = $apiDisc->getPessoa($cpf);
		if ((is_array($rs) ? count($rs) : 0) > 0){
			$this->Alert = "Voc� j� respondeu o DISC!";
		}else{
			$this->D = $apiDisc->getPerfil('1');
			$this->I = $apiDisc->getPerfil('2');
			$this->S = $apiDisc->getPerfil('3');
			$this->C = $apiDisc->getPerfil('4');
			if ($_SERVER['REQUEST_METHOD'] === 'POST') {
				$opcao = $_POST['opcao'];
				$nome = $pessoa->NOME;
				$empresa = $_SESSION['empresa_sessao'];
				$i = 0;
				$sql = array();
				$pessoa = new Pessoa();
				$pessoa->pessoa = $cpf;
				$pessoa->nome = $nome;
				$pessoa->empresa = $empresa;
				$pessoa->dta_cadastro =  date("d/m/Y");
				$sql[$i] = $apiDisc->addPessoa($pessoa);
				$i = $i+1;
				$resultado = new Resultado();
				$resultado->pessoa = $cpf;
				foreach ($opcao as $rs) {
					$resultado->opcao = $rs;
					$sql[$i] = $apiDisc->addResultado($resultado);
					$i = $i+1;
				}
				$log = new Log();
				$log->historico = "PESSOA;NOME;EMPRESa;DTA_CADASTRO|{$pessoa->pessoa};{$pessoa->nome};{$pessoa->empresa};{$pessoa->dta_cadastro}";
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiDisc->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'monaco/index/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'monaco/index/index/sucesso');
					}
				}else{
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		
		$this->view();
	}
	
}