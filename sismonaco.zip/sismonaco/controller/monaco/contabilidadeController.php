<?php

namespace controller\monaco;

use lib\Controller;
use helper\Security;
use api\geral\apiEmpresa;
use api\monaco\apiContabilidade;
use helper\Funcoes;

include 'classes/PHPExcel.php';

class contabilidadeController extends Controller {

	public function __construct() {

		parent::__construct();

		new Security($this->getModule(),$this->getController(),$this->getAction());
	}

	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Contabilidade";
		$this->view();
	}

	public function customiza1() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Customiza��o 1";
		$apiEmpresa = new apiEmpresa();
		$this->dados = array('empresa'=>$apiEmpresa->getMatrizes());

		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$funcoes = new Funcoes();
			$empresa = $_POST['emp'];
			$ano = $_POST['ano'];
			$mes = $_POST['mes'];

			if ($mes == '01'){
				$textmes = "JANEIRO";
			}elseif ($mes == '02'){
				$textmes = "FEVEREIRO";
			}elseif ($mes == '03'){
				$textmes = "MAR�O";
			}elseif ($mes == '04'){
				$textmes = "ABRIL";
			}elseif ($mes == '05'){
				$textmes = "MAIO";
			}elseif ($mes == '06'){
				$textmes = "JUNHO";
			}elseif ($mes == '07'){
				$textmes = "JULHO";
			}elseif ($mes == '08'){
				$textmes = "AGOSTO";
			}elseif ($mes == '09'){
				$textmes = "SETEMBRO";
			}elseif ($mes == '10'){
				$textmes = "OUTUBRO";
			}elseif ($mes == '11'){
				$textmes = "NOVEMBRO";
			}elseif ($mes == '12'){
				$textmes = "DEZEMBRO";
			}

			$ano_anterior = $ano - 1;
			$mes_anterior = $mes - 1;
			$ultimo_dia = date("t", mktime(0,0,0,$mes,'01',$ano));

			$apiContabilidade = new apiContabilidade();
			$emp = $apiContabilidade->getEmpresarevenda($empresa, "1");
			$result = $apiContabilidade->getBalancete($empresa,$ano, str_pad($mes, 2,0,STR_PAD_LEFT), $ano_anterior, str_pad($mes_anterior, 2,0,STR_PAD_LEFT));

			$objPHPExcel = new \PHPExcel();

			//Layout baseado no balancete

			$objPHPExcel->getDefaultStyle()->getFont()->setName('Arial')->setSize(14);
			$objPHPExcel->getActiveSheet()->getStyle('A1:L1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->mergeCells('A1:L1');
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(5);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(5);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(5);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(5);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(5);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(5);
			$objPHPExcel->getActiveSheet()->getStyle('A2:L2')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->mergeCells('A2:L2');
			$objPHPExcel->getActiveSheet()->getStyle('A2')->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
			$objPHPExcel->getActiveSheet()->getStyle('A4:L4')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->mergeCells('A4:L4');
			$objPHPExcel->getActiveSheet()->getStyle('A4')->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
			$objPHPExcel->getActiveSheet()->getStyle('A6')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G6')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('A8')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G8')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F7')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(29);
			$objPHPExcel->getActiveSheet()->getStyle('F7')->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
			$objPHPExcel->getActiveSheet()->getStyle('L7')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('L7')->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
			$objPHPExcel->getActiveSheet()->getStyle('E7')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('E7')->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
			$objPHPExcel->getActiveSheet()->getStyle('K7')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('K7')->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
			$objPHPExcel->getActiveSheet()->getStyle('A21')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G21')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('A24')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G24')->getFont()->setBold(true);
			if($empresa == "13"){

				$objPHPExcel->getActiveSheet()->getStyle('A28')->getFont()->setBold(true);

			}
			$objPHPExcel->getActiveSheet()->getStyle('A31')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('A38')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G38')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G40')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('A51')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G51')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('A52:F52')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->mergeCells('A52:F52');
			$objPHPExcel->getActiveSheet()->getStyle('A52')->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
			$objPHPExcel->getActiveSheet()->getStyle('E54')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E54')->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
			$objPHPExcel->getActiveSheet()->getStyle('F54')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F54')->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
			$objPHPExcel->getActiveSheet()->getStyle('A55')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('A59')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('A63')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('A65')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('A71')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('A75')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('A80')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D89')->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
			$objPHPExcel->getActiveSheet()->getStyle('J89')->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
			$objPHPExcel->getActiveSheet()->getStyle('D90')->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
			$objPHPExcel->getActiveSheet()->getStyle('J90')->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
			$objPHPExcel->getActiveSheet()->getStyle('D91')->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
			$objPHPExcel->getActiveSheet()->getStyle('J91')->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
			$objPHPExcel->getActiveSheet()->getStyle('D92')->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
			$objPHPExcel->getActiveSheet()->getStyle('J92')->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
			$objPHPExcel->getActiveSheet()->getStyle('E21')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F21')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('K21')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('L21')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E31')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F31')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E38')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F38')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('K38')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('L38')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('k40')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('L40')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E51')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F51')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('K51')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('L51')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E59')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F59')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E63')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F63')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E71')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F71')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E75')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F75')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E80')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F80')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('A81:L81')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->mergeCells('A81:L81');
			$objPHPExcel->getActiveSheet()->getStyle('A81')->getAlignment()->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

			$styleArray = array('borders' => array('outline' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
			$objPHPExcel->getActiveSheet()->getStyle('A6:L80')->applyFromArray($styleArray);
			unset($styleArray);

			$styleArray = array('borders' => array('left' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
			$objPHPExcel->getActiveSheet()->getStyle('G6:G80')->applyFromArray($styleArray);
			unset($styleArray);

			$styleArray = array('borders' => array('bottom' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
			$objPHPExcel->getActiveSheet()->getStyle('A51:L51')->applyFromArray($styleArray);
			unset($styleArray);

			$styleArray = array('borders' => array('bottom' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
			$objPHPExcel->getActiveSheet()->getStyle('D88')->applyFromArray($styleArray);
			unset($styleArray);

			$styleArray = array('borders' => array('bottom' => array('style' => \PHPExcel_Style_Border::BORDER_THIN)));
			$objPHPExcel->getActiveSheet()->getStyle('J88')->applyFromArray($styleArray);
			unset($styleArray);

			$gdImage = imagecreatefromjpeg($_SERVER["DOCUMENT_ROOT"] . "/sismonaco/content/geral/img/logomonaco.jpg");
			$objDrawing = new \PHPExcel_Worksheet_MemoryDrawing();
			$objDrawing->setName('Monaco');
			$objDrawing->setDescription('Logo Monaco');
			$objDrawing->setImageResource($gdImage);
			$objDrawing->setRenderingFunction(\PHPExcel_Worksheet_MemoryDrawing::RENDERING_JPEG);
			$objDrawing->setMimeType(\PHPExcel_Worksheet_MemoryDrawing::MIMETYPE_DEFAULT);
			$objDrawing->setWidthAndHeight(208,96);
			$objDrawing->setCoordinates('G53');
			$objDrawing->setWorksheet($objPHPExcel->getActiveSheet());

			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', utf8_encode("{$emp[0]->RAZAO_SOCIAL}") );
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A2', utf8_encode("CNPJ: {$funcoes->mask($emp[0]->CNPJ, '##.###.###/####-##')}     NIRE: {$emp[0]->REGISTRO_JUNTA}   EM {$emp[0]->DTA_FUNDACAO}") );
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A4', utf8_encode("BALANCETE EM {$ultimo_dia} DE {$textmes} DE {$ano}"));
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A6', "ATIVO");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G6', "PASSIVO");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A8', "CIRCULANTE");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G8', "CIRCULANTE");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E7', "".substr($textmes,0,3)."/{$ano}");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K7', "".substr($textmes,0,3)."/{$ano}");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F7', "DEZ/{$ano_anterior}");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('L7', "DEZ/{$ano_anterior}");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A9', "Disponibilidade");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A10', utf8_encode('Aplica��es Financeiras'));
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A11', utf8_encode('Cart�o de Cr�dito'));
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A12', "Clientes");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A13', "Adiantamento a Fornecedores");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A14', "Conta Corrente VW");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A15', "Estoques");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A16', "Contas a Recuperar");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A17', "Demais Contas a Receber");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G9', "Fornecedores Veiculos Novos/Usados");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G10', utf8_encode('Fornecedores Pe�as'));
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G11', "Fornecedores Diversos");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G12', "Adiantamento de Clientes");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G13', "Bancos Saldos Credores");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G14', utf8_encode('Institui��es Financeiras'));
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G15', "Encargos Sociais a Recolher");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G16', "Encargos c/Pessoal a Pagar");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G17', "Imposto a Recolher");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G18', "Demais Contas a Pagar");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A21', "TOTAL DO ATIVO CIRCULANTE");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G21', "TOTAL DO PASSIVO CIRCULANTE");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A24', utf8_encode('N�O CIRCULANTE'));
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G24', utf8_encode('N�O CIRCULANTE'));
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A26', utf8_encode('Empr�stimos a Empresas Ligadas'));
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G26', utf8_encode('Empr�stimos de Empresas Ligadas'));
			if($empresa == "13"){

				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A28', "INVESTIMENTOS");
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A29', utf8_encode('Fund�o de Veiculos - FIAT'));

			}
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A31', "IMOBILIZADO");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A32', "Imobilizado");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A33', "Intangivel");
			if ($empresa == "1" || $empresa == "3") {
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G31', utf8_encode('Empr�stimos e Financiamentos'));
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G32', "Financiamento Leasing");
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G33', "Parcelamento INSS");
			}else{
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G31', utf8_encode('Empr�stimos e Financiamentos'));
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G32', "Parcelamento INSS");
			}
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A34', utf8_encode('Deprecia��o'));
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A35', utf8_encode('Amortiza��o'));
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A38', utf8_encode('TOTAL N�O CIRCULANTE'));
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G38', utf8_encode('TOTAL N�O CIRCULANTE'));
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G40', utf8_encode('PATRIM�NIO L�QUIDO'));
			if ($empresa == "11") {
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G41', "Capital Social");
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G42', "-Capital a Integralizar");
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G43', "Lucros Acumulados");
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G44', utf8_encode('Preju�zos Acumulados'));
			}else {
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G41', "Capital Social");
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G42', "Lucros Acumulados");
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G43', utf8_encode('Preju�zos Acumulados'));
			}
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A51', "TOTALDO ATIVO");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('G51', "TOTAL DO PASSIVO");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A52', utf8_encode('DEMONSTRA��O DO RESULTADO DO PER�ODO'));
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E54', "".substr($textmes,0,3)."/{$ano}");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F54', "ACUMULADO");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A55', "RECEITA BRUTA DAS VENDAS");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A56', utf8_encode('Produtos/Servi�os'));
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A57', utf8_encode('Dedu��es de Vendas'));
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A59', utf8_encode('CUSTO DOS BENS E SRVI�OS'));
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A60', "Custo das vendas");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A61', utf8_encode('Deprecia��o/Amortiza��o'));
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A63', "LUCRO BRUTO");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A65', "DESPESAS(RECEITAS)OPERACIONAIS");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A66', "-Despesas Com Pessoal");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A67', "-Despesas com Vendas e Administrativa");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A68', utf8_encode('-Deprecia��o/Amortiza��o'));
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A69', "+Outras Receitas/Despesas Operacionais");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A71', "RESULT.ANTES DAS REC. E DESP. FINANCEIRAS");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A72', "-Despesas Financeiras");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A73', "+Receitas Financeiras");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A75', utf8_encode('RESULT. ANTES DA TRIBUTA��O'));
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A76', utf8_encode('Contribui��o Social'));
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A77', "Imposto de Renda PJ");
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A80', utf8_encode('LUCRO L�QUIDO DO PER�ODO'));
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('D89', utf8_encode('RUI DENARDIN'));
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('J89', utf8_encode('LUCIRENE AMOEDO DA GAMA'));
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('D90', utf8_encode('CPF N� 373.494.062-15'));
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('J90', utf8_encode('CPF: 607.941.862-20'));
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('D91', utf8_encode('RG: 1984635 SSP/PA'));
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('J91', utf8_encode('CRC PA- 011384/O-4'));
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('D92', utf8_encode('ADMINISTRADOR'));
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('J92', utf8_encode('CONTADORA'));

			//Valores Ativo
			$objPHPExcel->getActiveSheet()->getStyle('E9')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E9', str_replace(",", ".", $result[0]->SALDO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F9')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F9', str_replace(",", ".", $result[0]->SALDO_ANO_ANTERIOR),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E10')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E10', str_replace(",", ".", $result[1]->SALDO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F10')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F10', str_replace(",", ".", $result[1]->SALDO_ANO_ANTERIOR),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E11')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E11', str_replace(",", ".", $result[2]->SALDO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F11')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F11', str_replace(",", ".", $result[2]->SALDO_ANO_ANTERIOR),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E12')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E12', str_replace(",", ".", $result[3]->SALDO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F12')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F12', str_replace(",", ".", $result[3]->SALDO_ANO_ANTERIOR),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E13')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E13', str_replace(",", ".", $result[4]->SALDO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F13')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F13', str_replace(",", ".", $result[4]->SALDO_ANO_ANTERIOR),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E14')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E14', str_replace(",", ".", $result[5]->SALDO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F14')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F14', str_replace(",", ".", $result[5]->SALDO_ANO_ANTERIOR),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E15')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E15', str_replace(",", ".", $result[6]->SALDO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F15')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F15', str_replace(",", ".", $result[6]->SALDO_ANO_ANTERIOR),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E16')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E16', str_replace(",", ".", $result[7]->SALDO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F16')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F16', str_replace(",", ".", $result[7]->SALDO_ANO_ANTERIOR),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E17')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E17', str_replace(",", ".", $result[8]->SALDO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F17')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F17', str_replace(",", ".", $result[8]->SALDO_ANO_ANTERIOR),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E21')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E21', '=SUM(E9:E17)',\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F21')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F21', '=SUM(F9:F17)',\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E26')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E26', str_replace(",", ".", $result[9]->SALDO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F26')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F26', str_replace(",", ".", $result[9]->SALDO_ANO_ANTERIOR),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			if ($empresa == "13") {

				$objPHPExcel->getActiveSheet()->getStyle('E29')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E29', str_replace(",", ".", $result[10]->SALDO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->getStyle('F29')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F29', str_replace(",", ".", $result[10]->SALDO_ANO_ANTERIOR),\PHPExcel_Cell_DataType::TYPE_NUMERIC);

			}
			$objPHPExcel->getActiveSheet()->getStyle('E31')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E31', '=SUM(E32:E35)',\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F31')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F31', '=SUM(F32:F35)',\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E32')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E32', str_replace(",", ".", $result[11]->SALDO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F32')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F32', str_replace(",", ".", $result[11]->SALDO_ANO_ANTERIOR),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E33')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E33', str_replace(",", ".", $result[12]->SALDO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F33')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F33', str_replace(",", ".", $result[12]->SALDO_ANO_ANTERIOR),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E34')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E34', str_replace(",", ".", $result[13]->SALDO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F34')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F34', str_replace(",", ".", $result[13]->SALDO_ANO_ANTERIOR),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E35')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E35', str_replace(",", ".", $result[14]->SALDO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F35')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F35', str_replace(",", ".", $result[14]->SALDO_ANO_ANTERIOR),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E38')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E38', '=SUM(E26+E29+E31)',\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F38')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F38', '=SUM(F26+F29+F31)',\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E51')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E51', '=SUM(E21+E38)',\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F51')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F51', '=SUM(F21+F38)',\PHPExcel_Cell_DataType::TYPE_NUMERIC);

			//Valores Passivos
			$objPHPExcel->getActiveSheet()->getStyle('K9')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K9', abs(str_replace(",", ".", $result[15]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('L9')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('L9', abs(str_replace(",", ".", $result[15]->SALDO_ANO_ANTERIOR)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('K10')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K10', abs(str_replace(",", ".", $result[16]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('L10')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('L10', abs(str_replace(",", ".", $result[16]->SALDO_ANO_ANTERIOR)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('K11')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K11', abs(str_replace(",", ".", $result[17]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('L11')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('L11', abs(str_replace(",", ".", $result[17]->SALDO_ANO_ANTERIOR)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('K12')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K12', abs(str_replace(",", ".", $result[18]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('L12')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('L12', abs(str_replace(",", ".", $result[18]->SALDO_ANO_ANTERIOR)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('K13')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K13', abs(str_replace(",", ".", $result[19]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('L13')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('L13', abs(str_replace(",", ".", $result[19]->SALDO_ANO_ANTERIOR)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('K14')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K14', abs(str_replace(",", ".", $result[20]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('L14')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('L14', abs(str_replace(",", ".", $result[20]->SALDO_ANO_ANTERIOR)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('K15')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K15', abs(str_replace(",", ".", $result[21]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('L15')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('L15', abs(str_replace(",", ".", $result[21]->SALDO_ANO_ANTERIOR)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('K16')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K16', abs(str_replace(",", ".", $result[22]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('L16')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('L16', abs(str_replace(",", ".", $result[22]->SALDO_ANO_ANTERIOR)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('K17')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K17', abs(str_replace(",", ".", $result[23]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('L17')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('L17', abs(str_replace(",", ".", $result[23]->SALDO_ANO_ANTERIOR)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('K18')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K18', abs(str_replace(",", ".", $result[24]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('L18')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('L18', abs(str_replace(",", ".", $result[24]->SALDO_ANO_ANTERIOR)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('K21')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K21', '=SUM(K9:K18)',\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('L21')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('L21', '=SUM(L9:L18)',\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('K26')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K26', abs(str_replace(",", ".", $result[25]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('L26')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('L26', abs(str_replace(",", ".", $result[25]->SALDO_ANO_ANTERIOR)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			if ($empresa == "1" || $empresa == "3"){
				$objPHPExcel->getActiveSheet()->getStyle('K31')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K31', abs(str_replace(",", ".", $result[26]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->getStyle('L31')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('L31', abs(str_replace(",", ".", $result[26]->SALDO_ANO_ANTERIOR)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->getStyle('K32')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K32', abs(str_replace(",", ".", $result[27]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->getStyle('L32')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('L32', abs(str_replace(",", ".", $result[27]->SALDO_ANO_ANTERIOR)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->getStyle('K33')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K33', abs(str_replace(",", ".", $result[28]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->getStyle('L33')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('L33', abs(str_replace(",", ".", $result[28]->SALDO_ANO_ANTERIOR)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			}else{
				$objPHPExcel->getActiveSheet()->getStyle('K31')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K31', abs(str_replace(",", ".", $result[26]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->getStyle('L31')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('L31', abs(str_replace(",", ".", $result[26]->SALDO_ANO_ANTERIOR)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->getStyle('K32')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K32', abs(str_replace(",", ".", $result[28]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->getStyle('L32')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('L32', abs(str_replace(",", ".", $result[28]->SALDO_ANO_ANTERIOR)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			}
			$objPHPExcel->getActiveSheet()->getStyle('K38')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K38', '=SUM(K26+K31+K32+K33)',\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('L38')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('L38', '=SUM(L26+L31+L32+L33)',\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('K41')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K41', abs(str_replace(",", ".", $result[29]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('L41')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('L41', abs(str_replace(",", ".", $result[29]->SALDO_ANO_ANTERIOR)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			if ($empresa == "11") {
				$objPHPExcel->getActiveSheet()->getStyle('L42')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('L42', -abs(str_replace(",", ".", $result[30]->SALDO_ANO_ANTERIOR)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->getStyle('L43')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('L43', abs(str_replace(",", ".", $result[31]->SALDO_ANO_ANTERIOR)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->getStyle('L44')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('L44', -abs(str_replace(",", ".", $result[32]->SALDO_ANO_ANTERIOR)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			}else {
					
				$objPHPExcel->getActiveSheet()->getStyle('L42')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('L42', abs(str_replace(",", ".", $result[31]->SALDO_ANO_ANTERIOR)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->getStyle('L43')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
				$objPHPExcel->setActiveSheetIndex(0)->setCellValue('L43', -abs(str_replace(",", ".", $result[32]->SALDO_ANO_ANTERIOR)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			}
			$objPHPExcel->getActiveSheet()->getStyle('L40')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('L40', '=SUM(L41:L44)',\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('L51')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('L51', '=SUM(L21+L38+L40)',\PHPExcel_Cell_DataType::TYPE_NUMERIC);

			//Valores Demontra��o
			$objPHPExcel->getActiveSheet()->getStyle('E56')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E56', abs(str_replace(",", ".", $result[33]->MOVIMENTO_MES)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F56')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F56', abs(str_replace(",", ".", $result[33]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E57')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E57', abs(str_replace(",", ".", $result[34]->MOVIMENTO_MES)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F57')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F57', abs(str_replace(",", ".", $result[34]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E60')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E60', abs(str_replace(",", ".", $result[35]->MOVIMENTO_MES)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F60')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F60', abs(str_replace(",", ".", $result[35]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E61')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E61', abs(str_replace(",", ".", $result[36]->MOVIMENTO_MES)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F61')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F61', abs(str_replace(",", ".", $result[36]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E59')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E59', '=SUM(E60:E61)',\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F59')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F59', '=SUM(F60:F61)',\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E63')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E63', '=SUM(E56-E57-E59)',\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F63')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F63', '=SUM(F56-F57-F59)',\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E66')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E66', abs(str_replace(",", ".", $result[37]->MOVIMENTO_MES)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F66')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F66', abs(str_replace(",", ".", $result[37]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E67')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E67', abs(str_replace(",", ".", $result[38]->MOVIMENTO_MES)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F67')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F67', abs(str_replace(",", ".", $result[38]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E68')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E68', abs(str_replace(",", ".", $result[39]->MOVIMENTO_MES)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F68')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F68', abs(str_replace(",", ".", $result[39]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E69')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E69', abs(str_replace(",", ".", $result[40]->MOVIMENTO_MES)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F69')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F69', abs(str_replace(",", ".", $result[40]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E71')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E71', '=SUM(E63-E66-E67-E68+E69)',\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F71')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F71', '=SUM(F63-F66-F67-F68+F69)',\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E72')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E72', abs(str_replace(",", ".", $result[41]->MOVIMENTO_MES)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F72')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F72', abs(str_replace(",", ".", $result[41]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E73')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E73', abs(str_replace(",", ".", $result[42]->MOVIMENTO_MES)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F73')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F73', abs(str_replace(",", ".", $result[42]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E75')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E75', '=SUM(E71-E72+E73)',\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F75')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F75', '=SUM(F71-F72+F73)',\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E76')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E76', abs(str_replace(",", ".", $result[43]->MOVIMENTO_MES)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F76')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F76', abs(str_replace(",", ".", $result[43]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E77')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E77', abs(str_replace(",", ".", $result[44]->MOVIMENTO_MES)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F77')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F77', abs(str_replace(",", ".", $result[44]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('E80')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('E80', '=SUM(E75-E76-E77)',\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('F80')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('F80', '=SUM(F75-F76-F77)',\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$acumulado = (str_replace("-","",$result[33]->SALDO) - str_replace("-","",$result[34]->SALDO)) - (str_replace("-","",$result[35]->SALDO) + str_replace("-","",$result[36]->SALDO)) - str_replace("-","",$result[37]->SALDO) - str_replace("-","",$result[38]->SALDO) - str_replace("-","",$result[39]->SALDO) + str_replace("-","",$result[40]->SALDO) - str_replace("-","",$result[41]->SALDO) + str_replace("-","",$result[42]->SALDO) - str_replace("-","",$result[43]->SALDO) - str_replace("-","",$result[44]->SALDO);
			if($acumulado > 0){

				if ($empresa == "11") {
					$objPHPExcel->getActiveSheet()->getStyle('K42')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
					$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K42', -abs(str_replace(",", ".", $result[30]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->getActiveSheet()->getStyle('K43')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
					$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K43', "=SUM(".abs(str_replace(",", ".", $result[31]->SALDO)).",F80)",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->getActiveSheet()->getStyle('K44')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
					$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K44', -abs(str_replace(",", ".", $result[32]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				}else{
					$objPHPExcel->getActiveSheet()->getStyle('K42')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
					$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K42', "=SUM(".abs(str_replace(",", ".", $result[31]->SALDO)).",F80)",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->getActiveSheet()->getStyle('K43')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
					$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K43', -abs(str_replace(",", ".", $result[32]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				}

			}else{

				if ($empresa == "11") {
					$objPHPExcel->getActiveSheet()->getStyle('K42')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
					$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K42', -abs(str_replace(",", ".", $result[30]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->getActiveSheet()->getStyle('K43')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
					$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K43', abs(str_replace(",", ".", $result[31]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->getActiveSheet()->getStyle('K44')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
					$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K44', "=SUM(".-abs(str_replace(",", ".", $result[32]->SALDO)).",F80)",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				}else{
					$objPHPExcel->getActiveSheet()->getStyle('K42')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
					$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K42', abs(str_replace(",", ".", $result[31]->SALDO)),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->getActiveSheet()->getStyle('K43')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
					$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K43', "=SUM(".-abs(str_replace(",", ".", $result[32]->SALDO)).",F80)",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				}
			}
			$objPHPExcel->getActiveSheet()->getStyle('K40')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K40', '=SUM(K41:K44)',\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->getStyle('K51')->getNumberFormat()->setFormatCode('#,##0.00;"("#,##0.00")"');
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('K51', '=SUM(K21+K38+K40)',\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A81', utf8_encode("{$emp[0]->CIDADE}({$emp[0]->UF}), {$ultimo_dia} DE {$textmes} DE {$ano}"));




			$objPHPExcel->getActiveSheet()->setTitle("".utf8_encode(substr($emp[0]->RAZAO_SOCIAL,0,3))."");

			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
			$nome_arquivo = "BALANCETE-".str_replace(" ","-",$emp[0]->RAZAO_SOCIAL)."-{$ultimo_dia}-{$mes}-{$ano}.xls";
			header('Content-Type: application/vnd.ms-excel');
			header("Content-Disposition: attachment;filename={$nome_arquivo}");
			header("Pragma: no-cache");
			header("Expires: 0");

			ob_end_clean();
			$objWriter->save('php://output');
		}

		$this->view();
	}
}