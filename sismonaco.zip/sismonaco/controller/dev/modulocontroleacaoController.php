<?php

namespace controller\dev;

use lib\Controller;
use helper\Security;
use api\dev\apiModulo;
use helper\Paginator;
use obj\dev\Modulo;
use api\dev\apiControle;
use api\dev\apiAcao;
use obj\geral\Log;
use api\geral\apiLog;
use api\dev\apiModulocontroleacao;
use obj\dev\Modulocontroleacao;

class modulocontroleacaoController extends Controller {
	
	public function __construct() {
		
		parent::__construct();
		
		new Security($this->getModule(),$this->getController(),$this->getAction());
	}
	
	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Lista de Modulos";
		$apiModulo = new apiModulo();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
	    $a = '1';
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$busca = array(
				'1' => array('c' => '2','a' => $a,'coluna' => 'des_reduzida', 'valor' => $_POST['busca_texto']),
				'2' => array('c' => '2','a' => $a,'coluna' => 'des_modulo', 'valor' => $_POST['busca_texto']),
				'3' => array('c' => '1','a' => '3','coluna' => "ativo",'valor' => "1")
			);
			if(isset($busca[$_POST['busca']])){
				$this->dados = array('modulo' => $apiModulo->filtroModulo($busca[$_POST['busca']]['c'], $busca[$_POST['busca']]['a'], $busca[$_POST['busca']]['coluna'], $busca[$_POST['busca']]['valor']));
				$_SESSION['filtro_sessao'] = array('c' => $busca[$_POST['busca']]['c'], 'a' => $busca[$_POST['busca']]['a'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'valor' => $busca[$_POST['busca']]['valor']);
				$_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'dev/index/index/acessonegado');
				die();
			}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				$this->dados = array('modulo' => $apiModulo->filtroModulo($_SESSION['filtro_sessao']['c'],$_SESSION['filtro_sessao']['a'],$_SESSION['filtro_sessao']['coluna'], $_SESSION['filtro_sessao']['valor']));
				$_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('modulo' => $apiModulo->filtroModulo('1','3','ativo', '1'));
					$_SESSION['filtro_sessao'] = array('c' => '1', 'a' => '3', 'coluna' => 'ativo' , 'valor' => '1');
					$_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}
		}
		$TotalItem = (is_array($this->dados['modulo']) ? count($this->dados['modulo']) : 0);
		$this->dados['modulo'] = array_chunk($this->dados['modulo'], $ItemPorPagina);
		@$this->dados['modulo'] = $this->dados['modulo'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->view();
	}
	
	public function adicionar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$modulo = new Modulo();
		$modulo->modulo = $this->getParams(0);
		$this->modulo = $modulo->modulo;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		$apiModulo = new apiModulo();
		$apiControle = new apiControle();
		$apiAcao = new apiAcao();
		$this->controle = $apiControle->filtroControle('1','3','ativo', '1');
		$this->acao = $apiAcao->filtroAcao('1','3','ativo', '1');
		$this->dados = array('modulo' => $apiModulo->getModulo($modulo));
		$this->header = $this->dados['modulo']->DES_REDUZIDA." - ".$this->dados['modulo']->DES_MODULO;
		if (isset($this->dados['modulo'])){
			if ($this->dados['modulo']->ATIVO == '0'){			
				header('location:' .APP_ROOT. 'dev/index/index/acessonegado');
				die();			
			}
		}else{
			header('location:' .APP_ROOT. 'dev/index/index/acessonegado');
			die();
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$array = array();
			$controle = $_POST['controle'];
			$acao = $_POST['acao'];
			$apiModulocontroleacao = new apiModulocontroleacao();
			$modulocontroleacao = new Modulocontroleacao();
			$condicao = "";
			$a = 0;
			foreach ($controle as $rs => $va) {
				$condicao .= "(mca.modulo = '$modulo->modulo' AND mca.controle = '{$va}' AND mca.acao = '{$acao[$rs]}') OR ";
				$this->rollback[$a] = array('controle' => $va, 'acao' => $acao[$rs]);
				$a = $a + 1;
			}
			$rs = $apiModulocontroleacao->filtroModulocontroleacao(substr($condicao,0,-3));
			if ((is_array($rs) ? count($rs) : 0) > 0){
				$this->Alert = "<br>";
				foreach ($rs as $rs) {
					$this->Alert .= "J� existe o controle: {$rs->CT} e a��o: {$rs->AC} cadastrada nesse Modulo: {$rs->MD}! <br>";
				}
			}else{
				$modulocontroleacao->modulo = $modulo->modulo;
				$log = new Log();
				$apiLog = new apiLog();
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				foreach ($this->rollback as $rs) {
					$modulocontroleacao->controle = $rs['controle'];
					$modulocontroleacao->acao = $rs['acao'];
					$sql[$i] = $apiModulocontroleacao->addModulocontroleacao($modulocontroleacao);
					$i = $i+1;
					$log->historico = "MODULO;CONTROLE;ACAO|{$modulocontroleacao->modulo};{$modulocontroleacao->controle};{$modulocontroleacao->acao}";
					$sql[$i] = $apiLog->addLog($log);
					$i = $i+1;
				}
				$rs = $apiModulocontroleacao->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'dev/modulocontroleacao/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'dev/modulocontroleacao/index/sucesso');
					}
				}else{
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		
		$this->view();
	}
	
	public function excluir() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$modulo = new Modulo();
		$modulo->modulo = $this->getParams(0);
		$this->modulo = $modulo->modulo;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		$apiModulo = new apiModulo();
		$rs= $apiModulo->getModulo($modulo);
		$this->header = $rs->DES_REDUZIDA." - ".$rs->DES_MODULO;
		if (isset($rs)){
			if ($rs->ATIVO == '0'){
				header('location:' .APP_ROOT. 'dev/index/index/acessonegado');
				die();
			}
		}else{
			header('location:' .APP_ROOT. 'dev/index/index/acessonegado');
			die();
		}
		$apiModulocontroleacao = new apiModulocontroleacao();
		$this->dados = array('modulocontroleacao' => $apiModulocontroleacao->filtroModulocontroleacao("mca.modulo = '{$modulo->modulo}'"));
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$modulocontroleacao = new Modulocontroleacao();
			$modulocontroleacao->modulo = $modulo->modulo;
			$log = new Log();
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "E";
			$log->dta_registro = date("d/m/Y H:i:s");
			foreach ($_POST['exclusao'] as $rs) {
				$exp = explode(",", $rs);
				$modulocontroleacao->controle = $exp[0];
				$modulocontroleacao->acao = $exp[1];
				$sql[$i] = $apiModulocontroleacao->delModulocontroleacao($modulocontroleacao);
				$i = $i+1;
				$log->historico = "MODULO;CONTROLE;ACAO|{$modulocontroleacao->modulo};{$modulocontroleacao->controle};{$modulocontroleacao->acao}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$i = $i+1;
			}
			$rs = $apiModulocontroleacao->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'dev/modulocontroleacao/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'dev/modulocontroleacao/index/sucesso');
				}
			}else{
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}
		$this->view();
	}
}