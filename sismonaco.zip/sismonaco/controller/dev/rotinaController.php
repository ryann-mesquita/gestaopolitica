<?php

namespace controller\dev;

use lib\Controller;
use helper\Security;
use api\dev\apiRotina;
use helper\Paginator;
use obj\dev\Rotina;
use obj\geral\Log;
use api\geral\apiLog;

class rotinaController extends Controller {
	
	public function __construct() {
		
		parent::__construct();
		
		new Security($this->getModule(),$this->getController(),$this->getAction());
	}
	
	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Lista de Rotinas";
		$apiRotina = new apiRotina();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		(!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])) ? $a = '1' : $a = '3';
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$busca = array(
				'1' => array('c' => '1','a' => $a,'coluna' => 'ativo', 'valor' => '1'),
				'2' => array('c' => '1','a' => $a,'coluna' => 'ativo', 'valor' => '0'),
				'3' => array('c' => '2','a' => $a,'coluna' => 'des_reduzida', 'valor' => $_POST['busca_texto']),
				'4' => array('c' => '2','a' => $a,'coluna' => 'des_rotina', 'valor' => $_POST['busca_texto']),
				'5' => array('c' => '3','a' => $a,'coluna' => "",'valor' => "")
			);
			if(isset($busca[$_POST['busca']])){
				$this->dados = array('rotina' => $apiRotina->filtroRotina($busca[$_POST['busca']]['c'], $busca[$_POST['busca']]['a'], 'tudo',$busca[$_POST['busca']]['coluna'], $busca[$_POST['busca']]['valor']));
				$_SESSION['filtro_sessao'] = array('c' => $busca[$_POST['busca']]['c'], 'a' => $busca[$_POST['busca']]['a'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'valor' => $busca[$_POST['busca']]['valor']);
				$_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'dev/index/index/acessonegado');
				die();
			}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				$this->dados = array('rotina' => $apiRotina->filtroRotina($_SESSION['filtro_sessao']['c'],$_SESSION['filtro_sessao']['a'],'tudo',$_SESSION['filtro_sessao']['coluna'],$_SESSION['filtro_sessao']['valor']));
				$_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('rotina' => $apiRotina->filtroRotina('1','3','tudo','ativo', '1'));
					$_SESSION['filtro_sessao'] = array('c' => '1', 'a' => '3', 'tudo', 'coluna' => 'ativo' , 'valor' => '1');
					$_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}
		}
		$TotalItem = (is_array($this->dados['rotina']) ? count($this->dados['rotina']) : 0);
		$this->dados['rotina'] = array_chunk($this->dados['rotina'], $ItemPorPagina);
		@$this->dados['rotina'] = $this->dados['rotina'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->view();
	}
	
	public function adicionar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Cadastro de Rotinas";
		$apiRotina = new apiRotina();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$Post = new Rotina('POST');
			$apiRotina = new apiRotina();
			$rs = $apiRotina->filtroRotina('1','3','tudo','des_reduzida',$Post->des_reduzida);
			if ((is_array($rs) ? count($rs) : 0) > 0){
				$this->rollback = new Rotina('POST');
				$this->Alert = "J� existe uma rotina com esse nome cadastrado!";
			}else{
				$sql[$i] = $apiRotina->addRotina($Post);
				$i = $i+1;
				$log = new Log();
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico = "DES_REDUZIDA;DES_ROTINA;ATIVO|{$Post->des_reduzida};{$Post->des_rotina};{$Post->ativo}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiRotina->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'dev/rotina/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'dev/rotina/index/sucesso');
					}
				}else{
					$this->rollback = new Rotina('POST');
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		
		$this->view();
	}
	
	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Altera��o de Rotina";
		$rotina = new Rotina();
		$rotina->rotina = $this->getParams(0);
		$apiRotina = new apiRotina();
		$this->dados = array('rotina' => $apiRotina->getRotina($rotina));
		if (isset($this->dados['rotina'])){
			if ($this->dados['rotina']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'dev/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'dev/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$Post = new Rotina('POST');
			$Post->rotina = $this->getParams(0);
			$rs = $apiRotina->filtroRotina('1','3','tudo','des_reduzida',$Post->des_reduzida);
			$log = new Log();
			$log->historico = "DES_REDUZIDA;DES_ROTINA;ATIVO|{$this->dados['rotina']->DES_REDUZIDA};{$this->dados['rotina']->DES_ROTINA};{$this->dados['rotina']->ATIVO}";
			if ((is_array($rs) ? count($rs) : 0) > 0 && ($rs[0]->DES_REDUZIDA != $this->dados['rotina']->DES_REDUZIDA)){
				$this->dados['rotina']->DES_REDUZIDA = $Post->des_reduzida;
				$this->dados['rotina']->DES_ROTINA = $Post->des_rotina;
				$this->dados['rotina']->ATIVO = $Post->ativo;
				$this->Alert = "J� existe uma rotina com esse nome cadastrado!";
			}else{
				$sql[$i] = $apiRotina->editRotina($Post);
				$i = $i+1;
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "A";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico .= ":DES_REDUZIDA;DES_ROTINA;ATIVO|{$Post->des_reduzida};{$Post->des_rotina};{$Post->ativo}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiRotina->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'dev/rotina/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'dev/rotina/index/sucesso');
					}
				}else{
					$this->dados['rotina']->DES_REDUZIDA = $Post->des_reduzida;
					$this->dados['rotina']->DES_ROTINA = $Post->des_rotina;
					$this->dados['rotina']->ATIVO = $Post->ativo;
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		$this->view();
	}
	public function excluir() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Exclus�o de Rotina";
		$rotina = new Rotina();
		$rotina->rotina = $this->getParams(0);
		$apiRotina = new apiRotina();
		$this->dados = array('rotina' => $apiRotina->getRotina($rotina));
		if (isset($this->dados['rotina'])){
			if ($this->dados['rotina']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'dev/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'dev/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$sql[$i] = $apiRotina->delRotina($rotina);
			$i = $i+1;
			$log = new Log();
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "E";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico = "ROTINA;DES_REDUZIDA;DES_ROTINA;ATIVO|{$this->dados['rotina']->ROTINA};{$this->dados['rotina']->DES_REDUZIDA};{$this->dados['rotina']->DES_ROTINA};{$this->dados['rotina']->ATIVO}";
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiRotina->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'dev/rotina/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'dev/rotina/index/sucesso');
				}
			}else{
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}
		$this->view();
	}
}