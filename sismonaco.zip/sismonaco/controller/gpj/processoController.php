<?php

namespace controller\gpj;

use lib\Controller;
use helper\Security;
use api\gpj\apiProcesso;
use api\gpj\apiNatureza;
use api\gpj\apiConsultor;
use helper\Paginator;
use obj\gpj\Processo;
use obj\geral\Log;
use api\geral\apiLog;
use api\gpj\apiVara;
use api\geral\apiEmpresa;
use obj\geral\Empresa;
use api\gpj\apiCidade;
use api\gpj\apiStatus;
use api\adm\apiDepartamento;
use obj\gpj\Reclamante;
use api\gpj\apiReclamante;
use helper\Funcoes;
use api\gpj\apiItem;
use obj\gpj\Itemprocesso;
use api\gpj\apiMovimento;
use api\gpj\apiTipo;
use api\gpj\apiParcela;
use obj\gpj\Movimento;
use obj\gpj\Parcela;
use api\gpj\apiRisco;

class processoController extends Controller {
	
	public function __construct() {
		
		parent::__construct();
		
		new Security($this->getModule(),$this->getController(),$this->getAction());
	}
	
	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Lista de Processos";
		$apiProcesso = new apiProcesso();
		$this->funcoes = new Funcoes();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-4"])){
			$apiNatureza = new apiNatureza();
			$nat = $apiNatureza->filtroNatureza('1', '3', 'ativo', '1');
			foreach ($nat as $rs){
				$this->natureza[$rs->NATUREZA] = array('natureza' => $rs->NATUREZA, 'des_natureza' => $rs->DES_NATUREZA);
			}
			$apiConsultor = new apiConsultor();
			$this->consultor = $apiConsultor->filtroConsultor('1', 'tudo', 'c.consultor', $_SESSION['usuario_sessao']);
		}else{
			$apiConsultor = new apiConsultor();
			$this->consultor = $apiConsultor->filtroConsultor('1', 'tudo', 'c.consultor', $_SESSION['usuario_sessao']);
			foreach ($this->consultor as $rs){
				$this->natureza[$rs->NATUREZA] = array('natureza' => $rs->NATUREZA, 'des_natureza' => $rs->DES_NATUREZA);
			}
		}
		(!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])) ? $a = '1' : $a = '3';
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$busca = array(
				'1' => array('c' => '1','a' => $a,'coluna' => 'ativo', 'valor' => '1', 'natureza' => $_POST['natureza']),
				'2' => array('c' => '1','a' => $a,'coluna' => 'ativo', 'valor' => '0', 'natureza' => $_POST['natureza']),
				'3' => array('c' => '2','a' => $a,'coluna' => 'n_processo', 'valor' => $this->funcoes->naoNumerico(@$_POST['busca_valor']), 'natureza' => $_POST['natureza']),
				'4' => array('c' => '2','a' => $a,'coluna' => 'des_processo', 'valor' => @$_POST['busca_valor'], 'natureza' => $_POST['natureza']),
				'5' => array('c' => '2','a' => $a,'coluna' => 'nome_reclamante', 'valor' => @$_POST['busca_valor'], 'natureza' => $_POST['natureza']),
				'6' => array('c' => '3','a' => $a,'coluna' => "",'valor' => "", 'natureza' => $_POST['natureza'])
			);
			if(isset($busca[$_POST['busca']])){
				$this->dados = array('processo' => $apiProcesso->filtroProcesso($_SESSION['empresa_sessao'],$busca[$_POST['busca']]['natureza'],$busca[$_POST['busca']]['c'], $busca[$_POST['busca']]['a'], $busca[$_POST['busca']]['coluna'], $busca[$_POST['busca']]['valor']));
				$_SESSION['filtro_sessao'] = array('natureza' => $busca[$_POST['busca']]['natureza'], 'c' => $busca[$_POST['busca']]['c'], 'a' => $busca[$_POST['busca']]['a'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'busca_valor' => $busca[$_POST['busca']]['valor'], 'busca' => $_POST['busca']);
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'gpj/index/index/acessonegado');
				die();
			}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				$this->dados = array('processo' => $apiProcesso->filtroProcesso($_SESSION['empresa_sessao'], $_SESSION['filtro_sessao']['natureza'],$_SESSION['filtro_sessao']['c'],$_SESSION['filtro_sessao']['a'],$_SESSION['filtro_sessao']['coluna'], $_SESSION['filtro_sessao']['busca_valor']));
				$_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('processo' => $apiProcesso->filtroProcesso($_SESSION['empresa_sessao'], @$this->natureza[$this->consultor[0]->NATUREZA]['natureza'],'1','3','ativo', '1'));
					$_SESSION['filtro_sessao'] = array('natureza' => @$this->natureza[$this->consultor[0]->NATUREZA]['natureza'], 'c' => '1', 'a' => '3', 'coluna' => 'ativo' , 'busca_valor' => '1' , 'busca' => '6');
					$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}
		}
		$TotalItem = (is_array($this->dados['processo']) ? count($this->dados['processo']) : 0);
		$this->dados['processo'] = array_chunk($this->dados['processo'], $ItemPorPagina);
		@$this->dados['processo'] = $this->dados['processo'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->view();
	}
	
	public function adicionar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Cadastro de Processo";
		$apiProcesso = new apiProcesso();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-4"])){
			$apiNatureza = new apiNatureza();
			$nat = $apiNatureza->filtroNatureza('1', '3', 'ativo', '1');
			foreach ($nat as $rs){
				$this->natureza[$rs->NATUREZA] = array('natureza' => $rs->NATUREZA, 'des_natureza' => $rs->DES_NATUREZA);
			}
		}else{
			$apiConsultor = new apiConsultor();
			$this->consultor = $apiConsultor->filtroConsultor('1', 'tudo', 'c.consultor', $_SESSION['usuario_sessao']);
			if ((is_array($this->consultor) ? count($this->consultor) : 0) == 0){
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'gpj/index/index/acessonegado');
				die();
			}else{
				foreach ($this->consultor as $rs){
					$this->natureza[$rs->NATUREZA] = array('natureza' => $rs->NATUREZA, 'des_natureza' => $rs->DES_NATUREZA);
				}
			}
		}
		$apiVara = new apiVara();
		$vara = $apiVara->filtroVara('1','3','ativo','1','tudo');
		foreach ($vara as $rs){
			$this->vara[$rs->NATUREZA][$rs->N_LINHA] = array('vara' => $rs->VARA, 'des_vara' => $rs->DES_VARA);
		}
		$apiEmpresa  = new apiEmpresa();
		$empresa = new Empresa();
		$empresa->empresa = $_SESSION['empresa_sessao'];
		$local = $apiEmpresa->getEmpresa($empresa);
		$apiCidade = new apiCidade();
		$this->cidade = $apiCidade->filtroCidade('1','1','uf', $local->UF);
		$apiStatus = new apiStatus();
		$this->status = $apiStatus->filtroStatus('1','3','ativo', '1');
		$apiDepartamento = new apiDepartamento();
		$this->departamento = $apiDepartamento->filtroDepartamento('1','3','d.ativo', '1');
		$apiItem = new apiItem();
		$item = $apiItem->filtroItem('1', '3','ativo','1','tudo');
		foreach ($item as $rs){
			$this->item[$rs->NATUREZA][$rs->N_LINHA] = array('item' => $rs->ITEM, 'des_item' => $rs->DES_ITEM);
		}
		$apiRisco = new apiRisco();
		$this->risco = $apiRisco->filtroRisco('1','3','ativo','1');
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$funcoes = new Funcoes();
			$Post = new Processo();
			$Post->n_processo = $funcoes->naoNumerico($_POST['n_processo']);
			$Post->des_processo =  strtoupper($funcoes->retiraAcentos(trim($_POST['des_processo'])));
			$Post->natureza = $_POST['natureza'];
			$Post->vara = $_POST['vara'];
			$Post->cidade = $_POST['cidade'];
			$Post->polo = $_POST['polo'];
			$Post->terceiro = $_POST['terceiro'];
			if ($Post->natureza == 5){
				$Post->terceiro = "S";
				if (isset($_POST['autterceiro'])){
					$expo = explode("-", $_POST['reclamante']);
					$Post->reclamante = $expo[0];
					$nome = strtoupper($funcoes->retiraAcentos($expo[1]));
				}else{
					$Post->reclamante = $funcoes->naoNumerico($_POST['cons_reclamante']);
					$nome = strtoupper($funcoes->retiraAcentos(trim($_POST['reclamante'])));
				}
				$Post->nome_reclamante = $nome;
			}else{
				if ($Post->terceiro == "S"){
					if (isset($_POST['autterceiro'])){
						$expo = explode("-", $_POST['reclamante']);
						$Post->reclamante = $expo[0];
					}else{
						$Post->reclamante = $funcoes->naoNumerico($_POST['cons_reclamante']);
						$nome = strtoupper($funcoes->retiraAcentos(trim($_POST['reclamante'])));
					}
				}else{
					$expo = explode("-", $_POST['reclamante']);
					$Post->reclamante = $expo[0];
				}
				$Post->nome_reclamante = strtoupper($funcoes->retiraAcentos(trim($_POST['nome_reclamante'])));
			}
			$Post->val_causa = $funcoes->sanearValor($_POST['val_causa']);
			$Post->val_sentenca = $funcoes->sanearValor($_POST['val_sentenca']);
			$Post->val_quitacao = $funcoes->sanearValor($_POST['val_quitacao']);
			$Post->dta_inicio = $_POST['dta_inicio'];
			$Post->dta_proxima_acao = "{$_POST['dta_acao']} {$_POST['hora_acao']}";
			$Post->empresa = $_SESSION['empresa_sessao'];
			$Post->risco = $_POST['risco'];
			$Post->status = $_POST['status'];
			$Post->dta_cadastro = date("d/m/Y H:i:s");
			$Post->ativo = 1;
			$apiProcesso = new apiProcesso();
			$rs = $apiProcesso->filtroProcesso($_SESSION['empresa_sessao'],'1','3','n_processo',$Post->n_processo);
			if ((is_array($rs) ? count($rs) : 0) > 0){
				$this->rollback = $Post;
				$this->Alert = "J� existe um processo com esse n� cadastrado!";
			}else{
				$Post->n_processo = "<str>".$Post->n_processo;
				$Post->reclamante = "<str>".$Post->reclamante;
				if ($Post->terceiro == "S"){
					$reclamante = new Reclamante();
					$reclamante->reclamante = $Post->reclamante;
					$apiReclamante = new apiReclamante();
					$v = $apiReclamante->getReclamante($reclamante);
					if (!(is_array($v) ? count($v) : 0) == 1) {
						$reclamante->nome = $nome;
						$reclamante->departamento = $_POST['departamento'];
						$sql[$i] = $apiReclamante->addReclamante($reclamante);
						$i = $i+1;
					}	
				}
				$sql[$i] = $apiProcesso->addProcesso($Post);
				$Post->n_processo = str_replace("<str>", "", $Post->n_processo);
				$Post->reclamante = str_replace("<str>", "", $Post->reclamante);
				$item = $_POST["item"];
				$valor = $_POST["valor"];
				$sentenca = $_POST["sentenca"];
				$itemprocesso = new Itemprocesso();
				$processo = array('coluna' => 'processo','tabela' => 'gpj_processo');
				foreach ($item as $key => $it) {
					$i = $i+1;
					$itemprocesso->item = $it;
					$itemprocesso->valor = $funcoes->sanearValor($valor{$key});
					$itemprocesso->sentenca = $funcoes->sanearValor($sentenca{$key});
					$sql[$i] = $apiItem->addItemprocesso($itemprocesso,$processo);
				}
				$log = new Log();
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico = "N_PROCESSO||{$Post->n_processo};;DES_PROCESSO||{$Post->des_processo};;ACAO||{$Post->acao};;VARA||{$Post->vara};;TERCEIRO||{$Post->terceiro};;RECLAMANTE||{$Post->reclamante};;NOME_RECLAMANTE||{$Post->nome_reclamante};;VAL_CAUSA||{$Post->val_causa};;VAL_SENTENCA||{$Post->val_sentenca};;VAL_QUITACAO||{$Post->val_quitacao};;DTA_INICIO||{$Post->dta_inicio};;DTA_PROXIMA_ACAO||{$Post->dta_proxima_acao};;DTA_ENCERRAMENTO||{$Post->dta_encerramento};;EMPRESA||{$Post->empresa};;STATUS||{$Post->status};;ATIVO||{$Post->ativo};;DTA_CADASTRO||{$Post->dta_cadastro}";
				$apiLog = new apiLog();
				$i = $i+1;
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiProcesso->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'gpj/processo/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'gpj/processo/index/sucesso');
					}
				}else{
					$this->rollback = $Post;
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		
		$this->view();
	}
	
	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Altera��o de Processo";
		$this->funcoes = new Funcoes();
		$processo = new Processo();
		$processo->empresa = $_SESSION['empresa_sessao'];
		$processo->processo = $this->getParams(0);
		$apiProcesso = new apiProcesso();
		$this->dados = array('processo' => $apiProcesso->getProcesso($processo));
		if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-4"])){
			$apiNatureza = new apiNatureza();
			$nat = $apiNatureza->filtroNatureza('1', '3', 'ativo', '1');
			foreach ($nat as $rs){
				$this->natureza[$rs->NATUREZA] = array('natureza' => $rs->NATUREZA, 'des_natureza' => $rs->DES_NATUREZA);
			}
		}else{
			$apiConsultor = new apiConsultor();
			$this->consultor = $apiConsultor->filtroConsultor('1', 'tudo', 'c.consultor', $_SESSION['usuario_sessao']);
			foreach ($this->consultor as $rs){
				$this->natureza[$rs->NATUREZA] = array('natureza' => $rs->NATUREZA, 'des_natureza' => $rs->DES_NATUREZA);
			}
		}
		if (isset($this->dados['processo'])){
			if (isset($this->natureza[$this->dados['processo']->NATUREZA])){
				if ($this->dados['processo']->ATIVO == '0'){
					if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
						header('location:' .APP_ROOT. 'gpj/index/index/acessonegado');
						die();
					}
				}
			}else{
				header('location:' .APP_ROOT. 'gpj/index/index/acessonegado');
				die();
			}
		}else{
			header('location:' .APP_ROOT. 'gpj/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		
		$apiVara = new apiVara();
		$this->vara = $apiVara->filtroVara('1','3','ativo','1',$this->dados['processo']->NATUREZA);
		$apiEmpresa  = new apiEmpresa();
		$empresa = new Empresa();
		$empresa->empresa = $_SESSION['empresa_sessao'];
		$local = $apiEmpresa->getEmpresa($empresa);
		$apiCidade = new apiCidade();
		$this->cidade = $apiCidade->filtroCidade('1','1','uf', $local->UF);
		$apiStatus = new apiStatus();
		$this->status = $apiStatus->filtroStatus('1','3','ativo', '1');
		$apiDepartamento = new apiDepartamento();
		$this->departamento = $apiDepartamento->filtroDepartamento('1','3','d.ativo', '1');
		$apiItem = new apiItem();
		$this->item = $apiItem->filtroItem('1', '3','ativo','1',$this->dados['processo']->NATUREZA);
		$apiRisco = new apiRisco();
		$this->risco = $apiRisco->filtroRisco('1','3','ativo','1');
		$this->itens = $apiItem->getItemprocesso($processo);
		$apiMovimento = new apiMovimento();
		$this->movimento = $apiMovimento->filtroMovimento('1', '3', 'p.processo', $processo->processo);
		$apiTipo = new apiTipo();
		$this->tipo = $apiTipo->filtroTipo('1','3','ativo','1', $this->dados['processo']->NATUREZA);
		$apiParcela = new apiParcela();
		$this->parcela = $apiParcela->getParcelaprocesso($processo->processo);
		$apiRisco = new apiRisco();
		$this->risco = $apiRisco->filtroRisco('1','3','ativo','1');
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			if ($_POST['submeter'] == "movimentar"){
				$Post = new Movimento();
				$Post->processo = $processo->processo;
				$Post->tipo = $_POST['tipo'];
				$Post->usuario = $_SESSION['usuario_sessao'];
				if ($_POST['preposto_movimentacao'] == 'S'){
					if ($_POST['preposto'] != ""){
						$Post->des_movimento = str_replace("\r\n","<br>",$_POST["des_movimento"])."<br><b>Preposto: </b>".strtoupper($this->funcoes->retiraAcentos(trim($_POST['preposto'])))."<br>";
					}else{
						$Post->des_movimento = str_replace("\r\n","<br>",$_POST["des_movimento"])."<br>";
					}
				}else{
					$Post->des_movimento = str_replace("\r\n","<br>",$_POST["des_movimento"])."<br>";
				}
				$Post->dta_movimento = date("d/m/Y H:i:s");
				$apiMovimento = new apiMovimento();
				$sql[$i] = $apiMovimento->addMovimento($Post);
				$i = $i+1;
				if ($_POST['dta_acao'] != ""){
					$Postprocesso = new Processo();
					$Postprocesso->processo = $processo->processo;
					if ($_POST['hora_acao'] != ""){
						$Postprocesso->dta_proxima_acao = "{$_POST['dta_acao']} {$_POST['hora_acao']}";
					}else{
						$Postprocesso->dta_proxima_acao = "{$_POST['dta_acao']} 17:30:00";
					}
					$sql[$i] = $apiProcesso->editProcesso($Postprocesso);
				}
				$rs = $apiMovimento->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'gpj/processo/alterar/'.$processo->processo.'/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'gpj/processo/alterar/'.$processo->processo.'/sucesso');
					}
				}else{
					$this->rollback = new Movimento();
					$this->rollback->tipo = $Post->tipo;
					$this->rollback->dta_acao = $_POST['dta_acao'];
					$this->rollback->hora_acao = $_POST['hora_acao'];
					$this->rollback->preposto_movimentacao = $_POST['preposto_movimentacao'];
					$this->rollback->des_movimento = $_POST['des_movimento'];
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}elseif ($_POST['submeter'] == "alterar"){
				$anterior = "";
				$atual = "::";
				$Post = new Processo();
				$Post->processo = $processo->processo;
				if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-2"]) && ($this->dados['processo']->N_PROCESSO != $this->funcoes->naoNumerico($_POST['n_processo']))){
					$Post->n_processo = $this->funcoes->naoNumerico($_POST['n_processo']);
					$anterior .= "N_PROCESSO||{$this->dados['processo']->N_PROCESSO};;";
					$atual .= "N_PROCESSO||{$Post->n_processo};;";
				}
				if ($this->dados['processo']->DES_PROCESSO != strtoupper($this->funcoes->retiraAcentos(trim($_POST['des_processo'])))){
					$Post->des_processo =  strtoupper($this->funcoes->retiraAcentos(trim($_POST['des_processo'])));
					$anterior .= "DES_PROCESSO||{$this->dados['processo']->DES_PROCESSO};;";
					$atual .= "DES_PROCESSO||{$Post->des_processo};;";
				}
				if ($this->dados['processo']->VARA != $_POST['vara']){
					$Post->vara = $_POST['vara'];
					$anterior .= "VARA||{$this->dados['processo']->VARA};;";
					$atual .= "VARA||{$Post->vara};;";
				}
				if ($this->dados['processo']->CIDADE != $_POST['cidade']){
					$Post->cidade = $_POST['cidade'];
					$anterior .= "CIDADE||{$this->dados['processo']->CIDADE};;";
					$atual .= "CIDADE||{$Post->cidade};;";
				}
				if ($this->dados['processo']->POLO != $_POST['polo']){
					$Post->polo = $_POST['polo'];
					$anterior .= "POLO||{$this->dados['processo']->POLO};;";
					$atual .= "POLO||{$Post->polo};;";
				}
				if ($this->dados['processo']->NATUREZA == 5){
					if (isset($_POST['autterceiro'])){
						$expo = explode("-", $_POST['reclamante']);
						if ($this->dados['processo']->RECLAMANTE != $expo[0]){
							$Post->reclamante = $expo[0];
							$nome = strtoupper($this->funcoes->retiraAcentos(trim($expo[1])));
							$anterior .= "RECLAMANTE||{$this->dados['processo']->RECLAMANTE};;";
							$atual .= "RECLAMANTE||{$Post->reclamante};;";
							$Post->reclamante = "<str>".$expo[0];
						}
					}else{
						if ($this->dados['processo']->RECLAMANTE != $this->funcoes->naoNumerico($_POST['cons_reclamante'])){
							$Post->reclamante = $this->funcoes->naoNumerico($_POST['cons_reclamante']);
							$nome = strtoupper($this->funcoes->retiraAcentos(trim($_POST['reclamante'])));
							$anterior .= "RECLAMANTE||{$this->dados['processo']->RECLAMANTE};;";
							$atual .= "RECLAMANTE||{$Post->reclamante};;";
							$Post->reclamante = "<str>".$this->funcoes->naoNumerico($_POST['cons_reclamante']);
						}
					}
					if ($this->dados['processo']->NOME_RECLAMANTE != $nome){
						$Post->nome_reclamante = $nome;
						$anterior .= "NOME_RECLAMANTE||{$this->dados['processo']->NOME_RECLAMANTE};;";
						$atual .= "NOME_RECLAMANTE||{$Post->nome_reclamante};;";
					}
				}else{
					if ($this->dados['processo']->TERCEIRO != $_POST['terceiro']){
						$Post->terceiro = $_POST['terceiro'];
						$anterior .= "TERCEIRO||{$this->dados['processo']->TERCEIRO};;";
						$atual .= "TERCEIRO||{$Post->terceiro};;";
					}
					if ($_POST['terceiro'] == "S"){
						if (isset($_POST['autterceiro'])){
							$expo = explode("-", $_POST['reclamante']);
							if ($this->dados['processo']->RECLAMANTE != $expo[0]){
								$Post->reclamante = $expo[0];
								$anterior .= "RECLAMANTE||{$this->dados['processo']->RECLAMANTE};;";
								$atual .= "RECLAMANTE||{$Post->reclamante};;";
								$Post->reclamante = "<str>".$expo[0];
							}
						}else{
							if ($this->dados['processo']->RECLAMANTE != $this->funcoes->naoNumerico($_POST['cons_reclamante'])){
								$Post->reclamante = $this->funcoes->naoNumerico($_POST['cons_reclamante']);
								$nome = strtoupper($this->funcoes->retiraAcentos(trim($_POST['reclamante'])));
								$anterior .= "RECLAMANTE||{$this->dados['processo']->RECLAMANTE};;";
								$atual .= "RECLAMANTE||{$Post->reclamante};;";
								$Post->reclamante = "<str>".$this->funcoes->naoNumerico($_POST['cons_reclamante']);
							}
						}
					}else{
						$expo = explode("-", $_POST['reclamante']);
						if ($this->dados['processo']->RECLAMANTE != $expo[0]){
							$Post->reclamante = $expo[0];
							$anterior .= "RECLAMANTE||{$this->dados['processo']->RECLAMANTE};;";
							$atual .= "RECLAMANTE||{$Post->reclamante};;";
							$Post->reclamante = "<str>".$expo[0];
						}
					}
					if ($this->dados['processo']->NOME_RECLAMANTE != strtoupper($this->funcoes->retiraAcentos(trim($_POST['nome_reclamante'])))){
						$Post->nome_reclamante = strtoupper($this->funcoes->retiraAcentos(trim($_POST['nome_reclamante'])));
						$anterior .= "NOME_RECLAMANTE||{$this->dados['processo']->NOME_RECLAMANTE};;";
						$atual .= "NOME_RECLAMANTE||{$Post->nome_reclamante};;";
					}
				}
				
				
				if ($this->dados['processo']->PREPOSTO != strtoupper($this->funcoes->retiraAcentos(trim($_POST['preposto'])))){
					$Post->preposto = strtoupper($this->funcoes->retiraAcentos(trim($_POST['preposto'])));
					$anterior .= "PREPOSTO||{$this->dados['processo']->PREPOSTO};;";
					$atual .= "PREPOSTO||{$Post->preposto};;";
				}
				if ($this->dados['processo']->TESTEMUNHA_EMP1 != strtoupper($this->funcoes->retiraAcentos(trim($_POST['testemunha_emp1'])))){
					$Post->testemunha_emp1 = strtoupper($this->funcoes->retiraAcentos(trim($_POST['testemunha_emp1'])));
					$anterior .= "TESTEMUNHA_EMP1||{$this->dados['processo']->TESTEMUNHA_EMP1};;";
					$atual .= "TESTEMUNHA_EMP1||{$Post->testemunha_emp1};;";
				}
				if ($this->dados['processo']->TESTEMUNHA_EMP2 != strtoupper($this->funcoes->retiraAcentos(trim($_POST['testemunha_emp2'])))){
					$Post->testemunha_emp2 = strtoupper($this->funcoes->retiraAcentos(trim($_POST['testemunha_emp2'])));
					$anterior .= "TESTEMUNHA_EMP2||{$this->dados['processo']->TESTEMUNHA_EMP2};;";
					$atual .= "TESTEMUNHA_EMP2||{$Post->testemunha_emp2};;";
				}
				if ($this->dados['processo']->TESTEMUNHA_EMP3 != strtoupper($this->funcoes->retiraAcentos(trim($_POST['testemunha_emp3'])))){
					$Post->testemunha_emp3 = strtoupper($this->funcoes->retiraAcentos(trim($_POST['testemunha_emp3'])));
					$anterior .= "TESTEMUNHA_EMP3||{$this->dados['processo']->TESTEMUNHA_EMP3};;";
					$atual .= "TESTEMUNHA_EMP3||{$Post->testemunha_emp3};;";
				}
				if ($this->dados['processo']->TESTEMUNHA_RECL1 != strtoupper($this->funcoes->retiraAcentos(trim($_POST['testemunha_recl1'])))){
					$Post->testemunha_recl1 = strtoupper($this->funcoes->retiraAcentos(trim($_POST['testemunha_recl1'])));
					$anterior .= "TESTEMUNHA_RECL1||{$this->dados['processo']->TESTEMUNHA_RECL1};;";
					$atual .= "TESTEMUNHA_RECL1||{$Post->testemunha_recl1};;";
				}
				if ($this->dados['processo']->TESTEMUNHA_RECL2 != strtoupper($this->funcoes->retiraAcentos(trim($_POST['testemunha_recl2'])))){
					$Post->testemunha_recl2 = strtoupper($this->funcoes->retiraAcentos(trim($_POST['testemunha_recl2'])));
					$anterior .= "TESTEMUNHA_RECL2||{$this->dados['processo']->TESTEMUNHA_RECL2};;";
					$atual .= "TESTEMUNHA_RECL2||{$Post->testemunha_recl2};;";
				}
				if ($this->dados['processo']->TESTEMUNHA_RECL3 != strtoupper($this->funcoes->retiraAcentos(trim($_POST['testemunha_recl3'])))){
					$Post->testemunha_recl3 = strtoupper($this->funcoes->retiraAcentos(trim($_POST['testemunha_recl3'])));
					$anterior .= "TESTEMUNHA_RECL3||{$this->dados['processo']->TESTEMUNHA_RECL3};;";
					$atual .= "TESTEMUNHA_RECL3||{$Post->testemunha_recl3};;";
				}
				if ($this->dados['processo']->VAL_CAUSA != $this->funcoes->sanearValor($_POST['val_causa'])){
					$Post->val_causa = $this->funcoes->sanearValor($_POST['val_causa']);
					$anterior .= "VAL_CAUSA||{$this->dados['processo']->VAL_CAUSA};;";
					$atual .= "VAL_CAUSA||{$Post->val_causa};;";
				}
				if ($this->dados['processo']->VAL_SENTENCA != $this->funcoes->sanearValor($_POST['val_sentenca'])){
					$Post->val_sentenca = $this->funcoes->sanearValor($_POST['val_sentenca']);
					$anterior .= "VAL_SENTENCA||{$this->dados['processo']->VAL_SENTENCA};;";
					$atual .= "VAL_SENTENCA||{$Post->val_sentenca};;";
				}
				if ($this->dados['processo']->VAL_QUITACAO != $this->funcoes->sanearValor($_POST['val_quitacao'])){
					$Post->val_quitacao = $this->funcoes->sanearValor($_POST['val_quitacao']);
					$anterior .= "VAL_QUITACAO||{$this->dados['processo']->VAL_QUITACAO};;";
					$atual .= "VAL_QUITACAO||{$Post->val_quitacao};;";
				}
				if ($this->dados['processo']->DTA_INICIO != $_POST['dta_inicio']){
					$Post->dta_inicio = $_POST['dta_inicio'];
					$anterior .= "DTA_INICIO||{$this->dados['processo']->DTA_INICIO};;";
					$atual .= "DTA_INICIO||{$Post->dta_inicio};;";
				}
				if ($this->dados['processo']->DTA_ENCERRAMENTO != $_POST['dta_encerramento']){
					$Post->dta_encerramento = $_POST['dta_encerramento'];
					$anterior .= "DTA_ENCERRAMENTO||{$this->dados['processo']->DTA_ENCERRAMENTO};;";
					$atual .= "DTA_ENCERRAMENTO||{$Post->dta_encerramento};;";
				}
				if ($this->dados['processo']->RISCO != $_POST['risco']){
					$Post->risco = $_POST['risco'];
					$anterior .= "RISCO||{$this->dados['processo']->RISCO};;";
					$atual .= "RISCO||{$Post->risco};;";
				}
				if ($this->dados['processo']->STATUS != $_POST['status']){
					$Post->status = $_POST['status'];
					$anterior .= "STATUS||{$this->dados['processo']->STATUS};;";
					$atual .= "STATUS||{$Post->status};;";
				}
				if ($this->dados['processo']->ATIVO != $_POST['ativo']){
					$Post->ativo = $_POST['ativo'];
					$anterior .= "ATIVO||{$this->dados['processo']->ATIVO};;";
					$atual .= "ATIVO||{$Post->ativo};;";
				}
				
				if ($Post->n_processo != ""){
					$r = $apiProcesso->filtroProcesso($_SESSION['empresa_sessao'],'1','3','n_processo',$Post->n_processo);
				}
				if (isset($r) && (is_array($r) ? count($r) : 0) > 0){
					$this->Alert = "J� existe um processo com esse n� cadastrado!";
				}else{
					if ($_POST['terceiro'] == "S"){
						if ($Post->reclamante != ""){
							$reclamante = new Reclamante();
							$reclamante->reclamante = str_replace("<str>", "", $Post->reclamante);
							$apiReclamante = new apiReclamante();
							$v = $apiReclamante->getReclamante($reclamante);
							if (!(is_array($v) ? count($v) : 0) == 1) {
								$reclamante->nome = $nome;
								$reclamante->departamento = $_POST['departamento'];
								$reclamante->reclamante = "<str>".$reclamante->reclamante;
								$sql[$i] = $apiReclamante->addReclamante($reclamante);
								$i = $i+1;
							}
						}elseif ($this->dados['processo']->DEPARTAMENTO != $_POST['departamento']){
							$reclamante = new Reclamante();
							$apiReclamante = new apiReclamante();
							$reclamante->reclamante = $this->dados['processo']->RECLAMANTE;
							$reclamante->departamento = $_POST['departamento'];
							$sql[$i] = $apiReclamante->editReclamante($reclamante);
							$i = $i+1;
						}
					}elseif ($this->dados['processo']->DEPARTAMENTO != $_POST['departamento']){
						$expo = explode("-", $_POST['reclamante']);
						$sql[$i] = "UPDATE sis_usuario SET departamento = '{$_POST['departamento']}' WHERE cpf = '{$expo[0]}'";
						$i = $i+1;
					}
					if (($apiProcesso->editProcesso($Post)) != ""){
						$sql[$i] = $apiProcesso->editProcesso($Post);
						$i = $i+1;
						$log = new Log();
						$log->historico = substr($anterior,0,-2);
						$log->usuario = $_SESSION['usuario_sessao'];
						$log->modulo = $this->getModule()['modulo'];
						$log->controle = $this->getController()['controle'];
						$log->acao = $this->getAction()['acao'];
						$log->empresa = $_SESSION['empresa_sessao'];
						$log->tipo = "A";
						$log->dta_registro = date("d/m/Y H:i:s");
						$log->historico .= substr($atual,0,-2);
						$apiLog = new apiLog();
						$sql[$i] = $apiLog->addLog($log);
					}
					$itemprocesso = new Itemprocesso();
					$itemprocesso->processo = $processo->processo;
					if (isset($sql[$i])) {
						$i = $i+1;
						$sql[$i] = $apiItem->delItemprocesso($itemprocesso);
					}else{
						$sql[$i] = $apiItem->delItemprocesso($itemprocesso);
					}
					$item = $_POST["item"];
					$valor = $_POST["valor"];
					$sentenca = $_POST["sentenca"];
					foreach ($item as $key => $it) {
						$i = $i+1;
						$itemprocesso->item = $it;
						$itemprocesso->valor = $this->funcoes->sanearValor($valor{$key});
						$itemprocesso->sentenca = $this->funcoes->sanearValor($sentenca{$key});
						$sql[$i] = $apiItem->addItemprocesso($itemprocesso);
					}
					$rs = $apiProcesso->executeSQL($sql);
					if (@$rs[4] == 'sucesso') {
						if (isset($this->PaginaAtual)) {
							header('location:' .APP_ROOT. 'gpj/processo/alterar/'.$processo->processo.'/'.$this->PaginaAtual.'/sucesso');
						}else {
							header('location:' .APP_ROOT. 'gpj/processo/alterar/'.$processo->processo.'/sucesso');
						}
					}else{
						$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
						$erro = str_replace($retirar, "", $rs[2]);
						$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
					}
				}
			}elseif ($_POST['submeter'] == "modificar"){
				$Post = new Parcela();
				$Post->processo = $processo->processo;
				$sql[$i] = $apiParcela->delParcela($Post);
				$vencimento = $_POST["dta_vencimento"];
				$parcela = $_POST["val_parcela"];
				$situacao = $_POST['situacao'];
				$this->parcela = array();
				$ob = 0;
				foreach ($vencimento as $key => $parc) {
					$i = $i+1;
					$this->parcela[$ob]->DTA_VENCIMENTO = $parc;
					$this->parcela[$ob]->VAL_PARCELA = $this->funcoes->sanearValor($parcela{$key});
					$this->parcela[$ob]->SITUACAO = $situacao{$key};
					$Post->dta_vencimento = $parc;
					$Post->val_parcela = $this->funcoes->sanearValor($parcela{$key});
					$Post->situacao = $situacao{$key};
					$sql[$i] = $apiParcela->addParcela($Post);
					$ob = $ob+1;
				}
				$rs = $apiParcela->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'gpj/processo/alterar/'.$processo->processo.'/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'gpj/processo/alterar/'.$processo->processo.'/sucesso');
					}
				}else{
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}else{
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'gpj/processo/alterar/'.$processo->processo.'/'.$this->PaginaAtual.'/sucesso');
					die();
				}else {
					header('location:' .APP_ROOT. 'gpj/processo/alterar/'.$processo->processo.'/sucesso');
					die();
				}
			}
		}
		$this->view();
	}
	public function excluir() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Exclus�o de Processo";
		$this->funcoes = new Funcoes();
		$processo = new Processo();
		$processo->processo = $this->getParams(0);
		$processo->empresa = $_SESSION['empresa_sessao'];
		$apiProcesso = new apiProcesso();
		$this->dados = array('processo' => $apiProcesso->getProcesso($processo));
		if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-4"])){
			$apiNatureza = new apiNatureza();
			$nat = $apiNatureza->filtroNatureza('1', '3', 'ativo', '1');
			foreach ($nat as $rs){
				$this->natureza[$rs->NATUREZA] = array('natureza' => $rs->NATUREZA, 'des_natureza' => $rs->DES_NATUREZA);
			}
		}else{
			$apiConsultor = new apiConsultor();
			$this->consultor = $apiConsultor->filtroConsultor('1', 'tudo', 'c.consultor', $_SESSION['usuario_sessao']);
			foreach ($this->consultor as $rs){
				$this->natureza[$rs->NATUREZA] = array('natureza' => $rs->NATUREZA, 'des_natureza' => $rs->DES_NATUREZA);
			}
		}
		if (isset($this->dados['processo'])){
			if (isset($this->natureza[$this->dados['processo']->NATUREZA])){
				if ($this->dados['processo']->ATIVO == '0'){
					if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
						header('location:' .APP_ROOT. 'gpj/index/index/acessonegado');
						die();
					}
				}
			}else{
				header('location:' .APP_ROOT. 'gpj/index/index/acessonegado');
				die();
			}
		}else{
			header('location:' .APP_ROOT. 'gpj/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$apiMovimento = new apiMovimento();
			$sql[$i] = $apiMovimento->delMovimentoprocesso($processo);
			$i = $i + 1;
			$apiItem  =  new apiItem();
			$itemprocesso = new Itemprocesso();
			$itemprocesso->processo = $processo->processo;
			$sql[$i] = $apiItem->delItemprocesso($itemprocesso);
			$i = $i + 1;
			$apiParcela = new apiParcela();
			$parcela = new Parcela();
			$parcela->processo = $processo->processo;
			$sql[$i] = $apiParcela->delParcela($parcela);
			$i = $i+1;
			$sql[$i] = $apiProcesso->delProcesso($processo);
			$i = $i+1;
			$log = new Log();
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "E";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico = "PROCESSO||{$this->dados['processo']->PROCESSO};;N_PROCESSO||{$this->dados['processo']->N_PROCESSO};;DES_PROCESSO||{$this->dados['processo']->DES_PROCESSO};;ACAO||{$this->dados['processo']->ACAO};;VARA||{$this->dados['processo']->VARA};;TERCEIRO||{$this->dados['processo']->TERCEIRO};;RECLAMANTE||{$this->dados['processo']->RECLAMANTE};;NOME_RECLAMANTE||{$this->dados['processo']->NOME_RECLAMANTE};;PREPOSTO||{$this->dados['processo']->PREPOSTO};;TESTEMUNHA_EMP1||{$this->dados['processo']->TESTEMUNHA_EMP1};;TESTEMUNHA_EMP2||{$this->dados['processo']->TESTEMUNHA_EMP2};;TESTEMUNHA_EMP3||{$this->dados['processo']->TESTEMUNHA_EMP3};;TESTEMUNHA_RECL1||{$this->dados['processo']->TESTEMUNHA_RECL1};;TESTEMUNHA_RECL2||{$this->dados['processo']->TESTEMUNHA_RECL2};;TESTEMUNHA_RECL3||{$this->dados['processo']->TESTEMUNHA_RECL3};;VAL_CAUSA||{$this->dados['processo']->VAL_CAUSA};;VAL_SENTENCA||{$this->dados['processo']->VAL_SENTENCA};;VAL_QUITACAO||{$this->dados['processo']->VAL_QUITACAO};;DTA_INICIO||{$this->dados['processo']->DTA_INICIO};;DTA_PROXIMA_CAO||{$this->dados['processo']->DTA_PROXIMA_ACAO};;DTA_ENCERRAMENTO||{$this->dados['processo']->DTA_ENCERRAMENTO};;EMPRESA||{$this->dados['processo']->EMPRESA};;STATUS||{$this->dados['processo']->STATUS};;DTA_CADASTRO||{$this->dados['processo']->DTA_CADASTRO};;ATIVO||{$this->dados['processo']->ATIVO}";
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiProcesso->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'gpj/processo/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'gpj/processo/index/sucesso');
				}
			}else{
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}
		$this->view();
	}
	
	public function visualizar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Visualizar Processo";
		$this->funcoes = new Funcoes();
		$processo = new Processo();
		$this->processo = $processo->processo = $this->getParams(0);
		$apiProcesso = new apiProcesso();
		$this->dados = array('processo' => $apiProcesso->getProcesso($processo));
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		$apiItem = new apiItem();
		$this->itens = $apiItem->getItemprocesso($processo);
		$apiMovimento = new apiMovimento();
		$this->movimento = $apiMovimento->filtroMovimento('1', '3', 'p.processo', $this->processo);
		$this->view();
	}
}