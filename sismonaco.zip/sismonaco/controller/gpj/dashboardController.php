<?php
namespace controller\gpj;

use lib\Controller;
use helper\Security;
use api\gpj\apiDashboard;
use helper\Funcoes;
use api\gpj\apiNatureza;
use api\gpj\apiConsultor;
use api\adm\apiPermissao;
use obj\adm\Permissao;
use api\adm\apiDepartamento;

include 'classes/PHPExcel.php';

class dashboardController extends Controller{
	
	public function __construct() {
		
		parent::__construct();
		
		new Security($this->getModule(),$this->getController(),$this->getAction());
	}
	
	public function index(){
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Dashboard";
		$apiPermissao = new apiPermissao();
		$permissao = new Permissao();
		$apiDashboard = new apiDashboard();
		$funcoes = new Funcoes();
		if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-4"])){
			$apiNatureza = new apiNatureza();
			$nat = $apiNatureza->filtroNatureza('1', '3', 'ativo', '1');
			foreach ($nat as $rs){
				$this->natureza[$rs->NATUREZA] = array('natureza' => $rs->NATUREZA, 'des_natureza' => $rs->DES_NATUREZA);
			}
			$apiConsultor = new apiConsultor();
			$this->consultor = $apiConsultor->filtroConsultor('1', 'tudo', 'c.consultor', $_SESSION['usuario_sessao']);
		}else{
			$apiConsultor = new apiConsultor();
			$this->consultor = $apiConsultor->filtroConsultor('1', 'tudo', 'c.consultor', $_SESSION['usuario_sessao']);
			foreach ($this->consultor as $rs){
				$this->natureza[$rs->NATUREZA] = array('natureza' => $rs->NATUREZA, 'des_natureza' => $rs->DES_NATUREZA);
			}
		}
		$permissao->usuario = $_SESSION['usuario_sessao'];
		$permissao->modulo  = $this->getModule()['modulo'];
		$this->empresa = $apiPermissao->permEmpresa($permissao);
		$apiDepartamento = new apiDepartamento();
		$this->departamento = $apiDepartamento->filtroDepartamento('1','3','d.ativo', '1');
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			
			if ($_POST['submeter'] == "gerar"){
				unset($_SESSION['filtro_dashboard']);
				unset($_SESSION['consulta_dashboard']);
				$dashboard = $_POST['dashboard'];
				@$empresa = implode("','",array_values($_POST['empresa']));
				@$departamento = implode("','",array_values($_POST['departamento']));
				@$natureza = implode("','",array_values($_POST['natureza']));
				$de = $_POST['de'];
				$ate = $_POST['ate'];
				$this->dados = array('dashboard' => $apiDashboard->getDashboard($empresa, $natureza, $departamento, $dashboard, $de, $ate));
				$_SESSION['filtro_dashboard'] = array('empresa' => @$_POST['empresa'], 'natureza' => @$_POST['natureza'], 'departamento' => @$_POST['departamento'], 'dashboard' => $dashboard, 'de' => $de, 'ate' => $ate);
				$_SESSION['consulta_dashboard'] = $this->dados;
			}elseif ($_POST['submeter'] == "imprimir"){
				$this->dados = $_SESSION['consulta_dashboard'];
				if ($_SESSION['filtro_dashboard']['dashboard'] == 'agenda'){
					$i = 0;
					$objPHPExcel = new \PHPExcel();
					
					$objPHPExcel->getActiveSheet()->getPageSetup()->setOrientation(\PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
					$objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(\PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
					$objPHPExcel->getActiveSheet()->setShowGridlines(true);
					$objPHPExcel->getActiveSheet()->getPageSetup()->setFitToPage(true);
					$objPHPExcel->getActiveSheet()->getSheetView()->setZoomScale(80);
					
					$objPHPExcel->getActiveSheet()->mergeCells('A1:H1');
					$objPHPExcel->getActiveSheet()->getStyle('A1:H1')->getFont()->setSize(18)->setName('Courier New')->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('A2:H2')->getFont()->setSize(16)->setName('Courier New')->setBold(true);
					
					
					$objPHPExcel->setActiveSheetIndex(0);
					$objPHPExcel->getActiveSheet()->setCellValue("A2", "Empresa" )
					->setCellValue("B2", utf8_encode("N� Processo"))
					->setCellValue("C2", "Vara" )
					->setCellValue("D2", utf8_encode("Parte Contr�ria"))
					->setCellValue("E2", utf8_encode("Data"))
					->setCellValue("F2", utf8_encode("Hora"))
					->setCellValue("G2", "Status")
					->setCellValue("H2", "Preposto" );
					
					$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(70);
					$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(43);
					$objPHPExcel->getActiveSheet()->getStyle('B')->getNumberFormat()->setFormatCode('0');
					$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(40);
					$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(60);
					$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(17.5);
					$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(17.5);
					$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(35);
					$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(55);
					
					$gdImage = imagecreatefromjpeg($_SERVER["DOCUMENT_ROOT"] . "/sismonaco/content/geral/img/logomonacom.jpg");
					$objDrawing = new \PHPExcel_Worksheet_MemoryDrawing();
					$objDrawing->setName('Monaco');
					$objDrawing->setDescription('Logo Monaco');
					$objDrawing->setImageResource($gdImage);
					$objDrawing->setRenderingFunction(\PHPExcel_Worksheet_MemoryDrawing::RENDERING_JPEG);
					$objDrawing->setMimeType(\PHPExcel_Worksheet_MemoryDrawing::MIMETYPE_JPEG);
					$objDrawing->setCoordinates('A1');
					$objDrawing->setOffsetX(2);
					$objDrawing->setOffsetY(2);
					$objDrawing->setResizeProportional(false);
					$objDrawing->setWidth(25);
					$objDrawing->setHeight(20);
					$objDrawing->setWorksheet($objPHPExcel->getActiveSheet());
					
					$objPHPExcel->setActiveSheetIndex()->setCellValue('A1', utf8_encode("   Grupo M�naco - Agenda de Audi�ncias No Per�odo De {$_SESSION['filtro_dashboard']['de']} At� {$_SESSION['filtro_dashboard']['ate']}") );
					$i = 2;
					foreach ($this->dados['dashboard'] as $rs){
						$i = $i + 1;
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, utf8_encode("".ucfirst(strtolower($rs->EMPRESA)).""));
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $funcoes->mask($rs->N_PROCESSO,'#######-##.####.#.##.####'));
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, utf8_encode("".$rs->VARA."� ".ucfirst(strtolower($rs->DES_CIDADE)).""));
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, utf8_encode("".ucfirst(strtolower($rs->RECLAMANTE)).""));
						$exp = explode(" ", $rs->DTA_PROXIMA_ACAO);
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $exp[0]);
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $exp[1]);
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, utf8_encode("".ucfirst(strtolower($rs->DES_STATUS)).""));
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, utf8_encode("".ucfirst(strtolower($rs->PREPOSTO)).""));
					}
					$objPHPExcel->getActiveSheet()->getStyle("A3:G{$i}")->getFont()->setSize(14)->setName('Courier New');
					
					$objPHPExcel->getActiveSheet()->setTitle( utf8_encode("Agenda de Audi�ncia"));
					
					$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
					$nome_arquivo = "AGENDA-".date('d-m-Y').".xls";
					header('Content-Type: application/vnd.ms-excel');
					header("Content-Disposition: attachment;filename={$nome_arquivo}");
					header("Pragma: no-cache");
					header("Expires: 0");
					
					ob_end_clean();
					$objWriter->save('php://output');
				}elseif ($_SESSION['filtro_dashboard']['dashboard'] == 'acoes'){
					foreach ($this->dados['dashboard'] as $rs){
						$processo[$rs->EMPRESA][$rs->TERCEIRO][$rs->N_LINHA] = (array) $rs;
						$empresa[$rs->TERCEIRO][$rs->EMPRESA] = array('empresa' => $rs->EMPRESA, 'razao' => ucfirst(strtolower($funcoes->retiraAcentos($rs->RAZAO_SOCIAL))), 'terceiro' => $rs->TERCEIRO);
					}
					
					$i = 0;
					$objPHPExcel = new \PHPExcel();
					
					$objPHPExcel->setActiveSheetIndex(0);
					
					$objPHPExcel->getActiveSheet()->getPageSetup()->setOrientation(\PHPExcel_Worksheet_PageSetup::ORIENTATION_PORTRAIT);
					$objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(\PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
					$objPHPExcel->getActiveSheet()->setShowGridlines(true);
					$objPHPExcel->getActiveSheet()->getPageSetup()->setFitToPage(true);
					$objPHPExcel->getActiveSheet()->getSheetView()->setZoomScale(80);
					
					$objPHPExcel->getActiveSheet()->mergeCells('A1:J1');
					$objPHPExcel->getActiveSheet()->getStyle('A1:J1')->getFont()->setSize(15)->setName('Courier New')->setBold(true);
					$objPHPExcel->getActiveSheet()->mergeCells('A3:J3');
					$objPHPExcel->getActiveSheet()->getStyle('A3:J3')->getFont()->setSize(15)->setName('Courier New')->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('A3:J3')->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
					
					$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(30);
					$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(30);
					$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(30);
					$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(43);
					$objPHPExcel->getActiveSheet()->getStyle('D')->getNumberFormat()->setFormatCode('0');
					$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(30);
					$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(30);
					$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(30);
					$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(15);
					$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(30);
					$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(15);
					
					$gdImage = imagecreatefromjpeg($_SERVER["DOCUMENT_ROOT"] . "/sismonaco/content/geral/img/logomonacom.jpg");
					$objDrawing = new \PHPExcel_Worksheet_MemoryDrawing();
					$objDrawing->setName('Monaco');
					$objDrawing->setDescription('Logo Monaco');
					$objDrawing->setImageResource($gdImage);
					$objDrawing->setRenderingFunction(\PHPExcel_Worksheet_MemoryDrawing::RENDERING_JPEG);
					$objDrawing->setMimeType(\PHPExcel_Worksheet_MemoryDrawing::MIMETYPE_JPEG);
					$objDrawing->setCoordinates('A1');
					$objDrawing->setOffsetX(2);
					$objDrawing->setOffsetY(2);
					$objDrawing->setResizeProportional(false);
					$objDrawing->setWidth(25);
					$objDrawing->setHeight(20);
					$objDrawing->setWorksheet($objPHPExcel->getActiveSheet());
					
					$objPHPExcel->setActiveSheetIndex()->setCellValue('A1', utf8_encode("   Grupo M�naco - Custos com A��es no Per�odo De {$_SESSION['filtro_dashboard']['de']} At� {$_SESSION['filtro_dashboard']['ate']}") );
					$objPHPExcel->setActiveSheetIndex()->setCellValue('A3', utf8_encode("Processos Internos") );
					
					$i = 3;
					$arraytot = array();
					$ar = 0;
					$qtdtot = 0;
					$qtdtotproc = 0;
					$cft = "";
					$cgt = "";
					$cit = "";
					foreach ($empresa["N"] as $rs){
						$qtd = 0;
						$cont = 0;
						$i = $i + 1;
						$objPHPExcel->getActiveSheet()->mergeCells("A{$i}:J{$i}");
						$objPHPExcel->getActiveSheet()->getStyle("A{$i}:J{$i}")->getFont()->setSize(15)->setName('Courier New')->setBold(true);
						$objPHPExcel->getActiveSheet()->getStyle("A{$i}:J{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
						$objPHPExcel->setActiveSheetIndex()->setCellValue("A{$i}", utf8_encode($rs['razao']) );
						$i = $i + 1;
						$objPHPExcel->getActiveSheet()->mergeCells("A{$i}:C{$i}");
						$objPHPExcel->getActiveSheet()->getStyle("A{$i}:I{$i}")->getFont()->setSize(14)->setName('Courier New')->setBold(true);
						$objPHPExcel->getActiveSheet()->getStyle("A{$i}:C{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
						$objPHPExcel->getActiveSheet()->getStyle("D{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
						$objPHPExcel->getActiveSheet()->getStyle("E{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
						$objPHPExcel->getActiveSheet()->getStyle("F{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
						$objPHPExcel->getActiveSheet()->getStyle("G{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
						$objPHPExcel->getActiveSheet()->getStyle("H{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
						$objPHPExcel->getActiveSheet()->getStyle("I{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
						$objPHPExcel->getActiveSheet()->getStyle("J{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
						$objPHPExcel->setActiveSheetIndex()->setCellValue("A{$i}", utf8_encode("Parte Contr�ria") );
						$objPHPExcel->setActiveSheetIndex()->setCellValue("D{$i}", utf8_encode("N� Processo") );
						$objPHPExcel->setActiveSheetIndex()->setCellValue("E{$i}", utf8_encode("Departamento") );
						$objPHPExcel->setActiveSheetIndex()->setCellValue("F{$i}", utf8_encode("Valor da Causa") );
						$objPHPExcel->setActiveSheetIndex()->setCellValue("G{$i}", utf8_encode("Valor do Acordo") );
						$objPHPExcel->setActiveSheetIndex()->setCellValue("H{$i}", utf8_encode("% Acordo") );
						$objPHPExcel->setActiveSheetIndex()->setCellValue("I{$i}", utf8_encode("Valor Pago") );
						$objPHPExcel->setActiveSheetIndex()->setCellValue("J{$i}", utf8_encode("% Pago") );
						foreach ($processo[$rs['empresa']]["N"] as $e ){
							$qtd = $qtd + 1;
							$i = $i + 1;
							if ($cont == 0){
								$in = $i;
								$cont = 1;
							}
							$objPHPExcel->getActiveSheet()->mergeCells("A{$i}:C{$i}");
							$objPHPExcel->getActiveSheet()->getStyle("A{$i}:J{$i}")->getFont()->setSize(12)->setName('Courier New');
							$objPHPExcel->getActiveSheet()->getStyle("A{$i}:C{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
							$objPHPExcel->getActiveSheet()->getStyle("D{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
							$objPHPExcel->getActiveSheet()->getStyle("E{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
							$objPHPExcel->getActiveSheet()->getStyle("F{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
							$objPHPExcel->getActiveSheet()->getStyle("G{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
							$objPHPExcel->getActiveSheet()->getStyle("H{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
							$objPHPExcel->getActiveSheet()->getStyle("I{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
							$objPHPExcel->getActiveSheet()->getStyle("J{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
							$objPHPExcel->setActiveSheetIndex()->setCellValue("A{$i}", ucfirst(strtolower($e['RECLAMANTE'])));
							$objPHPExcel->setActiveSheetIndex()->setCellValue("D{$i}", $funcoes->mask($e['N_PROCESSO'],'#######-##.####.#.##.####'));
							$objPHPExcel->setActiveSheetIndex()->setCellValue("E{$i}", ucfirst(strtolower($e['DES_DEPARTAMENTO'])));
							$objPHPExcel->getActiveSheet()->getStyle("F{$i}")->getNumberFormat()->setFormatCode('R$ #,##0.00');
							$objPHPExcel->setActiveSheetIndex()->setCellValue("F{$i}", str_replace(",", ".", $e['VAL_CAUSA']),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
							$objPHPExcel->getActiveSheet()->getStyle("G{$i}")->getNumberFormat()->setFormatCode('R$ #,##0.00');
							$objPHPExcel->setActiveSheetIndex()->setCellValue("G{$i}", str_replace(",", ".", $e['VAL_SENTENCA']),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
							$objPHPExcel->getActiveSheet()->getStyle("H{$i}")->getNumberFormat()->setFormatCode('00%');
							$objPHPExcel->setActiveSheetIndex()->setCellValue("H{$i}", "=IF(F{$i}<>0,G{$i}/F{$i},0)");
							$objPHPExcel->getActiveSheet()->getStyle("I{$i}")->getNumberFormat()->setFormatCode('R$ #,##0.00');
							$objPHPExcel->setActiveSheetIndex()->setCellValue("I{$i}", str_replace(",", ".", $e['TOTAL_PAGO']),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
							$objPHPExcel->getActiveSheet()->getStyle("J{$i}")->getNumberFormat()->setFormatCode('00%');
							$objPHPExcel->setActiveSheetIndex()->setCellValue("J{$i}", "=IF(G{$i}<>0,I{$i}/G{$i},0)");
						}
						$qtdtot = $qtdtot + $qtd;
						$i = $i + 1;
						$ate = $i - 1;
						$arraytot[$ar] = $i;
						$ar = $ar + 1;
						$objPHPExcel->getActiveSheet()->mergeCells("A{$i}:C{$i}");
						$objPHPExcel->getActiveSheet()->getStyle("A{$i}:J{$i}")->getFont()->setSize(12)->setName('Courier New')->setBold(true);
						$objPHPExcel->getActiveSheet()->getStyle("A{$i}:C{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
						$objPHPExcel->getActiveSheet()->getStyle("D{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
						$objPHPExcel->getActiveSheet()->getStyle("E{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
						$objPHPExcel->getActiveSheet()->getStyle("F{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
						$objPHPExcel->getActiveSheet()->getStyle("G{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
						$objPHPExcel->getActiveSheet()->getStyle("H{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
						$objPHPExcel->getActiveSheet()->getStyle("I{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
						$objPHPExcel->getActiveSheet()->getStyle("J{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
						$objPHPExcel->setActiveSheetIndex()->setCellValue("A{$i}", "Total   {$qtd}");
						$objPHPExcel->setActiveSheetIndex()->setCellValue("D{$i}", "-");
						$objPHPExcel->setActiveSheetIndex()->setCellValue("E{$i}", "-");
						$objPHPExcel->getActiveSheet()->getStyle("F{$i}")->getNumberFormat()->setFormatCode('R$ #,##0.00');
						$objPHPExcel->setActiveSheetIndex()->setCellValue("F{$i}", "=SUBTOTAL(9,F{$in}:F{$ate})",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->getActiveSheet()->getStyle("G{$i}")->getNumberFormat()->setFormatCode('R$ #,##0.00');
						$objPHPExcel->setActiveSheetIndex()->setCellValue("G{$i}", "=SUBTOTAL(9,G{$in}:G{$ate})",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->getActiveSheet()->getStyle("H{$i}")->getNumberFormat()->setFormatCode('00%');
						$objPHPExcel->setActiveSheetIndex()->setCellValue("H{$i}", "=IF(F{$i}<>0,G{$i}/F{$i},0)");
						$objPHPExcel->getActiveSheet()->getStyle("I{$i}")->getNumberFormat()->setFormatCode('R$ #,##0.00');
						$objPHPExcel->setActiveSheetIndex()->setCellValue("I{$i}", "=SUBTOTAL(9,I{$in}:I{$ate})",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->getActiveSheet()->getStyle("J{$i}")->getNumberFormat()->setFormatCode('00%');
						$objPHPExcel->setActiveSheetIndex()->setCellValue("J{$i}", "=IF(G{$i}<>0,I{$i}/G{$i},0)");
						$i = $i + 1;
						$objPHPExcel->getActiveSheet()->mergeCells("A{$i}:J{$i}");
					}
					$i = $i + 1;
					$cf = "=SUM(";
					$cg = "=SUM(";
					$ci = "=SUM(";
					foreach ($arraytot as $rs){
						$cf .= "F{$rs}+";
						$cft .= "F{$rs}+";
						$cg .= "G{$rs}+";
						$cgt .= "G{$rs}+";
						$ci .= "I{$rs}+";
						$cit .= "I{$rs}+";
					}
					$cf = substr($cf,0,-1).")";
					$cg = substr($cg,0,-1).")";
					$ci = substr($ci,0,-1).")";
				 	
					$objPHPExcel->getActiveSheet()->mergeCells("A{$i}:C{$i}");
					$objPHPExcel->getActiveSheet()->getStyle("A{$i}:J{$i}")->getFont()->setSize(12)->setName('Courier New')->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle("A{$i}:C{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
					$objPHPExcel->getActiveSheet()->getStyle("D{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
					$objPHPExcel->getActiveSheet()->getStyle("E{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
					$objPHPExcel->getActiveSheet()->getStyle("F{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
					$objPHPExcel->getActiveSheet()->getStyle("G{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
					$objPHPExcel->getActiveSheet()->getStyle("H{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
					$objPHPExcel->getActiveSheet()->getStyle("I{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
					$objPHPExcel->getActiveSheet()->getStyle("J{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
					$objPHPExcel->setActiveSheetIndex()->setCellValue("A{$i}", "Total dos Processos Internos   {$qtdtot}");
					$objPHPExcel->setActiveSheetIndex()->setCellValue("D{$i}", "-");
					$objPHPExcel->setActiveSheetIndex()->setCellValue("E{$i}", "-");
					$objPHPExcel->getActiveSheet()->getStyle("F{$i}")->getNumberFormat()->setFormatCode('R$ #,##0.00');
					$objPHPExcel->setActiveSheetIndex()->setCellValue("F{$i}", "{$cf}",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->getActiveSheet()->getStyle("G{$i}")->getNumberFormat()->setFormatCode('R$ #,##0.00');
					$objPHPExcel->setActiveSheetIndex()->setCellValue("G{$i}", "{$cg}",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->getActiveSheet()->getStyle("H{$i}")->getNumberFormat()->setFormatCode('00%');
					$objPHPExcel->setActiveSheetIndex()->setCellValue("H{$i}", "=IF(F{$i}<>0,G{$i}/F{$i},0)");
					$objPHPExcel->getActiveSheet()->getStyle("I{$i}")->getNumberFormat()->setFormatCode('R$ #,##0.00');
					$objPHPExcel->setActiveSheetIndex()->setCellValue("I{$i}", "{$ci}",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->getActiveSheet()->getStyle("J{$i}")->getNumberFormat()->setFormatCode('00%');
					$objPHPExcel->setActiveSheetIndex()->setCellValue("J{$i}", "=IF(G{$i}<>0,I{$i}/G{$i},0)");
					$qtdtotproc = $qtdtotproc + $qtdtot;
					
					$i = $i + 1;
					$objPHPExcel->getActiveSheet()->mergeCells("A{$i}:J{$i}");
					$objPHPExcel->getActiveSheet()->getStyle("A{$i}:J{$i}")->getFont()->setSize(15)->setName('Courier New')->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle("A{$i}:J{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
					
					$objPHPExcel->setActiveSheetIndex()->setCellValue("A{$i}", utf8_encode("Processos de Terceiros") );
					
					$arraytot = array();
					$ar = 0;
					$qtdtot = 0;
					foreach ($empresa["S"] as $rs){
						$qtd = 0;
						$cont = 0;
						$i = $i + 1;
						$objPHPExcel->getActiveSheet()->mergeCells("A{$i}:J{$i}");
						$objPHPExcel->getActiveSheet()->getStyle("A{$i}:J{$i}")->getFont()->setSize(15)->setName('Courier New')->setBold(true);
						$objPHPExcel->getActiveSheet()->getStyle("A{$i}:J{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
						$objPHPExcel->setActiveSheetIndex()->setCellValue("A{$i}", utf8_encode($rs['razao']) );
						$i = $i + 1;
						$objPHPExcel->getActiveSheet()->mergeCells("B{$i}:C{$i}");
						$objPHPExcel->getActiveSheet()->getStyle("A{$i}:J{$i}")->getFont()->setSize(14)->setName('Courier New')->setBold(true);
						$objPHPExcel->getActiveSheet()->getStyle("A{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
						$objPHPExcel->getActiveSheet()->getStyle("B{$i}:C{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
						$objPHPExcel->getActiveSheet()->getStyle("D{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
						$objPHPExcel->getActiveSheet()->getStyle("E{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
						$objPHPExcel->getActiveSheet()->getStyle("F{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
						$objPHPExcel->getActiveSheet()->getStyle("G{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
						$objPHPExcel->getActiveSheet()->getStyle("H{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
						$objPHPExcel->getActiveSheet()->getStyle("I{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
						$objPHPExcel->getActiveSheet()->getStyle("J{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
						$objPHPExcel->setActiveSheetIndex()->setCellValue("A{$i}", utf8_encode("Terceiros") );
						$objPHPExcel->setActiveSheetIndex()->setCellValue("B{$i}", utf8_encode("Parte Contr�ria") );
						$objPHPExcel->setActiveSheetIndex()->setCellValue("D{$i}", utf8_encode("N� Processo") );
						$objPHPExcel->setActiveSheetIndex()->setCellValue("E{$i}", utf8_encode("Departamento") );
						$objPHPExcel->setActiveSheetIndex()->setCellValue("E{$i}", utf8_encode("Valor da Causa") );
						$objPHPExcel->setActiveSheetIndex()->setCellValue("F{$i}", utf8_encode("Valor do Acordo") );
						$objPHPExcel->setActiveSheetIndex()->setCellValue("G{$i}", utf8_encode("% Acordo") );
						$objPHPExcel->setActiveSheetIndex()->setCellValue("H{$i}", utf8_encode("Valor Pago") );
						$objPHPExcel->setActiveSheetIndex()->setCellValue("I{$i}", utf8_encode("% Pago") );
						foreach ($processo[$rs['empresa']]["S"] as $e ){
							$qtd = $qtd + 1;
							$i = $i + 1;
							if ($cont == 0){
								$in = $i;
								$cont = 1;
							}
							$objPHPExcel->getActiveSheet()->mergeCells("B{$i}:C{$i}");
							$objPHPExcel->getActiveSheet()->getStyle("A{$i}:J{$i}")->getFont()->setSize(12)->setName('Courier New');
							$objPHPExcel->getActiveSheet()->getStyle("A{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
							$objPHPExcel->getActiveSheet()->getStyle("B{$i}:C{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_LEFT);
							$objPHPExcel->getActiveSheet()->getStyle("D{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
							$objPHPExcel->getActiveSheet()->getStyle("E{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
							$objPHPExcel->getActiveSheet()->getStyle("F{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
							$objPHPExcel->getActiveSheet()->getStyle("G{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
							$objPHPExcel->getActiveSheet()->getStyle("H{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
							$objPHPExcel->getActiveSheet()->getStyle("I{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
							$objPHPExcel->getActiveSheet()->getStyle("J{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
							$objPHPExcel->setActiveSheetIndex()->setCellValue("A{$i}", ucfirst(strtolower($e['NOME_TERCEIRO'])));
							$objPHPExcel->setActiveSheetIndex()->setCellValue("B{$i}", ucfirst(strtolower($e['RECLAMANTE'])));
							$objPHPExcel->setActiveSheetIndex()->setCellValue("D{$i}", $funcoes->mask($e['N_PROCESSO'],'#######-##.####.#.##.####'));
							$objPHPExcel->setActiveSheetIndex()->setCellValue("E{$i}", ucfirst(strtolower($e['DES_DEPARTAMENTO'])));
							$objPHPExcel->getActiveSheet()->getStyle("F{$i}")->getNumberFormat()->setFormatCode('R$ #,##0.00');
							$objPHPExcel->setActiveSheetIndex()->setCellValue("F{$i}", str_replace(",", ".", $e['VAL_CAUSA']),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
							$objPHPExcel->getActiveSheet()->getStyle("G{$i}")->getNumberFormat()->setFormatCode('R$ #,##0.00');
							$objPHPExcel->setActiveSheetIndex()->setCellValue("G{$i}", str_replace(",", ".", $e['VAL_SENTENCA']),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
							$objPHPExcel->getActiveSheet()->getStyle("H{$i}")->getNumberFormat()->setFormatCode('00%');
							$objPHPExcel->setActiveSheetIndex()->setCellValue("H{$i}", "=IF(F{$i}<>0,G{$i}/F{$i},0)");
							$objPHPExcel->getActiveSheet()->getStyle("I{$i}")->getNumberFormat()->setFormatCode('R$ #,##0.00');
							$objPHPExcel->setActiveSheetIndex()->setCellValue("I{$i}", str_replace(",", ".", $e['TOTAL_PAGO']),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
							$objPHPExcel->getActiveSheet()->getStyle("J{$i}")->getNumberFormat()->setFormatCode('00%');
							$objPHPExcel->setActiveSheetIndex()->setCellValue("J{$i}", "=IF(G{$i}<>0,I{$i}/G{$i},0)");
						}
						$qtdtot = $qtdtot + $qtd;
						$i = $i + 1;
						$ate = $i - 1;
						$arraytot[$ar] = $i;
						$ar = $ar + 1;
						$objPHPExcel->getActiveSheet()->mergeCells("A{$i}:C{$i}");
						$objPHPExcel->getActiveSheet()->getStyle("A{$i}:J{$i}")->getFont()->setSize(12)->setName('Courier New')->setBold(true);
						$objPHPExcel->getActiveSheet()->getStyle("A{$i}:C{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
						$objPHPExcel->getActiveSheet()->getStyle("D{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
						$objPHPExcel->getActiveSheet()->getStyle("E{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
						$objPHPExcel->getActiveSheet()->getStyle("F{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
						$objPHPExcel->getActiveSheet()->getStyle("G{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
						$objPHPExcel->getActiveSheet()->getStyle("H{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
						$objPHPExcel->getActiveSheet()->getStyle("I{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
						$objPHPExcel->getActiveSheet()->getStyle("J{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
						$objPHPExcel->setActiveSheetIndex()->setCellValue("A{$i}", "Total   {$qtd}");
						$objPHPExcel->setActiveSheetIndex()->setCellValue("D{$i}", "-");
						$objPHPExcel->setActiveSheetIndex()->setCellValue("E{$i}", "-");
						$objPHPExcel->getActiveSheet()->getStyle("F{$i}")->getNumberFormat()->setFormatCode('R$ #,##0.00');
						$objPHPExcel->setActiveSheetIndex()->setCellValue("F{$i}", "=SUBTOTAL(9,F{$in}:F{$ate})",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->getActiveSheet()->getStyle("G{$i}")->getNumberFormat()->setFormatCode('R$ #,##0.00');
						$objPHPExcel->setActiveSheetIndex()->setCellValue("G{$i}", "=SUBTOTAL(9,G{$in}:G{$ate})",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->getActiveSheet()->getStyle("H{$i}")->getNumberFormat()->setFormatCode('00%');
						$objPHPExcel->setActiveSheetIndex()->setCellValue("H{$i}", "=IF(F{$i}<>0,G{$i}/F{$i},0)");
						$objPHPExcel->getActiveSheet()->getStyle("I{$i}")->getNumberFormat()->setFormatCode('R$ #,##0.00');
						$objPHPExcel->setActiveSheetIndex()->setCellValue("I{$i}", "=SUBTOTAL(9,I{$in}:I{$ate})",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->getActiveSheet()->getStyle("J{$i}")->getNumberFormat()->setFormatCode('00%');
						$objPHPExcel->setActiveSheetIndex()->setCellValue("J{$i}", "=IF(G{$i}<>0,I{$i}/G{$i},0)");
						$i = $i + 1;
						$objPHPExcel->getActiveSheet()->mergeCells("A{$i}:J{$i}");
					}
					$i = $i + 1;
					$cf = "=SUM(";
					$cg = "=SUM(";
					$ci = "=SUM(";
					foreach ($arraytot as $rs){
						$cf .= "F{$rs}+";
						$cft .= "F{$rs}+";
						$cg .= "G{$rs}+";
						$cgt .= "G{$rs}+";
						$ci .= "I{$rs}+";
						$cit .= "I{$rs}+";
					}
					$cf = substr($cf,0,-1).")";
					$cg = substr($cg,0,-1).")";
					$ci = substr($ci,0,-1).")";
					
					$objPHPExcel->getActiveSheet()->mergeCells("A{$i}:C{$i}");
					$objPHPExcel->getActiveSheet()->getStyle("A{$i}:J{$i}")->getFont()->setSize(12)->setName('Courier New')->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle("A{$i}:C{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
					$objPHPExcel->getActiveSheet()->getStyle("D{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
					$objPHPExcel->getActiveSheet()->getStyle("E{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
					$objPHPExcel->getActiveSheet()->getStyle("F{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
					$objPHPExcel->getActiveSheet()->getStyle("G{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
					$objPHPExcel->getActiveSheet()->getStyle("H{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
					$objPHPExcel->getActiveSheet()->getStyle("I{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
					$objPHPExcel->getActiveSheet()->getStyle("J{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
					$objPHPExcel->setActiveSheetIndex()->setCellValue("A{$i}", "Total dos Processos Terceiros   {$qtdtot}");
					$objPHPExcel->setActiveSheetIndex()->setCellValue("D{$i}", "-");
					$objPHPExcel->setActiveSheetIndex()->setCellValue("E{$i}", "-");
					$objPHPExcel->getActiveSheet()->getStyle("F{$i}")->getNumberFormat()->setFormatCode('R$ #,##0.00');
					$objPHPExcel->setActiveSheetIndex()->setCellValue("F{$i}", "{$cf}",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->getActiveSheet()->getStyle("G{$i}")->getNumberFormat()->setFormatCode('R$ #,##0.00');
					$objPHPExcel->setActiveSheetIndex()->setCellValue("G{$i}", "{$cg}",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->getActiveSheet()->getStyle("H{$i}")->getNumberFormat()->setFormatCode('00%');
					$objPHPExcel->setActiveSheetIndex()->setCellValue("H{$i}", "=IF(F{$i}<>0,G{$i}/F{$i},0)");
					$objPHPExcel->getActiveSheet()->getStyle("I{$i}")->getNumberFormat()->setFormatCode('R$ #,##0.00');
					$objPHPExcel->setActiveSheetIndex()->setCellValue("I{$i}", "{$ci}",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->getActiveSheet()->getStyle("J{$i}")->getNumberFormat()->setFormatCode('00%');
					$objPHPExcel->setActiveSheetIndex()->setCellValue("J{$i}", "=IF(G{$i}<>0,I{$i}/G{$i},0)");
					
					$qtdtotproc = $qtdtotproc + $qtdtot;
					$i = $i + 1;
					$cf = "=SUM({$cft}";
					$cg = "=SUM({$cgt}";
					$ci = "=SUM({$cit}";
					$cf = substr($cf,0,-1).")";
					$cg = substr($cg,0,-1).")";
					$ci = substr($ci,0,-1).")";
					
					$objPHPExcel->getActiveSheet()->mergeCells("A{$i}:C{$i}");
					$objPHPExcel->getActiveSheet()->getStyle("A{$i}:J{$i}")->getFont()->setSize(12)->setName('Courier New')->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle("A{$i}:C{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
					$objPHPExcel->getActiveSheet()->getStyle("D{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
					$objPHPExcel->getActiveSheet()->getStyle("E{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
					$objPHPExcel->getActiveSheet()->getStyle("F{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
					$objPHPExcel->getActiveSheet()->getStyle("G{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
					$objPHPExcel->getActiveSheet()->getStyle("H{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
					$objPHPExcel->getActiveSheet()->getStyle("I{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
					$objPHPExcel->getActiveSheet()->getStyle("J{$i}")->getAlignment()->setVertical(\PHPExcel_Style_Alignment::VERTICAL_CENTER)->setHorizontal(\PHPExcel_Style_Alignment::HORIZONTAL_RIGHT);
					$objPHPExcel->setActiveSheetIndex()->setCellValue("A{$i}", "Total dos Processos   {$qtdtotproc}");
					$objPHPExcel->setActiveSheetIndex()->setCellValue("D{$i}", "-");
					$objPHPExcel->setActiveSheetIndex()->setCellValue("E{$i}", "-");
					$objPHPExcel->getActiveSheet()->getStyle("F{$i}")->getNumberFormat()->setFormatCode('R$ #,##0.00');
					$objPHPExcel->setActiveSheetIndex()->setCellValue("F{$i}", "{$cf}",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->getActiveSheet()->getStyle("G{$i}")->getNumberFormat()->setFormatCode('R$ #,##0.00');
					$objPHPExcel->setActiveSheetIndex()->setCellValue("G{$i}", "{$cg}",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->getActiveSheet()->getStyle("H{$i}")->getNumberFormat()->setFormatCode('00%');
					$objPHPExcel->setActiveSheetIndex()->setCellValue("H{$i}", "=IF(F{$i}<>0,G{$i}/F{$i},0)");
					$objPHPExcel->getActiveSheet()->getStyle("I{$i}")->getNumberFormat()->setFormatCode('R$ #,##0.00');
					$objPHPExcel->setActiveSheetIndex()->setCellValue("I{$i}", "{$ci}",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->getActiveSheet()->getStyle("J{$i}")->getNumberFormat()->setFormatCode('00%');
					$objPHPExcel->setActiveSheetIndex()->setCellValue("J{$i}", "=IF(G{$i}<>0,I{$i}/G{$i},0)");
					
					$objPHPExcel->getActiveSheet()->setTitle( utf8_encode("Custos Com A��es"));
					
					$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
					$nome_arquivo = "ACOES-".date('d-m-Y').".xls";
					header('Content-Type: application/vnd.ms-excel');
					header("Content-Disposition: attachment;filename={$nome_arquivo}");
					header("Pragma: no-cache");
					header("Expires: 0");
					
					ob_end_clean();
					$objWriter->save('php://output');
					
				}elseif ($_SESSION['filtro_dashboard']['dashboard'] == 'pagar'){
					$i = 0;
					$objPHPExcel = new \PHPExcel();
					
					$objPHPExcel->getActiveSheet()->getPageSetup()->setOrientation(\PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
					$objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(\PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
					$objPHPExcel->getActiveSheet()->setShowGridlines(true);
					$objPHPExcel->getActiveSheet()->getPageSetup()->setFitToPage(true);
					$objPHPExcel->getActiveSheet()->getSheetView()->setZoomScale(80);
					
					$objPHPExcel->getActiveSheet()->mergeCells('A1:F1');
					$objPHPExcel->getActiveSheet()->getStyle('A1:F1')->getFont()->setSize(18)->setName('Courier New')->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('A2:F2')->getFont()->setSize(16)->setName('Courier New')->setBold(true);
					
					
					$objPHPExcel->setActiveSheetIndex(0);
					$objPHPExcel->getActiveSheet()->setCellValue("A2", "Empresa" )
					->setCellValue("B2", utf8_encode("N� Processo"))
					->setCellValue("C2", "Reclamante")
					->setCellValue("D2", "Parcela")
					->setCellValue("E2", "Valor")
					->setCellValue("F2", "Vencimento" );
					
					$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(70);
					$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(43);
					$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(60);
					$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(17);
					$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(25);
					$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(20);
					
					$gdImage = imagecreatefromjpeg($_SERVER["DOCUMENT_ROOT"] . "/sismonaco/content/geral/img/logomonacom.jpg");
					$objDrawing = new \PHPExcel_Worksheet_MemoryDrawing();
					$objDrawing->setName('Monaco');
					$objDrawing->setDescription('Logo Monaco');
					$objDrawing->setImageResource($gdImage);
					$objDrawing->setRenderingFunction(\PHPExcel_Worksheet_MemoryDrawing::RENDERING_JPEG);
					$objDrawing->setMimeType(\PHPExcel_Worksheet_MemoryDrawing::MIMETYPE_JPEG);
					$objDrawing->setCoordinates('A1');
					$objDrawing->setOffsetX(2);
					$objDrawing->setOffsetY(2);
					$objDrawing->setResizeProportional(false);
					$objDrawing->setWidth(25);
					$objDrawing->setHeight(20);
					$objDrawing->setWorksheet($objPHPExcel->getActiveSheet());
					
					$objPHPExcel->setActiveSheetIndex()->setCellValue('A1', utf8_encode("   Grupo M�naco - Parcelas a Pagar No Per�odo De {$_SESSION['filtro_dashboard']['de']} At� {$_SESSION['filtro_dashboard']['ate']}") );
					$i = 2;
					$in = 2;
					$ate = 0;
					$parcelas = array();
					foreach ($this->dados['dashboard'] as $rs){
						$i = $i + 1;
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, utf8_encode("".ucfirst(strtolower($rs->EMPRESA)).""));
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $funcoes->mask($rs->N_PROCESSO,'#######-##.####.#.##.####'));
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, utf8_encode("".ucfirst(strtolower($rs->RECLAMANTE)).""));
						@$parcelas[$rs->PROCESSO] = @$parcelas[$rs->PROCESSO] + 1;
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, ($rs->PARCELA + $parcelas[$rs->PROCESSO])."/".$rs->N_PARCELA);
						$objPHPExcel->getActiveSheet()->getStyle("E{$i}")->getNumberFormat()->setFormatCode('R$ #,##0.00');
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->VAL_PARCELA,\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->DTA_VENCIMENTO);
					}
					$ate = $i;
					$i = $i+1;
					$objPHPExcel->setActiveSheetIndex()->setCellValue("A{$i}", "Total");
					$objPHPExcel->getActiveSheet()->getStyle("E{$i}")->getNumberFormat()->setFormatCode('R$ #,##0.00');
					$objPHPExcel->setActiveSheetIndex()->setCellValue("E{$i}", "=SUBTOTAL(9,E{$in}:E{$ate})",\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->getActiveSheet()->getStyle("A3:F{$i}")->getFont()->setSize(14)->setName('Courier New');
					$objPHPExcel->getActiveSheet()->getStyle("A{$i}:F{$i}")->getFont()->setSize(16)->setBold(true);
					
					$objPHPExcel->getActiveSheet()->setTitle( utf8_encode("Parcelas a Pagar"));
					
					$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5');
					$nome_arquivo = "PARCELAS-".date('d-m-Y').".xls";
					header('Content-Type: application/vnd.ms-excel');
					header("Content-Disposition: attachment;filename={$nome_arquivo}");
					header("Pragma: no-cache");
					header("Expires: 0");
					
					ob_end_clean();
					$objWriter->save('php://output');
				}
			}
		}
		if (isset($_SESSION['filtro_dashboard']['dashboard'])){
			$_SESSION['filtro_dashboard'] = array('empresa' =>  $_SESSION['filtro_dashboard']['empresa'], 'natureza' =>  $_SESSION['filtro_dashboard']['natureza'], 'departamento' =>  $_SESSION['filtro_dashboard']['departamento'], 'dashboard' =>  $_SESSION['filtro_dashboard']['dashboard'], 'de' =>  $_SESSION['filtro_dashboard']['de'], 'ate' =>  $_SESSION['filtro_dashboard']['ate']);
			$this->dados = $_SESSION['consulta_dashboard'];
		}
		$this->view();
	}
}