<?php

namespace controller\gpj;

use lib\Controller;
use helper\Security;
use api\gpj\apiNatureza;
use api\gpj\apiConsultor;
use helper\Paginator;
use obj\gpj\Consultor;
use obj\geral\Log;
use api\geral\apiLog;

class consultorController extends Controller {
	
	public function __construct() {
		
		parent::__construct();
		
		new Security($this->getModule(),$this->getController(),$this->getAction());
	}
	
	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Lista de Consultors";
		$apiConsultor = new apiConsultor();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-4"])){
			$apiNatureza = new apiNatureza();
			$nat = $apiNatureza->filtroNatureza('1', '3', 'ativo', '1');
			foreach ($nat as $rs){
				$this->natureza[$rs->NATUREZA] = array('natureza' => $rs->NATUREZA, 'des_natureza' => $rs->DES_NATUREZA);
			}
			$apiConsultor = new apiConsultor();
			$this->consultor = $apiConsultor->filtroConsultor('1', 'tudo', 'c.consultor', $_SESSION['usuario_sessao']);
		}else{
			$apiConsultor = new apiConsultor();
			$this->consultor = $apiConsultor->filtroConsultor('1', 'tudo', 'c.consultor', $_SESSION['usuario_sessao']);
			foreach ($this->consultor as $rs){
				$this->natureza[$rs->NATUREZA] = array('natureza' => $rs->NATUREZA, 'des_natureza' => $rs->DES_NATUREZA);
			}
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$busca = array(
				'1' => array('c' => '2','n' => $_POST['natureza'],'coluna' => 'u.nome', 'valor' => @$_POST['busca_valor']),
				'2' => array('c' => '3','n' => $_POST['natureza'],'coluna' => "",'valor' => "")
			);
			if(isset($busca[$_POST['busca']])){
				$this->dados = array('consultor' => $apiConsultor->filtroConsultor($busca[$_POST['busca']]['c'], $busca[$_POST['busca']]['n'], $busca[$_POST['busca']]['coluna'], $busca[$_POST['busca']]['valor']));
				$_SESSION['filtro_sessao'] = array('c' => $busca[$_POST['busca']]['c'], 'n' => $busca[$_POST['busca']]['n'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'busca_valor' => $busca[$_POST['busca']]['valor'], 'busca' => $_POST['busca']);
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'gpj/index/index/acessonegado');
				die();
			}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				$this->dados = array('consultor' => $apiConsultor->filtroConsultor($_SESSION['filtro_sessao']['c'],$_SESSION['filtro_sessao']['n'],$_SESSION['filtro_sessao']['coluna'], $_SESSION['filtro_sessao']['busca_valor']));
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('consultor' => $apiConsultor->filtroConsultor('1','tudo','c.natureza', @$this->natureza[$this->consultor[0]->NATUREZA]['natureza']));
					$_SESSION['filtro_sessao'] = array('c' => '1', 'n' => @$this->natureza[$this->consultor[0]->NATUREZA]['natureza'], 'coluna' => 'c.natureza' , 'busca_valor' => @$this->natureza[$this->consultor[0]->NATUREZA]['natureza'], 'busca' => '2');
					$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}
		}
		$TotalItem = (is_array($this->dados['consultor']) ? count($this->dados['consultor']) : 0);
		$this->dados['consultor'] = array_chunk($this->dados['consultor'], $ItemPorPagina);
		@$this->dados['consultor'] = $this->dados['consultor'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->view();
	}
	
	public function adicionar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Cadastro de Consultor";
		$apiConsultor = new apiConsultor();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-4"])){
			$apiNatureza = new apiNatureza();
			$nat = $apiNatureza->filtroNatureza('1', '3', 'ativo', '1');
			foreach ($nat as $rs){
				$this->natureza[$rs->NATUREZA] = array('natureza' => $rs->NATUREZA, 'des_natureza' => $rs->DES_NATUREZA);
			}
		}else{
			$apiConsultor = new apiConsultor();
			$this->consultor = $apiConsultor->filtroConsultor('1', 'tudo', 'c.consultor', $_SESSION['usuario_sessao']);
			if ((is_array($this->consultor) ? count($this->consultor) : 0) == 0){
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'gpj/index/index/acessonegado');
				die();
			}else{
				foreach ($this->consultor as $rs){
					$this->natureza[$rs->NATUREZA] = array('natureza' => $rs->NATUREZA, 'des_natureza' => $rs->DES_NATUREZA);
				}
			}
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$Post = new Consultor('POST');
			$exp = explode("-", $_POST['consultor']);
			$Post->consultor = $exp[0];
			$apiConsultor = new apiConsultor();
			$rs = $apiConsultor->filtroConsultor('1','3','c.consultor',$Post->consultor);
			if ((is_array($rs) ? count($rs) : 0) > 0){
				$this->rollback = new Consultor('POST');
				if (isset($_POST['natureza'])){
					foreach ($_POST['natureza'] as $rs){
						$this->natureza_rollback[$rs] = $rs;
					}
				}
				$this->Alert = "Esse consultor j� est� cadastrado!";
			}else{
				
				$historico = "CONSULTOR||{$Post->consultor};;";
				foreach ($_POST['natureza'] as $rs) {
					$Post->natureza = $rs;
					$historico .= "NATUREZA||{$Post->natureza};;";
					$sql[$i] = $apiConsultor->addConsultor($Post);
					$i = $i+1;
				}
				$log = new Log();
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico .= substr($historico,0,-2);
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiConsultor->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'gpj/consultor/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'gpj/consultor/index/sucesso');
					}
				}else{
					$this->rollback = new Consultor('POST');
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		
		$this->view();
	}
	
	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Altera��o de Consultor";
		$exp = explode(",", $this->getParams(0));
		$consultor = new Consultor();
		$consultor->consultor = $exp[0];
		$consultor->natureza = $exp[1];
		$apiConsultor = new apiConsultor();
		$this->dados = array('consultor' => $apiConsultor->getConsultor($consultor));
		if (!isset($this->dados['consultor'])){	
			header('location:' .APP_ROOT. 'gpj/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-4"])){
			$apiNatureza = new apiNatureza();
			$natureza = $apiNatureza->filtroNatureza('1', '3', 'ativo', '1');
			foreach ($natureza as $rs){
				$this->natureza[$rs->NATUREZA] = array('natureza' => $rs->NATUREZA, 'des_natureza' => $rs->DES_NATUREZA);
			}
		}else{
			$apiConsultor = new apiConsultor();
			$this->consultor = $apiConsultor->filtroConsultor('1', 'tudo', 'c.consultor', $_SESSION['usuario_sessao']);
			if ((is_array($this->consultor) ? count($this->consultor) : 0) == 0){
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'gpj/index/index/acessonegado');
				die();
			}else{
				foreach ($this->consultor as $rs){
					$this->natureza[$rs->NATUREZA] = array('natureza' => $rs->NATUREZA, 'des_natureza' => $rs->DES_NATUREZA);
				}
			}
		}
		$nat = $apiConsultor->filtroConsultor('1', 'tudo', 'c.consultor', $consultor->consultor);
		foreach ($nat as $rs){
			$this->natureza_consultor[$rs->NATUREZA] = true;
		}	
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			if ((is_array($nat) ? count($nat) : 0) > 0 || (is_array($_POST['natureza']) ? count($_POST['natureza']) : 0) > 0 ){
				$postnatureza = array();
				foreach ($_POST['natureza'] as $rs) {
					$postnatureza[$rs] = true;
				}
				$consultornatureza = new Consultor();
				$consultornatureza->consultor = $consultor->consultor;
				$historico = "CONSULTOR||{$Post->consultor};;";
				foreach ($this->natureza as $rs){
					if (isset($postnatureza[$rs['natureza']])){
						if (@$this->natureza_consultor[$rs['natureza']] == NULL){
							$consultornatureza->natureza = $rs['natureza'];
							$historico .= "NATUREZAI||".$rs['natureza'].";;";
							$sql[$i] = $apiConsultor->addConsultor($consultornatureza);
							$i = $i+1;
						}
					}elseif (!isset($postnatureza[$rs['natureza']])){
						if (@$this->natureza_consultor[$rs['natureza']] != NULL){
							$consultornatureza->natureza = $rs['natureza'];
							$historico .= "NATUREZAD||".$rs['natureza'].";;";
							$sql[$i] = $apiConsultor->delConsultor($consultornatureza);
							$i = $i+1;
						}
					}
				}
			}
			$log = new Log();
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "A";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico .= substr($historico,0,-2);
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiConsultor->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'gpj/consultor/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'gpj/consultor/index/sucesso');
				}
			}else{
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		
		}
		$this->view();
	}
}