<?php

namespace controller\gpj;

use lib\Controller;
use helper\Security;
use api\gpj\apiCidade;
use helper\Paginator;
use obj\gpj\Cidade;
use obj\geral\Log;
use api\geral\apiLog;

class cidadeController extends Controller {
	
	public function __construct() {
		
		parent::__construct();
		
		new Security($this->getModule(),$this->getController(),$this->getAction());
	}
	
	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Lista de Cidade";
		$apiCidade = new apiCidade();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		(!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])) ? $a = '1' : $a = '3';
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$busca = array(
					'1' => array('c' => '1','a' => $a,'coluna' => 'ativo', 'valor' => '1'),
					'2' => array('c' => '1','a' => $a,'coluna' => 'ativo', 'valor' => '0'),
					'3' => array('c' => '2','a' => $a,'coluna' => 'des_cidade', 'valor' => @$_POST['busca_valor']),
					'4' => array('c' => '2','a' => $a,'coluna' => 'uf', 'valor' => @$_POST['busca_valor']),
					'5' => array('c' => '3','a' => $a,'coluna' => "",'valor' => "")
			);
			if(isset($busca[$_POST['busca']])){
				$this->dados = array('cidade' => $apiCidade->filtroCidade($busca[$_POST['busca']]['c'], $busca[$_POST['busca']]['a'], $busca[$_POST['busca']]['coluna'], $busca[$_POST['busca']]['valor']));
				$_SESSION['filtro_sessao'] = array('c' => $busca[$_POST['busca']]['c'], 'a' => $busca[$_POST['busca']]['a'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'busca_valor' => $busca[$_POST['busca']]['valor'], 'busca' => $_POST['busca']);
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'gpj/index/index/acessonegado');
				die();
			}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				$this->dados = array('cidade' => $apiCidade->filtroCidade($_SESSION['filtro_sessao']['c'],$_SESSION['filtro_sessao']['a'],$_SESSION['filtro_sessao']['coluna'], $_SESSION['filtro_sessao']['busca_valor']));
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('cidade' => $apiCidade->filtroCidade('1','3','ativo', '1'));
					$_SESSION['filtro_sessao'] = array('c' => '1', 'a' => '3', 'coluna' => 'ativo' , 'busca_valor' => '1', 'busca' => '5');
					$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}
		}
		$TotalItem = (is_array($this->dados['cidade']) ? count($this->dados['cidade']) : 0);
		$this->dados['cidade'] = array_chunk($this->dados['cidade'], $ItemPorPagina);
		@$this->dados['cidade'] = $this->dados['cidade'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->view();
	}
	
	public function adicionar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Cadastro de Cidade";
		$apiCidade = new apiCidade();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$Post = new Cidade('POST');
			$apiCidade = new apiCidade();
			$rs = $apiCidade->filtroCidade('1','3','des_cidade',$Post->des_cidade);
			if ((is_array($rs) ? count($rs) : 0) > 0){
				$this->rollback = new Cidade('POST');
				$this->Alert = "J� existe um cidade com esse nome cadastrado!";
			}else{
				$sql[$i] = $apiCidade->addCidade($Post);
				$i = $i+1;
				$log = new Log();
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico = "DES_CIDADE||{$Post->des_cidade};;ATIVO||{$Post->ativo}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiCidade->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'gpj/cidade/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'gpj/cidade/index/sucesso');
					}
				}else{
					$this->rollback = new Cidade('POST');
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		
		$this->view();
	}
	
	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Altera��o de Cidade";
		$cidade = new Cidade();
		$cidade->cidade = $this->getParams(0);
		$apiCidade = new apiCidade();
		$this->dados = array('cidade' => $apiCidade->getCidade($cidade));
		if (isset($this->dados['cidade'])){
			if ($this->dados['cidade']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'gpj/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'gpj/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$Post = new Cidade('POST');
			$Post->cidade = $this->getParams(0);
			$rs = $apiCidade->filtroCidade('1','3','des_cidade',$Post->des_cidade);
			$log = new Log();
			$log->historico = "DES_CIDADE||{$this->dados['cidade']->DES_CIDADE};;ATIVO||{$this->dados['cidade']->ATIVO}";
			if ((is_array($rs) ? count($rs) : 0) > 0 && ($rs[0]->DES_CIDADE != $this->dados['cidade']->DES_CIDADE)){
				$this->dados['cidade']->DES_CIDADE = $Post->des_cidade;
				$this->dados['cidade']->ATIVO = $Post->ativo;
				$this->Alert = "J� existe um cidade com esse nome cadastrado!";
			}else{
				$sql[$i] = $apiCidade->editCidade($Post);
				$i = $i+1;
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "A";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico .= "::DES_CIDADE||{$Post->des_cidade};;ATIVO||{$Post->ativo}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiCidade->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'gpj/cidade/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'gpj/cidade/index/sucesso');
					}
				}else{
					$this->dados['cidade']->DES_CIDADE = $Post->des_cidade;
					$this->dados['cidade']->ATIVO = $Post->ativo;
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		$this->view();
	}
	public function excluir() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Exclus�o de Cidade";
		$cidade = new Cidade();
		$cidade->cidade = $this->getParams(0);
		$apiCidade = new apiCidade();
		$this->dados = array('cidade' => $apiCidade->getCidade($cidade));
		if (isset($this->dados['cidade'])){
			if ($this->dados['cidade']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'gpj/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'gpj/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$sql[$i] = $apiCidade->delCidade($cidade);
			$i = $i+1;
			$log = new Log();
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "E";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico = "CIDADE||{$this->dados['cidade']->CIDADE};;DES_CIDADE||{$this->dados['cidade']->DES_CIDADE};;UF||{$this->dados['cidade']->UF};;ATIVO||{$this->dados['cidade']->ATIVO}";
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiCidade->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'gpj/cidade/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'gpj/cidade/index/sucesso');
				}
			}else{
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}
		$this->view();
	}
}