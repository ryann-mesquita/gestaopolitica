<?php

namespace controller\sie;

use lib\Controller;
use helper\Security;

use api\sie\apiPassagem;
use helper\Paginator;
use obj\sie\Passagem;
use obj\sie\Taxa;
use obj\geral\Log;
use api\geral\apiLog;
use api\geral\apiEmpresa;
use api\adm\apiCargo;
use helper\Funcoes;
use api\adm\apiDepartamento;
use obj\geral\Empresa;
use obj\adm\Usuario;
use api\adm\apiUsuario;

include 'classes/PHPExcel.php';

class passagemController extends Controller {

	public function __construct() {

		parent::__construct();

		new Security($this->getModule(),$this->getController(),$this->getAction());
	}

	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Lista de Passagens";
		$apiPassagem =  new apiPassagem();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		$apiEmpresa = new apiEmpresa();
		$this->empresa = $apiEmpresa->filtroEmpresa('1','3','ativo', '1');
		$apiDepartamento = new apiDepartamento();
		$this->departamento = $apiDepartamento->filtroDepartamento('3', '1','','');
		(!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])) ? $a = '1' : $a = '3';
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			if ($_POST['submeter'] == "consultar"){
			$busca = array(
				'1' => array('c' => '1','a' => $a,'coluna' => '', 'valor' => ''),
				'2' => array('c' => '1','a' => $a,'coluna' => '', 'valor' => ''),
				'3' => array('c' => '2','a' => $a,'coluna' => 'passagem', 'valor' => @$_POST['busca_valor']),
				'4' => array('c' => '1','a' => $a,'coluna' => 'usuario', 'valor' => @$_POST['busca_valor']),
				'5' => array('c' => '2','a' => $a,'coluna' => 'origem', 'valor' => @$_POST['busca_valor']),
				'6' => array('c' => '2','a' => $a,'coluna' => 'destino', 'valor' => @$_POST['busca_valor']),
				'7' => array('c' => '4','a' => $a,'coluna' => 'ida', 'valor' => @$_POST['busca_valor'], 'de' => @$_POST['busca_de'], 'ate' => @$_POST['busca_ate']),
				'8' => array('c' => '4','a' => $a,'coluna' => 'volta', 'valor' => @$_POST['busca_valor'], 'de' => @$_POST['busca_de'], 'ate' => @$_POST['busca_ate']),
				'9' => array('c' => '2','a' => $a,'coluna' => 'companhia', 'valor' => @$_POST['busca_valor']),
				'10' => array('c' => '1','a' => $a,'coluna' => 'empresa', 'valor' => @$_POST['busca_valor']),
				'11' => array('c' => '2','a' => $a,'coluna' => 'pagamento', 'valor' => @$_POST['busca_valor']),
				'12' => array('c' => '1','a' => $a,'coluna' => 'departamento', 'valor' => @$_POST['busca_valor']),
				'13' => array('c' => '4','a' => $a,'coluna' => 'dta_emissao', 'valor' => @$_POST['busca_valor'], 'de' => @$_POST['busca_de'], 'ate' => @$_POST['busca_ate']),
				'14' => array('c' => '3','a' => $a,'coluna' => "",'valor' => "")
			);
			if(isset($busca[$_POST['busca']])){
				$this->dados = array('passagem' => $apiPassagem->filtroPassagem($busca[$_POST['busca']]['c'], $busca[$_POST['busca']]['a'], $busca[$_POST['busca']]['coluna'], $busca[$_POST['busca']]['valor'], @$busca[$_POST['busca']]['de'],@$busca[$_POST['busca']]['ate']));
				$_SESSION['filtro_sessao'] = array('c' => $busca[$_POST['busca']]['c'], 'a' => $busca[$_POST['busca']]['a'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'busca_valor' => $busca[$_POST['busca']]['valor'],'de' => isset($_POST['busca_de']) ? $_POST['busca_de'] : "", 'ate' => isset($_POST['busca_ate']) ? $_POST['busca_ate'] : "",'busca' => $_POST['busca']);
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'sie/index/index/acessonegado');
				die();
			}
		}elseif($_POST['submeter'] == "imprimir"){
			$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			//	var_dump($_SESSION['filtro_sessao']);die();
			$this->dados = array('passagem' => $apiPassagem->filtroPassagem($_SESSION['filtro_sessao']['c'], $_SESSION['filtro_sessao']['a'], $_SESSION['filtro_sessao']['coluna'],$_SESSION['filtro_sessao']['busca_valor'], @$_SESSION['filtro_sessao']['de'],@$_SESSION['filtro_sessao']['ate']));
		//	var_dump($this->dados);die();
			$i = 0;
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getPageSetup()->setOrientation(\PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
			$objPHPExcel->getActiveSheet()->getPageSetup()->setPaperSize(\PHPExcel_Worksheet_PageSetup::PAPERSIZE_A4);
			$objPHPExcel->getActiveSheet()->setShowGridlines(true);
			$objPHPExcel->getActiveSheet()->getPageSetup()->setFitToPage(true);
			$objPHPExcel->getActiveSheet()->getSheetView()->setZoomScale(80);
			
			$objPHPExcel->getActiveSheet()->mergeCells('A1:O1');
			$objPHPExcel->getActiveSheet()->getStyle('A1:O1')->getFont()->setSize(18)->setName('Courier New')->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('A2:O2')->getFont()->setSize(16)->setName('Courier New')->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0);
			$objPHPExcel->getActiveSheet()->setCellValue("A2", "Passagem" )
			->setCellValue("B2", utf8_encode("Usu�rio" ))
			->setCellValue("C2", "Origem")
			->setCellValue("D2", "Destino")
			->setCellValue("E2", "Ida")
			->setCellValue("F2",  "Volta")
			->setCellValue("G2", "Companhia")
			->setCellValue("H2", "Empresa")
			->setCellValue("I2", "Departamento")
			->setCellValue("J2", "Cargo")
			->setCellValue("K2", utf8_encode("Data de Emiss�o"))
			->setCellValue("L2", "Valor")
			->setCellValue("M2", "Total")
			->setCellValue("N2", "Motivo")
			->setCellValue("O2", "Pagamento");
			
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(50);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(27);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(27);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(18);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(18);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(59);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(28);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(52);
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(28);
			$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(28);
			$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(25);
			$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(70);
			$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(25);
			
			$gdImage = imagecreatefromjpeg($_SERVER["DOCUMENT_ROOT"] . "/sismonaco/content/geral/img/logomonacom.jpg");
			$objDrawing = new \PHPExcel_Worksheet_MemoryDrawing();
			$objDrawing->setName('Monaco');
			$objDrawing->setDescription('Logo Monaco');
			$objDrawing->setImageResource($gdImage);
			$objDrawing->setRenderingFunction(\PHPExcel_Worksheet_MemoryDrawing::RENDERING_JPEG);
			$objDrawing->setMimeType(\PHPExcel_Worksheet_MemoryDrawing::MIMETYPE_JPEG);
			$objDrawing->setCoordinates('A1');
			$objDrawing->setOffsetX(2);
			$objDrawing->setOffsetY(2);
			$objDrawing->setResizeProportional(false);
			$objDrawing->setWidth(25);
			$objDrawing->setHeight(20);
			$objDrawing->setWorksheet($objPHPExcel->getActiveSheet());
			
			$objPHPExcel->setActiveSheetIndex()->setCellValue('A1', utf8_encode("   Gerenciamento de Passagem"));
			$i = 2;
			
			foreach ($this->dados['passagem'] as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->PASSAGEM);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, utf8_encode("".ucfirst(strtolower($rs->USUARIO_NOME)).""));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, utf8_encode("".ucfirst(strtolower($rs->ORIGEM)).""));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, utf8_encode("".ucfirst(strtolower($rs->DESTINO)).""));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->IDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->VOLTA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, utf8_encode("".ucfirst(strtolower($rs->COMPANHIA)).""));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, utf8_encode("".ucfirst(strtolower($rs->DES_EMPRESA)).""));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, utf8_encode("".ucfirst(strtolower($rs->DES_DEPARTAMENTO)).""));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, utf8_encode("".ucfirst(strtolower($rs->DES_CARGO)).""));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, $rs->DTA_EMISSAO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $i, $rs->VALOR);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $i, $rs->TOTAL);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $i, $rs->MOTIVO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $i, $rs->PAGAMENTO);
			}
			
			$objPHPExcel->getActiveSheet()->getStyle("A3:O{$i}")->getFont()->setSize(14)->setName('Courier New');
			
			$objPHPExcel->getActiveSheet()->setTitle( utf8_encode("Passagem"));
			
			$nome_arquivo = "PASSAGEM-".date('d-m-Y').".xlsx";
			header('Content-Type: application/vnd.ms-excel');
			header("Content-Disposition: attachment;filename={$nome_arquivo}");
			header("Pragma: no-cache");
			header("Expires: 0");
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			ob_end_clean();
			$objWriter->save('php://output');
			exit;
			
		}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				$this->dados = array('passagem' => $apiPassagem->filtroPassagem($_SESSION['filtro_sessao']['c'],$_SESSION['filtro_sessao']['a'],$_SESSION['filtro_sessao']['coluna'], $_SESSION['filtro_sessao']['busca_valor'], $_SESSION['filtro_sessao']['de'], $_SESSION['filtro_sessao']['ate']));
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('passagem' => $apiPassagem->filtroPassagem('3','1','', ''));
					$_SESSION['filtro_sessao'] = array('c' => '3', 'a' => '1', 'coluna' => 'passagem' , 'busca_valor' => '', 'de' => "", 'ate' => "", 'busca' => '12');
					$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}
		}
		@$TotalItem = (is_array($this->dados['passagem']) ? count($this->dados['passagem']) : 0);
		@$this->dados['passagem'] = array_chunk($this->dados['passagem'], $ItemPorPagina);
		@$this->dados['passagem'] = $this->dados['passagem'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->view();
	}
	public function adicionar(){
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Cadastro de Passagem";
		$apiEmpresa = new apiEmpresa();
		$this->empresa = $apiEmpresa->filtroEmpresa('3', '1','','');
		
		$apiDepartamento = new apiDepartamento();
		$this->departamento = $apiDepartamento->filtroDepartamento('3', '1','','');
		
		$apiCargo = new apiCargo();
		$this->cargo = $apiCargo->filtroCargo('3', '1','','');
		
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$Post = new Passagem('POST');
			$funcoes = new Funcoes();
			$apiPassagem = new apiPassagem();
			$rs = $apiPassagem->filtroPassagem('1','3','passagem',$Post->passagem);
		   if ((is_array($rs) ? count($rs) : 0) > 0){
				$this->rollback = new Passagem('POST');
				$this->Alert = "J� existe uma Passagem com esse identificador cadastrado!";
			}else{
				$exp = explode(".", $_FILES['anexo']['name']);
				$exp = end($exp);
				$Post->valor = $funcoes->sanearValor($Post->valor);	
				$Post->total = $funcoes->sanearValor($Post->valor);
				$Post->origem = strtoupper($funcoes->retiraAcentos(trim($Post->origem)));
				$Post->destino = strtoupper($funcoes->retiraAcentos(trim($Post->destino)));
				$Post->companhia = strtoupper($funcoes->retiraAcentos(trim($Post->companhia)));
				$Post->motivo = strtoupper($funcoes->retiraAcentos(trim($Post->motivo)));
				$Post->pagamento = strtoupper($funcoes->retiraAcentos(trim($Post->pagamento)));
				if(!empty($exp)){
					$Post->anexo = "{$Post->passagem}-{$Post->usuario}-".date('dmY-His').".{$exp}";
				}else{
					$Post->anexo = "";
				}
				
				
				$sql[$i] = $apiPassagem->addPassagem($Post);
				$i = $i+1;
				$log = new Log();
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico = "PASSAGEM||{$Post->passagem};;USUARIO||{$Post->usuario};;ORIGEM||{$Post->origem};;DESTINO||{$Post->destino};;COMPANHIA||{$Post->companhia};;IDA||{$Post->ida};;VOLTA||{$Post->volta};;TOTAL||{$Post->total}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiPassagem->executeSQL($sql);
			//  var_dump($rs);die();
				if (@$rs[4] == 'sucesso') {
					if(!empty($exp)){
						move_uploaded_file($_FILES['anexo']['tmp_name'], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/".$Post->anexo);
					}
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'sie/passagem/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'sie/passagem/index/sucesso');
					}
				}else{
					$this->rollback = new Passagem('POST');
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		
		$this->view();
	}
	
	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Altera��o de Passagem";
		$passagem = new Passagem();
		$this->getParams(0);
		$passagem->passagem = $this->getParams(0);
		$apiPassagem = new apiPassagem();
		$this->dados = array('passagem' => $apiPassagem->getPassagem($passagem));
		$this->totaltaxa = $apiPassagem->getTaxaValor($passagem);
		$this->totaltaxa['0']->TOTAL;
		$this->taxa = $apiPassagem->getTaxa($passagem);
		$apiEmpresa = new apiEmpresa();
		$this->empresa = $apiEmpresa->filtroEmpresa('3', '1','','');
		$apiDepartamento = new apiDepartamento();
		$this->departamento = $apiDepartamento->filtroDepartamento('3', '1','','');
		$apiCargo = new apiCargo();
		$this->cargo = $apiCargo->filtroCargo('3', '1','','');
	//	var_dump($this->dados);die();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$anterior = "";
			$atual = "::";
			$funcoes = new Funcoes();
			$sql = array();
			$Post = new Passagem();
			$Post->passagem = $this->getParams(0);
			$rs = $apiPassagem->filtroPassagem('1','3','passagem',$Post->passagem);
			$log = new Log();
			
		if (isset($_POST['submeter']) && $_POST['submeter'] == "alterar"){
			if ((is_array($rs) ? count($rs) : 0) > 0 && ($rs[0]->PASSAGEM != $this->dados['passagem']->PASSAGEM)){
				$this->dados['passagem']->PASSAGEM = $_POST['passagem'];
				$this->Alert = "J� existe uma Passagem com esse Identificador!";
			}else{
				if ($this->dados['passagem']->PASSAGEM != $_POST['passagem']){
					$Post->passagem = $_POST['passagem'];
					$anterior .= "PASSAGEM||{$this->dados['passagem']->PASSAGEM};;";
					$atual .= "PASSAGEM||{$Post->passagem};;";
				}
			//	var_dump($Post->passagem);die();
				if ($this->dados['passagem']->USUARIO != $_POST['usuario']){
					$Post->usuario = $_POST['usuario'];
					$anterior .= "USUARIO||{$this->dados['passagem']->USUARIO};;";
					$atual .= "USUARIO||{$Post->usuario};;";
				}
			    $origem = strtoupper($funcoes->retiraAcentos(trim($_POST['origem'])));
				if ($this->dados['passagem']->ORIGEM != $origem){
					$Post->origem = $origem;
					$anterior .= "ORIGEM||{$this->dados['passagem']->ORIGEM};;";
					$atual .= "ORIGEM||{$Post->origem};;";
				}
			    $destino = strtoupper($funcoes->retiraAcentos(trim($_POST['destino'])));
				if ($this->dados['passagem']->DESTINO != $destino){
					$Post->destino = $destino;
					$anterior .= "DESTINO||{$this->dados['passagem']->DESTINO};;";
					$atual .= "DESTINO||{$Post->destino};;";
				}
				if ($this->dados['passagem']->IDA != $_POST['ida']){
					$Post->ida = $_POST['ida'];
					$anterior .= "IDA||{$this->dados['passagem']->IDA};;";
					$atual .= "IDA||{$Post->ida};;";
				}
				if ($this->dados['passagem']->VOLTA != $_POST['volta']){
					$Post->volta = $_POST['volta'];
					$anterior .= "VOLTA||{$this->dados['volta']->VOLTA};;";
					$atual .= "VOLTA||{$Post->volta};;";
				}
				if ($this->dados['passagem']->VOLTA != $_POST['volta']){
					$Post->volta = $_POST['volta'];
					$anterior .= "VOLTA||{$this->dados['volta']->VOLTA};;";
					$atual .= "VOLTA||{$Post->volta};;";
				}
			    $companhia = strtoupper($funcoes->retiraAcentos(trim($_POST['companhia'])));
				if ($this->dados['passagem']->COMPANHIA != $companhia){
					$Post->companhia = $companhia;
					$anterior .= "COMPANHIA||{$this->dados['passagem']->COMPANHIA};;";
					$atual .= "COMPANHIA||{$Post->companhia};;";
				}
				if ($this->dados['passagem']->EMPRESA != $_POST['empresa']){
					$Post->empresa = $_POST['empresa'];
					$anterior .= "EMPRESA||{$this->dados['passagem']->EMPRESA};;";
					$atual .= "EMPRESA||{$Post->empresa};;";
				}
				if ($this->dados['passagem']->DEPARTAMENTO != $_POST['departamento']){
					$Post->departamento = $_POST['departamento'];
					$anterior .= "DEPARTAMENTO||{$this->dados['passagem']->DEPARTAMENTO};;";
					$atual .= "DEPARTAMENTO||{$Post->departamento};;";
				}
				if ($this->dados['passagem']->CARGO != $_POST['cargo']){
					$Post->cargo = $_POST['cargo'];
					$anterior .= "CARGO||{$this->dados['passagem']->CARGO};;";
					$atual .= "CARGO||{$Post->cargo};;";
				}
				if ($this->dados['passagem']->DTA_EMISSAO != $_POST['dta_emissao']){
					$Post->dta_emissao = $_POST['dta_emissao'];
					$anterior .= "DTA_EMISSAO||{$this->dados['passagem']->DTA_EMISSAO};;";
					$atual .= "DTA_EMISSAO||{$Post->dta_emissao};;";
				}
				if ($this->dados['passagem']->VALOR != $_POST['valor']){
					$Post->valor = $funcoes->sanearValor($_POST['valor']);
					$Post->total = $funcoes->sanearValor($Post->valor) + $funcoes->sanearValor($this->totaltaxa['0']->TOTAL);
					$anterior .= "VALOR||{$this->dados['passagem']->VALOR};;";
					$atual .= "VALOR||{$Post->valor};;";
				}
			    $motivo = strtoupper($funcoes->retiraAcentos(trim($_POST['motivo'])));
				if ($this->dados['passagem']->MOTIVO != $motivo){
					$Post->motivo = $motivo;
					$anterior .= "MOTIVO||{$this->dados['passagem']->MOTIVO};;";
					$atual .= "MOTIVO||{$Post->motivo};;";
				}
			    $pagamento = strtoupper($funcoes->retiraAcentos(trim($_POST['pagamento'])));
				if ($this->dados['passagem']->PAGAMENTO != $pagamento){
					$Post->pagamento = $pagamento;
					$anterior .= "PAGAMENTO||{$this->dados['passagem']->PAGAMENTO};;";
					$atual .= "PAGAMENTO||{$Post->pagamento};;";
				}

				if ($apiPassagem->editPassagem($Post) != ""){
					$sql[$i] = $apiPassagem->editPassagem($Post);
					$i = $i+1;
					$log->usuario = $_SESSION['usuario_sessao'];
					$log->modulo = $this->getModule()['modulo'];
					$log->controle = $this->getController()['controle'];
					$log->acao = $this->getAction()['acao'];
					$log->empresa = $_SESSION['empresa_sessao'];
					$log->tipo = "A";
					$log->dta_registro = date("d/m/Y H:i:s");
					$log->historico = substr($anterior,0,-2);
					$log->historico .= substr($atual,0,-2);
					$apiLog = new apiLog();
					$sql[$i] = $apiLog->addLog($log);
					$rs = $apiPassagem->executeSQL($sql);
					if (@$rs[4] == 'sucesso') {
						if (isset($this->PaginaAtual)) {
							header('location:' .APP_ROOT. 'sie/passagem/index/pagina/'.$this->PaginaAtual.'/sucesso');
						}else {
							header('location:' .APP_ROOT. 'sie/passagem/index/sucesso');
						}
					}else{
						$this->dados['passagem']->PASSAGEM = $_POST['passagem'];
						$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
						$erro = str_replace($retirar, "", $rs[2]);
						$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
					}
				}else{
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'sie/passagem/index/pagina/'.$this->PaginaAtual.'/insucesso');
					}else {
						header('location:' .APP_ROOT. 'sie/passagem/index/insucesso');
					}
				}
			}
		}elseif (isset($_POST['taxa_submeter']) && $_POST['taxa_submeter'] == "adicionar"){
		//	 var_dump($this->dados['passagem']->TOTAL);die();
			$Post_taxa = new Taxa();
			$Post_taxa->passagem = $this->getParams(0);
			$Post_taxa->des_taxa = $_POST['des_taxa'];
			$Post_taxa->valor = $funcoes->sanearValor($_POST['valor']);
			@$valortotal = $funcoes->sanearValor($_POST['valor']) + $funcoes->sanearValor($this->dados['passagem']->TOTAL);
			$passagem->total = @$valortotal;
			$sql[$i] = $apiPassagem->addTaxa($Post_taxa);
			$i= $i+1;
			$sql[$i] = $apiPassagem->valorTotalPassagem($passagem);
			$i=$i+1;
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "I";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico = "PASSAGEM||{$Post_taxa->passagem};;TAXA||{$Post_taxa->taxa};;VALOR||{$Post_taxa->valor}}";
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiPassagem->executeSQL($sql);
			if(@$rs[4] == 'sucesso'){
				header('location:' .APP_ROOT. 'sie/passagem/alterar/'.$this->dados['passagem']->PASSAGEM.'/sucesso');
			}else{
				$this->rollback = new Taxa();
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";	
			}
		}
		}
		$this->view();
	}
	public function excluir() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Exclus�o de Passagem";
		$passagem = new Passagem();
		$passagem->passagem = $this->getParams(0);
		$apiPassagem = new apiPassagem();
		$this->dados = array('passagem' => $apiPassagem->getPassagem($passagem));
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$sql[$i] = $apiPassagem->delPassagem($passagem);
			$i = $i+1;
			$log = new Log();
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "E";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico = "PASSAGEM||{$this->dados['passagem']->PASSAGEM};;USUARIO||{$this->dados['passagem']->PASSAGEM};;ORIGEM||{$this->dados['passagem']->ORIGEM};;DESTINO||{$this->dados['passagem']->DESTINO};;COMPANHIA||{$this->dados['passagem']->COMPANHIA};;IDA||{$this->dados['passagem']->IDA};;VOLTA||{$this->dados['passagem']->VOLTA};;TOTAL||{$this->dados['passagem']->TOTAL}";
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiPassagem->executeSQL($sql);
		//	var_dump($rs);die();
			if (@$rs[4] == 'sucesso') {
			 	unlink($_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/".$this->dados['passagem']->ANEXO);
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'sie/passagem/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'sie/passagem/index/sucesso');
				}
			}else{
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}
		$this->view();
	}
	
	public function visualizar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Gr�fico de Passagens";
		$empresa_filtro = new Empresa();
		$usuario_filtro = new Usuario();
		$apiEmpresa = new apiEmpresa();
		$apiUsuario = new apiUsuario();
		$this->empresa = $apiEmpresa->filtroEmpresa('3', '1','','');
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {		
			$usuario = $_POST['usuario'];
			$empresa = $_POST['empresa'];
			$ano = $_POST['ano'];
			
			$empresa_filtro->empresa = $empresa;
			$this->empresa_filtro = $apiEmpresa->getEmpresa($empresa_filtro);
		
			$usuario_filtro->usuario = $usuario;
			$this->usuario_filtro = $apiUsuario->getUsuario($usuario_filtro);
			$this->ano = $ano;

		$apiPassagem = new apiPassagem();
		$this->dados = array('grafico' => $apiPassagem->getGrafico($ano, $empresa, $usuario));
		$this->total = array('total' => $apiPassagem->getGraficoTotal($ano, $empresa, $usuario));
		$this->taxa = array('grafico2' => $apiPassagem->getGraficoTaxa($ano, $empresa, $usuario));
		$this->taxaTotal= array('taxaTotal' => $apiPassagem->getGraficoTaxaTotal($ano, $empresa, $usuario));

		}
		
		$this->view();
	}
	
	
}
	