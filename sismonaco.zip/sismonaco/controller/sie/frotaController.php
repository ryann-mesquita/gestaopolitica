<?php

namespace controller\sie;

use lib\Controller;
use helper\Security;
use api\sie\apiFrota;
use api\adm\apiDepartamento;
use api\geral\apiEmpresa;
use helper\Paginator;
use obj\sie\Frota;
use obj\sie\Revisao;
use obj\geral\Empresa;
use obj\geral\Log;
use api\geral\apiLog;
use helper\Funcoes;
use obj\sie\Infracao;

class frotaController extends Controller {

	public function __construct() {

		parent::__construct();

		new Security($this->getModule(),$this->getController(),$this->getAction());
	}

	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Lista de Frotas";
		$apiFrota=  new apiFrota();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		$apiEmpresa = new apiEmpresa();
		$this->empresa = $apiEmpresa->filtroEmpresa('1','3','ativo', '1');
		//var_dump($this->empresa);die();
		(!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])) ? $a = '1' : $a = '3';
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$busca = array(
				'1' => array('c'  => '1','a' => $a,'coluna'  => 'ativo', 'valor'  => '1'),
				'2' => array('c'  => '1','a' => $a,'coluna'  => 'ativo', 'valor'  => '0'),
				'3' => array('c'  => '1','a' => '2','coluna'  => 'veiculo', 'valor'  => @$_POST['busca_valor']),
				'4' => array('c'  => '1','a' => '3','coluna'  => 'placa', 'valor'  => @$_POST['busca_valor']),
				'5' => array('c'  => '1','a' => '2','coluna'  => 'chassi', 'valor' => @$_POST['busca_valor']),		
				'6' => array('c'  => '1','a' => '7','coluna'  => 'marca', 'valor'  => @$_POST['busca_valor']),		
				'7' => array('c'  => '1','a' => '5','coluna'  => 'modelo', 'valor' => @$_POST['busca_valor']),		
				'8' => array('c'  => '1','a' => '3','coluna'  => 'renavam', 'valor'=> @$_POST['busca_valor']),		
				'9' => array('c'  => '1','a' => '5','coluna'  => 'cor', 'valor'    => @$_POST['busca_valor']),		
				'10' => array('c' => '1','a' => '6','coluna'  => 'licenciamento', 'valor' => @$_POST['busca_valor'], 'de' => @$_POST['busca_de'], 'ate' => @$_POST['busca_ate']),		
				'11' => array('c' => '1','a' => '7','coluna'  => 'categoria', 'valor' => @$_POST['busca_valor']),		
				'12' => array('c' => '1','a' => '8','coluna'  => 'cnpj', 'valor' => @$_POST['busca_valor']),		
				'13' => array('c' => '1','a' => '5','coluna'  => 'localizacao', 'valor' => @$_POST['busca_valor']),		
				'14' => array('c' => '1','a' => "4",'coluna' => "",'valor' => "")
			);
		   // var_dump($busca[$_POST['busca']]);die();
			if(isset($busca[$_POST['busca']])){
				$this->dados = array('frota' => $apiFrota->filtroFrota($busca[$_POST['busca']]['c'], $busca[$_POST['busca']]['a'], $busca[$_POST['busca']]['coluna'], $busca[$_POST['busca']]['valor'],  @$busca[$_POST['busca']]['de'],@$busca[$_POST['busca']]['ate']));
				$_SESSION['filtro_sessao'] = array('c' => $busca[$_POST['busca']]['c'], 'a' => $busca[$_POST['busca']]['a'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'busca_valor' => $busca[$_POST['busca']]['valor'], 'de' => isset($_POST['busca_de']) ? $_POST['busca_de'] : "", 'ate' => isset($_POST['busca_ate']) ? $_POST['busca_ate'] : "", 'busca' => $_POST['busca']);
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
		
			}else{
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'sie/index/index/acessonegado');
				die();
			}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				$this->dados = array('frota' => $apiFrota->filtroFrota($_SESSION['filtro_sessao']['c'],$_SESSION['filtro_sessao']['a'],$_SESSION['filtro_sessao']['coluna'], $_SESSION['filtro_sessao']['busca_valor'], $_SESSION['filtro_sessao']['de'], $_SESSION['filtro_sessao']['ate']));
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('frota' => $apiFrota->filtroFrota('1','4','', ''));
					$_SESSION['filtro_sessao'] = array('c' => '1', 'a' => '4', 'coluna' => 'ativo' , 'busca_valor' => '1', 'de' => "", 'ate' => "", 'busca' => '4');
					$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}
		}
	//	var_dump($this->dados);die();
		$TotalItem = (is_array($this->dados['frota']) ? count($this->dados['frota']) : 0);
		$this->dados['frota'] = array_chunk($this->dados['frota'], $ItemPorPagina);
		@$this->dados['frota'] = $this->dados['frota'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->view();
	}
	public function adicionar(){
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Cadastro de Frota";
		$apiEmpresa = new apiEmpresa();
		$this->empresa = $apiEmpresa->filtroEmpresa('1','3','ativo', '1');
		$apiFrota = new apiFrota();
		$funcoes = new Funcoes();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$Post = new Frota('POST');
			$apiFrota = new apiFrota();
			$rs = $apiFrota->filtroFrota('1','3','frota',$Post->frota);
			if ((is_array($rs) ? count($rs) : 0) > 0 ){
				$this->rollback = new Frota('POST');
				$this->Alert = "J� existe uma frota com esse nome cadastrado!";
			}else{
				$sql[$i] = $apiFrota->addFrota($Post);
				$i = $i+1;
				$log = new Log();
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico = "PLACA||{$Post->placa};;ATIVO||{$Post->ativo}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				/*
				$descricao = $_POST["des_item"];
				foreach($descricao as $key => $des){
					$i = $i+1;
					$aqui= strtoupper($funcoes->retiraAcentos(trim($des)));
					var_dump($aqui);die();
				}
				var_dump($descricao);die();
				*/
				$rs = $apiFrota->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'sie/frota/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'sie/frota/index/sucesso');
					}
				}else{
					$this->rollback = new Frota('POST');
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		
		$this->view();
	}
	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Altera��o de Frota";
		$frota = new Frota();
		$this->getParams(0);
		$frota->frota = $this->getParams(0);	
		$apiEmpresa = new apiEmpresa();
		$this->empresa = $apiEmpresa->filtroEmpresa('1','3','ativo', '1');
		$apiFrota = new apiFrota();
		$this->infracao =  $apiFrota->getInfracao($frota);
		$this->dados = array('frota' => $apiFrota->getFrota($frota));
		$this->revisao = $apiFrota->getRevisao($frota);
		$apiDepartamento = new apiDepartamento();
		$this->departamento  = $apiDepartamento->filtroDepartamento("1","3","d.ativo","1");
		//var_dump($this->revisao);die();
		
		
	/*	
		if (isset($this->dados['frota'])){
			if ($this->dados['frota']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'sie/index/index/acessonegado');
					die();
				}
			}
		}else{   
			header('location:' .APP_ROOT. 'sie/index/index/acessonegado');
			die();
		}
	*/
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$anterior = "";
			$atual = "::";
			$funcoes = new Funcoes();
			$sql = array();
			$Post = new Frota();
			$Post->frota = $this->getParams(0);
		
			$rs = $apiFrota->filtroFrota('1','2','veiculo',$Post->frota);
			$log = new Log();
		//	var_dump($frota);die();
		if (isset($_POST['submeter']) && $_POST['submeter'] == "alterar"){
				if(empty($this->dados['frota']->FROTA)){
					$sql[$i]=$apiFrota->addFrota($frota);
					$i = $i+1;
				}elseif ($this->dados['frota']->FROTA == $frota->frota){
					$Post->frota = $this->dados['frota']->FROTA;
				}
				
				if ($this->dados['frota']->LICENCIAMENTO != $_POST['licenciamento']){
					$Post->licenciamento = $_POST['licenciamento'];
					$anterior .= "LICENCIAMENTO||{$this->dados['frota']->LICENCIAMENTO};;";
					$atual .= "LICENCIAMENTO||{$Post->licenciamento};;";
				}
				if ($this->dados['frota']->MARCA != $_POST['marca']){
					$Post->marca = $Post->marca = strtoupper($funcoes->retiraAcentos( $_POST['marca']));
				//	var_dump($Post->marca);die();
					$anterior .= "MARCA||{$this->dados['frota']->MARCA};;";
					$atual .= "MARCA||{$Post->marca};;";
				}
				$categoria = strtoupper($funcoes->retiraAcentos(trim($_POST['categoria'])));
				if ($this->dados['frota']->CATEGORIA != $categoria){
					$Post->categoria = $categoria;
					$anterior .= "CATEGORIA||{$this->dados['frota']->CATEGORIA};;";
					$atual .= "CATEGORIA||{$Post->categoria};;";
				}
				$obs = strtoupper($funcoes->retiraAcentos(trim($_POST['obs'])));
				if ($this->dados['frota']->OBS != $obs){
					$Post->obs = $obs;
					$anterior .= "OBS||{$this->dados['frota']->OBS};;";
					$atual .= "OBS||{$Post->obs};;";
				}
				if ($apiFrota->editFrota($Post) != ""){
					$sql[$i] = $apiFrota->editFrota($Post);
					$i = $i+1;
					$log->usuario = $_SESSION['usuario_sessao'];
					$log->modulo = $this->getModule()['modulo'];
					$log->controle = $this->getController()['controle'];
					$log->acao = $this->getAction()['acao'];
					$log->empresa = $_SESSION['empresa_sessao'];
					$log->tipo = "A";
					$log->dta_registro = date("d/m/Y H:i:s");
					$log->historico = substr($anterior,0,-2);
					$log->historico .= substr($atual,0,-2);
					$apiLog = new apiLog();
					$sql[$i] = $apiLog->addLog($log);
					$rs = $apiFrota->executeSQL($sql);
				//	var_dump($rs);die();
					if (@$rs[4] == 'sucesso') {
						if (isset($this->PaginaAtual)) {
							header('location:' .APP_ROOT. 'sie/frota/index/pagina/'.$this->PaginaAtual.'/sucesso');
						}else {
							header('location:' .APP_ROOT. 'sie/frota/index/sucesso');
						}
					}else{
						
						$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
						$erro = str_replace($retirar, "", $rs[2]);
						$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
					}
				}else{
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'sie/frota/index/pagina/'.$this->PaginaAtual.'/insucesso');
					}else {
						header('location:' .APP_ROOT. 'sie/frota/index/insucesso');
					}
				}
			
			}elseif (isset($_POST['infracao_submeter']) && $_POST['infracao_submeter'] == "confirmar"){
				$funcoes = new Funcoes();
				$Post_infracao = new Infracao();
			//	var_dump($_FILES['anexo']['name']);die();
				$exp = explode(".", $_FILES['anexo']['name']);
				$exp = end($exp);
				$Post_infracao->veiculo = $this->getParams(0);
				$Post_infracao->infracao = $_POST['infracao'];
				$Post_infracao->des_infracao = $_POST['des_infracao'];
				$Post_infracao->departamento = $_POST['departamento'];
				$Post_infracao->valor = $funcoes->sanearValor($_POST['valor']);
				$Post_infracao->dta_infracao = $_POST['dta_infracao'];
				$Post_infracao->hora_infracao = $_POST['hora_infracao'];
				$Post_infracao->dta_cadastro = date("d/m/Y");
				$Post_infracao->usuario = $_SESSION['usuario_sessao'];
				$Post_infracao->autor = $_POST['autor'];
				$Post_infracao->situacao = $_POST['situacao'];
				$Post_infracao->status = $_POST['status'];
			//	var_dump($Post_infracao->anexo);die();
				if(!empty($exp)){
				$Post_infracao->anexo = "{$Post_infracao->veiculo}-{$Post_infracao->infracao}-".date('dmY-His').".{$exp}";
				}else{
					$Post_infracao->anexo = "";
				}
				$sql[$i] = $apiFrota->addInfracao($Post_infracao);
				$i= $i+1;
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico = "VEICULO||{$Post_infracao->veiculo};;INFRACAO||{$Post_infracao->infracao};;DES_INFRACAO||{$Post_infracao->des_infracao};;DEPARTAMENTO||{$Post_infracao->departamento};; VALOR||{$Post_infracao->valor};;DTA_INFRACAO||{$Post_infracao->dta_infracao}}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiFrota->executeSQL($sql);
				
			//	var_dump($_FILES['anexo']['tmp_name']);die();
				if (@$rs[4] == 'sucesso'){
					if(!empty($exp)){
					move_uploaded_file($_FILES['anexo']['tmp_name'], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/".$Post_infracao->anexo);
					}
					header('location:' .APP_ROOT. 'sie/frota/alterar/'.$this->dados['frota']->VEICULO.'/sucesso');
				}else{
					$this->rollback = new Infracao();
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";	
				}
			}elseif (isset($_POST['revisao_submeter']) && $_POST['revisao_submeter'] == "revisao"){
				$funcoes = new Funcoes();
				$Post_revisao = new Revisao();
			//	$this->departamento  = $apiDepartamento->filtroDepartamento("1","3","d.ativo","1");
			//	var_dump($this->departamento);die();
				$exp = explode(".", $_FILES['anexo']['name']);
				$exp = end($exp);
				$Post_revisao->veiculo = $this->getParams(0);
				$Post_revisao->responsavel = $_POST['responsavel'];
				$Post_revisao->departamento = $_POST['departamento'];
				$Post_revisao->kilometragem = $_POST['kilometragem'];
				$Post_revisao->dta_revisao = $_POST['dta_revisao'];
				$Post_revisao->valor = $funcoes->sanearValor($_POST['valor']);
				$Post_revisao->anexo = "";
				$Post_revisao->des_revisao = $_POST['des_revisao'];
				if(!empty($exp)){
					$Post_revisao->anexo = "{$Post_revisao->veiculo}-{$Post_revisao->kilometragem}-".date('dmY-His').".{$exp}";
				}else{
					$Post_revisao->anexo = "";
				}
				$sql[$i] = $apiFrota->addRevisao($Post_revisao);
				$i= $i+1;
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico = "VEICULO||{$Post_revisao->veiculo};;RESPONSAVEL||{$Post_revisao->responsavel};;DEPARTAMENTO||{$Post_revisao->departamento};;KILOMETRAGEM ||{$Post_revisao->kilometragem};; VALOR||{$Post_revisao->valor};;DTA_REVISAO||{$Post_revisao->dta_revisao};;ATRASO||{$Post_revisao->atraso};;DES_REVISAO||{$Post_revisao->des_revisao}}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiFrota->executeSQL($sql);
				if (@$rs[4] == 'sucesso'){
					if(!empty($exp)){
						move_uploaded_file($_FILES['anexo']['tmp_name'], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/".$Post_revisao->anexo);
					}
					header('location:' .APP_ROOT. 'sie/frota/alterar/'.$this->dados['frota']->VEICULO.'/sucesso');
				}else{
					$this->rollback = new Revisao();
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		$this->view();
	}
	public function excluir() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Exclus�o de Frota";
		$frota= new Frota();
		$frota->frota = $this->getParams(0);
		$apiFrota = new apiFrota();
		$this->dados = array('frota' => $apiFrota->getFrota($frota));
		if (isset($this->dados['frota'])){
			if ($this->dados['frota']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'sie/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'sie/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$sql[$i] = $apiFrota->delFrota($frota);
			$i = $i+1;
			$log = new Log();
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "E";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico = "FROTA||{$this->dados['frota']->FROTA};;PLACA||{$this->dados['frota']->PLACA};;aTIVO||{$this->dados['frota']->ATIVO}";
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiFrota->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'sie/frota/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'sie/frota/index/sucesso');
				}
			}else{
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}
		$this->view();
	}
	
	
	
}