<?php

namespace controller\bi;

use lib\Controller;
use helper\Security;
use api\bi\apiRelatorio;
use helper\Paginator;
use obj\bi\Relatorio;
use obj\geral\Log;
use api\geral\apiLog;
use helper\Funcoes;

class relatorioController extends Controller {
	
	public function __construct() {
		
		parent::__construct();
		
		new Security($this->getModule(),$this->getController(),$this->getAction());
	}
	
	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Lista de Relatorios";
		$apiRelatorio = new apiRelatorio();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		(!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])) ? $a = '1' : $a = '3';
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$busca = array(
				'1' => array('c' => '1','a' => $a,'coluna' => 'ativo', 'valor' => '1'),
				'2' => array('c' => '1','a' => $a,'coluna' => 'ativo', 'valor' => '0'),
				'3' => array('c' => '2','a' => $a,'coluna' => 'des_reduzida', 'valor' => @$_POST['busca_valor']),
				'4' => array('c' => '2','a' => $a,'coluna' => 'des_relatorio', 'valor' => @$_POST['busca_valor']),
				'5' => array('c' => '3','a' => '3','coluna' => "",'valor' => "")
			);
			if(isset($busca[$_POST['busca']])){
				$this->dados = array('relatorio' => $apiRelatorio->filtroRelatorio($busca[$_POST['busca']]['c'], $busca[$_POST['busca']]['a'], $busca[$_POST['busca']]['coluna'], $busca[$_POST['busca']]['valor']));
				$_SESSION['filtro_sessao'] = array('c' => $busca[$_POST['busca']]['c'], 'a' => $busca[$_POST['busca']]['a'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'valor' => $busca[$_POST['busca']]['valor'], 'busca' => $_POST['busca']);
				$_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'bi/index/index/acessonegado');
				die();
			}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				$this->dados = array('relatorio' => $apiRelatorio->filtroRelatorio($_SESSION['filtro_sessao']['c'],$_SESSION['filtro_sessao']['a'],$_SESSION['filtro_sessao']['coluna'],$_SESSION['filtro_sessao']['valor']));
				$_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('relatorio' => $apiRelatorio->filtroRelatorio('3','3','ativo', '1'));
					$_SESSION['filtro_sessao'] = array('c' => '3', 'a' => '3','coluna' => 'ativo' , 'valor' => '1', 'busca_valor' => '1', 'de' => "", 'ate' => "", 'busca' => '');
					$_SESSION['consulta_sessao'][$_SESSION['empresa_sessao'].$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}
		}
		$TotalItem = (is_array($this->dados['relatorio']) ? count($this->dados['relatorio']) : 0);
		@$this->dados['relatorio'] = array_chunk($this->dados['relatorio'], $ItemPorPagina);
		@$this->dados['relatorio'] = $this->dados['relatorio'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->view();
	}
	
	public function adicionar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Cadastro de Relatorios";
		$apiRelatorio = new apiRelatorio();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$Post = new Relatorio('POST');
			$apiRelatorio = new apiRelatorio();
			$rs = $apiRelatorio->filtroRelatorio('1','3','des_reduzida',$Post->des_reduzida);
			if ((is_array($rs) ? count($rs) : 0) > 0){
				$this->rollback = new Relatorio('POST');
				$this->Alert = "J� existe um relatorio com esse nome cadastrado!";
			}else{
				$sql[$i] = $apiRelatorio->addRelatorio($Post);
				$i = $i+1;
				$log = new Log();
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico = "DES_RELATORIO;DES_RELATORIO;ATIVO|{$Post->des_reduzida};{$Post->des_relatorio};{$Post->ativo}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiRelatorio->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'bi/relatorio/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'bi/relatorio/index/sucesso');
					}
				}else{
					$this->rollback = new Relatorio('POST');
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		
		$this->view();
	}
	
	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Altera��o de Relat�rio";
		$relatorio = new Relatorio();
		$relatorio->relatorio = $this->getParams(0);
		$apiRelatorio = new apiRelatorio();
		$this->dados = array('relatorio' => $apiRelatorio->getRelatorio($relatorio));
		if (isset($this->dados['relatorio'])){
			if ($this->dados['relatorio']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'bi/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'bi/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$anterior = "";
			$atual = "::";
			$sql = array();
			$Post = new Relatorio('POST');
			$Post->relatorio = $this->getParams(0);
			$funcoes = new Funcoes();
			$rs = $apiRelatorio->filtroRelatorio('1','3','des_relatorio',$Post->des_relatorio);
			$log = new Log();
			$log->historico = "DES_REDUZIDA;DES_RELATORIO;ATIVO|{$this->dados['relatorio']->DES_REDUZIDA};{$this->dados['relatorio']->DES_RELATORIO};{$this->dados['relatorio']->ATIVO}";
			if ((is_array($rs) ? count($rs) : 0) > 0 && ($rs[0]->DES_REDUZIDA != $this->dados['relatorio']->DES_REDUZIDA)){
				$this->dados['relatorio']->DES_REDUZIDA = $Post->des_reduzida;
				$this->dados['relatorio']->DES_RELATORIO = $Post->des_relatorio;
				$this->dados['relatorio']->ATIVO = $Post->ativo;
				$this->Alert = "J� existe um relatorio com esse nome cadastrado!";
			}else{
				$des_reduzida = strtoupper($funcoes->retiraAcentos(trim($_POST['des_reduzida'])));
				if ($this->dados['relatorio']->DES_REDUZIDA != $des_reduzida){
					$Post->des_reduzida = $des_reduzida;
					$anterior .= "DES_REDUZIDA|{$this->dados['relatorio']->DES_REDUZIDA};;";
					$atual .= "DES_REDUZIDA||{$Post->des_reduzida};;";
				}
				$des_relatorio = strtoupper($funcoes->retiraAcentos(trim($_POST['des_relatorio'])));
				if ($this->dados['relatorio']->DES_RELATORIO != $des_relatorio){
					$Post->des_relatorio = $des_relatorio;
					$anterior .= "DES_RELATORIO|{$this->dados['relatorio']->DES_RELATORIO};;";
					$atual .= "DES_RELATORIO||{$Post->des_relatorio};;";
				}
				if ($this->dados['relatorio']->ATIVO != $_POST['ativo']){
					$Post->ativo = $_POST['ativo'];
					$anterior .= "ATIVO||{$this->dados['relatorio']->ATIVO};;";
					$atual .= "ATIVO||{$Post->ativo};;";
				}
				$sql[$i] = $apiRelatorio->editRelatorio($Post);
				$i = $i+1;
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "A";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico .= ":DES_REDUZIDA;DES_RELATORIO;ATIVO|{$Post->des_reduzida};{$Post->des_relatorio};{$Post->ativo}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiRelatorio->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'bi/relatorio/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'bi/relatorio/index/sucesso');
					}
				}else{
					$this->dados['relatorio']->DES_REDUZIDA = $Post->des_reduzida;
					$this->dados['relatorio']->DES_RELATORIO = $Post->des_relatorio;
					$this->dados['relatorio']->ATIVO = $Post->ativo;
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		$this->view();
	}
	public function excluir() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Exclus�o de Relat�rio";
		$relatorio = new Relatorio();
		$relatorio->relatorio = $this->getParams(0);
		$apiRelatorio = new apiRelatorio();
		$this->dados = array('relatorio' => $apiRelatorio->getRelatorio($relatorio));
		if (isset($this->dados['relatorio'])){
			if ($this->dados['relatorio']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'dev/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'bi/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$sql[$i] = $apiRelatorio->delRelatorio($relatorio);
			$i = $i+1;
			$log = new Log();
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "E";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico = "RELATORIO;DES_REDUZIDA;DES_RELATORIO;ATIVO|{$this->dados['relatorio']->RELATORIO};{$this->dados['relatorio']->DES_RELATORIO};{$this->dados['relatorio']->DES_RELATORIO};{$this->dados['relatorio']->ATIVO}";
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiRelatorio->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'bi/relatorio/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'bi/relatorio/index/sucesso');
				}
			}else{
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}
		$this->view();
	}
}