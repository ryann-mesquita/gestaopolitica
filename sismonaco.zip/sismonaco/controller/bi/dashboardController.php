<?php

namespace controller\bi;

use lib\Controller;
use helper\Paginator;
use helper\Security;

use api\bi\apiDashboard;

class dashboardController extends Controller {

	public function __construct() {

		parent::__construct();

		new Security($this->getModule(),$this->getController(),$this->getAction());
	}

	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Dashboard";
		$apiDashboard =  new apiDashboard();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		(!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])) ? $a = '1' : $a = '3';
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$busca = array(
					'1' => array('c' => '1','a' => $a,'coluna' => 'empresa', 'valor' => @$_POST['busca_valor']),
					'2' => array('c' => '1','a' => $a,'coluna' => 'revenda', 'valor' => @$_POST['busca_valor']),
					'3' => array('c' => '1','a' => $a,'coluna' => 'cliente', 'valor' => @$_POST['busca_valor']),

			);
			if(isset($busca[$_POST['busca']])){
				$this->dados = array('dashboard' => $apiDashboard->filtroDashboard($busca[$_POST['busca']]['c'], $busca[$_POST['busca']]['a'], $busca[$_POST['busca']]['coluna'], $busca[$_POST['busca']]['valor']));
				$_SESSION['filtro_sessao'] = array('c' => $busca[$_POST['busca']]['c'], 'a' => $busca[$_POST['busca']]['a'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'busca_valor' => $busca[$_POST['busca']]['valor'],'de' => isset($_POST['busca_de']) ? $_POST['busca_de'] : "", 'ate' => isset($_POST['busca_ate']) ? $_POST['busca_ate'] : "",'busca' => $_POST['busca']);
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			//	var_dump($_SESSION['filtro_sessao']);die();
			}else{
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'bi/index/index/acessonegado');
				die();
			}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				$this->dados = array('dashboard' => $apiDashboard->filtroDashboard($_SESSION['filtro_sessao']['c'],$_SESSION['filtro_sessao']['a'],$_SESSION['filtro_sessao']['coluna'], $_SESSION['filtro_sessao']['busca_valor']));
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('dashboard' => $apiDashboard->filtroDashboard('1','3','cliente', ''));
					$_SESSION['filtro_sessao'] = array('c' => '1', 'a' => '3', 'coluna' => 'cliente' , 'busca_valor' => '', 'busca' => '');
					$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}
		}
	//	var_dump($this->dados);die();
		$TotalItem = (is_array($this->dados['dashboard']) ? count($this->dados['dashboard']) : 0);
		$this->dados['dashboard'] = array_chunk($this->dados['dashboard'], $ItemPorPagina);
		@$this->dados['dashboard'] = $this->dados['dashboard'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->view();
	}
		
	}