<?php

namespace controller\finan;

use lib\Controller;
use helper\Security;
use api\finan\apiTipo;
use helper\Paginator;
use obj\finan\Tipo;
use obj\geral\Log;
use api\geral\apiLog;

class tipoController extends Controller {

	public function __construct() {

		parent::__construct();

		new Security($this->getModule(),$this->getController(),$this->getAction());
	}

	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Lista de Tipo";
		$apiTipo = new apiTipo();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		(!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])) ? $a = '1' : $a = '3';
		unset($_SESSION['aba_finan_sessao']);
		unset($_SESSION['aba_pagina_sessao']);
		$_SESSION['aba_finan_sessao'] = 'adiantamento';
		$_SESSION['aba_pagina_sessao']['ad'] = 1;
		$_SESSION['aba_pagina_sessao']['re'] = 1;
		$_SESSION['aba_pagina_sessao']['pr'] = 1;
		$_SESSION['aba_pagina_sessao']['in'] = 1;
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$busca = array(
				'1' => array('c' => '1','a' => $a,'coluna' => 'ativo', 'valor' => '1'),
				'2' => array('c' => '1','a' => $a,'coluna' => 'ativo', 'valor' => '0'),
				'3' => array('c' => '2','a' => $a,'coluna' => 'des_tipo', 'valor' => @$_POST['busca_valor']),
				'4' => array('c' => '3','a' => $a,'coluna' => "",'valor' => "")
			);
			if(isset($busca[$_POST['busca']])){
				$this->dados = array('tipo' => $apiTipo->filtroTipo($busca[$_POST['busca']]['c'], $busca[$_POST['busca']]['a'], $busca[$_POST['busca']]['coluna'], $busca[$_POST['busca']]['valor']));
				$_SESSION['filtro_sessao'] = array('c' => $busca[$_POST['busca']]['c'], 'a' => $busca[$_POST['busca']]['a'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'valor' => $busca[$_POST['busca']]['valor'], 'busca' => $_POST['busca'], 'busca_valor' => isset($_POST['busca_valor']) ? $_POST['busca_valor'] : "");
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'finan/index/index/acessonegado');
				die();
			}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				$this->dados = array('tipo' => $apiTipo->filtroTipo($_SESSION['filtro_sessao']['c'],$_SESSION['filtro_sessao']['a'],$_SESSION['filtro_sessao']['coluna'], $_SESSION['filtro_sessao']['valor']));
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('tipo' => $apiTipo->filtroTipo('1','3','ativo', '1'));
					$_SESSION['filtro_sessao'] = array('c' => '1', 'a' => '3', 'coluna' => 'ativo' , 'valor' => '1', 'busca' => '4', 'busca_valor' => '');
					$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}
		}
		$TotalItem = (is_array($this->dados['tipo']) ? count($this->dados['tipo']) : 0);
		$this->dados['tipo'] = array_chunk($this->dados['tipo'], $ItemPorPagina);
		@$this->dados['tipo'] = $this->dados['tipo'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->view();
	}

	public function adicionar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Cadastro de Tipo";
		$apiTipo = new apiTipo();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		$apiTipofunc = new \api\adm\apiTipo();
		$this->tipos = $apiTipofunc->filtroTipo('1','3','ativo', '1');
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$Post = new Tipo('POST');
			$apiTipo = new apiTipo();
			$rs = $apiTipo->filtroTipo('1','3','des_tipo',$Post->des_tipo);
			if ((is_array($rs) ? count($rs) : 0) > 0){
				$this->rollback = new Tipo('POST');
				$this->Alert = "J� existe um tipo finan esse nome cadastrado!";
			}else{
				$sql[$i] = $apiTipo->addTipo($Post);
				$i = $i+1;
				$log = new Log();
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico = "DES_TIPO||{$Post->des_tipo};;DIAS||{$Post->dias};;ATIVO||{$Post->ativo}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiTipo->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'finan/tipo/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'finan/tipo/index/sucesso');
					}
				}else{
					$this->rollback = new Tipo('POST');
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}

		$this->view();
	}

	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Altera��o de Tipo";
		$tipo = new Tipo();
		$tipo->tipo = $this->getParams(0);
		$apiTipo = new apiTipo();
		$this->dados = array('tipo' => $apiTipo->getTipo($tipo));
		$apiTipofunc = new \api\adm\apiTipo();
		$this->tipos = $apiTipofunc->filtroTipo('1','3','ativo', '1');
		if (isset($this->dados['tipo'])){
			if ($this->dados['tipo']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'finan/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'finan/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$Post = new Tipo('POST');
			$Post->tipo = $this->getParams(0);
			$rs = $apiTipo->filtroTipo('1','3','des_tipo',$Post->des_tipo);
			$log = new Log();
			$log->historico = "TIPO_FUNCIONARIO||{$this->dados['tipo']->TIPO_FUNCIONARIO};;DES_TIPO||{$this->dados['tipo']->DES_TIPO};;DIAS||{$this->dados['tipo']->DIAS};;ATIVO||{$this->dados['tipo']->ATIVO}";
			if ((is_array($rs) ? count($rs) : 0) > 0 && ($rs[0]->DES_TIPO != $this->dados['tipo']->DES_TIPO)){
				$this->dados['tipo']->DES_TIPO = $Post->des_tipo;
				$this->dados['tipo']->TIPO_FUNCIONARIO = $Post->tipo_funcionario;
				$this->dados['tipo']->DIAS = $Post->dias;
				$this->dados['tipo']->ATIVO = $Post->ativo;
				$this->Alert = "J� existe um tipo finan esse nome cadastrado!";
			}else{
				$sql[$i] = $apiTipo->editTipo($Post);
				$i = $i+1;
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "A";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico .= "::TIPO_FUNCIONARIO||{$Post->tipo_funcionario};;DES_TIPO||{$Post->des_tipo};;DIAS||{$Post->dias};;ATIVO||{$Post->ativo}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiTipo->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'finan/tipo/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'finan/tipo/index/sucesso');
					}
				}else{
					$this->dados['tipo']->DES_TIPO = $Post->des_tipo;
					$this->dados['tipo']->TIPO_FUNCIONARIO = $Post->tipo_funcionario;
					$this->dados['tipo']->DIAS = $Post->dias;
					$this->dados['tipo']->ATIVO = $Post->ativo;
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		$this->view();
	}
	public function excluir() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Exclus�o de Tipo";
		$tipo = new Tipo();
		$tipo->tipo = $this->getParams(0);
		$apiTipo = new apiTipo();
		$this->dados = array('tipo' => $apiTipo->getTipo($tipo));
		if (isset($this->dados['tipo'])){
			if ($this->dados['tipo']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'finan/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'finan/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$sql[$i] = $apiTipo->delTipo($tipo);
			$i = $i+1;
			$log = new Log();
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "E";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico = "TIPO||{$this->dados['tipo']->TIPO};;TIPO_FUNCIONARIO||{$this->dados['tipo']->TIPO_FUNCIONARIO};;DES_TIPO||{$this->dados['tipo']->DES_TIPO};;DIAS||{$this->dados['tipo']->DIAS};;ATIVO||{$this->dados['tipo']->ATIVO}";
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiTipo->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'finan/tipo/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'finan/tipo/index/sucesso');
				}
			}else{
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}
		$this->view();
	}
}