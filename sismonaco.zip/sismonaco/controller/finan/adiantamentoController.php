<?php

namespace controller\finan;

use lib\Controller;
use helper\Security;
use api\finan\apiAdiantamento;
use helper\Paginator;
use obj\finan\Adiantamento;
use obj\geral\Log;
use api\geral\apiLog;
use api\geral\apiEmpresa;
use api\finan\apiItem;
use helper\Funcoes;
use obj\finan\Autorizacao;
use obj\finan\Itemadiantamento;
use api\geral\apiApollo;
use api\finan\apiTipo;
use api\adm\apiUsuario;
//use helper\EnvioEmail;
use api\adm\apiPermissao;
use obj\adm\Permissao;
use obj\finan\Inconsistencia;
use obj\adm\Usuario;
use api\finan\apiRgm;

include 'classes/FPDF/html2pdf.php';

class adiantamentoController extends Controller {
	
	public function __construct() {
		
		parent::__construct();
		
		new Security($this->getModule(),$this->getController(),$this->getAction());
	}
	
	public function index() {
		$usuario = new Usuario();
		$apiUsuario = new apiUsuario();
		$apiRgm = new apiRgm();
		$usuario->usuario = $_SESSION['usuario_sessao'];
		$this->usuario = $apiUsuario->getUsuario($usuario);
		$this->rgm_cadastro = $apiRgm->getRgmCadastro($usuario);
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Selecione uma Aba Abaixo.";
		$apiAdiantamento = new apiAdiantamento();
		$PorPagina = 10;
		if ($this->getParams(1) > 0) {
			if ($_SESSION['aba_finan_sessao'] == "adiantamento"){
				$_SESSION['aba_pagina_sessao']['ad'] = $this->getParams(1);
			}elseif ($_SESSION['aba_finan_sessao'] == "reembolso"){
				$_SESSION['aba_pagina_sessao']['re'] = $this->getParams(1);
			}elseif ($_SESSION['aba_finan_sessao'] == "prestacao"){
				$_SESSION['aba_pagina_sessao']['pr'] = $this->getParams(1);
			}elseif ($_SESSION['aba_finan_sessao'] == "inconsistencia"){
				$_SESSION['aba_pagina_sessao']['in'] = $this->getParams(1);
			}
		}
		(!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-2"])) ? $solicitante = $_SESSION['usuario_sessao'] : $solicitante = 'tudo';
		$apiPermissao = new apiPermissao();
		$permissao = new Permissao();
		$permissao->usuario = $_SESSION['usuario_sessao'];
		$permissao->modulo = $this->getModule()['modulo'];
		$permissao->controle = $this->getController()['controle'];
		$permissao->acao = $this->getAction()['acao'];
		$this->empresas = $apiPermissao->permEmpresascontroleacao($permissao);
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			if ($_POST['submeter'] == "consultar_ad"){
				$busca = array(
					'1' => array('situacao' => ($_POST['situacao_ad'] != 6) ? "= {$_POST['situacao_ad']}" : "in (2,3,4,5,6)", 'empresa' => (isset($_POST['empresa_ad']) ? $_POST['empresa_ad'] : array($_SESSION['empresa_sessao'])), 'solicitante' => $solicitante, 'c' => '2', 'coluna' => 'u.nome', 'valor' => @$_POST['busca_valor_ad']),
					'2' => array('situacao' => ($_POST['situacao_ad'] != 6) ? "= {$_POST['situacao_ad']}" : "in (2,3,4,5,6)", 'empresa' => (isset($_POST['empresa_ad']) ? $_POST['empresa_ad'] : array($_SESSION['empresa_sessao'])), 'solicitante' => $solicitante, 'c' => '1', 'coluna' => "ad.adiantamento", 'valor' => @$_POST['busca_valor_ad']),
					'3' => array('situacao' => ($_POST['situacao_ad'] != 6) ? "= {$_POST['situacao_ad']}" : "in (2,3,4,5,6)", 'empresa' => (isset($_POST['empresa_ad']) ? $_POST['empresa_ad'] : array($_SESSION['empresa_sessao'])), 'solicitante' => $solicitante, 'c' => '3', 'coluna' => "", 'valor' => "")
				);
				if(isset($busca[$_POST['busca_ad']])){
					if (isset($_POST['empresa_ad'])){
						$emp = implode(",", $_POST['empresa_ad']);
					}else{
						$emp = $_SESSION['empresa_sessao'];
					}
					$empresa = "in ({$emp})";
					$this->adiantamento = $apiAdiantamento->filtroAdiantamento("= 'A'",$busca[$_POST['busca_ad']]['situacao'], $empresa, $busca[$_POST['busca_ad']]['solicitante'], $busca[$_POST['busca_ad']]['c'], $busca[$_POST['busca_ad']]['coluna'], $busca[$_POST['busca_ad']]['valor']);
					if (isset($_SESSION['consulta_sessao']['re'][$this->getModule()['modulo'].$this->getController()['controle']])){
						$this->reembolso = $_SESSION['consulta_sessao']['re'][$this->getModule()['modulo'].$this->getController()['controle']];
					}
					if (isset($_SESSION['consulta_sessao']['in'][$this->getModule()['modulo'].$this->getController()['controle']])){
						$this->inconsistencia = $_SESSION['consulta_sessao']['in'][$this->getModule()['modulo'].$this->getController()['controle']];
					}
					if (isset($_SESSION['consulta_sessao']['pr'][$this->getModule()['modulo'].$this->getController()['controle']])){
						$this->prestacao = $_SESSION['consulta_sessao']['pr'][$this->getModule()['modulo'].$this->getController()['controle']];
					}
					$_SESSION['filtro_sessao']['ad'] = array('situacao' => $busca[$_POST['busca_ad']]['situacao'], 'empresa' => $busca[$_POST['busca_ad']]['empresa'], 'solicitante' => $busca[$_POST['busca_ad']]['solicitante'], 'c' => $busca[$_POST['busca_ad']]['c'], 'coluna' => $busca[$_POST['busca_ad']]['coluna'], 'busca_valor' => $busca[$_POST['busca_ad']]['valor'], 'busca' => $_POST['busca_ad']);
					$_SESSION['consulta_sessao']['ad'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->adiantamento;
				}else{
					unset($_SESSION['filtro_sessao']['ad']);
					unset($_SESSION['consulta_sessao']['ad']);
					header('location:' .APP_ROOT. 'finan/index/index/acessonegado');
					die();
				}
			}elseif ($_POST['submeter'] == "consultar_re"){
				$busca = array(
					'1' => array('situacao' => "= {$_POST['situacao_re']}", 'empresa' => (isset($_POST['empresa_re']) ? $_POST['empresa_re'] : array($_SESSION['empresa_sessao'])), 'solicitante' => $solicitante, 'c' => '2', 'coluna' => 'u.nome', 'valor' => @$_POST['busca_valor_re']),
					'2' => array('situacao' => "= {$_POST['situacao_re']}", 'empresa' => (isset($_POST['empresa_re']) ? $_POST['empresa_re'] : array($_SESSION['empresa_sessao'])), 'solicitante' => $solicitante, 'c' => '1', 'coluna' => "ad.adiantamento", 'valor' => @$_POST['busca_valor_re']),
					'3' => array('situacao' => "= {$_POST['situacao_re']}", 'empresa' => (isset($_POST['empresa_re']) ? $_POST['empresa_re'] : array($_SESSION['empresa_sessao'])), 'solicitante' => $solicitante, 'c' => '3', 'coluna' => "", 'valor' => "")
				);
				if(isset($busca[$_POST['busca_re']])){
					if (isset($_POST['empresa_re'])){
						$emp = implode(",", $_POST['empresa_re']);
					}else{
						$emp = $_SESSION['empresa_sessao'];
					}
					$empresa = "in ({$emp})";
					$this->reembolso = $apiAdiantamento->filtroAdiantamento("= 'R'",$busca[$_POST['busca_re']]['situacao'], $empresa, $busca[$_POST['busca_re']]['solicitante'], $busca[$_POST['busca_re']]['c'], $busca[$_POST['busca_re']]['coluna'], $busca[$_POST['busca_re']]['valor']);
					if (isset($_SESSION['consulta_sessao']['ad'][$this->getModule()['modulo'].$this->getController()['controle']])){
						$this->adiantamento = $_SESSION['consulta_sessao']['ad'][$this->getModule()['modulo'].$this->getController()['controle']];
					}
					if (isset($_SESSION['consulta_sessao']['in'][$this->getModule()['modulo'].$this->getController()['controle']])){
						$this->inconsistencia = $_SESSION['consulta_sessao']['in'][$this->getModule()['modulo'].$this->getController()['controle']];
					}
					if (isset($_SESSION['consulta_sessao']['pr'][$this->getModule()['modulo'].$this->getController()['controle']])){
						$this->prestacao = $_SESSION['consulta_sessao']['pr'][$this->getModule()['modulo'].$this->getController()['controle']];
					}
					$_SESSION['filtro_sessao']['re'] = array('situacao' => $busca[$_POST['busca_re']]['situacao'], 'empresa' => $busca[$_POST['busca_re']]['empresa'], 'solicitante' => $busca[$_POST['busca_re']]['solicitante'], 'c' => $busca[$_POST['busca_re']]['c'], 'coluna' => $busca[$_POST['busca_re']]['coluna'], 'busca_valor' => $busca[$_POST['busca_re']]['valor'], 'busca' => $_POST['busca_re']);
					$_SESSION['consulta_sessao']['re'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->reembolso;
				}else{
					unset($_SESSION['filtro_sessao']['re']);
					unset($_SESSION['consulta_sessao']['re']);
					header('location:' .APP_ROOT. 'finan/index/index/acessonegado');
					die();
				}
			}elseif ($_POST['submeter'] == "confirma_re"){
				$i = 0;
				$sql = array();
				$adiantamento = new Adiantamento();
				if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-6"])){
					$doc = $_POST["doc_re"];
					foreach ($doc as $rs){
						$adiantamento->adiantamento = $rs;
						$adiantamento->usuario_doc = $_SESSION['usuario_sessao'];
						$adiantamento->dta_doc = date("d/m/Y H:i:s");
						$sql[$i] = $apiAdiantamento->editAdiantamento($adiantamento);
						$i = $i + 1;
					}
				}
				$rs = $apiAdiantamento->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					header('location:' .APP_ROOT. 'finan/adiantamento/index/sucesso');	
				}
			}elseif ($_POST['submeter'] == "consultar_pr"){
				$busca = array(
					'1' => array('situacao' => "= {$_POST['situacao_pr']}", 'empresa' => (isset($_POST['empresa_pr']) ? $_POST['empresa_pr'] : array($_SESSION['empresa_sessao'])), 'solicitante' => $solicitante, 'c' => '2', 'coluna' => 'u.nome', 'valor' => @$_POST['busca_valor_pr']),
					'2' => array('situacao' => "= {$_POST['situacao_pr']}", 'empresa' => (isset($_POST['empresa_pr']) ? $_POST['empresa_pr'] : array($_SESSION['empresa_sessao'])), 'solicitante' => $solicitante, 'c' => '1', 'coluna' => "ad.adiantamento", 'valor' => @$_POST['busca_valor_pr']),
					'3' => array('situacao' => "= {$_POST['situacao_pr']}", 'empresa' => (isset($_POST['empresa_pr']) ? $_POST['empresa_pr'] : array($_SESSION['empresa_sessao'])), 'solicitante' => $solicitante, 'c' => '3', 'coluna' => "", 'valor' => "")
				);
				if(isset($busca[$_POST['busca_pr']])){
					if (isset($_POST['empresa_pr'])){
						$emp = implode(",", $_POST['empresa_pr']);
					}else{
						$emp = $_SESSION['empresa_sessao'];
					}
					$empresa = "in ({$emp})";
					$this->prestacao = $apiAdiantamento->filtroAdiantamento("= 'A'",$busca[$_POST['busca_pr']]['situacao'], $empresa, $busca[$_POST['busca_pr']]['solicitante'], $busca[$_POST['busca_pr']]['c'], $busca[$_POST['busca_pr']]['coluna'], $busca[$_POST['busca_pr']]['valor']);
					if (isset($_SESSION['consulta_sessao']['ad'][$this->getModule()['modulo'].$this->getController()['controle']])){
						$this->adiantamento = $_SESSION['consulta_sessao']['ad'][$this->getModule()['modulo'].$this->getController()['controle']];
					}
					if (isset($_SESSION['consulta_sessao']['re'][$this->getModule()['modulo'].$this->getController()['controle']])){
						$this->reembolso = $_SESSION['consulta_sessao']['re'][$this->getModule()['modulo'].$this->getController()['controle']];
					}
					if (isset($_SESSION['consulta_sessao']['in'][$this->getModule()['modulo'].$this->getController()['controle']])){
						$this->inconsistencia = $_SESSION['consulta_sessao']['in'][$this->getModule()['modulo'].$this->getController()['controle']];
					}
					$_SESSION['filtro_sessao']['pr'] = array('situacao' => $busca[$_POST['busca_pr']]['situacao'], 'empresa' => $busca[$_POST['busca_pr']]['empresa'], 'solicitante' => $busca[$_POST['busca_pr']]['solicitante'], 'c' => $busca[$_POST['busca_pr']]['c'], 'coluna' => $busca[$_POST['busca_pr']]['coluna'], 'busca_valor' => $busca[$_POST['busca_pr']]['valor'], 'busca' => $_POST['busca_pr']);
					$_SESSION['consulta_sessao']['pr'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->prestacao;
				}else{
					unset($_SESSION['filtro_sessao']['pr']);
					unset($_SESSION['consulta_sessao']['pr']);
					header('location:' .APP_ROOT. 'finan/index/index/acessonegado');
					die();
				}
			}elseif ($_POST['submeter'] == "confirma_pr"){
				$i = 0;
				$sql = array();
				$adiantamento = new Adiantamento();
				if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-6"])){
					if (isset($_POST["doc_pr"])){
						$doc = $_POST["doc_pr"];
						foreach ($doc as $rs){
							$adiantamento->adiantamento = $rs;
							$adiantamento->usuario_doc = $_SESSION['usuario_sessao'];
							$adiantamento->dta_doc = date("d/m/Y H:i:s");
							$sql[$i] = $apiAdiantamento->editAdiantamento($adiantamento);
							$i = $i + 1;
						}
					}
				}
				if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-7"])){
					if (isset($_POST["dp_pr"])){
						$dp = $_POST["dp_pr"];
						foreach ($dp as $rs){
							$adiantamento->adiantamento = $rs;
							$adiantamento->usuario_dp = $_SESSION['usuario_sessao'];
							$adiantamento->dta_dp = date("d/m/Y H:i:s");
							$sql[$i] = $apiAdiantamento->editAdiantamento($adiantamento);
							$i = $i + 1;
						}
					}
				}
				$rs = $apiAdiantamento->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					header('location:' .APP_ROOT. 'finan/adiantamento/index/sucesso');
				}
			}elseif ($_POST['submeter'] == "consultar_in"){
				$busca = array(
					'1' => array('situacao' => "= {$_POST['situacao_in']}" , 'empresa' => (isset($_POST['empresa_in']) ? $_POST['empresa_in'] : array($_SESSION['empresa_sessao'])), 'solicitante' => $solicitante, 'c' => '2', 'coluna' => 'u.nome', 'valor' => @$_POST['busca_valor_in']),
					'2' => array('situacao' => "= {$_POST['situacao_in']}" , 'empresa' => (isset($_POST['empresa_in']) ? $_POST['empresa_in'] : array($_SESSION['empresa_sessao'])), 'solicitante' => $solicitante, 'c' => '1', 'coluna' => "ad.adiantamento", 'valor' => @$_POST['busca_valor_in']),
					'3' => array('situacao' => "= {$_POST['situacao_in']}" , 'empresa' => (isset($_POST['empresa_in']) ? $_POST['empresa_in'] : array($_SESSION['empresa_sessao'])), 'solicitante' => $solicitante, 'c' => '3', 'coluna' => "", 'valor' => "")
				);
				if(isset($busca[$_POST['busca_in']])){
					if (isset($_POST['empresa_in'])){
						$emp = implode(",", $_POST['empresa_in']);
					}else{
						$emp = $_SESSION['empresa_sessao'];
					}
					$empresa = "in ({$emp})";
					$this->inconsistencia = $apiAdiantamento->filtroAdiantamento("in ('A','R')",$busca[$_POST['busca_in']]['situacao'], $empresa, $busca[$_POST['busca_in']]['solicitante'], $busca[$_POST['busca_in']]['c'], $busca[$_POST['busca_in']]['coluna'], $busca[$_POST['busca_in']]['valor']);
				//	var_dump($this->inconsistencia);die();
					if (isset($_SESSION['consulta_sessao']['ad'][$this->getModule()['modulo'].$this->getController()['controle']])){
						$this->adiantamento = $_SESSION['consulta_sessao']['ad'][$this->getModule()['modulo'].$this->getController()['controle']];
					}
					if (isset($_SESSION['consulta_sessao']['re'][$this->getModule()['modulo'].$this->getController()['controle']])){
						$this->reembolso = $_SESSION['consulta_sessao']['re'][$this->getModule()['modulo'].$this->getController()['controle']];
					}
					if (isset($_SESSION['consulta_sessao']['pr'][$this->getModule()['modulo'].$this->getController()['controle']])){
						$this->prestacao = $_SESSION['consulta_sessao']['pr'][$this->getModule()['modulo'].$this->getController()['controle']];
					}
					$_SESSION['filtro_sessao']['in'] = array('situacao' => $busca[$_POST['busca_in']]['situacao'], 'empresa' => $busca[$_POST['busca_in']]['empresa'], 'solicitante' => $busca[$_POST['busca_in']]['solicitante'], 'c' => $busca[$_POST['busca_in']]['c'], 'coluna' => $busca[$_POST['busca_in']]['coluna'], 'busca_valor' => $busca[$_POST['busca_in']]['valor'], 'busca' => $_POST['busca_in']);
					$_SESSION['consulta_sessao']['in'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->inconsistencia;
				}else{
					unset($_SESSION['filtro_sessao']['in']);
					unset($_SESSION['consulta_sessao']['in']);
					header('location:' .APP_ROOT. 'finan/index/index/acessonegado');
					die();
				}
			}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				//--Adiantamento--//
				if ($_SESSION['aba_finan_sessao'] == "adiantamento"){
					$emp = implode(",", $_SESSION['filtro_sessao']['ad']['empresa']);
					$empresa = "in ({$emp})";
					$this->adiantamento = $apiAdiantamento->filtroAdiantamento("= 'A'", $_SESSION['filtro_sessao']['ad']['situacao'], $empresa, $_SESSION['filtro_sessao']['ad']['solicitante'], $_SESSION['filtro_sessao']['ad']['c'], $_SESSION['filtro_sessao']['ad']['coluna'], $_SESSION['filtro_sessao']['ad']['busca_valor']);
					$_SESSION['consulta_sessao']['ad'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->adiantamento;
				}else{
					if (isset($_SESSION['consulta_sessao']['re'][$this->getModule()['modulo'].$this->getController()['controle']])){
						$this->reembolso = $_SESSION['consulta_sessao']['re'][$this->getModule()['modulo'].$this->getController()['controle']];
					}
					if (isset($_SESSION['consulta_sessao']['in'][$this->getModule()['modulo'].$this->getController()['controle']])){
						$this->inconsistencia = $_SESSION['consulta_sessao']['in'][$this->getModule()['modulo'].$this->getController()['controle']];
					}
					if (isset($_SESSION['consulta_sessao']['pr'][$this->getModule()['modulo'].$this->getController()['controle']])){
						$this->prestacao = $_SESSION['consulta_sessao']['pr'][$this->getModule()['modulo'].$this->getController()['controle']];
					}
				}
				//--Adiantamento--//
				
				//--Reembolso----//
				if ($_SESSION['aba_finan_sessao'] == "reembolso"){
					$emp = implode(",", $_SESSION['filtro_sessao']['re']['empresa']);
					$empresa = "in ({$emp})";
					$this->reembolso = $apiAdiantamento->filtroAdiantamento("= 'R'", $_SESSION['filtro_sessao']['re']['situacao'], $empresa, $_SESSION['filtro_sessao']['re']['solicitante'], $_SESSION['filtro_sessao']['re']['c'], $_SESSION['filtro_sessao']['re']['coluna'], $_SESSION['filtro_sessao']['re']['busca_valor']);
					$_SESSION['consulta_sessao']['re'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->reembolso;
				
				}else{
					if (isset($_SESSION['consulta_sessao']['ad'][$this->getModule()['modulo'].$this->getController()['controle']])){
						$this->adiantamento = $_SESSION['consulta_sessao']['ad'][$this->getModule()['modulo'].$this->getController()['controle']];
					}
					if (isset($_SESSION['consulta_sessao']['pr'][$this->getModule()['modulo'].$this->getController()['controle']])){
						$this->prestacao = $_SESSION['consulta_sessao']['pr'][$this->getModule()['modulo'].$this->getController()['controle']];
					}
					if (isset($_SESSION['consulta_sessao']['in'][$this->getModule()['modulo'].$this->getController()['controle']])){
						$this->inconsistencia = $_SESSION['consulta_sessao']['in'][$this->getModule()['modulo'].$this->getController()['controle']];
					}
				}
				//--Reembolso----//
				
				//--Presta��o----//
				if ($_SESSION['aba_finan_sessao'] == "prestacao"){
					$emp = implode(",", $_SESSION['filtro_sessao']['pr']['empresa']);
					$empresa = "in ({$emp})";
					$this->prestacao = $apiAdiantamento->filtroAdiantamento("= 'A'", $_SESSION['filtro_sessao']['pr']['situacao'], $empresa, $_SESSION['filtro_sessao']['pr']['solicitante'], $_SESSION['filtro_sessao']['pr']['c'], $_SESSION['filtro_sessao']['pr']['coluna'], $_SESSION['filtro_sessao']['pr']['busca_valor']);
					$_SESSION['consulta_sessao']['pr'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->prestacao;
				}else{
					if (isset($_SESSION['consulta_sessao']['ad'][$this->getModule()['modulo'].$this->getController()['controle']])){
						$this->adiantamento = $_SESSION['consulta_sessao']['ad'][$this->getModule()['modulo'].$this->getController()['controle']];
					}
					if (isset($_SESSION['consulta_sessao']['re'][$this->getModule()['modulo'].$this->getController()['controle']])){
						$this->reembolso = $_SESSION['consulta_sessao']['re'][$this->getModule()['modulo'].$this->getController()['controle']];
					}
					if (isset($_SESSION['consulta_sessao']['in'][$this->getModule()['modulo'].$this->getController()['controle']])){
						$this->inconsistencia = $_SESSION['consulta_sessao']['in'][$this->getModule()['modulo'].$this->getController()['controle']];
					}
				}
				//--Presta��o----//
				
				//--Inconsist�ncia--//
				if ($_SESSION['aba_finan_sessao'] == "inconsistencia"){
					$emp = implode(",", $_SESSION['filtro_sessao']['in']['empresa']);
					$empresa = "in ({$emp})";
					$this->inconsistencia = $apiAdiantamento->filtroAdiantamento("in ('A','R')", $_SESSION['filtro_sessao']['in']['situacao'], $empresa, $_SESSION['filtro_sessao']['in']['solicitante'], $_SESSION['filtro_sessao']['in']['c'], $_SESSION['filtro_sessao']['in']['coluna'], $_SESSION['filtro_sessao']['in']['busca_valor']);
					$_SESSION['consulta_sessao']['in'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->inconsistencia;
				}else{
					if (isset($_SESSION['consulta_sessao']['ad'][$this->getModule()['modulo'].$this->getController()['controle']])){
						$this->adiantamento = $_SESSION['consulta_sessao']['ad'][$this->getModule()['modulo'].$this->getController()['controle']];
					}
					if (isset($_SESSION['consulta_sessao']['re'][$this->getModule()['modulo'].$this->getController()['controle']])){
						$this->reembolso = $_SESSION['consulta_sessao']['re'][$this->getModule()['modulo'].$this->getController()['controle']];
					}
					if (isset($_SESSION['consulta_sessao']['pr'][$this->getModule()['modulo'].$this->getController()['controle']])){
						$this->prestacao = $_SESSION['consulta_sessao']['pr'][$this->getModule()['modulo'].$this->getController()['controle']];
					}
				}
				//--Inconsist�ncia--//
			}else{
				if (isset($_SESSION['consulta_sessao']['ad'][$this->getModule()['modulo'].$this->getController()['controle']]) || isset($_SESSION['consulta_sessao']['re'][$this->getModule()['modulo'].$this->getController()['controle']]) || isset($_SESSION['consulta_sessao']['pr'][$this->getModule()['modulo'].$this->getController()['controle']]) || isset($_SESSION['consulta_sessao']['in'][$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->adiantamento = $_SESSION['consulta_sessao']['ad'][$this->getModule()['modulo'].$this->getController()['controle']];
					$this->reembolso = $_SESSION['consulta_sessao']['re'][$this->getModule()['modulo'].$this->getController()['controle']];
					$this->prestacao = $_SESSION['consulta_sessao']['pr'][$this->getModule()['modulo'].$this->getController()['controle']];
					$this->inconsistencia = $_SESSION['consulta_sessao']['in'][$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					//---Adiantamento--//
					unset($_SESSION['filtro_sessao']['ad']);
					unset($_SESSION['consulta_sessao']['ad']);
					$this->adiantamento = $apiAdiantamento->filtroAdiantamento("= 'A'",'= 0', "in({$_SESSION['empresa_sessao']})", $solicitante, '3');
					$_SESSION['filtro_sessao']['ad'] = array('situacao' => '= 0', 'empresa' => array($_SESSION['empresa_sessao']) , 'solicitante' => $solicitante, 'c' => '3', 'coluna' => '', 'busca_valor' => '', 'busca' => '3');
					$_SESSION['consulta_sessao']['ad'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->adiantamento;
					//------------//
					
					//---Reembolso--//
					unset($_SESSION['filtro_sessao']['re']);
					unset($_SESSION['consulta_sessao']['re']);
					$this->reembolso = $apiAdiantamento->filtroAdiantamento("= 'R'",'= 0', "in({$_SESSION['empresa_sessao']})", $solicitante, '3');
					$_SESSION['filtro_sessao']['re'] = array('situacao' => '= 0', 'empresa' => array($_SESSION['empresa_sessao']) , 'solicitante' => $solicitante, 'c' => '3', 'coluna' => '', 'busca_valor' => '', 'busca' => '3');
					$_SESSION['consulta_sessao']['re'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->reembolso;
					//------------//
					
					//---Presta��o--//
					unset($_SESSION['filtro_sessao']['pr']);
					unset($_SESSION['consulta_sessao']['pr']);
					$this->prestacao = $apiAdiantamento->filtroAdiantamento("= 'A'",'= 2', "in({$_SESSION['empresa_sessao']})", $solicitante, '3');
					$_SESSION['filtro_sessao']['pr'] = array('situacao' => '= 2', 'empresa' => array($_SESSION['empresa_sessao']) , 'solicitante' => $solicitante, 'c' => '3', 'coluna' => '', 'busca_valor' => '', 'busca' => '3');
					$_SESSION['consulta_sessao']['pr'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->prestacao;
					//------------//
					
					//---Inconsist�ncia--//
					unset($_SESSION['filtro_sessao']['in']);
					unset($_SESSION['consulta_sessao']['in']);
					$this->inconsistencia = $apiAdiantamento->filtroAdiantamento("in ('A','R')",'= 8', "in({$_SESSION['empresa_sessao']})", $solicitante, '3');
					$_SESSION['filtro_sessao']['in'] = array('situacao' => '= 8', 'empresa' => array($_SESSION['empresa_sessao']) , 'solicitante' => $solicitante, 'c' => '3', 'coluna' => '', 'busca_valor' => '', 'busca' => '3');
					$_SESSION['consulta_sessao']['in'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->inconsistencia;
					//------------//
				}
			}
		}
		//--Adiantamento--//
		$TotalAD = (is_array($this->adiantamento) ? count($this->adiantamento) : 0);
		@$this->adiantamento = array_chunk($this->adiantamento, $PorPagina);
		@$this->adiantamento = $this->adiantamento[$_SESSION['aba_pagina_sessao']['ad'] - 1];
		if ($TotalAD > $PorPagina) {
			$paginator = new Paginator();
			$this->paginacao_ad = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $_SESSION['aba_pagina_sessao']['ad'], $PorPagina, $TotalAD);
			$this->Paginaatual_ad = $_SESSION['aba_pagina_sessao']['ad'];
		}
		//------------//
		
		//--Reembolso--//
		$TotalRE = (is_array($this->reembolso) ? count($this->reembolso) : 0);
		@$this->reembolso = array_chunk($this->reembolso, $PorPagina);
		@$this->reembolso = $this->reembolso[$_SESSION['aba_pagina_sessao']['re'] - 1];
		if ($TotalRE > $PorPagina) {
			$paginator = new Paginator();
			$this->paginacao_re = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $_SESSION['aba_pagina_sessao']['re'], $PorPagina, $TotalRE);
			$this->Paginaatual_re = $_SESSION['aba_pagina_sessao']['re'];
		}
		//------------//
		
		//--Presta��o--//
		$TotalPR = (is_array($this->prestacao) ? count($this->prestacao) : 0);
		@$this->prestacao = array_chunk($this->prestacao, $PorPagina);
		@$this->prestacao = $this->prestacao[$_SESSION['aba_pagina_sessao']['pr'] - 1];
		if ($TotalPR > $PorPagina) {
			$paginator = new Paginator();
			$this->paginacao_pr = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $_SESSION['aba_pagina_sessao']['pr'], $PorPagina, $TotalPR);
			$this->Paginaatual_pr = $_SESSION['aba_pagina_sessao']['pr'];
		}
		//------------//
		
		//--Inconsist�ncia--//
		$TotalIN = (is_array($this->inconsistencia) ? count($this->inconsistencia) : 0);
		@$this->inconsistencia = array_chunk($this->inconsistencia, $PorPagina);
		@$this->inconsistencia = $this->inconsistencia[$_SESSION['aba_pagina_sessao']['in'] - 1];
		if ($TotalIN > $PorPagina) {
			$paginator = new Paginator();
			$this->paginacao_in = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $_SESSION['aba_pagina_sessao']['in'], $PorPagina, $TotalIN);
			$this->Paginaatual_in = $_SESSION['aba_pagina_sessao']['in'];
		}
		//------------//
		$this->view();
	}
	
	public function adicionar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		if ($_SESSION['aba_finan_sessao'] == "adiantamento"){
			$this->header = "Adiantamento";
		}elseif ($_SESSION['aba_finan_sessao'] == "reembolso"){
			$this->header = "Reembolso";
		}
		$apiAdiantamento = new apiAdiantamento();
		$AdiantamentoPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		$apiEmpresa = new apiEmpresa();
		$this->empresa = $apiEmpresa->filtroEmpresa('1','3','ativo', '1');
		$apiTipo = new apiTipo();
		$this->tipo = $apiTipo->filtroTipo('4','1','tipo_funcionario', $_SESSION['tipo_sessao']);
		$apiItem = new apiItem();
		$this->item = $apiItem->filtroItem('1', '3', 'ativo', '1');
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$funcoes = new Funcoes();
			$apiAdiantamento = new apiAdiantamento();
			$Post = new Adiantamento('POST');
			$prestacao = "prestacaodecontas@grupomonaco.com.br";
			if ($_SESSION['aba_finan_sessao'] == 'adiantamento'){
				$auth = "";
				if ($_SESSION['tipo_sessao'] == 5){
					$auth = "autorizado";
					$Post->situacao = 1;
					$Post->situacao_anterior = 1;
				}else{
					if (isset($_POST['segundo_ad']) && $_POST['segundo_ad'] == 'validar'){
						$auth = "autorizado";
						$Post->situacao = 0;
						$Post->situacao_anterior = 0;
					}else{
						$rs = $apiAdiantamento->filtroAdiantamento("= 'A'",'in (0,1)', 'tudo', 'tudo', '1', "ad.solicitante", $_SESSION['usuario_sessao']);
						if ((is_array($rs) ? count($rs) : 0) > 0){
							$this->rollback = new Adiantamento('POST');
							$this->Alert = "Voc� possui adiantamento em aberto, para solicitar um novo, voc� deve fazer a presta��o de contas ou solicitar autoriza��o ao diretor!";
							$auth = "negado";
						}else{
							$auth = "autorizado";
							$Post->situacao = 0;
							$Post->situacao_anterior = 0;
						}
					}
				}
				if($auth == 'autorizado'){
					$emp = $apiEmpresa->geEmpresarevenda($Post->empresa);
					$contpg = "";
					$data = date('d/m/Y');
					if ($emp->EMPRESA == "1"){
						$contpg = "contasapagar.dieselpa@grupomonaco.com.br";
					}elseif ($emp->EMPRESA == "2"){
						$contpg = "contasapagar.motopa@grupomonaco.com.br";
					}elseif ($emp->EMPRESA == "3"){
						$contpg = "contasapagar.dieselmt@grupomonaco.com.br";
					}elseif ($emp->EMPRESA == "4"){
						$contpg = "contasapagar.dieselpi@grupomonaco.com.br";
					}elseif ($emp->EMPRESA == "5"){
						$contpg = "contasapagar.dieselma@grupomonaco.com.br";
					}elseif ($emp->EMPRESA == "7"){
						$contpg = "contasapagar.motomt@grupomonaco.com.br";
					}elseif ($emp->EMPRESA == "9"){
						$contpg = "contasapagar.motoap@grupomonaco.com.br";
					}elseif ($emp->EMPRESA == "11"){
						$contpg = "contasapagar.dieselap@grupomonaco.com.br";
					}elseif ($emp->EMPRESA == "13"){
						$contpg = "contasapagar.fiatpa@grupomonaco.com.br";
					}elseif ($emp->EMPRESA == "50"){
						$contpg = "contasapagar.dieselparticipacoes@grupomonaco.com.br";
					}
					$Post->categoria = "A";
					$Post->des_adiantamento = str_replace("\r\n","<br>",$Post->des_adiantamento);
					$Post->solicitante = $_SESSION['usuario_sessao'];
					$Post->val_adiantamento = $funcoes->sanearValor($Post->val_adiantamento);
					$Post->dta_cadastro = date("d/m/Y H:i:s");
					$sql[$i] = $apiAdiantamento->addAdiantamento($Post);
					$i = $i+1;
					$log = new Log();
					$log->usuario = $_SESSION['usuario_sessao'];
					$log->modulo = $this->getModule()['modulo'];
					$log->controle = $this->getController()['controle'];
					$log->acao = $this->getAction()['acao'];
					$log->empresa = $_SESSION['empresa_sessao'];
					$log->tipo = "I";
					$log->dta_registro = date("d/m/Y H:i:s");
					$log->historico = "DES_ADIANTAMENTO||{$Post->des_adiantamento};;SOLICITANTE||{$Post->solicitante};;CATEGORIA||{$Post->categoria};;CC||{$Post->cc};;EMPRESA||{$Post->empresa};;VAL_ADIANTAMENTO||{$Post->val_adiantamento};;DTA_CADASTRO||{$Post->dta_cadastro};;SITUACAO||{$Post->situacao}";
					$apiLog = new apiLog();
					$adiantamento = array('coluna' => 'adiantamento','tabela' => 'finan_adiantamento');
					$autorizacao = new Autorizacao();
					$apiUsuario = new apiUsuario();
					$para = array();
					$a = 0;
					if ($_SESSION['tipo_sessao'] == 5){
						$autorizacao->situacao = 0;
						$autorizacao->destinatario = $_SESSION['usuario_sessao'];
						$autorizacao->autorizante = $_SESSION['usuario_sessao'];
						$autorizacao->dta_solicitacao = $Post->dta_cadastro;
						$autorizacao->dta_acao = $Post->dta_cadastro;
						$autorizacao->autorizado = 'S';
						$sql[$i] = $apiAdiantamento->addAutorizacao($autorizacao, $adiantamento);
						$i = $i+1;
						$autorizacao = new Autorizacao();
						$autorizacao->adiantamento = $adiantamento->adiantamento;
						$autorizacao->situacao = 1;
						$autorizacao->dta_solicitacao = date("d/m/Y H:i:s");
						$sql[$i] = $apiAdiantamento->addAutorizacao($autorizacao, $adiantamento);
						$envolvidos = $apiUsuario->getEmailenvolvidos($_SESSION['usuario_sessao']);
						foreach ($envolvidos as $rs) {
							$para[$a] = "{$rs->EMAIL}";
							$a = $a + 1;
						}
						$para[$a] = "{$prestacao}";
						$a = $a+1;
						$para[$a] = $contpg;
						$assunto   = "Aguardando Aprova��o Financeira {$data}";
						$situacao = "Aguardando Aprova��o Financeira";
						$gestorn = $envolvidos[0]->NOME;
						$gestorm = $envolvidos[0]->EMAIL;
						$mov = "<hr /><br><br><h2 style='margin-bottom:5px; margin-top:10px; font-size:12px;'>Autoriza��es & Hist�rico</h2><hr /><p style='margin-bottom:10px; margin-top:2px; font-style: italic;color: #606060;'>Em {$autorizacao->dta_acao}</p><p style='margin-bottom: 10px;'><strong>Situa��o:</strong> Aprova��o Gerencial</p><p style='margin-bottom: 10px;'><strong>Autorizante:</strong> {$_SESSION['nome_sessao']}</p><p style='margin-bottom: 10px;'><strong>Autorizado:</strong> Sim</p>";
					
					}else{
						$autorizacao->situacao = 0;
						$autorizacao->destinatario = $_POST['destinatario'];
						$autorizacao->dta_solicitacao = $Post->dta_cadastro;
						$sql[$i] = $apiAdiantamento->addAutorizacao($autorizacao, $adiantamento);
						$envolvidos = $apiUsuario->getEmailenvolvidos("{$_SESSION['usuario_sessao']},{$_POST['destinatario']}");
						foreach ($envolvidos as $rs) {
							$para[$a] = "{$rs->EMAIL}";
							$a = $a + 1;
						}
						$assunto   = "Aguardando Aprova��o Gerencial {$data}";
						$situacao = "Aguardando Aprova��o Gerencial";
						$gestorn = $envolvidos[0]->NOME;
						$gestorm = $envolvidos[0]->EMAIL;
						$mov = "";
					}
					$valor = $_POST['val_adiantamento'];
					$de  = "SisMonaco - SPC Adiantamento {$data}";
					$i = $i+1;
					$sql[$i] = $apiLog->addLog($log);
					
					$rs = $apiAdiantamento->executeSQL($sql);
					if (@$rs[4] == 'sucesso') {
						$cc[100] = "VE�CULOS NOVOS";
						$cc[200] = "VE�CULOS SEMINOVOS";
						$cc[300] = "PE�AS";
						$cc[400] = "ASSIST�NCIA T�CNICA";
						$cc[500] = "ADMINISTRATIVO";
						$cc[600] = "F&I";
						$cc[800] = "VENDA DIRETA";
						$cc[900] = "HOLDING";
						
						$this->dados = array('adiantamento' => $apiAdiantamento->numeroAdiantamento());
						$exp_s = explode(" ", $this->dados['adiantamento']->NOME);
						$exp_s[1] = end($exp_s);
						$exp_g = explode(" ", $gestorn);
						$exp_g[1] = end($exp_g);
						$descricao = wordwrap($this->dados['adiantamento']->DES_ADIANTAMENTO, 60, "<br>", true);
						$mensagem = "<html>
										<head></head>
										<body style='margin:0px; padding:0px; border: 0 none; font-size: 9px; font-family: verdana, sans-serif; background-color: #efefef;'>
											<style type='text/css'>
												td p{margin-bottom: 10px;}
												body.ticket {margin:0px; padding:0px; border: 0 none; font-size: 9px; font-family: verdana, sans-serif; background-color: #efefef;}
												h1.title {margin-bottom:0px;}
												p.subtitle {color: #ccc;margin-top:0px;margin-bottom:0px;font-style: italic;}
												table.content {width: 700px; margin: 50px auto 50px auto; border: 1px #ccc solid; background: #fff; font-size: 11px; font-family: verdana, sans-serif;}
												td.uppercontent {border:0px;padding: 9px; color: #fff; background: #070075;}
												tr.lowercontent {padding: 10px;}
												td.leftcolumn {width: 400px; padding: 15px 0px 0px 18px; vertical-align: top;}
												td.rightcolumn {width: 240px; vertical-align: top;}
												div.rightcolumndiv{margin:15px 8px 15px;padding: 9px; border: 1px #ccc solid; font-size: 10px;}
												p.rcmessage {margin-top:5px;}
												a.links {color:#0000FF; text-decoration: none;}
												hr.rcdivider {height: 1px; color: #ccc;}
												p.tickethistory {margin-bottom:10px; margin-top:2px; font-style: italic;color: #606060;}
												table.ticket-sum-hist {border: 1px #ccc solid; background: #eee; width: 394px; font-size: 11px; font-family: verdana, sans-serif;}
												div.ticket-sum-histdiv {margin: 9px;}
												h2.ticket-sum-hist-titles {margin-bottom:5px; margin-top:10px; font-size:12px;}
												p.date {font-style: italic;margin-bottom:10px;}
											</style>
											<table style='width: 800px; margin: 50px auto 50px auto; border: 1px #ccc solid; background: #fff; font-size: 11px; font-family: verdana, sans-serif;' align='center'>
												<tbody>
													<tr>
														<td colspan='2' style='padding: 9px; color: #000000; background: #d0d0d0;'>
															<img src='' />
															<br>
															<p style='margin-top:0px;margin-bottom:0px;font-style: italic;'>Notifica��o do SPC.</p>
														</td>
													</tr>
													<tr style='padding: 10px;'>
														<td style='width: 240px; vertical-align: top;'>
															<div style='margin:15px 8px 15px;padding: 9px; border: 1px #ccc solid; font-size: 10px;'>
																<strong>Adiantamento: </strong>{$this->dados['adiantamento']->ADIANTAMENTO}
																<hr style='height: 1px; color: #ccc;' />
																<strong>Data de Abertura:</strong> {$this->dados['adiantamento']->DTA_CADASTRO}<br />
																<br />
																<strong>Solicitado por:</strong> <a style='color:#0000FF; text-decoration: none;' href='mailto:{$this->dados['adiantamento']->EMAIL}?subject=[Adiantamento #{$this->dados['adiantamento']->ADIANTAMENTO}] {$this->dados['adiantamento']->DES_TIPO}'>{$exp_s[0]} {$exp_s[1]}</a><br />
																<br />
																<strong>Empresa Origem:</strong> {$this->dados['adiantamento']->DES_EMPRESA}<br />
																<br />
																<strong>Empresa Destino:</strong> {$this->dados['adiantamento']->EMPRESA_DESTINO}<br />
																<br />
																<strong>Departamento:</strong> {$this->dados['adiantamento']->DEPARTAMENTO}<br />
																<br />
																<strong>Assunto:</strong> {$this->dados['adiantamento']->DES_TIPO}<br />
																<br />
																<strong>Categoria:</strong> ADIANTAMENTO<br  />
																<br />
																<strong>Situacao:</strong> {$situacao}<br  />
																<br />
																<strong>Valor:</strong> {$valor}<br />
													            <br />
													            <strong>Centro de Custo:</strong> {$cc[$this->dados['adiantamento']->CC]}<br />
													            <br />
													            <strong>Solicita��o URL:</strong> <a style='color:#0000FF; text-decoration: none;' href='".APP_ROOT."finan/adiantamento/alterar/{$this->dados['adiantamento']->ADIANTAMENTO}'>Adiantamento {$this->dados['adiantamento']->ADIANTAMENTO}</a><br />
													            <br />
													            <strong>Autorizante Gestor:</strong> <a style='color:#0000FF; text-decoration: none;' href='mailto:{$gestorm}?subject=[Adiantamento #{$this->dados['adiantamento']->ADIANTAMENTO}] {$this->dados['adiantamento']->DES_TIPO}'>{$exp_g[0]} {$exp_g[1]}</a><br />
													            <br />
													            <hr style='height: 1px; color: #ccc;' />
													            <p style='margin-top:5px;'>se voc� quiser acessar o sistema para verificar seus 
																Adiantamentos e Reembolsos Por favor acesse <a style='color:#0000FF; text-decoration: none;' href='".APP_ROOT."finan/adiantamento/'>
													            aqui</a> e fa�a suas consultas.</p>
											           	 	</div>
											            </td>
											            <td style='width: 400px; padding: 15px 0px 0px 18px; vertical-align: top;'>
											            	<p style='margin-bottom: 10px;'>{$exp_s[0]} {$exp_s[1]},</p>
											            	<p style='font-style: italic;margin-bottom:10px;'>O Adiantamento: {$this->dados['adiantamento']->ADIANTAMENTO} foi criado em {$this->dados['adiantamento']->DTA_CADASTRO} por {$this->dados['adiantamento']->NOME}.</p>
											            	<br>
											            	<br>
											            	<br />
											            	<table style='border: 1px #ccc solid; background: #eee; width: 394px; font-size: 11px; font-family: verdana, sans-serif;'>
											            		<tr>
											            			<td>
															            <div style='margin: 9px; max-width:500px;'>
															            	<h2 style='margin-bottom:5px; margin-top:10px; font-size:12px;'>Adiantamento: {$this->dados['adiantamento']->ADIANTAMENTO}</h2>
															            	<p style='margin-bottom: 10px;'><strong>Assunto:</strong> {$this->dados['adiantamento']->DES_TIPO}</p>
															            	<p style='margin-bottom: 10px;'><strong>Descri��o:</strong> {$descricao}</p>
															            	<p style='margin-bottom: 10px;'><strong>Termo Grupo M�naco:</strong><br>Prezado, <strong>{$this->dados['adiantamento']->NOME}</strong>, ao efetivarmos a vossa solicita��o de adiantamento para custear as suas despesas, voc� passa a aceitar todos os termos, normas e processo conforme o RGM do GRUPO M�NACO, onde o seu descumprimento est� passivo de desconto, a ser realizado em seu provento mensal ou rescis�o de contrato de trabalho.</p>
																			{$mov}
											            				</div>
											            			</td>
											            		</tr>
											            	</table>
											            	<br />
											            	<br />
											            </td>
											     	</tr>
											   	</tbody>
											</table>
										</body>
									</html>";
						$Envio = new EnvioEmail();
						$Envio->Envio($de, $assunto, $mensagem, $para, "", "");
						if (isset($this->PaginaAtual)) {
							header('location:' .APP_ROOT. 'finan/adiantamento/index/pagina/'.$this->PaginaAtual.'/sucesso');
						}else {
							header('location:' .APP_ROOT. 'finan/adiantamento/index/sucesso');
						}
						
					}else{
						$this->rollback = new Adiantamento('POST');
						$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
						$erro = str_replace($retirar, "", $rs[2]);
						$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
					}
				}
			}else{
				$emp = $apiEmpresa->geEmpresarevenda($Post->empresa);
				$contpg = "";
				$data = date('d/m/Y');
				if ($emp->EMPRESA == "1"){
					$contpg = "contasapagar.dieselpa@grupomonaco.com.br";
				}elseif ($emp->EMPRESA == "2"){
					$contpg = "contasapagar.motopa@grupomonaco.com.br";
				}elseif ($emp->EMPRESA == "3"){
					$contpg = "contasapagar.dieselmt@grupomonaco.com.br";
				}elseif ($emp->EMPRESA == "4"){
					$contpg = "contasapagar.dieselpi@grupomonaco.com.br";
				}elseif ($emp->EMPRESA == "5"){
					$contpg = "contasapagar.dieselma@grupomonaco.com.br";
				}elseif ($emp->EMPRESA == "7"){
					$contpg = "contasapagar.motomt@grupomonaco.com.br";
				}elseif ($emp->EMPRESA == "9"){
					$contpg = "contasapagar.motoap@grupomonaco.com.br";
				}elseif ($emp->EMPRESA == "11"){
					$contpg = "contasapagar.dieselap@grupomonaco.com.br";
				}elseif ($emp->EMPRESA == "13"){
					$contpg = "contasapagar.fiatpa@grupomonaco.com.br";
				}elseif ($emp->EMPRESA == "50"){
					$contpg = "contasapagar.dieselparticipacoes@grupomonaco.com.br";
				}
				$Post = new Adiantamento();
				$Post->des_adiantamento = str_replace("\r\n","<br>",$_POST['des_adiantamento']);
				$Post->solicitante = $_SESSION['usuario_sessao'];
				$Post->categoria = "R";
				$Post->cc = $_POST['cc'];
				$Post->tipo = $_POST['tipo'];
				$Post->empresa = $_POST['empresa'];
				$Post->dta_inicio = $_POST['dta_inicio'];
				$Post->dta_fim = $_POST['dta_fim'];
				$Post->banco = $_POST['banco'];
				$Post->agencia = $_POST['agencia'];
				$Post->conta = $_POST['conta'];
				$Post->tipo_conta = $_POST['tipo_conta'];
				$Post->cartao_corporativo = $_POST['cartao_corporativo'];
				$Post->frota = $_POST['frota'];
				if ($Post->frota == 'A'){
					$Post->km_inicial = $_POST['km_inicial'];
					$Post->km_final = $_POST['km_final'];
					$Post->val_km = $funcoes->sanearValor($_POST['val_km']);
				}
				$Post->val_receber = $funcoes->sanearValor($_POST['val_receber']);
				$Post->dta_cadastro = date("d/m/Y H:i:s");
				if ($_SESSION['tipo_sessao'] == 5){
					$Post->situacao = 1;
					$Post->situacao_anterior = 1;
				}else{
					$Post->situacao = 0;
					$Post->situacao_anterior = 0;
				}
				
				$anexo = $_FILES["anexo"];
				$ane = 1;
				$an = 0;
				$anexos_nomes = array();
				$anexos = "";
				foreach ($anexo['name'] as $key => $v){
					$v = explode(".", $v);
					$exp = strtolower(end($v));
					$anexos_nomes[$an] = "{$_SESSION['usuario_sessao']}-Anexo{$ane}-".date('dmY-His').".{$exp}";
					$anexos .= "ANEXO{$ane}||{$_SESSION['usuario_sessao']}-Anexo{$ane}-".date('dmY-His').".{$exp};;";
					$an = $an + 1;
					$ane = $ane + 1;
				}
				$Post->anexos = substr($anexos,0,-2);
				$sql[$i] = $apiAdiantamento->addAdiantamento($Post);
				$i = $i+1;
				$log = new Log();
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico = "DES_ADIANTAMENTO||{$Post->des_adiantamento};;SOLICITANTE||{$Post->solicitante};;CATEGORIA||{$Post->categoria};;CC||{$Post->cc};;EMPRESA||{$Post->empresa};;VAL_ADIANTAMENTO||{$Post->val_adiantamento};;DTA_CADASTRO||{$Post->dta_cadastro};;SITUACAO||{$Post->situacao}";
				$apiLog = new apiLog();
				$adiantamento = array('coluna' => 'adiantamento','tabela' => 'finan_adiantamento');
				$autorizacao = new Autorizacao();
				$apiUsuario = new apiUsuario();
				$para = array();
				$a = 0;
				if ($_SESSION['tipo_sessao'] == 5){
					$autorizacao->situacao = 0;
					$autorizacao->destinatario = $_SESSION['usuario_sessao'];
					$autorizacao->autorizante = $_SESSION['usuario_sessao'];
					$autorizacao->dta_solicitacao = $Post->dta_cadastro;
					$autorizacao->dta_acao = $Post->dta_cadastro;
					$autorizacao->autorizado = 'S';
					$sql[$i] = $apiAdiantamento->addAutorizacao($autorizacao, $adiantamento);
					$i = $i+1;
					$autorizacao = new Autorizacao();
					$autorizacao->adiantamento = $adiantamento->adiantamento;
					$autorizacao->situacao = 1;
					$autorizacao->dta_solicitacao = date("d/m/Y H:i:s");
					$sql[$i] = $apiAdiantamento->addAutorizacao($autorizacao, $adiantamento);
					$envolvidos = $apiUsuario->getEmailenvolvidos($_SESSION['usuario_sessao']);
					foreach ($envolvidos as $rs) {
						$para[$a] = "{$rs->EMAIL}";
						$a = $a + 1;
					}
					$para[$a] = "{$prestacao}";
					$a = $a+1;
					$para[$a] = $contpg;
					$assunto   = "Aguardando Aprova��o Financeira {$data}";
					$situacao = "Aguardando Aprova��o Financeira";
					$gestorn = $envolvidos[0]->NOME;
					$gestorm = $envolvidos[0]->EMAIL;
					$mov = "<hr /><br><br><h2 style='margin-bottom:5px; margin-top:10px; font-size:12px;'>Autoriza��es & Hist�rico</h2><hr /><p style='margin-bottom:10px; margin-top:2px; font-style: italic;color: #606060;'>Em {$autorizacao->dta_acao}</p><p style='margin-bottom: 10px;'><strong>Situa��o:</strong> Aprova��o Gerencial</p><p style='margin-bottom: 10px;'><strong>Autorizante:</strong> {$_SESSION['nome_sessao']}</p><p style='margin-bottom: 10px;'><strong>Autorizado:</strong> Sim</p>";
				}else{
					$autorizacao->situacao = 0;
					$autorizacao->destinatario = $_POST['destinatario'];
					$autorizacao->dta_solicitacao = $Post->dta_cadastro;
					$sql[$i] = $apiAdiantamento->addAutorizacao($autorizacao, $adiantamento);
					$envolvidos = $apiUsuario->getEmailenvolvidos("{$_SESSION['usuario_sessao']},{$_POST['destinatario']}");
					foreach ($envolvidos as $rs) {
						$para[$a] = "{$rs->EMAIL}";
						$a = $a + 1;
					}
					$assunto   = "Aguardando Aprova��o Gerencial {$data}";
					$situacao = "Aguardando Aprova��o Gerencial";
					$gestorn = $envolvidos[0]->NOME;
					$gestorm = $envolvidos[0]->EMAIL;
					$mov = "";
				}
				$valorr = $_POST['val_receber'];;
				$de  = "SisMonaco - SPC Reembolso {$data}";
				$ordem = 0;
				$item = $_POST["item"];
				$descricao = $_POST["descricao"];
				$documento = $_POST["documento"];
				$fornecedor = $_POST["fornecedor"];
				$data = $_POST["data"];
				$valor = $_POST["valor"];
				$itemadiantamento = new Itemadiantamento();
				foreach ($item as $key => $it) {
					$i = $i+1;
					$ordem = $ordem + 1;
					$itemadiantamento->ordem = $ordem;
					$itemadiantamento->item = $it;
					$itemadiantamento->descricao = strtoupper($funcoes->retiraAcentos(trim($descricao{$key})));
					$itemadiantamento->documento = $documento{$key};
					$itemadiantamento->fornecedor = strtoupper($funcoes->retiraAcentos(trim($fornecedor{$key})));
					$itemadiantamento->data = $data{$key};
					$itemadiantamento->valor = $funcoes->sanearValor($valor{$key});
					$sql[$i] = $apiItem->addItemadiantamento($itemadiantamento,$adiantamento);
				}
				$i = $i+1;
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiAdiantamento->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					$cc[100] = "VE�CULOS NOVOS";
					$cc[200] = "VE�CULOS SEMINOVOS";
					$cc[300] = "PE�AS";
					$cc[400] = "ASSIST�NCIA T�CNICA";
					$cc[500] = "ADMINISTRATIVO";
					$cc[600] = "F&I";
					$cc[800] = "VENDA DIRETA";
					$cc[900] = "HOLDING";
					
					$this->dados = array('adiantamento' => $apiAdiantamento->numeroAdiantamento());
					$exp_s = explode(" ", $this->dados['adiantamento']->NOME);
					$exp_s[1] = end($exp_s);
					$exp_g = explode(" ", $gestorn);
					$exp_g[1] = end($exp_g);
					$descricao = wordwrap($this->dados['adiantamento']->DES_ADIANTAMENTO, 60, "<br>", true);
					$mensagem = "<html>
										<head></head>
										<body style='margin:0px; padding:0px; border: 0 none; font-size: 9px; font-family: verdana, sans-serif; background-color: #efefef;'>
											<style type='text/css'>
												td p{margin-bottom: 10px;}
												body.ticket {margin:0px; padding:0px; border: 0 none; font-size: 9px; font-family: verdana, sans-serif; background-color: #efefef;}
												h1.title {margin-bottom:0px;}
												p.subtitle {color: #ccc;margin-top:0px;margin-bottom:0px;font-style: italic;}
												table.content {width: 700px; margin: 50px auto 50px auto; border: 1px #ccc solid; background: #fff; font-size: 11px; font-family: verdana, sans-serif;}
												td.uppercontent {border:0px;padding: 9px; color: #fff; background: #070075;}
												tr.lowercontent {padding: 10px;}
												td.leftcolumn {width: 400px; padding: 15px 0px 0px 18px; vertical-align: top;}
												td.rightcolumn {width: 240px; vertical-align: top;}
												div.rightcolumndiv{margin:15px 8px 15px;padding: 9px; border: 1px #ccc solid; font-size: 10px;}
												p.rcmessage {margin-top:5px;}
												a.links {color:#0000FF; text-decoration: none;}
												hr.rcdivider {height: 1px; color: #ccc;}
												p.tickethistory {margin-bottom:10px; margin-top:2px; font-style: italic;color: #606060;}
												table.ticket-sum-hist {border: 1px #ccc solid; background: #eee; width: 394px; font-size: 11px; font-family: verdana, sans-serif;}
												div.ticket-sum-histdiv {margin: 9px;}
												h2.ticket-sum-hist-titles {margin-bottom:5px; margin-top:10px; font-size:12px;}
												p.date {font-style: italic;margin-bottom:10px;}
											</style>
											<table style='width: 800px; margin: 50px auto 50px auto; border: 1px #ccc solid; background: #fff; font-size: 11px; font-family: verdana, sans-serif;' align='center'>
												<tbody>
													<tr>
														<td colspan='2' style='padding: 9px; color: #000000; background: #d0d0d0;'>
															<img src='' />
															<br>
															<p style='margin-top:0px;margin-bottom:0px;font-style: italic;'>Notifica��o do SPC.</p>
														</td>
													</tr>
													<tr style='padding: 10px;'>
														<td style='width: 240px; vertical-align: top;'>
															<div style='margin:15px 8px 15px;padding: 9px; border: 1px #ccc solid; font-size: 10px;'>
																<strong>Reembolso: </strong>{$this->dados['adiantamento']->ADIANTAMENTO}
																<hr style='height: 1px; color: #ccc;' />
																<strong>Data de Abertura:</strong> {$this->dados['adiantamento']->DTA_CADASTRO}<br />
																<br />
																<strong>Solicitado por:</strong> <a style='color:#0000FF; text-decoration: none;' href='mailto:{$this->dados['adiantamento']->EMAIL}?subject=[Reembolso #{$this->dados['adiantamento']->ADIANTAMENTO}] {$this->dados['adiantamento']->DES_TIPO}'>{$exp_s[0]} {$exp_s[1]}</a><br />
																<br />
																<strong>Empresa Origem:</strong> {$this->dados['adiantamento']->DES_EMPRESA}<br />
																<br />
																<strong>Empresa Destino:</strong> {$this->dados['adiantamento']->EMPRESA_DESTINO}<br />
																<br />
																<strong>Departamento:</strong> {$this->dados['adiantamento']->DEPARTAMENTO}<br />
																<br />
																<strong>Assunto:</strong> {$this->dados['adiantamento']->DES_TIPO}<br />
																<br />
																<strong>Categoria:</strong> REEMBOLSO<br  />
																<br />
																<strong>Situacao:</strong> {$situacao}<br  />
																<br />
																<strong>Valor:</strong> {$valorr}<br />
																<br />
																<strong>Centro de Custo:</strong> {$cc[$this->dados['adiantamento']->CC]}<br />
																<br />
																<strong>Solicita��o URL:</strong> <a style='color:#0000FF; text-decoration: none;' href='".APP_ROOT."finan/adiantamento/alterar/{$this->dados['adiantamento']->ADIANTAMENTO}'>Reembolso {$this->dados['adiantamento']->ADIANTAMENTO}</a><br />
																<br />
																<strong>Autorizante Gestor:</strong> <a style='color:#0000FF; text-decoration: none;' href='mailto:{$gestorm}?subject=[Reembolso #{$this->dados['adiantamento']->ADIANTAMENTO}] {$this->dados['adiantamento']->DES_TIPO}'>{$exp_g[0]} {$exp_g[1]}</a><br />
																<br />
																<hr style='height: 1px; color: #ccc;' />
																<p style='margin-top:5px;'>se voc� quiser acessar o sistema para verificar seus
																Adiantamentos e Reembolsos Por favor acesse <a style='color:#0000FF; text-decoration: none;' href='".APP_ROOT."finan/adiantamento/'>
																aqui</a> e fa�a suas consultas.</p>
															</div>
														</td>
														<td style='width: 400px; padding: 15px 0px 0px 18px; vertical-align: top;'>
																<p style='margin-bottom: 10px;'>{$exp_s[0]} {$exp_s[1]},</p>
																<p style='font-style: italic;margin-bottom:10px;'>O Reembolso: {$this->dados['adiantamento']->ADIANTAMENTO} foi criado em {$this->dados['adiantamento']->DTA_CADASTRO} por {$this->dados['adiantamento']->NOME}.</p>
																<br>
																<br>
																<br />
																<table style='border: 1px #ccc solid; background: #eee; width: 394px; font-size: 11px; font-family: verdana, sans-serif;'>
																	<tr>
																		<td>
																			<div style='margin: 9px; max-width:500px;'>
																				<h2 style='margin-bottom:5px; margin-top:10px; font-size:12px;'>Reembolso: {$this->dados['adiantamento']->ADIANTAMENTO}</h2>
																				<p style='margin-bottom: 10px;'><strong>Assunto:</strong> {$this->dados['adiantamento']->DES_TIPO}</p>
																				<p style='margin-bottom: 10px;'><strong>Descri��o:</strong>{$descricao}</p>
																				<p style='margin-bottom: 10px;'><strong>Termo Grupo M�naco:</strong><br>Prezado, {$this->dados['adiantamento']->NOME}, ao aceitarmos a vossa solicita��o de reembolso referente ao custeio das vossas despesas, voc� passa a aceitar todos os termos, normas e processo conforme o RGM do GRUPO M�NACO, onde o seu descumprimento est� passivo de desconto, a ser realizado em seu provento mensal ou rescis�o de contrato de trabalho.</p>
																				{$mov}
																			</div>
																		</td>
																	</tr>
																</table>
																<br />
																<br />
															</td>
														</tr>
													</tbody>
												</table>
											</body>
										</html>";
					$Envio = new EnvioEmail();
					$Envio->Envio($de, $assunto, $mensagem, $para, "", "");				
					foreach ($anexos_nomes as $key => $v){
						move_uploaded_file($_FILES['anexo']['tmp_name'][$key], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/".$v);
					}
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'finan/adiantamento/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'finan/adiantamento/index/sucesso');
					}
				}else{
					$this->rollback = new Adiantamento('POST');
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		
		$this->view();
	}
	
	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		if ($_SESSION['aba_finan_sessao'] == "adiantamento"){
			$this->header = "Intera��o Adiantamento";
		}elseif ($_SESSION['aba_finan_sessao'] == "reembolso"){
			$this->header = "Intera��o Reembolso";
		}elseif ($_SESSION['aba_finan_sessao'] == "prestacao"){
			$this->header = "Presta��o de Contas";
		}elseif ($_SESSION['aba_finan_sessao'] == "inconsistencia"){
			$this->header = "Inconsist�ncia";
		}
		$adiantamento = new Adiantamento();
		$adiantamento->adiantamento = $this->getParams(0);
		$apiAdiantamento = new apiAdiantamento();
		$this->dados = array('adiantamento' => $apiAdiantamento->getAdiantamento($adiantamento));
	//	var_dump($this->dados['adiantamento']);die();
		$apiEmpresa = new apiEmpresa();
		$empresa = $apiEmpresa->filtroEmpresa('1','3','ativo', '1');
		foreach ($empresa as $rs){
			$this->empresa[$rs->EMPRESA] = array('empresa' => $rs->EMPRESA, 'des_empresa' => $rs->DES_EMPRESA);
		}
		$apiTipo = new apiTipo();
		$tipo = $apiTipo->filtroTipo('4','1','tipo_funcionario', $_SESSION['tipo_sessao']);
		foreach ($tipo as $rs){
			$this->tipo[$rs->TIPO] = array('tipo' => $rs->TIPO, 'des_tipo' => $rs->DES_TIPO);
		}
		$cc[100] = "VE�CULOS NOVOS";
		$cc[200] = "VE�CULOS SEMINOVOS";
		$cc[300] = "PE�AS";
		$cc[400] = "ASSIST�NCIA T�CNICA";
		$cc[500] = "ADMINISTRATIVO";
		$cc[600] = "F&I";
		$cc[800] = "VENDA DIRETA";
		$cc[900] = "HOLDING";
		
		$tipo_conta["S"] = "Conta Sal�rio";
		$tipo_conta["C"] = "Conta Corrente";
		$tipo_conta["P"] = "Conta Poupan�a";
		$tipo_conta["CO"] = "Conta Conjunta";
	
		if (isset($this->dados['adiantamento'])){
			if ($this->dados['adiantamento']->SOLICITANTE != $_SESSION['usuario_sessao']){
				if (($this->dados['adiantamento']->SITUACAO == 0 || $this->dados['adiantamento']->SITUACAO == 3) && !isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-4"])){	
					if (($this->dados['adiantamento']->SITUACAO == 0 || $this->dados['adiantamento']->SITUACAO == 3) && $this->dados['adiantamento']->DESTINATARIO != $_SESSION['usuario_sessao']){
						header('location:' .APP_ROOT. 'finan/index/index/acessonegado');
						die();
					}
				}elseif (($this->dados['adiantamento']->SITUACAO == 1 || $this->dados['adiantamento']->SITUACAO == 4) && !isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-5"])){
					header('location:' .APP_ROOT. 'finan/index/index/acessonegado');
					die();
				}elseif (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-2"])){
					header('location:' .APP_ROOT. 'finan/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'finan/index/index/acessonegado');
			die();
		}
		$strVal = explode(';;', $this->dados['adiantamento']->ANEXOS);
		foreach ($strVal as $va){
			@list($k, $v) = explode('||', $va);
			$this->anexos[$k] = $v;
		}
		rsort($this->anexos);
		/*$strVal = explode(';;', $this->dados['adiantamento']->ANEXOS_COMP);
		foreach ($strVal as $va){
			@list($k, $v) = explode('||', $va);
			$this->anexos_comp[$k] = $v;
		}
		rsort($this->anexos_comp);*/
		$this->autorizacao = $apiAdiantamento->getAdiantamentoautorizacao($adiantamento);
		$this->inconsistencia = $apiAdiantamento->getAdiantamentoinconsistencia($adiantamento);
		$AdiantamentoPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		$apiItem = new apiItem();
		$this->item = $apiItem->filtroItem('1', '3', 'ativo', '1');
		$this->itemadiantamento = $apiItem->getItemadiantamento($adiantamento);
		$apiEmpresa = new apiEmpresa();
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$funcoes = new Funcoes();
			$autorizacao = new Autorizacao();
			if ($_POST['submeter'] == "imprimir"){
				$solicitante = strtoupper($this->dados['adiantamento']->NOME);
				if ($this->dados['adiantamento']->CATEGORIA == "A"){
					if ($this->dados['adiantamento']->SITUACAO == 0 || $this->dados['adiantamento']->SITUACAO == 1 || $this->dados['adiantamento']->SITUACAO == 2){
						$valor = ($this->dados['adiantamento']->VAL_ADIANTAMENTO > 0) ? $this->dados['adiantamento']->VAL_ADIANTAMENTO : 0;
						$valor = str_replace(",", ".", $valor);
						$html = "Eu, <b><u>{$solicitante}</u></b>, Mat: {$this->dados['adiantamento']->CONTRATO} funcion�rio da empresa <b><u>{$this->dados['adiantamento']->RAZAO_SOCIAL}</u></b> lotado no Depto. <b><u>{$this->dados['adiantamento']->DEPARTAMENTO}</u></b> solicito o valor de <b><u>R$ ".number_format($valor, 2, ",", ".")." (".iconv('UTF-8', 'windows-1252', $funcoes->valorPorextenso($valor,false)).")</u></b>, para custear despesas <b><u>{$this->dados['adiantamento']->DES_ADIANTAMENTO}</u></b>, a ser utilizado no per�odo de <b><u>{$this->dados['adiantamento']->DTA_INICIO}</u></b> at� <b><u>{$this->dados['adiantamento']->DTA_FIM}</b></u>, e estou de acordo com as normas, processos e regimento do GRUPO M�NACO.";
						if ($this->dados['adiantamento']->EM == "AB" || $this->dados['adiantamento']->EM == "DF"){
							$val = str_replace(",", ".", $this->dados['adiantamento']->CP_VALOR);
							$html .= "Bem como autorizo o DP - Departamento de Pessoa � realizar o desconto no valor de <b><u>R$ ".number_format($val, 2, ",", ".")." (".iconv('UTF-8', 'windows-1252', $funcoes->valorPorextenso($val,false)).")</u></b>, referente a diferen�a da presta��o de contas em meus vencimentos na folha de pagamento ou rescis�o de contrato trabalho.";
						}
						$pdf = new \PDF_HTML();
						$pdf->AddPage();
						$pdf->Rect(8, 10, 194, 265, 'D');
						$pdf->SetMargins(8, 8, 8);
						//Cabe�alho
						$empo = $apiEmpresa->geEmpresarevenda($this->dados['adiantamento']->EMPRESA_ORIGEM);
						if ($empo->EMPRESA == "1"){
							$pdf->Image(APP_ROOT."content/geral/img/vwf.png",30,15,30,28);
						}elseif ($empo->EMPRESA == "2"){
							$pdf->Image(APP_ROOT."content/geral/img/motof.png",30,15,30,28);
						}elseif ($empo->EMPRESA == "3"){
							$pdf->Image(APP_ROOT."content/geral/img/vwf.png",30,15,30,28);
						}elseif ($empo->EMPRESA == "4"){
							$pdf->Image(APP_ROOT."content/geral/img/vwf.png",30,15,30,28);
						}elseif ($empo->EMPRESA == "5"){
							$pdf->Image(APP_ROOT."content/geral/img/vwf.png",30,15,30,28);
						}elseif ($empo->EMPRESA == "7"){
							$pdf->Image(APP_ROOT."content/geral/img/motof.png",30,15,30,28);
						}elseif ($empo->EMPRESA == "9"){
							$pdf->Image(APP_ROOT."content/geral/img/motof.png",30,15,30,28);
						}elseif ($empo->EMPRESA == "11"){
							$pdf->Image(APP_ROOT."content/geral/img/vwf.png",30,15,30,28);
						}elseif ($empo->EMPRESA == "13"){
							$pdf->Image(APP_ROOT."content/geral/img/fiatf.png",30,15,30,28);
						}elseif ($empo->EMPRESA == "50"){
							$pdf->Image(APP_ROOT."content/geral/img/vwf.png",30,15,30,28);
						}else{
							$pdf->Image(APP_ROOT."content/geral/img/vwf.png",30,15,30,28);
						}
						$pdf->Image(APP_ROOT."content/geral/img/gmf.png",90,15,31,33);
						$empd = $apiEmpresa->geEmpresarevenda($this->dados['adiantamento']->EMPRESA);
						if ($empd->EMPRESA == "1"){
							$pdf->Image(APP_ROOT."content/geral/img/vwf.png",150,15,30,28);
						}elseif ($empo->EMPRESA == "2"){
							$pdf->Image(APP_ROOT."content/geral/img/motof.png",150,15,30,28);
						}elseif ($empo->EMPRESA == "3"){
							$pdf->Image(APP_ROOT."content/geral/img/vwf.png",150,15,30,28);
						}elseif ($empo->EMPRESA == "4"){
							$pdf->Image(APP_ROOT."content/geral/img/vwf.png",150,15,30,28);
						}elseif ($empo->EMPRESA == "5"){
							$pdf->Image(APP_ROOT."content/geral/img/vwf.png",150,15,30,28);
						}elseif ($empo->EMPRESA == "7"){
							$pdf->Image(APP_ROOT."content/geral/img/motof.png",150,15,30,28);
						}elseif ($empo->EMPRESA == "9"){
							$pdf->Image(APP_ROOT."content/geral/img/motof.png",150,15,30,28);
						}elseif ($empo->EMPRESA == "11"){
							$pdf->Image(APP_ROOT."content/geral/img/vwf.png",150,15,30,28);
						}elseif ($empo->EMPRESA == "13"){
							$pdf->Image(APP_ROOT."content/geral/img/fiatf.png",150,15,30,28);
						}elseif ($empo->EMPRESA == "50"){
							$pdf->Image(APP_ROOT."content/geral/img/vwf.png",150,15,30,28);
						}else{
							$pdf->Image(APP_ROOT."content/geral/img/vwf.png",150,15,30,28);
						}
						$pdf->Ln(45);
						$pdf->SetFont('arial','B',15);
						$pdf->Cell(190,6,"SOLICITA��O DE ADIANTAMENTO  N�: {$this->dados['adiantamento']->ADIANTAMENTO}",0,0,'C');
						$pdf->Ln(15);
						$pdf->SetFont('arial','B',16);
						$pdf->Cell(100,6,"EMPRESA DESTINO: {$this->dados['adiantamento']->EMPRESA_DESTINO}",0,1,'L');
						$pdf->SetFont('arial','B',14);
						$pdf->Cell(100,6,"CENTRO DE CUSTO: ".$cc[$this->dados['adiantamento']->CC]."",0,1,'L');
						$pdf->Cell(100,6,"TIPO DE SOLICITA��O: {$this->dados['adiantamento']->DES_TIPO}",0,1,'L');
						$pdf->Ln(10);
						$pdf->SetFont("arial","",10);					
						//$pdf->WriteHTML($html, $parsed);
						//$pdf->MultiCell(194,4,$parsed,0,'C',false);
						$pdf->WriteHTML($html);
						$pdf->Ln(10);
						$pdf->SetFont('arial','B',10);
						$pdf->Cell(65,4,"INFORMA��ES BANC�RIAS",0,1,'L');
						$banco = ($this->dados['adiantamento']->BANCO != "001") ? ($this->dados['adiantamento']->BANCO != "237") ? ($this->dados['adiantamento']->BANCO == "341") ? "341-Banco Ita� S/A" : "Desconhecido": "237-Banco Bradesco S/A" : "001-Banco do Brasil S/A";
						$pdf->Cell(65,4,"Banco: {$banco}",0,1,'L');
						$pdf->Cell(65,4,"Ag�ncia: {$this->dados['adiantamento']->AGENCIA}",0,1,'L');
						$pdf->Cell(65,4,"Conta: {$this->dados['adiantamento']->CONTA}",0,1,'L');
						$tipo = ($this->dados['adiantamento']->TIPO_CONTA != "S") ? ($this->dados['adiantamento']->TIPO_CONTA != "C") ? ($this->dados['adiantamento']->TIPO_CONTA != "P") ? ($this->dados['adiantamento']->TIPO_CONTA == "CO") ? "Conta Conjunto" : "" : "Conta Poupan�a" : "Conta Corrente" : "Conta Sal�rio";
						$pdf->Cell(65,4,"Tipo: {$tipo}",0,1,'L');
						$pdf->Cell(65,4,"R$: ".number_format($valor, 2, ",", ".")."",0,1,'L');
						$pdf->SetXY(8, 220);
						$pdf->SetFont('arial','B',10);
						$pdf->Cell(65,4,"Autoriza��o do Solicitante",0,0,'L');
						$pdf->Cell(65,4,"Autoriza��o do Gestor",0,0,'L');
						$pdf->Cell(65,4,"Autoriza��o do Financeiro",0,1,'L');
						$pdf->SetFont('arial','',7);
						//1
						$pdf->Cell(65,3,"Data Solicita��o: {$this->dados['adiantamento']->DTA_CADASTRO}",0,0,'L');
						sort($this->autorizacao);
						if (isset($this->autorizacao[0]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Data Solicita��o: {$this->autorizacao[0]->DTA_SOLICITACAO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Data Solicita��o: {$this->autorizacao[1]->DTA_SOLICITACAO}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//2
						$pdf->Cell(65,3,"Situa��o: Aprova��o do Solicitante",0,0,'L');
						if (isset($this->autorizacao[0]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Situa��o: Aprova��o do Gestor",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Situa��o: Aprova��o do Financeiro",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//3
						$pdf->Cell(65,3,"Autorizante: {$this->dados['adiantamento']->NOME}",0,0,'L');
						if (isset($this->autorizacao[0]->DESTINATARIO)){
							$pdf->Cell(65,3,"Destinat�rio: {$this->autorizacao[0]->NOME_DESTINATARIO}",0,0,'L');
						}else{
							$pdf->Cell(65,0,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->AUTORIZANTE)){
							$pdf->Cell(65,3,"Autorizante: {$this->autorizacao[1]->NOME_AUTORIZANTE}",0,0,'L');
							$pdf->Cell(65,3,"",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//4
						$pdf->Cell(65,3,"Data A��o: {$this->dados['adiantamento']->DTA_CADASTRO}",0,0,'L');
						if (isset($this->autorizacao[0]->AUTORIZANTE)){
							$pdf->Cell(65,3,"Autorizante: {$this->autorizacao[0]->NOME_AUTORIZANTE}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->DTA_ACAO)){
							$pdf->Cell(65.6,3,"Data A��o: {$this->autorizacao[1]->DTA_ACAO}",0,0,'L');
							$pdf->Cell(65,3,"",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//5
						$pdf->Cell(65,3,"Autorizado: Sim",0,0,'L');
						if (isset($this->autorizacao[0]->DTA_ACAO)){
							$pdf->Cell(65,3,"Data A��o: {$this->autorizacao[0]->DTA_ACAO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->AUTORIZADO)){
							$autorizado = ($this->autorizacao[1]->AUTORIZADO == 'S') ? 'Sim' : 'N�o';
							$pdf->Cell(65,3,"Autorizado: {$autorizado}",0,0,'L');
							$pdf->Cell(65,3,"",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//6
						$pdf->Cell(65,3,"",0,0,'L');
						if (isset($this->autorizacao[0]->AUTORIZADO)){
							$autorizado = ($this->autorizacao[0]->AUTORIZADO == 'S') ? 'Sim' : 'N�o';
							$pdf->Cell(65,3,"Autorizado: {$autorizado}",0,0,'L');	
						}
						$pdf->Output("{$this->dados['adiantamento']->ADIANTAMENTO}-".date("d-m-Y").".pdf","D");
					}else{
						if (str_replace(",", ".", $this->dados['adiantamento']->VAL_RECEBER) > 0){
							$despesa = str_replace(",", ".", $this->dados['adiantamento']->VAL_ADIANTAMENTO) + str_replace(",", ".", $this->dados['adiantamento']->VAL_RECEBER);
						}elseif (str_replace(",", ".",$this->dados['adiantamento']->VAL_DEVOLVER) > 0){
							$despesa = str_replace(",", ".", $this->dados['adiantamento']->VAL_ADIANTAMENTO) - str_replace(",", ".", $this->dados['adiantamento']->VAL_DEVOLVER);
						}else{
							$despesa = str_replace(",", ".", $this->dados['adiantamento']->VAL_ADIANTAMENTO);
						}
						$valor = ($this->dados['adiantamento']->VAL_ADIANTAMENTO > 0) ? $this->dados['adiantamento']->VAL_ADIANTAMENTO : 0;
						$valor = str_replace(",", ".", $valor);
						$valor_receber = ($this->dados['adiantamento']->VAL_RECEBER > 0) ? $this->dados['adiantamento']->VAL_RECEBER : 0;
						$valor_receber = str_replace(",", ".", $valor_receber);
						$valor_devolver = ($this->dados['adiantamento']->VAL_DEVOLVER > 0) ? $this->dados['adiantamento']->VAL_DEVOLVER : 0;
						$valor_devolver = str_replace(",", ".", $valor_devolver);
						$html = "Eu, <b><u>{$solicitante}</u></b>, Mat: {$this->dados['adiantamento']->CONTRATO} funcion�rio da empresa <b><u>{$this->dados['adiantamento']->RAZAO_SOCIAL}</u></b> lotado no Depto. <b><u>{$this->dados['adiantamento']->DEPARTAMENTO}</u></b> solicito o valor de <b><u>R$ ".number_format($valor, 2, ",", ".")." (".iconv('UTF-8', 'windows-1252', $funcoes->valorPorextenso($valor,false)).")</u></b>, para custear despesas <b><u>{$this->dados['adiantamento']->DES_ADIANTAMENTO}</u></b>, a ser utilizado no per�odo de <b><u>{$this->dados['adiantamento']->DTA_INICIO}</u></b> at� <b><u>{$this->dados['adiantamento']->DTA_FIM}</b></u>, e estou de acordo com as normas, processos e regimento do GRUPO M�NACO.";
						if ($this->dados['adiantamento']->EM == "AB" || $this->dados['adiantamento']->EM == "DF"){
							$val = str_replace(",", ".", $this->dados['adiantamento']->CP_VALOR);
							$html .= "Bem como autorizo o DP - Departamento de Pessoa � realizar o desconto no valor de <b><u>R$ ".number_format($val, 2, ",", ".")." (".iconv('UTF-8', 'windows-1252', $funcoes->valorPorextenso($val,false)).")</u></b>, referente a diferen�a da presta��o de contas em meus vencimentos na folha de pagamento ou rescis�o de contrato trabalho.";
						}
						$pdf = new \PDF_HTML();
						$pdf->AddPage();
						$pdf->Rect(8, 10, 194, 265, 'D');
						$pdf->SetMargins(8, 8, 8);
						//Cabe�alho
						$empo = $apiEmpresa->geEmpresarevenda($this->dados['adiantamento']->EMPRESA_ORIGEM);
						if ($empo->EMPRESA == "1"){
							$pdf->Image(APP_ROOT."content/geral/img/vwf.png",30,15,30,28);
						}elseif ($empo->EMPRESA == "2"){
							$pdf->Image(APP_ROOT."content/geral/img/motof.png",30,15,30,28);
						}elseif ($empo->EMPRESA == "3"){
							$pdf->Image(APP_ROOT."content/geral/img/vwf.png",30,15,30,28);
						}elseif ($empo->EMPRESA == "4"){
							$pdf->Image(APP_ROOT."content/geral/img/vwf.png",30,15,30,28);
						}elseif ($empo->EMPRESA == "5"){
							$pdf->Image(APP_ROOT."content/geral/img/vwf.png",30,15,30,28);
						}elseif ($empo->EMPRESA == "7"){
							$pdf->Image(APP_ROOT."content/geral/img/motof.png",30,15,30,28);
						}elseif ($empo->EMPRESA == "9"){
							$pdf->Image(APP_ROOT."content/geral/img/motof.png",30,15,30,28);
						}elseif ($empo->EMPRESA == "11"){
							$pdf->Image(APP_ROOT."content/geral/img/vwf.png",30,15,30,28);
						}elseif ($empo->EMPRESA == "13"){
							$pdf->Image(APP_ROOT."content/geral/img/fiatf.png",30,15,30,28);
						}elseif ($empo->EMPRESA == "50"){
							$pdf->Image(APP_ROOT."content/geral/img/vwf.png",30,15,30,28);
						}else{
							$pdf->Image(APP_ROOT."content/geral/img/vwf.png",30,15,30,28);
						}
						$pdf->Image(APP_ROOT."content/geral/img/gmf.png",90,15,31,33);
						$empd = $apiEmpresa->geEmpresarevenda($this->dados['adiantamento']->EMPRESA);
						if ($empd->EMPRESA == "1"){
							$pdf->Image(APP_ROOT."content/geral/img/vwf.png",150,15,30,28);
						}elseif ($empo->EMPRESA == "2"){
							$pdf->Image(APP_ROOT."content/geral/img/motof.png",150,15,30,28);
						}elseif ($empo->EMPRESA == "3"){
							$pdf->Image(APP_ROOT."content/geral/img/vwf.png",150,15,30,28);
						}elseif ($empo->EMPRESA == "4"){
							$pdf->Image(APP_ROOT."content/geral/img/vwf.png",150,15,30,28);
						}elseif ($empo->EMPRESA == "5"){
							$pdf->Image(APP_ROOT."content/geral/img/vwf.png",150,15,30,28);
						}elseif ($empo->EMPRESA == "7"){
							$pdf->Image(APP_ROOT."content/geral/img/motof.png",150,15,30,28);
						}elseif ($empo->EMPRESA == "9"){
							$pdf->Image(APP_ROOT."content/geral/img/motof.png",150,15,30,28);
						}elseif ($empo->EMPRESA == "11"){
							$pdf->Image(APP_ROOT."content/geral/img/vwf.png",150,15,30,28);
						}elseif ($empo->EMPRESA == "13"){
							$pdf->Image(APP_ROOT."content/geral/img/fiatf.png",150,15,30,28);
						}elseif ($empo->EMPRESA == "50"){
							$pdf->Image(APP_ROOT."content/geral/img/vwf.png",150,15,30,28);
						}else{
							$pdf->Image(APP_ROOT."content/geral/img/vwf.png",150,15,30,28);
						}
						$pdf->Ln(45);
						$pdf->SetFont('arial','B',15);
						$pdf->Cell(190,6,"SOLICITA��O DE ADIANTAMENTO  N�: {$this->dados['adiantamento']->ADIANTAMENTO}",0,0,'C');
						$pdf->Ln(15);
						$pdf->SetFont('arial','B',16);
						$pdf->Cell(100,6,"EMPRESA DESTINO: {$this->dados['adiantamento']->EMPRESA_DESTINO}",0,1,'L');
						$pdf->SetFont('arial','B',14);
						$pdf->Cell(100,6,"CENTRO DE CUSTO: ".$cc[$this->dados['adiantamento']->CC]."",0,1,'L');
						$pdf->Cell(100,6,"TIPO DE SOLICITA��O: {$this->dados['adiantamento']->DES_TIPO}",0,1,'L');
						$pdf->Ln(10);
						$pdf->SetFont("arial","",10);
						$pdf->WriteHTML($html);
						$pdf->Ln(10);
						$pdf->SetFont('arial','B',10);
						$pdf->Cell(65,4,"INFORMA��ES BANC�RIAS",0,1,'L');
						$banco = ($this->dados['adiantamento']->BANCO != "001") ? ($this->dados['adiantamento']->BANCO != "237") ? ($this->dados['adiantamento']->BANCO == "341") ? "341-Banco Ita� S/A" : "Desconhecido": "237-Banco Bradesco S/A" : "001-Banco do Brasil S/A";
						$pdf->Cell(65,4,"Banco: {$banco}",0,1,'L');
						$pdf->Cell(65,4,"Ag�ncia: {$this->dados['adiantamento']->AGENCIA}",0,1,'L');
						$pdf->Cell(65,4,"Conta: {$this->dados['adiantamento']->CONTA}",0,1,'L');
						$tipo = ($this->dados['adiantamento']->TIPO_CONTA != "S") ? ($this->dados['adiantamento']->TIPO_CONTA != "C") ? ($this->dados['adiantamento']->TIPO_CONTA != "P") ? ($this->dados['adiantamento']->TIPO_CONTA == "CO") ? "Conta Conjunto" : "" : "Conta Poupan�a" : "Conta Corrente" : "Conta Sal�rio";
						$pdf->Cell(65,4,"Tipo: {$tipo}",0,1,'L');
						$pdf->Cell(65,4,"R$: ".number_format($valor, 2, ",", ".")."",0,1,'L');
						$pdf->Ln(3);
						$pdf->SetMargins(14, 14, 14);
						$pdf->SetWidths(array(20,27,27,27,27,27,27));
						$pdf->Row(array());
						$pdf->Row(array('Item','Descricao','Documento','Fornecedor','Data','Valor','Financeiro'),'arial',8,'B');
						foreach ($this->itemadiantamento as $rs){
							$val = number_format(str_replace(",", ".", $rs->VALOR), 2, ",", ".");
							if (isset($rs->FINANCEIRO)){
								$financeiro = number_format(str_replace(",", ".", $rs->FINANCEIRO), 2, ",", ".");
							}else{
								$financeiro = number_format(str_replace(",", ".", $rs->VALOR), 2, ",", ".");
							}
							$pdf->Row(array($rs->DES_ITEM, $rs->DESCRICAO, $rs->DOCUMENTO, $rs->FORNECEDOR, $rs->DATA, $val, $financeiro),'arial',7,'');
						}
						
						$pdf->Ln(3);
						$pdf->SetMargins(14, 14, 14);
						$pdf->SetWidths(array(45,45,45,45));
						$pdf->Row(array());
						$pdf->Row(array("VALOR ADIANTAMENTO: R$:".number_format($valor, 2, ",", ".")."","VALOR DESPESAS: R$:".number_format($despesa, 2, ",", ".")."","VALOR RECEBER: R$:".number_format($valor_receber, 2, ",", ".")."","VALOR DEVOLVER: R$:".number_format($valor_devolver, 2, ",", ".").""),'arial',7,'');

						$pdf->SetMargins(8, 8, 8);
						$pdf->Ln(7);
						$pdf->SetFont('arial','B',10);
						$pdf->Cell(65,4,"Autoriza��o do Solicitante",0,0,'L');
						$pdf->Cell(65,4,"Autoriza��o do Gestor",0,0,'L');
						$pdf->Cell(65,4,"Autoriza��o do Financeiro",0,1,'L');
						$pdf->SetFont('arial','',7);
						//1
						$pdf->Cell(65,3,"Data Solicita��o: {$this->dados['adiantamento']->DTA_CADASTRO}",0,0,'L');
						sort($this->autorizacao);
						if (isset($this->autorizacao[0]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Data Solicita��o: {$this->autorizacao[0]->DTA_SOLICITACAO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Data Solicita��o: {$this->autorizacao[1]->DTA_SOLICITACAO}",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//2
						$pdf->Cell(65,3,"Situa��o: Aprova��o do Solicitante",0,0,'L');
						if (isset($this->autorizacao[0]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Situa��o: Aprova��o do Gestor",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->DTA_SOLICITACAO)){
							$pdf->Cell(65,3,"Situa��o: Aprova��o do Financeiro",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//3
						$pdf->Cell(65,3,"Autorizante: {$this->dados['adiantamento']->NOME}",0,0,'L');
						if (isset($this->autorizacao[0]->DESTINATARIO)){
							$pdf->Cell(65,3,"Destinat�rio: {$this->autorizacao[0]->NOME_DESTINATARIO}",0,0,'L');
						}else{
							$pdf->Cell(65,0,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->AUTORIZANTE)){
							$pdf->Cell(65,3,"Autorizante: {$this->autorizacao[1]->NOME_AUTORIZANTE}",0,0,'L');
							$pdf->Cell(65,3,"",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//4
						$pdf->Cell(65,3,"Data A��o: {$this->dados['adiantamento']->DTA_CADASTRO}",0,0,'L');
						if (isset($this->autorizacao[0]->AUTORIZANTE)){
							$pdf->Cell(65,3,"Autorizante: {$this->autorizacao[0]->NOME_AUTORIZANTE}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->DTA_ACAO)){
							$pdf->Cell(65.6,3,"Data A��o: {$this->autorizacao[1]->DTA_ACAO}",0,0,'L');
							$pdf->Cell(65,3,"",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//5
						$pdf->Cell(65,3,"Autorizado: Sim",0,0,'L');
						if (isset($this->autorizacao[0]->DTA_ACAO)){
							$pdf->Cell(65,3,"Data A��o: {$this->autorizacao[0]->DTA_ACAO}",0,0,'L');
						}else{
							$pdf->Cell(65,3,"",0,0,'L');
						}
						if (isset($this->autorizacao[1]->AUTORIZADO)){
							$autorizado = ($this->autorizacao[1]->AUTORIZADO == 'S') ? 'Sim' : 'N�o';
							$pdf->Cell(65,3,"Autorizado: {$autorizado}",0,0,'L');
							$pdf->Cell(65,3,"",0,1,'L');
						}else{
							$pdf->Cell(65,3,"",0,1,'L');
						}
						//6
						$pdf->Cell(65,3,"",0,0,'L');
						if (isset($this->autorizacao[0]->AUTORIZADO)){
							$autorizado = ($this->autorizacao[0]->AUTORIZADO == 'S') ? 'Sim' : 'N�o';
							$pdf->Cell(65,3,"Autorizado: {$autorizado}",0,0,'L');
						}
						ob_start();
						$pdf->Output("{$this->dados['adiantamento']->ADIANTAMENTO}-".date("d-m-Y").".pdf","D");
						ob_end_flush();
					}
				}elseif ($this->dados['adiantamento']->CATEGORIA == "R"){
					if (str_replace(",", ".", $this->dados['adiantamento']->VAL_RECEBER) > 0){
						$despesa = str_replace(",", ".", $this->dados['adiantamento']->VAL_ADIANTAMENTO) + str_replace(",", ".", $this->dados['adiantamento']->VAL_RECEBER);
					}elseif (str_replace(",", ".",$this->dados['adiantamento']->VAL_DEVOLVER) > 0){
						$despesa = str_replace(",", ".", $this->dados['adiantamento']->VAL_ADIANTAMENTO) - str_replace(",", ".", $this->dados['adiantamento']->VAL_DEVOLVER);
					}else{
						$despesa = str_replace(",", ".", $this->dados['adiantamento']->VAL_ADIANTAMENTO);
					}
					$valor = ($this->dados['adiantamento']->VAL_RECEBER > 0) ? $this->dados['adiantamento']->VAL_RECEBER : 0;
					$valor = str_replace(",", ".", $valor);
					$valor_adiantamento = ($this->dados['adiantamento']->VAL_ADIANTAMENTO > 0) ? $this->dados['adiantamento']->VAL_ADIANTAMENTO : 0;
					$valor_adiantamento = str_replace(",", ".", $valor_adiantamento);
					$valor_devolver = ($this->dados['adiantamento']->VAL_DEVOLVER > 0) ? $this->dados['adiantamento']->VAL_DEVOLVER : 0;
					$valor_devolver = str_replace(",", ".", $valor_devolver);
					$html = "Eu, <b><u>{$solicitante}</u></b>, Mat: {$this->dados['adiantamento']->CONTRATO} funcion�rio da empresa <b><u>{$this->dados['adiantamento']->RAZAO_SOCIAL}</u></b> lotado no Depto. <b><u>{$this->dados['adiantamento']->DEPARTAMENTO}</u></b> solicito o valor de <b><u>R$ ".number_format($valor, 2, ",", ".")." (".iconv('UTF-8', 'windows-1252', $funcoes->valorPorextenso($valor,false)).")</u></b>, para reembolso <b><u>{$this->dados['adiantamento']->DES_ADIANTAMENTO}</u></b>, no per�odo de <b><u>{$this->dados['adiantamento']->DTA_INICIO}</u></b> at� <b><u>{$this->dados['adiantamento']->DTA_FIM}</b></u>, e estou de acordo com as normas, processos e regimento do GRUPO M�NACO.";
					$pdf = new \PDF_HTML();
					$pdf->AddPage();
					$pdf->Rect(8, 10, 194, 265, 'D');
					$pdf->SetMargins(8, 8, 8);
					//Cabe�alho
					$empo = $apiEmpresa->geEmpresarevenda($this->dados['adiantamento']->EMPRESA_ORIGEM);
					if ($empo->EMPRESA == "1"){
						$pdf->Image(APP_ROOT."content/geral/img/vwf.png",30,15,30,28);
					}elseif ($empo->EMPRESA == "2"){
						$pdf->Image(APP_ROOT."content/geral/img/motof.png",30,15,30,28);
					}elseif ($empo->EMPRESA == "3"){
						$pdf->Image(APP_ROOT."content/geral/img/vwf.png",30,15,30,28);
					}elseif ($empo->EMPRESA == "4"){
						$pdf->Image(APP_ROOT."content/geral/img/vwf.png",30,15,30,28);
					}elseif ($empo->EMPRESA == "5"){
						$pdf->Image(APP_ROOT."content/geral/img/vwf.png",30,15,30,28);
					}elseif ($empo->EMPRESA == "7"){
						$pdf->Image(APP_ROOT."content/geral/img/motof.png",30,15,30,28);
					}elseif ($empo->EMPRESA == "9"){
						$pdf->Image(APP_ROOT."content/geral/img/motof.png",30,15,30,28);
					}elseif ($empo->EMPRESA == "11"){
						$pdf->Image(APP_ROOT."content/geral/img/vwf.png",30,15,30,28);
					}elseif ($empo->EMPRESA == "13"){
						$pdf->Image(APP_ROOT."content/geral/img/fiatf.png",30,15,30,28);
					}elseif ($empo->EMPRESA == "50"){
						$pdf->Image(APP_ROOT."content/geral/img/vwf.png",30,15,30,28);
					}else{
						$pdf->Image(APP_ROOT."content/geral/img/vwf.png",30,15,30,28);
					}
					$pdf->Image(APP_ROOT."content/geral/img/gmf.png",90,15,31,33);
					$empd = $apiEmpresa->geEmpresarevenda($this->dados['adiantamento']->EMPRESA);
					if ($empd->EMPRESA == "1"){
						$pdf->Image(APP_ROOT."content/geral/img/vwf.png",150,15,30,28);
					}elseif ($empo->EMPRESA == "2"){
						$pdf->Image(APP_ROOT."content/geral/img/motof.png",150,15,30,28);
					}elseif ($empo->EMPRESA == "3"){
						$pdf->Image(APP_ROOT."content/geral/img/vwf.png",150,15,30,28);
					}elseif ($empo->EMPRESA == "4"){
						$pdf->Image(APP_ROOT."content/geral/img/vwf.png",150,15,30,28);
					}elseif ($empo->EMPRESA == "5"){
						$pdf->Image(APP_ROOT."content/geral/img/vwf.png",150,15,30,28);
					}elseif ($empo->EMPRESA == "7"){
						$pdf->Image(APP_ROOT."content/geral/img/motof.png",150,15,30,28);
					}elseif ($empo->EMPRESA == "9"){
						$pdf->Image(APP_ROOT."content/geral/img/motof.png",150,15,30,28);
					}elseif ($empo->EMPRESA == "11"){
						$pdf->Image(APP_ROOT."content/geral/img/vwf.png",150,15,30,28);
					}elseif ($empo->EMPRESA == "13"){
						$pdf->Image(APP_ROOT."content/geral/img/fiatf.png",150,15,30,28);
					}elseif ($empo->EMPRESA == "50"){
						$pdf->Image(APP_ROOT."content/geral/img/vwf.png",150,15,30,28);
					}else{
						$pdf->Image(APP_ROOT."content/geral/img/vwf.png",150,15,30,28);
					}
					$pdf->Ln(45);
					$pdf->SetFont('arial','B',15);
					$pdf->Cell(190,6,"SOLICITA��O DE REEMBOLSO  N�: {$this->dados['adiantamento']->ADIANTAMENTO}",0,0,'C');
					$pdf->Ln(15);
					$pdf->SetFont('arial','B',16);
					$pdf->Cell(100,6,"EMPRESA DESTINO: {$this->dados['adiantamento']->EMPRESA_DESTINO}",0,1,'L');
					$pdf->SetFont('arial','B',14);
					$pdf->Cell(100,6,"CENTRO DE CUSTO: ".$cc[$this->dados['adiantamento']->CC]."",0,1,'L');
					$pdf->Cell(100,6,"TIPO DE SOLICITA��O: {$this->dados['adiantamento']->DES_TIPO}",0,1,'L');
					$pdf->Ln(10);
					$pdf->SetFont("arial","",10);
					$pdf->WriteHTML($html);
					$pdf->Ln(10);
					$pdf->SetFont('arial','B',10);
					$pdf->Cell(65,4,"INFORMA��ES BANC�RIAS",0,1,'L');
					$banco = ($this->dados['adiantamento']->BANCO != "001") ? ($this->dados['adiantamento']->BANCO != "237") ? ($this->dados['adiantamento']->BANCO == "341") ? "341-Banco Ita� S/A" : "Desconhecido": "237-Banco Bradesco S/A" : "001-Banco do Brasil S/A";
					$pdf->Cell(65,4,"Banco: {$banco}",0,1,'L');
					$pdf->Cell(65,4,"Ag�ncia: {$this->dados['adiantamento']->AGENCIA}",0,1,'L');
					$pdf->Cell(65,4,"Conta: {$this->dados['adiantamento']->CONTA}",0,1,'L');
					$tipo = ($this->dados['adiantamento']->TIPO_CONTA != "S") ? ($this->dados['adiantamento']->TIPO_CONTA != "C") ? ($this->dados['adiantamento']->TIPO_CONTA != "P") ? ($this->dados['adiantamento']->TIPO_CONTA == "CO") ? "Conta Conjunto" : "" : "Conta Poupan�a" : "Conta Corrente" : "Conta Sal�rio";
					$pdf->Cell(65,4,"Tipo: {$tipo}",0,1,'L');
					$pdf->Cell(65,4,"R$: ".number_format($valor, 2, ",", ".")."",0,1,'L');
					$pdf->Ln(3);
					$pdf->SetMargins(14, 14, 14);
					$pdf->SetWidths(array(20,27,27,27,27,27,27));
					$pdf->Row(array());
					$pdf->Row(array('Item','Descricao','Documento','Fornecedor','Data','Valor'),'arial',8,'B');
					foreach ($this->itemadiantamento as $rs){
						$val = number_format(str_replace(",", ".", $rs->VALOR), 2, ",", ".");
						$pdf->Row(array($rs->DES_ITEM, $rs->DESCRICAO, $rs->DOCUMENTO, $rs->FORNECEDOR, $rs->DATA, $val),'arial',7,'');
					}
					$pdf->Ln(3);
					$pdf->SetMargins(14, 14, 14);
					$pdf->SetWidths(array(45,45,45, 45));
					$pdf->Row(array());
					$pdf->Row(array("VALOR ADIANTAMENTO: R$:".number_format($valor_adiantamento, 2, ",", ".")."","VALOR DESPESAS: R$:".number_format($despesas, 2, ",", ".")."","VALOR RECEBER: R$:".number_format($valor, 2, ",", ".")."","VALOR DEVOLVER: R$:".number_format($valor_devolver, 2, ",",".").""),'arial',7,'');
					
					$pdf->SetMargins(8, 8, 8);
					//$pdf->MultiCell(194,4,$parsed,0,'C',false);
					//$pdf->SetXY(8, 220);
					$pdf->Ln(7);
					$pdf->SetFont('arial','B',10);
					$pdf->Cell(65,4,"Autoriza��o do Solicitante",0,0,'L');
					$pdf->Cell(65,4,"Autoriza��o do Gestor",0,0,'L');
					$pdf->Cell(65,4,"Autoriza��o do Financeiro",0,1,'L');
					$pdf->SetFont('arial','',7);
					//1
					$pdf->Cell(65,3,"Data Solicita��o: {$this->dados['adiantamento']->DTA_CADASTRO}",0,0,'L');
					sort($this->autorizacao);
					if (isset($this->autorizacao[0]->DTA_SOLICITACAO)){
						$pdf->Cell(65,3,"Data Solicita��o: {$this->autorizacao[0]->DTA_SOLICITACAO}",0,0,'L');
					}else{
						$pdf->Cell(65,3,"",0,0,'L');
					}
					if (isset($this->autorizacao[1]->DTA_SOLICITACAO)){
						$pdf->Cell(65,3,"Data Solicita��o: {$this->autorizacao[1]->DTA_SOLICITACAO}",0,1,'L');
					}else{
						$pdf->Cell(65,3,"",0,1,'L');
					}
					//2
					$pdf->Cell(65,3,"Situa��o: Aprova��o do Solicitante",0,0,'L');
					if (isset($this->autorizacao[0]->DTA_SOLICITACAO)){
						$pdf->Cell(65,3,"Situa��o: Aprova��o do Gestor",0,0,'L');
					}else{
						$pdf->Cell(65,3,"",0,0,'L');
					}
					if (isset($this->autorizacao[1]->DTA_SOLICITACAO)){
						$pdf->Cell(65,3,"Situa��o: Aprova��o do Financeiro",0,1,'L');
					}else{
						$pdf->Cell(65,3,"",0,1,'L');
					}
					//3
					$pdf->Cell(65,3,"Autorizante: {$this->dados['adiantamento']->NOME}",0,0,'L');
					if (isset($this->autorizacao[0]->DESTINATARIO)){
						$pdf->Cell(65,3,"Destinat�rio: {$this->autorizacao[0]->NOME_DESTINATARIO}",0,0,'L');
					}else{
						$pdf->Cell(65,0,"",0,0,'L');
					}
					if (isset($this->autorizacao[1]->AUTORIZANTE)){
						$pdf->Cell(65,"Autorizante: {$this->autorizacao[1]->NOME_AUTORIZANTE}",0,0,'L');
						$pdf->Cell(65,3,"",0,1,'L');
					}else{
						$pdf->Cell(65,3,"",0,1,'L');
					}
					//4
					$pdf->Cell(65,3,"Data A��o: {$this->dados['adiantamento']->DTA_CADASTRO}",0,0,'L');
					if (isset($this->autorizacao[0]->AUTORIZANTE)){
						$pdf->Cell(65,3,"Autorizante: {$this->autorizacao[0]->NOME_AUTORIZANTE}",0,0,'L');
					}else{
						$pdf->Cell(65,3,"",0,0,'L');
					}
					if (isset($this->autorizacao[1]->DTA_ACAO)){
						$pdf->Cell(65,3,"Data A��o: {$this->autorizacao[1]->DTA_ACAO}",0,0,'L');
						$pdf->Cell(65,3,"",0,1,'L');
					}else{
						$pdf->Cell(65,3,"",0,1,'L');
					}
					//5
					$pdf->Cell(65,3,"Autorizado: Sim",0,0,'L');
					if (isset($this->autorizacao[0]->DTA_ACAO)){
						$pdf->Cell(65,3,"Data A��o: {$this->autorizacao[0]->DTA_ACAO}",0,0,'L');
					}else{
						$pdf->Cell(65,3,"",0,0,'L');
					}
					if (isset($this->autorizacao[1]->AUTORIZADO)){
						$autorizado = ($this->autorizacao[1]->AUTORIZADO == 'S') ? 'Sim' : 'N�o';
						$pdf->Cell(65,3,"Autorizado: {$autorizado}",0,0,'L');
						$pdf->Cell(65,3,"",0,1,'L');
					}else{
						$pdf->Cell(65,3,"",0,1,'L');
					}
					//6
					$pdf->Cell(65,3,"",0,0,'L');
					if (isset($this->autorizacao[0]->AUTORIZADO)){
						$autorizado = ($this->autorizacao[0]->AUTORIZADO == 'S') ? 'Sim' : 'N�o';
						$pdf->Cell(65,3,"Autorizado: {$autorizado}",0,0,'L');
					}
					ob_start();
					$pdf->Output("{$this->dados['adiantamento']->ADIANTAMENTO}-".date("d-m-Y").".pdf","D");
					ob_end_flush();
				}
			}elseif ($_POST['submeter'] == "reembolso"){
				$autorizacao->adiantamento = $adiantamento->adiantamento;
				if ($_SESSION['tipo_sessao'] == 5){
					$adiantamento->situacao = 4;
					$adiantamento->situacao_anterior = 4;
				}else{
					$adiantamento->situacao = 3;
					$adiantamento->situacao_anterior = 3;
				}
				$adiantamento->cartao_corporativo = $_POST['cartao_corporativo'];
				$adiantamento->frota = $_POST['frota'];
				if ($adiantamento->frota == 'A'){
					$adiantamento->km_inicial = $_POST['km_inicial'];
					$adiantamento->km_final = $_POST['km_final'];
					$adiantamento->val_km = $funcoes->sanearValor($_POST['val_km']);
				}
				$adiantamento->val_receber = $funcoes->sanearValor($_POST['val_receber']);
				$adiantamento->val_devolver = $funcoes->sanearValor($_POST['val_devolver']);
				$adiantamento->dta_prestacao = date("d/m/Y");
			
				$anexo = $_FILES["anexo"];
				$ane = 1;
				$an = 0;
				$anexos_nomes = array();
				$anexos = "";
				foreach ($anexo['name'] as $key => $v){
					$v = explode(".", $v);
					$exp = strtolower(end($v));
					$anexos_nomes[$an] = "{$_SESSION['usuario_sessao']}-{$adiantamento->adiantamento}-Anexo{$ane}-".date('dmY-His').".{$exp}";
					$anexos .= "ANEXO{$ane}||{$_SESSION['usuario_sessao']}-{$adiantamento->adiantamento}-Anexo{$ane}-".date('dmY-His').".{$exp};;";
					$an = $an + 1;
					$ane = $ane + 1;
				}
				$adiantamento->anexos = substr($anexos,0,-2);
				$sql[$i] = $apiAdiantamento->editAdiantamento($adiantamento);
				$i = $i+1;
				$log = new Log();
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico = "CARTAO_CORPORATIVO||{$adiantamento->cartao_corporativo};;FROTA||{$adiantamento->frota};;KM_INICIAL||{$adiantamento->km_inicial};;KM_FINAL||{$adiantamento->km_final};;VAL_KM||{$adiantamento->val_km};;VAL_RECEBER||{$adiantamento->val_receber};;VAL_DEVOLVER||{$adiantamento->val_devolver};;ANEXOS||{$adiantamento->anexos}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$item = $_POST["item"];
				$descricao = $_POST["descricao"];
				$documento = $_POST["documento"];
				$fornecedor = $_POST["fornecedor"];
				$data = $_POST["data"];
				$valor = $_POST["valor"];
				$itemadiantamento = new Itemadiantamento();
				$itemadiantamento->adiantamento = $adiantamento->adiantamento;
				$ordem = 0;
				foreach ($item as $key => $it) {
					$i = $i+1;
					$ordem = $ordem + 1;
					$itemadiantamento->ordem = $ordem;
					$itemadiantamento->item = $it;
					$itemadiantamento->descricao = strtoupper($funcoes->retiraAcentos(trim($descricao{$key})));
					$itemadiantamento->documento = $documento{$key};
					$itemadiantamento->fornecedor = strtoupper($funcoes->retiraAcentos(trim($fornecedor{$key})));
					$itemadiantamento->data = $data{$key};
					$itemadiantamento->valor = $funcoes->sanearValor($valor{$key});
					$sql[$i] = $apiItem->addItemadiantamento($itemadiantamento);
				}
				if ($_SESSION['tipo_sessao'] == 5){
					$autorizacao->situacao = 3;
					$autorizacao->destinatario = $_SESSION['usuario_sessao'];
					$autorizacao->autorizante = $_SESSION['usuario_sessao'];
					$autorizacao->dta_solicitacao = date("d/m/Y H:i:s");
					$autorizacao->dta_acao = date("d/m/Y H:i:s");
					$autorizacao->autorizado = 'S';
					$i = $i+1;
					$sql[$i] = $apiAdiantamento->addAutorizacao($autorizacao);
					$i = $i+1;
					$autorizacao = new Autorizacao();
					$autorizacao->adiantamento = $adiantamento->adiantamento;
					$autorizacao->situacao = 4;
					$autorizacao->dta_solicitacao = date("d/m/Y H:i:s");
					$sql[$i] = $apiAdiantamento->addAutorizacao($autorizacao);
				}else{
					$adiantamento->situacao = 0;
					$autAnterior = $apiAdiantamento->getAutorizacao($adiantamento);
					$autorizacao->situacao = 3;
					$autorizacao->destinatario = $autAnterior->DESTINATARIO;
					$autorizacao->dta_solicitacao = date("d/m/Y H:i:s");
					$i = $i+1;
					$sql[$i] = $apiAdiantamento->addAutorizacao($autorizacao);
				}
			}elseif ($this->dados['adiantamento']->SITUACAO == 8 || $this->dados['adiantamento']->SITUACAO == 9){
				if ($_POST['submeter'] == "alterar"){
					$alteracao = "";
					if(isset($_POST['des_adiantamento'])){
						$des_adiantamento = str_replace("\r\n","<br>",$_POST['des_adiantamento']);
						if ($this->dados['adiantamento']->DES_ADIANTAMENTO != $des_adiantamento){
							$adiantamento->des_adiantamento = $des_adiantamento;
							$alteracao .= "<b>De Descri��o:</b> {$this->dados['adiantamento']->DES_ADIANTAMENTO} <b>Para Descri��o:</b> {$des_adiantamento}<br><br>";
						}
					}
					if(isset($_POST['cc'])){
						if ($this->dados['adiantamento']->CC != $_POST['cc']){
							$adiantamento->cc = $_POST['cc'];
							$alteracao .= "<b>De CC:</b> {$cc[$this->dados['adiantamento']->CC]} <b>Para CC:</b> {$cc[$_POST['cc']]}<br><br>";
						}
					}
					if(isset($_POST['tipo'])){
						if ($this->dados['adiantamento']->TIPO != $_POST['tipo']){
							$adiantamento->tipo = $_POST['tipo'];
							$alteracao .= "<b>De Tipo:</b> {$this->tipo[$this->dados['adiantamento']->TIPO]['des_tipo']} <b>Para Tipo:</b> {$this->tipo[$_POST['tipo']]['des_tipo']}<br><br>";
						}
					}
					if(isset($_POST['empresa'])){
						if ($this->dados['adiantamento']->EMPRESA != $_POST['empresa']){
							$adiantamento->empresa = $_POST['empresa'];
							$alteracao .= "<b>De Empresa:</b> {$this->empresa[$this->dados['adiantamento']->EMPRESA]['des_empresa']} <b>Para Empresa:</b> {$this->empresa[$_POST['empresa']]['des_empresa']}<br><br>";
						}
					}
					if(isset($_POST['banco'])){
						if ($this->dados['adiantamento']->BANCO != $_POST['banco']){
							$adiantamento->banco = $_POST['banco'];
							$alteracao .= "<b>De Banco:</b> {$this->dados['adiantamento']->BANCO} <b>Para Banco:</b> {$_POST['banco']}<br><br>";
						}
					}
					if(isset($_POST['agencia'])){
						if ($this->dados['adiantamento']->AGENCIA != $_POST['agencia']){
							$adiantamento->agencia = $_POST['agencia'];
							$alteracao .= "<b>De Ag�ncia:</b> {$this->dados['adiantamento']->AGENCIA} <b>Para Ag�ncia:</b> {$_POST['agencia']}<br><br>";
						}
					}
					if(isset($_POST['conta'])){
						if ($this->dados['adiantamento']->CONTA != $_POST['conta']){
							$adiantamento->conta = $_POST['conta'];
							$alteracao .= "<b>De Conta:</b> {$this->dados['adiantamento']->CONTA} <b>Para Conta:</b> {$_POST['conta']}<br><br>";
						}
					}
					if(isset($_POST['tipo_conta'])){
						if ($this->dados['adiantamento']->TIPO_CONTA != $_POST['tipo_conta']){
							$adiantamento->tipo_conta = $_POST['tipo_conta'];
							$alteracao .= "<b>De Tipo de Conta:</b> {$tipo_conta[$this->dados['adiantamento']->TIPO_CONTA]} <b>Para Tipo de Conta:</b> {$tipo_conta[$_POST['tipo_conta']]}<br><br>";
						}
					}
					if(isset($_POST['dta_inicio'])){
						if ($this->dados['adiantamento']->DTA_INICIO != $_POST['dta_inicio']){
							$adiantamento->dta_inicio = $_POST['dta_inicio'];
							$alteracao .= "<b>De Data In�cio:</b> {$this->dados['adiantamento']->DTA_INICIO} <b>Para Data In�cio:</b> {$_POST['dta_inicio']}<br><br>";
						}
					}
					if(isset($_POST['dta_fim'])){
						if ($this->dados['adiantamento']->DTA_FIM != $_POST['dta_fim']){
							$adiantamento->dta_fim = $_POST['dta_fim'];
							$alteracao .= "<b>De Data Fim:</b> {$this->dados['adiantamento']->DTA_FIM} <b>Para Data Fim:</b> {$_POST['dta_fim']}<br><br>";
						}
					}
					if ($this->dados['adiantamento']->CATEGORIA == "R"){
						if ($this->dados['adiantamento']->CARTAO_CORPORATIVO != $_POST['cartao_corporativo']){
							$adiantamento->cartao_corporativo = $_POST['cartao_corporativo'];
							$alteracao .= "<b>De Cart�o</b> {$this->dados['adiantamento']->CARTAO_CORPORATIVO} <b>Para Cart�o:</b> {$_POST['cartao_corporativo']}<br><br>";
						}
						if ($this->dados['adiantamento']->FROTA != $_POST['frota']){
							$adiantamento->frota = $_POST['frota'];
							$alteracao .= "<b>De Frota</b> {$this->dados['adiantamento']->FROTA} <b>Para Frota:</b> {$_POST['frota']}<br><br>";
						}
						if ($_POST['frota'] == 'A'){
							if ($this->dados['adiantamento']->KM_INICIAL != $_POST['km_inicial']){
								$adiantamento->km_inicial = $_POST['km_inicial'];
								$alteracao .= "<b>De Km Inicial</b> {$this->dados['adiantamento']->KM_INICIAL} <b>Para Km Inicial:</b> {$_POST['km_inicial']}<br><br>";
							}
							if ($this->dados['adiantamento']->KM_FINAL != $_POST['km_final']){
								$adiantamento->km_final = $_POST['km_final'];
								$alteracao .= "<b>De Km Final</b> {$this->dados['adiantamento']->KM_FINAL} <b>Para Km Final:</b> {$_POST['km_final']}<br><br>";
							}
							$val_km = $funcoes->sanearValor($_POST['val_km']);
							if ($this->dados['adiantamento']->VAL_KM != $val_km){
								$adiantamento->val_km = $val_km;
								$alteracao .= "<b>De Valor Km</b> {$this->dados['adiantamento']->VAL_KM} <b>Para Valor Km:</b> {$_POST['val_km']}<br><br>";
							}
						}
						$val_receber = $funcoes->sanearValor($_POST['val_receber']);
						if ($this->dados['adiantamento']->VAL_RECEBER != $val_receber){
							$adiantamento->val_receber = $val_receber;
							$alteracao .= "<b>De Valor a Receber:</b> {$this->dados['adiantamento']->VAL_RECEBER} <b>Para Valor a Receber:</b> {$val_receber}<br><br>";
						}
						$anexos = "";
						if (isset($_POST['exclusao'])){
							$strVal = explode(';;', $this->dados['adiantamento']->ANEXOS);
							foreach ($strVal as $va){
								@list($k, $v) = explode('||', $va);
								
								if (!$funcoes->in_array_r("{$v}", $_POST['exclusao'])){
									$anexo_antigo[$k] = $v;
								}else{
									$alteracao .= "<b>Anexo Exclu�do:</b> {$v}<br><br>";
								}
							}
							$anexos = "";
							$ane = 1;
							foreach ($anexo_antigo as $v){
								$anexos .= "ANEXO{$ane}||{$v};;";
								$ane = $ane + 1;
							}
							$anexo = $_FILES["anexo"];
							$an = 0;
							$anexos_nomes = array();
							if ($_FILES["anexo"]["name"][0] != ""){
								foreach ($anexo['name'] as $key => $v){
									$v = explode(".", $v);
									$exp = strtolower(end($v));
									$anexos_nomes[$an] = "{$_SESSION['usuario_sessao']}-{$adiantamento->adiantamento}-Anexo{$ane}-".date('dmY-His').".{$exp}";
									$anexos .= "ANEXO{$ane}||{$_SESSION['usuario_sessao']}-{$adiantamento->adiantamento}-Anexo{$ane}-".date('dmY-His').".{$exp};;";
									$an = $an + 1;
									$ane = $ane + 1;
									$alteracao .= "<b>Anexo Inclu�do:</b> {$v}<br><br>";
								}
							}
						}else{
							if ($_FILES["anexo"]["name"][0] != ""){
								$ane = 0;
								$strVal = explode(';;', $this->dados['adiantamento']->ANEXOS);
								foreach ($strVal as $va){
									$ane = $ane + 1;
								}
								$anexos = "{$this->dados['adiantamento']->ANEXOS};;";
								$anexo = $_FILES["anexo"];
								$an = 0;
								$anexos_nomes = array();
								foreach ($anexo['name'] as $key => $v){
									$ane = $ane + 1;
									$v = explode(".", $v);
									$exp = strtolower(end($v));
									$anexos_nomes[$an] = "{$_SESSION['usuario_sessao']}-{$adiantamento->adiantamento}-Anexo{$ane}-".date('dmY-His').".{$exp}";
									$anexos .= "ANEXO{$ane}||{$_SESSION['usuario_sessao']}-{$adiantamento->adiantamento}-Anexo{$ane}-".date('dmY-His').".{$exp};;";
									$alteracao .= "<b>Anexo Inclu�do:</b> {$anexos_nomes[$an]}<br><br>";
									$an = $an + 1;
								}
							}
						}
						if ($anexos != ""){
							if ($this->dados['adiantamento']->ANEXOS != substr($anexos,0,-2)){
								$adiantamento->anexos = substr($anexos,0,-2);
							}
						}
						$ordem = 0;
						$item = $_POST["item"];
						$descricao = $_POST["descricao"];
						$documento = $_POST["documento"];
						$fornecedor = $_POST["fornecedor"];
						$data = $_POST["data"];
						$valor = $_POST["valor"];
						foreach ($item as $key => $it) {
							if (isset($this->itemadiantamento[$ordem])){
								if (isset($sql[$i])) {
									$i = $i+1;
								}
								$itemadiantamento = new Itemadiantamento();
								$itemadiantamento->adiantamento = $adiantamento->adiantamento;
								$itemadiantamento->ordem = $ordem + 1;
								if ($this->itemadiantamento[$ordem]->ITEM != $it){
									$itemadiantamento->item = $it;
									$n = $ordem + 1;
									$alteracao .= "<b>De Item {$n}:</b> {$this->itemadiantamento[$ordem]->ITEM} <b>Para Item {$n}:</b> {$itemadiantamento->item}<br><br>";
								}
								if ($this->itemadiantamento[$ordem]->DESCRICAO != strtoupper($funcoes->retiraAcentos(trim($descricao{$key})))){
									$itemadiantamento->descricao = strtoupper($funcoes->retiraAcentos(trim($descricao{$key})));
									$n = $ordem + 1;
									$alteracao .= "<b>De Item {$n} Descricao:</b> {$this->itemadiantamento[$ordem]->DESCRICAO} <b>Para Item {$n} Descri��o:</b> {$itemadiantamento->descricao}<br><br>";
								}
								if ($this->itemadiantamento[$ordem]->DOCUMENTO != $documento{$key}){
									$itemadiantamento->documento = $documento{$key};
									$n = $ordem + 1;
									$alteracao .= "<b>De Item {$n} Documento:</b> {$this->itemadiantamento[$ordem]->DOCUMENTO} <b>Para Item {$n} Documento:</b> {$itemadiantamento->documento}<br><br>";
								}
								if ($this->itemadiantamento[$ordem]->FORNECEDOR != strtoupper($funcoes->retiraAcentos(trim($fornecedor{$key})))){
									$itemadiantamento->fornecedor = strtoupper($funcoes->retiraAcentos(trim($fornecedor{$key})));
									$n = $ordem + 1;
									$alteracao .= "<b>De Item {$n} Fornecedor:</b> {$this->itemadiantamento[$ordem]->FORNECEDOR} <b>Para Item {$n} Fornecedor:</b> {$itemadiantamento->fornecedor}<br><br>";
								}
								if ($this->itemadiantamento[$ordem]->DATA != $data{$key}){
									$itemadiantamento->data = $data{$key};
									$n = $ordem + 1;
									$alteracao .= "<b>De Item {$n} Data:</b> {$this->itemadiantamento[$ordem]->DATA} <b>Para Item {$n} Data:</b> {$itemadiantamento->data}<br><br>";
								}
								if ($this->itemadiantamento[$ordem]->VALOR != $funcoes->sanearValor($valor{$key})){
									$itemadiantamento->valor = $funcoes->sanearValor($valor{$key});
									$n = $ordem + 1;
									$alteracao .= "<b>De Item {$n} Valor:</b> {$this->itemadiantamento[$ordem]->VALOR} <b>Para Item {$n} Valor:</b> {$itemadiantamento->valor}<br><br>";
								}
								$ordem = $ordem + 1;
								if ($itemadiantamento->item != "" || $itemadiantamento->descricao != "" || $itemadiantamento->documento != "" || $itemadiantamento->fornecedor != "" || $itemadiantamento->data != "" || $itemadiantamento->valor != ""){
									$sql[$i] = $apiItem->editItemadiantamento($itemadiantamento);
									$i = $i+1;
								}
							}else{
								if (isset($sql[$i])) {
									$i = $i+1;
								}
								$ordem = $ordem + 1;
								$itemadiantamento->ordem = $ordem;
								$itemadiantamento->item = $it;
								$itemadiantamento->descricao = strtoupper($funcoes->retiraAcentos(trim($descricao{$key})));
								$itemadiantamento->documento = $documento{$key};
								$itemadiantamento->fornecedor = strtoupper($funcoes->retiraAcentos(trim($fornecedor{$key})));
								$itemadiantamento->data = $data{$key};
								$itemadiantamento->valor = $funcoes->sanearValor($valor{$key});
								$sql[$i] = $apiItem->addItemadiantamento($itemadiantamento);
								$i = $i+1;
							}					
						}
					}else{
						if(isset($_POST['val_adiantamento'])){
							$val_adiantamento = $funcoes->sanearValor($_POST['val_adiantamento']);
							if ($this->dados['adiantamento']->VAL_ADIANTAMENTO != $val_adiantamento){
								$adiantamento->val_adiantamento = $val_adiantamento;
								$alteracao .= "<b>De Valor Adiantamento:</b> {$this->dados['adiantamento']->VAL_ADIANTAMENTO} <b>Para Valor Adiantamento:</b> {$val_adiantamento}<br><br>";
							}
						}
						if ($this->dados['adiantamento']->SITUACAO_ANTERIOR == 3 || $this->dados['adiantamento']->SITUACAO_ANTERIOR == 4){
							if ($this->dados['adiantamento']->CARTAO_CORPORATIVO != $_POST['cartao_corporativo']){
								$adiantamento->cartao_corporativo = $_POST['cartao_corporativo'];
								$alteracao .= "<b>De Cart�o</b> {$this->dados['adiantamento']->CARTAO_CORPORATIVO} <b>Para Cart�o:</b> {$_POST['cartao_corporativo']}<br><br>";
							}
							if ($this->dados['adiantamento']->FROTA != $_POST['frota']){
								$adiantamento->frota = $_POST['frota'];
								$alteracao .= "<b>De Frota</b> {$this->dados['adiantamento']->FROTA} <b>Para Frota:</b> {$_POST['frota']}<br><br>";
							}
							if ($_POST['frota'] == 'A'){
								if ($this->dados['adiantamento']->KM_INICIAL != $_POST['km_inicial']){
									$adiantamento->km_inicial = $_POST['km_inicial'];
									$alteracao .= "<b>De Km Inicial</b> {$this->dados['adiantamento']->KM_INICIAL} <b>Para Km Inicial:</b> {$_POST['km_inicial']}<br><br>";
								}
								if ($this->dados['adiantamento']->KM_FINAL != $_POST['km_final']){
									$adiantamento->km_final = $_POST['km_final'];
									$alteracao .= "<b>De Km Final</b> {$this->dados['adiantamento']->KM_FINAL} <b>Para Km Final:</b> {$_POST['km_final']}<br><br>";
								}
								$val_km = $funcoes->sanearValor($_POST['val_km']);
								if ($this->dados['adiantamento']->VAL_KM != $val_km){
									$adiantamento->val_km = $val_km;
									$alteracao .= "<b>De Valor Km</b> {$this->dados['adiantamento']->VAL_KM} <b>Para Valor Km:</b> {$_POST['val_km']}<br><br>";
								}
							}
							$val_receber = $funcoes->sanearValor($_POST['val_receber']);
							if ($this->dados['adiantamento']->VAL_RECEBER != $val_receber){
								$adiantamento->val_receber = $val_receber;
								$alteracao .= "<b>De Valor a Receber:</b> {$this->dados['adiantamento']->VAL_RECEBER} <b>Para Valor a Receber:</b> {$val_receber}<br><br>";
							}
							$val_devolver = $funcoes->sanearValor($_POST['val_devolver']);
							if ($this->dados['adiantamento']->VAL_DEVOLVER != $val_devolver){
								$adiantamento->val_devolver = $val_devolver;
								$alteracao .= "<b>De Valor a Devolver:</b> {$this->dados['adiantamento']->VAL_DEVOLVER} <b>Para Valor a Devolver:</b> {$val_devolver}<br><br>";
							}
							$anexos = "";
							if (isset($_POST['exclusao'])){
								$strVal = explode(';;', $this->dados['adiantamento']->ANEXOS);
								foreach ($strVal as $va){
									@list($k, $v) = explode('||', $va);
									
									if (!$funcoes->in_array_r("{$v}", $_POST['exclusao'])){
										$anexo_antigo[$k] = $v;
									}else{
										$alteracao .= "<b>Anexo Exclu�do:</b> {$v}<br><br>";
									}
								}
								$anexos = "";
								$ane = 1;
								foreach ($anexo_antigo as $v){
									$anexos .= "ANEXO{$ane}||{$v};;";
									$ane = $ane + 1;
								}
								$anexo = $_FILES["anexo"];
								$an = 0;
								$anexos_nomes = array();
								if ($_FILES["anexo"]["name"][0] != ""){
									foreach ($anexo['name'] as $key => $v){
										$v = explode(".", $v);
										$exp = strtolower(end($v));
										$anexos_nomes[$an] = "{$_SESSION['usuario_sessao']}-{$adiantamento->adiantamento}-Anexo{$ane}-".date('dmY-His').".{$exp}";
										$anexos .= "ANEXO{$ane}||{$_SESSION['usuario_sessao']}-{$adiantamento->adiantamento}-Anexo{$ane}-".date('dmY-His').".{$exp};;";
										$an = $an + 1;
										$ane = $ane + 1;
										$alteracao .= "<b>Anexo Inclu�do:</b> {$v}<br><br>";
									}
								}
							}else{
								if ($_FILES["anexo"]["name"][0] != ""){
									$ane = 0;
									$strVal = explode(';;', $this->dados['adiantamento']->ANEXOS);
									foreach ($strVal as $va){
										$ane = $ane + 1;
									}
									$anexos = "{$this->dados['adiantamento']->ANEXOS};;";
									$anexo = $_FILES["anexo"];
									$an = 0;
									$anexos_nomes = array();
									foreach ($anexo['name'] as $key => $v){
										$ane = $ane + 1;
										$v = explode(".", $v);
										$exp = strtolower(end($v));
										$anexos_nomes[$an] = "{$_SESSION['usuario_sessao']}-{$adiantamento->adiantamento}-Anexo{$ane}-".date('dmY-His').".{$exp}";
										$anexos .= "ANEXO{$ane}||{$_SESSION['usuario_sessao']}-{$adiantamento->adiantamento}-Anexo{$ane}-".date('dmY-His').".{$exp};;";
										$alteracao .= "<b>Anexo Inclu�do:</b> {$anexos_nomes[$an]}<br><br>";
										$an = $an + 1;
									}
								}
							}
							if ($anexos != ""){
								if ($this->dados['adiantamento']->ANEXOS != substr($anexos,0,-2)){
									$adiantamento->anexos = substr($anexos,0,-2);
								}
							}
							if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-5"])){
								$adiantamento->val_devolver = $funcoes->sanearValor($_POST['val_devolver']);
								$adiantamento->val_receber = $funcoes->sanearValor($_POST['val_receber']);
								$ordem = $_POST["ordem"];
								$financeiro = $_POST["financeiro"];
								$obs = $_POST["obs"];
								$itemadiantamento = new Itemadiantamento();
								$itemadiantamento->adiantamento = $adiantamento->adiantamento;
								foreach ($ordem as $key => $it) {
									$i = $i+1;
									$itemadiantamento->ordem = $it;
									$itemadiantamento->financeiro = $funcoes->sanearValor($financeiro{$key});
									$itemadiantamento->obs = $obs{$key};
									$sql[$i] = $apiItem->editItemadiantamento($itemadiantamento);
								}
							}
							$ordem = 0;
							$item = $_POST["item"];
							$descricao = $_POST["descricao"];
							$documento = $_POST["documento"];
							$fornecedor = $_POST["fornecedor"];
							$data = $_POST["data"];
							$valor = $_POST["valor"];
							if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-5"])){
								$financeiro = $_POST["financeiro"];
								$obs = $_POST["obs"];
							}
							foreach ($item as $key => $it) {
								if (isset($this->itemadiantamento[$ordem])){
									if (isset($sql[$i])) {
										$i = $i+1;
									}
									$itemadiantamento = new Itemadiantamento();
									$itemadiantamento->adiantamento = $adiantamento->adiantamento;
									$itemadiantamento->ordem = $ordem + 1;
									if ($this->itemadiantamento[$ordem]->ITEM != $it){
										$itemadiantamento->item = $it;
										$n = $ordem + 1;
										$alteracao .= "<b>De Item {$n}:</b> {$this->itemadiantamento[$ordem]->ITEM} <b>Para Item {$n}:</b> {$itemadiantamento->item}<br><br>";
									}
									if ($this->itemadiantamento[$ordem]->DESCRICAO != strtoupper($funcoes->retiraAcentos(trim($descricao{$key})))){
										$itemadiantamento->descricao = strtoupper($funcoes->retiraAcentos(trim($descricao{$key})));
										$n = $ordem + 1;
										$alteracao .= "<b>De Item {$n} Descricao:</b> {$this->itemadiantamento[$ordem]->DESCRICAO} <b>Para Item {$n} Descri��o:</b> {$itemadiantamento->descricao}<br><br>";
									}
									if ($this->itemadiantamento[$ordem]->DOCUMENTO != $documento{$key}){
										$itemadiantamento->documento = $documento{$key};
										$n = $ordem + 1;
										$alteracao .= "<b>De Item {$n} Documento:</b> {$this->itemadiantamento[$ordem]->DOCUMENTO} <b>Para Item {$n} Documento:</b> {$itemadiantamento->documento}<br><br>";
									}
									if ($this->itemadiantamento[$ordem]->FORNECEDOR != strtoupper($funcoes->retiraAcentos(trim($fornecedor{$key})))){
										$itemadiantamento->fornecedor = strtoupper($funcoes->retiraAcentos(trim($fornecedor{$key})));
										$n = $ordem + 1;
										$alteracao .= "<b>De Item {$n} Fornecedor:</b> {$this->itemadiantamento[$ordem]->FORNECEDOR} <b>Para Item {$n} Fornecedor:</b> {$itemadiantamento->fornecedor}<br><br>";
									}
									if ($this->itemadiantamento[$ordem]->DATA != $data{$key}){
										$itemadiantamento->data = $data{$key};
										$n = $ordem + 1;
										$alteracao .= "<b>De Item {$n} Data:</b> {$this->itemadiantamento[$ordem]->DATA} <b>Para Item {$n} Data:</b> {$itemadiantamento->data}<br><br>";
									}
									if ($this->itemadiantamento[$ordem]->VALOR != $funcoes->sanearValor($valor{$key})){
										$itemadiantamento->valor = $funcoes->sanearValor($valor{$key});
										$n = $ordem + 1;
										$alteracao .= "<b>De Item {$n} Valor:</b> {$this->itemadiantamento[$ordem]->VALOR} <b>Para Item {$n} Valor:</b> {$itemadiantamento->valor}<br><br>";
									}
									if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-5"])){
										if ($this->itemadiantamento[$ordem]->FINANCEIRO != $funcoes->sanearValor($financeiro{$key})){
											$itemadiantamento->financeiro = $funcoes->sanearValor($financeiro{$key});
											$n = $ordem + 1;
											$alteracao .= "<b>De Item {$n} Financeiro:</b> {$this->itemadiantamento[$ordem]->FINANCEIRO} <b>Para Item {$n} Financeiro:</b> {$itemadiantamento->financeiro}<br><br>";
										}
										if ($this->itemadiantamento[$ordem]->OBS != $obs{$key}){
											$itemadiantamento->obs = $obs{$key};
											$n = $ordem + 1;
											$alteracao .= "<b>De Item {$n} Obs:</b> {$this->itemadiantamento[$ordem]->OBS} <b>Para Item {$n} Obs:</b> {$itemadiantamento->obs}<br><br>";
										}
									}
									$ordem = $ordem + 1;
									if ($itemadiantamento->item != "" || $itemadiantamento->descricao != "" || $itemadiantamento->documento != "" || $itemadiantamento->fornecedor != "" || $itemadiantamento->data != "" || $itemadiantamento->valor != ""){
										$sql[$i] = $apiItem->editItemadiantamento($itemadiantamento);
										$i = $i+1;
									}
								}else{
									if (isset($sql[$i])) {
										$i = $i+1;
									}
									$ordem = $ordem + 1;
									$itemadiantamento->ordem = $ordem;
									$itemadiantamento->item = $it;
									$itemadiantamento->descricao = strtoupper($funcoes->retiraAcentos(trim($descricao{$key})));
									$itemadiantamento->documento = $documento{$key};
									$itemadiantamento->fornecedor = strtoupper($funcoes->retiraAcentos(trim($fornecedor{$key})));
									$itemadiantamento->data = $data{$key};
									$itemadiantamento->valor = $funcoes->sanearValor($valor{$key});
									$sql[$i] = $apiItem->addItemadiantamento($itemadiantamento);
									$i = $i+1;
								}
							}
						}
					}
					if ($alteracao != ""){
						$adiantamento->situacao = 9;
						$sql[$i] = $apiAdiantamento->editAdiantamento($adiantamento);
						$i = $i+1;
						$inconsistencia = new Inconsistencia();
						$inconsistencia->adiantamento = $adiantamento->adiantamento;
						$inconsistencia->criador = $_SESSION['usuario_sessao'];
						$inconsistencia->inconsistencia = $alteracao;
						$inconsistencia->dta_inconsistencia = date("d/m/Y H:i:s");
						$inconsistencia->dta_retorno_inconsistencia = $this->dados['adiantamento']->DTA_INCONSISTENCIA;
						$obs_env = "<p style='font-style: italic;margin-bottom:10px;'>Inconsist�ncias Ajustadas.</p> {$inconsistencia->inconsistencia}";
						$sql[$i] = $apiAdiantamento->addInconsistencia($inconsistencia);
					}
				}elseif ($_POST['submeter'] == "autorizar"){
					if ($this->dados['adiantamento']->SITUACAO_ANTERIOR == 0){
						$autorizacao->adiantamento = $adiantamento->adiantamento;
						$autorizacao->autorizado = 'S';
						$autorizacao->situacao = 0;
						$autorizacao->autorizante = $_SESSION['usuario_sessao'];
						$autorizacao->dta_acao = date("d/m/Y H:i:s");
						$adiantamento->situacao = 1;
						$adiantamento->situacao_anterior = 1;
						$sql[$i] = $apiAdiantamento->editAdiantamento($adiantamento);
						$i = $i+1;
						$sql[$i] = $apiAdiantamento->editAutorizacao($autorizacao);
						$i = $i+1;
						$autorizacao = new Autorizacao();
						$autorizacao->adiantamento = $adiantamento->adiantamento;
						$autorizacao->situacao = 1;
						$autorizacao->dta_solicitacao = date("d/m/Y H:i:s");
						$sql[$i] = $apiAdiantamento->addAutorizacao($autorizacao);
					}elseif ($this->dados['adiantamento']->SITUACAO_ANTERIOR == 1){
						$autorizacao->adiantamento = $adiantamento->adiantamento;
						$autorizacao->autorizado = 'S';
						$autorizacao->situacao = 1;
						$autorizacao->autorizante = $_SESSION['usuario_sessao'];
						$autorizacao->dta_acao = date("d/m/Y H:i:s");
						$adiantamento->dta_prev_pagamento = $funcoes->somarDiasuteis(date('d/m/Y'), "{$this->dados['adiantamento']->DIAS}", "");
						$adiantamento->cliente_apollo = $_POST['cliente_apollo'];
						$adiantamento->titulo_apollo = $_POST['titulo_apollo'];
						$adiantamento->duplicata_apollo = intval("{$_POST['duplicata_apollo']}");
						if ($this->dados['adiantamento']->CATEGORIA == 'A'){
							$adiantamento->dta_prestacao = $funcoes->somarDiasuteis($this->dados['adiantamento']->DTA_FIM, "5", "");
							$valor = $this->dados['adiantamento']->VAL_ADIANTAMENTO;
							$adiantamento->situacao = 2;
							$adiantamento->situacao_anterior = 2;
						}else{
							$adiantamento->situacao = 5;
							$adiantamento->situacao_anterior = 5;
							$adiantamento->em = $_POST['em'];
							$adiantamento->val_receber = $funcoes->sanearValor($_POST['val_receber']);
							/*if ($_FILES["anexo"]["name"][0] != ""){
								if (isset($this->dados['adiantamento']->ANEXOS_COMP)){
									$anexos_complemento = "{$this->dados['adiantamento']->ANEXOS_COMP};;";
									$ane = count(explode(';;', $this->dados['adiantamento']->ANEXOS_COMP)) + 1;
								}else{
									$anexos_complemento = "";
									$ane = 1;
								}
								$anexo = $_FILES["anexo"];
								$an = 0;
								$anexos_nomes = array();
								foreach ($anexo['name'] as $key => $v){
									$v = explode(".", $v);
									$exp = strtolower(end($v));
									$anexos_nomes[$an] = "{$_SESSION['usuario_sessao']}-{$adiantamento->adiantamento}-Anexo{$ane}-".date('dmY-His').".{$exp}";
									$anexos_complemento .= "ANEXO{$ane}||{$_SESSION['usuario_sessao']}-{$adiantamento->adiantamento}-Anexo{$ane}-".date('dmY-His').".{$exp};;";
									$an = $an + 1;
									$ane = $ane + 1;
								}
								$adiantamento->anexos_comp = substr($anexos_complemento,0,-2);
								$obs_env = "<p style='font-style: italic;margin-bottom:10px;'>Complementos Anexados no Adiantamento.</p>";
							}*/
							if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-5"])){
								$ordem = $_POST["ordem"];
								$financeiro = $_POST["financeiro"];
								$obs = $_POST["obs"];
								$itemadiantamento = new Itemadiantamento();
								$itemadiantamento->adiantamento = $adiantamento->adiantamento;
								foreach ($ordem as $key => $it) {
									if (isset($sql[$i])) {
										$i = $i+1;
									}
									$itemadiantamento->ordem = $it;
									$itemadiantamento->financeiro = $funcoes->sanearValor($financeiro{$key});
									$itemadiantamento->obs = $obs{$key};
									$sql[$i] = $apiItem->editItemadiantamento($itemadiantamento);
								}
								$valor = $adiantamento->val_receber;
							}else{
								$valor = $this->dados['adiantamento']->VAL_RECEBER;
							}
						}
						$apiApollo = new apiApollo();
						$ad = $apiApollo->getAdapollo($this->dados['adiantamento']->EMPRESA, $adiantamento->cliente_apollo, $adiantamento->titulo_apollo, $adiantamento->duplicata_apollo);
						if(isset($ad->TITULO)){
							$adiantamento->dta_pagamento = $ad->DTA_EMISSAO;
							$i = $i+1;
							$sql[$i] = $apiAdiantamento->editAdiantamento($adiantamento);
							$i = $i+1;
							$sql[$i] = $apiAdiantamento->editAutorizacao($autorizacao);
						}else{
							$this->Alert = "N�o foi encontrado o adiantamento, cliente: {$adiantamento->cliente_apollo}, titulo: {$adiantamento->titulo_apollo}, duplicata: {$adiantamento->duplicata_apollo}";
						}
					}elseif ($this->dados['adiantamento']->SITUACAO_ANTERIOR == 3){
						$autorizacao->adiantamento = $adiantamento->adiantamento;
						$autorizacao->autorizado = 'S';
						$autorizacao->situacao = 3;
						$autorizacao->autorizante = $_SESSION['usuario_sessao'];
						$autorizacao->dta_acao = date("d/m/Y H:i:s");
						$adiantamento->situacao = 4;
						$adiantamento->situacao_anterior = 4;
						$sql[$i] = $apiAdiantamento->editAdiantamento($adiantamento);
						$i = $i+1;
						$sql[$i] = $apiAdiantamento->editAutorizacao($autorizacao);
						$i = $i+1;
						$autorizacao = new Autorizacao();
						$autorizacao->adiantamento = $adiantamento->adiantamento;
						$autorizacao->situacao = 4;
						$autorizacao->dta_solicitacao = date("d/m/Y H:i:s");
						$sql[$i] = $apiAdiantamento->addAutorizacao($autorizacao);
					}elseif ($this->dados['adiantamento']->SITUACAO_ANTERIOR == 4){
						$autorizacao->adiantamento = $adiantamento->adiantamento;
						$autorizacao->autorizado = 'S';
						$autorizacao->situacao = 4;
						$autorizacao->autorizante = $_SESSION['usuario_sessao'];
						$autorizacao->dta_acao = date("d/m/Y H:i:s");
						$adiantamento->situacao = 5;
						$adiantamento->situacao_anterior = 5;
						$adiantamento->em = $_POST['em'];
						if (isset($_POST['cp_apollo'])){
							$adiantamento->cp_apollo = $_POST['cp_apollo'];
							$adiantamento->cp_duplicata = intval("{$_POST['cp_duplicata']}");
							$adiantamento->cp_valor = $funcoes->sanearValor($_POST['cp_valor']);
							$apiApollo = new apiApollo();
							$ad = $apiApollo->getCpapollo($this->dados['adiantamento']->EMPRESA, $this->dados['adiantamento']->CLIENTE_APOLLO, $adiantamento->cp_apollo, $adiantamento->cp_duplicata);
							if(!isset($ad->TITULO)){
								$this->Alert = "N�o foi encontrado o Contas a Pagar, cliente: {$this->dados['adiantamento']->CLIENTE_APOLLO}, titulo: {$adiantamento->cp_apollo}, duplicata: {$adiantamento->cp_duplicata} <br>";
							}
						}
						if (isset($_POST['ad_apollo'])){
							$adiantamento->ad_apollo = $_POST['ad_apollo'];
							$adiantamento->ad_duplicata = intval("{$_POST['ad_duplicata']}");
							if (isset($_POST['ad_valor'])){
								$adiantamento->ad_valor = $funcoes->sanearValor($_POST['ad_valor']);
							}elseif (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-6"])){
								$adiantamento->ad_valor = $funcoes->sanearValor($_POST['val_receber']);
							}else{
								$adiantamento->ad_valor = $this->dados['adiantamento']->VAL_RECEBER;
							}
							$apiApollo = new apiApollo();
							$ad = $apiApollo->getAdapollo($this->dados['adiantamento']->EMPRESA, $this->dados['adiantamento']->CLIENTE_APOLLO, $adiantamento->ad_apollo, $adiantamento->ad_duplicata);
							if(!isset($ad->TITULO)){
								$this->Alert .= "N�o foi encontrado o Adiantamento, cliente: {$this->dados['adiantamento']->CLIENTE_APOLLO}, titulo: {$adiantamento->ad_apollo}, duplicata: {$adiantamento->ad_duplicata} ";
							}
						}
						$sql[$i] = $apiAdiantamento->editAutorizacao($autorizacao);
						if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-5"])){
							$adiantamento->val_devolver = $funcoes->sanearValor($_POST['val_devolver']);
							$adiantamento->val_receber = $funcoes->sanearValor($_POST['val_receber']);
							$ordem = $_POST["ordem"];
							$financeiro = $_POST["financeiro"];
							$obs = $_POST["obs"];
							$itemadiantamento = new Itemadiantamento();
							$itemadiantamento->adiantamento = $adiantamento->adiantamento;
							foreach ($ordem as $key => $it) {
								$i = $i+1;
								$itemadiantamento->ordem = $it;
								$itemadiantamento->financeiro = $funcoes->sanearValor($financeiro{$key});
								$itemadiantamento->obs = $obs{$key};
								$sql[$i] = $apiItem->editItemadiantamento($itemadiantamento);
							}
						}
						$i = $i+1;
						$sql[$i] = $apiAdiantamento->editAdiantamento($adiantamento);
					}
				}elseif ($_POST['submeter'] == "inconsistencia"){
					$alteracao = "";
					$adiantamento->situacao = 8;
					$sql[$i] = $apiAdiantamento->editAdiantamento($adiantamento);
					$i = $i+1;
					$inconsistencia = new Inconsistencia();
					$inconsistencia->adiantamento = $adiantamento->adiantamento;
					$inconsistencia->criador = $_SESSION['usuario_sessao'];
					if ($this->dados['adiantamento']->SITUACAO_ANTERIOR == 4){
						if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-5"])){
							$ordem = 0;
							$item = $_POST["ordem"];
							$financeiro = $_POST["financeiro"];
							$obs = $_POST["obs"];
							foreach ($item as $key => $it) {
								if (isset($this->itemadiantamento[$ordem])){
									$itemadiantamento = new Itemadiantamento();
									$itemadiantamento->adiantamento = $adiantamento->adiantamento;
									$itemadiantamento->ordem = $ordem + 1;
									if ($this->itemadiantamento[$ordem]->OBS != $obs{$key}){
										$itemadiantamento->obs = $obs{$key};
										$n = $ordem + 1;
										$alteracao .= "<b>De Item {$n} Obs:</b> {$this->itemadiantamento[$ordem]->OBS} <b>Para Item {$n} Obs:</b> {$itemadiantamento->obs}<br><br>";
										$sql[$i] = $apiItem->editItemadiantamento($itemadiantamento);
										$i = $i+1;
										$ordem = $ordem + 1;
									}
								}
							}
						}
					}
					$inconsistencia->inconsistencia = str_replace("\r\n","<br>",$_POST["inconsistencia"]);
					if ($alteracao != ""){
						$inconsistencia->inconsistencia .= "<br>{$alteracao}";
					}
					$inconsistencia->dta_inconsistencia = date("d/m/Y H:i:s");
					$obs_env = "<p style='font-style: italic;margin-bottom:10px;'>Existe inconsist�ncias.</p> {$inconsistencia->inconsistencia}";
					$sql[$i] = $apiAdiantamento->addInconsistencia($inconsistencia);	
				}elseif ($_POST['submeter'] == "desautorizar"){
					if ($this->dados['adiantamento']->SITUACAO_ANTERIOR == 0){
						$autorizacao->autorizado = 'N';
						$autorizacao->situacao = 0;
						$autorizacao->autorizante = $_SESSION['usuario_sessao'];
						$autorizacao->dta_acao = date("d/m/Y H:i:s");
						$adiantamento->situacao = 7;
						$adiantamento->situacao_anterior = 7;
						$autorizacao->motivo = str_replace("\r\n","<br>",$_POST["motivo"]);
						$sql[$i] = $apiAdiantamento->editAdiantamento($adiantamento);
						$i = $i+1;
						$sql[$i] = $apiAdiantamento->editAutorizacao($autorizacao);	
					}elseif ($this->dados['adiantamento']->SITUACAO_ANTERIOR == 1){
						$autorizacao->autorizado = 'N';
						$autorizacao->situacao = 1;
						$autorizacao->autorizante = $_SESSION['usuario_sessao'];
						$autorizacao->dta_acao = date("d/m/Y H:i:s");
						$adiantamento->situacao = 7;
						$adiantamento->situacao_anterior = 7;
						$autorizacao->motivo = str_replace("\r\n","<br>",$_POST["motivo"]);
						$sql[$i] = $apiAdiantamento->editAdiantamento($adiantamento);
						$i = $i+1;
						$sql[$i] = $apiAdiantamento->editAutorizacao($autorizacao);
					}
				}
			}elseif ($this->dados['adiantamento']->SITUACAO == 0 || $this->dados['adiantamento']->SITUACAO == 1 || $this->dados['adiantamento']->SITUACAO == 3 || $this->dados['adiantamento']->SITUACAO == 4){
				if ($_POST['submeter'] == "autorizar"){
					$autorizacao->autorizado = 'S';
				}else{
					$autorizacao->autorizado = 'N';
				}
				$autorizacao->adiantamento = $adiantamento->adiantamento;
				if ($this->dados['adiantamento']->SITUACAO == 0){
					if ($_POST['submeter'] == "inconsistencia"){
						$adiantamento->situacao = 8;
						$sql[$i] = $apiAdiantamento->editAdiantamento($adiantamento);
						$i = $i+1;
						$inconsistencia = new Inconsistencia();
						$inconsistencia->adiantamento = $adiantamento->adiantamento;
						$inconsistencia->criador = $_SESSION['usuario_sessao'];
						$inconsistencia->inconsistencia = str_replace("\r\n","<br>",$_POST["inconsistencia"]);
						$inconsistencia->dta_inconsistencia = date("d/m/Y H:i:s");
						$obs_env = "<p style='font-style: italic;margin-bottom:10px;'>Existe inconsist�ncias.</p> {$inconsistencia->inconsistencia}";
						$sql[$i] = $apiAdiantamento->addInconsistencia($inconsistencia);
					}else{
						$autorizacao->situacao = 0;
						$autorizacao->autorizante = $_SESSION['usuario_sessao'];
						$autorizacao->dta_acao = date("d/m/Y H:i:s");
						if ($autorizacao->autorizado == 'S'){
							$adiantamento->situacao = 1;
							$adiantamento->situacao_anterior = 1;
							$sql[$i] = $apiAdiantamento->editAdiantamento($adiantamento);
							$i = $i+1;
							$sql[$i] = $apiAdiantamento->editAutorizacao($autorizacao);
							$i = $i+1;
							$autorizacao = new Autorizacao();
							$autorizacao->adiantamento = $adiantamento->adiantamento;
							$autorizacao->situacao = 1;
							$autorizacao->dta_solicitacao = date("d/m/Y H:i:s");
							$sql[$i] = $apiAdiantamento->addAutorizacao($autorizacao);
							/*if ($this->dados['adiantamento']->CATEGORIA == "R"){
								$ordem = $_POST["ordem"];
								$autorizou = $_POST["aut"];
								$itemadiantamento = new Itemadiantamento();
								$itemadiantamento->adiantamento = $adiantamento->adiantamento;
								foreach ($ordem as $key => $it) {
									$itemadiantamento->ordem = $it;
									if (in_array("{$it}", $autorizou)){
										$itemadiantamento->aut = "S";
									}else{
										$itemadiantamento->aut = "N";
									}
									$sql[$i] = $apiItem->editItemadiantamento($itemadiantamento);
									$i = $i+1;
								}
							}*/
						}else{
							$adiantamento->situacao = 7;
							$adiantamento->situacao_anterior = 7;
							$autorizacao->motivo = str_replace("\r\n","<br>",$_POST["motivo"]);
							$sql[$i] = $apiAdiantamento->editAdiantamento($adiantamento);
							$i = $i+1;
							$sql[$i] = $apiAdiantamento->editAutorizacao($autorizacao);	
						}
					}
				}elseif ($this->dados['adiantamento']->SITUACAO == 1){
					if ($_POST['submeter'] == "inconsistencia"){
						$adiantamento->situacao = 8;
						$sql[$i] = $apiAdiantamento->editAdiantamento($adiantamento);
						$i = $i+1;
						$inconsistencia = new Inconsistencia();
						$inconsistencia->adiantamento = $adiantamento->adiantamento;
						$inconsistencia->criador = $_SESSION['usuario_sessao'];
						$inconsistencia->inconsistencia = str_replace("\r\n","<br>",$_POST["inconsistencia"]);
						$inconsistencia->dta_inconsistencia = date("d/m/Y H:i:s");
						$obs_env = "<p style='font-style: italic;margin-bottom:10px;'>Existe inconsist�ncias.</p> {$inconsistencia->inconsistencia}";
						$sql[$i] = $apiAdiantamento->addInconsistencia($inconsistencia);
					}else{
						$autorizacao->situacao = 1;
						$autorizacao->autorizante = $_SESSION['usuario_sessao'];
						$autorizacao->dta_acao = date("d/m/Y H:i:s");
						if ($autorizacao->autorizado == 'S'){
							$adiantamento->dta_prev_pagamento = $funcoes->somarDiasuteis(date('d/m/Y'), "{$this->dados['adiantamento']->DIAS}", "");
							$adiantamento->cliente_apollo = $_POST['cliente_apollo'];
							$adiantamento->titulo_apollo = $_POST['titulo_apollo'];
							$adiantamento->duplicata_apollo = intval("{$_POST['duplicata_apollo']}");
							if ($this->dados['adiantamento']->CATEGORIA == 'A'){
								$adiantamento->dta_prestacao = $funcoes->somarDiasuteis($this->dados['adiantamento']->DTA_FIM, "5", "");
								$valor = $this->dados['adiantamento']->VAL_ADIANTAMENTO;
								$adiantamento->situacao = 2;
								$adiantamento->situacao_anterior = 2;
							}else{
								$adiantamento->situacao = 5;
								$adiantamento->situacao_anterior = 5;
								$adiantamento->em = $_POST['em'];
								$adiantamento->val_receber = $funcoes->sanearValor($_POST['val_receber']);
								/*if ($_FILES["anexo"]["name"][0] != ""){
									if (isset($this->dados['adiantamento']->ANEXOS_COMP)){
										$anexos_complemento = "{$this->dados['adiantamento']->ANEXOS_COMP};;";
										$ane = count(explode(';;', $this->dados['adiantamento']->ANEXOS_COMP)) + 1;
									}else{
										$anexos_complemento = "";
										$ane = 1;
									}
									$anexo = $_FILES["anexo"];
									$an = 0;
									$anexos_nomes = array();
									foreach ($anexo['name'] as $key => $v){
										$v = explode(".", $v);
										$exp = strtolower(end($v));
										$anexos_nomes[$an] = "{$_SESSION['usuario_sessao']}-{$adiantamento->adiantamento}-Anexo{$ane}-".date('dmY-His').".{$exp}";
										$anexos_complemento .= "ANEXO{$ane}||{$_SESSION['usuario_sessao']}-{$adiantamento->adiantamento}-Anexo{$ane}-".date('dmY-His').".{$exp};;";
										$an = $an + 1;
										$ane = $ane + 1;
									}
									$adiantamento->anexos_comp = substr($anexos_complemento,0,-2);
									$obs_env = "<p style='font-style: italic;margin-bottom:10px;'>Complementos Anexados no Adiantamento.</p>";
								}*/
								if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-5"])){
									$ordem = $_POST["ordem"];
									$financeiro = $_POST["financeiro"];
									$obs = $_POST["obs"];
									$itemadiantamento = new Itemadiantamento();
									$itemadiantamento->adiantamento = $adiantamento->adiantamento;
									foreach ($ordem as $key => $it) {
										if (isset($sql[$i])) {
											$i = $i+1;
										}
										$itemadiantamento->ordem = $it;
										$itemadiantamento->financeiro = $funcoes->sanearValor($financeiro{$key});
										$itemadiantamento->obs = $obs{$key};
										$sql[$i] = $apiItem->editItemadiantamento($itemadiantamento);
									}
									$valor = $adiantamento->val_receber;
								}else{
									$valor = $this->dados['adiantamento']->VAL_RECEBER;
								}
							}
							$apiApollo = new apiApollo();
							$ad = $apiApollo->getAdapollo($this->dados['adiantamento']->EMPRESA, $adiantamento->cliente_apollo, $adiantamento->titulo_apollo, $adiantamento->duplicata_apollo);
							if(isset($ad->TITULO)){
								$i = $i+1;
								$sql[$i] = $apiAdiantamento->editAdiantamento($adiantamento);
								$i = $i+1;
								$sql[$i] = $apiAdiantamento->editAutorizacao($autorizacao);
							}else{
								$this->Alert = "N�o foi encontrado o adiantamento, cliente: {$adiantamento->cliente_apollo}, titulo: {$adiantamento->titulo_apollo}, duplicata: {$adiantamento->duplicata_apollo}";
							}
						}else{
							$adiantamento->situacao = 7;
							$adiantamento->situacao_anterior = 7;
							$autorizacao->motivo = str_replace("\r\n","<br>",$_POST["motivo"]);
							$sql[$i] = $apiAdiantamento->editAdiantamento($adiantamento);
							$i = $i+1;
							$sql[$i] = $apiAdiantamento->editAutorizacao($autorizacao);	
						}
					}
				}elseif ($this->dados['adiantamento']->SITUACAO == 3){
					if ($_POST['submeter'] == "inconsistencia"){
						$adiantamento->situacao = 8;
						$sql[$i] = $apiAdiantamento->editAdiantamento($adiantamento);
						$i = $i+1;
						$inconsistencia = new Inconsistencia();
						$inconsistencia->adiantamento = $adiantamento->adiantamento;
						$inconsistencia->criador = $_SESSION['usuario_sessao'];
						$inconsistencia->inconsistencia = str_replace("\r\n","<br>",$_POST["inconsistencia"]);
						$inconsistencia->dta_inconsistencia = date("d/m/Y H:i:s");
						$obs_env = "<p style='font-style: italic;margin-bottom:10px;'>Existe inconsist�ncias.</p> {$inconsistencia->inconsistencia}";
						$sql[$i] = $apiAdiantamento->addInconsistencia($inconsistencia);
					}else{
						$aut = $autorizacao->autorizado;
						$autorizacao->situacao = 3;
						$autorizacao->autorizante = $_SESSION['usuario_sessao'];
						$autorizacao->dta_acao = date("d/m/Y H:i:s");
						$adiantamento->situacao = 4;
						$adiantamento->situacao_anterior = 4;
						$sql[$i] = $apiAdiantamento->editAdiantamento($adiantamento);
						$i = $i+1;
						$sql[$i] = $apiAdiantamento->editAutorizacao($autorizacao);
						$i = $i+1;
						$autorizacao = new Autorizacao();
						$autorizacao->adiantamento = $adiantamento->adiantamento;
						$autorizacao->situacao = 4;
						$autorizacao->dta_solicitacao = date("d/m/Y H:i:s");
						$sql[$i] = $apiAdiantamento->addAutorizacao($autorizacao);
						/*if ($aut == "S"){
							$ordem = $_POST["ordem"];
							$autorizou = $_POST["aut"];
							$itemadiantamento = new Itemadiantamento();
							$itemadiantamento->adiantamento = $adiantamento->adiantamento;
							foreach ($ordem as $key => $it) {
								$i = $i+1;
								$itemadiantamento->ordem = $it;
								if (in_array("{$it}", $autorizou)){
									$itemadiantamento->aut = "S";
								}else{
									$itemadiantamento->aut = "N";
								}
								$sql[$i] = $apiItem->editItemadiantamento($itemadiantamento);
							}
						}else{
							$item = $_POST["item"];
							$itemadiantamento = new Itemadiantamento();
							$itemadiantamento->adiantamento = $adiantamento->adiantamento;
							foreach ($item as $key => $it) {
								$i = $i+1;
								$itemadiantamento->item = $it;
								$itemadiantamento->aut = "N";
								$sql[$i] = $apiItem->editItemadiantamento($itemadiantamento);
							}
						}*/
					}
				}elseif ($this->dados['adiantamento']->SITUACAO == 4){
					if ($_POST['submeter'] == "inconsistencia"){
						$alteracao = "";
						$adiantamento->situacao = 8;
						$sql[$i] = $apiAdiantamento->editAdiantamento($adiantamento);
						$i = $i+1;
						$inconsistencia = new Inconsistencia();
						$inconsistencia->adiantamento = $adiantamento->adiantamento;
						$inconsistencia->criador = $_SESSION['usuario_sessao'];
						if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-5"])){
							$ordem = 0;
							$item = $_POST["ordem"];
							$financeiro = $_POST["financeiro"];
							$obs = $_POST["obs"];
							foreach ($item as $key => $it) {
								if (isset($this->itemadiantamento[$ordem])){
									$itemadiantamento = new Itemadiantamento();
									$itemadiantamento->adiantamento = $adiantamento->adiantamento;
									$itemadiantamento->ordem = $ordem + 1;
									if ($this->itemadiantamento[$ordem]->OBS != $obs{$key}){
										$itemadiantamento->obs = $obs{$key};
										$n = $ordem + 1;
										$alteracao .= "<b>De Item {$n} Obs:</b> {$this->itemadiantamento[$ordem]->OBS} <b>Para Item {$n} Obs:</b> {$itemadiantamento->obs}<br><br>";
										$sql[$i] = $apiItem->editItemadiantamento($itemadiantamento);
										$i = $i+1;
										$ordem = $ordem + 1;
									}
								}
							}
						}
						$inconsistencia->inconsistencia = str_replace("\r\n","<br>",$_POST["inconsistencia"]);
						if ($alteracao != ""){
							$inconsistencia->inconsistencia .= "<br>{$alteracao}";
						}
						$inconsistencia->dta_inconsistencia = date("d/m/Y H:i:s");
						$obs_env = "<p style='font-style: italic;margin-bottom:10px;'>Existe inconsist�ncias.</p> {$inconsistencia->inconsistencia}";
						$sql[$i] = $apiAdiantamento->addInconsistencia($inconsistencia);
					}elseif ($autorizacao->autorizado == "S"){
						$autorizacao->situacao = 4;
						$autorizacao->autorizante = $_SESSION['usuario_sessao'];
						$autorizacao->dta_acao = date("d/m/Y H:i:s");
						$adiantamento->situacao = 5;
						$adiantamento->situacao_anterior = 5;
						$adiantamento->em = $_POST['em'];
						if (isset($_POST['cp_apollo'])){
							$adiantamento->cp_apollo = $_POST['cp_apollo'];
							$adiantamento->cp_duplicata = intval("{$_POST['cp_duplicata']}");
							$adiantamento->cp_valor = $funcoes->sanearValor($_POST['cp_valor']);
							$apiApollo = new apiApollo();
							$ad = $apiApollo->getCpapollo($this->dados['adiantamento']->EMPRESA, $this->dados['adiantamento']->CLIENTE_APOLLO, $adiantamento->cp_apollo, $adiantamento->cp_duplicata);
							if(!isset($ad->TITULO)){
								$this->Alert = "N�o foi encontrado o Contas a Pagar, cliente: {$this->dados['adiantamento']->CLIENTE_APOLLO}, titulo: {$adiantamento->cp_apollo}, duplicata: {$adiantamento->cp_duplicata} <br>";
							}
						}
						if (isset($_POST['ad_apollo'])){
							$adiantamento->ad_apollo = $_POST['ad_apollo'];
							$adiantamento->ad_duplicata = intval("{$_POST['ad_duplicata']}");
							if (isset($_POST['ad_valor'])){
								$adiantamento->ad_valor = $funcoes->sanearValor($_POST['ad_valor']);
							}elseif (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-6"])){
								$adiantamento->ad_valor = $funcoes->sanearValor($_POST['val_receber']);
							}else{
								$adiantamento->ad_valor = $this->dados['adiantamento']->VAL_RECEBER;
							}
							$apiApollo = new apiApollo();
							$ad = $apiApollo->getAdapollo($this->dados['adiantamento']->EMPRESA, $this->dados['adiantamento']->CLIENTE_APOLLO, $adiantamento->ad_apollo, $adiantamento->ad_duplicata);
							if(!isset($ad->TITULO)){
								$this->Alert .= "N�o foi encontrado o Adiantamento, cliente: {$this->dados['adiantamento']->CLIENTE_APOLLO}, titulo: {$adiantamento->ad_apollo}, duplicata: {$adiantamento->ad_duplicata} ";
							}
						}
						$sql[$i] = $apiAdiantamento->editAutorizacao($autorizacao);
						if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-5"])){
							$adiantamento->val_devolver = $funcoes->sanearValor($_POST['val_devolver']);
							$adiantamento->val_receber = $funcoes->sanearValor($_POST['val_receber']);
							$ordem = $_POST["ordem"];
							$financeiro = $_POST["financeiro"];
							$obs = $_POST["obs"];
							$itemadiantamento = new Itemadiantamento();
							$itemadiantamento->adiantamento = $adiantamento->adiantamento;
							foreach ($ordem as $key => $it) {
								$i = $i+1;
								$itemadiantamento->ordem = $it;
								$itemadiantamento->financeiro = $funcoes->sanearValor($financeiro{$key});
								$itemadiantamento->obs = $obs{$key};
								$sql[$i] = $apiItem->editItemadiantamento($itemadiantamento);
							}
						}
						$i = $i+1;
						$sql[$i] = $apiAdiantamento->editAdiantamento($adiantamento);
					}
				}
			}
			if (!isset($this->Alert)){
				$rs = $apiAdiantamento->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if ($this->dados['adiantamento']->CATEGORIA == 'R'){
						if (isset($_POST['exclusao'])){
							foreach ($_POST['exclusao'] as $e){
								unlink($_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/".$e);
							}
						}
						if ($_FILES["anexo"]["name"][0] != "" && $adiantamento->situacao != 5){
							foreach ($anexos_nomes as $key => $v){
								move_uploaded_file($_FILES['anexo']['tmp_name'][$key], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/".$v);
							}
						}elseif ($adiantamento->situacao == 5){
							$conn_id = ftp_connect("10.3.101.38","21");
							$login_result = ftp_login($conn_id, "monaco", "m0n4c0");
							$caminho = "/".str_replace("\Adiantamentos","",substr(substr(str_replace("\\10.3.101.38\Arq_Apollo\Arq\\", "", $ad->DIR_PASTA_ADIANTAMENTO),0,-1),1))."/Adiantamentos/{$ad->EMPRESA}-{$ad->REVENDA}-{$ad->TITULO}-{$ad->DUPLICATA}-{$ad->CLIENTE}-AD/";
							
							$strVal = explode(';;', $this->dados['adiantamento']->ANEXOS);
							foreach ($strVal as $va){
								@list($k, $v) = explode('||', $va);
								$this->anexos[$k] = $v;
							}
							foreach ($this->anexos as $v){
								ftp_put($conn_id, "{$caminho}{$v}", $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/".$v,FTP_BINARY);
							}
							
							/*$strVal = explode(';;', $this->dados['adiantamento']->ANEXOS_COMP);
							foreach ($strVal as $va){
								@list($k, $v) = explode('||', $va);
								$this->anexos_comp[$k] = $v;
							}
							foreach ($this->anexos_comp as $v){
								ftp_put($conn_id, "{$caminho}{$v}", $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/".$v,FTP_BINARY);
							}
							ftp_close($conn_id);*/
						}
					}else{
						if ($this->dados['adiantamento']->SITUACAO == 8){
							if (isset($_POST['exclusao'])){
								$conn_id = ftp_connect("10.3.101.38","21");
								$login_result = ftp_login($conn_id, "monaco", "m0n4c0");
								$caminho = "/".str_replace("\Adiantamentos","",substr(substr(str_replace("\\10.3.101.38\Arq_Apollo\Arq\\", "", $this->dados['adiantamento']->DIR_PASTA_ADIANTAMENTO),0,-1),1))."/Adiantamentos/{$this->dados['adiantamento']->EMPRESA_APOLLO}-{$this->dados['adiantamento']->REVENDA_APOLLO}-{$this->dados['adiantamento']->TITULO_APOLLO}-{$this->dados['adiantamento']->DUPLICATA_APOLLO}-{$this->dados['adiantamento']->CLIENTE_APOLLO}-AD/";
								foreach ($_POST['exclusao'] as $e){
									unlink($_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/".$e);
									ftp_delete($conn_id, $caminho.$e);
								}
								ftp_close($conn_id);
							}
							if ($_FILES["anexo"]["name"][0] != "" && $adiantamento->situacao != 5){
								$conn_id = ftp_connect("10.3.101.38","21");
								$login_result = ftp_login($conn_id, "monaco", "m0n4c0");
								$caminho = "/".str_replace("\Adiantamentos","",substr(substr(str_replace("\\10.3.101.38\Arq_Apollo\Arq\\", "", $this->dados['adiantamento']->DIR_PASTA_ADIANTAMENTO),0,-1),1))."/Adiantamentos/{$this->dados['adiantamento']->EMPRESA_APOLLO}-{$this->dados['adiantamento']->REVENDA_APOLLO}-{$this->dados['adiantamento']->TITULO_APOLLO}-{$this->dados['adiantamento']->DUPLICATA_APOLLO}-{$this->dados['adiantamento']->CLIENTE_APOLLO}-AD/";
								foreach ($anexos_nomes as $key => $v){
									move_uploaded_file($_FILES['anexo']['tmp_name'][$key], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/".$v);
									ftp_put($conn_id, "{$caminho}{$v}", $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/".$v,FTP_BINARY);
								}
								ftp_close($conn_id);
							}
						}
						if ($this->dados['adiantamento']->CATEGORIA == 'A' && $this->dados['adiantamento']->SITUACAO == 2){
							$conn_id = ftp_connect("10.3.101.38","21");
							$login_result = ftp_login($conn_id, "monaco", "m0n4c0");
							$caminho = "/".str_replace("\Adiantamentos","",substr(substr(str_replace("\\10.3.101.38\Arq_Apollo\Arq\\", "", $this->dados['adiantamento']->DIR_PASTA_ADIANTAMENTO),0,-1),1))."/Adiantamentos/{$this->dados['adiantamento']->EMPRESA_APOLLO}-{$this->dados['adiantamento']->REVENDA_APOLLO}-{$this->dados['adiantamento']->TITULO_APOLLO}-{$this->dados['adiantamento']->DUPLICATA_APOLLO}-{$this->dados['adiantamento']->CLIENTE_APOLLO}-AD/";
							foreach ($anexos_nomes as $key => $v){
								move_uploaded_file($_FILES['anexo']['tmp_name'][$key], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/".$v);
								ftp_put($conn_id, "{$caminho}{$v}", $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/".$v,FTP_BINARY);
							}
							ftp_close($conn_id);
						}/*elseif (($this->dados['adiantamento']->CATEGORIA == 'A' && $this->dados['adiantamento']->SITUACAO == 4) || ($this->dados['adiantamento']->CATEGORIA == 'A' && $this->dados['adiantamento']->SITUACAO_ANTERIOR == 4)){
							if ($_FILES["anexo"]["name"][0] != ""){
								$conn_id = ftp_connect("10.3.101.38","21");
								$login_result = ftp_login($conn_id, "monaco", "m0n4c0");
								$caminho = "/".str_replace("\Adiantamentos","",substr(substr(str_replace("\\10.3.101.38\Arq_Apollo\Arq\\", "", $this->dados['adiantamento']->DIR_PASTA_ADIANTAMENTO),0,-1),1))."/Adiantamentos/{$this->dados['adiantamento']->EMPRESA_APOLLO}-{$this->dados['adiantamento']->REVENDA_APOLLO}-{$this->dados['adiantamento']->TITULO_APOLLO}-{$this->dados['adiantamento']->DUPLICATA_APOLLO}-{$this->dados['adiantamento']->CLIENTE_APOLLO}-AD/";
								foreach ($anexos_nomes as $key => $v){
									move_uploaded_file($_FILES['anexo']['tmp_name'][$key], $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/".$v);
									ftp_put($conn_id, "{$caminho}{$v}", $_SERVER['DOCUMENT_ROOT']."/".RAIZ_PATH."dados/".$this->getModule()['des_modulo']."/".$v,FTP_BINARY);
								}
								ftp_close($conn_id);
							}	
						}*/
					}
					$mov = "";
					$aut = "";
					$this->autorizacao = $apiAdiantamento->getAdiantamentoautorizacao($adiantamento);
					foreach ($this->autorizacao as $rs){
						$mov .="<hr /><p style='margin-bottom:10px; margin-top:2px; font-style: italic;color: #606060;'>Em {$rs->DTA_SOLICITACAO}</p>";
						$sit = ( ($rs->SITUACAO != 0) ? ($rs->SITUACAO != 1) ? ($rs->SITUACAO != 3) ? ($rs->SITUACAO != 4) ? ($rs->SITUACAO != 5) ? ($rs->SITUACAO != 6) ?($rs->SITUACAO == 7) ? "Cancelado" : "" : "Conclu�do" : "Processando Pagamento" : "Aprova��o Financeiro 2" : "Aprova��o Gerencial 2" : "Aprova��o Financeiro" : "Aprova��o Gerencial");
						$mov .="<p style='margin-bottom: 10px;'><strong>Situa��o:</strong> {$sit}</p>";
						if (isset($rs->DESTINATARIO)){
							$mov .="<p style='margin-bottom: 10px;'><strong>Destinat�rio:</strong> {$rs->NOME_DESTINATARIO}</p>";
						}
						if (isset($rs->AUTORIZANTE)){
							$mov .="<p style='margin-bottom: 10px;'><strong>Autorizante:</strong> {$rs->NOME_AUTORIZANTE}</p>";
						}
						if (isset($rs->DTA_ACAO)){
							$mov .="<p style='margin-bottom: 10px;'><strong>Data A��o:</strong> {$rs->DTA_ACAO}</p>";
						}
						if (isset($rs->MOTIVO)){
							$mov .="<p style='margin-bottom: 10px;'><strong>Motivo:</strong> {$rs->MOTIVO}</p>";
						}
						if (isset($rs->AUTORIZADO)){
							$aut = ($rs->AUTORIZADO == 'S') ? 'Sim' : 'N�o';
							$mov .="<p style='margin-bottom: 10px;'><strong>Autorizado:</strong> {$aut}</p>";
						}
					}
					$this->dados = array('adiantamento' => $apiAdiantamento->getAdiantamento($adiantamento));
					$emp = $apiEmpresa->geEmpresarevenda($this->dados['adiantamento']->EMPRESA);
					$contpg = "";
					$data = date('d/m/Y');
					$prestacao = "prestacaodecontas@grupomonaco.com.br";
					if ($emp->EMPRESA == "1"){
						$contpg = "contasapagar.dieselpa@grupomonaco.com.br";
						if (isset($_POST['em'])){
							if ($_POST['em'] == "DF"){
								$emaildp = "dp.dieselpa@grupomonaco.com.br";
								$vdf = $adiantamento->cp_valor;
							}elseif ($_POST['em'] == "AB"){
								$emaildp = "dp.dieselpa@grupomonaco.com.br";
								$vdf = $adiantamento->cp_valor;
							}
						}
					}elseif ($emp->EMPRESA == "2"){
						$contpg = "contasapagar.motopa@grupomonaco.com.br";
						if (isset($_POST['em'])){
							if ($_POST['em'] == "DF"){
								$emaildp = "dp.motopa@grupomonaco.com.br";
								$vdf = $adiantamento->cp_valor;
							}elseif ($_POST['em'] == "AB"){
								$emaildp = "dp.motopa@grupomonaco.com.br";
								$vdf = $adiantamento->cp_valor;
							}
						}
					}elseif ($emp->EMPRESA == "3"){
						$contpg = "contasapagar.dieselmt@grupomonaco.com.br";
						if (isset($_POST['em'])){
							if ($_POST['em'] == "DF"){
								$emaildp = "dp.dieselmt@grupomonaco.com.br";
								$vdf = $adiantamento->cp_valor;
							}elseif ($_POST['em'] == "AB"){
								$emaildp = "dp.dieselmt@grupomonaco.com.br";
								$vdf = $adiantamento->cp_valor;
							}
						}
					}elseif ($emp->EMPRESA == "4"){
						$contpg = "contasapagar.dieselpi@grupomonaco.com.br";
						if (isset($_POST['em'])){
							if ($_POST['em'] == "DF"){
								$emaildp = "dp.dieselpi@grupomonaco.com.br";
								$vdf = $adiantamento->cp_valor;
							}elseif ($_POST['em'] == "AB"){
								$emaildp = "dp.dieselpi@grupomonaco.com.br";
								$vdf = $adiantamento->cp_valor;
							}
						}
					}elseif ($emp->EMPRESA == "5"){
						$contpg = "contasapagar.dieselma@grupomonaco.com.br";
						if (isset($_POST['em'])){
							if ($_POST['em'] == "DF"){
								$emaildp = "dp.dieselma@grupomonaco.com.br";
								$vdf = $adiantamento->cp_valor;
							}elseif ($_POST['em'] == "AB"){
								$emaildp = "dp.dieselma@grupomonaco.com.br";
								$vdf = $adiantamento->cp_valor;
							}
						}
					}elseif ($emp->EMPRESA == "7"){
						$contpg = "contasapagar.motomt@grupomonaco.com.br";
						if (isset($_POST['em'])){
							if ($_POST['em'] == "DF"){
								$emaildp = "dp.motomt@grupomonaco.com.br";
								$vdf = $adiantamento->cp_valor;
							}elseif ($_POST['em'] == "AB"){
								$emaildp = "dp.motomt@grupomonaco.com.br";
								$vdf = $adiantamento->cp_valor;
							}
						}
					}elseif ($emp->EMPRESA == "9"){
						$contpg = "contasapagar.motoap@grupomonaco.com.br";
						if (isset($_POST['em'])){
							if ($_POST['em'] == "DF"){
								$emaildp = "dp.motoap@grupomonaco.com.br";
								$vdf = $adiantamento->cp_valor;
							}elseif ($_POST['em'] == "AB"){
								$emaildp = "dp.motoap@grupomonaco.com.br";
								$vdf = $adiantamento->cp_valor;
							}
						}
					}elseif ($emp->EMPRESA == "11"){
						$contpg = "contasapagar.dieselap@grupomonaco.com.br";
						if (isset($_POST['em'])){
							if ($_POST['em'] == "DF"){
								$emaildp = "dp.dieselap@grupomonaco.com.br";
								$vdf = $adiantamento->cp_valor;
							}elseif ($_POST['em'] == "AB"){
								$emaildp = "dp.dieselap@grupomonaco.com.br";
								$vdf = $adiantamento->cp_valor;
							}
						}
					}elseif ($emp->EMPRESA == "13"){
						$contpg = "contasapagar.fiatpa@grupomonaco.com.br";
						if (isset($_POST['em'])){
							if ($_POST['em'] == "DF"){
								$emaildp = "dp.fiatpa@grupomonaco.com.br";
								$vdf = $adiantamento->cp_valor;
							}elseif ($_POST['em'] == "AB"){
								$emaildp = "dp.fiatpa@grupomonaco.com.br";
								$vdf = $adiantamento->cp_valor;
							}
						}
					}elseif ($emp->EMPRESA == "50"){
						$contpg = "contasapagar.dieselparticipacoes@grupomonaco.com.br";
						if (isset($_POST['em'])){
							if ($_POST['em'] == "DF"){
								$emaildp = "dp.holding@grupomonaco.com.br";
								$vdf = $adiantamento->cp_valor;
							}elseif ($_POST['em'] == "AB"){
								$emaildp = "dp.holding@grupomonaco.com.br";
								$vdf = $adiantamento->cp_valor;
							}
						}
					}
					$apiUsuario = new apiUsuario();
					$para = array();
					$a = 0;
					$para[$a] = "{$prestacao}";
					$a = $a+1;
					if ($this->dados['adiantamento']->CATEGORIA == 'A'){
						$cat = "Adiantamento";
						$valorr = number_format(str_replace(",", ".", $this->dados['adiantamento']->VAL_ADIANTAMENTO), 2, ",", ".");
					}else{
						$cat = "Reembolso";
						$valorr = number_format(str_replace(",", ".", $this->dados['adiantamento']->VAL_RECEBER), 2, ",", ".");
					}
					$df = "";
					$de  = "SisMonaco - SPC {$cat} {$data}";
					if ($this->dados['adiantamento']->SITUACAO == 0){
						$situacao = "Aguardando Aprova��o Gerencial";
						$assunto   = "Aguardando Aprova��o Gerencial {$data}";
						$envolvidos = $apiUsuario->getEmailenvolvidos("{$this->dados['adiantamento']->SOLICITANTE},{$this->dados['adiantamento']->DESTINATARIO}");
						foreach ($envolvidos as $rs) {
							$para[$a] = "{$rs->EMAIL}";
							$a = $a + 1;
						}
						$gestorn = $envolvidos[0]->NOME;
						$gestorm = $envolvidos[0]->EMAIL;
					}elseif ($this->dados['adiantamento']->SITUACAO == 1){
						$situacao = "Aguardando Aprova��o Financeira";
						$assunto  = "Aguardando Aprova��o Financeira {$data}";
						$envolvidos = $apiUsuario->getEmailenvolvidos("{$this->dados['adiantamento']->SOLICITANTE}");
						foreach ($envolvidos as $rs) {
							$para[$a] = "{$rs->EMAIL}";
							$a = $a + 1;
						}
						$gestorn = "Contas a Pagar";
						$para[$a] = "{$contpg}";
						$gestorm = $contpg;
					}elseif ($this->dados['adiantamento']->SITUACAO == 2){
						$situacao = "Aguardando Presta��o de Contas";
						$assunto  = "Aguardando Presta��o de Contas {$data}";
						$envolvidos = $apiUsuario->getEmailenvolvidos("{$this->dados['adiantamento']->SOLICITANTE}");
						foreach ($envolvidos as $rs) {
							$para[$a] = "{$rs->EMAIL}";
							$a = $a + 1;
						}
						$gestorn = "Contas a Pagar";
						$para[$a] = "{$contpg}";
						$gestorm = $contpg;
					}elseif ($this->dados['adiantamento']->SITUACAO == 3){
						$situacao = "Aguardando Aprova��o Gerencial 2";
						$assunto  = "Aguardando Aprova��o Gerencial 2 {$data}";
						$envolvidos = $apiUsuario->getEmailenvolvidos("{$this->dados['adiantamento']->SOLICITANTE},{$this->dados['adiantamento']->DESTINATARIO}");
						foreach ($envolvidos as $rs) {
							$para[$a] = "{$rs->EMAIL}";
							$a = $a + 1;
						}
						$gestorn = $envolvidos[0]->NOME;
						$gestorm = $envolvidos[0]->EMAIL;
					}elseif ($this->dados['adiantamento']->SITUACAO == 4){
						$situacao = "Aguardando Aprova��o Financeira 2";
						$assunto  = "Aguardando Aprova��o Financeira 2 {$data}";
						$envolvidos = $apiUsuario->getEmailenvolvidos("{$this->dados['adiantamento']->SOLICITANTE}");
						foreach ($envolvidos as $rs) {
							$para[$a] = "{$rs->EMAIL}";
							$a = $a + 1;
						}
						$gestorn = "Contas a Pagar";
						$para[$a] = "{$contpg}";
						$gestorm = $contpg;
					}elseif ($this->dados['adiantamento']->SITUACAO == 5){
						$situacao = "Processando Pagamento";
						$assunto  = "Processando Pagamento {$data}";
						$envolvidos = $apiUsuario->getEmailenvolvidos("{$this->dados['adiantamento']->SOLICITANTE}");
						foreach ($envolvidos as $rs) {
							$para[$a] = "{$rs->EMAIL}";
							$a = $a + 1;
						}
						if(isset($emaildp)){
							$para[$a] = "{$emaildp}";
							$a = $a + 1;
							$df = "<p style='font-style: italic;margin-bottom:10px;'>Ser� feito um Desconto em Folha no valor de R$ {$vdf} .</p>";
						}
						$gestorn = "Contas a Pagar";
						$para[$a] = "{$contpg}";
						$gestorm = $contpg;
					}elseif ($this->dados['adiantamento']->SITUACAO == 6){
						$situacao = "Adiantamento Conclu�do";
						$assunto  = "Adiantamento Conclu�do {$data}";
						$envolvidos = $apiUsuario->getEmailenvolvidos("{$this->dados['adiantamento']->SOLICITANTE}");
						foreach ($envolvidos as $rs) {
							$para[$a] = "{$rs->EMAIL}";
							$a = $a + 1;
						}
						$gestorn = "Contas a Pagar";
						$para[$a] = "{$contpg}";
						$gestorm = $contpg;
					}elseif ($this->dados['adiantamento']->SITUACAO == 7){
						$situacao= "Adiantamento Cancelado";
						$assunto  = "Adiantamento Cancelado {$data}";
						$envolvidos = $apiUsuario->getEmailenvolvidos("{$this->dados['adiantamento']->SOLICITANTE}");
						foreach ($envolvidos as $rs) {
							$para[$a] = "{$rs->EMAIL}";
							$a = $a + 1;
						}
						$gestorn = "Contas a Pagar";
						$para[$a] = "{$contpg}";
						$gestorm = $contpg;
					}elseif ($this->dados['adiantamento']->SITUACAO == 8){
						$situacao= "Inconsist�ncia";
						$assunto  = "Inconsist�ncia {$data}";
						$envolvidos = $apiUsuario->getEmailenvolvidos("{$this->dados['adiantamento']->SOLICITANTE}");
						foreach ($envolvidos as $rs) {
							$para[$a] = "{$rs->EMAIL}";
							$a = $a + 1;
						}
						if ($this->dados['adiantamento']->SITUACAO_ANTERIOR == 0){
							$envolvidos = $apiUsuario->getEmailenvolvidos("{$this->dados['adiantamento']->DESTINATARIO}");
							foreach ($envolvidos as $rs) {
								$para[$a] = "{$rs->EMAIL}";
								$a = $a + 1;
							}
							$gestorn = $envolvidos[0]->NOME;
							$gestorm = $envolvidos[0]->EMAIL;
						}else{
							$gestorn = "Contas a Pagar";
							$para[$a] = "{$contpg}";
							$gestorm = $contpg;
						}
					}elseif ($this->dados['adiantamento']->SITUACAO == 9){
						$situacao= "Retorno da Inconsist�ncia";
						$assunto  = "Retorno da Inconsist�ncia {$data}";
						$envolvidos = $apiUsuario->getEmailenvolvidos("{$this->dados['adiantamento']->SOLICITANTE}");
						foreach ($envolvidos as $rs) {
							$para[$a] = "{$rs->EMAIL}";
							$a = $a + 1;
						}
						if ($this->dados['adiantamento']->SITUACAO_ANTERIOR == 0){
							$envolvidos = $apiUsuario->getEmailenvolvidos("{$this->dados['adiantamento']->DESTINATARIO}");
							foreach ($envolvidos as $rs) {
								$para[$a] = "{$rs->EMAIL}";
								$a = $a + 1;
							}
							$gestorn = $envolvidos[0]->NOME;
							$gestorm = $envolvidos[0]->EMAIL;
						}else{
							$gestorn = "Contas a Pagar";
							$para[$a] = "{$contpg}";
							$gestorm = $contpg;
						}
					}

					$exp_s = explode(" ", $this->dados['adiantamento']->NOME);
					$exp_s[1] = end($exp_s);
					$exp_g = explode(" ", $gestorn);
					$exp_g[1] = end($exp_g);
					$descricao = wordwrap($this->dados['adiantamento']->DES_ADIANTAMENTO, 60, "<br>", true);
					$mensagem = "<html>
									<head></head>
									<body style='margin:0px; padding:0px; border: 0 none; font-size: 9px; font-family: verdana, sans-serif; background-color: #efefef;'>
										<style type='text/css'>
											td p{margin-bottom: 10px;}
											body.ticket {margin:0px; padding:0px; border: 0 none; font-size: 9px; font-family: verdana, sans-serif; background-color: #efefef;}
											h1.title {margin-bottom:0px;}
											p.subtitle {color: #ccc;margin-top:0px;margin-bottom:0px;font-style: italic;}
											table.content {width: 700px; margin: 50px auto 50px auto; border: 1px #ccc solid; background: #fff; font-size: 11px; font-family: verdana, sans-serif;}
											td.uppercontent {border:0px;padding: 9px; color: #fff; background: #070075;}
											tr.lowercontent {padding: 10px;}
											td.leftcolumn {width: 400px; padding: 15px 0px 0px 18px; vertical-align: top;}
											td.rightcolumn {width: 240px; vertical-align: top;}
											div.rightcolumndiv{margin:15px 8px 15px;padding: 9px; border: 1px #ccc solid; font-size: 10px;}
											p.rcmessage {margin-top:5px;}
											a.links {color:#0000FF; text-decoration: none;}
											hr.rcdivider {height: 1px; color: #ccc;}
											p.tickethistory {margin-bottom:10px; margin-top:2px; font-style: italic;color: #606060;}
											table.ticket-sum-hist {border: 1px #ccc solid; background: #eee; width: 394px; font-size: 11px; font-family: verdana, sans-serif;}
											div.ticket-sum-histdiv {margin: 9px;}
											h2.ticket-sum-hist-titles {margin-bottom:5px; margin-top:10px; font-size:12px;}
											p.date {font-style: italic;margin-bottom:10px;}
										</style>
										<table style='width: 800px; margin: 50px auto 50px auto; border: 1px #ccc solid; background: #fff; font-size: 11px; font-family: verdana, sans-serif;' align='center'>
										<tbody>
											<tr>
												<td colspan='2' style='padding: 9px; color: #000000; background: #d0d0d0;'>
													<img src='' />
													<br>
													<p style='margin-top:0px;margin-bottom:0px;font-style: italic;'>Notifica��o do SPC.</p>
												</td>
											</tr>
											<tr style='padding: 10px;'>
												<td style='width: 240px; vertical-align: top;'>
													<div style='margin:15px 8px 15px;padding: 9px; border: 1px #ccc solid; font-size: 10px;'>
														<strong>{$cat}: </strong>{$this->dados['adiantamento']->ADIANTAMENTO}
														<hr style='height: 1px; color: #ccc;' />
														<strong>Data de Abertura:</strong> {$this->dados['adiantamento']->DTA_CADASTRO}<br />
														<br />
														<strong>Solicitado por:</strong> <a style='color:#0000FF; text-decoration: none;' href='mailto:{$this->dados['adiantamento']->EMAIL}?subject=[{$cat} #{$this->dados['adiantamento']->ADIANTAMENTO}] {$this->dados['adiantamento']->DES_TIPO}'>{$exp_s[0]} {$exp_s[1]}</a><br />
														<br />
														<strong>Empresa Origem:</strong> {$this->dados['adiantamento']->DES_EMPRESA}<br />
														<br />
														<strong>Empresa Destino:</strong> {$this->dados['adiantamento']->EMPRESA_DESTINO}<br />
														<br />
														<strong>Departamento:</strong> {$this->dados['adiantamento']->DEPARTAMENTO}<br />
														<br />
														<strong>Assunto:</strong> {$this->dados['adiantamento']->DES_TIPO}<br />
														<br />
														<strong>Categoria:</strong> {$cat}<br  />
														<br />
														<strong>Situacao:</strong> {$situacao}<br  />
														<br />
														<strong>Valor:</strong> {$valorr}<br />
														<br />
														<strong>Centro de Custo:</strong> {$cc[$this->dados['adiantamento']->CC]}<br />
														<br />
														<strong>Solicita��o URL:</strong> <a style='color:#0000FF; text-decoration: none;' href='".APP_ROOT."finan/adiantamento/alterar/{$this->dados['adiantamento']->ADIANTAMENTO}'>{$cat} {$this->dados['adiantamento']->ADIANTAMENTO}</a><br />
														<br />
														<strong>Autorizante Gestor:</strong> <a style='color:#0000FF; text-decoration: none;' href='mailto:{$gestorm}?subject=[{$cat} #{$this->dados['adiantamento']->ADIANTAMENTO}] {$this->dados['adiantamento']->DES_TIPO}'>{$exp_g[0]} {$exp_g[1]}</a><br />
														<br />
														<hr style='height: 1px; color: #ccc;' />
														<p style='margin-top:5px;'>se voc� quiser acessar o sistema para verificar seus
														Adiantamentos e Reembolsos Por favor acesse <a style='color:#0000FF; text-decoration: none;' href='".APP_ROOT."finan/adiantamento/'>
														aqui</a> e fa�a suas consultas.</p>
													</div>
												</td>
												<td style='width: 400px; padding: 15px 0px 0px 18px; vertical-align: top;'>
													<p style='margin-bottom: 10px;'>{$exp_s[0]} {$exp_s[1]},</p>
													<p style='font-style: italic;margin-bottom:10px;'>O {$cat}: {$this->dados['adiantamento']->ADIANTAMENTO} teve um movimento.</p>
													{$obs_env}
													{$df}
													<br>
													<br />
													<table style='border: 1px #ccc solid; background: #eee; width: 394px; font-size: 11px; font-family: verdana, sans-serif;'>
														<tr>
															<td>
																<div style='margin: 9px; max-width:500px;'>
																	<h2 style='margin-bottom:5px; margin-top:10px; font-size:12px;'>Reembolso: {$this->dados['adiantamento']->ADIANTAMENTO}</h2>
																	<p style='margin-bottom: 10px;'><strong>Assunto:</strong> {$this->dados['adiantamento']->DES_TIPO}</p>
																	<p style='margin-bottom: 10px;'><strong>Descri��o:</strong>{$descricao}</p>
																	<hr />
																	<br>
																	<br>
                 													<h2 style='margin-bottom:5px; margin-top:10px; font-size:12px;'>Autoriza��es & Hist�rico</h2>
				  													{$mov}	
																</div>
															</td>
														</tr>
													</table>
													<br />
													<br />
												</td>
											</tr>
										</tbody>
										</table>
									</body>
							</html>";
				  	$Envio = new EnvioEmail();
				  	$Envio->Envio($de, $assunto, $mensagem, $para, "", "");
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'finan/adiantamento/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'finan/adiantamento/index/sucesso');
					}
				}else{
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		$this->view();
	}
	public function excluir() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Exclus�o de Adiantamento";
		$adiantamento = new Adiantamento();
		$adiantamento->adiantamento = $this->getParams(0);
		$apiAdiantamento = new apiAdiantamento();
		$this->dados = array('adiantamento' => $apiAdiantamento->getAdiantamento($adiantamento));
		if (isset($this->dados['adiantamento'])){
			if ($this->dados['adiantamento']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'finan/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'finan/index/index/acessonegado');
			die();
		}
		$AdiantamentoPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$sql[$i] = $apiAdiantamento->delAdiantamento($adiantamento);
			$i = $i+1;
			$log = new Log();
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "E";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico = "ITEM||{$this->dados['adiantamento']->ITEM};;DES_ITEM||{$this->dados['adiantamento']->DES_ITEM};;ATIVO||{$this->dados['adiantamento']->ATIVO}";
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiAdiantamento->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'finan/adiantamento/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'finan/adiantamento/index/sucesso');
				}
			}else{
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}
		$this->view();
	}
}