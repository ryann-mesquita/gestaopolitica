<?php

namespace controller\finan;

use lib\Controller;
use helper\Security;

class indexController extends Controller {

	public function __construct() {

		parent::__construct();

		new Security($this->getModule(),$this->getController(),$this->getAction());
	}

	public function index() {

		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Financeiro M�naco";
		unset($_SESSION['filtro_sessao']);
		unset($_SESSION['consulta_sessao']);
		unset($_SESSION['aba_finan_sessao']);
		unset($_SESSION['aba_pagina_sessao']);
		$_SESSION['aba_finan_sessao'] = 'adiantamento';
		$_SESSION['aba_pagina_sessao']['ad'] = 1;
		$_SESSION['aba_pagina_sessao']['re'] = 1;
		$_SESSION['aba_pagina_sessao']['pr'] = 1;
		$_SESSION['aba_pagina_sessao']['in'] = 1;
		if ($_SERVER['REQUEST_METHOD'] === "POST"){
			$financeiro = $_POST['financeiro'];
			header('location:' . APP_ROOT .'finan/'.$financeiro);
		}
		
		$this->view();
	}
}