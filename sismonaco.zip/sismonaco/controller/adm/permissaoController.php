<?php

namespace controller\adm;

use lib\Controller;
use helper\Security;
use api\adm\apiPermissao;
use obj\adm\Permissao;
use obj\adm\Usuario;
use api\adm\apiUsuario;
use api\geral\apiEmpresa;
use api\dev\apiControle;
use api\dev\apiModulocontroleacao;

class permissaoController extends Controller {

	public function __construct() {

		parent::__construct();

		new Security($this->getModule(),$this->getController(),$this->getAction());
	}

	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Permiss�es";
		$this->view();
	}
	
	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Gerenciamento de Permiss�es";
		if (isset($_POST['selecionado']) || isset($_POST['selecionado_permissao'])){
			$apiPermissao = new apiPermissao();
			$permissao = new Permissao();
			if (isset($_POST['selecionado'])){
				$permissao->usuario = $_POST['selecionado'];
				$pagina = "index";
			}else{
				$permissao->usuario = $_POST['selecionado_permissao'];
				$pagina = "alterar";
			}
			$this->usuario = $permissao->usuario;
			$usuario = new Usuario();
			$usuario->usuario = $this->usuario;
			$apiUsuario = new apiUsuario();
			$rs = $apiUsuario->getUsuario($usuario);
			if (isset($rs)) {
				if ($rs->ATIVO == '0'){
					header('location:' .APP_ROOT. 'adm/index/index/acessonegado');
					die();
				}
			}else{
				header('location:' .APP_ROOT. 'adm/index/index/acessonegado');
				die();
			}
			$permissao->empresa = $_SESSION['empresa_sessao'];
			$this->permissao = $apiPermissao->permEmpresapadrao($permissao);
			if ((is_array($this->permissao) ? count($this->permissao) : 0) > 0) {
				foreach ($this->permissao as $p){
					$privilegio[$p->EMPRESA.$p->MODULO.$p->CONTROLE.$p->ACAO] = true;
				}
				$this->permissao = $privilegio;
			}
			$this->empresa_padrao = $rs->EMPRESA;
			$this->nome = $rs->NOME;
			$apiEmpresa = new apiEmpresa();
			$this->empresa = $apiEmpresa->filtroEmpresa('1','3','ativo', '1');
			$usuario->usuario = $_SESSION['usuario_sessao'];
			$this->modulo = $apiUsuario->getModulousuario($usuario);
			$apiControle = new apiControle();
			$this->controle = $apiControle->filtroControle("1","3","ativo","1");
			$apiModulocontroleacao = new apiModulocontroleacao();
			$this->modulocontroleacao = $apiModulocontroleacao->alloModulocontroleacao();
			foreach ($this->modulocontroleacao as $i){
				
				$this->modulos[$i->MODULO][$i->CONTROLE] = array('controle' => $i->CONTROLE, 'des_controle' => $i->DES_CONTROLE);
				$this->controles[$i->MODULO][$i->CONTROLE][$i->ACAO] = array('acao' => $i->ACAO,'des_acao' =>$i->DES_ACAO);
				
			}
			if ($pagina == "alterar" && $_SERVER['REQUEST_METHOD'] === 'POST') {
				$in = 0;
				$sql = array();
				$empresa = $_POST['empresa'];
				$tamanho_empresa = sizeof($empresa);
				for($i=0;$i<$tamanho_empresa;$i++) {
					foreach ($this->modulo as $modulo){
						foreach ($this->modulos[$modulo->MODULO] as $i1){
							foreach ($this->controles[$modulo->MODULO][$i1['controle']] as $i2){
								$permissao = new Permissao();
								$permissao->usuario = $this->usuario;
								$permissao->empresa = $empresa[$i];
								$permissao->modulo = $modulo->MODULO;
								$permissao->controle = $i1['controle'];
								$permissao->acao = $i2['acao'];
								$this->permissao = $apiPermissao->getPermissao($permissao);
								if(isset($_POST[$modulo->MODULO.",".$i1['controle'].",".$i2['acao']])) {
									if($this->permissao == NULL){
										$sql[$in] = $apiPermissao->addPermissao($permissao);
										$in = $in+1;
									}		
								}elseif(!isset($_POST[$modulo->MODULO.",".$i1['controle'].",".$i2['acao']])){
									if($this->permissao != NULL){
										$sql[$in] = $apiPermissao->delPermissao($permissao);
										$in = $in+1;
									}
								}
							}
						}
					}
				}
				$rs = $apiPermissao->executeSQL($sql);
				if (isset($rs[4])){
					if ($rs[4] == 'sucesso'){
						header('location:' .APP_ROOT. 'adm/permissao/index/sucesso');
					}
				}else{
					header('location:' .APP_ROOT. 'adm/permissao/index/insucesso');
				}
			}
			$this->view();
		}else {	
			header('location:' .APP_ROOT. 'adm/index/index/acessonegado');
			die();
		}
	}
}