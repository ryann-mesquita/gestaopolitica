<?php

namespace controller\adm;

use lib\Controller;
use helper\Security;
use api\adm\apiDepartamento;
use api\adm\apiCargo;
use helper\Paginator;
use obj\adm\Cargo;
use obj\geral\Log;
use api\geral\apiLog;

class cargoController extends Controller {
	
	public function __construct() {
		
		parent::__construct();
		
		new Security($this->getModule(),$this->getController(),$this->getAction());
	}
	
	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Lista de Cargo";
		$apiCargo = new apiCargo();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		$apiDepartamento = new apiDepartamento();
		$this->departamento = $apiDepartamento->filtroDepartamento('1','3','d.ativo', '1');
		(!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])) ? $a = '1' : $a = '3';
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$busca = array(
					'1' => array('c' => '1','a' => $a,'coluna' => 'ativo', 'valor' => '1'),
					'2' => array('c' => '1','a' => $a,'coluna' => 'ativo', 'valor' => '0'),
					'3' => array('c' => '1','a' => $a,'coluna' => 'departamento', 'valor' => @$_POST['busca_valor']),
					'4' => array('c' => '2','a' => $a,'coluna' => 'des_cargo', 'valor' => @$_POST['busca_valor']),
					'5' => array('c' => '1','a' => $a,'coluna' => 'cbo', 'valor' => @$_POST['busca_valor']),
					'6' => array('c' => '3','a' => $a,'coluna' => "",'valor' => "")
			);
			if(isset($busca[$_POST['busca']])){
				$this->dados = array('cargo' => $apiCargo->filtroCargo($busca[$_POST['busca']]['c'], $busca[$_POST['busca']]['a'], $busca[$_POST['busca']]['coluna'], $busca[$_POST['busca']]['valor']));
				$_SESSION['filtro_sessao'] = array('c' => $busca[$_POST['busca']]['c'], 'a' => $busca[$_POST['busca']]['a'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'valor' => $busca[$_POST['busca']]['valor'], 'busca' => $_POST['busca'], 'busca_valor' => isset($_POST['busca_valor']) ? $_POST['busca_valor'] : "");
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'adm/index/index/acessonegado');
				die();
			}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				$this->dados = array('cargo' => $apiCargo->filtroCargo($_SESSION['filtro_sessao']['c'],$_SESSION['filtro_sessao']['a'],$_SESSION['filtro_sessao']['coluna'], $_SESSION['filtro_sessao']['valor']));
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('cargo' => $apiCargo->filtroCargo('1','3','ativo', '1'));
					$_SESSION['filtro_sessao'] = array('c' => '1', 'a' => '3', 'coluna' => 'ativo' , 'valor' => '1', 'busca' => '6', 'busca_valor' => '');
					$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}
		}
		$TotalItem = (is_array($this->dados['cargo']) ? count($this->dados['cargo']) : 0);
		$this->dados['cargo'] = array_chunk($this->dados['cargo'], $ItemPorPagina);
		@$this->dados['cargo'] = $this->dados['cargo'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->view();
	}
	
	public function adicionar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Cadastro de Cargo";
		$apiCargo = new apiCargo();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		$apiDepartamento = new apiDepartamento();
		$this->departamento = $apiDepartamento->filtroDepartamento('1','3','d.ativo', '1');
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$Post = new Cargo('POST');
			$apiCargo = new apiCargo();
			$rs = $apiCargo->filtroCargo('1','3','des_cargo',$Post->des_cargo);
			if ((is_array($rs) ? count($rs) : 0) > 0){
				$this->rollback = new Cargo('POST');
				$this->Alert = "J� existe um cargo com esse nome cadastrado!";
			}else{
				$sql[$i] = $apiCargo->addCargo($Post);
				$i = $i+1;
				$log = new Log();
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico = "DEPARTAMENTO||{$Post->departamento};;DES_CARGO||{$Post->des_cargo};;CBO||{$Post->cbo};;ATIVO||{$Post->ativo}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiCargo->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'adm/cargo/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'adm/cargo/index/sucesso');
					}
				}else{
					$this->rollback = new Cargo('POST');
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		
		$this->view();
	}
	
	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Altera��o de Cargo";
		$cargo = new Cargo();
		$cargo->cargo = $this->getParams(0);
		$apiCargo = new apiCargo();
		$this->dados = array('cargo' => $apiCargo->getCargo($cargo));
		if (isset($this->dados['cargo'])){
			if ($this->dados['cargo']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'adm/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'adm/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		$apiDepartamento = new apiDepartamento();
		$this->departamento = $apiDepartamento->filtroDepartamento('1','3','d.ativo', '1');
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$Post = new Cargo('POST');
			$Post->cargo = $this->getParams(0);
			$rs = $apiCargo->filtroCargo('1','3','des_cargo',$Post->des_cargo);
			$log = new Log();
			$log->historico = "DEPARTAMENTO||{$this->dados['cargo']->DEPARTAMENTO};;DES_CARGO||{$this->dados['cargo']->DES_CARGO};;CBO||{$this->dados['cargo']->CBO};;ATIVO||{$this->dados['cargo']->ATIVO}";
			if ((is_array($rs) ? count($rs) : 0) > 0 && ($rs[0]->DES_CARGO != $this->dados['cargo']->DES_CARGO)){
				$this->dados['cargo']->DEPARTAMENTO = $Post->departamento;
				$this->dados['cargo']->DES_CARGO = $Post->des_cargo;
				$this->dados['cargo']->CBO = $Post->cbo;
				$this->dados['cargo']->ATIVO = $Post->ativo;
				$this->Alert = "J� existe um cargo com esse nome cadastrado!";
			}else{
				$sql[$i] = $apiCargo->editCargo($Post);
				$i = $i+1;
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "A";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico .= "::DEPARTAMENTO||{$Post->departamento};;DES_CARGO||{$Post->des_cargo};;CBO||{$Post->cbo};;ATIVO||{$Post->ativo}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiCargo->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'adm/cargo/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'adm/cargo/index/sucesso');
					}
				}else{
					$this->dados['cargo']->DEPARTAMENTO = $Post->departamento;
					$this->dados['cargo']->DES_CARGO = $Post->des_cargo;
					$this->dados['cargo']->CBO = $Post->cbo;
					$this->dados['cargo']->ATIVO = $Post->ativo;
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		$this->view();
	}
	public function excluir() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Exclus�o de Cargo";
		$cargo = new Cargo();
		$cargo->cargo = $this->getParams(0);
		$apiCargo = new apiCargo();
		$this->dados = array('cargo' => $apiCargo->getCargo($cargo));
		if (isset($this->dados['cargo'])){
			if ($this->dados['cargo']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'adm/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'adm/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$sql[$i] = $apiCargo->delCargo($cargo);
			$i = $i+1;
			$log = new Log();
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "E";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico = "CARGO||{$this->dados['cargo']->CARGO};;DEPARTAMENTO||{$this->dados['cargo']->DEPARTAMENTO};;DES_CARGO||{$this->dados['cargo']->DES_CARGO};;CBO||{$this->dados['cargo']->CBO};;ATIVO||{$this->dados['cargo']->ATIVO}";
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiCargo->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'adm/cargo/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'adm/cargo/index/sucesso');
				}
			}else{
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}
		$this->view();
	}
}