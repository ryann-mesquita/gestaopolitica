<?php

namespace controller\adm;

use lib\Controller;
use helper\Security;
use api\adm\apiUsuario;
use api\dev\apiModulo;
use api\dev\apiControle;
use api\dev\apiAcao;
use helper\Paginator;
use obj\geral\Log;
use api\geral\apiLog;

class logController extends Controller {
	
	public function __construct() {
		
		parent::__construct();
		
		new Security($this->getModule(),$this->getController(),$this->getAction());
	}
	
	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
	 	$this->header = "Logs do Sistema";
	 	$apiUsuario = new apiUsuario();
	 	$ItemPorPagina = 10;
	 	$PaginaAtual = 1;
	 	if ($this->getParams(1) > $PaginaAtual) {
	 		$PaginaAtual = $this->getParams(1);
	 	}
	 	$apiUsuario = new apiUsuario();
	 	$this->usuario = $apiUsuario->filtroUsuario('1', '3', 'u.ativo','1');
	 	$apiModulo = new apiModulo();
	 	$this->modulo = $apiModulo->filtroModulo('1', '3', 'ativo', '1');
	 	$apiControle = new apiControle();
	 	$this->controle = $apiControle->filtroControle('1', '3', 'ativo', '1');
	 	$apiAcao = new apiAcao();
	 	$this->acao = $apiAcao->filtroAcao('1', '3', 'ativo', '1');
	 	if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	 		unset($_SESSION['filtro_sessao']);
	 		unset($_SESSION['consulta_sessao']);
	 		$de = $_POST['de'];
	 		$ate = $_POST['ate'];
	 		$log = new Log();
	 		$log->usuario = $_POST['usuario'];
	 		$apiLog = new apiLog();
	 		if ($_POST['consulta'] == '1' ){
	 			$this->dados = array('log' => $apiLog->filtroLogacesso($de, $ate, $log->usuario));
	 			$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
	 		}else{
	 			$log->tipo = $_POST['tipo'];
	 			$log->modulo = $_POST['modulo'];
	 			$log->controle = $_POST['controle'];
	 			$log->acao = $_POST['acao'];
	 			$this->dados = array('log' => $apiLog->filtroLog($log, $de, $ate));
	 			$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
	 		}
	 		$_SESSION['filtro_sessao'] = array('consulta' => @$_POST['consulta'], 'de' => $de, 'ate' => $ate, 'usuario' => @$_POST['usuario'], 'modulo' => @$_POST['modulo'], 'controle' => @$_POST['controle'], 'acao' => @$_POST['acao'], 'tipo' => @$_POST['tipo']);
	 	}
	 	
	 	if (isset($_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']])){
	 		$this->dados = $_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']];
	 		$TotalItem = (is_array($this->dados['log']) ? count($this->dados['log']) : 0);
	 		$this->dados['log'] = array_chunk($this->dados['log'], $ItemPorPagina);
	 		@$this->dados['log'] = $this->dados['log'][$PaginaAtual - 1];
	 		if ($TotalItem > $ItemPorPagina) {
	 			$paginator = new Paginator();
	 			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
	 			$this->PaginaAtual = $PaginaAtual;
	 		}
	 	}
	 	$this->view();
	}
}