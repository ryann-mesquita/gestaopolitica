<?php

namespace controller\adm;

use lib\Controller;
use helper\Security;
use api\dev\apiRotina;
use helper\Paginator;
use obj\dev\Rotina;
use api\adm\apiAgendarotina;
use obj\adm\Agendarotina;
use obj\geral\Log;
use api\geral\apiLog;
use api\geral\apiEmail;
use helper\EnvioEmail;
use api\adm\apiRotinausuario;
use api\geral\apiFuncionario;
use api\adm\apiUsuario;
use obj\adm\Usuario;
use helper\Funcoes;
use api\ged\apiDocumento;
use helper\ServidorArquivo;
use obj\geral\Email;
use obj\ged\Documento;
use api\ged\apiUsuarioavisoorgao;
use obj\geral\Usuarioapollo;
use api\geral\apiApollo;
use obj\sav\Proposta;
use api\sav\apiProposta;
use obj\geral\Pandion;
use api\geral\apiPandion;
use obj\com\Parametros;
use api\com\apiIndex;
use obj\com\Produtivo;
use api\com\apiProdutivo;
use obj\finan\Adiantamento;
use api\finan\apiAdiantamento;
use obj\finan\Autorizacao;

include 'classes/PHPExcel.php';
include 'classes/adLDAP/adLDAP.php';

class agendarotinaController extends Controller {

	public function __construct() {

		parent::__construct();
		
		if ($this->getAction()['des_acao'] == 'index' || $this->getAction()['des_acao'] == 'alterar') {
			new Security($this->getModule(),$this->getController(),$this->getAction());
		}
	}

	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Lista de Rotinas";
		$apiRotina = new apiRotina();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		(!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])) ? $a = '1' : $a = '3';
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$busca = array(
				'1' => array('c' => '1','a' => $a, 'prioridade' => $_POST['prioridade'], 'coluna' => 'r.ativo', 'valor' => '1'),
				'2' => array('c' => '1','a' => $a, 'prioridade' => $_POST['prioridade'], 'coluna' => 'r.ativo', 'valor' => '0'),
				'3' => array('c' => '2','a' => $a, 'prioridade' => $_POST['prioridade'], 'coluna' => 'ar.frequencia', 'valor' => @$_POST['busca_valor']),
				'4' => array('c' => '2','a' => $a, 'prioridade' => $_POST['prioridade'], 'coluna' => 'r.des_rotina', 'valor' => @$_POST['busca_valor']),
				'5' => array('c' => '2','a' => $a, 'prioridade' => $_POST['prioridade'], 'coluna' => 'ar.dta_ult_execucao', 'valor' => @$_POST['busca_valor']),
				'6' => array('c' => '3','a' => $a, 'prioridade' => $_POST['prioridade'], 'coluna' => "",'valor' => "")
			);
			if(isset($busca[$_POST['busca']])){
				$this->dados = array('rotina' => $apiRotina->filtroRotina($busca[$_POST['busca']]['c'], $busca[$_POST['busca']]['a'], $busca[$_POST['busca']]['prioridade'], $busca[$_POST['busca']]['coluna'], $busca[$_POST['busca']]['valor']));
				$_SESSION['filtro_sessao'] = array('c' => $busca[$_POST['busca']]['c'], 'a' => $busca[$_POST['busca']]['a'], 'prioridade' => $busca[$_POST['busca']]['prioridade'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'busca_valor' => $busca[$_POST['busca']]['valor'], 'busca' => $_POST['busca']);
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'adm/index/index/acessonegado');
				die();
			}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				$this->dados = array('rotina' => $apiRotina->filtroRotina($_SESSION['filtro_sessao']['c'], $_SESSION['filtro_sessao']['a'], $_SESSION['filtro_sessao']['prioridade'], $_SESSION['filtro_sessao']['coluna'], $_SESSION['filtro_sessao']['busca_valor']));
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('rotina' => $apiRotina->filtroRotina('1','3','tudo', 'ativo', '1'));
					$_SESSION['filtro_sessao'] = array('c' => '1', 'a' => '3', 'prioridade' => 'tudo', 'coluna' => 'ativo' , 'busca_valor' => '1', 'busca' => '6');
					$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}
		}
		$TotalItem = (is_array($this->dados['rotina']) ? count($this->dados['rotina']) : 0);
		$this->dados['rotina'] = array_chunk($this->dados['rotina'], $ItemPorPagina);
		@$this->dados['rotina'] = $this->dados['rotina'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->view();
	}

	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$rotina= new Rotina();
		$rotina->rotina = $this->getParams(0);
		$this->rotina = $rotina->rotina;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		$apiRotina = new apiRotina();
		$rs = $apiRotina->getRotina($rotina);
		$this->header = $rs->DES_ROTINA;
		if (isset($rs)){
			if ($rs->ATIVO == '0'){
				header('location:' .APP_ROOT. 'adm/index/index/acessonegado');
				die();
			}
		}else{
			header('location:' .APP_ROOT. 'adm/index/index/acessonegado');
			die();
		}
		$agendarotina = new Agendarotina();
		$apiAgendarotina = new apiAgendarotina();
		$agendarotina->rotina = $rotina->rotina;
		$this->dados = array('agendarotina' => $apiAgendarotina->getAgendarotina($agendarotina));
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$log = new Log();
			$apiLog = new apiLog();
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->historico = "Registro de Movimento";
			$log->dta_registro = date("d/m/Y H:i:s");
			if ((is_array($this->dados['agendarotina']) ? count($this->dados['agendarotina']) : 0) == 1) {
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $this->rotina;
				$agendarotina->frequencia = $_POST['frequencia'];
				$agendarotina->hora_execucao = $_POST['hora_execucao'];
				(isset($_POST['segunda']) ? $agendarotina->segunda = $_POST['segunda'] : $agendarotina->segunda = 0);
				(isset($_POST['terca']) ? $agendarotina->terca = $_POST['terca'] : $agendarotina->terca = 0);
				(isset($_POST['quarta']) ? $agendarotina->quarta = $_POST['quarta'] : $agendarotina->quarta = 0);
				(isset($_POST['quinta']) ? $agendarotina->quinta = $_POST['quinta'] : $agendarotina->quinta = 0);
				(isset($_POST['sexta']) ? $agendarotina->sexta = $_POST['sexta'] : $agendarotina->sexta = 0);
				(isset($_POST['sabado']) ? $agendarotina->sabado = $_POST['sabado'] : $agendarotina->sabado = 0);
				(isset($_POST['domingo']) ? $agendarotina->domingo = $_POST['domingo'] : $agendarotina->domingo = 0);
				(isset($_POST['dia1']) ? $agendarotina->dia1 = $_POST['dia1'] : $agendarotina->dia1 = 0);
				(isset($_POST['dia2']) ? $agendarotina->dia2 = $_POST['dia2'] : $agendarotina->dia2 = 0);
				(isset($_POST['dia3']) ? $agendarotina->dia3 = $_POST['dia3'] : $agendarotina->dia3 = 0);
				(isset($_POST['dia4']) ? $agendarotina->dia4 = $_POST['dia4'] : $agendarotina->dia4 = 0);
				(isset($_POST['dia5']) ? $agendarotina->dia5 = $_POST['dia5'] : $agendarotina->dia5 = 0);
				(isset($_POST['dia6']) ? $agendarotina->dia6 = $_POST['dia6'] : $agendarotina->dia6 = 0);
				(isset($_POST['dia7']) ? $agendarotina->dia7 = $_POST['dia7'] : $agendarotina->dia7 = 0);
				(isset($_POST['dia8']) ? $agendarotina->dia8 = $_POST['dia8'] : $agendarotina->dia8 = 0);
				(isset($_POST['dia9']) ? $agendarotina->dia9 = $_POST['dia9'] : $agendarotina->dia9 = 0);
				(isset($_POST['dia10']) ? $agendarotina->dia10 = $_POST['dia10'] : $agendarotina->dia10 = 0);
				(isset($_POST['dia11']) ? $agendarotina->dia11 = $_POST['dia11'] : $agendarotina->dia11 = 0);
				(isset($_POST['dia12']) ? $agendarotina->dia12 = $_POST['dia12'] : $agendarotina->dia12 = 0);
				(isset($_POST['dia13']) ? $agendarotina->dia13 = $_POST['dia13'] : $agendarotina->dia13 = 0);
				(isset($_POST['dia14']) ? $agendarotina->dia14 = $_POST['dia14'] : $agendarotina->dia14 = 0);
				(isset($_POST['dia15']) ? $agendarotina->dia15 = $_POST['dia15'] : $agendarotina->dia15 = 0);
				(isset($_POST['dia16']) ? $agendarotina->dia16 = $_POST['dia16'] : $agendarotina->dia16 = 0);
				(isset($_POST['dia17']) ? $agendarotina->dia17 = $_POST['dia17'] : $agendarotina->dia17 = 0);
				(isset($_POST['dia18']) ? $agendarotina->dia18 = $_POST['dia18'] : $agendarotina->dia18 = 0);
				(isset($_POST['dia19']) ? $agendarotina->dia19 = $_POST['dia19'] : $agendarotina->dia19 = 0);
				(isset($_POST['dia20']) ? $agendarotina->dia20 = $_POST['dia20'] : $agendarotina->dia20 = 0);
				(isset($_POST['dia21']) ? $agendarotina->dia21 = $_POST['dia21'] : $agendarotina->dia21 = 0);
				(isset($_POST['dia22']) ? $agendarotina->dia22 = $_POST['dia22'] : $agendarotina->dia22 = 0);
				(isset($_POST['dia23']) ? $agendarotina->dia23 = $_POST['dia23'] : $agendarotina->dia23 = 0);
				(isset($_POST['dia24']) ? $agendarotina->dia24 = $_POST['dia24'] : $agendarotina->dia24 = 0);
				(isset($_POST['dia25']) ? $agendarotina->dia25 = $_POST['dia25'] : $agendarotina->dia25 = 0);
				(isset($_POST['dia26']) ? $agendarotina->dia26 = $_POST['dia26'] : $agendarotina->dia26 = 0);
				(isset($_POST['dia27']) ? $agendarotina->dia27 = $_POST['dia27'] : $agendarotina->dia27 = 0);
				(isset($_POST['dia28']) ? $agendarotina->dia28 = $_POST['dia28'] : $agendarotina->dia28 = 0);
				(isset($_POST['dia29']) ? $agendarotina->dia29 = $_POST['dia29'] : $agendarotina->dia29 = 0);
				(isset($_POST['dia30']) ? $agendarotina->dia30 = $_POST['dia30'] : $agendarotina->dia30 = 0);
				(isset($_POST['dia31']) ? $agendarotina->dia31 = $_POST['dia31'] : $agendarotina->dia31 = 0);
				$agendarotina->prioridade = $_POST['prioridade'];
				$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
				$log->tipo = "A";
			}else{
				$agendarotina = new Agendarotina('POST');
				$agendarotina->rotina = $this->rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[$i] = $apiAgendarotina->addAgendarotina($agendarotina);
				$log->tipo = "I";
			}
			$i = $i+1;
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiAgendarotina->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'adm/agendarotina/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'adm/agendarotina/index/sucesso');
				}
			}else{
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}

		$this->view();
	}
	
	public function execucao() {
		$funcoes = new Funcoes();
		$data = date('d/m/Y');
		$hora = date('H:i:s');
		$semana = $funcoes->retiraAcentos(str_replace("-feira", "", strtolower(strftime('%A'))));
		$dia = date('j');
		$agendarotina = new Agendarotina();
		$apiAgendarotina = new apiAgendarotina();
		$agenda1 = $apiAgendarotina->getRotinaagendada(1,$data, $hora, $dia, $semana);
		$agenda2 = $apiAgendarotina->getRotinaagendada(2,$data, $hora, $dia, $semana);
		$agenda3 = $apiAgendarotina->getRotinaagendada(3,$data, $hora, $dia, $semana);
		$agenda4 = $apiAgendarotina->getRotinaagendada(4,$data, $hora, $dia, $semana);
		$agendaemail = $apiAgendarotina->getRotinaemail($data, $hora);
		if ((is_array($agenda1) ? count($agenda1) : 0) > 0){
			$i = 0;
			unset($_SESSION['rotina_sessao']);
			foreach ($agenda1 as $rotina) {
				$_SESSION['rotina_sessao'][$i] = array('rotina' => $rotina->ROTINA, 'des_rotina' => $rotina->DES_ROTINA, 'validacao' => md5($rotina->ROTINA.date("dmY")));
				$i = $i + 1;
			}
			$_SESSION['contador_sessao'] = 0;
			header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
			die();
		}elseif ((is_array($agenda2) ? count($agenda2) : 0) > 0){
			$i = 0;
			unset($_SESSION['rotina_sessao']);
			foreach ($agenda2 as $rotina) {
				$_SESSION['rotina_sessao'][$i] = array('rotina' => $rotina->ROTINA, 'des_rotina' => $rotina->DES_ROTINA, 'validacao' => md5($rotina->ROTINA.date("dmY")));
				$i = $i + 1;
			}
			$_SESSION['contador_sessao'] = 0;
			header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
			die();
		}elseif ((is_array($agenda3) ? count($agenda3) : 0) > 0){
			$i = 0;
			unset($_SESSION['rotina_sessao']);
			foreach ($agenda3 as $rotina) {
				$_SESSION['rotina_sessao'][$i] = array('rotina' => $rotina->ROTINA, 'des_rotina' => $rotina->DES_ROTINA, 'validacao' => md5($rotina->ROTINA.date("dmY")));
				$i = $i + 1;
			}
			$_SESSION['contador_sessao'] = 0;
			header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
			die();
		}elseif ((is_array($agenda4) ? count($agenda4) : 0) > 0){
			$i = 0;
			unset($_SESSION['rotina_sessao']);
			foreach ($agenda4 as $rotina) {
				$_SESSION['rotina_sessao'][$i] = array('rotina' => $rotina->ROTINA, 'des_rotina' => $rotina->DES_ROTINA, 'validacao' => md5($rotina->ROTINA.date("dmY")));
				$i = $i + 1;
			}
			$_SESSION['contador_sessao'] = 0;
			header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
			die();
		}elseif ((is_array($agendaemail) ? count($agendaemail) : 0) > 0){
			$_SESSION['contador_sessao'] = 0;
			header("location:" .APP_ROOT. "adm/agendarotina/rotina{$agendaemail[0]->ROTINA}/{$agendaemail[0]->ROTINA}/".md5($agendaemail[0]->ROTINA.date('dmY'))."");
			die();	
		}else{
			session_unset();
			echo "Nenhuma Rotina Pendente, essa Pagina se autocarregar� em 10 minutos para uma prox�ma verifica��o!";
			exit();
		}
	}
	
	//********************************************Rotinas Que executam de Hora em Hora********************************************
	
	public function rotina36() {
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 36 && $validacao == md5($rotina.date("dmY"))) {
			$data = date('d/m/Y');
			$hora = date('H:i:s');
			$sql = array();
			$apiEmail = new apiEmail();
			$emails = $apiEmail->getEmail($data,$hora, 1, 460);
			if ((is_array($emails) ? count($emails) : 0) > 0) {
				$rotinas = $apiEmail->getGruporotina($data,$hora, 1, 460);
				$Envio = new EnvioEmail();
				if($Envio->Envioagendado($emails, $rotinas) == "sucesso"){
					$agendarotina = new Agendarotina();
					$agendarotina->rotina = $rotina;
					$agendarotina->dta_ult_execucao = $data;
					$agendarotina->hora_ult_execucao = date('H:i:s');
					$apiAgendarotina = new apiAgendarotina();
					$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
					$rs = $apiAgendarotina->executeSQL($sql);
					if ($rs[4] == "sucesso"){
						header("location:" .APP_ROOT. "adm/agendarotina/execucao");
						die();
					}else{
						header("location:" .APP_ROOT. "adm/agendarotina/execucao");
						die();
					}
				}else{
					$agendarotina = new Agendarotina();
					$agendarotina->rotina = $rotina;
					$agendarotina->dta_ult_execucao = $data;
					$agendarotina->hora_ult_execucao = date('H:i:s');
					$apiAgendarotina = new apiAgendarotina();
					$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
					$rs = $apiAgendarotina->executeSQL($sql);
					if ($rs[4] == "sucesso"){
						header("location:" .APP_ROOT. "adm/agendarotina/execucao");
						die();
					}else{
						header("location:" .APP_ROOT. "adm/agendarotina/execucao");
						die();
					}
				}
			}else{
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = $data;
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$apiAgendarotina = new apiAgendarotina();
				$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					header("location:" .APP_ROOT. "adm/agendarotina/execucao");
					die();
				}else{
					header("location:" .APP_ROOT. "adm/agendarotina/execucao");
					die();
				}
			}
		}
	}
	
	public function rotina37(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 37 && $validacao == md5($rotina.date("dmY"))) {
			$data = date('d/m/Y');
			$hora = date('H:i:s');
			$apiAgendarotina = new apiAgendarotina();
			$notas = array();
			$result = $apiAgendarotina->getInconsistenciasNF(date('d/m/Y'), date('d/m/Y'));
			$in = 0;
			$i = 1;
			$aPeso = array(4,3,2,9,8,7,6,5,4,3,2,9,8,7,6,5,4,3,2,9,8,7,6,5,4,3,2,9,8,7,6,5,4,3,2,9,8,7,6,5,4,3,2);
			
			$objPHPExcel = new \PHPExcel();
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'DATA' )
			->setCellValue('B1', "EMPRESA" )
			->setCellValue("C1", "REVENDA" )
			->setCellValue("D1", "CNPJ" )
			->setCellValue("E1", "FORNECEDOR" )
			->setCellValue("F1", "N NOTA" )
			->setCellValue("G1", "N SERIE" )
			->setCellValue("H1", "MODELO" )
			->setCellValue("I1", "CHAVE" )
			->setCellValue("J1", "ERRO" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(25);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(25);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(45);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(30);
			
			foreach ($result as $rs) {
				$n = strlen($chave43 = substr($rs->NFE_CHAVE_ACESSO,0,43));
				if ($n != 43){
					$notas[$in] = array('data'=>$rs->DTA_ENTRADA_SAIDA,'empresa'=>$rs->EMPRESA,'revenda'=>$rs->REVENDA,'cnpj'=>$rs->CNPJ,'fornecedor'=>$rs->CGC,'nota'=>$rs->NUMERO_NOTA_FISCAL,'serie'=>$rs->SERIE_NOTA_FISCAL,'modelo'=>$rs->COD_MODELO_NF_USOFISCAL,'chave'=>$rs->NFE_CHAVE_ACESSO,'erro'=>"Numero da Chave Menor que 44");
					$in = $in + 1;
				}else{
					$aChave = str_split($chave43);
					$soma = 0;
					$ponderacao = 0;
					for($x=42;$x > -1;$x--){
						$soma += $aPeso[$x] * $aChave[$x];
					}
					$resto = $soma%11;
					if ($resto == 0 || $resto == 1){
						$dv = 0;
					} else {
						$dv = 11-$resto;
					}
					if ( substr($rs->NFE_CHAVE_ACESSO,43,1) == $dv ){
						
						if (substr($rs->NFE_CHAVE_ACESSO,25,9) != str_pad($rs->NUMERO_NOTA_FISCAL, 9, 0,STR_PAD_LEFT)){
							$notas[$in] = array('data'=>$rs->DTA_ENTRADA_SAIDA,'empresa'=>$rs->EMPRESA,'revenda'=>$rs->REVENDA,'cnpj'=>$rs->CNPJ,'fornecedor'=>$rs->CGC,'nota'=>$rs->NUMERO_NOTA_FISCAL,'serie'=>$rs->SERIE_NOTA_FISCAL,'modelo'=>$rs->COD_MODELO_NF_USOFISCAL,'chave'=>$rs->NFE_CHAVE_ACESSO,'erro'=>"Numeracao da Nota");
							$in = $in + 1;
						}elseif (substr($rs->NFE_CHAVE_ACESSO,22,3) != str_pad($rs->SERIE_NOTA_FISCAL, 3, 0, STR_PAD_LEFT)){
							$notas[$in] = array('data'=>$rs->DTA_ENTRADA_SAIDA,'empresa'=>$rs->EMPRESA,'revenda'=>$rs->REVENDA,'cnpj'=>$rs->CNPJ,'fornecedor'=>$rs->CGC,'nota'=>$rs->NUMERO_NOTA_FISCAL,'serie'=>$rs->SERIE_NOTA_FISCAL,'modelo'=>$rs->COD_MODELO_NF_USOFISCAL,'chave'=>$rs->NFE_CHAVE_ACESSO,'erro'=>"Serie da Nota");
							$in = $in + 1;
						}elseif (substr($rs->NFE_CHAVE_ACESSO,20,2) != strval($rs->COD_MODELO_NF_USOFISCAL)){
							$notas[$in] = array('data'=>$rs->DTA_ENTRADA_SAIDA,'empresa'=>$rs->EMPRESA,'revenda'=>$rs->REVENDA,'cnpj'=>$rs->CNPJ,'fornecedor'=>$rs->CGC,'nota'=>$rs->NUMERO_NOTA_FISCAL,'serie'=>$rs->SERIE_NOTA_FISCAL,'modelo'=>$rs->COD_MODELO_NF_USOFISCAL,'chave'=>$rs->NFE_CHAVE_ACESSO,'erro'=>"Modelo da Nota");
							$in = $in + 1;
						}elseif ((substr($rs->NFE_CHAVE_ACESSO,6,14) != str_pad($rs->CNPJ, 14, 0, STR_PAD_LEFT)) && (substr($rs->NFE_CHAVE_ACESSO,6,14) != str_pad($rs->CGC, 14, 0, STR_PAD_LEFT))){
							$notas[$in] = array('data'=>$rs->DTA_ENTRADA_SAIDA,'empresa'=>$rs->EMPRESA,'revenda'=>$rs->REVENDA,'cnpj'=>$rs->CNPJ,'fornecedor'=>$rs->CGC,'nota'=>$rs->NUMERO_NOTA_FISCAL,'serie'=>$rs->SERIE_NOTA_FISCAL,'modelo'=>$rs->COD_MODELO_NF_USOFISCAL,'chave'=>$rs->NFE_CHAVE_ACESSO,'erro'=>"Fornecedor da Nota");
							$in = $in + 1;
						}
					}else {
						$notas[$in] = array('data'=>$rs->DTA_ENTRADA_SAIDA,'empresa'=>$rs->EMPRESA,'revenda'=>$rs->REVENDA,'cnpj'=>$rs->CNPJ,'fornecedor'=>$rs->CGC,'nota'=>$rs->NUMERO_NOTA_FISCAL,'serie'=>$rs->SERIE_NOTA_FISCAL,'modelo'=>$rs->COD_MODELO_NF_USOFISCAL,'chave'=>$rs->NFE_CHAVE_ACESSO,'erro'=>'Chave da Nota');
						$in = $in + 1;
					}
				}
			}
			
			if ((is_array($notas) ? count($notas) : 0) > 0) {
				foreach ($notas as $rs){
					$i = $i + 1;
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs['data']);
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs['empresa']);
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs['revenda']);
					$objPHPExcel->getActiveSheet()->setCellValueExplicitByColumnAndRow(3, $i, $rs['cnpj']);
					$objPHPExcel->getActiveSheet()->setCellValueExplicitByColumnAndRow(4, $i, $rs['fornecedor']);
					$objPHPExcel->getActiveSheet()->setCellValueExplicitByColumnAndRow(5, $i, $rs['nota']);
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $rs['serie']);
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $rs['modelo']);
					$objPHPExcel->getActiveSheet()->setCellValueExplicitByColumnAndRow(8, $i, $rs['chave']);
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, $rs['erro']);
				}
				
				$objPHPExcel->getActiveSheet()->setTitle('Notas Com Erros');
				$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
				
				$nome_arquivo = "NF-Alerta-".date("d-m-Y");
				$objWriter->save($_SERVER["DOCUMENT_ROOT"] . "/".RAIZ_PATH."dados/anexo/{$nome_arquivo}.xlsx");
				
				$de  = "SisMonaco - NF Alerta {$data}";
				$assunto   = "NFs Com Erro {$data}";
				$mensagem  = "Em Anexo as NFs que apresentam problemas" ;
				
				$para = array();
				$a = 0;
				$apiRotinausuario = new apiRotinausuario();
				$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
				foreach ($result as $rs) {
					$para[$a] = "{$rs->EMAIL}";
					$a = $a + 1;
				}
				$Envio = new EnvioEmail();
				if($Envio->Envio($de, $assunto, $mensagem, $para, "", "dados/anexo/{$nome_arquivo}.xlsx") == "sucesso") {
					$agendarotina = new Agendarotina();
					$agendarotina->rotina = $rotina;
					$agendarotina->dta_ult_execucao = $data;
					$agendarotina->hora_ult_execucao = date('H:i:s');
					$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
					$rs = $apiAgendarotina->executeSQL($sql);
					if ($rs[4] == "sucesso"){
						$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
						header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
						die();
					}else{
						$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
						header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
						die();
					}
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = $data;
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}
		}
	}
	
	public function rotina22(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 22 && $validacao == md5($rotina.date("dmY"))) {
			$data = date('d/m/Y');
			$hora = date('H:i:s');
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getTitulosemaberto();
			if ((is_array($result) ? count($result) : 0) > 0) {
				$objPHPExcel = new \PHPExcel();
				
				$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
				$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
				$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
				$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
				$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
				$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
				
				$objPHPExcel->setActiveSheetIndex(0)
				->setCellValue('A1', 'EMPRESA' )
				->setCellValue('B1', "REVENDA" )
				->setCellValue("C1", "TITULO" )
				->setCellValue("D1", "VALOR TITULO" )
				->setCellValue("E1", "CLIENTE" )
				->setCellValue("F1", "STATUS" );
				
				$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
				$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
				$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
				$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(15);
				$objPHPExcel->getActiveSheet()->getStyle('D')->getNumberFormat()->setFormatCode('#,##0.00');
				$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(15);
				$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(15);
				
				$i = 1;
				foreach ($result as $rs){
					$i = $i + 1;
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA);
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->TITULO);
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, str_replace(",", ".", $rs->VAL_TITULO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->CLIENTE);
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->STATUS);
				}
				
				$objPHPExcel->getActiveSheet()->setTitle('Titulos em Aberto');
				
				$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
				
				$nome_arquivo = "Titulo-".date("d-m-Y");
				$objWriter->save($_SERVER["DOCUMENT_ROOT"] . "/".RAIZ_PATH."dados/anexo/{$nome_arquivo}.xlsx");
				
				$de  = "SisMonaco - Titulos {$data}";
				$assunto   = "Titulos em aberto no sistema {$data}";
				$mensagem  = "Segue em anexo o relat�rio de titulos em aberto" ;
				
				$para = array();
				$a = 0;
				$apiRotinausuario = new apiRotinausuario();
				$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
				foreach ($result as $rs) {
					$para[$a] = "{$rs->EMAIL}";
					$a = $a + 1;
				}
				$Envio = new EnvioEmail();
				if($Envio->Envio($de, $assunto, $mensagem, $para, "", "dados/anexo/{$nome_arquivo}.xlsx") == "sucesso") {
					$agendarotina = new Agendarotina();
					$agendarotina->rotina = $rotina;
					$agendarotina->dta_ult_execucao = $data;
					$agendarotina->hora_ult_execucao = date('H:i:s');
					$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
					$rs = $apiAgendarotina->executeSQL($sql);
					if ($rs[4] == "sucesso"){
						$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
						header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
						die();
					}
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = $data;
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}
		}
	}
	public function rotina34(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 34 && $validacao == md5($rotina.date("dmY"))) {
			$apiFuncionario = new apiFuncionario();
			$admissao = $apiFuncionario->getAdmissao();
			$i = 0;
			$sql = array();
			
			if ((is_array($admissao) ? count($admissao) : 0) > 0){
					
				$mensagem  = "<html>
							  	<head></head>
								<body>
									<style type='text/css'>
										.fieldset {
										  border: 1px solid #ddd;
										  margin-top: 1em;
										  width: 500px;
										}
										.fieldset h3 {
										  font-size: 12px;
										  text-align: center;
										}
										.fieldset h3 span {
										  display: inline;
										  border: 1px solid #ddd;
										  background: #fff;
										  padding: 5px 10px;
										  position: relative;
										  top: -1.3em;
										}
									</style>
									<p><h3><b>Movimenta��es de Admiss�o</b></h3></p>";
				
				$apiUsuario =  new apiUsuario();
				$usuario =  new Usuario();
				foreach ($admissao as $rs){
					$usuario->contrato = $rs->CONTRATO;
					$usuario->cpf = "<str>".trim($rs->CPF);
					$usuario->nome = trim($rs->NOME);
					$usuario->tipo = ($rs->TIPO != "") ? $rs->TIPO : 2;
					$usuario->cargo = ($rs->CARGO != "") ? $rs->CARGO : 1;
					$usuario->departamento = ($rs->DEPARTAMENTO != "") ? $rs->DEPARTAMENTO : 1;
					$usuario->dta_nascimento = trim($rs->DTA_NASCIMENTO);
					$usuario->dta_admissao = trim($rs->DTA_ADMISSAO);
					$usuario->email = strtolower(str_replace("'", "", trim($rs->EMAIL)));
					$usuario->dta_ult_alteracao = date('d/m/Y H:i:s');
					if ($usuario->email == ""){
						$usuario->email = "naodefinido@grupomonaco.com.br";
					}
					$usuario->empresa = $rs->EMPRESA;
					$usuario->ativo = $rs->ATIVO;
					$usuario->dta_cadastro = date("d/m/Y H:i:s");
					$sql[$i] = $apiUsuario->addUsuario($usuario);
					$i = $i+1;
					$sql[$i] = "INSERT INTO sis_permissao (usuario,modulo,controle,acao,empresa) VALUES (seq_sis_usuario.currval,'7','1','1','{$rs->EMPRESA}')";
					$i = $i+1;
					$sql[$i] = "INSERT INTO sis_permissao (usuario,modulo,controle,acao,empresa) VALUES (seq_sis_usuario.currval,'7','40','1','{$rs->EMPRESA}')";
					$i = $i+1;
					$sql[$i] = "INSERT INTO sis_permissao (usuario,modulo,controle,acao,empresa) VALUES (seq_sis_usuario.currval,'7','40','2','{$rs->EMPRESA}')";
					$i = $i+1;
					$sql[$i] = "INSERT INTO sis_permissao (usuario,modulo,controle,acao,empresa) VALUES (seq_sis_usuario.currval,'7','40','3','{$rs->EMPRESA}')";
					$i = $i+1;
					$sql[$i] = "INSERT INTO sis_permissao (usuario,modulo,controle,acao,empresa) VALUES (seq_sis_usuario.currval,'5','1','1','{$rs->EMPRESA}')";
					$i = $i+1;
					$sql[$i] = "INSERT INTO sis_permissao (usuario,modulo,controle,acao,empresa) VALUES (seq_sis_usuario.currval,'9','1','1','{$rs->EMPRESA}')";
					$i = $i+1;
					$sql[$i] = "INSERT INTO sis_permissao (usuario,modulo,controle,acao,empresa) VALUES (seq_sis_usuario.currval,'9','52','1','{$rs->EMPRESA}')";
					$i = $i+1;
					$sql[$i] = "INSERT INTO sis_permissao (usuario,modulo,controle,acao,empresa) VALUES (seq_sis_usuario.currval,'9','52','2','{$rs->EMPRESA}')";
					$i = $i+1;
					$sql[$i] = "INSERT INTO sis_permissao (usuario,modulo,controle,acao,empresa) VALUES (seq_sis_usuario.currval,'9','52','3','{$rs->EMPRESA}')";
					
			
					$mensagem .= "<div class='fieldset'><h3><span>Admiss�o</span></h3>";
					$mensagem .= "<p>CPF: {$rs->CPF}<br>";
					$mensagem .= "Nome: {$rs->NOME}<br>";
					$mensagem .= "Email: {$rs->EMAIL}<br>";
					$mensagem .= "Data Admiss�o: {$rs->DTA_ADMISSAO}</p>";
					$mensagem .= "</div>";
				}
			
				$para = array();
				$data = date('d/m/Y');
				$de  = "SisMonaco - Admiss�o {$data}";
				$para[0] = "ti@grupomonaco.com.br";
				$assunto   = "Funcion�rios que foram admitidos no metadados. {$data}";
								
				$Envio = new EnvioEmail();
				$mensagem .= "</body></html>";
				$Envio->Envio($de, $assunto, $mensagem, $para, "", "");
			
				
			}		
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao =  date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$apiAgendarotina = new apiAgendarotina();
			if (isset($sql[$i])) {
				$i = $i+1;
				$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			}else{
				$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			}
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				if ((is_array($admissao) ? count($admissao) : 0) > 0) {
					foreach ($admissao as $rs){
						$mail = strtolower(str_replace("'", "", trim($rs->EMAIL)));
						$mail = explode("@", $mail);
						if (end($mail) == "grupomonaco.com.br"){
							$adldap = new \adLDAP();
							$surname = explode(" ", strtolower($rs->NOME));
							$attributes = array(
								"username" => $mail[0],
								"logon_name" => $mail[0]."@grupomonaco.local",
								"display_name" => $mail[0],
								"firstname" => current(explode(" ", strtolower($rs->NOME))),
								"surname" => end($surname),
								"email" => strtolower(str_replace("'", "", trim($rs->EMAIL))),
								"enabled" => true,
								"container" => array("Usuarios"),
								"password" => strtoupper(substr($rs->NOME, 0, 1)) . strtolower(substr($rs->NOME, 1, 1)) . str_replace(array(".", "-", " "), "", $rs->CPF),
							);
							try {
								$adldap->user()->create($attributes);
								$adldap->group()->addUser("grupo1", current(explode("@", $mail)));
							} catch (\adLDAPException $e) {
								echo "n�o foi poss�vel criar o usu�rio e adiciona-lo no grupo {$e}";
							}
							
							//Cria��o de Usu�rio Pandion
							$pandion = new Pandion();
							$pandion->username = $mail[0];
							$pandion->password =substr(ucfirst($rs->NOME), 0, 2).$rs->CPF;
							$apiPandion = new apiPandion();
							$apiPandion->addUsuario($pandion);
						}
					}
				}
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina62(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		$funcoes = new Funcoes();
		if ($rotina == 62 && $validacao == md5($rotina.date("dmY"))) {
			$apiFuncionario = new apiFuncionario();
			$inicioferias = $apiFuncionario->getFeriasinicio();
			$i = 0;
			$sql = array();
			
			if ((is_array($inicioferias) ? count($inicioferias) : 0) > 0){
				
				$mensagem  = "<html>
							  	<head></head>
								<body>
									<style type='text/css'>
										.fieldset {
										  border: 1px solid #ddd;
										  margin-top: 1em;
										  width: 500px;
										}
										.fieldset h3 {
										  font-size: 12px;
										  text-align: center;
										}
										.fieldset h3 span {
										  display: inline;
										  border: 1px solid #ddd;
										  background: #fff;
										  padding: 5px 10px;
										  position: relative;
										  top: -1.3em;
										}
									</style>
									<p><h3><b>Movimenta��es de In�cio de F�rias</b></h3></p>";
		
				$apiUsuario =  new apiUsuario();
				$usuario =  new Usuario();
				$usuario->ativo = 0;
				$apiApollo = new apiApollo();
				$usuarioapollo = new Usuarioapollo();
				$usuarioapollo->ativo = 'N';
				$usuarioapollo->status = 1;
				$usuarioapollo->usuario_rede = 'FERIAS';
				$usuarioapollo->dta_inativacao = date('d/m/Y');
				foreach ($inicioferias as $rs) {
					$usuario->usuario = $rs->USUARIO;
					$usuario->dta_ult_ini_ferias = $rs->DATAINICIOFERIAS;
					$usuario->dta_ult_fim_ferias = $rs->DATATERMINOFERIAS;
					$usuario->dta_ult_alteracao = date('d/m/Y H:i:s');
					$login = explode("@", $rs->EMAIL);
					$result = $apiApollo->getUsuarioapollo(strtoupper(trim($login[0])), $rs->CPF, $rs->EMAIL);
					if (isset($sql[$i])) {
						$i = $i+1;
						$sql[$i] = $apiUsuario->editUsuario($usuario);
					}else{
						$sql[$i] = $apiUsuario->editUsuario($usuario);
					}
					foreach ($result as $ap) {
						$usuarioapollo->usuario = $ap->USUARIO;
						if (isset($sql[$i])) {
							$i = $i+1;
							$sql[$i] = $apiApollo->atualizaUsuario($usuarioapollo);
							$i = $i+1;
							$sql[$i] = $apiApollo->atualizaVendedor($usuarioapollo);
							$i = $i+1;
							$sql[$i] = $apiApollo->atualizaMecanico($usuarioapollo);
						}else{
							$sql[$i] = $apiApollo->atualizaUsuario($usuarioapollo);
							$i = $i+1;
							$sql[$i] = $apiApollo->atualizaVendedor($usuarioapollo);
							$i = $i+1;
							$sql[$i] = $apiApollo->atualizaMecanico($usuarioapollo);
						}
					}
					
					$mensagem .= "<div class='fieldset'><h3><span>In�cio F�rias</span></h3>";
					$mensagem .= "<p>CPF: {$rs->CPF}<br>";
					$mensagem .= "Nome: {$rs->NOME}<br>";
					$mensagem .= "Email: {$rs->EMAIL}<br>";
					$mensagem .= "Data In�cio: {$rs->DATAINICIOFERIAS}<br>";
					$mensagem .= "Data T�rmino: {$rs->DATATERMINOFERIAS}</p>";
					$mensagem .= "</div>";
				}
				$para = array();
				$data = date('d/m/Y');
				$de  = "SisMonaco - In�cio F�rias {$data}";
				$para[0] = "ti@grupomonaco.com.br";
				$assunto   = "Funcion�rios que entraram de f�rias nessa data {$data}";
				$Envio = new EnvioEmail();
				$mensagem .= "</body></html>";
				$Envio->Envio($de, $assunto, $mensagem, $para, "", "");	
			}
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao =  date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$apiAgendarotina = new apiAgendarotina();
			if (isset($sql[$i])) {
				$i = $i+1;
				$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			}else{
				$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			}
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				if ((is_array($inicioferias) ? count($inicioferias) : 0) > 0) {
					foreach ($inicioferias as $rs){
						$mail = strtolower(str_replace("'", "", trim($rs->EMAIL)));
						$mail = explode("@", $mail);
						if (end($mail) == "grupomonaco.com.br"){
							$pandion = new Pandion();
							$adldap = new \adLDAP();
							$Username = $mail[0];
							try {
								$adldap->user()->modify($Username, array('enabled' => false));
								$pandion->password = $funcoes->senhaAleatoria();
								
							} catch (\adLDAPException $e) {
								echo "n�o foi poss�vel desativar o {$Username} {$e}";
							}
							//Editar Usu�rio Pandion
							$pandion->username = $Username;
							$apiPandion = new apiPandion();
							$apiPandion->editUsuario($pandion);
						}
					}
				}
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina63(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 63 && $validacao == md5($rotina.date("dmY"))) {
			$apiFuncionario = new apiFuncionario();
			$terminoferias = $apiFuncionario->getFeriastermino();
			$i = 0;
			$sql = array();
			
			if ((is_array($terminoferias) ? count($terminoferias) : 0) > 0){
				
				$mensagem  = "<html>
							  	<head></head>
								<body>
									<style type='text/css'>
										.fieldset {
										  border: 1px solid #ddd;
										  margin-top: 1em;
										  width: 500px;
										}
										.fieldset h3 {
										  font-size: 12px;
										  text-align: center;
										}
										.fieldset h3 span {
										  display: inline;
										  border: 1px solid #ddd;
										  background: #fff;
										  padding: 5px 10px;
										  position: relative;
										  top: -1.3em;
										}
									</style>
									<p><h3><b>Movimenta��es de T�rmino de F�rias</b></h3></p>";
				
				$apiUsuario =  new apiUsuario();
				$usuario =  new Usuario();
				$apiApollo = new apiApollo();
				$usuarioapollo = new Usuarioapollo();
				$usuarioapollo->ativo = 'S';
				$usuarioapollo->status = 0;
				$usuarioapollo->usuario_rede = 'RETORNO FERIAS';
				$usuarioapollo->dta_inativacao = date('d/m/Y');
				$fim = date('d/m/Y', strtotime('-1 days', strtotime(date('d-m-Y'))));
				foreach ($terminoferias as $rs) {
					if ($fim == $rs->DATATERMINOFERIAS){
						$usuario->usuario = $rs->USUARIO;
						$usuario->ativo = 1;
						$usuario->dta_ult_alteracao = date("d/m/Y H:i:s");
						$login = explode("@", $rs->EMAIL);
						$result = $apiApollo->getUsuarioapollo(strtoupper(trim($login[0])), $rs->CPF, $rs->EMAIL);
						if (isset($sql[$i])) {
							$i = $i+1;
							$sql[$i] = $apiUsuario->editUsuario($usuario);
						}else{
							$sql[$i] = $apiUsuario->editUsuario($usuario);
						}
						foreach ($result as $ap) {
							$usuarioapollo->usuario = $ap->USUARIO;
							if (isset($sql[$i])) {
								$i = $i+1;
								$sql[$i] = $apiApollo->atualizaUsuario($usuarioapollo);
								$i = $i+1;
								$sql[$i] = $apiApollo->atualizaVendedor($usuarioapollo);
								$i = $i+1;
								$sql[$i] = $apiApollo->atualizaMecanico($usuarioapollo);
							}else{
								$sql[$i] = $apiApollo->atualizaUsuario($usuarioapollo);
								$i = $i+1;
								$sql[$i] = $apiApollo->atualizaVendedor($usuarioapollo);
								$i = $i+1;
								$sql[$i] = $apiApollo->atualizaMecanico($usuarioapollo);
							}
						}
					}else{
						$usuario->usuario = $rs->USUARIO;
						$usuario->dta_ult_alteracao = date("d/m/Y H:i:s");
						if (isset($sql[$i])) {
							$i = $i+1;
							$sql[$i] = $apiUsuario->editUsuario($usuario);
						}else{
							$sql[$i] = $apiUsuario->editUsuario($usuario);
						}
						$mensagem .= "<div class='fieldset'><h3><span>T�rmino F�rias</span></h3>";
						$mensagem .= "<p>CPF: {$rs->CPF}<br>";
						$mensagem .= "Nome: {$rs->NOME}<br>";
						$mensagem .= "Email: {$rs->EMAIL}<br>";
						$mensagem .= "Data T�rmino: {$rs->DATATERMINOFERIAS}</p>";
						$mensagem .= "</div>";
					}
				}
				$fim = date('d/m/Y', strtotime('-1 days', strtotime(date('d-m-Y'))));
				$auth = "N�o";
				foreach ($terminoferias as $rs) {
					if ($fim != $rs->DATATERMINOFERIAS){
						$auth = "Sim";
					}
				}
				if ($auth == "Sim"){
					$para = array();
					$data = date('d/m/Y');
					$de  = "SisMonaco - T�rmino F�rias {$data}";
					$para[0] = "ti@grupomonaco.com.br";
					$assunto   = "Funcion�rios que retornaram de f�rias {$data}";
					$Envio = new EnvioEmail();
					$mensagem .= "</body></html>";
					$Envio->Envio($de, $assunto, $mensagem, $para, "", "");
				}
			}
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao =  date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$apiAgendarotina = new apiAgendarotina();
			if (isset($sql[$i])) {
				$i = $i+1;
				$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			}else{
				$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			}
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				if ((is_array($terminoferias) ? count($terminoferias) : 0) > 0) {
					foreach ($terminoferias as $rs){
						$fim = date('d/m/Y', strtotime('-1 days', strtotime(date('d-m-Y'))));
						if ($fim == $rs->DATATERMINOFERIAS){
							$nome = strtolower(trim($rs->NOME));
							$mail = strtolower(str_replace("'", "", trim($rs->EMAIL)));
							$mail = explode("@", $mail);
							if (end($mail) == "grupomonaco.com.br"){					
								$pandion = new Pandion();
								$adldap = new \adLDAP();
								$Username = $mail[0];
								try {
									$adldap->user()->modify($Username, array('enabled' => true));
									$pandion->password = $pandion->password = substr(ucfirst($rs->NOME), 0, 2).trim($rs->CPF);
									
								} catch (\adLDAPException $e) {
									echo "n�o foi poss�vel ativar o {$Username} {$e}";
								}
								//Editar Usu�rio Pandion
								$pandion->username = $Username;
								$apiPandion = new apiPandion();
								$apiPandion->editUsuario($pandion);			
							}
						}
					}
				}
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina64(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		$funcoes = new Funcoes();
		if ($rotina == 64 && $validacao == md5($rotina.date("dmY"))) {
			$apiFuncionario = new apiFuncionario();
			$demissao = $apiFuncionario->getDemissao();
			$i = 0;
			$sql = array();
			
			if ((is_array($demissao) ? count($demissao) : 0) > 0){
				
				$mensagem  = "<html>
							  	<head></head>
								<body>
									<style type='text/css'>
										.fieldset {
										  border: 1px solid #ddd;
										  margin-top: 1em;
										  width: 500px;
										}
										.fieldset h3 {
										  font-size: 12px;
										  text-align: center;
										}
										.fieldset h3 span {
										  display: inline;
										  border: 1px solid #ddd;
										  background: #fff;
										  padding: 5px 10px;
										  position: relative;
										  top: -1.3em;
										}
									</style>
									<p><h3><b>Movimenta��es de Desligamento</b></h3></p>";
				
				$apiUsuario =  new apiUsuario();
				$usuario =  new Usuario();
				$usuario->ativo = 0;
				$usuario->dta_demissao = date("d/m/Y");
				$usuario->dta_ult_alteracao = date('d/m/Y H:i:s');
				$apiApollo = new apiApollo();
				$usuarioapollo = new Usuarioapollo();
				$usuarioapollo->grupo = 219;
				$usuarioapollo->ativo = 'N';
				$usuarioapollo->status = 2;
				$usuarioapollo->usuario_rede = 'DESLIGADO';
				$usuarioapollo->dta_inativacao = $usuario->dta_demissao;
				foreach ($demissao as $rs) {
					$usuario->usuario = $rs->USUARIO;
					$login = explode("@", $rs->EMAIL);
					$result = $apiApollo->getUsuarioapollo(strtoupper(trim($login[0])), $rs->CPF, $rs->EMAIL);
					if (isset($sql[$i])) {
						$i = $i+1;
						$sql[$i] = $apiUsuario->editUsuario($usuario);
					}else{
						$sql[$i] = $apiUsuario->editUsuario($usuario);
					}
					foreach ($result as $ap) {
						$usuarioapollo->usuario = $ap->USUARIO;
						if (isset($sql[$i])) {
							$i = $i+1;
							$sql[$i] = $apiApollo->atualizaUsuario($usuarioapollo);
							$i = $i+1;
							$sql[$i] = $apiApollo->atualizaVendedor($usuarioapollo);
							$i = $i+1;
							$sql[$i] = $apiApollo->atualizaMecanico($usuarioapollo);
						}else{
							$sql[$i] = $apiApollo->atualizaUsuario($usuarioapollo);
							$i = $i+1;
							$sql[$i] = $apiApollo->atualizaVendedor($usuarioapollo);
							$i = $i+1;
							$sql[$i] = $apiApollo->atualizaMecanico($usuarioapollo);
						}
					}
					$mensagem .= "<div class='fieldset'><h3><span>Demiss�o</span></h3>";
					$mensagem .= "<p>CPF: {$rs->CPF}<br>";
					$mensagem .= "Nome: {$rs->NOME}<br>";
					$mensagem .= "Email: {$rs->EMAIL}<br>";
					$mensagem .= "Data Demiss�o: {$usuario->dta_demissao}</p>";
					$mensagem .= "</div>";
				}
			
				$para = array();
				$data = date('d/m/Y');
				$de  = "SisMonaco - Desligamento {$data}";
				$para[0] = "cpd@grupomonaco.com.br";
				$assunto   = "Funcion�rios que tiveram aviso pr�vio lan�ado no metadados. {$data}";
				$Envio = new EnvioEmail();
				$mensagem .= "</body></html>";
				$Envio->Envio($de, $assunto, $mensagem, $para, "", "");		
			}
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao =  date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$apiAgendarotina = new apiAgendarotina();
			if (isset($sql[$i])) {
				$i = $i+1;
				$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			}else{
				$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			}
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				if ((is_array($demissao) ? count($demissao) : 0) > 0){
					foreach ($demissao as $rs){
						$mail = strtolower(str_replace("'", "", trim($rs->EMAIL)));
						$mail = explode("@", $mail);
						if (end($mail) == "grupomonaco.com.br"){
							$pandion = new Pandion();
							$adldap = new \adLDAP();
							$Username = $mail[0];
							try {
								$adldap->user()->modify($Username, array('enabled' => false));
								$pandion->password = $funcoes->senhaAleatoria();	
							} catch (\adLDAPException $e) {
								echo "n�o foi poss�vel desativar o {$Username} {$e}";
							}
							//Editar Usu�rio Pandion
							$pandion->username = $Username;
							$apiPandion = new apiPandion();
							$apiPandion->editUsuario($pandion);
						}
					}
				}
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina65(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 65 && $validacao == md5($rotina.date("dmY"))) {
			$apiFuncionario = new apiFuncionario();
			$atualizaemail = $apiFuncionario->atualizaEmail();
			$i = 0;
			$sql = array();
			if ((is_array($atualizaemail) ? count($atualizaemail) : 0) > 0){
				$apiUsuario =  new apiUsuario();
				$usuario =  new Usuario();
				foreach ($atualizaemail as $rs) {
					$usuario->usuario = $rs->USUARIO;
					$usuario->email = strtolower(str_replace("'", "", trim($rs->EMAIL)));
					if (isset($sql[$i])) {
						$i = $i+1;
						$sql[$i] = $apiUsuario->editUsuario($usuario);
					}else{
						$sql[$i] = $apiUsuario->editUsuario($usuario);
					}
				}
			}
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao =  date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$apiAgendarotina = new apiAgendarotina();
			if (isset($sql[$i])) {
				$i = $i+1;
				$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			}else{
				$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			}
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina66(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 66 && $validacao == md5($rotina.date("dmY"))) {
			$dia = date("d");
			$timestamp = strtotime(date("Y-m-d"));
			$util = date('N',$timestamp);
			$util2 = $util + 1;
			$i = 0;
			$sql = array();
			if (($dia == "01" && $util <= 5) ||($dia == "02" && $util2 == 2) || ($dia == "03" && $util2 == 2)) {
				$empresas = array();
				$empresas[0] = array('empresa' => '13', 'revenda' => '1');
				$empresas[1] = array('empresa' => '13', 'revenda' => '2');
				$funcoes = new Funcoes();
				$apiIndex = new apiIndex();
				$apiProdutivo = new apiProdutivo();
				foreach ($empresas as $rs){
					$parametros = new Parametros();
					$parametros->empresa = $rs['empresa'];
					$parametros->revenda = $rs['revenda'];
					$parametros->mes = "<str>".date('m');
					$parametros->ano = date('Y');
					$parametros->maodeobra = $apiIndex->getPrecomaoobra("{$rs['empresa']}.{$rs['revenda']}", "9")->PRC_PUBLICO;
					$produtivo = new Produtivo();
					$produtivo->empresa = $rs['empresa'];
					$produtivo->revenda = $rs['revenda'];
					$resultado = $apiProdutivo->getProdutivo($produtivo);
					$parametros->qtd_meca = $resultado->QTD_MECA;
					$parametros->qtd_elet = $resultado->QTD_ELET;
					$parametros->qtd_cons = $resultado->QTD_CONS;
					$parametros->mec_prod1 = $resultado->MEC_PROD1;
					$parametros->mec_prod2 = $resultado->MEC_PROD2;
					$parametros->mec_prod3 = $resultado->MEC_PROD3;
					$parametros->mec_prod4 = $resultado->MEC_PROD4;
					$parametros->ele_prod1 = $resultado->ELE_PROD1;
					$parametros->ele_prod2 = $resultado->ELE_PROD2;
					$parametros->ele_prod3 = $resultado->ELE_PROD3;
					$parametros->ele_prod4 = $resultado->ELE_PROD4;
					$parametros->con_prod1 = $resultado->CON_PROD1;
					$parametros->con_prod2 = $resultado->CON_PROD2;
					$parametros->con_prod3 = $resultado->CON_PROD3;
					$parametros->con_prod4 = $resultado->CON_PROD4;
					$parametros->ila = $resultado->ILA;
					$sql[$i] = $apiProdutivo->addParametros($parametros);
					$i = $i+1;
				}
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao =  date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$apiAgendarotina = new apiAgendarotina();
				if (isset($sql[$i])) {
					$i = $i+1;
					$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
				}else{
					$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
				}
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$apiAgendarotina = new apiAgendarotina();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}
		}
	}
	
	public function rotina68(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		$funcoes = new Funcoes();
		if ($rotina == 68 && $validacao == md5($rotina.date("dmY"))) {
			$apiFuncionario = new apiFuncionario();
			$afastamentoinicio = $apiFuncionario->getAfastamentoinicio();
			$afastamentotermino = $apiFuncionario->getAfastamentotermino();
			$i = 0;
			$sql = array();
			
			if ((is_array($afastamentoinicio) ? count($afastamentoinicio) : 0) > 0){
				$mensagem  = "<html>
							  	<head></head>
								<body>
									<style type='text/css'>
										.fieldset {
										  border: 1px solid #ddd;
										  margin-top: 1em;
										  width: 500px;
										}
										.fieldset h3 {
										  font-size: 12px;
										  text-align: center;
										}
										.fieldset h3 span {
										  display: inline;
										  border: 1px solid #ddd;
										  background: #fff;
										  padding: 5px 10px;
										  position: relative;
										  top: -1.3em;
										}
									</style>
									<p><h3><b>Movimenta��es de In�cio do Afastamento</b></h3></p>";
				
				$apiUsuario =  new apiUsuario();
				$usuario =  new Usuario();
				$apiApollo = new apiApollo();
				$usuarioapollo = new Usuarioapollo();
				foreach ($afastamentoinicio as $rs) {
					$usuario->usuario = $rs->USUARIO;
					$usuario->ativo = 0;
					$usuario->dta_ult_alteracao = date('d/m/Y H:i:s');
					$usuarioapollo->ativo = 'N';
					$usuarioapollo->status = 1;
					$usuarioapollo->usuario_rede = 'INICIO AFASTAMENTO';
					$usuarioapollo->dta_inativacao = date('d/m/Y');
					$login = explode("@", $rs->EMAIL);
					$result = $apiApollo->getUsuarioapollo(strtoupper(trim($login[0])), $rs->CPF, $rs->EMAIL);
					if (isset($sql[$i])) {
						$i = $i+1;
						$sql[$i] = $apiUsuario->editUsuario($usuario);
					}else{
						$sql[$i] = $apiUsuario->editUsuario($usuario);
					}
					foreach ($result as $ap) {
						$usuarioapollo->usuario = $ap->USUARIO;
						if (isset($sql[$i])) {
							$i = $i+1;
							$sql[$i] = $apiApollo->atualizaUsuario($usuarioapollo);
							$i = $i+1;
							$sql[$i] = $apiApollo->atualizaVendedor($usuarioapollo);
							$i = $i+1;
							$sql[$i] = $apiApollo->atualizaMecanico($usuarioapollo);
						}else{
							$sql[$i] = $apiApollo->atualizaUsuario($usuarioapollo);
							$i = $i+1;
							$sql[$i] = $apiApollo->atualizaVendedor($usuarioapollo);
							$i = $i+1;
							$sql[$i] = $apiApollo->atualizaMecanico($usuarioapollo);
						}
					}
				
					$mensagem .= "<div class='fieldset'><h3><span>{$rs->DESCRICAO40}</span></h3>";
					$mensagem .= "<p>Contrato: {$rs->CONTRATO}<br>";
					$mensagem .= "CPF: {$rs->CPF}<br>";
					$mensagem .= "Nome: {$rs->NOME}<br>";
					$mensagem .= "Email: {$rs->EMAIL}<br>";
					$mensagem .= "Unidade: {$rs->UNIDADE}<br>";
					$mensagem .= "Inicio Afastamento: {$rs->DATAINICIOOCORRENCIA}<br>";
					$mensagem .= "T�rmino Afastamento: {$rs->DATATERMINOOCORRENCIA}</p>";
					$mensagem .= "</div>";
					
				}
				
				$para = array();
				$data = date('d/m/Y');
				$de  = "SisMonaco - In�cio Afastamento {$data}";
				$para[0] = "cpd@grupomonaco.com.br";
				$para[1] = "carloscosta@grupomonaco.com.br";
				$para[2] = "fabianoferro@grupomonaco.com.br";
				$assunto   = "Funcion�rios que tiveram fastamento. {$data}";
				$Envio = new EnvioEmail();
				$mensagem .= "</body></html>";
				$Envio->Envio($de, $assunto, $mensagem, $para, "", "");
			}
			if ((is_array($afastamentotermino) ? count($afastamentotermino) : 0) > 0){
				$mensagem  = "<html>
							  	<head></head>
								<body>
									<style type='text/css'>
										.fieldset {
										  border: 1px solid #ddd;
										  margin-top: 1em;
										  width: 500px;
										}
										.fieldset h3 {
										  font-size: 12px;
										  text-align: center;
										}
										.fieldset h3 span {
										  display: inline;
										  border: 1px solid #ddd;
										  background: #fff;
										  padding: 5px 10px;
										  position: relative;
										  top: -1.3em;
										}
									</style>
									<p><h3><b>Movimenta��es de Retorno do Afastamento</b></h3></p>";
				
				$apiUsuario =  new apiUsuario();
				$usuario =  new Usuario();
				$apiApollo = new apiApollo();
				$usuarioapollo = new Usuarioapollo();
				$usuarioapollo->ativo = 'S';
				$usuarioapollo->status = 0;
				$usuarioapollo->usuario_rede = 'RETORNO AFASTAMENTO';
				$usuarioapollo->dta_inativacao = date('d/m/Y');
				foreach ($afastamentotermino as $rs) {
					$usuario->usuario = $rs->USUARIO;
					$usuario->ativo = 1;
					$usuario->dta_ult_alteracao = date("d/m/Y H:i:s");
					$login = explode("@", $rs->EMAIL);
					$result = $apiApollo->getUsuarioapollo(strtoupper(trim($login[0])), $rs->CPF, $rs->EMAIL);
					if (isset($sql[$i])) {
						$i = $i+1;
						$sql[$i] = $apiUsuario->editUsuario($usuario);
					}else{
						$sql[$i] = $apiUsuario->editUsuario($usuario);
					}
					foreach ($result as $ap) {
						$usuarioapollo->usuario = $ap->USUARIO;
						if (isset($sql[$i])) {
							$i = $i+1;
							$sql[$i] = $apiApollo->atualizaUsuario($usuarioapollo);
							$i = $i+1;
							$sql[$i] = $apiApollo->atualizaVendedor($usuarioapollo);
							$i = $i+1;
							$sql[$i] = $apiApollo->atualizaMecanico($usuarioapollo);
						}else{
							$sql[$i] = $apiApollo->atualizaUsuario($usuarioapollo);
							$i = $i+1;
							$sql[$i] = $apiApollo->atualizaVendedor($usuarioapollo);
							$i = $i+1;
							$sql[$i] = $apiApollo->atualizaMecanico($usuarioapollo);
						}
					}
					$mensagem .= "<div class='fieldset'><h3><span>{$rs->DESCRICAO40}</span></h3>";
					$mensagem .= "<p>Contrato: {$rs->CONTRATO}<br>";
					$mensagem .= "CPF: {$rs->CPF}<br>";
					$mensagem .= "Nome: {$rs->NOME}<br>";
					$mensagem .= "Email: {$rs->EMAIL}<br>";
					$mensagem .= "Unidade: {$rs->UNIDADE}<br>";
					$mensagem .= "Inicio Afastamento: {$rs->DATAINICIOOCORRENCIA}<br>";
					$mensagem .= "T�rmino Afastamento: {$rs->DATATERMINOOCORRENCIA}</p>";
					$mensagem .= "</div>";
				}
				$para = array();
				$data = date('d/m/Y');
				$de  = "SisMonaco - Retorno Afastamento {$data}";
				$para[0] = "cpd@grupomonaco.com.br";
				$para[1] = "carloscosta@grupomonaco.com.br";
				$para[2] = "fabianoferro@grupomonaco.com.br";
				$assunto   = "Funcion�rios que retornaram do fastamento. {$data}";
				$Envio = new EnvioEmail();
				$mensagem .= "</body></html>";
				$Envio->Envio($de, $assunto, $mensagem, $para, "", "");
			}
			
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao =  date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$apiAgendarotina = new apiAgendarotina();
			if (isset($sql[$i])) {
				$i = $i+1;
				$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			}else{
				$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			}
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				if ((is_array($afastamentoinicio) ? count($afastamentoinicio) : 0) > 0){
					foreach ($afastamentoinicio as $rs) {
						$mail = strtolower(str_replace("'", "", trim($rs->EMAIL)));
						$mail = explode("@", $mail);
						if (end($mail) == "grupomonaco.com.br"){
							$pandion = new Pandion();
							$adldap = new \adLDAP();
							$Username = $mail[0];
							try {
								$adldap->user()->modify($Username, array('enabled' => false));
								$pandion->password = $funcoes->senhaAleatoria();
							} catch (\adLDAPException $e) {
								echo "n�o foi poss�vel desativar o {$Username} {$e}";
							}
							//Editar Usu�rio Pandion
							$pandion->username = $Username;
							$apiPandion = new apiPandion();
							$apiPandion->editUsuario($pandion);
						}
					}
				}
				if ((is_array($afastamentotermino) ? count($afastamentotermino) : 0) > 0){
					foreach ($afastamentotermino as $rs) {
						$mail = strtolower(str_replace("'", "", trim($rs->EMAIL)));
						$mail = explode("@", $mail);
						if (end($mail) == "grupomonaco.com.br"){
							$pandion = new Pandion();
							$adldap = new \adLDAP();
							$Username = $mail[0];
							try {
								$adldap->user()->modify($Username, array('enabled' => true));
								$pandion->password = $pandion->password = substr(ucfirst($rs->NOME), 0, 2).trim($rs->CPF);
								
							} catch (\adLDAPException $e) {
								echo "n�o foi poss�vel ativar o {$Username} {$e}";
							}
							//Editar Usu�rio Pandion
							$pandion->username = $Username;
							$apiPandion = new apiPandion();
							$apiPandion->editUsuario($pandion);
						}
					}
				}
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina58(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 58 && $validacao == md5($rotina.date("dmY"))) {
			$i = 0;
			$sql = array();
			$funcoes = new Funcoes();
			$apiAgendarotina = new apiAgendarotina();
			$data = date('d/m/Y');
			$result = $apiAgendarotina->getSincronizasav();
			if ((is_array($result) ? count($result) : 0) > 0){
				$proposta = new Proposta();
				$apiProposta = new apiProposta();
				$apiUsuario = new apiUsuario();
				foreach ($result as $rs) {
					$proposta->empresa = $rs->SAV_EMPRESA;
					$proposta->proposta = $rs->SAV_PROPOSTA;
					$usuario = $apiUsuario->filtroUsuario("1", "3", "u.cpf", str_pad($rs->CPF_VENDEDOR, 11, "0", STR_PAD_LEFT));
					if (isset($usuario[0]->USUARIO)){
						$proposta->vendedor = $usuario[0]->USUARIO;
					}
					
					$proposta->vendedor_nome = $rs->NOME_VENDEDOR;
					$proposta->des_vendedor = "VENDEDOR: ".$proposta->vendedor_nome." CPF: ".$funcoes->mask(str_pad($rs->CPF_VENDEDOR, 11, "0", STR_PAD_LEFT),"###.###.###-##")."\r\n"."GERENTE: ".strtoupper($rs->NOME_GERENTE)." CPF: ".$funcoes->mask($rs->CPF_GERENTE,"###.###.###-##");
					$proposta->cliente = $rs->CLIENTE;
					$proposta->cliente_nome = $rs->NOME;
					$proposta->nf_entrada = $rs->NF_ENTRADA;
					$proposta->nf_saida = $rs->NF_SAIDA;
					$proposta->nf_direta = $rs->NF_DIRETA;
				
					if (($rs->TIPO_RENAVAM != NULL) && (($rs->TIPO_RENAVAM == 8) || ($rs->TIPO_RENAVAM == 14))){
						$proposta->tipo_renavam = $rs->TIPO_RENAVAM;	
					}
					$proposta->chassi = $rs->CHASSI;
					$proposta->modelo = $rs->DES_MODELO;
					$proposta->situacao = $rs->SITUACAO;
					if (($rs->SITUACAO == 7) || ($rs->SITUACAO == 9)){
						$proposta->dta_conclusao = $rs->DTA_VENDA;
					}
					$proposta->dta_ult_alteracao = date("d/m/Y H:i:s");
					$sql[$i] = $apiProposta->editProposta($proposta);
					$i = $i+1;
				}
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = $data;
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = $data;
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}
		}
	}
	
	public function rotina59(){
		$rotina = $this->getParams(0);
		if (isset($_SERVER['HTTP_CLIENT_IP'])){
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		}elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])){
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		}else{
			$ip = $_SERVER['REMOTE_ADDR'];
		}
		if ($rotina == 59 && $ip == "10.3.101.3") {
			$temperatura = substr(shell_exec('c:\\httpget\\httpget.exe -r -S "*SRTC\r" 10.3.101.66:2000'),2);
			echo "A temperatura atual do CPD � : {$temperatura} C";
			if($temperatura > 22.0){
				//Silvio Mota
				$rand = rand();
				$url = 'http://10.3.99.3/default/en_US/sms_info.html';
				$line = '1'; // sim card to use in my case #1
				$telnum = '5591984439232'; // phone number to send sms
				$smscontent = "A temperatura do CPD esta em {$temperatura} C"; //your message
				$username = "admin"; //goip username
				$password = "m0n4c0"; //goip password
				$fields_string = "";
				
				$fields = array(
						'line' => urlencode($line),
						'smskey' => urlencode($rand),
						'action' => urlencode('sms'),
						'telnum' => urlencode($telnum),
						'smscontent' => urlencode($smscontent),
						'send' => urlencode('send')
				);
				
				//url-ify the data for the POST
				foreach($fields as $key=>$value)
				{ $fields_string .= $key.'='.$value.'&'; }
				rtrim($fields_string, '&');
				
				//open connection
				$ch = curl_init();
				
				//set the url, number of POST vars, POST data
				curl_setopt($ch,CURLOPT_URL, $url);
				
				curl_setopt($ch, CURLOPT_URL, $url);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
				curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
				curl_setopt($ch, CURLOPT_PORT, 80);
				curl_setopt($ch,CURLOPT_POST, (is_array($fields) ? count($fields) : 0));
				curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);
				
				//execute post
				curl_exec($ch);
				curl_getinfo($ch);
				
				//close connection
				sleep(15);
				curl_close($ch);
				
				//Claudio Raiol
				$rand = rand();
				$url = 'http://10.3.99.3/default/en_US/sms_info.html';
				$line = '2'; // sim card to use in my case #1
				$telnum = '5591991047720'; // phone number to send sms
				$smscontent = "A temperatura do CPD esta em {$temperatura} C"; //your message
				$username = "admin"; //goip username
				$password = "m0n4c0"; //goip password
				$fields_string = "";
				
				$fields = array(
						'line' => urlencode($line),
						'smskey' => urlencode($rand),
						'action' => urlencode('sms'),
						'telnum' => urlencode($telnum),
						'smscontent' => urlencode($smscontent),
						'send' => urlencode('send')
				);
				
				//url-ify the data for the POST
				foreach($fields as $key=>$value)
				{ $fields_string .= $key.'='.$value.'&'; }
				rtrim($fields_string, '&');
				
				//open connection
				$ch = curl_init();
				
				//set the url, number of POST vars, POST data
				curl_setopt($ch,CURLOPT_URL, $url);
				
				curl_setopt($ch, CURLOPT_URL, $url);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
				curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
				curl_setopt($ch, CURLOPT_PORT, 80);
				curl_setopt($ch,CURLOPT_POST, (is_array($fields) ? count($fields) : 0));
				curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);
				
				//execute post
				curl_exec($ch);
				curl_getinfo($ch);
				
				//close connection
				sleep(15);
				curl_close($ch);
				
				//Joelson Santos
				$rand = rand();
				$url = 'http://10.3.99.3/default/en_US/sms_info.html';
				$line = '4'; // sim card to use in my case #1
				$telnum = '5591982271265'; // phone number to send sms
				$smscontent = "A temperatura do CPD esta em {$temperatura} C"; //your message
				$username = "admin"; //goip username
				$password = "m0n4c0"; //goip password
				$fields_string = "";
				
				$fields = array(
						'line' => urlencode($line),
						'smskey' => urlencode($rand),
						'action' => urlencode('sms'),
						'telnum' => urlencode($telnum),
						'smscontent' => urlencode($smscontent),
						'send' => urlencode('send')
				);
				
				//url-ify the data for the POST
				foreach($fields as $key=>$value)
				{ $fields_string .= $key.'='.$value.'&'; }
				rtrim($fields_string, '&');
				
				//open connection
				$ch = curl_init();
				
				//set the url, number of POST vars, POST data
				curl_setopt($ch,CURLOPT_URL, $url);
				
				curl_setopt($ch, CURLOPT_URL, $url);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
				curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
				curl_setopt($ch, CURLOPT_PORT, 80);
				curl_setopt($ch,CURLOPT_POST, (is_array($fields) ? count($fields) : 0));
				curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);
				
				//execute post
				curl_exec($ch);
				curl_getinfo($ch);
				
				//close connection
				sleep(15);
				curl_close($ch);
				
				//Enildo Andrade
				$rand = rand();
				$url = 'http://10.3.99.3/default/en_US/sms_info.html';
				$line = '1'; // sim card to use in my case #1
				$telnum = '5591982350146'; // phone number to send sms
				$smscontent = "A temperatura do CPD esta em {$temperatura} C"; //your message
				$username = "admin"; //goip username
				$password = "m0n4c0"; //goip password
				$fields_string = "";
				
				$fields = array(
						'line' => urlencode($line),
						'smskey' => urlencode($rand),
						'action' => urlencode('sms'),
						'telnum' => urlencode($telnum),
						'smscontent' => urlencode($smscontent),
						'send' => urlencode('send')
				);
				
				//url-ify the data for the POST
				foreach($fields as $key=>$value)
				{ $fields_string .= $key.'='.$value.'&'; }
				rtrim($fields_string, '&');
				
				//open connection
				$ch = curl_init();
				
				//set the url, number of POST vars, POST data
				curl_setopt($ch,CURLOPT_URL, $url);
				
				curl_setopt($ch, CURLOPT_URL, $url);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($ch, CURLOPT_USERPWD, "$username:$password");
				curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
				curl_setopt($ch, CURLOPT_PORT, 80);
				curl_setopt($ch,CURLOPT_POST, (is_array($fields) ? count($fields) : 0));
				curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);
				
				//execute post
				curl_exec($ch);
				curl_getinfo($ch);
				
				//close connection
				sleep(15);
				curl_close($ch);
			}
		}
	}
	
	public function rotina67(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 67 && $validacao == md5($rotina.date("dmY"))) {
			$i = 0;
			$sql = array();
			$data =  date('d/m/Y');
			$apiAgendarotina = new apiAgendarotina();
			$reembolsoCon = $apiAgendarotina->getSincronizafinan("R", 6);
			$adiantamentoCon = $apiAgendarotina->getSincronizafinan("A", 6);
			$reembolsoCan = $apiAgendarotina->getSincronizafinan("R", 7);
			$adiantamentoCan = $apiAgendarotina->getSincronizafinan("A", 7);
			if ((is_array($reembolsoCon) ? count($reembolsoCon) : 0) > 0 || (is_array($adiantamentoCon) ? count($adiantamentoCon) : 0) > 0 || (is_array($reembolsoCan) ? count($reembolsoCan) : 0) > 0 || (is_array($adiantamentoCan) ? count($adiantamentoCan) : 0) > 0){
				$adiantamento = new Adiantamento();
				$apiAdiantamento = new apiAdiantamento();
				if ((is_array($reembolsoCon) ? count($reembolsoCon) : 0) > 0){
					foreach ($reembolsoCon as $r){
						$adiantamento->adiantamento = $r->ADIANTAMENTO;
						$adiantamento->situacao = 6;
						$adiantamento->situacao_anterior = 6;
						$sql[$i] = $apiAdiantamento->editAdiantamento($adiantamento);
						$i = $i + 1;
					}
				}
				
				if ((is_array($adiantamentoCon) ? count($adiantamentoCon) : 0) > 0){
					foreach ($adiantamentoCon as $r){
						$adiantamento->adiantamento = $r->ADIANTAMENTO;
						$adiantamento->situacao_anterior = 6;
						$sql[$i] = $apiAdiantamento->editAdiantamento($adiantamento);
						$i = $i + 1;
					}
				}
				
				if ((is_array($reembolsoCan) ? count($reembolsoCan) : 0) > 0){
					foreach ($reembolsoCan as $r){
						$adiantamento->adiantamento = $r->ADIANTAMENTO;
						$adiantamento->situacao = 1;
						$adiantamento->situacao_anterior = 1;
						$adiantamento->em = '';
						$adiantamento->cliente_apollo = '';
						$adiantamento->titulo_apollo = '';
						$adiantamento->duplicata_apollo = '';
						$sql[$i] = $apiAdiantamento->editAdiantamento($adiantamento);
						$i = $i + 1;
						$autorizacao = new Autorizacao();
						$autorizacao->adiantamento = $r->ADIANTAMENTO;
						$autorizacao->situacao = 1;
						$autorizacao->destinatario = '';
						$autorizacao->autorizante = '';
						$autorizacao->motivo = '';
						$autorizacao->dta_acao = '';
						$autorizacao->autorizado = '';
						$sql[$i] = $apiAdiantamento->editAutorizacao($autorizacao);
						$i = $i + 1;
					}
				}
				
				if ((is_array($adiantamentoCan) ? count($adiantamentoCan) : 0) > 0){
					foreach ($adiantamentoCan as $r){
						$adiantamento->adiantamento = $r->ADIANTAMENTO;
						$adiantamento->situacao = 1;
						$adiantamento->situacao_anterior = 1;
						$adiantamento->em = '';
						$adiantamento->cliente_apollo = '';
						$adiantamento->titulo_apollo = '';
						$adiantamento->duplicata_apollo = '';
						$sql[$i] = $apiAdiantamento->editAdiantamento($adiantamento);
						$i = $i + 1;
						$autorizacao = new Autorizacao();
						$autorizacao->adiantamento = $r->ADIANTAMENTO;
						$autorizacao->situacao = 1;
						$autorizacao->destinatario = '';
						$autorizacao->autorizante = '';
						$autorizacao->motivo = '';
						$autorizacao->dta_acao = '';
						$autorizacao->autorizado = '';
						$sql[$i] = $apiAdiantamento->editAutorizacao($autorizacao);
						$i = $i + 1;
					}
				}
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = $data;
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				
				if ($rs[4] == "sucesso"){
					if ((is_array($reembolsoCan) ? count($reembolsoCan) : 0) > 0){
						$conn_id = ftp_connect("10.3.101.38","21");
						$login_result = ftp_login($conn_id, "monaco", "m0n4c0");
						foreach ($reembolsoCan as $r){
							if (isset($r->ANEXOS)){
								$caminho = "/".str_replace("\Adiantamentos","",substr(substr(str_replace("\\10.3.101.38\Arq_Apollo\Arq\\", "", $r->DIR_PASTA_ADIANTAMENTO),0,-1),1))."/Adiantamentos/{$r->EMPRESA}-{$r->REVENDA}-{$r->TITULO}-{$r->DUPLICATA}-{$r->CLIENTE}-AD/";
								$strVal = explode(';;', $r->ANEXOS);
								foreach ($strVal as $va){
									@list($k, $v) = explode('||', $va);
									$anexos[$k] = $v;
								}
								foreach ($anexos as $e){
									ftp_delete($conn_id, $caminho.$e);
								}
								unset($anexos);
							}
						}
						ftp_close($conn_id);
					}
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = $data;
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}
		}
	}
			
	//***********************************************Rotinas Di�rias************************************************
	public function rotina39(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 39 && $validacao == md5($rotina.date("dmY"))) {
			$apiDocumento = new apiDocumento();
			$documentos = $apiDocumento->filtroDocumento('3', '1', '', '', '');
			$hoje = strtotime(date("Y-m-d"));
			if ((is_array($documentos) ? count($documentos) : 0) > 0) {
				$sql = array();
				$i = 0;
				$documento = new Documento();
				$apiUsuarioavisoorgao = new apiUsuarioavisoorgao();
				$apiEmail = new apiEmail();
				$email = new Email();
				$email->dta_envio = date('d/m/Y');
				$email->hora_envio = "07:50:00";
				$email->situacao = 'P';
				
				foreach ($documentos as $rs) {
					$email->rotina = "{$rs->DOCUMENTO}";
					$documento->documento = $rs->DOCUMENTO;
					$email->remetente = "SisMonaco - GED: {$rs->DES_EMPRESA} - Ref.: {$rs->N_REFERENCIA}";
					$vencimento = strtotime(implode("-",array_reverse(explode("/",$rs->DTA_VENCIMENTO))));
					$diferencia = $vencimento - $hoje;
					$dias_vencimento = (int)floor($diferencia / (60 * 60 * 24));
					
					$email->mensagem  = "<p><h3><b>{$rs->DES_DOCUMENTO} - N� de Ref.: {$rs->N_REFERENCIA}</b></h3></p>";
					$email->mensagem .= "<fieldset><legend>ORGAO EXPEDIDOR</legend>";
					$email->mensagem .= "<p>Orgao: {$rs->DES_ORGAO}<br>";
					$email->mensagem .= "Telefone: (".substr($rs->TELEFONE, 0, 2).")".substr($rs->TELEFONE, 2)."<br>";
					$email->mensagem .= "Site: {$rs->SITE}<br>";
					$email->mensagem .= "Contato: {$rs->CONTATO}<br>";
					$email->mensagem .= "Email: {$rs->EMAIL}<br>";
					$email->mensagem .= "Cidade-UF: {$rs->CIDADE}-{$rs->UF}</p>";
					$email->mensagem .= "</fieldset>";
					$email->mensagem .= "<fieldset><legend>DOCUMENTO</legend>";
					$email->mensagem .= "<p>Empresa: {$rs->DES_EMPRESA}<br>";
					$email->mensagem .= "CNPJ: {$rs->CNPJ}<br>";
					$email->mensagem .= "Descricao: {$rs->DES_DOCUMENTO}<br>";
					$email->mensagem .= "Aviso: {$rs->DES_AVISO}<br>";
					$email->mensagem .= "N de Referencia: {$rs->N_REFERENCIA}<br>";
					$email->mensagem .= "Data de emissao: {$rs->DTA_EMISSAO}<br>";
					$email->mensagem .= "<b>Data de vencimento: {$rs->DTA_VENCIMENTO}</b><br>";
					$email->mensagem .= "Obs.: {$rs->OBS}<br>";
					if($dias_vencimento >= 1) {
						$email->mensagem .= "Prazo de validade: {$dias_vencimento}<br>";
					}elseif($dias_vencimento == 0){
						$email->mensagem .= "<b>O vencimento deste documento � HOJE!</b><br>";
					}elseif($dias_vencimento < 0){
						$email->mensagem .= "Este documento esta vencido a: ".abs($dias_vencimento)." dia(s)<br>";
						$email->mensagem .= "<a href='".APP_ROOT."/dados/ged/".$rs->ANEXO."'>Visualizar documento</a>";
						$email->mensagem .= "</fieldset>";
					}
					if($rs->STATUS_AVISO1 == 0){
						$data_aviso = date('Y-m-d', strtotime("-".$rs->AVISO1." days", $vencimento));
						
						if(date('Y-m-d') >= $data_aviso){
							$email->assunto = "Aviso do GED N� 1";
							$documento->status_aviso1 = 1;
							$sql[$i] = $apiDocumento->editDocumento($documento);
							$i = $i + 1;
						}	
					}elseif($rs->STATUS_AVISO2 == 0){
						$data_aviso = date('Y-m-d', strtotime("-".$rs->AVISO2." days", $vencimento));
						if(date('Y-m-d') >= $data_aviso){
							$email->assunto = "Aviso do GED N� 2";
							$documento->status_aviso2 = 1;
							$sql[$i] = $apiDocumento->editDocumento($documento);
							$i = $i + 1;
						}	
					}elseif($rs->STATUS_AVISO3 == 0){
						$data_aviso = date('Y-m-d', strtotime("-".$rs->AVISO3." days", $vencimento));
						if(date('Y-m-d') >= $data_aviso){	
							$email->assunto = "Aviso do GED N� 3";
							$documento->status_aviso3 = 1;
							$sql[$i] = $apiDocumento->editDocumento($documento);
							$i = $i + 1;
						}
					}else{
						$enviado = $apiDocumento->getUltimosenviados($rs->DOCUMENTO);
						$n_reg = (is_array($enviado) ? count($enviado) : 0);
						$n_reg = $n_reg + 1;
						
						$ultimo_envio = strtotime(implode("-",array_reverse(explode("/",$enviado[0]->DTA_ENVIADO))));
						$prox_envio = date('Y-m-d', strtotime("+".$rs->AVISO_A_CADA." days", $ultimo_envio));
						$hoje = date("Y-m-d");
						if(strtotime($hoje) >= strtotime($prox_envio)){
							$email->assunto = "Aviso do GED N� {$n_reg}";
						}
					}
					$result = $apiUsuarioavisoorgao->getUsuariosvinculados($rs->AVISO, $rs->ORGAO);
					foreach ($result as $rs) {
						$email->destinatario = $rs->EMAIL;
						$sql[$i] = $apiEmail->addEmail($email);
						$i = $i + 1;	
					}
				}
				
				$apiAgendarotina = new apiAgendarotina();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}
		}
	}
	
	public function rotina23() {
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 23 && $validacao == md5($rotina.date("dmY"))) {
			$data = date('m/d/Y');
			$amanha = date('d/m/Y',strtotime($data."+1 days"));
			$hora = "05:00:00";
			$rotinas = array(
				'0' => array('rotina' => 22),
				//'1' => array('rotina' => 34),
				'2' => array('rotina' => 37),
				'3' => array('rotina' => 58)
			);
			$sql = array();
			$i = 0;
			$agendarotina = new Agendarotina();
			$apiAgendarotina = new apiAgendarotina();
			foreach ($rotinas as $ro) {
				$agendarotina->rotina = $ro['rotina'];
				$agendarotina->dta_ult_execucao = $amanha;
				$agendarotina->hora_ult_execucao = $hora;
				$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
				$i = $i + 1;
			}
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao = date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
		    }
		}	
	}
	
	public function rotina57(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 57 && $validacao == md5($rotina.date("dmY"))) {
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getDescontomotos();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('K1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('L1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('M1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('N1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('O1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('P1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Q1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('R1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('S1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('T1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('U1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('V1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('W1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('X1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Y1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Z1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AA1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AB1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AC1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AD1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AE1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue("A1", "EMPRESA" )
			->setCellValue("B1", "REVENDA" )
			->setCellValue("C1", "PROPOSTA" )
			->setCellValue("D1", "DDD_TELEFONE" )
			->setCellValue("E1", "TELEFONE" )
			->setCellValue("F1", "DDD_CELULAR" )
			->setCellValue("G1", "CELULAR" )
			->setCellValue("H1", "E_MAIL_TRABALHO" )
			->setCellValue("I1", "E_MAIL_CASA" )
			->setCellValue("J1", "NUMERO_NOTA_FISCAL" )
			->setCellValue("K1", "SERIE_NOTA_FISCAL" )
			->setCellValue("L1", "TIPO_TRANSACAO" )
			->setCellValue("M1", "DTA_ENTRADA_SAIDA" )
			->setCellValue("N1", "TOT_NOTA_FISCAL" )
			->setCellValue("O1", "VENDA_REAL" )
			->setCellValue("P1", "VALOR_FRETE" )
			->setCellValue("Q1", "TOT_CUSTO_MEDIO" )
			->setCellValue("R1", "OPERACAO_DESCONTO" )
			->setCellValue("S1", "VAL_MARGEM" )
			->setCellValue("T1", "PTC_MARGEM" )
			->setCellValue("U1", "VEICULO" )
			->setCellValue("V1", "CHASSI" )
			->setCellValue("W1", "DES_MODELO" )
			->setCellValue("X1", "VENDEDOR" )
			->setCellValue("Y1", "NOME_VENDEDOR" )
			->setCellValue("Z1", "MUNICIPIO_ENTREGA" )
			->setCellValue("AA1", "ANO_FABRICACAO" )
			->setCellValue("AB1", "ANO_MODELO" )
			->setCellValue("AC1", "TIPO_DE_VEICULO" )
			->setCellValue("AD1", "TIPO_CILINDRADA" )
			->setCellValue("AE1", "TIPO_VENDA" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(35);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(35);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('Q')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('R')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('S')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('T')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('T')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('U')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('U')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('V')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('V')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('W')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('X')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('Y')->setWidth(35);
			$objPHPExcel->getActiveSheet()->getColumnDimension('Z')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('AA')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('AB')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('AC')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('AD')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('AE')->setWidth(15);
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->PROPOSTA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->DDD_TELEFONE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->TELEFONE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->DDD_CELULAR);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $rs->CELULAR);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $rs->E_MAIL_TRABALHO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, $rs->E_MAIL_CASA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, $rs->NUMERO_NOTA_FISCAL);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, $rs->SERIE_NOTA_FISCAL);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $i, $rs->TIPO_TRANSACAO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $i, $rs->DTA_ENTRADA_SAIDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $i, str_replace(",", ".", $rs->TOT_NOTA_FISCAL),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $i, str_replace(",", ".", $rs->VENDA_REAL),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(15, $i, str_replace(",", ".", $rs->VALOR_FRETE),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(16, $i, str_replace(",", ".", $rs->TOT_CUSTO_MEDIO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(17, $i, str_replace(",", ".", $rs->OPERACAO_DESCONTO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(18, $i, str_replace(",", ".", $rs->VAL_MARGEM),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(19, $i, str_replace(",", ".", $rs->PCT_MARGEM),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(20, $i, $rs->VEICULO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(21, $i, $rs->CHASSI);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(22, $i, utf8_encode($rs->DES_MODELO));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(23, $i, $rs->VENDEDOR);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(24, $i, utf8_encode($rs->NOME_VENDEDOR));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(25, $i, utf8_encode($rs->MUNICIPIO_ENTREGA));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(26, $i, $rs->ANO_FABRICACAO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(27, $i, $rs->ANO_MODELO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(28, $i, utf8_encode($rs->TIPO_DE_VEICULO));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(29, $i, utf8_encode($rs->TIPO_CILINDRADA));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(30, $i, utf8_encode($rs->TIPO_VENDA));
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Motos com operacao de desconto');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "Venda-Moto-Desconto-".date("d-m-Y");
			$objWriter->save($_SERVER["DOCUMENT_ROOT"] ."/". RAIZ_PATH."dados/anexo/{$nome_arquivo}.xlsx");
			
			$sql = array();
			$i = 0;
			$email = new Email();
			$email->dta_envio = date('d/m/Y');
			$email->hora_envio = "07:50:00";
			$email->rotina = $rotina;
			$email->remetente = "SisMonaco - Motos Desconto ".date('d/m/Y');
			$email->assunto = "Motos com Opera��o de Descontos ".date('d/m/Y');
			$email->mensagem = "Segue em anexo o relat�rio do inicio do m�s at� ontem de motos com opera��o de desconto" ;
			$email->anexo = "dados/anexo/{$nome_arquivo}.xlsx";
			$email->situacao = 'P';
			$apiEmail = new apiEmail();
			$apiRotinausuario = new apiRotinausuario();
			$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
			foreach ($result as $rs) {
				$email->destinatario = $rs->EMAIL;
				$sql[$i] = $apiEmail->addEmail($email);
				$i = $i + 1;
			}
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao = date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina69(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 69 && $validacao == md5($rotina.date("dmY"))) {
			$apiAgendarotina = new apiAgendarotina();
			$apiRotinausuario = new apiRotinausuario();
			$result = $apiAgendarotina->getVisitaFiat();
			$data = date("d/m/Y");
			$i = 0;
			$sql = array();
			
			if (is_array($result) > 0){
				
				$mensagem  = "<html>
							  	<head></head>
								<body>
									<style type='text/css'>
										.fieldset {
										  border: 1px solid #ddd;
										  margin-top: 1em;
										  width: 500px;
										}
										.fieldset h3 {
										  font-size: 12px;
										  text-align: center;
										}
										.fieldset h3 span {
										  display: inline;
										  border: 1px solid #ddd;
										  background: #fff;
										  padding: 5px 10px;
										  position: relative;
										  top: -1.3em;
										}
									</style>
									<p><h3><b>Movimenta��es de Lead da Fiat</b></h3></p>";
				
				$mensagem .= "<div class='fieldset'><h3><span>Movimenta��es</span></h3><p>";
				foreach ($result as $rs) {
					$mensagem .= "Origem: {$rs->ORIGEM}, Tipo: {$rs->TIPO}, Qtd: {$rs->QTD}<br>";
				}
				$mensagem .= "</p></div>";
				$para = array();
				$data = date('d/m/Y');
				$de  = "SisMonaco - Leads Site Fiat {$data}";
				$env = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
				foreach ($env as $rs) {
					$para[$i] = "{$rs->EMAIL}";
					$i = $i + 1;
				}
				$assunto   = "Leads Recebidos atrav�s do site da Fiat {$data}";
				$Envio = new EnvioEmail();
				$mensagem .= "</body></html>";
				$Envio->Envio($de, $assunto, $mensagem, $para, "", "");
			}
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao =  date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$apiAgendarotina = new apiAgendarotina();
			$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina73(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 73 && $validacao == md5($rotina.date("dmY"))) {
			$funcoes = new Funcoes();
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getCremaberto();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('L1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('M1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('N1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('O1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('P1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Q1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('R1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'EMPRESA' )
			->setCellValue('B1', "REVENDA" )
			->setCellValue("C1", "CLIENTE" )
			->setCellValue("D1", "NOME" )
			->setCellValue("E1", "ORIGEM" )
			->setCellValue("F1", "DES_ORIGEM" )
			->setCellValue("G1", "TIPO" )
			->setCellValue("H1", "TITULO" )
			->setCellValue("I1", "DUPLICATA" )
			->setCellValue("J1", "STATUS" )
			->setCellValue("K1", "DTA_EMISSAO" )
			->setCellValue("L1", "DTA_CONTABIL" )
			->setCellValue("M1", "DTA_VENCIMENTO" )
			->setCellValue("N1", "PAGAR_RECEBER" )
			->setCellValue("O1", "DEPARTAMENTO" )
			->setCellValue("P1", "VAL_TITULO" )
			->setCellValue("Q1", "VALOR_PAGO" )
			->setCellValue("R1", "SALDO" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(40);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(13);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(12);
			$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(12);
			$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(12);
			$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(13);
			$objPHPExcel->getActiveSheet()->getStyle('P')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(13);
			$objPHPExcel->getActiveSheet()->getStyle('Q')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(13);
			$objPHPExcel->getActiveSheet()->getStyle('R')->getNumberFormat()->setFormatCode('#,##0.00');
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->CLIENTE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, utf8_encode($rs->NOME));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->ORIGEM);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, utf8_encode($rs->DES_ORIGEM));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $rs->TIPO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $rs->TITULO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, $rs->DUPLICATA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, $rs->STATUS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, $rs->DTA_EMISSAO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $i, $rs->DTA_CONTABIL);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $i, $rs->DTA_VENCIMENTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $i, $rs->PAGAR_RECEBER);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $i, $rs->DEPARTAMENTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(15, $i, number_format(str_replace(",", ".", $rs->VAL_TITULO), 2, ",", "."),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(16, $i, number_format(str_replace(",", ".", $rs->VALOR_PAGO), 2, ",", "."),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(17, $i, number_format(str_replace(",", ".", $rs->SALDO), 2, ",", "."),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('CR em Aberto');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "CR-EM-ABERTO-".date("d-m-Y");
			$objWriter->save($nome_arquivo.".xlsx");
			
			$ssh = new ServidorArquivo();
			
			if ($ssh->MandaArquivo('relatorio', $nome_arquivo.".xlsx") == 'sucesso'){
				$sql = array();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina74(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 74 && $validacao == md5($rotina.date("dmY"))) {
			$funcoes = new Funcoes();
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getCpemaberto();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('L1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('M1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('N1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('O1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('P1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Q1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('R1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'EMPRESA' )
			->setCellValue('B1', "REVENDA" )
			->setCellValue("C1", "CLIENTE" )
			->setCellValue("D1", "NOME" )
			->setCellValue("E1", "ORIGEM" )
			->setCellValue("F1", "DES_ORIGEM" )
			->setCellValue("G1", "TIPO" )
			->setCellValue("H1", "TITULO" )
			->setCellValue("I1", "DUPLICATA" )
			->setCellValue("J1", "STATUS" )
			->setCellValue("K1", "DTA_EMISSAO" )
			->setCellValue("L1", "DTA_CONTABIL" )
			->setCellValue("M1", "DTA_VENCIMENTO" )
			->setCellValue("N1", "PAGAR_RECEBER" )
			->setCellValue("O1", "DEPARTAMENTO" )
			->setCellValue("P1", "VAL_TITULO" )
			->setCellValue("Q1", "VALOR_PAGO" )
			->setCellValue("R1", "SALDO" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(40);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(13);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(12);
			$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(12);
			$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(12);
			$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(13);
			$objPHPExcel->getActiveSheet()->getStyle('P')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(13);
			$objPHPExcel->getActiveSheet()->getStyle('Q')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(13);
			$objPHPExcel->getActiveSheet()->getStyle('R')->getNumberFormat()->setFormatCode('#,##0.00');
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->CLIENTE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, utf8_encode($rs->NOME));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->ORIGEM);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, utf8_encode($rs->DES_ORIGEM));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $rs->TIPO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $rs->TITULO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, $rs->DUPLICATA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, $rs->STATUS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, $rs->DTA_EMISSAO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $i, $rs->DTA_CONTABIL);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $i, $rs->DTA_VENCIMENTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $i, $rs->PAGAR_RECEBER);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $i, $rs->DEPARTAMENTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(15, $i, number_format(str_replace(",", ".", $rs->VAL_TITULO), 2, ",", "."),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(16, $i, number_format(str_replace(",", ".", $rs->VALOR_PAGO), 2, ",", "."),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(17, $i, number_format(str_replace(",", ".", $rs->SALDO), 2, ",", "."),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('CP em Aberto');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "CP-EM-ABERTO-".date("d-m-Y");
			$objWriter->save($nome_arquivo.".xlsx");
			
			$ssh = new ServidorArquivo();
			
			if ($ssh->MandaArquivo('relatorio', $nome_arquivo.".xlsx") == 'sucesso'){
				$sql = array();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina77(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 77 && $validacao == md5($rotina.date("dmY"))) {
			
			$apiAgendarotina = new apiAgendarotina();
			$result1 = $apiAgendarotina->resumodescontoMotos1();
			$result2 = $apiAgendarotina->resumodescontoMotos2();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('K1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('L1')->getFont()->setBold(true);

			
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'EMPRESA' )
			->setCellValue('B1', 'DTA_VENDA' )
			->setCellValue('C1', "VALOR_VENDA" )
			->setCellValue("D1", "VENDA_NOVOS" )
			->setCellValue("E1", "VENDA_USADOS" )
			->setCellValue("F1", "ALTA_CILINDRADA" )
			->setCellValue("G1", "BAIXA_MEDIA_CILINDRADA" )
			->setCellValue("H1", "VENDA_NORMAL" )
			->setCellValue("I1", "VENDA_CONSORCIO" )
			->setCellValue("J1", "VAL_CUSTO_MEDIO" )
			->setCellValue("K1", "VAL_MARGEM" )
			->setCellValue("L1", "PCT_MARGEM" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(18);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(18);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(27);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(17);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(25);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(18);
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(25);
			
			$i = 1;
			foreach ($result1 as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->DTA_VENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->VALOR_VENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->VENDA_NOVOS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->VENDA_USADOS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->ALTA_CILINDRADA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $rs->BAIXA_MEDIA_CILINDRADA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $rs->VENDA_NORMAL);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, $rs->VENDA_CONSORCIO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, $rs->VAL_CUSTO_MEDIO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, $rs->VAL_MARGEM);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $i, $rs->PCT_MARGEM);
			}
			
			$t = $i+4;
			$objPHPExcel->getActiveSheet()->getStyle("A{$t}")->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle("B{$t}")->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle("C{$t}")->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle("D{$t}")->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle("E{$t}")->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle("F{$t}")->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle("G{$t}")->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle("H{$t}")->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle("I{$t}")->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue("A{$t}", "EMPRESA" )
			->setCellValue("B{$t}", "TIPO" )
			->setCellValue("C{$t}", "VALOR_ACUMULADO" )
			->setCellValue("D{$t}", "VENDA_NOVOS" )
			->setCellValue("E{$t}", "VENDA_USADOS" )
			->setCellValue("F{$t}", "ALTA_CILINDRADA" )
			->setCellValue("G{$t}", "BAIXA_MEDIA_CILINDRADA" )
			->setCellValue("H{$t}", "VENDA_NORMAL" )
			->setCellValue("I{$t}", "VENDA_CONSORCIO" );
			
			foreach ($result2 as $rs2){
				$t = $t + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $t, $rs2->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $t, $rs2->TIPO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $t, $rs2->VALOR_ACUMULADO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $t, $rs2->VENDA_NOVOS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $t, $rs2->VENDA_USADOS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $t, $rs2->ALTA_CILINDRADA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $t, $rs2->BAIXA_MEDIA_CILINDRADA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $t, $rs2->VENDA_NORMAL);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $t, $rs2->VENDA_CONSORCIO);
			}
			
			
			$objPHPExcel->getActiveSheet()->setTitle('Resumo Desconto Motos');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "Resumo-DescMotos-".date("d-m-Y");
			
			$objWriter->save($_SERVER["DOCUMENT_ROOT"] ."/". RAIZ_PATH."dados/anexo/{$nome_arquivo}.xlsx");
			
			
			$sql = array();
			$i = 0;
			$email = new Email();
			$email->dta_envio = date('d/m/Y');
			$email->hora_envio = "07:50:00";
			$email->rotina = $rotina;
			$email->remetente = "SisMonaco - Resumo Motos Desconto ".date('d/m/Y');
			$email->assunto = " Resumo Motos com Opera��o de Descontos ".date('d/m/Y');
			$email->mensagem = "Segue em anexo o relat�rio Resumo de Motos com Descontos" ;
			$email->anexo = "dados/anexo/{$nome_arquivo}.xlsx";
			$email->situacao = 'P';
			$apiEmail = new apiEmail();
			$apiRotinausuario = new apiRotinausuario();
			$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
			foreach ($result as $rs) {
				$email->destinatario = $rs->EMAIL;
				$sql[$i] = $apiEmail->addEmail($email);
				$i = $i + 1;
			}
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao = date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
		
	}
	
	public function rotina79(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		
		if ($rotina == 79 && $validacao == md5($rotina.date("dmY"))) {
		
		$apiAgendarotina= new apiAgendarotina();
		$result = $apiAgendarotina->estoqueveiculos();
		
		$objPHPExcel = new \PHPExcel();
		
		$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('K1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('L1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('M1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('N1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('O1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('P1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('Q1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('R1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('S1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('T1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('U1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('V1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('W1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('X1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('Y1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('Z1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('AA1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('AB1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('AC1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('AD1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('AE1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('AF1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('AG1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('AH1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('AI1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('AJ1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('AK1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('AL1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('AM1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('AN1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('AO1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('AP1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('AQ1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('AR1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('AS1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('AT1')->getFont()->setBold(true);
		
		$objPHPExcel->setActiveSheetIndex(0)
		->setCellValue("A1", "EMPRESA" )
		->setCellValue("B1", "REVENDA" )
		->setCellValue("C1", "DES_EMPRESA" )
		->setCellValue("D1", "DES_NEGOCIO" )
		->setCellValue("E1", "ID_NUCLEO" )
		->setCellValue("F1", "VEICULO" )
		->setCellValue("G1", "QUILOMETRAGEM" )
		->setCellValue("H1", "DES_LOCALIZACAO" )
		->setCellValue("I1", "CHASSI" )
		->setCellValue("J1", "MODELO" )
		->setCellValue("K1", "DES_MODELO" )
		->setCellValue("L1", "DES_FAMILIA" )
		->setCellValue("M1", "COMBUSTIVEL" )
		->setCellValue("N1", "SITUACAO" )
		->setCellValue("O1", "NOVO_USADO" )
		->setCellValue("P1", "DEPARTAMENTO" )
		->setCellValue("Q1", "PLACA" )
		->setCellValue("R1", "ACABAMENTO" )
		->setCellValue("S1", "ANO_FABRICACAO" )
		->setCellValue("T1", "ANO_MODELO" )
		->setCellValue("U1", "CONTABIL" )
		->setCellValue("V1", "TRANSITO" )
		->setCellValue("W1", "RESERVADO" )
		->setCellValue("X1", "NEGOCIADO" )
		->setCellValue("Y1", "TEM_PROPOSTA" )
		->setCellValue("Z1", "DISPONIVEL" )
		->setCellValue("AA1", "VENDIDO" )
		->setCellValue("AB1", "PROPOSTA" )
		->setCellValue("AC1", "DES_COR" )
		->setCellValue("AD1", "OPCIONAIS" )
		->setCellValue("AE1", "VAL_CUSTO_CONTABIL" )
		->setCellValue("AF1", "VAL_COMPRA" )
		->setCellValue("AG1", "CUSTO" )
		->setCellValue("AH1", "CUSTO_PRES" )
		->setCellValue("AI1", "TOT_NOTAL_FISCAL" )
		->setCellValue("AJ1", "TIPO_TRANSACAO" )
		->setCellValue("AK1", "TIPO_COMERCIALIZACAO" )
		->setCellValue("AL1", "DES_CATEGORIA_VEICULO" )
		->setCellValue("AM1", "NUMERO_NOTA_NFENTRADA" )
		->setCellValue("AN1", "DTA_ENTRADA" )
		->setCellValue("AO1", "DIAS" )
		->setCellValue("AP1", "SIT_VEIC" )
		->setCellValue("AQ1", "EMPRESA_NFENTRADA" )
		->setCellValue("AR1", "REVENDA_NFENTRADA" )
		->setCellValue("AS1", "ANO_PROCESSAMENTO" )
		->setCellValue("AT1", "MES_PROCESSAMENTO" );
		
		$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(40);
		$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('T')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('U')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('V')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('W')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('X')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('Y')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('Z')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('AA')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('AB')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('AC')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('AD')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('AE')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('AF')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('AG')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('AH')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('AI')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('AJ')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('AK')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('AL')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('AM')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('AM')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('AN')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('AO')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('AP')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('AQ')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('AR')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('AS')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('AT')->setWidth(30);
		
		
		$i = 1;
		foreach ($result as $rs){
			$i = $i + 1;
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, utf8_encode($rs->DES_EMPRESA));
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, utf8_encode($rs->DES_NEGOCIO));
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->ID_NUCLEO);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->VEICULO);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $rs->QUILOMETRAGEM);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, utf8_encode($rs->DES_LOCALIZACAO));
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, $rs->CHASSI);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, utf8_encode($rs->MODELO));
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, utf8_encode($rs->DES_MODELO));
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $i, utf8_encode($rs->DES_FAMILIA));
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $i, $rs->COMBUSTIVEL);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $i, $rs->SITUACAO);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $i, $rs->NOVO_USADO);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(15, $i, $rs->DEPARTAMENTO);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(16, $i, $rs->PLACA);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(17, $i, $rs->ACABAMENTO);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(18, $i, $rs->ANO_FABRICACAO);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(19, $i, $rs->ANO_MODELO);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(20, $i, $rs->CONTABIL);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(21, $i, $rs->TRANSITO);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(22, $i, $rs->RESERVADO);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(23, $i, $rs->NEGOCIADO);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(24, $i, $rs->TEM_PROPOSTA);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(25, $i, $rs->DISPONIVEL);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(26, $i, $rs->VENDIDO);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(27, $i, $rs->PROPOSTA);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(28, $i, utf8_encode($rs->DES_COR));
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(29, $i, utf8_encode($rs->OPCIONAIS));
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(30, $i, number_format(str_replace(",", ".", $rs->VAL_CUSTO_CONTABIL), 2, ",", "."),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(31, $i, number_format(str_replace(",", ".", $rs->VAL_COMPRA), 2, ",", "."),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(32, $i, number_format(str_replace(",", ".", $rs->CUSTO), 2, ",", "."),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(33, $i, number_format(str_replace(",", ".", $rs->CUSTO_PRES), 2, ",", "."),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(34, $i, number_format(str_replace(",", ".", $rs->TOT_NOTA_FISCAL), 2, ",", "."),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(35, $i, $rs->TIPO_TRANSACAO);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(36, $i, utf8_encode($rs->TIPO_COMERCIALIZACAO));
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(37, $i, utf8_encode($rs->DES_CATEGORIA_VEICULO));
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(38, $i, $rs->NUMERO_NOTA_NFENTRADA);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(39, $i, $rs->DTA_ENTRADA);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(40, $i, $rs->DIAS);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(41, $i, $rs->SIT_VEIC);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(42, $i, $rs->EMPRESA_NFENTRADA);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(43, $i, $rs->REVENDA_NFENTRADA);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(44, $i, $rs->ANO_PROCESSAMENTO);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(45, $i, $rs->MES_PROCESSAMENTO);
			
		}
		
		$objPHPExcel->getActiveSheet()->setTitle('Estoque Veiculos');
		
		$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		
		$nome_arquivo = "Estoque-Veiculos-".date("d-m-Y");
		$objWriter->save($nome_arquivo.".xlsx");
		
		
		$ssh = new ServidorArquivo();
		if ($ssh->MandaArquivo('relatorio', $nome_arquivo.".xlsx") == 'sucesso'){
			$sql = array();
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao = date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}else{
			$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
			header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
			die();
		}
	}
	}
	
	//***********************************************Rotinas Semanais************************************************
	public function rotina6(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 6 && $validacao == md5($rotina.date("dmY"))) {
			
			$apiAgendarotina= new apiAgendarotina();
			$result = $apiAgendarotina->getDespesasanalitico();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('K1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue("A1", "EMPRESA" )
			->setCellValue("B1", "REVENDA_DIVISAO" )
			->setCellValue("C1", "ANO_MES" )
			->setCellValue("D1", "DIA" )
			->setCellValue("E1", "CONTA" )
			->setCellValue("F1", "DES_CONTA" )
			->setCellValue("G1", "CENTRO_CUSTO" )
			->setCellValue("H1", "TIPO" )
			->setCellValue("I1", "NATUREZA_D_VALOR" )
			->setCellValue("J1", "NATUREZA_C_VALOR" )
			->setCellValue("K1", "SALDO" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getStyle('I')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getStyle('J')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getStyle('K')->getNumberFormat()->setFormatCode('#,##0.00');
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA_DIVISAO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->ANO_MES);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->DIA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->CONTA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->DES_CONTA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $rs->CENTRO_CUSTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $rs->TIPO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, str_replace(",", ".", $rs->NATUREZA_D_VALOR),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, str_replace(",", ".", $rs->NATUREZA_C_VALOR),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, str_replace(",", ".", $rs->SALDO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Despesas Analitico');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "Despesas-Analitico-".date("d-m-Y");
			$objWriter->save($nome_arquivo.".xlsx");
			
			$ssh = new ServidorArquivo();
			
			if ($ssh->MandaArquivo('relatorio', $nome_arquivo.".xlsx") == 'sucesso'){
				$sql = array();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	public function rotina7(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 7 && $validacao == md5($rotina.date("dmY"))) {
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getDespesassintetico();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue("A1", "EMPRESA" )
			->setCellValue("B1", "REVENDA_DIVISAO" )
			->setCellValue("C1", "ANO_MES" )
			->setCellValue("D1", "DIA" )
			->setCellValue("E1", "CENTRO_CUSTO" )
			->setCellValue("F1", "TIPO_ITEM" )
			->setCellValue("G1", "SALDO" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getStyle('G')->getNumberFormat()->setFormatCode('#,##0.00');
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA_DIVISAO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->ANO_MES);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->DIA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->CENTRO_CUSTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->TIPO_ITEM);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, str_replace(",", ".", $rs->SALDO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Despesas Sintetico');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "Despesas-Sintetico-".date("d-m-Y");
			$objWriter->save($nome_arquivo.".xlsx");
			
			$ssh = new ServidorArquivo();
			
			if ($ssh->MandaArquivo('relatorio', $nome_arquivo.".xlsx") == 'sucesso'){
				$sql = array();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
			
		}
	}
	
	public function rotina8(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 8 && $validacao == md5($rotina.date("dmY"))) {
			$funcoes = new Funcoes();
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getEstoquegeralhd();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('K1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('L1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('M1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('N1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('O1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('P1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Q1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('R1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('S1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('T1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('U1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('V1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('W1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('X1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Y1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Z1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AA1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AB1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AC1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'EMPRESA' )
			->setCellValue('B1', "REVENDA" )
			->setCellValue("C1", "ITEM_ESTOQUE" )
			->setCellValue("D1", "ITEM_ESTOQUE_PUB" )
			->setCellValue("E1", "DES_ITEM_ESTOQUE" )
			->setCellValue("F1", "CLASS_ABC" )
			->setCellValue("G1", "CLASS_XYZ" )
			->setCellValue("H1", "QTD_CONTABIL" )
			->setCellValue("I1", "DTA_SAIDA" )
			->setCellValue("J1", "DTA_ULT_ENTRADA" )
			->setCellValue("K1", "QTD_ULT_ENTRADA" )
			->setCellValue("L1", "BASE_PIS" )
			->setCellValue("M1", "BASE_COFINS" )
			->setCellValue("N1", "NCM" )
			->setCellValue("O1", "CUSTO_MEDIO" )
			->setCellValue("P1", "VAL_ESTOQUE" )
			->setCellValue("Q1", "NOME_GRUPO" )
			->setCellValue("R1", "GRUPO" )
			->setCellValue("S1", "NOME_CATEGORIA" )
			->setCellValue("T1", "CATEGORIA" )
			->setCellValue("U1", "PCT_DESCONTO" )
			->setCellValue("V1", "GRUPO_DESCONTO" )
			->setCellValue("W1", "ALIQUOTA_IPI" )
			->setCellValue("X1", "PRECO_ALTERNATIVO" )
			->setCellValue("Y1", "DEMANDA_MEDIA" )
			->setCellValue("Z1", "INCIDE_PIS_COFINS" )
			->setCellValue("AA1", "PRECO_PUBLICO_ATUAL" )
			->setCellValue("AB1", "CUSTO_REPOS" )
			->setCellValue("AC1", "DIAS" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(35);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(13);
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(13);
			$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(13);
			$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(13);
			$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('O')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('P')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('T')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('U')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('V')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('W')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('X')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('X')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('Y')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('Z')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('AA')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('AA')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('AB')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('AB')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('AC')->setWidth(10);
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->ITEM_ESTOQUE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->ITEM_ESTOQUE_PUB);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $funcoes->retiraAcentos($rs->DES_ITEM_ESTOQUE));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->CLASS_ABC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $rs->CLASS_XYZ);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $rs->QTD_CONTABIL);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, $rs->DTA_SAIDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, $rs->DTA_ULT_ENTRADA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, $rs->QTD_ULT_ENTRADA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $i, $rs->BASE_PIS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $i, $rs->BASE_COFINS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $i, $rs->NCM);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $i, str_replace(",", ".", $rs->CUSTO_MEDIO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(15, $i, str_replace(",", ".", $rs->VAL_ESTOQUE),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(16, $i, $rs->NOME_GRUPO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(17, $i, $rs->GRUPO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(18, $i, $rs->NOME_CATEGORIA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(19, $i, $rs->CATEGORIA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(20, $i, $rs->PCT_DESCONTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(21, $i, $rs->GRUPO_DESCONTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(22, $i, $rs->ALIQUOTA_IPI);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(23, $i, str_replace(",", ".", $rs->PRECO_ALTERNATIVO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(24, $i, $rs->DEMANDA_MEDIA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(25, $i, $rs->INCIDE_PIS_COFINS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(26, $i, str_replace(",", ".", $rs->PRECO_PUBLICO_ATUAL),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(27, $i, str_replace(",", ".", $rs->CUSTO_REPOS),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(28, $i, $rs->DIAS);
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Estoque Geral HD');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "Estoque-Geral-HD-".date("d-m-Y");
			$objWriter->save($nome_arquivo.".xlsx");
			
			$ssh = new ServidorArquivo();
			
			if ($ssh->MandaArquivo('relatorio', $nome_arquivo.".xlsx") == 'sucesso'){
				$sql = array();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina9(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 9 && $validacao == md5($rotina.date("dmY"))) {
			$funcoes = new Funcoes();
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getEstoquegeralvw();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('K1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('L1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('M1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('N1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('O1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('P1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Q1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('R1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('S1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('T1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('U1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('V1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('W1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('X1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Y1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Z1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AA1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AB1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AC1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'EMPRESA' )
			->setCellValue('B1', "REVENDA" )
			->setCellValue("C1", "ITEM_ESTOQUE" )
			->setCellValue("D1", "ITEM_ESTOQUE_PUB" )
			->setCellValue("E1", "DES_ITEM_ESTOQUE" )
			->setCellValue("F1", "CLASS_ABC" )
			->setCellValue("G1", "CLASS_XYZ" )
			->setCellValue("H1", "QTD_CONTABIL" )
			->setCellValue("I1", "DTA_SAIDA" )
			->setCellValue("J1", "DTA_ULT_ENTRADA" )
			->setCellValue("K1", "QTD_ULT_ENTRADA" )
			->setCellValue("L1", "BASE_PIS" )
			->setCellValue("M1", "BASE_COFINS" )
			->setCellValue("N1", "NCM" )
			->setCellValue("O1", "CUSTO_MEDIO" )
			->setCellValue("P1", "VAL_ESTOQUE" )
			->setCellValue("Q1", "NOME_GRUPO" )
			->setCellValue("R1", "GRUPO" )
			->setCellValue("S1", "NOME_CATEGORIA" )
			->setCellValue("T1", "CATEGORIA" )
			->setCellValue("U1", "PCT_DESCONTO" )
			->setCellValue("V1", "GRUPO_DESCONTO" )
			->setCellValue("W1", "ALIQUOTA_IPI" )
			->setCellValue("X1", "PRECO_ALTERNATIVO" )
			->setCellValue("Y1", "DEMANDA_MEDIA" )
			->setCellValue("Z1", "INCIDE_PIS_COFINS" )
			->setCellValue("AA1", "PRECO_PUBLICO_ATUAL" )
			->setCellValue("AB1", "CUSTO_REPOS" )
			->setCellValue("AC1", "DIAS" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(35);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(13);
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(13);
			$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(13);
			$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(13);
			$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('O')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('P')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('T')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('U')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('V')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('W')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('X')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('X')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('Y')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('Z')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('AA')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('AA')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('AB')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('AB')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('AC')->setWidth(10);
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->ITEM_ESTOQUE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->ITEM_ESTOQUE_PUB);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $funcoes->retiraAcentos($rs->DES_ITEM_ESTOQUE));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->CLASS_ABC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $rs->CLASS_XYZ);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $rs->QTD_CONTABIL);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, $rs->DTA_SAIDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, $rs->DTA_ULT_ENTRADA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, $rs->QTD_ULT_ENTRADA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $i, $rs->BASE_PIS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $i, $rs->BASE_COFINS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $i, $rs->NCM);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $i, str_replace(",", ".", $rs->CUSTO_MEDIO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(15, $i, str_replace(",", ".", $rs->VAL_ESTOQUE),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(16, $i, $rs->NOME_GRUPO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(17, $i, $rs->GRUPO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(18, $i, $rs->NOME_CATEGORIA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(19, $i, $rs->CATEGORIA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(20, $i, $rs->PCT_DESCONTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(21, $i, $rs->GRUPO_DESCONTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(22, $i, $rs->ALIQUOTA_IPI);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(23, $i, str_replace(",", ".", $rs->PRECO_ALTERNATIVO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(24, $i, $rs->DEMANDA_MEDIA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(25, $i, $rs->INCIDE_PIS_COFINS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(26, $i, str_replace(",", ".", $rs->PRECO_PUBLICO_ATUAL),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(27, $i, str_replace(",", ".", $rs->CUSTO_REPOS),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(28, $i, $rs->DIAS);
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Estoque Geral VW');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "Estoque-Geral-VW-".date("d-m-Y");
			$objWriter->save($nome_arquivo.".xlsx");
			
			$ssh = new ServidorArquivo();
			
			if ($ssh->MandaArquivo('relatorio', $nome_arquivo.".xlsx") == 'sucesso'){
				$sql = array();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina10(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 10 && $validacao == md5($rotina.date("dmY"))) {
			$funcoes = new Funcoes();
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getEstoquegeralfiat();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('K1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('L1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('M1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('N1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('O1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('P1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Q1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('R1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('S1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('T1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('U1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('V1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('W1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('X1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Y1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Z1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AA1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AB1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AC1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'EMPRESA' )
			->setCellValue('B1', "REVENDA" )
			->setCellValue("C1", "ITEM_ESTOQUE" )
			->setCellValue("D1", "ITEM_ESTOQUE_PUB" )
			->setCellValue("E1", "DES_ITEM_ESTOQUE" )
			->setCellValue("F1", "CLASS_ABC" )
			->setCellValue("G1", "CLASS_XYZ" )
			->setCellValue("H1", "QTD_CONTABIL" )
			->setCellValue("I1", "DTA_SAIDA" )
			->setCellValue("J1", "DTA_ULT_ENTRADA" )
			->setCellValue("K1", "QTD_ULT_ENTRADA" )
			->setCellValue("L1", "BASE_PIS" )
			->setCellValue("M1", "BASE_COFINS" )
			->setCellValue("N1", "NCM" )
			->setCellValue("O1", "CUSTO_MEDIO" )
			->setCellValue("P1", "VAL_ESTOQUE" )
			->setCellValue("Q1", "NOME_GRUPO" )
			->setCellValue("R1", "GRUPO" )
			->setCellValue("S1", "NOME_CATEGORIA" )
			->setCellValue("T1", "CATEGORIA" )
			->setCellValue("U1", "PCT_DESCONTO" )
			->setCellValue("V1", "GRUPO_DESCONTO" )
			->setCellValue("W1", "ALIQUOTA_IPI" )
			->setCellValue("X1", "PRECO_ALTERNATIVO" )
			->setCellValue("Y1", "DEMANDA_MEDIA" )
			->setCellValue("Z1", "INCIDE_PIS_COFINS" )
			->setCellValue("AA1", "PRECO_PUBLICO_ATUAL" )
			->setCellValue("AB1", "CUSTO_REPOS" )
			->setCellValue("AC1", "DIAS" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(35);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(13);
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(13);
			$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(13);
			$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(13);
			$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('O')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('P')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('T')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('U')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('V')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('W')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('X')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('X')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('Y')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('Z')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('AA')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('AA')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('AB')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('AB')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('AC')->setWidth(10);
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->ITEM_ESTOQUE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->ITEM_ESTOQUE_PUB);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $funcoes->retiraAcentos($rs->DES_ITEM_ESTOQUE));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->CLASS_ABC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $rs->CLASS_XYZ);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $rs->QTD_CONTABIL);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, $rs->DTA_SAIDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, $rs->DTA_ULT_ENTRADA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, $rs->QTD_ULT_ENTRADA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $i, $rs->BASE_PIS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $i, $rs->BASE_COFINS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $i, $rs->NCM);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $i, str_replace(",", ".", $rs->CUSTO_MEDIO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(15, $i, str_replace(",", ".", $rs->VAL_ESTOQUE),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(16, $i, $rs->NOME_GRUPO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(17, $i, $rs->GRUPO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(18, $i, $rs->NOME_CATEGORIA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(19, $i, $rs->CATEGORIA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(20, $i, $rs->PCT_DESCONTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(21, $i, $rs->GRUPO_DESCONTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(22, $i, $rs->ALIQUOTA_IPI);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(23, $i, str_replace(",", ".", $rs->PRECO_ALTERNATIVO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(24, $i, $rs->DEMANDA_MEDIA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(25, $i, $rs->INCIDE_PIS_COFINS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(26, $i, str_replace(",", ".", $rs->PRECO_PUBLICO_ATUAL),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(27, $i, str_replace(",", ".", $rs->CUSTO_REPOS),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(28, $i, $rs->DIAS);
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Estoque Geral Fiat');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "Estoque-Geral-Fiat-".date("d-m-Y");
			$objWriter->save($nome_arquivo.".xlsx");
			
			$ssh = new ServidorArquivo();
			
			if ($ssh->MandaArquivo('relatorio', $nome_arquivo.".xlsx") == 'sucesso'){
				$sql = array();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina11(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 11 && $validacao == md5($rotina.date("dmY"))) {
			$funcoes = new Funcoes();
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getMaparesultados1();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'EMPRESA' )
			->setCellValue('B1', "REVENDA" )
			->setCellValue("C1", "NUCLEO" )
			->setCellValue("D1", "VALOR_TOTAL_ESTOQUE" )
			->setCellValue("E1", "VAL_ESTOQUE_OBSOLETO" )
			->setCellValue("F1", "FAT DE MAO DE OBRA" )
			->setCellValue("G1", "OS EM ABERTO" )
			->setCellValue("H1", "OS EM ABERTO +30" )
			->setCellValue("I1", "QTD PASSAGEM OFI" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getStyle('D')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getStyle('E')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getStyle('F')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getStyle('G')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getStyle('H')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(30);
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $funcoes->retiraAcentos($rs->NUCLEO));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, str_replace(",", ".", $rs->VALOR_TOTAL_ESTOQUE),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, str_replace(",", ".", $rs->VAL_ESTOQUE_OBSOLETO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, str_replace(",", ".", $rs->FAT_MAO_OBRA),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, str_replace(",", ".", $rs->OS_ABERTO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, str_replace(",", ".", $rs->OS_ABERTO_30),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, $rs->QTD_PASSAGEM_OFI);
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Mapas de Resultado 1');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "Mapas-de-Resultado1-".date("d-m-Y");
			$objWriter->save($nome_arquivo.".xlsx");
			
			$ssh = new ServidorArquivo();
			
			if ($ssh->MandaArquivo('relatorio', $nome_arquivo.".xlsx") == 'sucesso'){
				$sql = array();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina12(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 12 && $validacao == md5($rotina.date("dmY"))) {
			$funcoes = new Funcoes();
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getMapasresultados2();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'EMPRESA' )
			->setCellValue('B1', "REVENDA" )
			->setCellValue("C1", "NUCLEO" )
			->setCellValue("D1", "DEPARTAMENTO" )
			->setCellValue("E1", "TOTAL_FAT_PECAS" )
			->setCellValue("F1", "CUSTO" )
			->setCellValue("G1", "IMPOSTO" )
			->setCellValue("H1", "MARGEM-%" )
			->setCellValue("I1", "VAL_MARGEM" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getStyle('E')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getStyle('F')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getStyle('G')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getStyle('H')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getStyle('I')->getNumberFormat()->setFormatCode('#,##0.00');
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $funcoes->retiraAcentos($rs->NUCLEO));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->DEPARTAMENTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, str_replace(",", ".", $rs->T_FAT_PECAS),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, str_replace(",", ".", $rs->CUSTO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, str_replace(",", ".", $rs->IMPOSTO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, str_replace(",", ".", $rs->MARGEM),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, str_replace(",", ".", $rs->VAL_MARGEM),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Mapas de Resultado 2');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "Mapas-de-Resultado2-".date("d-m-Y");
			$objWriter->save($nome_arquivo.".xlsx");
			
			$ssh = new ServidorArquivo();
			
			if ($ssh->MandaArquivo('relatorio', $nome_arquivo.".xlsx") == 'sucesso'){
				$sql = array();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina13(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 13 && $validacao == md5($rotina.date("dmY"))) {
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getGarantiaaberto30();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('K1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('L1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('M1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('N1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('O1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('P1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Q1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('R1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('S1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('T1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'EMPRESA' )
			->setCellValue('B1', "REVENDA" )
			->setCellValue("C1", "TITULO" )
			->setCellValue("D1", "DUPLICATA" )
			->setCellValue("E1", "CLIENTE" )
			->setCellValue("F1", "NOME DO CLIENTE" )
			->setCellValue("G1", "TIPO" )
			->setCellValue("H1", "DEPARTAMENTO" )
			->setCellValue("I1", "VENDEDOR" )
			->setCellValue('J1', 'NOME DO VENDEDOR' )
			->setCellValue('K1', "ORIGEM" )
			->setCellValue("L1", "DESCRICAO DA ORIGEM" )
			->setCellValue('M1', 'DATA DE VENCIMENTO' )
			->setCellValue('N1', "VALOR DO TITULO" )
			->setCellValue("O1", "PAGAR OU RECEBER" )
			->setCellValue('P1', 'STATUS' )
			->setCellValue('Q1', "OPERACAO" )
			->setCellValue("R1", "VALOR PAGAMENTO" )
			->setCellValue('S1', 'SALDO DO TITULO' )
			->setCellValue('T1', "NOME DO APROVADOR" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(35);
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('N')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('R')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('S')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('T')->setWidth(30);
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->TITULO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->DUPLICATA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->CLIENTE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->NOME_CLIENTE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $rs->TIPO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $rs->DEPARTAMENTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, $rs->VENDEDOR);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, $rs->NOME_VENDEDOR);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, $rs->ORIGEM);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $i, $rs->DES_ORIGEM);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $i, $rs->DTA_VENCIMENTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $i, str_replace(",", ".", $rs->VAL_TITULO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $i, $rs->PAGAR_RECEBER);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(15, $i, $rs->STATUS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(16, $i, $rs->OPERACAO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(17, $i, str_replace(",", ".", $rs->VAL_PAG),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(18, $i, str_replace(",", ".", $rs->SALDO_TITULO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(19, $i, $rs->NOME_APROVADOR);
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Garantia Mais De 30 Dias');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "Garantias-Em-Aberto-Mais-De-30-Dias-".date("d-m-Y");
			$objWriter->save($nome_arquivo.".xlsx");
			
			$ssh = new ServidorArquivo();
			
			if ($ssh->MandaArquivo('relatorio', $nome_arquivo.".xlsx") == 'sucesso'){
				$sql = array();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina14(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 14 && $validacao == md5($rotina.date("dmY"))) {
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getGarantiaaberto();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('K1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('L1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('M1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('N1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('O1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('P1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Q1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('R1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('S1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('T1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'EMPRESA' )
			->setCellValue('B1', "REVENDA" )
			->setCellValue("C1", "TITULO" )
			->setCellValue("D1", "DUPLICATA" )
			->setCellValue("E1", "CLIENTE" )
			->setCellValue("F1", "NOME DO CLIENTE" )
			->setCellValue("G1", "TIPO" )
			->setCellValue("H1", "DEPARTAMENTO" )
			->setCellValue("I1", "VENDEDOR" )
			->setCellValue('J1', 'NOME DO VENDEDOR' )
			->setCellValue('K1', "ORIGEM" )
			->setCellValue("L1", "DESCRICAO DA ORIGEM" )
			->setCellValue('M1', 'DATA DE VENCIMENTO' )
			->setCellValue('N1', "VALOR DO TITULO" )
			->setCellValue("O1", "PAGAR OU RECEBER" )
			->setCellValue('P1', 'STATUS' )
			->setCellValue('Q1', "OPERACAO" )
			->setCellValue("R1", "VALOR PAGAMENTO" )
			->setCellValue('S1', 'SALDO DO TITULO' )
			->setCellValue('T1', "NOME DO APROVADOR" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(35);
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('N')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('R')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('S')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('T')->setWidth(30);
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->TITULO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->DUPLICATA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->CLIENTE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->NOME_CLIENTE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $rs->TIPO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $rs->DEPARTAMENTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, $rs->VENDEDOR);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, $rs->NOME_VENDEDOR);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, $rs->ORIGEM);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $i, $rs->DES_ORIGEM);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $i, $rs->DTA_VENCIMENTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $i, str_replace(",", ".", $rs->VAL_TITULO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $i, $rs->PAGAR_RECEBER);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(15, $i, $rs->STATUS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(16, $i, $rs->OPERACAO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(17, $i, str_replace(",", ".", $rs->VAL_PAG),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(18, $i, str_replace(",", ".", $rs->SALDO_TITULO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(19, $i, $rs->NOME_APROVADOR);
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Garantias Em Aberto');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "Garantias-Em-Aberto-".date("d-m-Y");
			$objWriter->save($nome_arquivo.".xlsx");
			
			$ssh = new ServidorArquivo();
			
			if ($ssh->MandaArquivo('relatorio', $nome_arquivo.".xlsx") == 'sucesso'){
				$sql = array();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina15(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 15 && $validacao == md5($rotina.date("dmY"))) {
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getInadiplencia();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('K1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('L1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('M1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('N1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('O1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('P1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Q1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('R1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('S1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('T1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'EMPRESA' )
			->setCellValue('B1', "REVENDA" )
			->setCellValue("C1", "TITULO" )
			->setCellValue("D1", "DUPLICATA" )
			->setCellValue("E1", "CLIENTE" )
			->setCellValue("F1", "NOME DO CLIENTE" )
			->setCellValue("G1", "TIPO" )
			->setCellValue("H1", "DEPARTAMENTO" )
			->setCellValue("I1", "VENDEDOR" )
			->setCellValue('J1', 'NOME DO VENDEDOR' )
			->setCellValue('K1', "ORIGEM" )
			->setCellValue("L1", "DESCRICAO DA ORIGEM" )
			->setCellValue('M1', 'DATA DE VENCIMENTO' )
			->setCellValue('N1', "VALOR DO TITULO" )
			->setCellValue("O1", "PAGAR OU RECEBER" )
			->setCellValue('P1', 'STATUS' )
			->setCellValue('Q1', "OPERACAO" )
			->setCellValue("R1", "VALOR PAGAMENTO" )
			->setCellValue('S1', 'SALDO DO TITULO' )
			->setCellValue('T1', "NOME DO APROVADOR" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(35);
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('N')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('R')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('S')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('T')->setWidth(30);
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->TITULO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->DUPLICATA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->CLIENTE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->NOME_CLIENTE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $rs->TIPO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $rs->DEPARTAMENTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, $rs->VENDEDOR);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, $rs->NOME_VENDEDOR);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, $rs->ORIGEM);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $i, $rs->DES_ORIGEM);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $i, $rs->DTA_VENCIMENTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $i, str_replace(",", ".", $rs->VAL_TITULO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $i, $rs->PAGAR_RECEBER);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(15, $i, $rs->STATUS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(16, $i, $rs->OPERACAO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(17, $i, str_replace(",", ".", $rs->VAL_PAG),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(18, $i, str_replace(",", ".", $rs->SALDO_TITULO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(19, $i, $rs->NOME_APROVADOR);
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Inadiplencia');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "Inadiplencia-".date("d-m-Y");
			$objWriter->save($nome_arquivo.".xlsx");
			
			$ssh = new ServidorArquivo();
			
			if ($ssh->MandaArquivo('relatorio', $nome_arquivo.".xlsx") == 'sucesso'){
				$sql = array();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina16(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 16 && $validacao == md5($rotina.date("dmY"))) {
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getChequedia();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'DIA' )
			->setCellValue('B1', "BANCO" )
			->setCellValue("C1", "NOME BANCO" )
			->setCellValue("D1", "VALOR" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(25);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(35);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getStyle('D')->getNumberFormat()->setFormatCode('#,##0.00');
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->DIA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->BANCO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->DES_BANCO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, str_replace(",", ".", $rs->VALOR),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Posicao Cheque Dia');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "CH-Dia-".date("d-m-Y");
			$objWriter->save($_SERVER["DOCUMENT_ROOT"] ."/". RAIZ_PATH."dados/anexo/{$nome_arquivo}.xlsx");
			
			$sql = array();
			$i = 0;
			$email = new Email();
			$email->dta_envio = date('d/m/Y');
			$email->hora_envio = "07:50:00";
			$email->rotina = $rotina;
			$email->remetente = "SisMonaco - Cheques Dia ".date('d/m/Y');
			$email->assunto = "Cheques Pendentes Dia ".date('d/m/Y');
			$email->mensagem = "Segue em anexo o relat�rio de cheques em aberto di�rio" ;
			$email->anexo = "dados/anexo/{$nome_arquivo}.xlsx";
			$email->situacao = 'P';
			$apiEmail = new apiEmail();
			$apiRotinausuario = new apiRotinausuario();
			$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
			foreach ($result as $rs) {
				$email->destinatario = $rs->EMAIL;
				$sql[$i] = $apiEmail->addEmail($email);
				$i = $i + 1;	
			}
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao = date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina17(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 17 && $validacao == md5($rotina.date("dmY"))) {
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getChequemes();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'ANO' )
			->setCellValue('B1', "MES" )
			->setCellValue("C1", "MES/ANO" )
			->setCellValue("D1", "BANCO" )
			->setCellValue("E1", "NOME BANCO" )
			->setCellValue("F1", "VALOR" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(35);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getStyle('F')->getNumberFormat()->setFormatCode('#,##0.00');
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->ANO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->MES);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->MESANO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->BANCO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->DES_BANCO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, str_replace(",", ".", $rs->VALOR),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Posicao Cheques Mes');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "CH-Mes-".date("d-m-Y");
			$objWriter->save($_SERVER["DOCUMENT_ROOT"] ."/". RAIZ_PATH."dados/anexo/{$nome_arquivo}.xlsx");
			
			$sql = array();
			$i = 0;
			$email = new Email();
			$email->dta_envio = date('d/m/Y');
			$email->hora_envio = "07:50:00";
			$email->rotina = $rotina;
			$email->remetente = "SisMonaco - Cheques M�s ".date('d/m/Y');
			$email->assunto = "Cheques Pendentes M�s ".date('d/m/Y');
			$email->mensagem = "Segue em anexo o relat�rio de cheques em aberto mensal" ;
			$email->anexo = "dados/anexo/{$nome_arquivo}.xlsx";
			$email->situacao = 'P';
			$apiEmail = new apiEmail();
			$apiRotinausuario = new apiRotinausuario();
			$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
			foreach ($result as $rs) {
				$email->destinatario = $rs->EMAIL;
				$sql[$i] = $apiEmail->addEmail($email);
				$i = $i + 1;
			}
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao = date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina18(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 18 && $validacao == md5($rotina.date("dmY"))) {
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getContasreceberdia();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'MES/ANO' )
			->setCellValue('B1', "QUANTIDADE" )
			->setCellValue("C1", "VALOR" )
			->setCellValue("D1", "MEDIA" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(25);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getStyle('C')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getStyle('D')->getNumberFormat()->setFormatCode('#,##0.00');
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->MESANO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->QUANTIDADE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, str_replace(",", ".", $rs->VALOR),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, str_replace(",", ".", $rs->MEDIA),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Contas a Receber Dia');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "CR-Dia-".date("d-m-Y");
			$objWriter->save($_SERVER["DOCUMENT_ROOT"] ."/". RAIZ_PATH."dados/anexo/{$nome_arquivo}.xlsx");
			
			$sql = array();
			$i = 0;
			$email = new Email();
			$email->dta_envio = date('d/m/Y');
			$email->hora_envio = "07:50:00";
			$email->rotina = $rotina;
			$email->remetente = "SisMonaco - CR Dia ".date('d/m/Y');
			$email->assunto = "Contas a Receber Dia ".date('d/m/Y');
			$email->mensagem = "Segue em anexo o relat�rio de contas a receber di�rio" ;
			$email->anexo = "dados/anexo/{$nome_arquivo}.xlsx";
			$email->situacao = 'P';
			$apiEmail = new apiEmail();
			$apiRotinausuario = new apiRotinausuario();
			$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
			foreach ($result as $rs) {
				$email->destinatario = $rs->EMAIL;
				$sql[$i] = $apiEmail->addEmail($email);
				$i = $i + 1;
			}
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao = date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina19(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 19 && $validacao == md5($rotina.date("dmY"))) {
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getContasrecebermes();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'MES' )
			->setCellValue('B1', "ANO" )
			->setCellValue("C1", "MES/ANO" )
			->setCellValue("D1", "QUANTIDADE" )
			->setCellValue("E1", "VALOR" )
			->setCellValue("F1", "MEDIA" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(25);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getStyle('E')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getStyle('F')->getNumberFormat()->setFormatCode('#,##0.00');
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->MES);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->ANO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->MESANO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->QUANTIDADE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, str_replace(",", ".", $rs->VALOR),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, str_replace(",", ".", $rs->MEDIA),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Contas a Receber Mes');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "CR-Mes-".date("d-m-Y");
			$objWriter->save($_SERVER["DOCUMENT_ROOT"] ."/". RAIZ_PATH."dados/anexo/{$nome_arquivo}.xlsx");
			
			$sql = array();
			$i = 0;
			$email = new Email();
			$email->dta_envio = date('d/m/Y');
			$email->hora_envio = "07:50:00";
			$email->rotina = $rotina;
			$email->remetente = "SisMonaco - CR Mes ".date('d/m/Y');
			$email->assunto = "Contas a Receber Mes ".date('d/m/Y');
			$email->mensagem = "Segue em anexo o relat�rio de contas a receber mensal" ;
			$email->anexo = "dados/anexo/{$nome_arquivo}.xlsx";
			$email->situacao = 'P';
			$apiEmail = new apiEmail();
			$apiRotinausuario = new apiRotinausuario();
			$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
			foreach ($result as $rs) {
				$email->destinatario = $rs->EMAIL;
				$sql[$i] = $apiEmail->addEmail($email);
				$i = $i + 1;
			}
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao = date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina20(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 20 && $validacao == md5($rotina.date("dmY"))) {
			$funcoes = new  Funcoes();
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getMotologistica();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('K1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('L1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('M1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('N1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('O1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('P1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue("A1", "EMPRESA" )
			->setCellValue("B1", "REVENDA" )
			->setCellValue("C1", "CONTATO" )
			->setCellValue("D1", "NUMERO DE NOTA FISCAL" )
			->setCellValue("E1", "NOME CLIENTE" )
			->setCellValue("F1", "CIDADE" )
			->setCellValue("G1", "FONE FIXO" )
			->setCellValue("H1", "CELULAR" )
			->setCellValue("I1", "DATA VENDA" )
			->setCellValue("J1", "PROPOSTA" )
			->setCellValue("K1", "NOME DE VENDEDOR" )
			->setCellValue("L1", "CHASSI" )
			->setCellValue("M1", "DESCRICAO COR" )
			->setCellValue("N1", "DESCRICAO MODELO" )
			->setCellValue("O1", "LOCALIZACAO" )
			->setCellValue("P1", "OBSERVACAO" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(20);
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->CONTATO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->NUMERO_NOTA_FISCAL);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, utf8_encode($rs->NOME_CLIENTE));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, utf8_encode($rs->CIDADE));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $rs->FONE_FIXO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $rs->CELULAR);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, $rs->DATA_VENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, $rs->PROPOSTA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, utf8_encode($rs->NOME_VENDEDOR));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $i, $rs->N_CHASSI);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $i, utf8_encode($rs->DESCRICAO_COR));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $i, utf8_encode($rs->DESCRICAO_MODELO));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $i, utf8_encode($rs->LOCALIZACAO));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(15, $i, utf8_encode($rs->OBSERVACAO));
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Motos Logistica');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "Logistica-".date("d-m-Y");
			$objWriter->save($_SERVER["DOCUMENT_ROOT"] ."/". RAIZ_PATH."dados/anexo/{$nome_arquivo}.xlsx");
			
			$sql = array();
			$i = 0;
			$email = new Email();
			$email->dta_envio = date('d/m/Y');
			$email->hora_envio = "07:50:00";
			$email->rotina = $rotina;
			$email->remetente = "SisMonaco - Motos Logistica ".date('d/m/Y');
			$email->assunto = "Movimento Motos ".date('d/m/Y');
			$email->mensagem = "Segue em anexo o relat�rio de notas de motos para Logistica" ;
			$email->anexo = "dados/anexo/{$nome_arquivo}.xlsx";
			$email->situacao = 'P';
			$apiEmail = new apiEmail();
			$apiRotinausuario = new apiRotinausuario();
			$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
			foreach ($result as $rs) {
				$email->destinatario = $rs->EMAIL;
				$sql[$i] = $apiEmail->addEmail($email);
				$i = $i + 1;
			}
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao = date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina21(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 21 && $validacao == md5($rotina.date("dmY"))) {
			$funcoes = new Funcoes();
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getEstoquemotos();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('K1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'NOME FANTASIA' )
			->setCellValue('B1', "EMPRESA" )
			->setCellValue("C1", "REVENDA" )
			->setCellValue("D1", "VEICULO" )
			->setCellValue("E1", "SITUACAO" )
			->setCellValue("F1", "VALOR CUSTO CONTABIL" )
			->setCellValue("G1", "MODELO" )
			->setCellValue("H1", "PRECO PUBLICO" )
			->setCellValue("I1", "DIAS EM ESTOQUE" )
			->setCellValue("J1", "COR" )
			->setCellValue("K1", "LOCALIZACAO" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(40);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('F')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('H')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(17);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(30);
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $funcoes->retiraAcentos($rs->NOME_FANTASIA));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->REVENDA_ORIGEM);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->VEICULO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->SITUACAO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, str_replace(",", ".", $rs->VAL_CUSTO_CONTABIL),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $rs->MODELO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, str_replace(",", ".", $rs->PRECO_PUBLICO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, $rs->DIAS_EM_ESTOQUES);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, utf8_encode($rs->COR));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, utf8_encode($rs->LOCALIZACAO));
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Estoque de Motos');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "Motos-".date("d-m-Y");
			$objWriter->save($_SERVER["DOCUMENT_ROOT"] ."/". RAIZ_PATH."dados/anexo/{$nome_arquivo}.xlsx");
			
			$sql = array();
			$i = 0;
			$email = new Email();
			$email->dta_envio = date('d/m/Y');
			$email->hora_envio = "07:50:00";
			$email->rotina = $rotina;
			$email->remetente = "SisMonaco - Motos Em Estoque ".date('d/m/Y');
			$email->assunto = "Motos No Estoque ".date('d/m/Y');
			$email->mensagem = "Segue em anexo o relat�rio de motos em estoque" ;
			$email->anexo = "dados/anexo/{$nome_arquivo}.xlsx";
			$email->situacao = 'P';
			$apiEmail = new apiEmail();
			$apiRotinausuario = new apiRotinausuario();
			$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
			foreach ($result as $rs) {
				$email->destinatario = $rs->EMAIL;
				$sql[$i] = $apiEmail->addEmail($email);
				$i = $i + 1;
			}
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao = date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina26(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 26 && $validacao == md5($rotina.date("dmY"))) {
			$funcoes = new Funcoes();
			$apiAgendarotina = new apiAgendarotina();
			
			$result = $apiAgendarotina->getSaidademonstracao();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('K1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('L1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('M1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('N1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('O1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'EMPRESA' )
			->setCellValue('B1', "REVENDA" )
			->setCellValue("C1", "NUMERO_NOTA_FISCAL" )
			->setCellValue("D1", "SERIE NOTA_FISCAL" )
			->setCellValue("E1", "TIPO TRANSACAO" )
			->setCellValue("F1", "SITUACAO" )
			->setCellValue("G1", "REVENDA_ORIGEM" )
			->setCellValue("H1", "VEICULO" )
			->setCellValue("I1", "DES_COR" )
			->setCellValue('J1', "LOCALIZACAO" )
			->setCellValue('K1', "CLIENTE" )
			->setCellValue("L1", "NOME" )
			->setCellValue('M1', "DTA ENTRADA SAIDA" )
			->setCellValue('N1', "DTA VENCIMENTO" )
			->setCellValue("O1", "DIAS" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(35);
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(15);
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->NUMERO_NOTA_FISCAL);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->SERIE_NOTA_FISCAL);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->TIPO_TRANSACAO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->SITUACAO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $rs->REVENDA_ORIGEM);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $rs->VEICULO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, $rs->DES_COR);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, $funcoes->retiraAcentos($rs->LOCALIZACAO));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, $rs->CLIENTE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $i,$funcoes->retiraAcentos( $rs->NOME));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $i, $rs->DTA_ENTRADA_SAIDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $i, $rs->DTA_VENCIMENTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $i, round($rs->DIAS));
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Saida Em Demonstracao');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "Demonstracao-".date("d-m-Y");
			$objWriter->save($_SERVER["DOCUMENT_ROOT"] ."/". RAIZ_PATH."dados/anexo/{$nome_arquivo}.xlsx");
			
			$sql = array();
			$i = 0;
			$email = new Email();
			$email->dta_envio = date('d/m/Y');
			$email->hora_envio = "07:50:00";
			$email->rotina = $rotina;
			$email->remetente = "SisMonaco - Demonstra��o ".date('d/m/Y');
			$email->assunto = "Ve�culos em Demonstra��o ".date('d/m/Y');
			$email->mensagem = "Segue em anexo o relat�rio de ve�culos em demonstra��o" ;
			$email->anexo = "dados/anexo/{$nome_arquivo}.xlsx";
			$email->situacao = 'P';
			$apiEmail = new apiEmail();
			$apiRotinausuario = new apiRotinausuario();
			$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
			foreach ($result as $rs) {
				$email->destinatario = $rs->EMAIL;
				$sql[$i] = $apiEmail->addEmail($email);
				$i = $i + 1;
			}
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao = date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina27(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 27 && $validacao == md5($rotina.date("dmY"))) {
			$funcoes = new Funcoes();
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getVmog();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('K1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('L1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('M1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('N1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('O1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('P1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Q1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('R1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('S1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('T1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('U1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('V1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('W1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('X1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Y1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Z1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AA1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AB1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AC1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AD1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AE1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AF1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AG1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AH1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AI1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AJ1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AK1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'DN' )
			->setCellValue('B1', 'OS' )
			->setCellValue("C1", 'DATA DE ABERTURA' )
			->setCellValue('D1', 'DATA DE FECHAMENTO' )
			->setCellValue('E1', 'FONTE PAGADORA' )
			->setCellValue("F1", 'CHASSI DO VEICULO' )
			->setCellValue('G1', 'MODELO DO VEICULO' )
			->setCellValue('H1', 'MODELO' )
			->setCellValue('I1', 'NATUREZA DO SERVICO' )
			->setCellValue("J1", 'CODIGO DO TPR' )
			->setCellValue('K1', 'DESCRICAO DO SERVICO' )
			->setCellValue('L1', 'TEMPO VENDIDO' )
			->setCellValue("M1", 'VALOR FATURADO' )
			->setCellValue('N1', 'OFICINA' )
			->setCellValue('O1', 'TERCEIRO' )
			->setCellValue("P1", 'CATEGORIA DO VEICULO' )
			->setCellValue('Q1', 'DESLOCAMENTO' )
			->setCellValue('R1', 'NOME DO CLIENTE' )
			->setCellValue("S1", 'TIPO DE CLIENTE' )
			->setCellValue('T1', 'CGC/CPF' )
			->setCellValue('U1', 'PAIS' )
			->setCellValue("V1", 'CONTATO' )
			->setCellValue('W1', 'TELEFONE' )
			->setCellValue('X1', 'CELULAR' )
			->setCellValue("Y1", 'E-MAIL' )
			->setCellValue('Z1', 'KILOMETRAGEM' )
			->setCellValue('AA1', 'PLACA' )
			->setCellValue("AB1", 'MONTADORA(VW,MAN)' )
			->setCellValue('AC1', 'TIPO DE VIA' )
			->setCellValue('AD1', 'ENDERECO' )
			->setCellValue("AE1", 'COMPLEMENTO' )
			->setCellValue('AF1', 'BAIRRO' )
			->setCellValue('AG1', 'CIDADE' )
			->setCellValue("AH1", 'UF' )
			->setCellValue('AI1', 'CEP' )
			->setCellValue('AJ1', 'NOTA FISCAL' )
			->setCellValue("AK1", 'NOME DO CONSULTOR' );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(5);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(8);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(17);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(19);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(35);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(19);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('L')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('M')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(12);
			$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(13);
			$objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('T')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('T')->getNumberFormat()->setFormatCode('0');
			$objPHPExcel->getActiveSheet()->getColumnDimension('U')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('V')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('W')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('X')->setWidth(35);
			$objPHPExcel->getActiveSheet()->getColumnDimension('Y')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('Z')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('AA')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('AB')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('AC')->setWidth(35);
			$objPHPExcel->getActiveSheet()->getColumnDimension('AD')->setWidth(35);
			$objPHPExcel->getActiveSheet()->getColumnDimension('AE')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('AF')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('AG')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('AH')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('AI')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('AJ')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('AK')->setWidth(35);
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->DN);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->OS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->DATADEABERTURA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->DATADEFATURAMENTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->FONTEPAGADORA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->CHASSIDOVEICULO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, utf8_encode($rs->MODELODOVEICULO));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $rs->MODELO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, $rs->NATUREZADOSERVICO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, $rs->CODIGODOTPR);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, utf8_encode($rs->DESCRICAODOSERVICO));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $i, str_replace(",", ".",$rs->TEMPOVENDIDO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $i, str_replace(",", ".",$rs->VALORFATURADO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $i, $rs->OFICINA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $i, $rs->TERCEIRO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(15, $i, $rs->CATEGORIADOVEICULO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(16, $i, $rs->DESLOCAMENTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(17, $i, utf8_encode($rs->NOMEDOCLIENTE));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(18, $i, $rs->TIPODECLIENTE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(19, $i, $rs->CGC_CPF);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(20, $i, $rs->PAIS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(21, $i, utf8_encode($rs->CONTATO));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(22, $i, $rs->TELEFONE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(23, $i, $rs->CELULAR);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(24, $i, $rs->EMAIL);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(25, $i, $rs->KILOMETRAGEM);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(26, $i, $rs->PLACA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(27, $i, $rs->MONTADORAVW_MAN);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(28, $i, $rs->TIPOVIA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(29, $i, utf8_encode($rs->ENDERECO));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(30, $i, utf8_encode($rs->COMPLEMENTO));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(31, $i, utf8_encode($rs->BAIRRO));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(32, $i, utf8_encode($rs->CIDADE));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(33, $i, $rs->UF);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(34, $i, $rs->CEP);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(35, $i, $rs->NOTAFISCAL);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(36, $i, utf8_encode($rs->NOMEDOCONSULTOR));
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('VMOG');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "VMOG-Semanal-".date("d-m-Y");
			$objWriter->save($_SERVER["DOCUMENT_ROOT"] ."/". RAIZ_PATH."dados/anexo/{$nome_arquivo}.xlsx");
			
			$sql = array();
			$i = 0;
			$email = new Email();
			$email->dta_envio = date('d/m/Y');
			$email->hora_envio = "07:50:00";
			$email->rotina = $rotina;
			$email->remetente = "SisMonaco - VMOG";
			$email->assunto = "VMOG Semanal ".date('d/m/Y');
			$email->mensagem = "Segue em anexo o relat�rio VMOG" ;
			$email->anexo = "dados/anexo/{$nome_arquivo}.xlsx";
			$email->situacao = 'P';
			$apiEmail = new apiEmail();
			$apiRotinausuario = new apiRotinausuario();
			$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
			foreach ($result as $rs) {
				$email->destinatario = $rs->EMAIL;
				$sql[$i] = $apiEmail->addEmail($email);
				$i = $i + 1;
			}
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao = date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina28(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 28 && $validacao == md5($rotina.date("dmY"))) {
			$funcoes = new Funcoes();
			$apiAgendarotina = new apiAgendarotina();
			
			$result = $apiAgendarotina->getInvempresas();
			
			$i = 0;$cont = 0;
			
			$arr_op[0]['op'] = "and VV.NOVO_USADO = 'N'";
			$arr_op[0]['nome_op'] = "NOVOS";
			$arr_op[0]['situacao_op'] = "'AV', 'BL', 'EF', 'ES'";
			
			$arr_op[1]['op'] = "and VV.NOVO_USADO = 'U'";
			$arr_op[1]['nome_op'] = "USADOS";
			$arr_op[1]['situacao_op'] = "'AV', 'BL', 'EF', 'ES'";
			
			$arr_op[2]['op'] = "";
			$arr_op[2]['nome_op'] = "DEMONSTRACAO";
			$arr_op[2]['situacao_op'] = "'SD'";
			
			$arr_op[3]['op'] = "";
			$arr_op[3]['nome_op'] = "FEIRA_EXPOSICAO";
			$arr_op[3]['situacao_op'] = "'ST'";
			
			foreach ($result as $rs){
				$arr_emp[$i]['empresa'] = $rs->EMPRESA;
				$arr_emp[$i]['revenda'] = $rs->REVENDA;
				$arr_emp[$i]['cnpj'] = $rs->CNPJ;
				$arr_emp[$i]['razao_social'] = $rs->RAZAO_SOCIAL;
				$i++;
			}
			$tam_emp = (is_array($arr_emp) ? count($arr_emp) : 0);
			
			for($i=0;$i<$tam_emp;$i++){
				
				for($j=0;$j<4;$j++){
					$result = $apiAgendarotina->getInventarioveiculo($arr_emp[$i]['empresa'], $arr_emp[$i]['revenda'], $arr_op[$j]['situacao_op'], $arr_op[$j]['op']);
					
					$qtd_itens = 0;
					$c_total = 0;
					$a = 0;
					
					
					$objPHPExcel = new \PHPExcel();
					
					$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('A2')->getFont()->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('B2')->getFont()->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('C2')->getFont()->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('D2')->getFont()->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('E2')->getFont()->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('F2')->getFont()->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('G2')->getFont()->setBold(true);
					$objPHPExcel->getActiveSheet()->getStyle('H2')->getFont()->setBold(true);
					
					$objPHPExcel->setActiveSheetIndex(0)
					->setCellValue('A2', 'ITEM' )
					->setCellValue('B2', "POSICAO_FISCAL" )
					->setCellValue("C2", "NF" )
					->setCellValue("D2", "DT_ENTRADA" )
					->setCellValue("E2", "VEICULO" )
					->setCellValue("F2", "CHASSI" )
					->setCellValue("G2", "DES_MODELO" )
					->setCellValue("H2", "VAL_CUSTO_CONTABIL" );
					
					$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(6);
					$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(16);
					$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(12);
					$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(13);
					$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(20);
					$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(20);
					$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(20);
					$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(20);
					$objPHPExcel->getActiveSheet()->getStyle('H')->getNumberFormat()->setFormatCode('#,##0.00');
					
					// Tamb�m podemos escolher a posi��o exata aonde o dado ser� inserido (coluna, linha, dado);
					$a = 2;
					foreach ($result as $rs){
						$a = $a + 1;
						$qtd_itens = $qtd_itens + 1;
						$arr = explode("E", $rs->DADOS);
						$dt_entrada = $arr[0];
						$nf = $arr[1];
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $a, $qtd_itens);
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $a, $rs->POSICAO_FISCAL);
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $a, $nf);
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $a, $dt_entrada);
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $a, $rs->VEICULO);
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $a, $rs->CHASSI);
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $a, $rs->DES_MODELO);
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $a, str_replace(",", ".", $rs->VAL_CUSTO_CONTABIL),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						$c_total = $c_total + str_replace(",", ".", $rs->VAL_CUSTO_CONTABIL);
						$cont = 1;
					}
					if($cont!=0){
						$objPHPExcel->getActiveSheet()->mergeCells('A1:H1')->setCellValueByColumnAndRow(0, 1, "Empresa: {$arr_emp[$i]['empresa']}.{$arr_emp[$i]['revenda']}.{$arr_emp[$i]['razao_social']} - Relatorio de Inventario de Veiculo - {$arr_op[$j]['nome_op']}    Data: ".date("d-m-Y")." Hora: ".date("H:i:s"));
						$a = $a + 1;
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $a,"");
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $a,"");
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $a,"");
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $a,"");
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $a,"");
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $a,"");
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $a,"");
						$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $a,str_replace(",", ".", $c_total),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
						
						$objPHPExcel->getActiveSheet()->setTitle('Inventario de Veiculos');
						
						$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
						
						$nome_arquivo = "SisMonaco-Inventario-de-Veiculos-[{$arr_emp[$i]['empresa']}.{$arr_emp[$i]['revenda']}]".str_replace(" ","-",$funcoes->retiraAcentos($arr_emp[$i]['razao_social']))."-{$funcoes->retiraAcentos($arr_op[$j]['nome_op'])}";
						$objWriter->save($_SERVER["DOCUMENT_ROOT"] ."/". RAIZ_PATH."{$nome_arquivo}.xlsx");
						
						$ssh = new ServidorArquivo();
						
						if ($ssh->MandaArquivo('inventario', $nome_arquivo.".xlsx") == 'sucesso'){
							$mensagem = "Executado com Sucesso!";
						}else {
							$mensagem = "N�o Executado!";
						}
						
					}
					$cont = 0;
				}
				
			}
			
			if ($mensagem != NULL){
				$sql = array();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}	
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina40(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 40 && $validacao == md5($rotina.date("dmY"))) {
			$sql = array();
			$i = 0;
			$email = new Email();
			$email->dta_envio = date('d/m/Y');
			$email->hora_envio = "16:50:00";
			$email->rotina = $rotina;
			$email->remetente = "SisMonaco - Aviso Semanal 17:00";
			$email->assunto = "Anal�se de Resultado";
			$email->mensagem = "GESTORES J� AVALIARAM SEUS RESULTADO DA SEMANA , EST� DENTRO DA PROJE��O ? REUNA SUA EQUIPE , PARABENIZE OS QUE EST�O DENTRO DA META E ESTIGUE OS QUE AINDA N�O EST�O NO RESULTADO IDEAL PROPOSTO.";
			$email->situacao = 'P';
			$apiEmail = new apiEmail();
			$apiRotinausuario = new apiRotinausuario();
			$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
			foreach ($result as $rs) {
				$email->destinatario = $rs->EMAIL;
				$sql[$i] = $apiEmail->addEmail($email);
				$i = $i + 1;
			}
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao = date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$apiAgendarotina = new apiAgendarotina();
			$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina43(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 43 && $validacao == md5($rotina.date("dmY"))) {
			$sql = array();
			$i = 0;
			$email = new Email();
			$email->dta_envio = date('d/m/Y');
			$email->hora_envio = "07:50:00";
			$email->rotina = $rotina;
			$email->remetente = "SisMonaco - Aviso Semanal 08:00";
			$email->assunto = "Participa��o da Reuni�o de Vendas";
			$email->mensagem = "GESTORES J� MOSTRARAM A NOSSA EQUIPE DE VENDAS NOSSAS PROMO��ES SEMANAIS , OS NOSSOS PRE�OS DAS PRIMEIRAS REVIS�ES ? RESSALTEM QUE SOMOS UM TIME E QUE ELES TAMB�M DEVEM VENDER NOSSO P�S VENDAS.";
			$email->situacao = 'P';
			$apiEmail = new apiEmail();
			$apiRotinausuario = new apiRotinausuario();
			$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
			foreach ($result as $rs) {
				$email->destinatario = $rs->EMAIL;
				$sql[$i] = $apiEmail->addEmail($email);
				$i = $i + 1;
			}
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao = date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$apiAgendarotina = new apiAgendarotina();
			$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina44(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 44 && $validacao == md5($rotina.date("dmY"))) {
			$sql = array();
			$i = 0;
			$email = new Email();
			$email->dta_envio = date('d/m/Y');
			$email->hora_envio ="07:50:00";
			$email->rotina = $rotina;
			$email->remetente = "SisMonaco - Aviso Semanal 08:00";
			$email->assunto = "Acompanhamento de O.S em Aberto";
			$email->mensagem = "GESTORES TEM ACOMPANHADO AS O.S EM ABERTO ? QUAL O MOTIVO ? FALTA DE PE�AS ? NOTA DE TERCEIROS ? AUTORIZA��O DE AEG ? AUTORIZA��O DO CLIENTE ? LEMBREM SE QUE DEPENDEMOS DE SUAS EMISS�ES PARA TERMOS UM FLUXO DE CAIXA SA�DAVEL.";
			$email->situacao = 'P';
			$apiEmail = new apiEmail();
			$apiRotinausuario = new apiRotinausuario();
			$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
			foreach ($result as $rs) {
				$email->destinatario = $rs->EMAIL;
				$sql[$i] = $apiEmail->addEmail($email);
				$i = $i + 1;
			}
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao = date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$apiAgendarotina = new apiAgendarotina();
			$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina46(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 46 && $validacao == md5($rotina.date("dmY"))) {
			$sql = array();
			$i = 0;
			$email = new Email();
			$email->dta_envio = date('d/m/Y');
			$email->hora_envio = "15:50:00";
			$email->rotina = $rotina;
			$email->remetente = "SisMonaco - Aviso Semanal 16:00";
			$email->assunto = "Controle do Pedido de Compras";
			$email->mensagem = "GESTORES J� AVALIARAM SEUS RESULTADO DA SEMANA DE RETIRADA DE PE�AS NO P&A , EST� ACOMPANHANDO NOSSA PERFORMANCE , PARA ALCAN�ARMOS O M�NIMO ESTABELECIDO DE 10% DE BONIFICA��O?";
			$email->situacao = 'P';
			$apiEmail = new apiEmail();
			$apiRotinausuario = new apiRotinausuario();
			$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
			foreach ($result as $rs) {
				$email->destinatario = $rs->EMAIL;
				$sql[$i] = $apiEmail->addEmail($email);
				$i = $i + 1;
			}
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao = date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$apiAgendarotina = new apiAgendarotina();
			$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina47(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 47 && $validacao == md5($rotina.date("dmY"))) {
			$sql = array();
			$i = 0;
			$email = new Email();
			$email->dta_envio = date('d/m/Y');
			$email->hora_envio = "15:50:00";
			$email->rotina = $rotina;
			$email->remetente = "SisMonaco - Aviso Semanal 16:00";
			$email->assunto = "Acompanhamento do CRM";
			$email->mensagem = "GESTORES TEM USADO O COMIT� PARA AVALIAR O RESULTADO DA SEMANA DE NOSSO CRM ? TEMOS AUMENTADO NOSSO ATENDIMENTO ESTAMOS OFERTANDO NOSSAS PROMO��ES , O SUCESSO DO CRM DEPENDE MUITO DE NOSSO ACOMPANHAMENTO.";
			$email->situacao = 'P';
			$apiEmail = new apiEmail();
			$apiRotinausuario = new apiRotinausuario();
			$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
			foreach ($result as $rs) {
				$email->destinatario = $rs->EMAIL;
				$sql[$i] = $apiEmail->addEmail($email);
				$i = $i + 1;
			}
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao = date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$apiAgendarotina = new apiAgendarotina();
			$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina48(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 48 && $validacao == md5($rotina.date("dmY"))) {
			$sql = array();
			$i = 0;
			$email = new Email();
			$email->dta_envio = date('d/m/Y');
			$email->hora_envio = "13:50:00";
			$email->rotina = $rotina;
			$email->remetente = "SisMonaco - Aviso Semanal 14:00";
			$email->assunto = "Redu��o de Estoque Obsoleto";
			$email->mensagem = "GESTORES J� AVALIARAM SEUS ESTOQUE OBSOLETOS , FIZEMOS ALGUMA A��O NA SEMANA ? HOUVE RESULTADO ? ME�A COM A EQUIPE O RESULTADO ALCAN�ADO E MATENHA O FOCO.";
			$email->situacao = 'P';
			$apiEmail = new apiEmail();
			$apiRotinausuario = new apiRotinausuario();
			$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
			foreach ($result as $rs) {
				$email->destinatario = $rs->EMAIL;
				$sql[$i] = $apiEmail->addEmail($email);
				$i = $i + 1;
			}
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao = date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$apiAgendarotina = new apiAgendarotina();
			$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina49(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 49 && $validacao == md5($rotina.date("dmY"))) {
			$sql = array();
			$i = 0;
			$email = new Email();
			$email->dta_envio = date('d/m/Y');
			$email->hora_envio = "10:50:00";
			$email->rotina = $rotina;
			$email->remetente = "SisMonaco - Aviso Semanal 11:00";
			$email->assunto = "Lan�amento das Visitas no Syonet";
			$email->mensagem = "SENHORES COMO EST� O LAN�AMENTO DAS VISITAS NO SYONET ? USEM A FERRAMENTA PARA TRANSCREVER O QUE O CLIENTE PRECISA , ABORDE PONTOS DE MELHORIAS E O QUE ESTE VALORIZA , APROVEITE PARA ATUALIZAR A SUA FROTA , NOME DO COMPRADOR , E-MAIL E TELEFONE.";
			$email->situacao = 'P';
			$apiEmail = new apiEmail();
			$apiRotinausuario = new apiRotinausuario();
			$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
			foreach ($result as $rs) {
				$email->destinatario = $rs->EMAIL;
				$sql[$i] = $apiEmail->addEmail($email);
				$i = $i + 1;
			}
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao = date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$apiAgendarotina = new apiAgendarotina();
			$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina51(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 51 && $validacao == md5($rotina.date("dmY"))) {
			$sql = array();
			$i = 0;
			$email = new Email();
			$email->dta_envio = date('d/m/Y');
			$email->hora_envio = "09:50:00";
			$email->rotina = $rotina;
			$email->remetente = "SisMonaco - Aviso Semanal 10:00";
			$email->assunto = "Atas de Reuni�o";
			$email->mensagem = "SENHORES FEZ ALGUM BATE PAPO OU ALGUM ALINHAMENTO DE TAREFAS E OU DIVULGOU ALGO IMPORTANTE PARA EQUIPE ?  N�O ESQUE�A DE FAZER ATA DE REUNI�O , AFINAL S�O ELAS QUE COMPROVAM NOSSAS ATUA��ES E NOS EVIDENCIAM EM NOSSOS PERFIS.";
			$email->situacao = 'P';
			$apiEmail = new apiEmail();
			$apiRotinausuario = new apiRotinausuario();
			$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
			foreach ($result as $rs) {
				$email->destinatario = $rs->EMAIL;
				$sql[$i] = $apiEmail->addEmail($email);
				$i = $i + 1;
			}
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao = date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$apiAgendarotina = new apiAgendarotina();
			$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina52(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 52 && $validacao == md5($rotina.date("dmY"))) {
			$sql = array();
			$i = 0;
			$email = new Email();
			$email->dta_envio = date('d/m/Y');
			$email->hora_envio = "15:50:00";
			$email->rotina = $rotina;
			$email->remetente = "SisMonaco - Aviso Semanal 16:00";
			$email->assunto = "Controle de Banco de Horas";
			$email->mensagem = "GESTORES N�O ESQUE�AM DE ACOMPANHAR O BANCO DE HORAS DE VOSSOS DEPARTAMENTOS , SE TEMOS MUITAS HORAS IDENTIFIQUE O MOTIVO DOS EXCESSOS , AFINAL ULTRAPASSAR A CARGA HOR�RIA DO DIA , S� COM VOSSAS AUTORIZA��ES.";
			$email->situacao = 'P';
			$apiEmail = new apiEmail();
			$apiRotinausuario = new apiRotinausuario();
			$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
			foreach ($result as $rs) {
				$email->destinatario = $rs->EMAIL;
				$sql[$i] = $apiEmail->addEmail($email);
				$i = $i + 1;
			}
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao = date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$apiAgendarotina = new apiAgendarotina();
			$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina55(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 55 && $validacao == md5($rotina.date("dmY"))) {
			$sql = array();
			$i = 0;
			$email = new Email();
			$email->dta_envio = date('d/m/Y');
			$email->hora_envio = "16:50:00";
			$email->rotina = $rotina;
			$email->remetente = "SisMonaco - Aviso Semanal 17:00";
			$email->assunto = "Acompanhamento de Meta Dia";
			$email->mensagem = "GESTORES COMO FECHAMOS O NOSSO DIA ? NOSSOS VENDEDORES FECHARAM O DIA COM A META ALMEJADA ? LEMBREM SE SE BATERMOS AS NOSSAS METAS DIA , O RESULTADO FLUI NATURALMENTE E ENTREGAMOS A META DO M�S.";
			$email->situacao = 'P';
			$apiEmail = new apiEmail();
			$apiRotinausuario = new apiRotinausuario();
			$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
			foreach ($result as $rs) {
				$email->destinatario = $rs->EMAIL;
				$sql[$i] = $apiEmail->addEmail($email);
				$i = $i + 1;
			}
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao = date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$apiAgendarotina = new apiAgendarotina();
			$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina60(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 60 && $validacao == md5($rotina.date("dmY"))) {
			$sql = array();
			$i = 0;
			$email = new Email();
			$email->dta_envio = date('d/m/Y');
			$email->hora_envio = "07:30:00";
			$email->rotina = $rotina;
			$email->remetente = "SisMonaco - Aviso Semanal 07:00";
			$email->assunto = "Mala Direta Pe�as Promo��o";
			$email->mensagem =  "ENVIO DE MALA DIRETA DE PE�AS PROMOCIONAL PARA OS CLIENTES!";
			$email->situacao = 'P';
			$apiEmail = new apiEmail();
			$apiRotinausuario = new apiRotinausuario();
			$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
			foreach ($result as $rs) {
				$email->destinatario = $rs->EMAIL;
				$sql[$i] = $apiEmail->addEmail($email);
				$i = $i + 1;
			}
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao = date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$apiAgendarotina = new apiAgendarotina();
			$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina35(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 35 && $validacao == md5($rotina.date("dmY"))) {
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getCoaf();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('K1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('L1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('M1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('N1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('O1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('P1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Q1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('R1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('S1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('T1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('U1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('V1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('W1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', "EMPRESA")
			->setCellValue('B1', "REVENDA")
			->setCellValue("C1", "CLIENTE")
			->setCellValue("D1", "NOME" )
			->setCellValue("E1", "FISJUR")
			->setCellValue('F1', "IDENTIDADE")
			->setCellValue('G1', "ORGAO_EXPEDIDOR_ID")
			->setCellValue("H1", "CGCCPF")
			->setCellValue("I1", "LOGRADOURO_ENTREGA")
			->setCellValue("J1", "CEP_ENTREGA")
			->setCellValue("K1", "BAIRRO_ENTREGA")
			->setCellValue("L1", "MUNICIPIO_ENTREGA")
			->setCellValue('M1', 'UF_ENTREGA')
			->setCellValue('N1', "OPERACAO")
			->setCellValue("O1", "VALOR_OPERACAO")
			->setCellValue("P1", "TIPO" )
			->setCellValue("Q1", "CAIXA" )
			->setCellValue('R1', 'HISTORICO')
			->setCellValue('S1', "PESSOA_POLITICAMENTE_EXPOSTA")
			->setCellValue("T1", "ORIGEM")
			->setCellValue("U1", "DES_ORIGEM")
			->setCellValue("V1", "DTA_EMISSAO")
			->setCellValue("W1", "PAGAR_RECEBER");
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(40);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getStyle('H')->getNumberFormat()->setFormatCode('0');
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('M')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(40);
			$objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('T')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('U')->setWidth(25);
			$objPHPExcel->getActiveSheet()->getColumnDimension('V')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('W')->setWidth(15);
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->CLIENTE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, utf8_encode($rs->NOME));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->FISJUR);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->IDENTIDADE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $rs->ORGAO_EXPEDIDOR_ID);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $rs->CGCCPF);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, utf8_encode($rs->LOGRADOURO_ENTREGA));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, utf8_encode($rs->CEP_ENTREGA));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, utf8_encode($rs->BAIRRO_ENTREGA));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $i, utf8_encode($rs->MUNICIPIO_ENTREGA));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $i, $rs->UF_ENTREGA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $i, $rs->OPERACAO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $i, str_replace(",", ".", $rs->VALOR_OPERACAO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(15, $i, $rs->TIPO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(16, $i, $rs->CAIXA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(17, $i, utf8_encode($rs->HISTORICO));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(18, $i, $rs->PESSOA_POLITICAMENTE_EXPOSTA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(19, $i, $rs->ORIGEM);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(20, $i, utf8_encode($rs->DES_ORIGEM));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(21, $i, $rs->DTA_EMISSAO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(22, $i, $rs->PAGAR_RECEBER);
			}
			
			$objPHPExcel->getActiveSheet()->setTitle(utf8_encode("COAF Di�rio"));
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "COAF-".date("d-m-Y");
			$objWriter->save($_SERVER["DOCUMENT_ROOT"] ."/". RAIZ_PATH."dados/anexo/{$nome_arquivo}.xlsx");
			
			$sql = array();
			$i = 0;
			$email = new Email();
			$email->dta_envio = date('d/m/Y');
			$email->hora_envio = "07:50:00";
			$email->rotina = $rotina;
			$email->remetente = "SisMonaco - COAF Di�rio ".date('d/m/Y');
			$email->assunto = "COAF do Dia ".date('d/m/Y');
			$email->mensagem = "Segue em anexo o relat�rio de COAF Di�rio" ;
			$email->anexo = "dados/anexo/{$nome_arquivo}.xlsx";
			$email->situacao = 'P';
			$apiEmail = new apiEmail();
			$apiRotinausuario = new apiRotinausuario();
			$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
			foreach ($result as $rs) {
				$email->destinatario = $rs->EMAIL;
				$sql[$i] = $apiEmail->addEmail($email);
				$i = $i + 1;
			}
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao = date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	public function rotina61(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 61 && $validacao == md5($rotina.date("dmY"))) {
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getTransf();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('K1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('L1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('M1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('N1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('O1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('P1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Q1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'EMPRESA' )
			->setCellValue('B1', "REVENDA" )
			->setCellValue("C1", "VEICULO" )
			->setCellValue("D1", "CHASSI" )
			->setCellValue("E1", "SITUACAO" )
			->setCellValue("F1", "DES_MODELO" )
			->setCellValue("G1", "NUMERO_NOTA_FISCAL" )
			->setCellValue("H1", "SERIE_NOTA_FISCAL" )
			->setCellValue("I1", "TIPO_TRANSACAO" )
			->setCellValue("J1", "DTA_DOCUMENTO" )
			->setCellValue("K1", "STATUS" )
			->setCellValue("L1", "CLIENTE" )
			->setCellValue("M1", "REVENDA_DESTINO" )
			->setCellValue("N1", "MUNICIPIO_DESTINO" )
			->setCellValue("O1", "USUARIO" )
			->setCellValue("P1", "TOT_MERCADORIA" )
			->setCellValue("Q1", "TOT_NOTA_FISCAL" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(40);
			$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(35);
			$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getStyle('P')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getStyle('Q')->getNumberFormat()->setFormatCode('#,##0.00');
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->VEICULO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->CHASSI);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->SITUACAO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->DES_MODELO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $rs->NUMERO_NOTA_FISCAL);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $rs->SERIE_NOTA_FISCAL);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, $rs->TIPO_TRANSACAO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, $rs->DTA_DOCUMENTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, $rs->STATUS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $i, $rs->CLIENTE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $i, $rs->REVENDA_DESTINO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $i, $rs->MUNICIPIO_DESTINO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $i, $rs->USUARIO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(15, $i, str_replace(",", ".", $rs->TOT_MERCADORIA),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(16, $i, str_replace(",", ".", $rs->TOT_NOTA_FISCAL),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Veiculos em TF');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "TF-Dia-".date("d-m-Y");
			$objWriter->save($_SERVER["DOCUMENT_ROOT"] ."/". RAIZ_PATH."dados/anexo/{$nome_arquivo}.xlsx");
			
			$sql = array();
			$i = 0;
			$email = new Email();
			$email->dta_envio = date('d/m/Y');
			$email->hora_envio = "06:50:00";
			$email->rotina = $rotina;
			$email->remetente = "SisMonaco - TF Dia ".date('d/m/Y');
			$email->assunto = "Veiculos TF Dia ".date('d/m/Y');
			$email->mensagem = "Segue em anexo o relat�rio de veiculos em tf" ;
			$email->anexo = "dados/anexo/{$nome_arquivo}.xlsx";
			$email->situacao = 'P';
			$apiEmail = new apiEmail();
			$apiRotinausuario = new apiRotinausuario();
			$email->destinatario = "transf@grupomonaco.com.br";
			$sql[$i] = $apiEmail->addEmail($email);
			$i = $i + 1;
			$email->destinatario = "logistica@grupomonaco.com.br";
			$sql[$i] = $apiEmail->addEmail($email);
			$i = $i + 1;
			$email->destinatario = "logistica.cap@grupomonaco.com.br";
			$sql[$i] = $apiEmail->addEmail($email);
			$i = $i + 1;
			
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao = date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	public function rotina70(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 70 && $validacao == md5($rotina.date("dmY"))) {
			$data = date('d/m/Y');
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getPosicaoos("1,11");
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('K1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('L1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('M1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('N1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('O1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('P1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Q1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('R1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('S1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('T1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('U1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('V1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('W1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('X1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Y1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Z1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AA1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AB1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'EMPRESA' )
			->setCellValue('B1', "REVENDA" )
			->setCellValue("C1", "NRO_OS" )
			->setCellValue("D1", "DTA_EMISSAO" )
			->setCellValue("E1", "SITUACAO_OS" )
			->setCellValue("F1", "SITUACAO_LANCAMENTO" )
			->setCellValue("G1", "CONTATO" )
			->setCellValue("H1", "VENDEDOR" )
			->setCellValue("I1", "NOME_VENDEDOR" )
			->setCellValue("J1", "PLACA" )
			->setCellValue("K1", "MODELO" )
			->setCellValue("L1", "DEPARTAMENTO" )
			->setCellValue("M1", "CHASSI" )
			->setCellValue("N1", "NOME_DEPARTAMENTO" )
			->setCellValue("O1", "CLIENTE" )
			->setCellValue("P1", "NOME_CLIENTE" )
			->setCellValue("Q1", "FISJUR" )
			->setCellValue("R1", "CATEGORIA_OS" )
			->setCellValue("S1", "DEPARTAMENTO_DEBITO" )
			->setCellValue("T1", "NOME_DEPARTAMENTO_DEBITO" )
			->setCellValue("U1", "NOME_CATEGORIA" )
			->setCellValue("V1", "VAL_TOTAL_PECAS" )
			->setCellValue("W1", "VAL_TOTAL_SERVICOS" )
			->setCellValue("X1", "VAL_TOTAL_OS" )
			->setCellValue("Y1", "KILOMETRAGEM" )
			->setCellValue("Z1", "MARCA" )
			->setCellValue("AA1", "DTA_VENDA" )
			->setCellValue("AB1", "DIAS_ABERTO" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('T')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('U')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('V')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('V')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('W')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('W')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('X')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('X')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('Y')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('Y')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('Z')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('AA')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('AB')->setWidth(10);
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->NRO_OS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->DTA_EMISSAO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->SITUACAO_OS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->SITUACAO_LANCAMENTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $rs->CONTATO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $rs->VENDEDOR);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, $rs->NOME_VENDEDOR);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, $rs->PLACA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, $rs->MODELO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $i, $rs->DEPARTAMENTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $i, $rs->CHASSI);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $i, $rs->NOME_DEPARTAMENTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $i, $rs->CLIENTE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(15, $i, $rs->NOME_CLIENTE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(16, $i, $rs->FISJUR);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(17, $i, $rs->CATEGORIA_OS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(18, $i, $rs->DEPARTAMENTO_DEBITO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(19, $i, $rs->NOME_DEPARTAMENTO_DEBITO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(20, $i, $rs->NOME_CATEGORIA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(21, $i, str_replace(",", ".", $rs->VAL_TOTAL_PECAS),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(22, $i, str_replace(",", ".", $rs->VAL_TOTAL_SERVICOS),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(23, $i, str_replace(",", ".", $rs->VAL_TOTAL_OS),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(24, $i, str_replace(",", ".", $rs->KILOMETRAGEM),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(25, $i, $rs->MARCA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(26, $i, $rs->DTA_VENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(27, $i, $rs->DIAS_ABERTO);
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Posicao de OS Abertas');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "Posicao-de-OS-".date("d-m-Y");
			$objWriter->save($nome_arquivo.".xlsx");
			
			$de  = "SisMonaco - Posi��o de OS {$data}";
			$assunto   = "OSs em Aberto at� hoje: {$data}";
			$mensagem  = "Em Anexo todas as O.S em aberto" ;
			
			$para = array();
			$a = 0;
			$apiRotinausuario = new apiRotinausuario();
			$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
			foreach ($result as $rs) {
				$para[$a] = "{$rs->EMAIL}";
				$a = $a + 1;
			}
			$Envio = new EnvioEmail();
			if($Envio->Envio($de, $assunto, $mensagem, $para, "", "{$nome_arquivo}.xlsx") == "sucesso") {
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = $data;
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina71(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 71 && $validacao == md5($rotina.date("dmY"))) {
			$funcoes = new Funcoes();
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getSaldobanco();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'EMPRESA' )
			->setCellValue('B1', "REVENDA" )
			->setCellValue("C1", "VAL_SALDO" )
			->setCellValue("D1", "DTA_REFERENCIA" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('C')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(15);
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, number_format(str_replace(",", ".", $rs->VAL_SALDO), 2, ",", "."),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->DTA_REFERENCIA);
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Saldo Banco');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "Saldo-Banco-".date("d-m-Y");
			$objWriter->save($nome_arquivo.".xlsx");
			
			$ssh = new ServidorArquivo();
			
			if ($ssh->MandaArquivo('relatorio', $nome_arquivo.".xlsx") == 'sucesso'){
				$sql = array();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina72(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 72 && $validacao == md5($rotina.date("dmY"))) {
			$data = date('d/m/Y');
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getMotosfidc();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('K1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'EMPRESA' )
			->setCellValue('B1', "REVENDA" )
			->setCellValue("C1", "VEICULO" )
			->setCellValue("D1", "CHASSI" )
			->setCellValue("E1", "SITUACAO" )
			->setCellValue("F1", "MODELO" )
			->setCellValue("G1", "DTA_FAT_FABRICA" )
			->setCellValue("H1", "DTA_VENCIMENTO_FISCAL" )
			->setCellValue("I1", "DTA_EMISSAO_PROPOSTA" )
			->setCellValue("J1", "DTA_PROV_PAGAMENTO" )
			->setCellValue("K1", "PAG_FIDC" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(19);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(18);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(12);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(12);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(12);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(12);
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(12);
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA_ORIGEM);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->VEICULO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->CHASSI);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->SITUACAO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->MODELO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $rs->DTA_FAT_FABRICA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $rs->DTA_VENCIMENTO_FISCAL);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, $rs->DTA_EMISSAO_PROPOSTA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, $rs->DTA_PROV_PAGAMENTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, $rs->PAG_FIDC);
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Motos FIDC');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "Fidc-".date("d-m-Y");
			$objWriter->save($nome_arquivo.".xlsx");
			
			$de  = "SisMonaco - Motos Fidc {$data}";
			$assunto   = "Rela��o de Motos FIDC: {$data}";
			$mensagem  = "Em Anexo o relat�rio" ;
			
			$para = array();
			$a = 0;
			$apiRotinausuario = new apiRotinausuario();
			$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
			foreach ($result as $rs) {
				$para[$a] = "{$rs->EMAIL}";
				$a = $a + 1;
			}
			$Envio = new EnvioEmail();
			if($Envio->Envio($de, $assunto, $mensagem, $para, "", "{$nome_arquivo}.xlsx") == "sucesso") {
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = $data;
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina75(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 75 && $validacao == md5($rotina.date("dmY"))) {
			$data = date('d/m/Y');
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getComprasobsoleto();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('K1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'EMPRESA' )
			->setCellValue('B1', "REVENDA" )
			->setCellValue("C1", "NF" )
			->setCellValue("D1", "SERIE" )
			->setCellValue("E1", "TRANSACAO" )
			->setCellValue("F1", "CALSS_ABC" )
			->setCellValue("G1", "ITEM_ESTOQUE" )
			->setCellValue("H1", "ITEM_ESTOQUE_PUB" )
			->setCellValue("I1", "DTA_ENTRADA" )
			->setCellValue("J1", "DTA_ULTIMA_SAIDA" )
			->setCellValue("K1", "DES_ITEM_ESTOQUE" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(25);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(13);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(13);
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(25);
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->NUMERO_NOTA_FISCAL);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->SERIE_NOTA_FISCAL);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->TIPO_TRANSACAO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->CLASS_ABC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $rs->ITEM_ESTOQUE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $rs->ITEM_ESTOQUE_PUB);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, $rs->DTA_ENTRADA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, $rs->DTA_ULTIMA_SAIDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, $rs->DES_ITEM_ESTOQUE);

			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Obsoleto de ontem');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "Obsoleto-".date("d-m-Y");
			$objWriter->save($nome_arquivo.".xlsx");
			
			$de  = "SisMonaco - Itens Obsoleto {$data}";
			$assunto   = "Obsoletos de ontem: {$data}";
			$mensagem  = "Em Anexo todos obsoletos do dia anterior" ;
			
			$para = array();
			$para[0] = "centraldecompras@grupomonaco.com.br";
			$Envio = new EnvioEmail();
			if($Envio->Envio($de, $assunto, $mensagem, $para, "", "{$nome_arquivo}.xlsx") == "sucesso") {
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = $data;
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina76(){

		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 76 && $validacao == md5($rotina.date("dmY"))) {
		$data = date('d/m/Y');
		$apiAgendarotina = new apiAgendarotina();
		$result = $apiAgendarotina->titulosGarantia();	
		$objPHPExcel = new \PHPExcel();
		
		$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('K1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('L1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('M1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('N1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('O1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('P1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('Q1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('R1')->getFont()->setBold(true);
		$objPHPExcel->getActiveSheet()->getStyle('S1')->getFont()->setBold(true);


		$objPHPExcel->setActiveSheetIndex(0)
		->setCellValue('A1', 'EMPRESA' )
		->setCellValue('B1', "REVENDA" )
		->setCellValue("C1", "TITULO" )
		->setCellValue("D1", "DUPLICATA" )
		->setCellValue("E1", "DTA_EMISSAO" )
		->setCellValue("F1", "DTA_VENCIMENTO" )
		->setCellValue("G1", "STATUS" )
		->setCellValue("H1", "VAL_TITULO" )
		->setCellValue("I1", "PAGAMENTO" )
		->setCellValue("J1", "SALDO" )
		->setCellValue("K1", "DTA_PAGAMENTO" )
		->setCellValue("L1", "TIPO_OS" )
		->setCellValue("M1", "TIPO_SERVICO" )
		->setCellValue("N1", "N_OS" )
		->setCellValue("O1", "ORIGEM" )
		->setCellValue("P1", "DES_ORIGEM" )
		->setCellValue("Q1", "DTA_EMISSAO_OS" )
		->setCellValue("R1", "DTA_TRANSMISSAO_GARANTIA" )
		->setCellValue("S1", "DTA_TRANSMISSAO_REVISAO" )
		->setCellValue("T1", "SITUACAO_OS" );
		
		$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(13);
		$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(15);
		$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(20);
		$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(10);
		$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(25);
		$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(13);
		$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(20);
		$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(25);
		$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(25);
		$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(25);
		$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(25);
		$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(25);
		$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth(30);
		$objPHPExcel->getActiveSheet()->getColumnDimension('T')->setWidth(25);

		
		$i = 1;
		foreach ($result as $rs){
			$i = $i + 1;
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->TITULO);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->DUPLICATA);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->DTA_EMISSAO);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->DTA_VENCIMENTO);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $rs->STATUS);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, str_replace(",", ".", $rs->VAL_TITULO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, $rs->PAGAMENTO);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, str_replace(",", ".", $rs->SALDO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, $rs->DTA_PAGAMENTO);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $i, $rs->TIPO_OS);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $i, $rs->TIPO_SERVICO);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $i, $rs->N_OS);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $i, $rs->ORIGEM);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(15, $i, utf8_encode($rs->DES_ORIGEM));
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(16, $i, $rs->DTA_EMISSAO_OS);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(17, $i, $rs->DTA_TRANSMISSAO_GARANTIA);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(18, $i, $rs->DTA_TRANSMISSAO_REVISAO);
			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(19, $i, utf8_encode($rs->SITUACAO_OS));			
		}
		$objPHPExcel->getActiveSheet()->setTitle('Titulos e Garantias');
		
		$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
		
		$nome_arquivo = "TitulosGarantias-".date("d-m-Y");
		$objWriter->save($nome_arquivo.".xlsx");
		
		$de  = "SisMonaco - Titulos e Garantia {$data}";
		$assunto   = "Titulos e Garantia: {$data}";
		$mensagem  = "Em Anexo relat�rios de Titulos e Garantias" ;
	
		$para = array();
		$para[0] = "ryannmesquita@grupomonaco.com.br";
		$para[1] = "daisy.slz@grupomonaco.com.br";
		$Envio = new EnvioEmail();
		if($Envio->Envio($de, $assunto, $mensagem, $para, "", "{$nome_arquivo}.xlsx") == "sucesso") {
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao = $data;
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}else{
			$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
			header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
			die();
		}
		}
		
	}
	
	
 	public function rotina78(){
 		$rotina = $this->getParams(0);
 		$validacao = $this->getParams(1);
 		if ($rotina == 76 && $validacao == md5($rotina.date("dmY"))) {
 	
 		$data = date('d/m/Y');
 		$apiAgendarotina = new apiAgendarotina();
 		$result = $apiAgendarotina->osemabertarevisao();
 		
 		$objPHPExcel = new \PHPExcel();
 		
 		$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
 		$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
 		$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
 		$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
 		$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
 		$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
 		$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
	
 		
 		$objPHPExcel->setActiveSheetIndex(0)
 		->setCellValue('A1', 'EMPRESA' )
 		->setCellValue('B1', "REVENDA" )
 		->setCellValue("C1", "NRO_OS" )
 		->setCellValue("D1", "DTA_EMISSAO_OS" )
 		->setCellValue("E1", "DTA_TRANSMISSAO_OS" )
 		->setCellValue("F1", "DTA_CONCLUSAO_OS" )
 		->setCellValue("G1", "SITUACAO_OS" );

 		
 		$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
 		$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
 		$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
 		$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(18);
 		$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(18);
 		$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(22);
 		$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(15);	
 		
 		$i = 1;
 		foreach ($result as $rs){
 			$i = $i + 1;
 			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
 			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA);
 			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->NRO_OS);
 			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->DTA_EMISSAO_OS);
 			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->DTA_TRANSMISSAO_OS);
 			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->DTA_CONCLUSAO_OS);
 			$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $rs->SITUACAO_OS);

 		}
 		
 		
 		$objPHPExcel->getActiveSheet()->setTitle('Os em Aberta de Revisao ');
 		
 		$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
 		
 		$nome_arquivo = "OsAbertaRevisao-".date("d-m-Y");
 		$objWriter->save($nome_arquivo.".xlsx");
 		
 		$de  = "SisMonaco - Os em Aberta de Revis�o {$data}";
 		$assunto   = "Os em Aberta de Revis�o: {$data}";
 		$mensagem  = "Em Anexo Os em Aberta de Revis�o" ;
 		
 		$para = array();
 		$para[0] = "ryannmesquita@grupomonaco.com.br";
 		$para[1] = "daisy.slz@grupomonaco.com.br";
 		$Envio = new EnvioEmail();
 		if($Envio->Envio($de, $assunto, $mensagem, $para, "", "{$nome_arquivo}.xlsx") == "sucesso") {
 			$agendarotina = new Agendarotina();
 			$agendarotina->rotina = $rotina;
 			$agendarotina->dta_ult_execucao = $data;
 			$agendarotina->hora_ult_execucao = date('H:i:s');
 			$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
 			$rs = $apiAgendarotina->executeSQL($sql);
 			if ($rs[4] == "sucesso"){
 				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
 				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
 				die();
 			}else{
 				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
 				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
 				die();
 			}
 		}else{
 			$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
 			header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
 			die();
 		}
 		}
 		
 	}
	
	
	//***********************************************Rotinas Quinzenais************************************************
	
	public function rotina53(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 53 && $validacao == md5($rotina.date("dmY"))) {
			$sql = array();
			$i = 0;
			$email = new Email();
			$email->dta_envio = date('d/m/Y');
			$email->hora_envio = "09:50:00";
			$email->rotina = $rotina;
			$email->remetente = "SisMonaco - Aviso Quinzenal 10:00";
			$email->assunto = "Reuni�o Sobre Inadipl�ncia";
			$email->mensagem = "GESTORES VEJAM E MOSTRE A NOSSAS EQUIPES NOSSA INADIMPL�NCIA , AFINAL SE EST� EST� ACIMA DO TOLER�VEL , SOMOS PENALIZADOS EM NOSSO LUCRO LIQUIDO E DIFICULTA FUTURAS LIBERA��ES , REFOR�EM ISSO COM O NOSSO TIME.";
			$email->situacao = 'P';
			$apiEmail = new apiEmail();
			$apiRotinausuario = new apiRotinausuario();
			$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
			foreach ($result as $rs) {
				$email->destinatario = $rs->EMAIL;
				$sql[$i] = $apiEmail->addEmail($email);
				$i = $i + 1;
			}
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao = date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$apiAgendarotina = new apiAgendarotina();
			$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	//***********************************************Rotinas Mensais************************************************
	
	public function rotina1(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 1 && $validacao == md5($rotina.date("dmY"))) {
			$funcoes = new Funcoes();
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getAprovacaocredito();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('K1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('L1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('M1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('N1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('O1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('P1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Q1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('R1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'Empresa' )
			->setCellValue('B1', "Revenda" )
			->setCellValue("C1", "Contato" )
			->setCellValue("D1", "Data de Entrada e Saida" )
			->setCellValue("E1", "Numero Nota Fiscal" )
			->setCellValue("F1", "Serie" )
			->setCellValue("G1", "Transacao" )
			->setCellValue("H1", "Cliente" )
			->setCellValue("I1", "Nome" )
			->setCellValue("J1", "Valor" )
			->setCellValue("K1", "Funcao" )
			->setCellValue("L1", "Descricao da Funcao" )
			->setCellValue("M1", "Solicitante" )
			->setCellValue("N1", "Nome do Solicitante" )
			->setCellValue("O1", "Aprovador" )
			->setCellValue("P1", "Nome do Aprovador" )
			->setCellValue("Q1", "Valor Solicitado" )
			->setCellValue("R1", "Valor Aprovado" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('J')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('Q')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('R')->getNumberFormat()->setFormatCode('#,##0.00');
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->CONTATO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->DTA_ENTRADA_SAIDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->NUMERO_NOTA_FISCAL);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->SERIE_NOTA_FISCAL);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $rs->TIPO_TRANSACAO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $rs->CLIENTE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, $rs->NOME);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, str_replace(",", ".", $rs->VALOR),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, $rs->FUNCAO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $i, $funcoes->retiraAcentos($rs->DES_FUNCAO));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $i, $rs->USUARIO_SOLIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $i, $rs->NOME_USUARIO_SOLIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $i, $rs->USUARIO_APROV);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(15, $i, $rs->NOME_USUARIO_APROV);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(16, $i, str_replace(",", ".", $rs->VAL_SOLICITADO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(17, $i, str_replace(",", ".", $rs->VAL_APROVADO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Aprovacoes de Credito');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "Aprovacoes-".date("d-m-Y");
			$objWriter->save($nome_arquivo.".xlsx");
			
			$ssh = new ServidorArquivo();
			
			if ($ssh->MandaArquivo('relatorio', $nome_arquivo.".xlsx") == 'sucesso'){
				$sql = array();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina2(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 2 && $validacao == md5($rotina.date("dmY"))) {
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getPosicaoos("1,2,3,4,5,6,7,8,9,10,11,12,13");
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('K1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('L1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('M1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('N1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('O1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('P1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Q1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('R1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('S1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('T1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('U1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('V1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('W1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('X1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Y1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Z1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AA1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AB1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'EMPRESA' )
			->setCellValue('B1', "REVENDA" )
			->setCellValue("C1", "NRO_OS" )
			->setCellValue("D1", "DTA_EMISSAO" )
			->setCellValue("E1", "SITUACAO_OS" )
			->setCellValue("F1", "SITUACAO_LANCAMENTO" )
			->setCellValue("G1", "CONTATO" )
			->setCellValue("H1", "VENDEDOR" )
			->setCellValue("I1", "NOME_VENDEDOR" )
			->setCellValue("J1", "PLACA" )
			->setCellValue("K1", "MODELO" )
			->setCellValue("L1", "DEPARTAMENTO" )
			->setCellValue("M1", "CHASSI" )
			->setCellValue("N1", "NOME_DEPARTAMENTO" )
			->setCellValue("O1", "CLIENTE" )
			->setCellValue("P1", "NOME_CLIENTE" )
			->setCellValue("Q1", "FISJUR" )
			->setCellValue("R1", "CATEGORIA_OS" )
			->setCellValue("S1", "DEPARTAMENTO_DEBITO" )
			->setCellValue("T1", "NOME_DEPARTAMENTO_DEBITO" )
			->setCellValue("U1", "NOME_CATEGORIA" )
			->setCellValue("V1", "VAL_TOTAL_PECAS" )
			->setCellValue("W1", "VAL_TOTAL_SERVICOS" )
			->setCellValue("X1", "VAL_TOTAL_OS" )
			->setCellValue("Y1", "KILOMETRAGEM" )
			->setCellValue("Z1", "MARCA" )
			->setCellValue("AA1", "DTA_VENDA" )
			->setCellValue("AB1", "DIAS_ABERTO" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('T')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('U')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('V')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('V')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('W')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('W')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('X')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('X')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('Y')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('Y')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('Z')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('AA')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('AB')->setWidth(10);
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->NRO_OS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->DTA_EMISSAO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->SITUACAO_OS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->SITUACAO_LANCAMENTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $rs->CONTATO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $rs->VENDEDOR);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, $rs->NOME_VENDEDOR);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, $rs->PLACA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, $rs->MODELO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $i, $rs->DEPARTAMENTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $i, $rs->CHASSI);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $i, $rs->NOME_DEPARTAMENTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $i, $rs->CLIENTE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(15, $i, $rs->NOME_CLIENTE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(16, $i, $rs->FISJUR);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(17, $i, $rs->CATEGORIA_OS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(18, $i, $rs->DEPARTAMENTO_DEBITO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(19, $i, $rs->NOME_DEPARTAMENTO_DEBITO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(20, $i, $rs->NOME_CATEGORIA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(21, $i, str_replace(",", ".", $rs->VAL_TOTAL_PECAS),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(22, $i, str_replace(",", ".", $rs->VAL_TOTAL_SERVICOS),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(23, $i, str_replace(",", ".", $rs->VAL_TOTAL_OS),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(24, $i, str_replace(",", ".", $rs->KILOMETRAGEM),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(25, $i, $rs->MARCA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(26, $i, $rs->DTA_VENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(27, $i, $rs->DIAS_ABERTO);
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Posicao de OS Abertas');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "Posicao-de-OS-".date("d-m-Y");
			$objWriter->save($nome_arquivo.".xlsx");
			
			$ssh = new ServidorArquivo();
			
			if ($ssh->MandaArquivo('relatorio', $nome_arquivo.".xlsx") == 'sucesso'){
				$sql = array();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina3(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 3 && $validacao == md5($rotina.date("dmY"))) {
			$funcoes = new Funcoes();
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getEstoque180();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('K1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('L1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('M1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('N1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('O1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('P1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Q1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('R1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('S1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('T1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('U1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('V1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('W1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('X1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Y1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Z1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AA1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AB1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AC1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'EMPRESA' )
			->setCellValue('B1', "REVENDA" )
			->setCellValue("C1", "ITEM_ESTOQUE" )
			->setCellValue("D1", "ITEM_ESTOQUE_PUB" )
			->setCellValue("E1", "DES_ITEM_ESTOQUE" )
			->setCellValue("F1", "CLASS_ABC" )
			->setCellValue("G1", "CLASS_XYZ" )
			->setCellValue("H1", "QTD_CONTABIL" )
			->setCellValue("I1", "DTA_SAIDA" )
			->setCellValue("J1", "DTA_ULT_ENTRADA" )
			->setCellValue("K1", "QTD_ULT_ENTRADA" )
			->setCellValue("L1", "BASE_PIS" )
			->setCellValue("M1", "BASE_COFINS" )
			->setCellValue("N1", "LOCACAO" )
			->setCellValue("O1", "CUSTO_MEDIO" )
			->setCellValue("P1", "VAL_ESTOQUE" )
			->setCellValue("Q1", "NOME_GRUPO" )
			->setCellValue("R1", "GRUPO" )
			->setCellValue("S1", "NOME_CATEGORIA" )
			->setCellValue("T1", "CATEGORIA" )
			->setCellValue("U1", "PCT_DESCONTO" )
			->setCellValue("V1", "GRUPO_DESCONTO" )
			->setCellValue("W1", "ALIQUOTA_IPI" )
			->setCellValue("X1", "PRECO_ALTERNATIVO" )
			->setCellValue("Y1", "DEMANDA_MEDIA" )
			->setCellValue("Z1", "INCIDE_PIS_COFINS" )
			->setCellValue("AA1", "PRECO_PUBLICO_ATUAL" )
			->setCellValue("AB1", "CUSTO_REPOS" )
			->setCellValue("AC1", "DIAS" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('O')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getStyle('P')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('T')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('U')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('V')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('W')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('X')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('X')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('Y')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('Z')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('AA')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('AA')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('AB')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('AB')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('AC')->setWidth(10);
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->ITEM_ESTOQUE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, utf8_encode($rs->ITEM_ESTOQUE_PUB));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, utf8_encode($rs->DES_ITEM_ESTOQUE));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->CLASS_ABC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $rs->CLASS_XYZ);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $rs->QTD_CONTABIL);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, $rs->DTA_SAIDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, $rs->DTA_ULT_ENTRADA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, $rs->QTD_ULT_ENTRADA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $i, $rs->BASE_PIS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $i, $rs->BASE_COFINS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $i, utf8_encode($rs->LOCACAO));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $i, number_format(str_replace(",", ".", $rs->CUSTO_MEDIO), 2, ",", "."),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(15, $i, number_format(str_replace(",", ".", $rs->VAL_ESTOQUE), 2, ",", "."),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(16, $i, utf8_encode($rs->NOME_GRUPO));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(17, $i, $rs->GRUPO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(18, $i, utf8_encode($rs->NOME_CATEGORIA));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(19, $i, $rs->CATEGORIA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(20, $i, $rs->PCT_DESCONTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(21, $i, $rs->GRUPO_DESCONTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(22, $i, $rs->ALIQUOTA_IPI);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(23, $i, number_format(str_replace(",", ".", $rs->PRECO_ALTERNATIVO), 2, ",", "."),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(24, $i, $rs->DEMANDA_MEDIA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(25, $i, $rs->INCIDE_PIS_COFINS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(26, $i, number_format(str_replace(",", ".", $rs->PRECO_PUBLICO_ATUAL), 2, ",", "."),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(27, $i, number_format(str_replace(",", ".", $rs->CUSTO_REPOS), 2, ",", "."),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(28, $i, $rs->DIAS);
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Estoque 180 Dias');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "Estoque-180-Dias-".date("d-m-Y");
			$objWriter->save($nome_arquivo.".xlsx");
			
			$ssh = new ServidorArquivo();
			
			if ($ssh->MandaArquivo('relatorio', $nome_arquivo.".xlsx") == 'sucesso'){
				$sql = array();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina4(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 4 && $validacao == md5($rotina.date("dmY"))) {
			$funcoes = new Funcoes();
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getEstoque360();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('K1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('L1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('M1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('N1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('O1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('P1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Q1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('R1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('S1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('T1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('U1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('V1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('W1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('X1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Y1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Z1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AA1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AB1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('AC1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'EMPRESA' )
			->setCellValue('B1', "REVENDA" )
			->setCellValue("C1", "ITEM_ESTOQUE" )
			->setCellValue("D1", "ITEM_ESTOQUE_PUB" )
			->setCellValue("E1", "DES_ITEM_ESTOQUE" )
			->setCellValue("F1", "CLASS_ABC" )
			->setCellValue("G1", "CLASS_XYZ" )
			->setCellValue("H1", "QTD_CONTABIL" )
			->setCellValue("I1", "DTA_SAIDA" )
			->setCellValue("J1", "DTA_ULT_ENTRADA" )
			->setCellValue("K1", "QTD_ULT_ENTRADA" )
			->setCellValue("L1", "BASE_PIS" )
			->setCellValue("M1", "BASE_COFINS" )
			->setCellValue("N1", "LOCACAO" )
			->setCellValue("O1", "CUSTO_MEDIO" )
			->setCellValue("P1", "VAL_ESTOQUE" )
			->setCellValue("Q1", "NOME_GRUPO" )
			->setCellValue("R1", "GRUPO" )
			->setCellValue("S1", "NOME_CATEGORIA" )
			->setCellValue("T1", "CATEGORIA" )
			->setCellValue("U1", "PCT_DESCONTO" )
			->setCellValue("V1", "GRUPO_DESCONTO" )
			->setCellValue("W1", "ALIQUOTA_IPI" )
			->setCellValue("X1", "PRECO_ALTERNATIVO" )
			->setCellValue("Y1", "DEMANDA_MEDIA" )
			->setCellValue("Z1", "INCIDE_PIS_COFINS" )
			->setCellValue("AA1", "PRECO_PUBLICO_ATUAL" )
			->setCellValue("AB1", "CUSTO_REPOS" )
			->setCellValue("AC1", "DIAS" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('O')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getStyle('P')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('T')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('U')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('V')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('W')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('X')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('X')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('Y')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('Z')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('AA')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('AA')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('AB')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('AB')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('AC')->setWidth(10);
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->ITEM_ESTOQUE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->ITEM_ESTOQUE_PUB);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $funcoes->retiraAcentos($rs->DES_ITEM_ESTOQUE));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->CLASS_ABC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $rs->CLASS_XYZ);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $rs->QTD_CONTABIL);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, $rs->DTA_SAIDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, $rs->DTA_ULT_ENTRADA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, $rs->QTD_ULT_ENTRADA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $i, $rs->BASE_PIS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $i, $rs->BASE_COFINS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $i, $rs->LOCACAO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $i, str_replace(",", ".", $rs->CUSTO_MEDIO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(15, $i, str_replace(",", ".", $rs->VAL_ESTOQUE),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(16, $i, $funcoes->retiraAcentos($rs->NOME_GRUPO));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(17, $i, $rs->GRUPO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(18, $i, $funcoes->retiraAcentos($rs->NOME_CATEGORIA));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(19, $i, $rs->CATEGORIA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(20, $i, $rs->PCT_DESCONTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(21, $i, $rs->GRUPO_DESCONTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(22, $i, $rs->ALIQUOTA_IPI);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(23, $i, str_replace(",", ".", $rs->PRECO_ALTERNATIVO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(24, $i, $rs->DEMANDA_MEDIA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(25, $i, $rs->INCIDE_PIS_COFINS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(26, $i, str_replace(",", ".", $rs->PRECO_PUBLICO_ATUAL),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(27, $i, str_replace(",", ".", $rs->CUSTO_REPOS),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(28, $i, $rs->DIAS);
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Estoque 360 Dias');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "Estoque-360-Dias-".date("d-m-Y");
			$objWriter->save($nome_arquivo.".xlsx");
			
			$ssh = new ServidorArquivo();
			
			if ($ssh->MandaArquivo('relatorio', $nome_arquivo.".xlsx") == 'sucesso'){
				$sql = array();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina5(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 5 && $validacao == md5($rotina.date("dmY"))) {
			$apiAgendarotina = new apiAgendarotina();
			
			$result = $apiAgendarotina->getVeiculoauditoria();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('K1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('L1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('M1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('N1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('O1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('P1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'EMPRESA' )
			->setCellValue('B1', "REVENDA_ORIGEM" )
			->setCellValue("C1", "NOVO_USADO" )
			->setCellValue("D1", "VEICULO" )
			->setCellValue("E1", "DTA_FAT_FABRICA" )
			->setCellValue("F1", "DTA_ENTRADA" )
			->setCellValue("G1", "CHASSI" )
			->setCellValue("H1", "POSICAO_FISCAL" )
			->setCellValue("I1", "SITUACAO" )
			->setCellValue("J1", "DES_MODELO" )
			->setCellValue("K1", "FORMULA" )
			->setCellValue("L1", "VAL_CUSTO_CONTABIL" )
			->setCellValue("M1", "SITUACAO_PAGAR" )
			->setCellValue("N1", "DADOS" )
			->setCellValue("O1", "DADOS" )
			->setCellValue("P1", "TIPO" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('L')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(10);
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA_ORIGEM);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->NOVO_USADO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->VEICULO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->DTA_FAT_FABRICA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->DTA_ENTRADA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $rs->CHASSI);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $rs->POSICAO_FINAL);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, $rs->SITUACAO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, $rs->DES_MODELO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, $rs->FORMULA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $i, str_replace(",", ".", $rs->VAL_CUSTO_CONTABIL),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $i, $rs->SITUACAO_PAGAR);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $i, $rs->DADOS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $i, $rs->DADOS);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(15, $i, $rs->TIPO);
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Veiculos Auditoria');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "Veiculos-Auditoria-".date("d-m-Y");
			$objWriter->save($nome_arquivo.".xlsx");
			
			$ssh = new ServidorArquivo();
			
			if ($ssh->MandaArquivo('relatorio', $nome_arquivo.".xlsx") == 'sucesso'){
				$sql = array();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina24(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 24 && $validacao == md5($rotina.date("dmY"))) {
			$funcoes = new Funcoes();
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getRelatoriofuncionarios();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'UNIDADE' )
			->setCellValue('B1', "EMPRESA" )
			->setCellValue("C1", "CONTRATO" )
			->setCellValue("D1", "FUNCIONARIO" )
			->setCellValue("E1", "CARGO" )
			->setCellValue("F1", "DEPARTAMENTO" )
			->setCellValue("G1", "CC" )
			->setCellValue("H1", "TOTALCC" )
			->setCellValue("I1", "SALARIOS" )
			->setCellValue("J1", "TOTALUNIDADE" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(5);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(35);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('I')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(10);
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->UNIDADE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, utf8_encode($rs->EMPRESA));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->CONTRATO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, utf8_encode($rs->FUNCIONARIO));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, utf8_encode($rs->CARGO));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, utf8_encode($rs->DEPARTAMENTO));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $rs->CC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $rs->TOTALCC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, str_replace(",", ".", $rs->SALARIOS),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, $rs->TOTALUNIDADE);
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Relatorios de Funcionarios');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "Funcionarios-".date("d-m-Y");
			$objWriter->save($_SERVER["DOCUMENT_ROOT"] ."/". RAIZ_PATH."dados/anexo/{$nome_arquivo}.xlsx");
			
			$sql = array();
			$i = 0;
			$email = new Email();
			$email->dta_envio = date('d/m/Y');
			$email->hora_envio = "07:50:00";
			$email->rotina = $rotina;
			$email->remetente = "SisMonaco - Folha ".date('d/m/Y');
			$email->assunto = "Relatorio de funcionarios ".date('d/m/Y');
			$email->mensagem = "Segue em anexo o relat�rio de funcion�rios fechado do m�s com a soma dos sal�rios e comiss�es por centro de custo." ;
			$email->anexo = "dados/anexo/{$nome_arquivo}.xlsx";
			$email->situacao = 'P';
			$apiEmail = new apiEmail();
			$apiRotinausuario = new apiRotinausuario();
			$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
			foreach ($result as $rs) {
				$email->destinatario = $rs->EMAIL;
				$sql[$i] = $apiEmail->addEmail($email);
				$i = $i + 1;
			}
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao = date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina25(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 25 && $validacao == md5($rotina.date("dmY"))) {
			$funcoes = new Funcoes();
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getResumoporunidade();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', "UNIDADE")
			->setCellValue('B1', "EMPRESA")
			->setCellValue("C1", "DEPARTAMENTO")
			->setCellValue("D1", "CC")
			->setCellValue("E1", "TOTALCC")
			->setCellValue("F1", "TOTALUNIDADE");
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(5);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(35);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(20);
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->UNIDADE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, utf8_encode($rs->EMPRESA));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, utf8_encode($rs->DEPARTAMENTO));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->CC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->TOTALCC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->TOTALUNIDADE);
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Resumo por Unidade');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "Resumo-".date("d-m-Y");
			$objWriter->save($_SERVER["DOCUMENT_ROOT"] ."/". RAIZ_PATH."dados/anexo/{$nome_arquivo}.xlsx");
			
			$sql = array();
			$i = 0;
			$email = new Email();
			$email->dta_envio = date('d/m/Y');
			$email->hora_envio = "07:50:00";
			$email->rotina = $rotina;
			$email->remetente = "SisMonaco - Unidades ".date('d/m/Y');
			$email->assunto = "Resumo por Unidade ".date('d/m/Y');
			$email->mensagem = "Segue em anexo o relat�rio resumido por unidade." ;
			$email->anexo = "dados/anexo/{$nome_arquivo}.xlsx";
			$email->situacao = 'P';
			$apiEmail = new apiEmail();
			$apiRotinausuario = new apiRotinausuario();
			$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
			foreach ($result as $rs) {
				$email->destinatario = $rs->EMAIL;
				$sql[$i] = $apiEmail->addEmail($email);
				$i = $i + 1;
			}
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao = date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina29(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 29 && $validacao == md5($rotina.date("dmY"))) {
			$funcoes = new Funcoes();
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getLancamentosbancarios();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('K1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('L1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('M1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('N1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('O1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('P1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Q1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('R1')->getFont()->setBold(true);
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue("A1", "EMPRESA" )
			->setCellValue("B1", "REVENDA" )
			->setCellValue("C1", "TITULO" )
			->setCellValue("D1", "DUPLICATA" )
			->setCellValue("E1", "CLIENTE" )
			->setCellValue("F1", "TIPO" )
			->setCellValue("G1", "DEPARTAMENTO" )
			->setCellValue("H1", "BANCO" )
			->setCellValue("I1", "USUARIO" )
			->setCellValue("J1", "GRUPO" )
			->setCellValue("K1", "ORIGEM" )
			->setCellValue("L1", "DTA_EMISSAO" )
			->setCellValue("M1", "DTA_VENCIMENTO" )
			->setCellValue("N1", "DTA_CONTABIL" )
			->setCellValue("O1", "HISTORICO" )
			->setCellValue("P1", "VAL_TITULO" )
			->setCellValue("Q1", "PAGAR_RECEBER" )
			->setCellValue("R1", "STATUS" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(5);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(5);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(35);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(7);
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(7);
			$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(50);
			$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('P')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(10);
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->TITULO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->DUPLICATA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->CLIENTE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->TIPO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $rs->DEPARTAMENTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $rs->BANCO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, utf8_encode($rs->NOME));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, $rs->GRUPO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, $rs->ORIGEM);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $i, $rs->DTA_EMISSAO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $i, $rs->DTA_VENCIMENTO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $i, $rs->DTA_CONTABIL);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $i, utf8_encode($rs->HISTORICO));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(15, $i, str_replace(",", ".", $rs->VAL_TITULO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(16, $i, $rs->PAGAR_RECEBER);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(17, $i, $rs->STATUS);
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Lancamentos Bancarios');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "Lancamentos-Bancarios-".date("d-m-Y");
			$objWriter->save($_SERVER["DOCUMENT_ROOT"] ."/". RAIZ_PATH."dados/anexo/{$nome_arquivo}.xlsx");
			
			$sql = array();
			$i = 0;
			$email = new Email();
			$email->dta_envio = date('d/m/Y');
			$email->hora_envio = "07:50:00";
			$email->rotina = $rotina;
			$email->remetente = "SisMonaco - Lancamento Bancario ".date('d/m/Y');
			$email->assunto = "Relatorio de lancamentos bancarios ".date('d/m/Y');
			$email->mensagem = "Segue em anexo o relat�rio de lancamentos bancarios do m�s anterior." ;
			$email->anexo = "dados/anexo/{$nome_arquivo}.xlsx";
			$email->situacao = 'P';
			$apiEmail = new apiEmail();
			$apiRotinausuario = new apiRotinausuario();
			$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
			foreach ($result as $rs) {
				$email->destinatario = $rs->EMAIL;
				$sql[$i] = $apiEmail->addEmail($email);
				$i = $i + 1;
			}
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao = date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina30(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 30 && $validacao == md5($rotina.date("dmY"))) {
			$funcoes = new Funcoes();
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getEstoquecritico();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('K1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('L1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('M1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('N1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('O1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('P1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Q1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('R1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('S1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('T1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('U1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('V1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('W1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('X1')->getFont()->setBold(true);
			
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'EMPRESA' )
			->setCellValue('B1', "REVENDA" )
			->setCellValue("C1", "GRUPO" )
			->setCellValue("D1", "DES_GRUPO" )
			->setCellValue("E1", "ITEM_ESTOQUE" )
			->setCellValue("F1", "ITEM_ESTOQUE_PUB" )
			->setCellValue("G1", "DES_ITEM_ESTOQUE" )
			->setCellValue("H1", "CLASS_ABC" )
			->setCellValue("I1", "CLASS_XYZ" )
			->setCellValue("J1", "QTD_CONTABIL" )
			->setCellValue("K1", "DEMANDA_MEDIA" )
			->setCellValue("L1", "QTD_PEDIDA" )
			->setCellValue("M1", "VAL_ESTOQUE" )
			->setCellValue("N1", "DTA_DO_CADASTRO" )
			->setCellValue("O1", "DTA_SAIDA" )
			->setCellValue("P1", "DTA_ULT_COMPRA" )
			->setCellValue("Q1", "QTD_ULT_COMPRA" )
			->setCellValue("R1", "CUS_ULT_COMPRA" )
			->setCellValue("S1", "ESTOQUE_MEDIO" )
			->setCellValue("T1", "ESTOQUE_MAXIMO" )
			->setCellValue("U1", "ESTOQUE_IDEAL_60_DIAS" )
			->setCellValue("V1", "QTD_CRITICA" )
			->setCellValue("W1", "VALOR_EST_CRITICO" )
			->setCellValue("X1", "VARIACAO_EST_X_DEM" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('K')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getStyle('M')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('R')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('T')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('U')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('U')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('V')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('V')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('W')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('W')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('X')->setWidth(10);
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->GRUPO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i,  $funcoes->retiraAcentos($rs->DES_GRUPO));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->ITEM_ESTOQUE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->ITEM_ESTOQUE_PUB);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i,  $funcoes->retiraAcentos($rs->DES_ITEM_ESTOQUE));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $rs->CLASS_ABC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, $rs->CLASS_XYZ);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, $rs->QTD_CONTABIL);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, str_replace(",", ".", $rs->DEMANDA_MEDIA),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $i, $rs->QTD_PEDIDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $i, str_replace(",", ".", $rs->VAL_ESTOQUE),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $i, $rs->DTA_DO_CADASTRO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $i, $rs->DTA_SAIDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(15, $i, $rs->DTA_ULT_COMPRA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(16, $i, $rs->QTD_ULT_COMPRA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(17, $i, str_replace(",", ".", $rs->CUS_ULT_COMPRA),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(18, $i, $rs->ESTOQUE_MEDIO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(19, $i, $rs->ESTOQUE_MAXIMO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(20, $i, str_replace(",", ".", $rs->ESTOQUE_IDEAL_60_DIAS),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(21, $i, str_replace(",", ".", $rs->QTD_CRITICA),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(22, $i, str_replace(",", ".", $rs->VALOR_EST_CRITICO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(23, $i, $rs->VARIACAO_EST_X_DEM);
				
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Estoque Critico');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "Estoque-Critico-".date("d-m-Y");
			$objWriter->save($nome_arquivo.".xlsx");
			
			$ssh = new ServidorArquivo();
			
			if ($ssh->MandaArquivo('relatorio', $nome_arquivo.".xlsx") == 'sucesso'){
				$sql = array();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina31(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 31 && $validacao == md5($rotina.date("dmY"))) {
			$funcoes = new Funcoes();
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getEstoqueexcesso();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('K1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('L1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('M1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('N1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('O1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('P1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Q1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('R1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('S1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('T1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('U1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('V1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('W1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('X1')->getFont()->setBold(true);
			
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'EMPRESA' )
			->setCellValue('B1', "REVENDA" )
			->setCellValue("C1", "GRUPO" )
			->setCellValue("D1", "DES_GRUPO" )
			->setCellValue("E1", "ITEM_ESTOQUE" )
			->setCellValue("F1", "ITEM_ESTOQUE_PUB" )
			->setCellValue("G1", "DES_ITEM_ESTOQUE" )
			->setCellValue("H1", "CLASS_ABC" )
			->setCellValue("I1", "CLASS_XYZ" )
			->setCellValue("J1", "QTD_CONTABIL" )
			->setCellValue("K1", "DEMANDA_MEDIA" )
			->setCellValue("L1", "QTD_PEDIDA" )
			->setCellValue("M1", "VAL_ESTOQUE" )
			->setCellValue("N1", "DTA_DO_CADASTRO" )
			->setCellValue("O1", "DTA_SAIDA" )
			->setCellValue("P1", "DTA_ULT_COMPRA" )
			->setCellValue("Q1", "QTD_ULT_COMPRA" )
			->setCellValue("R1", "CUS_ULT_COMPRA" )
			->setCellValue("S1", "ESTOQUE_MEDIO" )
			->setCellValue("T1", "ESTOQUE_MAXIMO" )
			->setCellValue("U1", "ESTOQUE_IDEAL_60_DIAS" )
			->setCellValue("V1", "QTD_CRITICA" )
			->setCellValue("W1", "VALOR_EST_CRITICO" )
			->setCellValue("X1", "VARIACAO_EST_X_DEM" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('K')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getStyle('M')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('R')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('T')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('U')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('U')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('V')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('V')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('W')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('W')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('X')->setWidth(10);
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->GRUPO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i,  $funcoes->retiraAcentos($rs->DES_GRUPO));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->ITEM_ESTOQUE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->ITEM_ESTOQUE_PUB);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i,  $funcoes->retiraAcentos($rs->DES_ITEM_ESTOQUE));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $rs->CLASS_ABC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, $rs->CLASS_XYZ);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, $rs->QTD_CONTABIL);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, str_replace(",", ".", $rs->DEMANDA_MEDIA),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $i, $rs->QTD_PEDIDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $i, str_replace(",", ".", $rs->VAL_ESTOQUE),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $i, $rs->DTA_DO_CADASTRO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $i, $rs->DTA_SAIDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(15, $i, $rs->DTA_ULT_COMPRA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(16, $i, $rs->QTD_ULT_COMPRA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(17, $i, str_replace(",", ".", $rs->CUS_ULT_COMPRA),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(18, $i, $rs->ESTOQUE_MEDIO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(19, $i, $rs->ESTOQUE_MAXIMO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(20, $i, str_replace(",", ".", $rs->ESTOQUE_IDEAL_60_DIAS),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(21, $i, str_replace(",", ".", $rs->QTD_CRITICA),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(22, $i, str_replace(",", ".", $rs->VALOR_EST_CRITICO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(23, $i, $rs->VARIACAO_EST_X_DEM);
				
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Estoque Excesso');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "Estoque-Excesso-".date("d-m-Y");
			$objWriter->save($nome_arquivo.".xlsx");
			
			$ssh = new ServidorArquivo();
			
			if ($ssh->MandaArquivo('relatorio', $nome_arquivo.".xlsx") == 'sucesso'){
				$sql = array();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina32(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 32 && $validacao == md5($rotina.date("dmY"))) {
			$funcoes = new Funcoes();
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getVendas300();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('K1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('L1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('M1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('N1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('O1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('P1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Q1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('R1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('S1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('T1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('U1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('V1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('W1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('X1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Y1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Z1')->getFont()->setBold(true);
			
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'EMPRESA' )
			->setCellValue('B1', "REVENDA" )
			->setCellValue("C1", "CLIENTE" )
			->setCellValue("D1", "NOME" )
			->setCellValue("E1", "DES_CATEGORIA_CLIENTE" )
			->setCellValue("F1", "CLASSIFICACAO" )
			->setCellValue("G1", "MUNICIPIO_ENTREGA" )
			->setCellValue("H1", "BAIRRO_ENTREGA" )
			->setCellValue("I1", "DDD_TELEFONE" )
			->setCellValue("J1", "TELEFONE" )
			->setCellValue("K1", "DDD_CELULAR" )
			->setCellValue("L1", "CELULAR" )
			->setCellValue("M1", "E_MAIL_TRABALHO" )
			->setCellValue("N1", "E_MAIL_CASA" )
			->setCellValue("O1", "TOTAL_VENDA" )
			->setCellValue("P1", "TOTAL_DESCONTO" )
			->setCellValue("Q1", "CUSTO_DA_VENDA" )
			->setCellValue("R1", "VALOR_MARGEM" )
			->setCellValue("S1", "MARGEM_PCT" )
			->setCellValue("T1", "PRIMEIRO_MES" )
			->setCellValue("U1", "SEGUNDO_MES" )
			->setCellValue("V1", "TERCEIRO_MES" )
			->setCellValue("W1", "QUARTO_MES" )
			->setCellValue("X1", "QUINTO_MES" )
			->setCellValue("Y1", "SEXTO_MES" )
			->setCellValue("Z1", "MES_ATUAL" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getStyle('O')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('P')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getStyle('Q')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('R')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('S')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('T')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('T')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('U')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('U')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('V')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('V')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('W')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('W')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('X')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('X')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('Y')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('Y')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('Z')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('Z')->getNumberFormat()->setFormatCode('#,##0.00');
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->CLIENTE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $funcoes->retiraAcentos($rs->NOME));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $funcoes->retiraAcentos($rs->DES_CATEGORIA_CLIENTE));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->CLASSIFICACAO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $funcoes->retiraAcentos($rs->MUNICIPIO_ENTREGA));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $funcoes->retiraAcentos($rs->BAIRRO_ENTREGA));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, $rs->DDD_TELEFONE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, $rs->TELEFONE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, $rs->DDD_CELULAR);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $i, $rs->CELULAR);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $i, $funcoes->retiraAcentos($rs->E_MAIL_TRABALHO));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $i, $funcoes->retiraAcentos($rs->E_MAIL_CASA));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $i, str_replace(",", ".", $rs->TOTAL_VENDA),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(15, $i, str_replace(",", ".", $rs->TOTAL_DESCONTO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(16, $i, str_replace(",", ".", $rs->CUSTO_DA_VENDA),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(17, $i, str_replace(",", ".", $rs->VALOR_MARGEM),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(18, $i, str_replace(",", ".", $rs->MARGEM_PCT),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(19, $i, str_replace(",", ".", $rs->PRIMEIRO_MES),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(20, $i, str_replace(",", ".", $rs->SEGUNDO_MES),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(21, $i, str_replace(",", ".", $rs->TERCEIRO_MES),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(22, $i, str_replace(",", ".", $rs->QUARTO_MES),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(23, $i, str_replace(",", ".", $rs->QUINTO_MES),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(24, $i, str_replace(",", ".", $rs->SEXTO_MES),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(25, $i, str_replace(",", ".", $rs->MES_ATUAL),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Curvas ABCD de Clientes Pecas');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "Curva-ABCD-Pecas-".date("d-m-Y");
			$objWriter->save($nome_arquivo.".xlsx");
			
			$ssh = new ServidorArquivo();
			
			if ($ssh->MandaArquivo('relatorio', $nome_arquivo.".xlsx") == 'sucesso'){
				$sql = array();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina33(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 33 && $validacao == md5($rotina.date("dmY"))) {
			$funcoes = new Funcoes();
			$apiAgendarotina = new apiAgendarotina();
			$result = $apiAgendarotina->getVendas400();
			
			$objPHPExcel = new \PHPExcel();
			
			$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('K1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('L1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('M1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('N1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('O1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('P1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Q1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('R1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('S1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('T1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('U1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('V1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('W1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('X1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Y1')->getFont()->setBold(true);
			$objPHPExcel->getActiveSheet()->getStyle('Z1')->getFont()->setBold(true);
			
			
			$objPHPExcel->setActiveSheetIndex(0)
			->setCellValue('A1', 'EMPRESA' )
			->setCellValue('B1', "REVENDA" )
			->setCellValue("C1", "CLIENTE" )
			->setCellValue("D1", "NOME" )
			->setCellValue("E1", "DES_CATEGORIA_CLIENTE" )
			->setCellValue("F1", "CLASSIFICACAO" )
			->setCellValue("G1", "MUNICIPIO_ENTREGA" )
			->setCellValue("H1", "BAIRRO_ENTREGA" )
			->setCellValue("I1", "DDD_TELEFONE" )
			->setCellValue("J1", "TELEFONE" )
			->setCellValue("K1", "DDD_CELULAR" )
			->setCellValue("L1", "CELULAR" )
			->setCellValue("M1", "E_MAIL_TRABALHO" )
			->setCellValue("N1", "E_MAIL_CASA" )
			->setCellValue("O1", "TOTAL_VENDA" )
			->setCellValue("P1", "TOTAL_DESCONTO" )
			->setCellValue("Q1", "CUSTO_DA_VENDA" )
			->setCellValue("R1", "VALOR_MARGEM" )
			->setCellValue("S1", "MARGEM_PCT" )
			->setCellValue("T1", "PRIMEIRO_MES" )
			->setCellValue("U1", "SEGUNDO_MES" )
			->setCellValue("V1", "TERCEIRO_MES" )
			->setCellValue("W1", "QUARTO_MES" )
			->setCellValue("X1", "QUINTO_MES" )
			->setCellValue("Y1", "SEXTO_MES" )
			->setCellValue("Z1", "MES_ATUAL" );
			
			$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(20);
			$objPHPExcel->getActiveSheet()->getStyle('O')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('P')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(30);
			$objPHPExcel->getActiveSheet()->getStyle('Q')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('R')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('S')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('T')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('T')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('U')->setWidth(15);
			$objPHPExcel->getActiveSheet()->getStyle('U')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('V')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('V')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('W')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('W')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('X')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('X')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('Y')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('Y')->getNumberFormat()->setFormatCode('#,##0.00');
			$objPHPExcel->getActiveSheet()->getColumnDimension('Z')->setWidth(10);
			$objPHPExcel->getActiveSheet()->getStyle('Z')->getNumberFormat()->setFormatCode('#,##0.00');
			
			$i = 1;
			foreach ($result as $rs){
				$i = $i + 1;
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->EMPRESA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->REVENDA);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->CLIENTE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $funcoes->retiraAcentos($rs->NOME));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $funcoes->retiraAcentos($rs->DES_CATEGORIA_CLIENTE));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->CLASSIFICACAO);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $funcoes->retiraAcentos($rs->MUNICIPIO_ENTREGA));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $funcoes->retiraAcentos($rs->BAIRRO_ENTREGA));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, $rs->DDD_TELEFONE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, $rs->TELEFONE);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, $rs->DDD_CELULAR);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $i, $rs->CELULAR);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $i, $funcoes->retiraAcentos($rs->E_MAIL_TRABALHO));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $i, $funcoes->retiraAcentos($rs->E_MAIL_CASA));
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $i, str_replace(",", ".", $rs->TOTAL_VENDA),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(15, $i, str_replace(",", ".", $rs->TOTAL_DESCONTO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(16, $i, str_replace(",", ".", $rs->CUSTO_DA_VENDA),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(17, $i, str_replace(",", ".", $rs->VALOR_MARGEM),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(18, $i, str_replace(",", ".", $rs->MARGEM_PCT),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(19, $i, str_replace(",", ".", $rs->PRIMEIRO_MES),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(20, $i, str_replace(",", ".", $rs->SEGUNDO_MES),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(21, $i, str_replace(",", ".", $rs->TERCEIRO_MES),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(22, $i, str_replace(",", ".", $rs->QUARTO_MES),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(23, $i, str_replace(",", ".", $rs->QUINTO_MES),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(24, $i, str_replace(",", ".", $rs->SEXTO_MES),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(25, $i, str_replace(",", ".", $rs->MES_ATUAL),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				
			}
			
			$objPHPExcel->getActiveSheet()->setTitle('Curvas ABCD de Clientes Oficina');
			
			$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
			
			$nome_arquivo = "Curva-ABCD-Oficina-".date("d-m-Y");
			$objWriter->save($nome_arquivo.".xlsx");
			
			$ssh = new ServidorArquivo();
			
			if ($ssh->MandaArquivo('relatorio', $nome_arquivo.".xlsx") == 'sucesso'){
				$sql = array();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	
	public function rotina38(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 38 && $validacao == md5($rotina.date("dmY"))) {
			$dia = date('d');
			if ($dia == '01') {
				$pasta = $_SERVER["DOCUMENT_ROOT"] ."/". RAIZ_PATH."dados/anexo/";
				$sql = array();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				if (is_dir($pasta)) {
					$diretorio = dir($pasta);
					while ($arquivo = $diretorio->read()) {
						if (($arquivo != '.') && ($arquivo != '..') && ($arquivo != 'index.php')) {
							unlink($pasta.$arquivo);
							echo 'Arquivo '.$arquivo.' foi apagado com sucesso. <br />';
							$mensagem = "Executado com Sucesso!";
						}
					}
					$diretorio->close();
				}else{
					echo "A Pasta n�o Existe";
				}
				if ($mensagem != NULL) {
					$apiAgendarotina = new apiAgendarotina();
					$sql[0] = $apiAgendarotina->editAgendarotina($agendarotina);
					$rs = $apiAgendarotina->executeSQL($sql);
					if ($rs[4] == "sucesso"){
						$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
						header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
						die();
					}else{
						$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
						header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
						die();
					}
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}
		}
	}
	public function rotina41(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 41 && $validacao == md5($rotina.date("dmY"))) {
			$dia = date("d");
			$timestamp = strtotime(date("Y-m-d"));
			$util = date('N',$timestamp);
			$util2 = $util + 1;
			$sql = array();
			$i = 0;
			if (($dia == "01" && $util <= 5) ||($dia == "02" && $util2 == 2) || ($dia == "03" && $util2 == 2)) {
				$email = new Email();
				$email->dta_envio = date('d/m/Y');
				$email->hora_envio = "07:50:00";
				$email->rotina = $rotina;
				$email->remetente ="SisMonaco - Aviso Mensal 08:00";
				$email->assunto = "Acompanhamento de Audit�rias 1";
				$email->mensagem = "GESTORES COMO EST� O ACOMPANHAMENTO DE NOSSAS AUDIT�RIAS (ISO/ PERFIL / PPA) , LEMBREM SE QUE TEMOS QUE EST� EM DIAS COM ESSAS A��ES , PPA DEVE SER ENVIADA AT� O 3� DIA �TIL DE CADA M�S , POR ESSA PONTUALIDADE GANHARMOS 1% DE BONIFICA��O EM PE�AS, POR�M  SE ANTECIPEM.";
				$email->situacao = 'P';
				$apiEmail = new apiEmail();
				$apiRotinausuario = new apiRotinausuario();
				$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
				foreach ($result as $rs) {
					$email->destinatario = $rs->EMAIL;
					$sql[$i] = $apiEmail->addEmail($email);
					$i = $i + 1;
				}
				$apiAgendarotina = new apiAgendarotina();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$apiAgendarotina = new apiAgendarotina();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}
		}
	}
	
	public function rotina42(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 42 && $validacao == md5($rotina.date("dmY"))) {
			$dia = date("d");
			$timestamp = strtotime(date("Y-m-d"));
			$util = date('N',$timestamp);
			$util2 = $util + 1;
			$sql = array();
			$i = 0;
			if (($dia == "02" && $util <= 5) ||($dia == "03" && $util2 == 2) || ($dia == "04" && $util2 == 2)) {
				$email = new Email();
				$email->dta_envio = date('d/m/Y');
				$email->hora_envio = "07:50:00";
				$email->rotina = $rotina;
				$email->remetente ="SisMonaco - Aviso Mensal 08:00";
				$email->assunto = "Acompanhamento de Audit�rias 2";
				$email->mensagem = "GESTORES N�O ESQUE�AM DE REUNIR SUA EQUIPE E LEVAR EM PAUTA NOSSAS AUDIT�RIAS DA ISO / PERFIL OPERACIONAL / DEG / RMS , AFINAL TODOS DEVEM TER CONHECIMENTO DE NOSSAS AVALIA��ES PERANTE A F�BRICA  E N�O ESQUE�A DA ATA DE REUNI�O.";
				$email->situacao = 'P';
				$apiEmail = new apiEmail();
				$apiRotinausuario = new apiRotinausuario();
				$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
				foreach ($result as $rs) {
					$email->destinatario = $rs->EMAIL;
					$sql[$i] = $apiEmail->addEmail($email);
					$i = $i + 1;
				}
				$apiAgendarotina = new apiAgendarotina();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$apiAgendarotina = new apiAgendarotina();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}
		}
	}
	
	public function rotina45(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 45 && $validacao == md5($rotina.date("dmY"))) {
			$dia = date("d");
			$timestamp = strtotime(date("Y-m-d"));
			$util = date('N',$timestamp);
			$util2 = $util + 1;
			$sql = array();
			$i = 0;
			if (($dia == "01" && $util <= 5) ||($dia == "02" && $util2 == 2) || ($dia == "03" && $util2 == 2)) {
				$email = new Email();
				$email->dta_envio = date('d/m/Y');
				$email->hora_envio = "07:50:00";
				$email->rotina = $rotina;
				$email->remetente ="SisMonaco - Aviso Mensal 08:00";
				$email->assunto = "Acompanhamento de A��es de Campo";
				$email->mensagem = "GESTOR TEVE ALGUMA A��O DE CAMPO EM SUA UNIDADE ? COMO FOI O DESEMPENHO ?  USE O CRM PARA AUMENTAR SEUS CONTATOS E ME�A OS CONTATOS FEITOS PELOS O QUE FORAM EFETIVADOS , AFINAL A��O DE CAMPO � FATURAMENTO GARANTIDO.";
				$email->situacao = 'P';
				$apiEmail = new apiEmail();
				$apiRotinausuario = new apiRotinausuario();
				$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
				foreach ($result as $rs) {
					$email->destinatario = $rs->EMAIL;
					$sql[$i] = $apiEmail->addEmail($email);
					$i = $i + 1;
				}
				$apiAgendarotina = new apiAgendarotina();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$apiAgendarotina = new apiAgendarotina();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}
		}
	}
	
	public function rotina50(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 50 && $validacao == md5($rotina.date("dmY"))) {
			$dia = date("d");
			$sql = array();
			$i = 0;
			if (($dia == "01") ||($dia == "02")) {
				$email = new Email();
				$email->dta_envio = date('d/m/Y');
				$email->hora_envio = "09:50:00";
				$email->rotina = $rotina;
				$email->remetente ="SisMonaco - Aviso Mensal 10:00";
				$email->assunto = "Apresenta��o de Circulares Pe�as e AT";
				$email->mensagem = "Senhores gestores j� apresentou as circulares de pe�as e ou A.T aos nossos colaboradores ? SE j� n�o esque�am de fazer ATA DE REUNI�O e ter a assinatura de todos os presentes, pois isso serve de evid�ncia para o nosso PERFIL E ISO.";
				$email->situacao = 'P';
				$apiEmail = new apiEmail();
				$apiRotinausuario = new apiRotinausuario();
				$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
				foreach ($result as $rs) {
					$email->destinatario = $rs->EMAIL;
					$sql[$i] = $apiEmail->addEmail($email);
					$i = $i + 1;
				}
				$apiAgendarotina = new apiAgendarotina();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$apiAgendarotina = new apiAgendarotina();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}
		}
	}
	
	public function rotina56(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 56 && $validacao == md5($rotina.date("dmY"))) {
			$dia = date("d");
			$timestamp = strtotime(date("Y-m-d"));
			$util = date('N',$timestamp);
			$util2 = $util + 1;
			$sql = array();
			$i = 0;
			if (($dia == "01" && $util <= 5) ||($dia == "02" && $util2 == 2) || ($dia == "03" && $util2 == 2)) {
				$funcoes = new Funcoes();
				$apiAgendarotina = new apiAgendarotina();
				$result = $apiAgendarotina->getRmsvw();
				
				$objPHPExcel = new \PHPExcel();
				
				$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
				$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->setBold(true);
				$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->setBold(true);
				$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->setBold(true);
				$objPHPExcel->getActiveSheet()->getStyle('E1')->getFont()->setBold(true);
				$objPHPExcel->getActiveSheet()->getStyle('F1')->getFont()->setBold(true);
				$objPHPExcel->getActiveSheet()->getStyle('G1')->getFont()->setBold(true);
				$objPHPExcel->getActiveSheet()->getStyle('H1')->getFont()->setBold(true);
				$objPHPExcel->getActiveSheet()->getStyle('I1')->getFont()->setBold(true);
				$objPHPExcel->getActiveSheet()->getStyle('J1')->getFont()->setBold(true);
				$objPHPExcel->getActiveSheet()->getStyle('K1')->getFont()->setBold(true);
				$objPHPExcel->getActiveSheet()->getStyle('L1')->getFont()->setBold(true);
				$objPHPExcel->getActiveSheet()->getStyle('M1')->getFont()->setBold(true);
				$objPHPExcel->getActiveSheet()->getStyle('N1')->getFont()->setBold(true);
				$objPHPExcel->getActiveSheet()->getStyle('O1')->getFont()->setBold(true);
				$objPHPExcel->getActiveSheet()->getStyle('P1')->getFont()->setBold(true);
				$objPHPExcel->getActiveSheet()->getStyle('Q1')->getFont()->setBold(true);
				$objPHPExcel->getActiveSheet()->getStyle('R1')->getFont()->setBold(true);
				$objPHPExcel->getActiveSheet()->getStyle('S1')->getFont()->setBold(true);
				$objPHPExcel->getActiveSheet()->getStyle('T1')->getFont()->setBold(true);
				$objPHPExcel->getActiveSheet()->getStyle('U1')->getFont()->setBold(true);
				
				$objPHPExcel->setActiveSheetIndex(0)
				->setCellValue('A1', 'TIPO' )
				->setCellValue('B1', 'EMPRESA' )
				->setCellValue('C1', 'REVENDA' )
				->setCellValue('D1', 'NRO_OS' )
				->setCellValue('E1', 'DTA_EMISSAO' )
				->setCellValue('F1', 'DTA_ENCERRAMENTO' )
				->setCellValue('G1', 'PLACA' )
				->setCellValue('H1', 'NRO_LANCAMENTO' )
				->setCellValue('I1', 'MODELO_SERVICO' )
				->setCellValue('J1', 'FAMILIA' )
				->setCellValue('K1', 'DES_MODELO' )
				->setCellValue('L1', 'MAODEOBRA' )
				->setCellValue('M1', 'DESCRICAO' )
				->setCellValue('N1', 'TIPO_SERVICO' )
				->setCellValue('O1', 'HORA_COBRADA' )
				->setCellValue('P1', 'HORA_TRABALHADA' )
				->setCellValue('Q1', 'VAL_DESCONTO' )
				->setCellValue('R1', 'VAL_SERVICO' )
				->setCellValue('S1', 'VAL_BRUTO' )
				->setCellValue('T1', 'VAL_IMPOSTOS' )
				->setCellValue('U1', 'VAL_LIQUIDO' );
				
				$objPHPExcel->getActiveSheet()->getColumnDimension('A')->setWidth(5);
				$objPHPExcel->getActiveSheet()->getColumnDimension('B')->setWidth(10);
				$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setWidth(10);
				$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setWidth(15);
				$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setWidth(20);
				$objPHPExcel->getActiveSheet()->getColumnDimension('F')->setWidth(20);
				$objPHPExcel->getActiveSheet()->getColumnDimension('G')->setWidth(10);
				$objPHPExcel->getActiveSheet()->getColumnDimension('H')->setWidth(15);
				$objPHPExcel->getActiveSheet()->getColumnDimension('I')->setWidth(15);
				$objPHPExcel->getActiveSheet()->getColumnDimension('J')->setWidth(10);
				$objPHPExcel->getActiveSheet()->getColumnDimension('K')->setWidth(30);
				$objPHPExcel->getActiveSheet()->getColumnDimension('L')->setWidth(15);
				$objPHPExcel->getActiveSheet()->getColumnDimension('M')->setWidth(30);
				$objPHPExcel->getActiveSheet()->getColumnDimension('N')->setWidth(15);
				$objPHPExcel->getActiveSheet()->getColumnDimension('O')->setWidth(15);
				$objPHPExcel->getActiveSheet()->getStyle('O')->getNumberFormat()->setFormatCode('#,##0.00');
				$objPHPExcel->getActiveSheet()->getColumnDimension('P')->setWidth(15);
				$objPHPExcel->getActiveSheet()->getStyle('P')->getNumberFormat()->setFormatCode('#,##0.00');
				$objPHPExcel->getActiveSheet()->getColumnDimension('Q')->setWidth(15);
				$objPHPExcel->getActiveSheet()->getStyle('Q')->getNumberFormat()->setFormatCode('#,##0.00');
				$objPHPExcel->getActiveSheet()->getColumnDimension('R')->setWidth(15);
				$objPHPExcel->getActiveSheet()->getStyle('R')->getNumberFormat()->setFormatCode('#,##0.00');
				$objPHPExcel->getActiveSheet()->getColumnDimension('S')->setWidth(15);
				$objPHPExcel->getActiveSheet()->getStyle('S')->getNumberFormat()->setFormatCode('#,##0.00');
				$objPHPExcel->getActiveSheet()->getColumnDimension('T')->setWidth(15);
				$objPHPExcel->getActiveSheet()->getStyle('T')->getNumberFormat()->setFormatCode('#,##0.00');
				$objPHPExcel->getActiveSheet()->getColumnDimension('U')->setWidth(15);
				$objPHPExcel->getActiveSheet()->getStyle('U')->getNumberFormat()->setFormatCode('#,##0.00');
				
				$i = 1;
				foreach ($result as $rs){
					$i = $i + 1;
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(0, $i, $rs->TIPO);
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(1, $i, $rs->EMPRESA);
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(2, $i, $rs->REVENDA);
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(3, $i, $rs->NRO_OS);
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(4, $i, $rs->DTA_EMISSAO);
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(5, $i, $rs->DTA_ENCERRAMENTO);
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(6, $i, $rs->PLACA);
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(7, $i, $rs->NRO_LANCAMENTO);
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(8, $i, $rs->MODELO_SERVICO);
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(9, $i, $rs->FAMILIA);
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(10, $i, utf8_encode($rs->DES_MODELO));
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(11, $i, $rs->MAODEOBRA);
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(12, $i, utf8_encode($rs->DESCRICAO));
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(13, $i, $rs->TIPO_SERVICO);
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(14, $i, str_replace(",", ".",$rs->HORA_COBRADA),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(15, $i, str_replace(",", ".",$rs->HORA_TRABALHADA),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(16, $i, str_replace(",", ".",$rs->VAL_DESCONTO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(17, $i, str_replace(",", ".",$rs->VAL_SERVICO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(18, $i, str_replace(",", ".",$rs->VAL_BRUTO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(19, $i, str_replace(",", ".",$rs->VAL_IMPOSTOS),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
					$objPHPExcel->getActiveSheet()->setCellValueByColumnAndRow(20, $i, str_replace(",", ".",$rs->VAL_LIQUIDO),\PHPExcel_Cell_DataType::TYPE_NUMERIC);
				}
				
				$objPHPExcel->getActiveSheet()->setTitle('RMS VW');
				
				$objWriter = \PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
				
				$nome_arquivo = "RMS-VW-Mensal-".date("d-m-Y");
				$objWriter->save($_SERVER["DOCUMENT_ROOT"] ."/". RAIZ_PATH."dados/anexo/{$nome_arquivo}.xlsx");
				
				$sql = array();
				$i = 0;
				$email = new Email();
				$email->dta_envio = date('d/m/Y');
				$email->hora_envio = "07:50:00";
				$email->rotina = $rotina;
				$email->remetente = "SisMonaco - RMS VW";
				$email->assunto = "RMS VW Mensal ".date('d/m/Y');
				$email->mensagem = "Segue em anexo o relat�rio RMS VW" ;
				$email->anexo = "dados/anexo/{$nome_arquivo}.xlsx";
				$email->situacao = 'P';
				$apiEmail = new apiEmail();
				$apiRotinausuario = new apiRotinausuario();
				$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
				foreach ($result as $rs) {
					$email->destinatario = $rs->EMAIL;
					$sql[$i] = $apiEmail->addEmail($email);
					$i = $i + 1;
				}
				$apiAgendarotina = new apiAgendarotina();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}else{
				$apiAgendarotina = new apiAgendarotina();
				$agendarotina = new Agendarotina();
				$agendarotina->rotina = $rotina;
				$agendarotina->dta_ult_execucao = date('d/m/Y');
				$agendarotina->hora_ult_execucao = date('H:i:s');
				$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
				$rs = $apiAgendarotina->executeSQL($sql);
				if ($rs[4] == "sucesso"){
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}else{
					$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
					header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
					die();
				}
			}
		}
	}
	
	//***********************************************Rotinas Quadrimestrais************************************************
	public function rotina54(){
		$rotina = $this->getParams(0);
		$validacao = $this->getParams(1);
		if ($rotina == 54 && $validacao == md5($rotina.date("dmY"))) {
			$sql = array();
			$i = 0;
			$email = new Email();
			$email->dta_envio = date('d/m/Y');
			$email->hora_envio = "07:50:00";
			$email->rotina = $rotina;
			$email->remetente = "SisMonaco - Aviso Quadrimestral 08:00";
			$email->assunto = "Invent�rio de Pe�as e Ferramentas";
			$email->mensagem = "GESTORES J� PROGRAMOU A DATA DO SEU INVENT�RO DE PE�AS E FERRAMENTAS ? LEMBREM SE QUE DEVEMOS TER UM INVENT�RIO POR QUADRIMESTRE AFINAL SOMOS PONTUADOS EM NOSSAS AUDIT�RIAS POR ESSE CONTROLE.";
			$email->situacao = 'P';
			$apiEmail = new apiEmail();
			$apiRotinausuario = new apiRotinausuario();
			$result = $apiRotinausuario->filtroRotinausuario($rotina, " AND u.ativo = '1'");
			foreach ($result as $rs) {
				$email->destinatario = $rs->EMAIL;
				$sql[$i] = $apiEmail->addEmail($email);
				$i = $i + 1;
			}
			$apiAgendarotina = new apiAgendarotina();
			$agendarotina = new Agendarotina();
			$agendarotina->rotina = $rotina;
			$agendarotina->dta_ult_execucao = date('d/m/Y');
			$agendarotina->hora_ult_execucao = date('H:i:s');
			$sql[$i] = $apiAgendarotina->editAgendarotina($agendarotina);
			$rs = $apiAgendarotina->executeSQL($sql);
			if ($rs[4] == "sucesso"){
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}else{
				$_SESSION['contador_sessao'] = $_SESSION['contador_sessao'] + 1;
				header("location:" .APP_ROOT. "adm/agendarotina/rotina{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['rotina']}/{$_SESSION['rotina_sessao'][$_SESSION['contador_sessao']]['validacao']}");
				die();
			}
		}
	}
	public function rotina(){
		header("location:" .APP_ROOT. "adm/agendarotina/execucao");
		die();
	}
}