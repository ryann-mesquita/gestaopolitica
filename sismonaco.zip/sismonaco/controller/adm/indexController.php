<?php

namespace controller\adm;

use lib\Controller;
use helper\Security;

class indexController extends Controller {

	public function __construct() {

		parent::__construct();

		new Security($this->getModule(),$this->getController(),$this->getAction());
	}

	public function index() {

		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "�rea Administrativa";
		unset($_SESSION['filtro_sessao']);
		unset($_SESSION['consulta_sessao']);
		/*$funcoes = new Funcoes();
		$semana = str_replace('/', '-', '12/12/2018 17:00:00');
		$semana = strtotime(date("m/d/Y", strtotime($semana)));
		$semana = $funcoes->retiraAcentos(str_replace("-feira", "", strtolower(strftime('%A',$semana))));
		if ($semana == "segunda"){
			$dia = 1;
		}elseif ($semana == "terca"){
			$dia = 2;
		}elseif ($semana == "quarta"){
			$dia = 3;
		}elseif ($semana == "quinta"){
			$dia = 4;
		}elseif ($semana == "sexta"){
			$dia = 5;
		}elseif ($semana == "sabado"){
			$dia = 6;
		}else{
			$dia = 7;
		}
		$atual = strtotime('2018-12-17');
		$ult_mov = strtotime(date("Y-m-d", strtotime('2018-12-12 17:00:00')));
		$calc_dias = $atual - $ult_mov;
		echo $dias_mov = round($calc_dias/(60 * 60 * 24))."<br>";
		
		if ($dias_mov == 0){
			$atual =  strtotime('2018-12-12 13:38:50');
			$mov =  strtotime('2018-12-12 12:02:50');
			$tempo = $atual - $mov;
			echo $tempo = round($tempo/60);
		}else{
			for ($i=0; $i <= $dias_mov; $i++){
				if ($i == 0){
					$fim_exp =  strtotime('17:30:00');
					$ult_mov =  strtotime('17:02:50');
					$tempo = $fim_exp - $ult_mov;
					$duracao = round($tempo/60);
				}elseif ($i == $dias_mov){
					$ini_exp =  strtotime('07:30:00');
					$mov =  strtotime('09:39:00');
					$tempo = $mov - $ini_exp;
					$duracao = $duracao + round($tempo/60);
				}else{
					if ($dia == 6){
						$duracao = $duracao + 240;
					}elseif ($dia == 7){
						$duracao = $duracao;
					}else{
						$duracao = $duracao + 528;
					}
				}
				$dia = $dia + 1;
			}
		}
		echo $duracao;
		//echo floor( $duracao/ 60)."h ".($duracao % 60)."m";
		//echo ($duracao/60);
		//$atual = strtotime(date('Y-m-d H:i:s'));
		//echo $atual =  strtotime('2018-12-14 09:38:50')."<br>";
		//echo $atual =  strtotime('2018-12-12')."<br>";
		//2018-12-12 17:02:50
		//2018-12-13 09:38:50
		//$mov = str_replace('/', '-', $this->dados['chamado']->DTA_ULT_MOVIMENTO);
		//echo $mov =  strtotime('2018-12-12 17:02:50')."<br>";
		//echo $mov =  strtotime('2018-12-12')."<br>";
		//$mov = strtotime(date("Y-m-d H:i:s", strtotime($mov)));
		//echo $tempo = $atual - $mov;
		//echo "<br>";
		//echo $tempo = round($tempo/(60 * 60 * 24))."<br>";
		//echo round((($tempo/60) / 2.84),2);
		/*$apiUsuario = new apiUsuario();
		$rs = $apiUsuario->migracaoUsuario();
		$usuario = new Usuario();
		$sql = array();
		$i = 0;
		foreach ($rs as $rs) {
			$usuario->tipo = 1;
			$usuario->departamento = 1;
			$usuario->cpf = $rs->CPF;
			$usuario->nome = $rs->NOME;
			$usuario->email = $rs->EMAIL;
			$usuario->senha = md5(substr(ucfirst($rs->NOME), 0, 2).$rs->CPF);
			$usuario->empresa = $rs->EMPRESA;
			$usuario->ativo = 1;
			$sql[$i] = $apiUsuario->addUsuario($usuario);
			$i = $i + 1;		
		}
		$apiUsuario->executeSQL($sql);*/	
		$this->view();
	}
}