<?php

namespace controller\adm;

use lib\Controller;
use helper\Security;
use api\dev\apiRotina;
use helper\Paginator;
use obj\adm\Rotinausuario;
use obj\dev\Rotina;
use api\adm\apiRotinausuario;
use obj\geral\Log;
use api\geral\apiLog;

class rotinausuarioController extends Controller {

	public function __construct() {

		parent::__construct();

		new Security($this->getModule(),$this->getController(),$this->getAction());
	}

	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Lista de Rotinas";
		$apiRotina = new apiRotina();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		(!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])) ? $a = '1' : $a = '3';
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$busca = array(
				'1' => array('c' => '1','a' => $a,'coluna' => 'ativo', 'valor' => '1'),
				'2' => array('c' => '1','a' => $a,'coluna' => 'ativo', 'valor' => '0'),
				'3' => array('c' => '2','a' => $a,'coluna' => 'des_rotina', 'valor' => @$_POST['busca_valor']),
				'4' => array('c' => '3','a' => $a,'coluna' => "",'valor' => "")
			);
			if(isset($busca[$_POST['busca']])){
				$this->dados = array('rotina' => $apiRotina->filtroRotina($busca[$_POST['busca']]['c'], $busca[$_POST['busca']]['a'],'tudo', $busca[$_POST['busca']]['coluna'], $busca[$_POST['busca']]['valor']));
				$_SESSION['filtro_sessao'] = array('c' => $busca[$_POST['busca']]['c'], 'a' => $busca[$_POST['busca']]['a'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'valor' => $busca[$_POST['busca']]['valor'], 'busca' => $_POST['busca'], 'busca_valor' => isset($_POST['busca_valor']) ? $_POST['busca_valor'] : "");
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'adm/index/index/acessonegado');
				die();
			}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				$this->dados = array('rotina' => $apiRotina->filtroRotina($_SESSION['filtro_sessao']['c'],$_SESSION['filtro_sessao']['a'],'tudo',$_SESSION['filtro_sessao']['coluna'], $_SESSION['filtro_sessao']['valor']));
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('rotina' => $apiRotina->filtroRotina('1','3','tudo','ativo', '1'));
					$_SESSION['filtro_sessao'] = array('c' => '1', 'a' => '3', 'coluna' => 'ativo' , 'valor' => '1', 'busca' => '4', 'busca_valor' => '');
					$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}
		}
		$TotalItem = (is_array($this->dados['rotina']) ? count($this->dados['rotina']) : 0);
		$this->dados['rotina'] = array_chunk($this->dados['rotina'], $ItemPorPagina);
		@$this->dados['rotina'] = $this->dados['rotina'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->view();
	}

	public function adicionar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$rotina= new Rotina();
		$rotina->rotina = $this->getParams(0);
		$this->rotina = $rotina->rotina;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		$apiRotina = new apiRotina();
		$rs = $apiRotina->getRotina($rotina);
		$this->header = $rs->DES_ROTINA;
		if (isset($rs)){
			if ($rs->ATIVO == '0'){
				header('location:' .APP_ROOT. 'adm/index/index/acessonegado');
				die();
			}
		}else{
			header('location:' .APP_ROOT. 'adm/index/index/acessonegado');
			die();
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$apiRotinausuario = new apiRotinausuario();
			$usuario = $_POST['usuario'];
			$usuario_nome = $_POST['usuario_nome'];
			$condicao = "(";
			$a = 0;
			foreach ($usuario as $rs => $va) {
				$condicao .= "ru.usuario = '{$va}' OR ";
				$this->rollback[$a] = array('usuario' => $va, 'usuario_nome' => $usuario_nome[$rs]);
				$a = $a + 1;
			}
			$rs = $apiRotinausuario->filtroRotinausuario($rotina->rotina," AND ".substr($condicao,0,-3).")");
			if ((is_array($rs) ? count($rs) : 0) > 0){
				$this->Alert = "<br>";
				foreach ($rs as $rs) {
					$this->Alert .= "J� existe o usuario: {$rs->NOME} vinculado a essa rotina! <br>";
				}
			}else{
				$rotinausuario = new Rotinausuario();
				$rotinausuario->rotina = $rotina->rotina;
				$log = new Log();
				$apiLog = new apiLog();
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				foreach ($this->rollback as $rs) {
					$rotinausuario->usuario = $rs['usuario'];
					$sql[$i] = $apiRotinausuario->addRotinausuario($rotinausuario);
					$i = $i+1;
					$log->historico = "ROTINA||{$rotinausuario->rotina};;USUARIO||{$rotinausuario->usuario}";
					$sql[$i] = $apiLog->addLog($log);
					$i = $i+1;
				}
				$rs = $apiRotinausuario->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'adm/rotinausuario/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'adm/rotinausuario/index/sucesso');
					}
				}else{
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}

		$this->view();
	}

	public function excluir() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$rotina = new Rotina();
		$rotina->rotina = $this->getParams(0);
		$this->rotina = $rotina->rotina;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		$apiRotina = new apiRotina();
		$rs= $apiRotina->getRotina($rotina);
		$this->header = $rs->DES_ROTINA;
		if (isset($rs)){
			if ($rs->ATIVO == '0'){
				header('location:' .APP_ROOT. 'adm/index/index/acessonegado');
				die();
			}
		}else{
			header('location:' .APP_ROOT. 'adm/index/index/acessonegado');
			die();
		}
		$apiRotinausuario = new apiRotinausuario();
		$this->dados = array('rotinausuario' => $apiRotinausuario->filtroRotinausuario($rotina->rotina));
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$rotinausuario = new Rotinausuario();
			$rotinausuario->rotina = $rotina->rotina;
			$log = new Log();
			$apiLog = new apiLog();
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "E";
			$log->dta_registro = date("d/m/Y H:i:s");
			foreach ($_POST['exclusao'] as $rs) {
				$rotinausuario->usuario = $rs;
				$sql[$i] = $apiRotinausuario->delRotinausuario($rotinausuario);
				$i = $i+1;
				$log->historico = "ROTINA||{$rotinausuario->rotina};;USUARIO||{$rotinausuario->usuario}";
				$sql[$i] = $apiLog->addLog($log);
				$i = $i+1;
			}
			$rs = $apiRotinausuario->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'adm/rotinausuario/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'adm/rotinausuario/index/sucesso');
				}
			}else{
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}
		$this->view();
	}
}