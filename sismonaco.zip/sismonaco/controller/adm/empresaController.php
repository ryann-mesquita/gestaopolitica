<?php

namespace controller\adm;

use lib\Controller;
use helper\Security;
use api\geral\apiEmpresa;
use helper\Paginator;
use obj\geral\Log;
use api\geral\apiLog;
use obj\geral\Empresa;
use helper\Funcoes;

class empresaController extends Controller {

	public function __construct() {

		parent::__construct();

		new Security($this->getModule(),$this->getController(),$this->getAction());
	}

	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Lista de Empresas";
		$apiEmpresa = new apiEmpresa();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		(!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])) ? $a = '1' : $a = '3';
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$busca = array(
				'1' => array('c' => '1','a' => $a,'coluna' => 'ativo', 'valor' => '1'),
				'2' => array('c' => '1','a' => $a,'coluna' => 'ativo', 'valor' => '0'),
				'3' => array('c' => '2','a' => $a,'coluna' => 'cnpj', 'valor' => @$_POST['busca_valor']),
				'4' => array('c' => '2','a' => $a,'coluna' => 'des_empresa', 'valor' => @$_POST['busca_valor']),
				'5' => array('c' => '3','a' => $a,'coluna' => "",'valor' => "")
			);
			if(isset($busca[$_POST['busca']])){
				$this->dados = array('empresa' => $apiEmpresa->filtroEmpresa($busca[$_POST['busca']]['c'], $busca[$_POST['busca']]['a'], $busca[$_POST['busca']]['coluna'], $busca[$_POST['busca']]['valor']));
				$_SESSION['filtro_sessao'] = array('c' => $busca[$_POST['busca']]['c'], 'a' => $busca[$_POST['busca']]['a'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'valor' => $busca[$_POST['busca']]['valor'], 'busca' => $_POST['busca'], 'busca_valor' => isset($_POST['busca_valor']) ? $_POST['busca_valor'] : "");
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				unset($_SESSION['filtro_sessao']);
				unset($_SESSION['consulta_sessao']);
				header('location:' .APP_ROOT. 'adm/index/index/acessonegado');
				die();
			}	
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				$this->dados = array('empresa' => $apiEmpresa->filtroEmpresa($_SESSION['filtro_sessao']['c'],$_SESSION['filtro_sessao']['a'],$_SESSION['filtro_sessao']['coluna'], $_SESSION['filtro_sessao']['valor']));
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('empresa' => $apiEmpresa->filtroEmpresa('1','3','ativo', '1'));
					$_SESSION['filtro_sessao'] = array('c' => '1', 'a' => '3', 'coluna' => 'ativo' , 'valor' => '1', 'busca' => '5', 'busca_valor' => '');
					$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}
			
		}
		$TotalItem = (is_array($this->dados['empresa']) ? count($this->dados['empresa']) : 0);
		$this->dados['empresa'] = array_chunk($this->dados['empresa'], $ItemPorPagina);
		@$this->dados['empresa'] = $this->dados['empresa'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->view();
	}

	public function adicionar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Cadastro de Empresa";
		$apiEmpresa = new apiEmpresa();
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$funcoes = new Funcoes();
			$Post = new Empresa('POST');
			$Post->cnpj = $funcoes->naoNumerico($Post->cnpj);
			$Post->des_empresa = strtolower($funcoes->retiraAcentos($Post->des_empresa));
			$Post->cep = $funcoes->naoNumerico($Post->cep);
			$apiEmpresa = new apiEmpresa();
			$rs = $apiEmpresa->filtroEmpresa('4','3',"","",$Post);
			if ((is_array($rs) ? count($rs) : 0) > 0){
				$this->rollback = new Empresa('POST');
				$this->Alert = "J� existe uma empresa com essa descri��o ou cnpj cadastrado!";
			}else{
				$sql[$i] = $apiEmpresa->addEmpresa($Post);
				$i = $i+1;
				$log = new Log();
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "I";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico = "ORDEM||{$Post->ordem};;DES_EMPRESA||{$Post->des_empresa};;RAZAO_SOCIAL||{$Post->razao_social};;CNPJ||{$Post->cnpj};;ENDERECO||{$Post->endereco};;NRO_ENDERECO||{$Post->nro_endereco};;UF||{$Post->uf};;CIDADE||{$Post->cidade};;BAIRRO||{$Post->bairro};;CEP||{$Post->cep};;ATIVO||{$Post->ativo}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiEmpresa->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'adm/empresa/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'adm/empresa/index/sucesso');
					}
				}else{
					$this->rollback = new Empresa('POST');
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}

		$this->view();
	}

	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Altera��o de Empresa";
		$empresa = new Empresa();
		$empresa->empresa = $this->getParams(0);
		$apiEmpresa = new apiEmpresa();
		$this->dados = array('empresa' => $apiEmpresa->getEmpresa($empresa));
		if (isset($this->dados['empresa'])){
			if ($this->dados['empresa']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'adm/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'adm/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$funcoes = new Funcoes();
			$Post = new Empresa('POST');
			$Post->empresa = $empresa->empresa;
			$Post->des_empresa = strtolower($funcoes->retiraAcentos($Post->des_empresa));
			$Post->cep = $funcoes->naoNumerico($Post->cep);
			$rs = $apiEmpresa->filtroEmpresa('4','3',"","",$Post);
			$log = new Log();
			$log->historico = "EMPRESA||{$this->dados['empresa']->EMPRESA};;ORDEM||{$this->dados['empresa']->ORDEM};;DES_EMPRESA||{$this->dados['empresa']->DES_EMPRESA};;RAZAO_SOCIAL||{$this->dados['empresa']->RAZAO_SOCIAL};;CNPJ||{$this->dados['empresa']->CNPJ};;ENDERECO||{$this->dados['empresa']->ENDERECO};;NRO_ENDERECO||{$this->dados['empresa']->NRO_ENDERECO};;UF||{$this->dados['empresa']->UF};;CIDADE||{$this->dados['empresa']->CIDADE};;BAIRRO||{$this->dados['empresa']->BAIRRO};;CEP||{$this->dados['empresa']->CEP};;ATIVO||{$this->dados['empresa']->ATIVO}";
			if ((is_array($rs) ? count($rs) : 0) > 0 && ($rs[0]->EMPRESA != $this->dados['empresa']->EMPRESA)){
				$this->dados['empresa']->ORDEM = $Post->ordem;
				$this->dados['empresa']->DES_EMPRESA = $Post->des_empresa;
				$this->dados['empresa']->RAZAO_SOCIAL = $Post->razao_social;
				$this->dados['empresa']->ENDERECO = $Post->endereco;
				$this->dados['empresa']->NRO_ENDERECO = $Post->nro_endereco;
				$this->dados['empresa']->UF = $Post->uf;
				$this->dados['empresa']->CIDADE = $Post->cidade;
				$this->dados['empresa']->BAIRRO = $Post->bairro;
				$this->dados['empresa']->CEP = $Post->cep;
				$this->dados['empresa']->ATIVO = $Post->ativo;
				$this->Alert = "J� existe uma empresa com essa descri��o({$this->dados['empresa']->DES_EMPRESA}) cadastrado!";
			}else{
				$sql[$i] = $apiEmpresa->editEmpresa($Post);
				$i = $i+1;
				$log->usuario = $_SESSION['usuario_sessao'];
				$log->modulo = $this->getModule()['modulo'];
				$log->controle = $this->getController()['controle'];
				$log->acao = $this->getAction()['acao'];
				$log->empresa = $_SESSION['empresa_sessao'];
				$log->tipo = "A";
				$log->dta_registro = date("d/m/Y H:i:s");
				$log->historico = "::EMPRESA||{$Post->empresa};;ORDEM||{$Post->ordem};;DES_EMPRESA||{$Post->des_empresa};;RAZAO_SOCIAL||{$Post->razao_social};;CNPJ||{$Post->cnpj};;ENDERECO||{$Post->endereco};;NRO_ENDERECO||{$Post->nro_endereco};;UF||{$Post->uf};;CIDADE||{$Post->cidade};;BAIRRO||{$Post->bairro};;CEP||{$Post->cep};;ATIVO||{$Post->ativo}";
				$apiLog = new apiLog();
				$sql[$i] = $apiLog->addLog($log);
				$rs = $apiEmpresa->executeSQL($sql);
				if (@$rs[4] == 'sucesso') {
					if (isset($this->PaginaAtual)) {
						header('location:' .APP_ROOT. 'adm/empresa/index/pagina/'.$this->PaginaAtual.'/sucesso');
					}else {
						header('location:' .APP_ROOT. 'adm/empresa/index/sucesso');
					}
				}else{
					$this->dados['empresa']->ORDEM = $Post->ordem;
					$this->dados['empresa']->DES_EMPRESA = $Post->des_empresa;
					$this->dados['empresa']->RAZAO_SOCIAL = $Post->razao_social;
					$this->dados['empresa']->ENDERECO = $Post->endereco;
					$this->dados['empresa']->NRO_ENDERECO = $Post->nro_endereco;
					$this->dados['empresa']->UF = $Post->uf;
					$this->dados['empresa']->CIDADE = $Post->cidade;
					$this->dados['empresa']->BAIRRO = $Post->bairro;
					$this->dados['empresa']->CEP = $Post->cep;
					$this->dados['empresa']->ATIVO = $Post->ativo;
					$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
					$erro = str_replace($retirar, "", $rs[2]);
					$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
				}
			}
		}
		$this->view();
	}
	public function excluir() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Exclus�o de Empresa";
		$empresa = new Empresa();
		$empresa->empresa = $this->getParams(0);
		$apiEmpresa = new apiEmpresa();
		$this->dados = array('empresa' => $apiEmpresa->getEmpresa($empresa));
		$this->funcoes = new Funcoes();
		if (isset($this->dados['empresa'])){
			if ($this->dados['empresa']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'adm/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'adm/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$sql[$i] = $apiEmpresa->delEmpresa($empresa);
			$i = $i+1;
			$log = new Log();
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "E";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico = "EMPRESA||{$this->dados['empresa']->EMPRESA};;ORDEM||{$this->dados['empresa']->ORDEM};;DES_EMPRESA||{$this->dados['empresa']->DES_EMPRESA};;RAZAO_SOCIAL||{$this->dados['empresa']->RAZAO_SOCIAL};;CNPJ||{$this->dados['empresa']->CNPJ};;ENDERECO||{$this->dados['empresa']->ENDERECO};;NRO_ENDERECO||{$this->dados['empresa']->NRO_ENDERECO};;UF||{$this->dados['empresa']->UF};;CIDADE||{$this->dados['empresa']->CIDADE};;BAIRRO||{$this->dados['empresa']->BAIRRO};;CEP||{$this->dados['empresa']->CEP};;ATIVO||{$this->dados['empresa']->ATIVO}";
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiEmpresa->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'adm/empresa/index/pagina/'.$this->PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'adm/empresa/index/sucesso');
				}
			}else{
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}
		$this->view();
	}
}