<?php

namespace controller\adm;

use lib\Controller;
use helper\Security;
use api\adm\apiUsuario;
use api\adm\apiArea;
use api\adm\apiDepartamento;
use api\adm\apiTipo;
use api\adm\apiCargo;
use api\geral\apiEmpresa;
use obj\geral\Padrao;
use api\geral\apiPadrao;
use helper\Paginator;
use api\dev\apiFuncao;
use api\dev\apiModulo;
use obj\adm\Usuario;
use obj\geral\Log;
use api\geral\apiLog;
use helper\Funcoes;
use obj\dev\Funcao;
use obj\geral\Pandion;
use api\geral\apiPandion;

include 'classes/adLDAP/adLDAP.php';

class usuarioController extends Controller {

	public function __construct() {

		parent::__construct();

		new Security($this->getModule(),$this->getController(),$this->getAction());
	}

	public function index() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Lista de Usu�rio";
		if (isset($_SESSION["padrao_sessao"]["{$this->getModule()['modulo']}-{$this->getController()['controle']}-{$this->getAction()['acao']}"]) && !isset($_SESSION["colunas{$this->getModule()['modulo']}-{$this->getController()['controle']}-{$this->getAction()['acao']}"]['empresa'])){
			$val = $_SESSION["padrao_sessao"]["{$this->getModule()['modulo']}-{$this->getController()['controle']}-{$this->getAction()['acao']}"];
			$strVal = explode(';;', $val);
			foreach ($strVal as $rs){
				list($k, $v) = explode('||', $rs);
				$_SESSION["colunas{$this->getModule()['modulo']}-{$this->getController()['controle']}-{$this->getAction()['acao']}"][$k] = $v;
			}
		}
		$apiUsuario = new apiUsuario();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
		}
		(!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])) ? $a = '1' : $a = '3';
		$apiArea = new apiArea();
		$this->area = $apiArea->filtroArea('1','3','ativo', '1');
		$apiDepartamento = new apiDepartamento();
		$this->departamento = $apiDepartamento->filtroDepartamento('1','3','d.ativo', '1');
		$apiTipo = new apiTipo();
		$this->tipo = $apiTipo->filtroTipo('1','3','ativo', '1');
		$apiCargo = new apiCargo();
		$this->cargo = $apiCargo->filtroCargo('1','3','ativo', '1');
		$apiEmpresa = new apiEmpresa();
		$this->empresa = $apiEmpresa->filtroEmpresa('1','3','ativo', '1');
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			if ($_POST["submeter"] == "salvar"){
				$sql = array();
				$padrao = new Padrao();
				$padrao->modulo = $this->getModule()['modulo'];
				$padrao->controle = $this->getController()['controle'];
				$padrao->acao = $this->getAction()['acao'];
				$padrao->usuario = $_SESSION['usuario_sessao'];
				$padrao->padrao = isset($_POST['empresa']) ? "empresa||S;;" : "empresa||N;;";
				$padrao->padrao .= isset($_POST['dta_admissao']) ? "dta_admissao||S;;" : "dta_admissao||N;;";
				$padrao->padrao .= isset($_POST['dta_demissao']) ? "dta_demissao||S;;" : "dta_demissao||N;;";
				$padrao->padrao .= isset($_POST['dta_nascimento']) ? "dta_nascimento||S;;" : "dta_nascimento||N;;";
				$padrao->padrao .= isset($_POST['departamento']) ? "departamento||S;;" : "departamento||N;;";
				$padrao->padrao .= isset($_POST['tipo']) ? "tipo||S;;" : "tipo||N;;";
				$padrao->padrao .= isset($_POST['cargo']) ? "cargo||S;;" : "cargo||N;;";
				$padrao->padrao .= isset($_POST['cpf']) ? "cpf||S;;" : "cpf||N;;";
				$padrao->padrao .= isset($_POST['nome']) ? "nome||S;;" : "nome||N;;";
				$padrao->padrao .= isset($_POST['email']) ? "email||S;;" : "email||N;;";
				$padrao->padrao .= isset($_POST['dta_cadastro']) ? "dta_cadastro||S;;" : "dta_cadastro||N;;";
				$padrao->padrao .= isset($_POST['dta_ult_ini_ferias']) ? "dta_ult_ini_ferias||S;;" : "dta_ult_ini_ferias||N;;";
				$padrao->padrao .= isset($_POST['dta_ult_fim_ferias']) ? "dta_ult_fim_ferias||S;;" : "dta_ult_fim_ferias||N;;";
				$padrao->padrao .= isset($_POST['dta_ult_alteracao']) ? "dta_ult_alteracao||S;;" : "dta_ult_alteracao||N;;";
				$padrao->padrao .= isset($_POST['ativo']) ? "ativo||S;;" : "ativo||N;;";
				$padrao->padrao .= isset($_POST['online']) ? "online||S" : "online||N";
				$strVal = explode(';;', $padrao->padrao);
				foreach ($strVal as $rs){
					list($k, $v) = explode('||', $rs);
					$_SESSION["colunas{$this->getModule()['modulo']}-{$this->getController()['controle']}-{$this->getAction()['acao']}"][$k] = $v;
				}
				$apiPadrao = new apiPadrao();
				$rs = $apiPadrao->getPadrao($padrao);
				if ((is_array($rs) ? count($rs) : 0) > 0) {
					$sql[0] = $apiPadrao->editPadrao($padrao);
				}else{
					$sql[0] = $apiPadrao->addPadrao($padrao);
				}
				$apiPadrao->executeSQL($sql);
			}elseif ($_POST["submeter"] == "consultar"){
				$busca = array(
					'1' => array('c' => '1','a' => $a,'coluna' => 'u.ativo', 'valor' => '1'),
					'2' => array('c' => '1','a' => $a,'coluna' => 'u.ativo', 'valor' => '0'),
					'3' => array('c' => '2','a' => $a,'coluna' => 'dta_admissao', 'valor' => @$_POST['busca_valor']),
					'4' => array('c' => '2','a' => $a,'coluna' => 'dta_demissao', 'valor' => @$_POST['busca_valor']),
					'5' => array('c' => '1','a' => $a,'coluna' => 'dta_nascimento', 'valor' => @$_POST['busca_valor']),
					'6' => array('c' => '1','a' => $a,'coluna' => 'u.departamento', 'valor' => @$_POST['busca_valor']),	
					'7' => array('c' => '1','a' => $a,'coluna' => 'u.tipo', 'valor' => @$_POST['busca_valor']),
					'8' => array('c' => '1','a' => $a,'coluna' => 'u.cargo', 'valor' => @$_POST['busca_valor']),
					'9' => array('c' => '2','a' => $a,'coluna' => 'cpf', 'valor' => @$_POST['busca_valor']),
					'10' => array('c' => '2','a' => $a,'coluna' => 'nome', 'valor' => @$_POST['busca_valor']),
					'11' => array('c' => '2','a' => $a,'coluna' => 'email', 'valor' => @$_POST['busca_valor']),
					'12' => array('c' => '1','a' => $a,'coluna' => 'u.empresa', 'valor' => @$_POST['busca_valor']),
					'13' => array('c' => '5', 'a' => $a,'coluna' => 'u.dta_ult_ini_ferias', 'valor' => @$_POST['busca_valor'], 'de' => @$_POST['busca_de'], 'ate' => @$_POST['busca_ate']),
					'14' => array('c' => '5', 'a' => $a,'coluna' => 'u.dta_ult_fim_ferias', 'valor' => @$_POST['busca_valor'], 'de' => @$_POST['busca_de'], 'ate' => @$_POST['busca_ate']),
					'15' => array('c' => '1','a' => $a,'coluna' => 'u.status', 'valor' => '1'),
					'16' => array('c' => '3','a' => $a,'coluna' => "",'valor' => "")
				);
	
				if(isset($busca[$_POST['busca']])){
					$this->dados = array('usuario' => $apiUsuario->filtroUsuario($busca[$_POST['busca']]['c'], $busca[$_POST['busca']]['a'], $busca[$_POST['busca']]['coluna'], $busca[$_POST['busca']]['valor'],"",@$busca[$_POST['busca']]['de'],@$busca[$_POST['busca']]['ate']));
					$_SESSION['filtro_sessao'] = array('c' => $busca[$_POST['busca']]['c'], 'a' => $busca[$_POST['busca']]['a'], 'coluna' => $busca[$_POST['busca']]['coluna'], 'busca_valor' => $busca[$_POST['busca']]['valor'], 'de' => isset($_POST['busca_de']) ? $_POST['busca_de'] : "", 'ate' => isset($_POST['busca_ate']) ? $_POST['busca_ate'] : "", 'busca' => $_POST['busca']);
					$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					header('location:' .APP_ROOT. 'adm/index/index/acessonegado');
					die();
				}
			}elseif ($_POST["submeter"] == "alterar"){
				$ge = $apiUsuario->getGestoresempresa();
				foreach ($ge as $rs){
					$ges["{$rs->EMPRESA}"]["{$rs->USUARIO}"] =  $rs->USUARIO;
				}
				$empresa = $_POST["empresa_usuario"];
				@$usuarios = $_POST["usuario"];
				$sql = array();
				$i = 0;
				if ((is_array($empresa) ? count($empresa) : 0) > 0){
					foreach ($empresa as $rs){
						if (isset($usuarios)){
							foreach ($usuarios as $u){
								if (!isset($ges["{$rs}"]["{$u}"])){
									$usuario = new Usuario();
									$usuario->usuario = $u;
									$usuario->empresa = $rs;
									$sql[$i] = $apiUsuario->addGestor($usuario);
									$i = $i + 1;
								}
							}
							foreach ($ges["{$_SESSION['empresa_sessao']}"] as $u){
								if (!in_array("{$u}", $_POST["usuario"])){
									if (isset($ges["{$rs}"]["{$u}"])){
										$usuario = new Usuario();
										$usuario->usuario = $u;
										$usuario->empresa = $rs;
										$sql[$i] = $apiUsuario->delGestor($usuario);
										$i = $i + 1;
									}
								}
							}
						}else{
							foreach ($ges["{$_SESSION['empresa_sessao']}"] as $r){
								if (isset($ges["{$rs}"]["{$r}"])){
									$usuario = new Usuario();
									$usuario->usuario = $r;
									$usuario->empresa = $rs;
									$sql[$i] = $apiUsuario->delGestor($usuario);
									$i = $i + 1;
								}
							}
						}
					}
				}
				$apiUsuario->executeSQL($sql);
				if ($PaginaAtual > 1) {
					header('location:' .APP_ROOT. 'adm/usuario/index/pagina/'.$PaginaAtual.'/sucesso');
				}else {
					header('location:' .APP_ROOT. 'adm/usuario/index/sucesso');
				}
			}
		}else{
			$endereco = explode('/', $_SERVER ['REQUEST_URI']);
			if(end($endereco) == "sucesso"){
				$this->dados = array('usuario' => $apiUsuario->filtroUsuario($_SESSION['filtro_sessao']['c'],$_SESSION['filtro_sessao']['a'],$_SESSION['filtro_sessao']['coluna'], $_SESSION['filtro_sessao']['busca_valor'], "", $_SESSION['filtro_sessao']['de'], $_SESSION['filtro_sessao']['ate']));
				$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
			}else{
				if (isset($_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']])){
					$this->dados = $_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']];
				}else{
					unset($_SESSION['filtro_sessao']);
					unset($_SESSION['consulta_sessao']);
					$this->dados = array('usuario' => $apiUsuario->filtroUsuario('1','3','u.ativo', '1'));
					$_SESSION['filtro_sessao'] = array('c' => '1', 'a' => '3', 'coluna' => 'u.ativo' , 'busca_valor' => 1,'de' => "", 'ate' => "",'busca' => '16');
					$_SESSION['consulta_sessao'][$this->getModule()['modulo'].$this->getController()['controle']] = $this->dados;
				}
			}
			$result = $apiUsuario->getGestoresempresa($_SESSION['empresa_sessao']);
			foreach ($result as $rs){
				$this->usuarios_empresa[] = array('usuario' => $rs->USUARIO, 'nome' => $rs->NOME, 'des_tipo' => $rs->DES_TIPO);
			}
		}
		$TotalItem = (is_array($this->dados['usuario']) ? count($this->dados['usuario']) : 0);
		$this->dados['usuario'] = array_chunk($this->dados['usuario'], $ItemPorPagina);
		@$this->dados['usuario'] = $this->dados['usuario'][$PaginaAtual - 1];
		if ($TotalItem > $ItemPorPagina) {
			$paginator = new Paginator();
			$this->paginacao = $paginator->navPaginator($this->getModule()['des_modulo'], $this->getController()['des_controle'], $this->getAction()['des_acao'], $PaginaAtual, $ItemPorPagina, $TotalItem);
			$this->PaginaAtual = $PaginaAtual;
		}
		$this->view();
	}

	public function adicionar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Cadastro de Usuario";
		$apiUsuario = new apiUsuario();
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		$apiTipo = new apiTipo();
		$this->tipo = $apiTipo->filtroTipo("1","3","ativo","1");
		$apiDepartamento = new apiDepartamento();
		$this->departamento  = $apiDepartamento->filtroDepartamento("1","3","d.ativo","1");
		$apiCargo = new apiCargo();
		$this->cargo = $apiCargo->filtroCargo('1','3','ativo', '1');
		$apiEmpresa = new apiEmpresa();
		$this->empresa = $apiEmpresa->filtroEmpresa("1","3","ativo","1");
		$apiFuncao = new apiFuncao();
		$func = $apiFuncao->filtroFuncao("1","3","f.ativo","1");
		$this->funcao = array();
		foreach ($func as $rs){
			$this->modulo_funcao[$rs->MODULO] = array('modulo' => $rs->MODULO, 'des_modulo' => $rs->DES_REDUZIDA);
			$this->funcao[$rs->MODULO][$rs->FUNCAO] = array('modulo' => $rs->MODULO, 'funcao' => $rs->FUNCAO, 'des_funcao' => $rs->DES_FUNCAO);
		}
		$apiModulo = new apiModulo();
		$this->modulo = $apiModulo->filtroModulo("1","3","ativo","1");
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$funcoes = new Funcoes();
			$Post = new Usuario('POST');
			$Post->cpf = $funcoes->naoNumerico($Post->cpf);
			$Post->email = strtolower($funcoes->retiraAcentos(trim($Post->email)));
			$Post->telefone = $funcoes->naoNumerico($Post->telefone);
			$Post->celular = $funcoes->naoNumerico($Post->celular);
			$Post->ip = $funcoes->naoNumerico($Post->ip);
			$Post->dta_cadastro = date('d/m/Y H:i:s');
			$Post->dta_ult_alteracao = date('d/m/Y H:i:s');
			$apiUsuario = new apiUsuario();
			$rs = $apiUsuario->filtroUsuario('1','3',"cpf",$Post->cpf);
			if ((is_array($rs) ? count($rs) : 0) > 0){
				$this->rollback = new Usuario('POST');
				if (isset($_POST['funcao'])){
					foreach ($_POST['funcao'] as $rs){
						$this->funcao_rollback["{$rs}"] = $rs;
					}
				}
				if (isset($_POST['modulo'])){
					foreach ($_POST['modulo'] as $rs){
						$this->modulo_rollback[$rs] = $rs;
					}
				}
				$this->Alert = "J� existe um usuario com esse cpf cadastrado!";
			}else{
				$exp = explode("@", $Post->email);
				$rs = $apiUsuario->filtroUsuario('4','3','email',"{$exp[0]}@");
				if ((is_array($rs) ? count($rs) : 0) > 0){
					$this->rollback = new Usuario('POST');
					if (isset($_POST['funcao'])){
						foreach ($_POST['funcao'] as $rs){
							$this->funcao_rollback["{$rs}"] = $rs;
						}
					}
					if (isset($_POST['modulo'])){
						foreach ($_POST['modulo'] as $rs){
							$this->modulo_rollback[$rs] = $rs;
						}
					}
					$this->Alert = "J� existe um usuario com esse email cadastrado!";
				}else{
					$sql[$i] = $apiUsuario->addUsuario($Post);
					$i = $i+1;
					$log = new Log();
					$log->usuario = $_SESSION['usuario_sessao'];
					$log->modulo = $this->getModule()['modulo'];
					$log->controle = $this->getController()['controle'];
					$log->acao = $this->getAction()['acao'];
					$log->empresa = $_SESSION['empresa_sessao'];
					$log->tipo = "I";
					$log->dta_registro = date("d/m/Y H:i:s");
					$log->historico = "TIPO||{$Post->tipo};;DEPARTAMENTO||{$Post->departamento};;CARGO||{$Post->cargo};;CPF||{$Post->cpf};;NOME||{$Post->nome};;DTA_NASCIMENTO||{$Post->dta_nascimento};;DTA_ADMISSAO||{$Post->dta_admissao};;DTA_DEMISSAO||{$Post->dta_demissao};;EMAIL||{$Post->email};;TELEFONE||{$Post->telefone};;CELULAR||{$Post->celular};;IP||{$Post->ip};;EMPRESA||{$Post->empresa};;ATIVO||{$Post->ativo};;DTA_CADASTRO||{$Post->dta_cadastro};;DEG||{$Post->deg}";
					$apiLog = new apiLog();
					$funcaousuario = new Funcao();
					$usuario = array('coluna' => 'usuario','tabela' => 'sis_usuario');
					if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-2"])){
						if (isset($_POST['funcao'])){
							foreach ($_POST['funcao'] as $rs) {
								$exp = explode(",", $rs);
								$funcaousuario->modulo = $exp[0];
								$funcaousuario->funcao =$exp[1];
								$sql[$i] = $apiFuncao->addFuncaousuario($funcaousuario,$usuario);
								$i = $i+1;
							}
						}
					}
					if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-3"])){
						if (isset($_POST['modulo'])){
							foreach ($_POST['modulo'] as $rs) {
								$Post->modulo = $rs;
								$sql[$i] = $apiUsuario->addModulousuario($Post,$usuario);
								$i = $i+1;
							}
						}
					}
					$sql[$i] = $apiLog->addLog($log);
					$rs = $apiUsuario->executeSQL($sql);
					if (@$rs[4] == 'sucesso') {
						//Cria��o de Usu�rio na AD
						$adldap = new \adLDAP($options);
						$surname = explode(" ", strtolower($Post->nome));
						$attributes = array(
							"username" => current(explode("@", $Post->email)),
							"logon_name" => current(explode("@", $Post->email))."@grupomonaco.local",
							"display_name" => current(explode("@", $Post->email)),
							"firstname" => current(explode(" ", strtolower($Post->nome))),
							"surname" => end($surname),
							"email" => $Post->email,
							"enabled" => true,
							"container" => array("Usuarios"),
							"password" => strtoupper(substr($Post->nome, 0, 1)) . strtolower(substr($Post->nome, 1, 1)) . str_replace(array(".", "-", " "), "", $Post->cpf),
						);
						try {
							$adldap->user()->create($attributes);
							$adldap->group()->addUser("grupo1", current(explode("@", $Post->email)));
						} catch (\adLDAPException $e) {
							echo "n�o foi poss�vel criar o usu�rio e adiciona-lo no grupo {$e}";
						}
						
						//Cria��o de Usu�rio Pandion
						$pandion = new Pandion();
						$pandion->username = current(explode("@", $Post->email));
						$pandion->password =substr(ucfirst($Post->nome), 0, 2).$Post->cpf;
						$apiPandion = new apiPandion();
						$apiPandion->addUsuario($pandion);
						if (isset($this->PaginaAtual)) {
							header('location:' .APP_ROOT. 'adm/usuario/index/pagina/'.$this->PaginaAtual.'/sucesso');
						}else {
							header('location:' .APP_ROOT. 'adm/usuario/index/sucesso');
						}
					}else{
						$this->rollback = new Usuario('POST');
						if (isset($_POST['funcao'])){
							foreach ($_POST['funcao'] as $rs){
								$this->funcao_rollback["{$rs}"] = $rs;
							}
						}
						if (isset($_POST['modulo'])){
							foreach ($_POST['modulo'] as $rs){
								$this->modulo_rollback[$rs] = $rs;
							}
						}
						$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
						$erro = str_replace($retirar, "", $rs[2]);
						$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
					}
				}
			}
		}

		$this->view();
	}

	public function alterar() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Altera��o de Usuario";
		$usuario = new Usuario();
		$usuario->usuario = $this->getParams(0);
		$apiUsuario = new apiUsuario();
		$this->dados = array('usuario' => $apiUsuario->getUsuario($usuario));
		if (isset($this->dados['usuario'])){
			if ($this->dados['usuario']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'adm/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'adm/index/index/acessonegado');
			die();
		}
		$apiTipo = new apiTipo();
		$this->tipo = $apiTipo->filtroTipo("1","3","ativo","1");
		$apiDepartamento = new apiDepartamento();
		$this->departamento  = $apiDepartamento->filtroDepartamento("1","3","d.ativo","1");
		$apiCargo = new apiCargo();
		$this->cargo = $apiCargo->filtroCargo('1','3','ativo', '1');
		$apiEmpresa = new apiEmpresa();
		$this->empresa = $apiEmpresa->filtroEmpresa("1","3","ativo","1");
		$apiFuncao = new apiFuncao();
		$func = $apiFuncao->filtroFuncao("1","3","f.ativo","1");
		$this->funcao = array();
		foreach ($func as $rs){
			$this->modulo_funcao[$rs->MODULO] = array('modulo' => $rs->MODULO, 'des_modulo' => $rs->DES_REDUZIDA);
			$this->funcao[$rs->MODULO][$rs->FUNCAO] = array('modulo' => $rs->MODULO, 'funcao' => $rs->FUNCAO, 'des_funcao' => $rs->DES_FUNCAO);
		}
		$funca = $apiFuncao->funcaoUsuario($usuario);
		foreach ($funca as $rs){
			$this->funcao_usuario["{$rs->MODULO},{$rs->FUNCAO}"] = true;
		}
		$apiModulo = new apiModulo();
		$this->modulo = $apiModulo->filtroModulo("1","3","ativo","1");
		$modul = $apiUsuario->getModulousuario($usuario);
		foreach ($modul as $rs){
			$this->usuario_modulo[$rs->MODULO] = true;
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$anterior = "";
			$atual = "::";
			$sql = array();
			$funcoes = new Funcoes();
			$Post = new Usuario();
			$Post->usuario = $this->getParams(0);
			if ($this->dados['usuario']->TIPO != $_POST['tipo']){
				$Post->tipo = $_POST['tipo'];
				$anterior .= "TIPO||{$this->dados['usuario']->TIPO};;";
				$atual .= "TIPO||{$Post->tipo};;";
			}
			if ($this->dados['usuario']->DEPARTAMENTO != $_POST['departamento']){
				$Post->departamento = $_POST['departamento'];
				$anterior .= "DEPARTAMENTO||{$this->dados['usuario']->DEPARTAMENTO};;";
				$atual .= "DEPARTAMENTO||{$Post->departamento};;";
			}
			if ($this->dados['usuario']->CARGO != $_POST['cargo']){
				$Post->cargo = $_POST['cargo'];
				$anterior .= "CARGO||{$this->dados['usuario']->CARGO};;";
				$atual .= "CARGO||{$Post->cargo};;";
			}
			if ($this->dados['usuario']->CPF != $funcoes->naoNumerico($_POST['cpf'])){
				$Post->cpf = $funcoes->naoNumerico($_POST['cpf']);
				$anterior .= "CPF||{$this->dados['usuario']->CPF};;";
				$atual .= "CPF||{$Post->cpf};;";
			}
			if (strtolower($this->dados['usuario']->NOME) != strtolower($funcoes->retiraAcentos(trim($_POST['nome'])))){
				$Post->nome = strtolower($funcoes->retiraAcentos(trim($_POST['nome'])));
				$anterior .= "NOME||{$this->dados['usuario']->NOME};;";
				$atual .= "NOME||{$Post->nome};;";
			}
			if ($this->dados['usuario']->DTA_NASCIMENTO != $_POST['dta_nascimento']){
				$Post->dta_nascimento = $_POST['dta_nascimento'];
				$anterior .= "DTA_NASCIMENTO||{$this->dados['usuario']->DTA_NASCIMENTO};;";
				$atual .= "DTA_NASCIMENTO||{$Post->dta_nascimento};;";
			}
			if ($this->dados['usuario']->DTA_ADMISSAO != $_POST['dta_admissao']){
				$Post->dta_admissao = $_POST['dta_admissao'];
				$anterior .= "DTA_ADMISSAO||{$this->dados['usuario']->DTA_ADMISSAO};;";
				$atual .= "DTA_ADMISSAO||{$Post->dta_admissao};;";
			}
			if ($this->dados['usuario']->DTA_DEMISSAO != $_POST['dta_demissao']){
				$Post->dta_demissao = $_POST['dta_demissao'];
				$anterior .= "DTA_DEMISSAO||{$this->dados['usuario']->DTA_DEMISSAO};;";
				$atual .= "DTA_DEMISSAO||{$Post->dta_demissao};;";
			}
			if ($this->dados['usuario']->DTA_ULT_INI_FERIAS != $_POST['dta_ult_ini_ferias']){
				$Post->dta_ult_ini_ferias = $_POST['dta_ult_ini_ferias'];
				$anterior .= "DTA_ULT_INI_FERIAS||{$this->dados['usuario']->DTA_ULT_INI_FERIAS};;";
				$atual .= "DTA_ULT_INI_FERIAS||{$Post->dta_ult_ini_ferias};;";
			}
			if ($this->dados['usuario']->DTA_ULT_FIM_FERIAS != $_POST['dta_ult_fim_ferias']){
				$Post->dta_ult_fim_ferias = $_POST['dta_ult_fim_ferias'];
				$anterior .= "DTA_ULT_FIM_FERIAS||{$this->dados['usuario']->DTA_ULT_FIM_FERIAS};;";
				$atual .= "DTA_ULT_FIM_FERIAS||{$Post->dta_ult_fim_ferias};;";
			}
			if ($this->dados['usuario']->EMAIL != trim($_POST['email'])){
				$Post->email = $_POST['email'];
				$anterior .= "EMAIL||{$this->dados['usuario']->EMAIL};;";
				$atual .= "EMAIL||{$Post->email};;";
			}
			if (isset($_POST['senha']) && strlen($_POST['senha']) < 32 ){
				$Post->senha = $_POST['senha'];
				$anterior .= "SENHA||{$this->dados['usuario']->SENHA};;";
				$atual .= "SENHA||{$Post->senha};;";
			}
			if ($this->dados['usuario']->TELEFONE != $funcoes->naoNumerico($_POST['telefone'])){
				$Post->telefone = $funcoes->naoNumerico($_POST['telefone']);
				$anterior .= "TELEFONE||{$this->dados['usuario']->TELEFONE};;";
				$atual .= "TELEFONE||{$Post->telefone};;";
			}
			if ($this->dados['usuario']->CELULAR != $funcoes->naoNumerico($_POST['celular'])){
				$Post->celular = $funcoes->naoNumerico($_POST['celular']);
				$anterior .= "CELULAR||{$this->dados['usuario']->CELULAR};;";
				$atual .= "CELULAR||{$Post->celular};;";
			}
			if ($this->dados['usuario']->IP != $funcoes->naoNumerico($_POST['ip'])){
				$Post->ip = $funcoes->naoNumerico($_POST['ip']);
				$anterior .= "IP||{$this->dados['usuario']->IP};;";
				$atual .= "IP||{$Post->ip};;";
			}
			if ($this->dados['usuario']->CONTRATO != $funcoes->naoNumerico($_POST['contrato'])){
				$Post->contrato = $funcoes->naoNumerico($_POST['contrato']);
				$anterior .= "CONTRATO||{$this->dados['usuario']->CONTRATO};;";
				$atual .= "CONTRATO||{$Post->contrato};;";
			}
			if ($this->dados['usuario']->EMPRESA != $_POST['empresa']){
				$Post->empresa = $_POST['empresa'];
				$anterior .= "EMPRESA||{$this->dados['usuario']->EMPRESA};;";
				$atual .= "EMPRESA||{$Post->empresa};;";
			}
			if ($this->dados['usuario']->ATIVO != $_POST['ativo']){
				$Post->ativo = $_POST['ativo'];
				$anterior .= "ATIVO||{$this->dados['usuario']->ATIVO};;";
				$atual .= "ATIVO||{$Post->ativo};;";
			}
			if ($this->dados['usuario']->DEG != $_POST['deg']){
				$Post->deg = $_POST['deg'];
				$anterior .= "DEG||{$this->dados['usuario']->DEG};;";
				$atual .= "DEG||{$Post->deg};;";
			}
			$Post->dta_ult_alteracao = date('d/m/Y H:i:s');
			$rs = $apiUsuario->filtroUsuario('1','3','cpf',$Post->cpf);
			if ((is_array($rs) ? count($rs) : 0) > 0 && ($rs[0]->CPF != $this->dados['usuario']->CPF)){
				$this->dados['usuario']->TIPO = $Post->tipo;
				$this->dados['usuario']->DEPARTAMENTO = $Post->departamento;
				$this->dados['usuario']->CARGO = $Post->cargo;
				$this->dados['usuario']->CPF = $Post->cpf;
				$this->dados['usuario']->NOME = $Post->nome;
				$this->dados['usuario']->DTA_NASCIMENTO = $Post->dta_nascimento;
				$this->dados['usuario']->DTA_ADMISSAO = $Post->dta_admissao;
				$this->dados['usuario']->EMAIL = $Post->email;
				$this->dados['usuario']->SENHA = $Post->senha;
				$this->dados['usuario']->TELEFONE = $Post->telefone;
				$this->dados['usuario']->CELULAR = $Post->celular;
				$this->dados['usuario']->IP = $Post->ip;
				$this->dados['usuario']->EMPRESA = $Post->empresa;
				$this->dados['usuario']->ATIVO = $Post->ativo;
				if (isset($_POST['funcao'])){
					foreach ($_POST['funcao'] as $rs){
						$this->funcao_usuario["{$rs}"] = true;
					}
				}
				if (isset($_POST['modulo'])){
					foreach ($_POST['modulo'] as $rs){
						$this->usuario_modulo[$rs] = true;
					}
				}
				$this->Alert = "J� existe um usuario com esse cpf cadastrado!";
			}else{
				$exp = explode("@", $Post->email);
				$rs = $apiUsuario->filtroUsuario('4','3','email',"{$exp[0]}@");
				if ((is_array($rs) ? count($rs) : 0) > 0 && ($rs[0]->EMAIL != $this->dados['usuario']->EMAIL)){
					$this->dados['usuario']->TIPO = $Post->tipo;
					$this->dados['usuario']->DEPARTAMENTO = $Post->departamento;
					$this->dados['usuario']->CARGO = $Post->cargo;
					$this->dados['usuario']->CPF = $Post->cpf;
					$this->dados['usuario']->NOME = $Post->nome;
					$this->dados['usuario']->DTA_NASCIMENTO = $Post->dta_nascimento;
					$this->dados['usuario']->DTA_ADMISSAO = $Post->dta_admissao;
					$this->dados['usuario']->EMAIL = $Post->email;
					$this->dados['usuario']->SENHA = $Post->senha;
					$this->dados['usuario']->TELEFONE = $Post->telefone;
					$this->dados['usuario']->CELULAR = $Post->celular;
					$this->dados['usuario']->IP = $Post->ip;
					$this->dados['usuario']->EMPRESA = $Post->empresa;
					$this->dados['usuario']->ATIVO = $Post->ativo;
					if (isset($_POST['funcao'])){
						foreach ($_POST['funcao'] as $rs){
							$this->funcao_usuario["{$rs}"] = true;
						}
					}
					if (isset($_POST['modulo'])){
						foreach ($_POST['modulo'] as $rs){
							$this->usuario_modulo[$rs] = true;
						}
					}
					$this->Alert = "J� existe um usuario com esse email cadastrado!";
				}else{
					$sql[$i] = $apiUsuario->editUsuario($Post);
					$i = $i+1;
					$log = new Log();
					$log->usuario = $_SESSION['usuario_sessao'];
					$log->modulo = $this->getModule()['modulo'];
					$log->controle = $this->getController()['controle'];
					$log->acao = $this->getAction()['acao'];
					$log->empresa = $_SESSION['empresa_sessao'];
					$log->tipo = "A";
					$log->dta_registro = date("d/m/Y H:i:s");
					$apiLog = new apiLog();
					$funcaousuario = new Funcao();
					$funcaousuario->usuario = $Post->usuario;
					if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-2"])){
						if ((is_array($funca) ? count($funca) : 0) > 0 || (is_array($_POST['funcao']) ? count($_POST['funcao']) : 0) > 0 ){
							$postfuncao = array();
							foreach ($_POST['funcao'] as $rs) {
								$postfuncao["{$rs}"] = true;
							}
							foreach ($func as $rs){
								if (isset($postfuncao["{$rs->MODULO},{$rs->FUNCAO}"])){
									if (@$this->funcao_usuario["{$rs->MODULO},{$rs->FUNCAO}"] == NULL){
										$funcaousuario->funcao = $rs->FUNCAO;
										$funcaousuario->modulo = $rs->MODULO;
										$sql[$i] = $apiFuncao->addFuncaousuario($funcaousuario);
										$i = $i+1;
										$anterior .= "FUNCAO{$rs->MODULO},{$rs->FUNCAO}||NAO;;";
										$atual .= "FUNCAO{$rs->MODULO},{$rs->FUNCAO}||SIM;;";
									}
								}elseif (!isset($postfuncao["{$rs->MODULO},{$rs->FUNCAO}"])){
									if (@$this->funcao_usuario["{$rs->MODULO},{$rs->FUNCAO}"] != NULL){
										$funcaousuario->funcao = $rs->FUNCAO;
										$funcaousuario->modulo = $rs->MODULO;
										$sql[$i] = $apiFuncao->delFuncaousuario($funcaousuario);
										$i = $i+1;
										$anterior .= "FUNCAO{$rs->MODULO},{$rs->FUNCAO}||SIM;;";
										$atual .= "FUNCAO{$rs->MODULO},{$rs->FUNCAO}||NAO;;";
									}
								}
							}
						}
					}
					if (isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-3"])){
						if ((is_array($modul) ? count($modul) : 0) > 0 || (is_array(@$_POST['modulo']) ? count($_POST['modulo']) : 0) > 0 ){
							$postmodulo = array();
							foreach ($_POST['modulo'] as $rs) {
								$postmodulo[$rs] = true;
							}
							foreach ($this->modulo as $rs){
								if (isset($postmodulo[$rs->MODULO])){
									if ($this->usuario_modulo[$rs->MODULO] == NULL){
										$Post->modulo = $rs->MODULO;
										$sql[$i] = $apiUsuario->addModulousuario($Post);
										$i = $i+1;
										$anterior .= "MODULO{$rs->MODULO}||NAO;;";
										$atual .= "MODULO{$rs->MODULO}||SIM;;";
									}
								}elseif (!isset($postmodulo[$rs->MODULO])){
									if ($this->usuario_modulo[$rs->MODULO] != NULL){
										$Post->modulo = $rs->MODULO;
										$sql[$i] = $apiUsuario->delModulousuario($Post);
										$i = $i+1;
										$anterior .= "MODULO{$rs->MODULO}||SIM;;";
										$atual .= "MODULO{$rs->MODULO}||NAO;;";
									}
								}
							}
						}
					}
					$log->historico = substr($anterior,0,-2);
					$log->historico .= substr($atual,0,-2);
					$sql[$i] = $apiLog->addLog($log);
					$rs = $apiUsuario->executeSQL($sql);
					if (@$rs[4] == 'sucesso') {
						if ($Post->senha != ""){
							$adldap = new \adLDAP();
							$Username= current(explode("@", $this->dados['usuario']->EMAIL));
							$Senha = $_POST['senha'];
							try {
								$adldap->user()->password($Username, $Senha);
								if ($Post->ativo != ""){
									if ($Post->ativo == 1){
										$adldap->user()->modify($Username, array('enabled' => true));
									}else{
										$adldap->user()->modify($Username, array('enabled' => false));
									}
								}
							} catch (\adLDAPException $e) {
								echo "n�o foi poss�vel alterar a senha do {$Username} {$e}";
							}
							//Editar Usu�rio Pandion
							$pandion = new Pandion();
							$pandion->username = $Username;
							$pandion->password = $_POST['senha'];
							$apiPandion = new apiPandion();
							$apiPandion->editUsuario($pandion);
						}elseif ($Post->ativo != ""){
							$pandion = new Pandion();
							$adldap = new \adLDAP();
							$Username = current(explode("@", $this->dados['usuario']->EMAIL));
							$Senha = $_POST['senha'];
							try {
								$adldap->user()->password($Username, $Senha);
								if ($Post->ativo != ""){
									if ($Post->ativo == 1){
										$adldap->user()->modify($Username, array('enabled' => true));
										$pandion->password = $pandion->password = substr(ucfirst($this->dados['usuario']->NOME), 0, 2).trim($this->dados['usuario']->CPF);
									}else{
										$adldap->user()->modify($Username, array('enabled' => false));
										$pandion->password = $funcoes->senhaAleatoria();
									}
								}
							} catch (\adLDAPException $e) {
								echo "n�o foi poss�vel ativar ou desativar o {$Username} {$e}";
							}
							//Editar Usu�rio Pandion
							$pandion->username = $Username;
							$apiPandion = new apiPandion();
							$apiPandion->editUsuario($pandion);
						}
						if (isset($this->PaginaAtual)) {
							header('location:' .APP_ROOT. 'adm/usuario/index/pagina/'.$this->PaginaAtual.'/sucesso');
							die();
						}else {
							header('location:' .APP_ROOT. 'adm/usuario/index/sucesso');
							die();
						}
					}else{
						$this->dados['usuario']->TIPO = $Post->tipo;
						$this->dados['usuario']->DEPARTAMENTO = $Post->departamento;
						$this->dados['usuario']->CARGO = $Post->cargo;
						$this->dados['usuario']->CPF = $Post->cpf;
						$this->dados['usuario']->NOME = $Post->nome;
						$this->dados['usuario']->DTA_NASCIMENTO = $Post->dta_nascimento;
						$this->dados['usuario']->DTA_ADMISSAO = $Post->dta_admissao;
						$this->dados['usuario']->EMAIL = $Post->email;
						$this->dados['usuario']->SENHA = $Post->senha;
						$this->dados['usuario']->TELEFONE = $Post->telefone;
						$this->dados['usuario']->CELULAR = $Post->celular;
						$this->dados['usuario']->IP = $Post->ip;
						$this->dados['usuario']->EMPRESA = $Post->empresa;
						$this->dados['usuario']->ATIVO = $Post->ativo;
						if (isset($_POST['funcao'])){
							foreach ($_POST['funcao'] as $i1){
								$this->funcao_usuario["{$i1}"] = true;
							}
						}
						if (isset($_POST['modulo'])){
							foreach ($_POST['modulo'] as $i2){
								$this->usuario_modulo[$i2] = true;
							}
						}
						$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
						$erro = str_replace($retirar, "", $rs[2]);
						$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
					}
				}
			}
		}
		$this->view();
	}
	public function excluir() {
		$this->title = "SisMonaco - ".ucfirst($this->getModule()['des_modulo']);
		$this->header = "Exclus�o de Usuario";
		$usuario = new Usuario();
		$usuario->usuario = $this->getParams(0);
		$apiUsuario = new apiUsuario();
		$this->dados = array('usuario' => $apiUsuario->getUsuario($usuario));
		if (isset($this->dados['usuario'])){
			if ($this->dados['usuario']->ATIVO == '0'){
				if (!isset($_SESSION['funcao_sessao']["{$this->getModule()['modulo']}-1"])){
					header('location:' .APP_ROOT. 'adm/index/index/acessonegado');
					die();
				}
			}
		}else{
			header('location:' .APP_ROOT. 'adm/index/index/acessonegado');
			die();
		}
		$ItemPorPagina = 10;
		$PaginaAtual = 1;
		if ($this->getParams(1) > $PaginaAtual) {
			$PaginaAtual = $this->getParams(1);
			$this->PaginaAtual = $PaginaAtual;
		}
		if ($_SERVER['REQUEST_METHOD'] === 'POST') {
			$i = 0;
			$sql = array();
			$sql[$i] = $apiUsuario->delUsuario($usuario);
			$i = $i+1;
			$log = new Log();
			$log->usuario = $_SESSION['usuario_sessao'];
			$log->modulo = $this->getModule()['modulo'];
			$log->controle = $this->getController()['controle'];
			$log->acao = $this->getAction()['acao'];
			$log->empresa = $_SESSION['empresa_sessao'];
			$log->tipo = "E";
			$log->dta_registro = date("d/m/Y H:i:s");
			$log->historico = "USUARIO||{$this->dados['usuario']->USUARIO};;TIPO||{$this->dados['usuario']->TIPO};;DEPARTAMENTO||{$this->dados['usuario']->DEPARTAMENTO};;CARGO||{$this->dados['usuario']->CARGO};;CPF||{$this->dados['usuario']->CPF};;NOME||{$this->dados['usuario']->NOME};;DTA_NASCIMENTO||{$this->dados['usuario']->DTA_NASCIMENTO};;DTA_ADMISSAO||{$this->dados['usuario']->DTA_ADMISSAO};;DTA_DEMISSAO||{$this->dados['usuario']->DTA_DEMISSAO};;EMAIL||{$this->dados['usuario']->EMAIL};;TELEFONE||{$this->dados['usuario']->TELEFONE};;CELULAR||{$this->dados['usuario']->CELULAR};;IP||{$this->dados['usuario']->IP};;EMPRESA||{$this->dados['usuario']->EMPRESA};;ATIVO||{$this->dados['usuario']->ATIVO};;DTA_CADASTRO||{$this->dados['usuario']->DTA_CADASTRO};;DTA_ULT_ACESSO||{$this->dados['usuario']->DTA_ULT_ACESSO}";
			$apiLog = new apiLog();
			$sql[$i] = $apiLog->addLog($log);
			$rs = $apiUsuario->executeSQL($sql);
			if (@$rs[4] == 'sucesso') {
				if (isset($this->PaginaAtual)) {
					header('location:' .APP_ROOT. 'adm/usuario/index/pagina/'.$this->PaginaAtual.'/sucesso');
					die();
				}else {
					header('location:' .APP_ROOT. 'adm/usuario/index/sucesso');
					die();
				}
			}else{
				$retirar = array("OCIStmtExecute:", "(ext\pdo_oci\oci_driver.c:358)");
				$erro = str_replace($retirar, "", $rs[2]);
				$this->Alert = "Opera��o n�o pode ser executada ({$erro})";
			}
		}
		$this->view();
	}
}