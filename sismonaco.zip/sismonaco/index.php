<?php

set_time_limit(0);
ini_set('memory_limit', '2000M');
setlocale(LC_TIME, 'pt_BR', 'pt_BR.utf-8', 'pt_BR.utf-8', 'portuguese');
date_default_timezone_set('America/Belem');

session_start();

header ('Content-type: text/html; charset=ISO-8859-1');

if (isset($_POST)){
	foreach ($_POST as $in => $va){
		$_POST[$in] = str_replace("'", "\\'", $va);
	}
}

require_once 'helper/Bootstrap.php';
define('RAIZ_PATH', 'sismonaco/');
define('APP_ROOT', 'http'.(isset($_SERVER['HTTPS']) ? (($_SERVER['HTTPS']=="on") ? "s" : "") : "").'://' . $_SERVER['HTTP_HOST'] . '/'. RAIZ_PATH . '');

use lib\System;

$System = new System();
$System->run();