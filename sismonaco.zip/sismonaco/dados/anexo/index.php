<?php

if (!isset($_SESSION['usuario_sessao']) || empty($_SESSION['usuario_sessao'])) {
	
	header('location: ../../');
	
}