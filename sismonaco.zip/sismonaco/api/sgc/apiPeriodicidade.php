<?php

namespace api\sgc;

use lib\Model;
use obj\sgc\Periodicidade;
use helper\PrepareSQL;
use helper\Funcoes;

class apiPeriodicidade extends Model {

	public function getPeriodicidade(Periodicidade$obj) {
		return  $this->First($this->Select("SELECT * FROM sgc_periodicidade WHERE periodicidade = '{$obj->periodicidade}'"));
		
		
	}
	public function filtroPeriodicidade($c, $a, $coluna = NULL, $val = NULL) {
		$val = strtolower(trim($val));
		$condicao = array(
			'1'	=> " WHERE LOWER(p.{$coluna}) = '{$val}' ",
			'2' => " WHERE LOWER(p.{$coluna}) LIKE '%{$val}%' ",
			'3'	=> " ",
		);
		$ativo = array(
			'1' => "AND p.ativo = '1' ",
			'2' => "AND p.ativo = '0' ",
			'3' => "",
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT p.periodicidade, p.des_periodicidade, p.ativo
		FROM sgc_periodicidade p{$condicao[$c]}{$ativo[$a]}ORDER BY p.des_periodicidade ASC) R ) R2");
	}
	
	public function addPeriodicidade(Periodicidade $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_periodicidade = strtoupper($funcoes->retiraAcentos(trim($obj->des_periodicidade)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'sgc_periodicidade','periodicidade');
	}
	
	public function editPeriodicidade(Periodicidade $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'periodicidade';}, ARRAY_FILTER_USE_KEY);
		if ((is_array($set) ? count($set) : 0) > 0){
			return $prepare->PrepareUpdate($set,array('periodicidade' => $obj['periodicidade']), 'sgc_periodicidade');
		}
  }
  
  public function delPeriodicidade(Periodicidade $obj) {
  	$prepare = new PrepareSQL();
  	return $prepare->PrepareDelete(array('periodicidade' => $obj->periodicidade), 'sgc_periodicidade');
  }
   public function executeSQL($sql){
  	return $this->Execute($sql);
  }
}