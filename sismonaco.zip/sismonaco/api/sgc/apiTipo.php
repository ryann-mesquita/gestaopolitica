<?php

namespace api\sgc;

use lib\Model;
use obj\sgc\Tipo;
use helper\PrepareSQL;
use helper\Funcoes;

class apiTipo extends Model {

	public function getTipo(Tipo $obj) {
		return  $this->First($this->Select("SELECT * FROM sgc_tipo WHERE tipo = '{$obj->tipo}'"));
		
		
	}
	public function filtroTipo($c, $a, $coluna = NULL, $val = NULL) {
		$val = strtolower(trim($val));
		$condicao = array(
			'1'	=> " WHERE LOWER(t.{$coluna}) = '{$val}' ",
			'2' => " WHERE LOWER(t.{$coluna}) LIKE '%{$val}%' ",
			'3'	=> " ",
		);
		$ativo = array(
			'1' => "AND t.ativo = '1' ",
			'2' => "AND t.ativo = '0' ",
			'3' => "",
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT t.tipo, t.des_tipo, t.ativo
		FROM sgc_tipo t{$condicao[$c]}{$ativo[$a]}ORDER BY t.des_tipo ASC) R ) R2");
	}
	
	public function addTipo(Tipo $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'sgc_tipo','tipo');
	}
	
	public function editTipo(Tipo $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'tipo';}, ARRAY_FILTER_USE_KEY);
		if ((is_array($set) ? count($set) : 0) > 0){
			return $prepare->PrepareUpdate($set,array('tipo' => $obj['tipo']), 'sgc_tipo');
		}
  }
  
  	public function delTipo(Tipo $obj) {
  	$prepare = new PrepareSQL();
  	return $prepare->PrepareDelete(array('tipo' => $obj->tipo), 'sgc_tipo');
  }
   public function executeSQL($sql){
  	return $this->Execute($sql);
  }
}