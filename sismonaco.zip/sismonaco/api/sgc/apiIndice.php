<?php

namespace api\sgc;

use lib\Model;
use obj\sgc\Indice;
use helper\PrepareSQL;
use helper\Funcoes;

class apiIndice extends Model {

	public function getIndice(Indice $obj) {
		return  $this->First($this->Select("SELECT * FROM sgc_indice WHERE indice = '{$obj->indice}'"));
		
		
	}
	public function filtroIndice($c, $a, $coluna = NULL, $val = NULL) {
		$val = strtolower(trim($val));
		$condicao = array(
				'1'	=> " WHERE LOWER(i.{$coluna}) = '{$val}' ",
				'2' => " WHERE LOWER(i.{$coluna}) LIKE '%{$val}%' ",
				'3'	=> " ",
		);
		$ativo = array(
				'1' => "AND i.ativo = '1' ",
				'2' => "AND i.ativo = '0' ",
				'3' => "",
		);
		return $this->Select("SELECT R2.*
				FROM (SELECT rownum n_linha, R.*
				FROM(SELECT i.indice,i.des_reduzida, i.des_indice, i.ativo
				FROM sgc_indice i{$condicao[$c]}{$ativo[$a]}ORDER BY i.des_indice ASC) R ) R2");
	}
	
	public function addIndice(Indice $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_reduzida = strtoupper($funcoes->retiraAcentos(trim($obj->des_reduzida)));
		$obj->des_indice = strtoupper($funcoes->retiraAcentos(trim($obj->des_indice)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'sgc_indice','indice');
	}
	
	public function editIndice(Indice $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'indice';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('indice' => $obj['indice']), 'sgc_indice');
	}
	
	public function delIndice(Indice $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('indice' => $obj->indice), 'sgc_indice');
	}
	
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
	
	
}



