<?php

namespace api\sgc;

use lib\Model;
use obj\sgc\Contrato;
use helper\PrepareSQL;
use obj\sgc\Itemcontrato;
use obj\sgc\Aditivocontrato;

class apiContrato extends Model {

	public function getContrato(Contrato $obj) {
		return  $this->First($this->Select("SELECT c.contrato, c.cod_contrato, c.empresa, c.des_contrato, c.n_contrato, c.fornecedor, f.nome nome_fornecedor,
		c.contratante, u1.nome nome_contratante, c.gestor, u2.nome nome_gestor, c.dta_inicio, c.dta_termino, c.prazo_contrato, c.dias_pagamento, c.opcao_pagamento, c.pagamento, pg.des_pagamento,
		c.periodicidade, p.des_periodicidade, c.tipo, t.des_tipo, c.indice, i.des_indice, c.valor, c.periodo_valor, i.des_reduzida, c.obs, c.alerta1,
		c.alerta2, c.alerta3, c.alerta4, c.alerta5, c.alerta6, c.dta_criacao, c.ativo
		FROM sgc_contrato c
		JOIN sgc_tipo t on c.tipo = t.tipo
		JOIN sgc_periodicidade p on c.periodicidade = p.periodicidade
		JOIN sgc_indice i on c.indice = i.indice
		JOIN sgc_pagamento pg on c.pagamento = pg.pagamento
		JOIN sis_usuario u1 on c.contratante = u1.usuario
		JOIN sis_usuario u2 on c.gestor = u2.usuario
		JOIN fat_cliente f on c.fornecedor = f.cliente
		WHERE c.contrato = '{$obj->contrato}'"));	
	}
	public function getItemcontrato(Contrato $obj){
		return $this->Select("SELECT ic.contrato, ic.item, ic.des_item, ic.val_item, ic.periodo_item, p.des_periodicidade
		FROM sgc_item_contrato ic
		JOIN sgc_periodicidade p ON ic.periodo_item = p.periodicidade
		WHERE ic.contrato = '{$obj->contrato}' ORDER BY ic.contrato ASC, ic.item ASC");
	}
	public function getAditivocontrato(Contrato $obj){
		return $this->Select("SELECT ac.contrato, ac.aditivo, ac.des_aditivo, ac.vigencia, ac.aditivo_anexo, ac.dta_aditivo
		FROM sgc_aditivo_contrato ac
		WHERE ac.contrato = '{$obj->contrato}' ORDER BY ac.contrato ASC, ac.aditivo ASC");
	}
	public function filtroContrato($c, $a, $coluna = NULL, $val = NULL, $de = NULL, $ate = NULL) {
		$val = strtolower(trim($val));
		$condicao = array(
			'1'	=> " WHERE LOWER(c.{$coluna}) = '{$val}' ",
			'2' => " WHERE LOWER(c.{$coluna}) LIKE '%{$val}%' ",
			'3'	=> " ",
			'4' => " WHERE TO_DATE(TO_CHAR(TO_DATE({$coluna}, 'dd/mm/yyyy hh24:mi:ss'), 'dd/mm/yyyy'), 'dd/mm/yyyy') BETWEEN TO_DATE('{$de}','dd/mm/yyyy') AND TO_DATE('{$ate}','dd/mm/yyyy') "
			    	
		); 
		$ativo = array(
			'1' => "AND c.ativo = '1' ",
			'2' => "AND c.ativo = '0' ",
			'3' => "",
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT c.contrato, c.cod_contrato, c.empresa, c.des_contrato, c.n_contrato, c.fornecedor, f.nome nome_fornecedor,
        c.contratante, u1.nome nome_contratante, c.gestor, u2.nome nome_gestor, c.dta_inicio, c.dta_termino, c.prazo_contrato, c.dias_pagamento, c.opcao_pagamento, c.pagamento, pg.des_pagamento, 
        c.periodicidade, p.des_periodicidade, c.tipo, t.des_tipo, c.indice, i.des_indice, c.valor, c.periodo_valor, i.des_reduzida, c.obs, c.alerta1,
		c.alerta2, c.alerta3, c.alerta4, c.alerta5, c.alerta6, c.dta_criacao, c.ativo
		FROM sgc_contrato c
		JOIN sgc_tipo t on c.tipo = t.tipo
		JOIN sgc_periodicidade p on c.periodicidade = p.periodicidade
		JOIN sgc_indice i on c.indice = i.indice
		JOIN sgc_pagamento pg on c.pagamento = pg.pagamento
		JOIN sis_usuario u1 on c.contratante = u1.usuario
		JOIN sis_usuario u2 on c.gestor = u2.usuario
		JOIN fat_cliente f on c.fornecedor = f.cliente	
		{$condicao[$c]}{$ativo[$a]}
        ORDER BY c.des_contrato ASC) R ) R2");
		
	}
	
	public function getCodpadrao($empresa){
		return $this->First($this->Select("select case when empresa in (1,2,3) then 'INFRADBLM'
		when empresa in (4,5,6,7)  then 'INFRAMBLM'
		when empresa in (8,9,10,11,12) then 'INFRADCBA'
		when empresa in (13,14) then 'INFRADTHE'
		when empresa in (15,16,17) then 'INFRADMA'
		when empresa in (19,20,21,22,23,24) then 'INFRAMCBA'
		when empresa in (25,26,27) then 'INFRAMMCP'
		when empresa in (32) then 'INFRADMCP'
		when empresa in (35) then 'INFRAVBR'
		when empresa in (36) then 'INFRAVDOCA'
		when empresa in (37) then 'INFRAVALTAMIRA'
		else 'INFRAHOLDING' end cod
		from sis_empresa where empresa = '{$empresa}'"));
	}
	public function getCodsgc($empresa){
		return $this->First($this->Select("select case when empresa in (1,2,3) then substr(cod_contrato,9)
        when empresa in (4,5,6,7)  then substr(cod_contrato,9)
        when empresa in (8,9,10,11,12) then substr(cod_contrato,9)
        when empresa in (13,14) then substr(cod_contrato,9)
        when empresa in (15,16,17) then substr(cod_contrato,8) 
        when empresa in (19,20,21,22,23,24) then substr(cod_contrato,9)
        when empresa in (25,26,27) then substr(cod_contrato,9)
        when empresa in (32) then substr(cod_contrato,9)
        when empresa in (35) then substr(cod_contrato,8) 
        when empresa in (36) then substr(cod_contrato,10)
        when empresa in (37) then substr(cod_contrato,14)
	    else substr(cod_contrato,13) end cod 
	    from sgc_contrato where empresa = '{$empresa}' order by cod_contrato desc"));
	}
	
	public function addContrato(Contrato $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'sgc_contrato','contrato');
	}
	
	public function addItemcontrato(Itemcontrato $obj,$currval = NULL) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$obj = array_filter($obj, function($v){return $v != 'anexo';}, ARRAY_FILTER_USE_KEY);
		if ($currval != NULL){
			return $prepare->PrepareInsert($obj, 'sgc_item_contrato',"",$currval);
		}else{
			return $prepare->PrepareInsert($obj, 'sgc_item_contrato');
		}
	}
	
	public function addAditivocontrato(Aditivocontrato $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$obj = array_filter($obj, function($v){return $v != 'anexo';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareInsert($obj, 'sgc_aditivo_contrato');
	}
	
	public function editContrato(Contrato $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'contrato';}, ARRAY_FILTER_USE_KEY);
		if ((is_array($set) ? count($set) : 0) > 0){
			return $prepare->PrepareUpdate($set,array('contrato' => $obj['contrato']), 'sgc_contrato');
		}
	}
	
	public function editItemcontrato(Itemcontrato $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'contrato' && $v != 'item' && $v != 'anexo';}, ARRAY_FILTER_USE_KEY);
		if ((is_array($set) ? count($set) : 0) > 0){
			return $prepare->PrepareUpdate($set,array('contrato' => $obj['contrato'], 'item' => $obj['item']), 'sgc_item_contrato');
		}
	}
	
	public function editAditivocontrato(Aditivocontrato $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'contrato' && $v != 'aditivo' && $v != 'anexo';}, ARRAY_FILTER_USE_KEY);
		if ((is_array($set) ? count($set) : 0) > 0){
			return $prepare->PrepareUpdate($set,array('contrato' => $obj['contrato'], 'aditivo' => $obj['aditivo']), 'sgc_aditivo_contrato');
		}
	}
	
	public function delContrato(Contrato $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('contrato' => $obj->contrato), 'sgc_contrato');
	}
	
	public function delItens(Contrato $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('contrato' => $obj->contrato), 'sgc_item_contrato');
	}
	
	public function delAditivo(Contrato $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('contrato' => $obj->contrato), 'sgc_aditivo_contrato');
	}
	
	public function delItemcontrato(Itemcontrato $obj){
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('contrato' => $obj->contrato, 'item' => $obj->item), 'sgc_item_contrato');
	}
	
	public function delAditivocontrato(Aditivocontrato $obj){
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('contrato' => $obj->contrato, 'aditivo' => $obj->aditivo), 'sgc_aditivo_contrato');
	}

	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
	
	
}



