<?php

namespace api\sie;

use lib\Model;
use obj\sie\Frota;
use helper\PrepareSQL;
use helper\Funcoes;
use obj\sie\Infracao;
use obj\sie\Revisao;

class apiFrota extends Model {

	public function getFrota(Frota $obj) {
		return  $this->First($this->Select("SELECT v.empresa, e.des_empresa, v.veiculo, v.cor, v.chassi,v.localizacao, v.modelo, o.ano_fabricacao, o.ano_modelo, 
		o.placa, o.renavam, f.licenciamento, f.marca, f.categoria, f.obs, f.frota
		FROM vei_veiculo v
        LEFT JOIN ofi_ficha_seguimento o on v.chassi = o.chassi
		LEFT JOIN ger_revenda r on  v.empresa = r.empresa AND v.revenda_origem = r.revenda 
 		LEFT JOIN sis_empresa e on r.cnpj = e.cnpj
		LEFT JOIN sie_frota f on v.veiculo = f.frota
        WHERE v.veiculo = '{$obj->frota}'"));
		
	}
	public function filtroFrota($c, $a, $coluna = NULL, $val = NULL, $de = NULL, $ate = NULL) {
		$val = strtolower(trim($val));
		$condicao = array(
			'1'	=> "WHERE SITUACAO = 'IM'",
			'2' => " WHERE LOWER(f.{$coluna}) LIKE '%{$val}%' ",
			'3'	=> " ",
		);
		$ativo = array(
			'1' => "",
			'2' => "AND LOWER(v.{$coluna}) = '{$val}'",
			'3' => "AND LOWER(o.{$coluna}) = '{$val}'",
			'4' => "",
			'5' => "AND LOWER(v.{$coluna}) LIKE '%{$val}%'",
			'6' => " AND TO_DATE(TO_CHAR(TO_DATE({$coluna}, 'dd/mm/yyyy hh24:mi:ss'), 'dd/mm/yyyy'), 'dd/mm/yyyy') BETWEEN TO_DATE('{$de}','dd/mm/yyyy') AND TO_DATE('{$ate}','dd/mm/yyyy')",
			'7' => "AND LOWER(f.{$coluna}) LIKE '%{$val}%'",
			'8' => "AND LOWER(r.{$coluna}) = '{$val}'",
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT v.empresa, e.des_empresa, v.veiculo, v.cor, v.chassi, v.localizacao, v.modelo, o.ano_fabricacao, o.ano_modelo, 
		o.placa, o.renavam, f.licenciamento, f.marca, f.categoria, f.obs
		FROM vei_veiculo v 
		LEFT JOIN ofi_ficha_seguimento o on v.chassi = o.chassi
		LEFT JOIN ger_revenda r on  v.empresa = r.empresa AND v.revenda_origem = r.revenda 
 		LEFT JOIN sis_empresa e on r.cnpj = e.cnpj
		LEFT JOIN sie_frota f on v.veiculo = f.frota
		{$condicao[$c]}{$ativo[$a]}) R ) R2");
	}
	
	public function getInfracao(Frota $obj) {
		return $this->Select("SELECT i.veiculo, i.infracao, i.des_infracao, i.departamento, d.des_departamento, i.situacao, i.valor,i.status,i.anexo,
		i.dta_infracao, i.hora_infracao, i.dta_cadastro, i.usuario, i.autor, u1.nome nome_autor, u2.nome nome_cadastro 
		FROM sie_frota_infracao i  
		LEFT JOIN sis_usuario u1 on i.autor = u1.usuario
		LEFT JOIN sis_usuario u2 on i.usuario = u2.usuario
		LEFT JOIN sis_departamento d on i.departamento = d.departamento
		WHERE i.veiculo = '{$obj->frota}'");
	}
	
	public function getUnidadeInfracao(Infracao $obj){
		return $this->First($this->Select("SELECT i.veiculo, i.infracao, i.des_infracao, i.departamento,
		i.valor, i.anexo, i.situacao, i.dta_infracao, i.hora_infracao, i.dta_cadastro, i.usuario, i.autor, i.status 
		FROM sie_frota_infracao i 
		WHERE i.infracao = '{$obj->infracao}' AND i.veiculo = '{$obj->veiculo}'"));
	}
	
	/*
	public function getRevisao(Frota $obj) {
			return $this->Select("select sv.descricao, u.nome, m.chassi,s.empresa, s.revenda,s.servico_revisao,s.dta_fim_revisao,s.kilometragem, s.nro_os, sv.val_servico
					from ofi_ordem_servico s
					left join ofi_ficha_movimento m on s.nro_os = m.nro_os and s.empresa = m.empresa  and s.revenda = m.revenda
					left join ofi_servico_os sv on s.empresa = sv.empresa and s.revenda = sv.revenda and s.nro_os = sv.nro_os
					left join ger_usuario u on s.usu_fechamento_rev = u.usuario
					where s.servico_revisao = 9 and m.chassi in (select v.chassi from vei_veiculo v
					left JOIN ofi_ficha_seguimento o on v.chassi = o.chassi
					left JOIN sis_empresa e on v.empresa = e.empresa
					LEFT JOIN sie_frota f on v.veiculo = f.frota
					WHERE v.SITUACAO = 'IM') and m.chassi = '{$obj->chassi}'");
	}
	*/
	
	public function getRevisao(Frota $obj){
		return $this->Select("SELECT r.revisao, r.veiculo, r.responsavel, u.nome nome_responsavel, r.departamento, d.des_departamento, r.kilometragem, r.dta_revisao,
		r.valor, r.anexo, r.des_revisao 
		FROM sie_frota_revisao r 
		LEFT JOIN sis_departamento d on r.departamento = d.departamento
		LEFT JOIN sis_usuario u on r.responsavel = u.usuario
		WHERE r.veiculo = '{$obj->frota}'");
	}
	
	public function getUnidadeRevisao(Revisao $obj){
		return $this->first($this->Select("SELECT s.revisao, s.veiculo, s.responsavel, s.departamento, 
		s.kilometragem, s.dta_revisao, s.valor, s.anexo, s.des_revisao
		FROM sie_frota_revisao s WHERE s.revisao = '{$obj->revisao}' AND s.veiculo = '{$obj->veiculo}'"));
	}
	
	
	public function addFrota(Frota $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
	  //var_dump($obj);die();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'sie_frota');
	}
	public function addInfracao(Infracao $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
	  //var_dump($obj);die();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'sie_frota_infracao');
	}
	public function addRevisao(Revisao $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
	  //var_dump($obj);die();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'sie_frota_revisao', 'revisao');
	}
	public function editFrota(Frota $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != '';}, ARRAY_FILTER_USE_KEY);
		if ((is_array($set) ? count($set) : 0) > 0){
			return $prepare->PrepareUpdate($set,array('frota' => $obj['frota']), 'sie_frota');
		}
	}
	
	public function delFrota(Frota $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('frota' => $obj->frota), 'sie_frota');
	}
	
	public function delInfracao(Infracao $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('infracao' => $obj->infracao, 'veiculo'=> $obj->veiculo), 'sie_frota_infracao');
	}
	public function delRevisao(Revisao $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('revisao' => $obj->revisao, 'veiculo'=> $obj->veiculo), 'sie_frota_revisao');
	}
	

   public function executeSQL($sql){
  	return $this->Execute($sql);
  }
}