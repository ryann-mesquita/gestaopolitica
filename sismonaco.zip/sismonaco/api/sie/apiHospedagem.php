<?php 
namespace api\sie;

use lib\Model;
use obj\sie\Custo;
use helper\PrepareSQL;
use helper\Funcoes;
use obj\sie\Hospedagem;

class apiHospedagem extends Model {
	
	public function getHospedagem(Hospedagem $obj){
		return $this->First($this->Select("SELECT h.hospedagem, h.hotel, h.cidade, h.estado, h.usuario, u.nome usuario_nome, h.departamento, d.des_departamento, h.cargo, c.des_cargo, h.empresa, e.des_empresa, h.dta_emissao, h.motivo, h.dta_entrada, h.dta_saida, h.valor, h.total, h.pagamento, h.anexo
			   FROM sie_hospedagem h
			   LEFT JOIN sis_usuario u on h.usuario = u.usuario
			   LEFT JOIN sis_empresa e on h.empresa = e.empresa
			   LEFT JOIN sis_cargo c ON h.cargo = c.cargo
			   LEFT JOIN sis_departamento d ON h.departamento = d.departamento
			   WHERE h.hospedagem = '{$obj->hospedagem}'"));
	}
	
	public function filtroHospedagem($c, $a, $coluna = NULL, $val = NULL, $de = NULL, $ate = NULL){
		$val = strtolower(trim($val));
		$condicao = array(
				'1'	=> " WHERE LOWER(h.{$coluna}) = '{$val}' ",
				'2' => " WHERE LOWER(h.{$coluna}) LIKE '%{$val}%' ",
				'3'	=> "",
				'4' => " WHERE TO_DATE(TO_CHAR(TO_DATE({$coluna}, 'dd/mm/yyyy hh24:mi:ss'), 'dd/mm/yyyy'), 'dd/mm/yyyy') BETWEEN TO_DATE('{$de}','dd/mm/yyyy') AND TO_DATE('{$ate}','dd/mm/yyyy')",
		);
		$ativo = array(
				'1' => "",
				'2' => "",
				'3' => "",
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM (SELECT h.hospedagem, h.hotel, h.cidade, h.estado, h.usuario, u.nome usuario_nome, h.departamento, d.des_departamento, h.cargo, c.des_cargo, h.empresa, e.des_empresa, h.dta_emissao, h.motivo, h.dta_entrada, h.dta_saida, h.valor, h.total, h.pagamento, h.anexo 
		FROM sie_hospedagem h
		LEFT JOIN sis_usuario u on h.usuario = u.usuario
	    LEFT JOIN sis_empresa e on h.empresa = e.empresa
	    LEFT JOIN sis_cargo c ON h.cargo = c.cargo
	    LEFT JOIN sis_departamento d ON h.departamento = d.departamento 
        {$condicao[$c]}{$ativo[$a]}) R ) R2");
	}
	
	public function getCusto(Hospedagem $obj){
		return $this->Select("SELECT c.custo, c.valor, c.des_custo FROM sie_hospedagem_custo c
				WHERE c.hospedagem = '{$obj->hospedagem}'");
	}
	
	public function getCustoValor(Hospedagem $obj){
		return $this->Select("SELECT SUM(c.valor) AS total FROM sie_hospedagem_custo c
				WHERE c.hospedagem = '{$obj->hospedagem}'");
	}
	public function getCustoUnidade(Custo $obj){
		return $this->first($this->Select("SELECT c.custo, c.valor, c.des_custo FROM sie_hospedagem_custo c
				WHERE c.custo = '{$obj->custo}'"));
	}
	
	public function getGrafico($ano, $empresa, $usuario){
		if ($empresa != NULL){
			$cond1 = "AND h.empresa = '{$empresa}' ";
		}else{
			$cond1 = " ";
		}
		if ($usuario != NULL){
			$cond2 = "AND h.usuario = '{$usuario}' ";
		}else{
			$cond2 = " ";
		}
		
		return $this->Select("select sum(total) total,mes,
    	case
	    when mes = 1 then 'Jan'
	    when mes = 2 then 'Fev'
	    when mes = 3 then 'Mar'
	    when mes = 4 then 'Abr'
	    when mes = 5 then 'Mai'
	    when mes = 6 then 'Jun'
	    when mes = 7 then 'Jul'
	    when mes = 8 then 'Ago'
	    when mes = 9 then 'Set'
	    when mes = 10 then 'Out'
	    when mes = 11 then 'Nov'
	    when mes = 12 then 'Dez'
	    end as meses
	    from
	      (SELECT h.total,
	        EXTRACT( MONTH FROM TO_DATE( h.dta_emissao,  'DD/MM/YYYY' ) ) MES
	      FROM 
	      sie_hospedagem h
	      WHERE EXTRACT( YEAR FROM TO_DATE( h.dta_emissao,  'DD/MM/YYYY' ) ) = '$ano' $cond1 $cond2
	      group by  h.total , h.dta_emissao) teste 
	     group by mes
	     order by mes");
		}
	public function getGraficoTotal($ano, $empresa, $usuario){
		if ($empresa != NULL){
			$cond1 = "AND h.empresa = '{$empresa}' ";
		}else{
			$cond1 = " ";
		}
		if ($usuario != NULL){
			$cond2 = "AND h.usuario = '{$usuario}' ";
		}else{
			$cond2 = " ";
		}
		return $this->Select("select sum(tabela.total) total from (select sum(total) total,mes,
				case
				when mes = 1 then 'Jan'
				when mes = 2 then 'Fev'
				when mes = 3 then 'Mar'
				when mes = 4 then 'Abr'
				when mes = 5 then 'Mai'
				when mes = 6 then 'Jun'
				when mes = 7 then 'Jul'
				when mes = 8 then 'Ago'
				when mes = 9 then 'Set'
				when mes = 10 then 'Out'
				when mes = 11 then 'Nov'
				when mes = 12 then 'Dez'
				end as meses
				from
				(SELECT h.total,
				EXTRACT( MONTH FROM TO_DATE( h.dta_emissao,  'DD/MM/YYYY' ) ) MES
				FROM
				sie_hospedagem h
				WHERE EXTRACT( YEAR FROM TO_DATE( h.dta_emissao,  'DD/MM/YYYY' ) ) = '$ano' $cond1 $cond2
				group by  h.total , h.dta_emissao) teste
				group by mes
				order by mes)tabela");
	}
	
	public function getGraficoCusto($ano, $empresa, $usuario){
		if ($empresa != NULL){
			$cond1 = "AND h.empresa = '{$empresa}' ";
		}else{
			$cond1 = " ";
		}
		if ($usuario != NULL){
			$cond2 = "AND h.usuario = '{$usuario}' ";
		}else{
			$cond2 = " ";
		}
		return $this->Select("select sum(val_custo) val_custo,mes,
		case
		when mes = 1 then 'Jan'
		when mes = 2 then 'Fev'
		when mes = 3 then 'Mar'
		when mes = 4 then 'Abr'
		when mes = 5 then 'Mai'
		when mes = 6 then 'Jun'
		when mes = 7 then 'Jul'
		when mes = 8 then 'Ago'
		when mes = 9 then 'Set'
		when mes = 10 then 'Out'
		when mes = 11 then 'Nov'
		when mes = 12 then 'Dez'
		end as des_mes
		from
		(SELECT  sum(c.valor) val_custo,
		  EXTRACT( MONTH FROM TO_DATE( h.dta_emissao,  'DD/MM/YYYY' ) ) MES
		FROM 
		sie_hospedagem h, sie_hospedagem_custo c
		WHERE EXTRACT( YEAR FROM TO_DATE( h.dta_emissao,  'DD/MM/YYYY' ) ) = $ano $cond1 $cond2
		AND h.hospedagem = c.hospedagem
		group by  h.dta_emissao) teste 
		group by  mes
		order by mes");
	}
	public function getGraficoCustoTotal($ano, $empresa, $usuario){
		if ($empresa != NULL){
			$cond1 = "AND h.empresa = '{$empresa}' ";
		}else{
			$cond1 = " ";
		}
		if ($usuario != NULL){
			$cond2 = "AND h.usuario = '{$usuario}' ";
		}else{
			$cond2 = " ";
		}
		return $this->Select("select sum(tabela.val_custo) total_custo from(select val_custo,mes,
		case
		when mes = 1 then 'Jan'
		when mes = 2 then 'Fev'
		when mes = 3 then 'Mar'
		when mes = 4 then 'Abr'
		when mes = 5 then 'Mai'
		when mes = 6 then 'Jun'
		when mes = 7 then 'Jul'
		when mes = 8 then 'Ago'
		when mes = 9 then 'Set'
		when mes = 10 then 'Out'
		when mes = 11 then 'Nov'
		when mes = 12 then 'Dez'
		end as des_mes
		from
		(SELECT  sum(t.valor) val_custo,
		  EXTRACT( MONTH FROM TO_DATE( h.dta_emissao,  'DD/MM/YYYY' ) ) MES
		FROM 
		sie_hospedagem h, sie_hospedagem_custo t
		WHERE EXTRACT( YEAR FROM TO_DATE( h.dta_emissao,  'DD/MM/YYYY' ) ) = $ano $cond1 $cond2
		AND h.hospedagem = t.hospedagem
		group by  h.dta_emissao) teste 
		group by  val_custo, mes
		order by mes)tabela");
	}

	public function addHospedagem(Hospedagem $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'sie_hospedagem', 'hospedagem' );
	}
	
	public function addCusto(Custo $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'sie_hospedagem_custo', 'custo');
	}
	
	public function sumValorHospedagem(Hospedagem $obj){
		return $this->Select("SELECT h.valor +
				(SELECT SUM(t.valor) FROM sie_hospedagem_custo c WHERE c.hospedagem = '{$obj->hospedagem}')
				FROM sie_hospedagem h");
	}
	
	public function valorTotalHospedagem(Hospedagem $obj)
	{
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'hospedagem';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('Hospedagem' => $obj['hospedagem']), 'sie_hospedagem');
	}
	
	public function editHospedagem(Hospedagem $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'passagem';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('hospedagem' => $obj['hospedagem']), 'sie_hospedagem');
	}

	public function delHospedagem(Hospedagem $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('hospedagem' => $obj->hospedagem), 'sie_hospedagem');
	}
	
	public function delCusto(Custo $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('custo' => $obj->custo, 'hospedagem'=> $obj->hospedagem), 'sie_hospedagem_custo');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
	
	
}