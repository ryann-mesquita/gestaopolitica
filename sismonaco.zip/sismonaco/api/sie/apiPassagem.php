<?php

namespace api\sie;

use lib\Model;
use obj\sie\Passagem;
use obj\sie\Taxa;
use helper\PrepareSQL;
use helper\Funcoes;

class apiPassagem extends Model {
	
	public function getPassagem(Passagem $obj) {
		return  $this->First($this->Select("SELECT p.passagem, p.usuario, u.nome usuario_nome, p.origem, p.destino, p.ida, 
				p.volta, p.companhia, p.empresa, e.des_empresa des_empresa, p.departamento, d.des_departamento, p.cargo, c.des_cargo,  p.dta_emissao, 
				p.valor, p.total, p.motivo, p.pagamento, p.anexo
				FROM sie_passagem p
				LEFT JOIN sis_usuario u on p.usuario = u.usuario
				LEFT JOIN sis_empresa e on p.empresa = e.empresa
				LEFT JOIN sis_cargo c ON p.cargo = c.cargo
				LEFT JOIN sis_departamento d ON p.departamento = d.departamento
				WHERE p.passagem = '{$obj->passagem}'"));
	}
	public function filtroPassagem($c, $a, $coluna = NULL, $val = NULL, $de = NULL, $ate = NULL) {
		$val = strtolower(trim($val));
		$condicao = array(
				'1'	=> " WHERE LOWER(p.{$coluna}) = '{$val}' ",
				'2' => " WHERE LOWER(p.{$coluna}) LIKE '%{$val}%' ",
				'3'	=> "",
				'4' => " WHERE TO_DATE(TO_CHAR(TO_DATE({$coluna}, 'dd/mm/yyyy hh24:mi:ss'), 'dd/mm/yyyy'), 'dd/mm/yyyy') BETWEEN TO_DATE('{$de}','dd/mm/yyyy') AND TO_DATE('{$ate}','dd/mm/yyyy')",
		);
		$ativo = array(
				'1' => "",
				'2' => "",
				'3' => "",
		);
		return $this->Select("SELECT R2.*
				FROM (SELECT rownum n_linha, R.*
				FROM(SELECT p.passagem, p.usuario, u.nome usuario_nome, p.origem, p.destino, p.ida, 
				p.volta, p.companhia, p.empresa, e.des_empresa, p.departamento, d.des_departamento, p.cargo, c.des_cargo, p.dta_emissao, 
				p.valor, p.total, p.motivo, p.pagamento, p.anexo
				FROM sie_passagem p 
				LEFT JOIN sis_usuario u on p.usuario = u.usuario
				LEFT JOIN sis_empresa e on p.empresa = e.empresa
				LEFT JOIN sis_cargo c ON p.cargo = c.cargo
				LEFT JOIN sis_departamento d ON p.departamento = d.departamento
		        {$condicao[$c]}{$ativo[$a]}) R ) R2");
	}
	
	public function getTaxa(Passagem $obj){
		return $this->Select("SELECT t.taxa, t.valor, t.des_taxa FROM sie_passagem_taxa t
		WHERE t.passagem = '{$obj->passagem}'");
	}
	public function getTaxaValor(Passagem $obj){
		return $this->Select("SELECT SUM(t.valor) AS total FROM sie_passagem_taxa t
		WHERE t.passagem = '{$obj->passagem}'");
	}
	public function getTaxaUnidade(Taxa $obj){
		return $this->first($this->Select("SELECT t.taxa, t.valor, t.des_taxa FROM sie_passagem_taxa t
		WHERE t.taxa = '{$obj->taxa}'"));
	}
	
	public function getGrafico($ano, $empresa, $usuario){
		if ($empresa != NULL){
			$cond1 = "AND ps.empresa = '{$empresa}' ";
		}else{
			$cond1 = " ";
		}
		if ($usuario != NULL){
			$cond2 = "AND ps.usuario = '{$usuario}' ";
		}else{
			$cond2 = " ";
		}
		return $this->Select("select sum(total) total,mes,
		case
		when mes = 1 then 'Jan'
		when mes = 2 then 'Fev'
		when mes = 3 then 'Mar'
		when mes = 4 then 'Abr'
		when mes = 5 then 'Mai'
		when mes = 6 then 'Jun'
		when mes = 7 then 'Jul'
		when mes = 8 then 'Ago'
		when mes = 9 then 'Set'
		when mes = 10 then 'Out'
		when mes = 11 then 'Nov'
		when mes = 12 then 'Dez'
		end as meses
		from
			(SELECT ps.total,
			  EXTRACT( MONTH FROM TO_DATE( ps.dta_emissao,  'DD/MM/YYYY' ) ) MES
			FROM 
			sie_passagem ps
			WHERE EXTRACT( YEAR FROM TO_DATE( ps.dta_emissao,  'DD/MM/YYYY' ) ) = '$ano' $cond1 $cond2
			group by  ps.total , ps.dta_emissao) teste 
		group by mes
		order by mes");
	}
	public function getGraficoTotal($ano, $empresa, $usuario){
		if ($empresa != NULL){
			$cond1 = "AND ps.empresa = '{$empresa}' ";
		}else{
			$cond1 = " ";
		}
		if ($usuario != NULL){
			$cond2 = "AND ps.usuario = '{$usuario}' ";
		}else{
			$cond2 = " ";
		}
		return $this->Select("select sum(tabela.total) total from (select sum(total) total,mes,
		case
		when mes = 1 then 'Jan'
		when mes = 2 then 'Fev'
		when mes = 3 then 'Mar'
		when mes = 4 then 'Abr'
		when mes = 5 then 'Mai'
		when mes = 6 then 'Jun'
		when mes = 7 then 'Jul'
		when mes = 8 then 'Ago'
		when mes = 9 then 'Set'
		when mes = 10 then 'Out'
		when mes = 11 then 'Nov'
		when mes = 12 then 'Dez'
		end as meses
		from
			(SELECT ps.total,
			  EXTRACT( MONTH FROM TO_DATE( ps.dta_emissao,  'DD/MM/YYYY' ) ) MES
			FROM 
			sie_passagem ps
			WHERE EXTRACT( YEAR FROM TO_DATE( ps.dta_emissao,  'DD/MM/YYYY' ) ) = '$ano' $cond1 $cond2
			group by  ps.total , ps.dta_emissao) teste 
		group by mes
		order by mes)tabela");
	}
	public function getGraficoTaxa($ano, $empresa, $usuario){
		if ($empresa != NULL){
			$cond1 = "AND ps.empresa = '{$empresa}' ";
		}else{
			$cond1 = " ";
		}
		if ($usuario != NULL){
			$cond2 = "AND ps.usuario = '{$usuario}' ";
		}else{
			$cond2 = " ";
		}
		return $this->Select("select sum(val_taxa) val_taxa,mes,
		case
		when mes = 1 then 'Jan'
		when mes = 2 then 'Fev'
		when mes = 3 then 'Mar'
		when mes = 4 then 'Abr'
		when mes = 5 then 'Mai'
		when mes = 6 then 'Jun'
		when mes = 7 then 'Jul'
		when mes = 8 then 'Ago'
		when mes = 9 then 'Set'
		when mes = 10 then 'Out'
		when mes = 11 then 'Nov'
		when mes = 12 then 'Dez'
		end as des_mes
		from
		(SELECT  sum(t.valor) val_taxa,
		  EXTRACT( MONTH FROM TO_DATE( ps.dta_emissao,  'DD/MM/YYYY' ) ) MES
		FROM 
		sie_passagem ps, sie_passagem_taxa t
		WHERE EXTRACT( YEAR FROM TO_DATE( ps.dta_emissao,  'DD/MM/YYYY' ) ) = $ano $cond1 $cond2
		AND ps.passagem = t.passagem
		group by  ps.dta_emissao) teste 
		group by  mes
		order by mes");
	}
	public function getGraficoTaxaTotal($ano, $empresa, $usuario){
		if ($empresa != NULL){
			$cond1 = "AND ps.empresa = '{$empresa}' ";
		}else{
			$cond1 = " ";
		}
		if ($usuario != NULL){
			$cond2 = "AND ps.usuario = '{$usuario}' ";
		}else{
			$cond2 = " ";
		}
		return $this->Select("select sum(tabela.val_taxa) total_taxa from(select val_taxa,mes,
		case
		when mes = 1 then 'Jan'
		when mes = 2 then 'Fev'
		when mes = 3 then 'Mar'
		when mes = 4 then 'Abr'
		when mes = 5 then 'Mai'
		when mes = 6 then 'Jun'
		when mes = 7 then 'Jul'
		when mes = 8 then 'Ago'
		when mes = 9 then 'Set'
		when mes = 10 then 'Out'
		when mes = 11 then 'Nov'
		when mes = 12 then 'Dez'
		end as des_mes
		from
		(SELECT  sum(t.valor) val_taxa,
		  EXTRACT( MONTH FROM TO_DATE( ps.dta_emissao,  'DD/MM/YYYY' ) ) MES
		FROM 
		sie_passagem ps, sie_passagem_taxa t
		WHERE EXTRACT( YEAR FROM TO_DATE( ps.dta_emissao,  'DD/MM/YYYY' ) ) = $ano $cond1 $cond2
		AND ps.passagem = t.passagem
		group by  ps.dta_emissao) teste 
		group by  val_taxa, mes
		order by mes)tabela");
	}

	public function addPassagem(Passagem $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'sie_passagem' );
	}
	public function addTaxa(Taxa $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'sie_passagem_taxa', 'taxa');
	}
	
	public function editPassagem(Passagem $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'passagem';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('passagem' => $obj['passagem']), 'sie_passagem');
	}
	
	public function sumValorPassagem(Passagem $obj){
		return $this->Select("SELECT p.valor + 
 		(SELECT SUM(t.valor) FROM sie_passagem_taxa t WHERE t.passagem = '{$obj->passagem}')
 		 FROM sie_passagem p");
	}
	
	public function valorTotalPassagem(Passagem $obj)
	{
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'passagem';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('Passagem' => $obj['passagem']), 'sie_passagem');
	}
	
	public function delPassagem(Passagem $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('passagem' => $obj->passagem), 'sie_passagem');
	}
	
	public function delTaxa(Taxa $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('taxa' => $obj->taxa, 'passagem'=> $obj->passagem), 'sie_passagem_taxa');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}


}