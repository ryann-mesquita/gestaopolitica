<?php

namespace api\finan;

use lib\Model;
use obj\finan\Adiantamento;
use helper\PrepareSQL;
use helper\Funcoes;
use obj\finan\Adiantamentoadiantamento;
use obj\finan\Autorizacao;
use obj\finan\Inconsistencia;

class apiAdiantamento extends Model {
	
	public function getAdiantamento(Adiantamento $obj) {
		return  $this->First($this->Select("SELECT ad.adiantamento, ad.des_adiantamento, ad.solicitante, u.contrato, u.nome,
		u.cpf, u.empresa empresa_origem, e.des_empresa, e.razao_social, d.des_departamento departamento, ad.categoria, ad.cc,
		ad.tipo, t.des_tipo, t.dias, ad.empresa, e2.des_empresa empresa_destino, ad.cartao_corporativo, ad.frota, ad.km_inicial,
		ad.km_final, ad.val_km, ad.val_adiantamento, ad.val_receber, ad.val_devolver, ad.banco, ad.tipo_conta, ad.agencia, 
		ad.conta, trunc(to_date(ad.dta_cadastro, 'dd/mm/yyyy hh24:mi:ss')) dta_cadastro, ad.dta_inicio, ad.dta_fim, ad.dta_prev_pagamento,
		ad.dta_prestacao, ad.dta_doc, ad.usuario_doc, u4.nome nome_doc, ad.dta_dp, ad.usuario_dp, u5.nome nome_dp, ad.situacao, ad.situacao_anterior, 
		ad.em, ad.cliente_apollo, ad.titulo_apollo, ad.duplicata_apollo, ad.cp_apollo, ad.cp_duplicata, ad.cp_valor, ad.ad_apollo, 
		ad.ad_duplicata, ad.ad_valor, ad.anexos, ad.anexos_comp, au.destinatario, u2.nome nome_destinatario, au.autorizante, 
		u3.nome nome_autorizante, au.dta_solicitacao, au.dta_acao, au.motivo, au.autorizado, p.dir_pasta_adiantamento,
		p.empresa empresa_apollo, p.revenda revenda_apollo, ai.dta_inconsistencia, ai.inconsistencia, ai.dta_retorno_inconsistencia
		FROM finan_adiantamento ad 
		JOIN finan_tipo t ON ad.tipo = t.tipo
		JOIN sis_usuario u ON ad.solicitante = u.usuario
		JOIN sis_departamento d ON u.departamento = d.departamento
		JOIN sis_empresa e ON u.empresa = e.empresa
		JOIN sis_empresa e2 ON ad.empresa = e2.empresa
		LEFT JOIN ger_revenda r ON e2.cnpj = r.cnpj
		LEFT JOIN fin_parametro p on r.empresa = p.empresa and r.revenda = p.revenda 
		LEFT JOIN finan_adiantamento_autorizacao au ON ad.adiantamento = au.adiantamento AND ad.situacao_anterior = au.situacao
		LEFT JOIN (select adiantamento,max(to_date(dta_inconsistencia,'dd/mm/yyyy hh24:mi:ss'))  dta_inconsistencia
		from finan_adiantamento_inconsis group by adiantamento ) aii on ad.adiantamento = aii.adiantamento 
		LEFT JOIN finan_adiantamento_inconsis  ai on aii.adiantamento = ai.adiantamento and aii.dta_inconsistencia = to_date(ai.dta_inconsistencia,'dd/mm/yyyy hh24:mi:ss')
		LEFT JOIN sis_usuario u2 ON au.destinatario = u2.usuario 
		LEFT JOIN sis_usuario u3 ON au.autorizante = u3.usuario
		LEFT JOIN sis_usuario u4 ON ad.usuario_doc = u4.usuario
		LEFT JOIN sis_usuario u5 ON ad.usuario_dp = u5.usuario WHERE ad.adiantamento = '{$obj->adiantamento}'"));
	}
	
	public function numeroAdiantamento() {
		return  $this->First($this->Select("SELECT ad.adiantamento, ad.des_adiantamento, ad.solicitante, u.contrato, u.nome,
		u.email, u.cpf, u.empresa empresa_origem, e.des_empresa, e.razao_social, d.des_departamento departamento, ad.categoria,
		ad.cc, ad.tipo, t.des_tipo, t.dias, ad.empresa, e2.des_empresa empresa_destino, ad.cartao_corporativo, ad.frota,
		ad.km_inicial, ad.km_final, ad.val_km, ad.val_adiantamento, ad.val_receber, ad.val_devolver, ad.banco, ad.tipo_conta,
		ad.agencia, ad.conta, trunc(to_date(ad.dta_cadastro, 'dd/mm/yyyy hh24:mi:ss')) dta_cadastro, ad.dta_inicio, ad.dta_fim,
		ad.dta_prev_pagamento, ad.dta_prestacao, ad.dta_doc, ad.usuario_doc, ad.dta_dp, ad.usuario_dp, ad.situacao, ad.situacao_anterior, ad.em, ad.cliente_apollo,
		ad.titulo_apollo, ad.duplicata_apollo, ad.cp_apollo, ad.cp_duplicata, ad.cp_valor, ad.ad_apollo, ad.ad_duplicata, ad.ad_valor, 
		ad.anexos, ad.anexos_comp, au.destinatario, u2.nome nome_destinatario, au.autorizante, u3.nome nome_autorizante, au.dta_solicitacao, 
		au.dta_acao, au.motivo, au.autorizado, p.dir_pasta_adiantamento, ai.dta_inconsistencia, ai.inconsistencia,
		p.empresa empresa_apollo, p.revenda revenda_apollo
		FROM finan_adiantamento ad
		JOIN finan_tipo t ON ad.tipo = t.tipo
		JOIN sis_usuario u ON ad.solicitante = u.usuario
		JOIN sis_departamento d ON u.departamento = d.departamento
		JOIN sis_empresa e ON u.empresa = e.empresa
		JOIN sis_empresa e2 ON ad.empresa = e2.empresa
		LEFT JOIN ger_revenda r ON e2.cnpj = r.cnpj
		LEFT JOIN fin_parametro p on r.empresa = p.empresa and r.revenda = p.revenda
		LEFT JOIN finan_adiantamento_autorizacao au ON ad.adiantamento = au.adiantamento AND ad.situacao_anterior = au.situacao
		LEFT JOIN (select adiantamento,max(to_date(dta_inconsistencia,'dd/mm/yyyy hh24:mi:ss'))  dta_inconsistencia
		from finan_adiantamento_inconsis group by adiantamento ) aii on ad.adiantamento = aii.adiantamento 
		LEFT JOIN finan_adiantamento_inconsis  ai on aii.adiantamento = ai.adiantamento and aii.dta_inconsistencia = to_date(ai.dta_inconsistencia,'dd/mm/yyyy hh24:mi:ss')
		LEFT JOIN sis_usuario u2 ON au.destinatario = u2.usuario
		LEFT JOIN sis_usuario u3 ON au.autorizante = u3.usuario WHERE ad.adiantamento = ((SELECT last_number FROM user_sequences WHERE sequence_name = 'SEQ_FINAN_ADIANTAMENTO') - 1)"));
	}
	
	public function getAdiantamentoautorizacao(Adiantamento $obj){
		return $this->Select("SELECT au.adiantamento, ad.des_adiantamento, au.situacao, au.destinatario, 
		u.nome nome_destinatario, au.autorizante, u2.nome nome_autorizante, au.dta_solicitacao, au.dta_acao, au.motivo, au.autorizado
		FROM finan_adiantamento_autorizacao au
		JOIN finan_adiantamento ad ON au.adiantamento = ad.adiantamento
		LEFT JOIN sis_usuario u ON au.destinatario = u.usuario
		LEFT JOIN sis_usuario u2 ON au.autorizante = u2.usuario
		WHERE au.adiantamento = '{$obj->adiantamento}' ORDER BY au.situacao DESC");
	}
	public function getAdiantamentoinconsistencia(Adiantamento $obj){
		return $this->Select("SELECT ai.adiantamento, ai.criador, u.nome nome_criador, ai.inconsistencia,
		ai.dta_inconsistencia
		FROM finan_adiantamento_inconsis ai
		JOIN finan_adiantamento ad ON ai.adiantamento = ad.adiantamento
		LEFT JOIN sis_usuario u ON ai.criador = u.usuario
		WHERE ai.adiantamento = '{$obj->adiantamento}' ORDER BY to_date(ai.dta_inconsistencia,'dd/mm/yyyy hh24:mi:ss') DESC");
	}
	public function getAutorizacao(Adiantamento $obj){
		return $this->First($this->Select("SELECT au.adiantamento, ad.des_adiantamento, au.situacao, au.destinatario,
		u.nome nome_destinatario, au.autorizante, u2.nome nome_autorizante, au.dta_solicitacao, au.dta_acao, au.motivo, au.autorizado
		FROM finan_adiantamento_autorizacao au
		JOIN finan_adiantamento ad ON au.adiantamento = ad.adiantamento
		LEFT JOIN sis_usuario u ON au.destinatario = u.usuario
		LEFT JOIN sis_usuario u2 ON au.autorizante = u2.usuario
		WHERE au.adiantamento = '{$obj->adiantamento}' and au.situacao = '{$obj->situacao}' ORDER BY au.situacao DESC"));
	}
	public function filtroAdiantamento($tipo, $situacao, $empresa, $solicitante, $c, $coluna = NULL, $val = NULL) {
		$funcoes = new Funcoes();
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		if ($empresa != 'tudo'){
			$emp = "AND (ad.empresa {$empresa} OR u.empresa {$empresa} ) ";
		}else{
			$emp = "";
		}
		
		if ($solicitante != 'tudo'){
			$sol = "AND ad.solicitante = '{$solicitante}' OR au.destinatario = '{$solicitante}' ";
		}else{
			$sol = "";
		}
		
		$condicao = array(
			'1'	=> "AND LOWER({$coluna}) = '{$val}' ",
			'2' => "AND LOWER({$coluna}) LIKE '%{$val}%' ",
			'3'	=> "",
		);
		
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT ad.adiantamento, ad.des_adiantamento, ad.solicitante, u.contrato, u.nome, u.cpf, u.empresa empresa_origem, 
		e.des_empresa, e.razao_social, d.des_departamento departamento, ad.categoria, ad.cc, ad.tipo, t.des_tipo, t.dias, 
		ad.empresa, e2.des_empresa empresa_destino, ad.cartao_corporativo, ad.frota, ad.km_inicial, ad.km_final, ad.val_km, 
		ad.val_adiantamento, ad.val_receber, ad.val_devolver, ad.banco, ad.agencia, ad.conta, ad.tipo_conta, 
		trunc(to_date(ad.dta_cadastro, 'dd/mm/yyyy hh24:mi:ss')) dta_cadastro,
		ad.dta_inicio, ad.dta_fim, ad.dta_prev_pagamento, ad.dta_prestacao, ad.dta_doc, ad.usuario_doc, u4.nome nome_doc, 
		ad.dta_dp, ad.usuario_dp, u5.nome nome_dp, ad.situacao, ad.situacao_anterior, ad.em, ad.cliente_apollo, ad.titulo_apollo, ad.duplicata_apollo,
		ad.cp_apollo, ad.cp_duplicata, ad.cp_valor, ad.ad_apollo, ad.ad_duplicata, ad.ad_valor, ad.anexos, ad.anexos_comp, 
		au.destinatario, u2.nome nome_destinatario, au.autorizante, u3.nome nome_autorizante, au.dta_solicitacao, au.dta_acao, 
		au.motivo, au.autorizado, p.dir_pasta_adiantamento, p.empresa empresa_apollo, p.revenda revenda_apollo, ai.dta_inconsistencia, ai.inconsistencia, ai.dta_retorno_inconsistencia, au2.dta_acao dta_autorizacao_gestor
		FROM finan_adiantamento ad
		JOIN finan_tipo t ON ad.tipo = t.tipo 
		JOIN sis_usuario u ON ad.solicitante = u.usuario
		JOIN sis_departamento d ON u.departamento = d.departamento
		JOIN sis_empresa e ON u.empresa = e.empresa
		JOIN sis_empresa e2 ON ad.empresa = e2.empresa
		LEFT JOIN ger_revenda r ON e2.cnpj = r.cnpj
		LEFT JOIN fin_parametro p on r.empresa = p.empresa and r.revenda = p.revenda 
		LEFT JOIN finan_adiantamento_autorizacao au ON ad.adiantamento = au.adiantamento AND ad.situacao_anterior = au.situacao
		LEFT JOIN finan_adiantamento_autorizacao au2 ON ad.adiantamento = au2.adiantamento AND  au2.situacao = 0
		LEFT JOIN (select adiantamento,max(to_date(dta_inconsistencia,'dd/mm/yyyy hh24:mi:ss'))  dta_inconsistencia
		from finan_adiantamento_inconsis group by adiantamento ) aii on ad.adiantamento = aii.adiantamento 
		LEFT JOIN finan_adiantamento_inconsis  ai on aii.adiantamento = ai.adiantamento and aii.dta_inconsistencia = to_date(ai.dta_inconsistencia,'dd/mm/yyyy hh24:mi:ss')
		LEFT JOIN sis_usuario u2 ON au.destinatario = u2.usuario 
		LEFT JOIN sis_usuario u3 ON au.autorizante = u3.usuario
		LEFT JOIN sis_usuario u4 ON ad.usuario_doc = u4.usuario
		LEFT JOIN sis_usuario u5 ON ad.usuario_dp = u5.usuario
		WHERE ad.categoria {$tipo} AND ad.situacao {$situacao} 
		{$emp}{$sol}{$condicao[$c]}ORDER BY to_date(au.dta_solicitacao, 'dd/mm/yyyy hh24:mi:ss') DESC) R ) R2");
	}
	
	public function addAdiantamento(Adiantamento $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$obj = array_filter($obj, function($v){return $v != 'destinatario' && $v != 'anexo' && $v != 'segundo_ad';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareInsert($obj, 'finan_adiantamento','adiantamento');
	}
	
	public function addAutorizacao(Autorizacao $obj, $currval = NULL) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		if ($currval != NULL){
			$obj = array_filter($obj, function($v){return $v != 'adiantamento' && $v != 'anexo' && $v != 'segundo_ad';}, ARRAY_FILTER_USE_KEY);
			return $prepare->PrepareInsert($obj, 'finan_adiantamento_autorizacao',"",$currval);
		}else{
			$obj = array_filter($obj, function($v){return $v != 'anexo' && $v != 'segundo_ad';}, ARRAY_FILTER_USE_KEY);
			return $prepare->PrepareInsert($obj, 'finan_adiantamento_autorizacao');
		}
	}
	
	public function addInconsistencia(Inconsistencia $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$obj = array_filter($obj, function($v){return $v != 'anexo' && $v != 'segundo_ad';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareInsert($obj, 'finan_adiantamento_inconsis');
	}
	
	public function editAdiantamento(Adiantamento $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'adiantamento' && $v != 'anexo';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('adiantamento' => $obj['adiantamento']), 'finan_adiantamento');
	}
	
	public function editAutorizacao(Autorizacao $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'adiantamento' && $v != 'situacao' && $v != 'anexo';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('adiantamento' => $obj['adiantamento'], 'situacao' => $obj['situacao']), 'finan_adiantamento_autorizacao');
	}
	
	public function delAdiantamento(Adiantamento $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('adiantamento' => $obj->adiantamento), 'finan_adiantamento');
	}
	
	public function delAdiantamentoadiantamento(Adiantamentoadiantamento $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('adiantamento' => $obj->adiantamento), 'finan_adiantamento_adiantamento');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}