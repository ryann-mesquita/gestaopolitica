<?php

namespace api\finan;

use lib\Model;
use obj\finan\Tipo;
use helper\PrepareSQL;
use helper\Funcoes;

class apiTipo extends Model {

	public function getTipo(Tipo $obj) {
		return  $this->First($this->Select("SELECT t.tipo, t.tipo_funcionario, st.des_tipo des_funcionario, t.des_tipo, 
		t.dias, t.ativo 
		FROM finan_tipo t 
		JOIN sis_tipo st ON t.tipo_funcionario = st.tipo 
		WHERE t.tipo = '{$obj->tipo}'"));
	}

	public function filtroTipo($c, $a, $coluna = NULL, $val = NULL) {
		$val = strtolower(trim($val));
		$condicao = array(
			'1'	=> " WHERE LOWER(t.{$coluna}) = '{$val}' ",
			'2' => " WHERE LOWER(t.{$coluna}) LIKE '%{$val}%' ",
			'3'	=> " ",
			'4'	=> " WHERE LOWER(t.{$coluna}) <= {$val} ",
		);
		$ativo = array(
			'1' => "AND t.ativo = '1' ",
			'2' => "AND t.ativo = '0' ",
			'3' => "",
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT t.tipo, t.tipo_funcionario, st.des_tipo des_funcionario, t.des_tipo, 
		t.dias, t.ativo 
		FROM finan_tipo t 
		JOIN sis_tipo st ON t.tipo_funcionario = st.tipo{$condicao[$c]}{$ativo[$a]}ORDER BY t.des_tipo ASC) R ) R2");
	}

	public function addTipo(Tipo $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_tipo = strtoupper($funcoes->retiraAcentos(trim($obj->des_tipo)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'finan_tipo','tipo');
	}

	public function editTipo(Tipo $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_tipo = strtoupper($funcoes->retiraAcentos(trim($obj->des_tipo)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'tipo';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('tipo' => $obj['tipo']), 'finan_tipo');
	}

	public function delTipo(Tipo $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('tipo' => $obj->tipo), 'finan_tipo');
	}

	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}