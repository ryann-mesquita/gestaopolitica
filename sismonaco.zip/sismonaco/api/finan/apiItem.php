<?php

namespace api\finan;

use lib\Model;
use obj\finan\Item;
use helper\PrepareSQL;
use helper\Funcoes;
use obj\finan\Itemadiantamento;
use obj\finan\Adiantamento;

class apiItem extends Model {
	
	public function getItem(Item $obj) {
		return  $this->First($this->Select("SELECT * FROM finan_item WHERE item = '{$obj->item}'"));
	}
	
	public function getItemadiantamento(Adiantamento $obj){
		return $this->Select("SELECT id.ordem, id.item, id.adiantamento, i.des_item, id.descricao, id.documento, id.fornecedor, id.data, 
		id.valor, id.aut, id.financeiro, id.obs 
		FROM finan_item_adiantamento id
		JOIN finan_item i ON id.item = i.item
		WHERE id.adiantamento = '{$obj->adiantamento}' ORDER BY id.ordem");
	}
	public function filtroItem($c, $a, $coluna = NULL, $val = NULL) {
		$funcoes = new Funcoes();
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		$condicao = array(
			'1'	=> " WHERE LOWER(i.{$coluna}) = '{$val}' ",
			'2' => " WHERE LOWER(i.{$coluna}) LIKE '%{$val}%' ",
			'3'	=> " ",
		);
		$ativo = array(
			'1' => "AND i.ativo = '1' ",
			'2' => "AND i.ativo = '0' ",
			'3' => "",
		);
		
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT i.item, i.des_item, i.ativo
		FROM finan_item i{$condicao[$c]}{$ativo[$a]}ORDER BY i.des_item ASC) R ) R2");
	}
	
	public function addItem(Item $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_item = strtoupper($funcoes->retiraAcentos(trim($obj->des_item)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'finan_item','item');
	}
	
	public function addItemadiantamento(Itemadiantamento $obj,$currval = NULL) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$obj = array_filter($obj, function($v){return $v != 'anexo';}, ARRAY_FILTER_USE_KEY);
		if ($currval != NULL){
			return $prepare->PrepareInsert($obj, 'finan_item_adiantamento',"",$currval);
		}else{
			return $prepare->PrepareInsert($obj, 'finan_item_adiantamento');
		}
	}
	
	public function editItem(Item $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_item = strtoupper($funcoes->retiraAcentos(trim($obj->des_item)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'item';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('item' => $obj['item']), 'finan_item');
	}
	
	public function editItemadiantamento(Itemadiantamento $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'ordem' && $v != 'adiantamento' && $v != 'anexo';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('ordem' => $obj['ordem'], 'adiantamento' => $obj['adiantamento']), 'finan_item_adiantamento');
	}
	
	public function delItem(Item $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('item' => $obj->item), 'finan_item');
	}
	
	public function delItemadiantamento(Itemadiantamento $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('adiantamento' => $obj->adiantamento), 'finan_item_adiantamento');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}