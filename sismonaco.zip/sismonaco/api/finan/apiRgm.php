<?php

namespace api\finan;

use lib\Model;
use obj\finan\Rgm;
use helper\PrepareSQL;
use helper\Funcoes;
use obj\adm\Usuario;


class apiRgm extends Model {
	
	public function addRgm(Rgm $obj){
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'sis_finan_rgm_cadastro');
	}
	
	public function getRgmCadastro(Usuario $obj) {
		return $this->First($this->Select("SELECT s.usuario, s.dta_cadastro, s.rgm, s.aceito
				FROM sis_finan_rgm_cadastro s
				WHERE s.aceito = 1 AND s.usuario = '{$obj->usuario}'"));
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
	
}