<?php

namespace api\ged;

use lib\Model;
use obj\ged\Usuarioavisoorgao;
use helper\PrepareSQL;

class apiUsuarioavisoorgao extends Model {
	
	public function getUsuarioavisoorgao(Usuarioavisoorgao $obj) {
		return  $this->First($this->Select("SELECT uao.usuario, u.nome, uao.aviso, a.des_aviso, uao.orgao, o.des_orgao
		FROM ged_usuario_aviso_orgao uao
		JOIN sis_usuario u ON uao.usuario = u.usuario
		JOIN ged_aviso a ON uao.aviso = a.aviso
		JOIN ged_orgao o ON uao.orgao = o.orgao
		WHERE uao.usuario = '{$obj->usuario}' AND uao.aviso = '{$obj->aviso}' AND uao.orgao = '{$obj->orgao}'"));
	}
	
	public function filtroUsuarioavisoorgao($condicao) {
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM (SELECT uao.usuario,
		CASE WHEN uao.usuario LIKE '#%' 
		THEN (SELECT g.des_reduzida FROM ged_grupo g WHERE g.grupo = substr(uao.usuario,2))
		ELSE (SELECT nome FROM sis_usuario u  WHERE u.usuario = uao.usuario) END nome,
		uao.aviso,a.des_aviso,uao.orgao,o.des_orgao
		FROM ged_usuario_aviso_orgao uao
		JOIN ged_aviso a ON uao.aviso = a.aviso
		JOIN ged_orgao o ON uao.orgao = o.orgao
		JOIN sis_empresa e ON o.empresa = e.empresa
		WHERE {$condicao}ORDER BY uao.orgao ASC) R ) R2");
	}
	
	public function getUsuariosvinculados($aviso,$orgao) {
		return $this->Select("SELECT uao.usuario,u.email,uao.aviso, uao.orgao 
		FROM ged_usuario_aviso_orgao uao
		LEFT JOIN ged_grupo_usuario gu ON CASE WHEN uao.usuario LIKE '#%' THEN substr(uao.usuario,2) END = gu.grupo
		JOIN sis_usuario u ON CASE WHEN uao.usuario NOT LIKE '#%' THEN uao.usuario else to_char(gu.usuario,'9999999999') end = u.usuario
		WHERE uao.aviso = '{$aviso}' AND uao.orgao = '{$orgao}'");
	}
	
	public function addUsuarioavisoorgao(Usuarioavisoorgao $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareInsert($obj, 'ged_usuario_aviso_orgao');
	}
	
	public function delUsuarioavisoorgao(Usuarioavisoorgao $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('usuario' => $obj->usuario, 'aviso' => $obj->aviso, 'orgao' => $obj->orgao), 'ged_usuario_aviso_orgao');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}