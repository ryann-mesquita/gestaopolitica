<?php

namespace api\ged;

use lib\Model;
use obj\ged\Orgao;
use helper\PrepareSQL;
use helper\Funcoes;

class apiOrgao extends Model {
	
	public function getOrgao(Orgao $obj) {
		return  $this->First($this->Select("SELECT o.orgao, o.des_orgao, o.tipo, t.des_tipo, o.site, 
		o.email, o.telefone, o.contato, o.empresa, e.des_empresa, o.ativo
		FROM ged_orgao o
		JOIN ged_tipo t ON o.tipo = t.tipo 
		JOIN sis_empresa e ON o.empresa = e.empresa
		WHERE o.orgao = '{$obj->orgao}' AND o.empresa = '{$obj->empresa}'"));
	}
	
	public function filtroOrgao($c, $a, $coluna = NULL, $val = NULL, $empresa = NULL) {
		$funcoes = new Funcoes();
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		$condicao = array(
			'1'	=> " WHERE LOWER(o.{$coluna}) = '{$val}' AND o.empresa = '{$empresa}' ",
			'2' => " WHERE LOWER(o.{$coluna}) LIKE '%{$val}%' AND o.empresa = '{$empresa}' ",
			'3'	=> " ",
			'4' => " WHERE LOWER(o.{$coluna}) LIKE '%{$val}%' AND o.empresa = '{$empresa}' "
		);
		$ativo = array(
			'1' => "AND o.ativo = '1' ",
			'2' => "AND o.ativo = '0' ",
			'3' => "",
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM (SELECT o.orgao, o.des_orgao, o.tipo, t.des_tipo, o.site, o.email, 
		o.telefone, o.contato, o.empresa, e.des_empresa, o.ativo
		FROM ged_orgao o
		JOIN ged_tipo t ON o.tipo = t.tipo
		JOIN sis_empresa e ON o.empresa = e.empresa{$condicao[$c]}{$ativo[$a]}ORDER BY o.orgao DESC) R ) R2");
	}
	
	public function addOrgao(Orgao $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_orgao = strtoupper($funcoes->retiraAcentos(trim($obj->des_orgao)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'ged_orgao','orgao');
	}
	
	public function editOrgao(Orgao $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_orgao = strtoupper($funcoes->retiraAcentos(trim($obj->des_orgao)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'orgao';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('orgao' => $obj['orgao']), 'ged_orgao');
	}
	
	public function delOrgao(Orgao $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('orgao' => $obj->orgao), 'ged_orgao');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}