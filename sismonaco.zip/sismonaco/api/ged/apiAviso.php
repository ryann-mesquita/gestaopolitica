<?php

namespace api\ged;

use lib\Model;
use obj\ged\Aviso;
use helper\PrepareSQL;
use helper\Funcoes;

class apiAviso extends Model {
	
	public function getAviso(Aviso $obj) {
		return  $this->First($this->Select("SELECT * FROM ged_aviso WHERE aviso = '{$obj->aviso}'"));
	}
	
	public function filtroAviso($c, $a, $coluna = NULL, $val = NULL) {
		$funcoes = new Funcoes();
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		$condicao = array(
				'1'	=> " WHERE LOWER(a.{$coluna}) = '{$val}' ",
				'2' => " WHERE LOWER(a.{$coluna}) LIKE '%{$val}%' ",
				'3'	=> " ",
		);
		$ativo = array(
				'1' => "AND a.ativo = '1' ",
				'2' => "AND a.ativo = '0' ",
				'3' => "",
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM (SELECT a.aviso, a.des_aviso, a.aviso1, a.aviso2, a.aviso3, a.aviso_a_cada, a.ativo
		FROM ged_aviso a{$condicao[$c]}{$ativo[$a]}ORDER BY a.aviso DESC) R ) R2");
	}
	
	public function addAviso(Aviso $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_aviso = strtoupper($funcoes->retiraAcentos(trim($obj->des_aviso)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'ged_aviso','aviso');
	}
	
	public function editAviso(Aviso $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_aviso = strtoupper($funcoes->retiraAcentos(trim($obj->des_aviso)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'aviso';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('aviso' => $obj['aviso']), 'ged_aviso');
	}
	
	public function delAviso(Aviso $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('aviso' => $obj->aviso), 'ged_aviso');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}