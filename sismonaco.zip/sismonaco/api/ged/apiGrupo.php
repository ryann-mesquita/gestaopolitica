<?php

namespace api\ged;

use lib\Model;
use obj\ged\Grupo;
use helper\PrepareSQL;
use helper\Funcoes;

class apiGrupo extends Model {
	
	public function getGrupo(Grupo $obj) {
		return  $this->First($this->Select("SELECT * FROM ged_grupo WHERE grupo = '{$obj->grupo}'"));
	}
	
	public function filtroGrupo($c, $a, $coluna = NULL, $val = NULL) {
		$funcoes = new Funcoes();
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		$condicao = array(
			'1'	=> " WHERE LOWER(g.{$coluna}) = '{$val}' ",
			'2' => " WHERE LOWER(g.{$coluna}) LIKE '%{$val}%' ",
			'3'	=> " ",
		);
		$ativo = array(
			'1' => "AND g.ativo = '1' ",
			'2' => "AND g.ativo = '0' ",
			'3' => "",
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT g.grupo, g.des_reduzida, g.des_grupo, g.ativo
		FROM ged_grupo g{$condicao[$c]}{$ativo[$a]}ORDER BY g.grupo DESC) R ) R2");
	}
	
	public function addGrupo(Grupo $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_reduzida = strtoupper($funcoes->retiraAcentos(trim($obj->des_reduzida)));
		$obj->des_grupo = strtoupper($funcoes->retiraAcentos(trim($obj->des_grupo)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'ged_grupo','grupo');
	}
	
	public function editGrupo(Grupo $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_reduzida = strtoupper($funcoes->retiraAcentos(trim($obj->des_reduzida)));
		$obj->des_grupo = strtoupper($funcoes->retiraAcentos(trim($obj->des_grupo)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'grupo';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('grupo' => $obj['grupo']), 'ged_grupo');
	}
	
	public function delGrupo(Grupo $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('grupo' => $obj->grupo), 'ged_grupo');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}