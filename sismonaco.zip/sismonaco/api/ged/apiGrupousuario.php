<?php

namespace api\ged;

use lib\Model;
use obj\ged\Grupousuario;
use helper\PrepareSQL;

class apiGrupousuario extends Model {
	
	public function getGrupousuario(Grupousuario $obj) {
		return  $this->First($this->Select("SELECT gu.usuario, u.nome, gu.grupo, g.des_grupo, 
		gu.empresa, e.des_empresa
		FROM ged_grupo_usuario gu
		JOIN sis_usuario u ON gu.usuario = u.usuario
		JOIN ged_grupo g ON gu.grupo = g.grupo
		JOIN sis_empresa e ON gu.empresa = e.empresa
		WHERE gu.usuario = '{$obj->usuario}' AND gu.grupo = '{$obj->grupo}' AND gu.empresa = '{$obj->empresa}'"));
	}
	
	public function filtroGrupousuario($condicao) {
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM (SELECT gu.usuario, u.nome, gu.grupo, g.des_reduzida,
		g.des_grupo, gu.empresa, e.des_empresa
		FROM ged_grupo_usuario gu
		JOIN sis_usuario u ON gu.usuario = u.usuario
		JOIN ged_grupo g ON gu.grupo = g.grupo
		JOIN sis_empresa e ON gu.empresa = e.empresa WHERE {$condicao}
		ORDER BY gu.empresa ASC, gu.grupo ASC, gu.usuario ASC) R ) R2");
	}
	
	public function addGrupousuario(Grupousuario $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareInsert($obj, 'ged_grupo_usuario');
	}
	
	public function delGrupousuario(Grupousuario $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('usuario' => $obj->usuario, 'grupo' => $obj->grupo, 'empresa' => $obj->empresa), 'ged_grupo_usuario');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}