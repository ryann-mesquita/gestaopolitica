<?php

namespace api\ged;

use lib\Model;
use obj\ged\Documento;
use helper\PrepareSQL;
use helper\Funcoes;

class apiDocumento extends Model {

	public function getDocumento(Documento $obj) {
		return $this->First($this->Select("SELECT d.documento, d.aviso, a.des_aviso, a.aviso1, a.aviso2, a.aviso3, 
		a.aviso_a_cada, d.orgao, o.des_orgao, o.telefone, o.site, o.contato, o.email, d.n_referencia,
		d.des_documento, d.dta_emissao, d.dta_vencimento, d.anexo, d.obs, d.status_aviso1, d.status_aviso2,
		d.status_aviso3, d.empresa, e.des_empresa, e.cnpj, e.uf, e.cidade, d.ativo 
		FROM ged_documento d 
		JOIN ged_aviso a ON d.aviso = a.aviso 
		JOIN ged_orgao o ON d.orgao = o.orgao
		JOIN ged_tipo t ON o.tipo = t.tipo
		JOIN sis_empresa e ON d.empresa = e.empresa   
		WHERE d.documento = '{$obj->documento}' AND d.empresa='{$obj->empresa}' "));
	}

	public function filtroDocumento($c, $a, $coluna = NULL, $val = NULL, $empresa = NULL) {
		$funcoes = new Funcoes();
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		$condicao = array(
			'1'	=> " WHERE LOWER(d.{$coluna}) = '{$val}' AND d.empresa = '{$empresa}' ",
			'2' => " WHERE LOWER(d.{$coluna}) LIKE '%{$val}%' AND d.empresa = '{$empresa}' ",
			'3'	=> " WHERE d.empresa is not null ",
		);
		$ativo = array(
			'1' => "AND d.ativo = '1' ",
			'2' => "AND d.ativo = '0' ",
			'3' => "",
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT d.documento, d.aviso, a.des_aviso, a.aviso1, a.aviso2, a.aviso3, 
		a.aviso_a_cada, d.orgao, o.des_orgao, o.telefone, o.site, o.contato, o.email, d.n_referencia,
		d.des_documento, d.dta_emissao, d.dta_vencimento, d.anexo, d.obs, d.status_aviso1, d.status_aviso2,
		d.status_aviso3, d.empresa, e.des_empresa, e.cnpj, e.uf, e.cidade, d.ativo 
		FROM ged_documento d 
		JOIN ged_aviso a ON d.aviso = a.aviso 
		JOIN ged_orgao o ON d.orgao = o.orgao
		JOIN ged_tipo t ON o.tipo = t.tipo
		JOIN sis_empresa e ON d.empresa = e.empresa{$condicao[$c]}{$ativo[$a]}ORDER BY d.documento DESC) R ) R2");
	}
	
	public function getUltimosenviados($rotina){	
		return $this->Select(" SELECT e.rotina, to_char(to_date(e.dta_enviado,'dd/mm/yyyy hh24:mi:ss'),'dd/mm/yyyy') dta_enviado FROM sis_email e 
	    WHERE e.rotina = '{$rotina}' AND e.assunto like 'Aviso do GED N%'
	    GROUP BY e.rotina, to_char(to_date(e.dta_enviado,'dd/mm/yyyy hh24:mi:ss'),'dd/mm/yyyy')
	    ORDER BY to_char(to_date(e.dta_enviado, 'dd/mm/yyyy hh24:mi:ss'),'dd/mm/yyyy') DESC");
	}
	
	public function addDocumento(Documento $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_documento = strtoupper($funcoes->retiraAcentos(trim($obj->des_documento)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'ged_documento','documento');
	}
	
	public function editDocumento(Documento $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		if (isset($obj->des_documento)){
			$obj->des_documento = strtoupper($funcoes->retiraAcentos(trim($obj->des_documento)));
		}
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'documento';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('documento' => $obj['documento']), 'ged_documento');
	}
	
	public function delDocumento(Documento $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('documento' => $obj->documento), 'ged_documento');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}