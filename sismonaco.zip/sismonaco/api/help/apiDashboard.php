<?php

namespace api\help;

use lib\Model;

class apiDashboard extends Model {

	public function dashboard($ambiente, $dashboard,$data) {
		if ($dashboard == "produtividade"){
			return  $this->Select("SELECT t.tecnico, a.des_ambiente, u.nome,nvl(ch1.atendimento,0) atendimento, nvl(ch2.aberto,0) aberto ,
			nvl(ch3.fechado,0) fechado, nvl(ch4.no_prazo,0) no_prazo, nvl(ch5.demanda,0) demanda
			FROM help_tecnico t
			JOIN sis_usuario u ON t.tecnico = u.usuario
			JOIN help_tecnico_ambiente ta ON t.tecnico = ta.tecnico
			JOIN help_ambiente a ON ta.ambiente = a.ambiente
			LEFT JOIN (select c.tecnico, nvl(count(c.tecnico),0) atendimento 
			from help_chamado c join help_status s on c.status = s.status 
		    join help_tecnico_ambiente ta on c.tecnico = ta.tecnico and ta.ambiente = '{$ambiente}' 
		    where ta.ambiente = '{$ambiente}' and s.situacao = 'EA' and 
		    to_char(to_date(c.dta_abertura,'dd/mm/yyyy hh24:mi:ss'),'mm/yyyy') = '{$data}' 
		    group by c.tecnico) ch1 ON t.tecnico = ch1.tecnico
			LEFT JOIN (select c.tecnico, nvl(count(c.tecnico),0) aberto 
			from help_chamado c join help_status s on c.status = s.status 
      		join help_tecnico_ambiente ta on c.tecnico = ta.tecnico and ta.ambiente = '{$ambiente}'
      		where ta.ambiente = '{$ambiente}' and to_char(to_date(dta_abertura,'dd/mm/yyyy hh24:mi:ss'),'mm/yyyy') = '{$data}'
			and s.situacao <> 'C' group by c.tecnico) ch2 on t.tecnico = ch2.tecnico
			LEFT JOIN (select c.tecnico, nvl(count(c.tecnico),0) fechado 
			from help_chamado c join help_status s on c.status = s.status
      		join help_tecnico_ambiente ta on c.tecnico = ta.tecnico and ta.ambiente = '{$ambiente}'
      		where ta.ambiente = '{$ambiente}' and to_char(to_date(c.dta_fechamento,'dd/mm/yyyy hh24:mi:ss'),'mm/yyyy') = '{$data}'
			and s.situacao = 'C' group by c.tecnico) ch3 on t.tecnico = ch3.tecnico
			LEFT JOIN (select c.tecnico, nvl(count(c.tecnico),0) no_prazo 
		    from help_chamado c join help_status st on c.status = st.status
        	join help_tecnico_ambiente ta on c.tecnico = ta.tecnico and ta.ambiente = '{$ambiente}'
		    join help_subcategoria s on c.subcategoria = s.subcategoria 
		    where ta.ambiente = '{$ambiente}' and situacao = 'C' 
        	and to_char(to_date(c.dta_fechamento,'dd/mm/yyyy hh24:mi:ss'),'mm/yyyy') = '{$data}' and 
		    ((to_date(c.dta_fechamento,'dd/mm/yyyy hh24:mi:ss') <= to_date(c.dta_vencimento,'dd/mm/yyyy hh24:mi:ss'))
		    or (c.tempo_atendimento < (s.tempo_atendimento*60))) group by c.tecnico) ch4 ON t.tecnico = ch4.tecnico
			LEFT JOIN (select c.tecnico, nvl(count(c.tecnico),0) demanda 
			from help_chamado c join help_tecnico_ambiente ta on c.tecnico = ta.tecnico and ta.ambiente = '{$ambiente}'
        	where ta.ambiente = '{$ambiente}' and  
			(to_char(to_date(c.dta_abertura,'dd/mm/yyyy hh24:mi:ss'),'mm/yyyy') = '{$data}')
			or (to_char(to_date(c.dta_fechamento,'dd/mm/yyyy hh24:mi:ss'),'mm/yyyy') = '{$data}')
			group by c.tecnico) ch5 ON t.tecnico = ch5.tecnico
			WHERE ta.ambiente = '{$ambiente}'
			ORDER BY nvl(ch3.fechado,0) DESC,  u.nome ASC");
		}
		
		if ($dashboard == "atraso"){
			return  $this->Select("SELECT c.chamado, e.des_empresa empresa, c.dta_abertura, c.dta_vencimento, c.assunto,
			u1.nome tecnico, u2.nome solicitante, s.des_subcategoria subcategoria, st.des_status status
			FROM help_chamado c
			JOIN sis_empresa e ON c.empresa = e.empresa
			JOIN sis_usuario u1 ON c.tecnico = u1.usuario
			JOIN sis_usuario u2 ON c.solicitante = u2.usuario
			JOIN help_subcategoria s ON c.subcategoria = s.subcategoria
			JOIN help_status st ON c.status = st.status
			WHERE to_char(to_date(c.dta_abertura, 'dd/mm/yyyy hh24:mi:ss'),'mm/yyyy') =  '{$data}' AND
			c.status NOT IN ('3','7','9','10') AND c.ambiente = '{$ambiente}' AND
			to_date(c.dta_vencimento,'dd/mm/yyyy hh24:mi:ss') < sysdate");
		}
		
		if ($dashboard == "externo"){
			return  $this->Select("SELECT e.des_empresa empresa, c.chamado, c.dta_externo, c.previsao_externo, 
			c.chamado_externo, c.chamado_dvi, c.cod_empresa, c.assunto, u1.nome as criador,u2.nome as tecnico, 
			ca.des_categoria as categoria, s.des_subcategoria subcategoria, d.des_departamento as departamento,
  			t.des_tipo as ocorrencia
			FROM help_chamado c
			JOIN sis_usuario u1 ON c.solicitante = u1.usuario
			JOIN sis_usuario u2 ON c.tecnico = u2.usuario
			JOIN help_subcategoria s ON c.subcategoria = s.subcategoria
			JOIN help_categoria ca ON s.categoria = ca.categoria
			JOIN sis_empresa e ON c.empresa = e.empresa
			JOIN sis_departamento d ON c.departamento = d.departamento
			JOIN help_tipo t ON c.tipo = t.tipo
			JOIN help_status st ON c.status = st.status
			WHERE c.status = 3 and c.ambiente = '{$ambiente}'
			ORDER BY c.chamado");
		}
		
		if ($dashboard == "analitico"){
			return $this->Select("SELECT c.chamado,c.assunto,u1.nome as criador , u2.nome as tecnico,
			ca.des_categoria as categoria, s.des_subcategoria as subcategoria,
			e.des_empresa as empresa, d.des_departamento as departamento,
			t.des_tipo as ocorrencia, st.des_status, 
			to_char(to_date(c.dta_abertura,'dd/mm/yyyy hh24:mi:ss'),'dd/mm/yyyy') as dta_abertura,
			round(((m.primeiro_movimento - to_date(c.dta_abertura,'dd/mm/yyyy hh24:mi:ss')) * 1440)) primeiro_movimento,
			to_char(to_date(c.dta_vencimento,'dd/mm/yyyy hh24:mi:ss'),'dd/mm/yyyy') as dta_vencimento,
			c.tempo_atendimento,c.tempo_aguardando,c.tempo_outros, 
			s.tempo_atendimento as tempo_subcategoria,
			to_char(to_date(c.dta_fechamento,'dd/mm/yyyy hh24:mi:ss'),'dd/mm/yyyy') as dta_fechamento,
			CASE WHEN c.status in ('7','9','10') and 
			to_char(to_date(c.dta_fechamento,'dd/mm/yyyy hh24:mi:ss'),'mm/yyyy') = '{$data}' and 
			((to_date(c.dta_fechamento,'dd/mm/yyyy hh24:mi:ss') <= to_date(c.dta_vencimento,'dd/mm/yyyy hh24:mi:ss'))
			or (c.tempo_atendimento < (s.tempo_atendimento*60))) THEN 'No Prazo'
			ELSE 'Fora do Prazo' END Prazo
			FROM help_chamado c
			LEFT JOIN (select distinct c.chamado, min(to_date(m.dta_movimento, 'dd/mm/yyyy hh24:mi:ss')) as primeiro_movimento from help_chamado c
			join help_movimento m ON c.chamado = m.chamado where c.ambiente = '{$ambiente}'
			group by c.chamado) m ON c.chamado = m.chamado
			JOIN sis_usuario u1 ON c.solicitante = u1.usuario
			JOIN sis_usuario u2 ON c.tecnico = u2.usuario
			JOIN help_subcategoria s ON c.subcategoria = s.subcategoria
			JOIN help_categoria ca ON s.categoria = ca.categoria
			JOIN sis_empresa e ON c.empresa = e.empresa
			JOIN sis_departamento d ON c.departamento = d.departamento
			JOIN help_tipo t ON c.tipo = t.tipo
			JOIN help_status st ON c.status = st.status
			WHERE to_char(to_date(dta_abertura,'dd/mm/yyyy hh24:mi:ss'),'mm/yyyy') = '{$data}' and c.ambiente = '{$ambiente}'
			ORDER BY c.chamado");
		}
	}
	
	public function getCapaconsolidado($ano, $mes) {
		return  $this->Select("select * from help_consolidado where ano = '$ano' and mes between 1 and {$mes}
		ORDER BY mes");
	}
	
	public function getProjetos($ano, $mes) {
		return  $this->Select("select p.* from help_projeto p where p.ano = '{$ano}' and p.mes = '{$mes}' ");
	}
	
	public function getCapamesatual($ambiente, $ano, $mes) {
		return  $this->Select("SELECT c1.mes, c1.aberto,nvl(c2.qtd,0) noprazo,nvl(c3.qtd,0) comatraso,nvl(c4.externo,0) externo,
		nvl(c5.semfeedback,0) semfeedback, c6.tempoinicio, c7.tempoconclusao
		FROM (SELECT to_number(to_char(to_date(c.dta_abertura, 'dd/mm/yyyy hh24:mi:ss'),'mm')) as mes, count(c.dta_abertura) aberto
		FROM help_chamado c 
		WHERE to_char(to_date(dta_abertura, 'dd/mm/yyyy hh24:mi:ss'), 'mm/yyyy') = '{$mes}/{$ano}' and c.ambiente = '{$ambiente}'
		GROUP BY to_char(to_date(c.dta_abertura, 'dd/mm/yyyy hh24:mi:ss'),'mm')
		ORDER BY to_char(to_date(c.dta_abertura, 'dd/mm/yyyy hh24:mi:ss'),'mm')) c1
		LEFT JOIN(SELECT to_char(to_date(c.dta_abertura, 'dd/mm/yyyy hh24:mi:ss'),'mm') as mes, c.prazo, count(c.prazo) qtd
		FROM (SELECT c.dta_abertura, 
		CASE WHEN c.status in ('7','9','10') and to_char(to_date(c.dta_fechamento, 'dd/mm/yyyy hh24:mi:ss'),
		'mm/yyyy') =  '{$mes}/{$ano}' and
		((to_date(c.dta_fechamento,'dd/mm/yyyy hh24:mi:ss') <= to_date(c.dta_vencimento,'dd/mm/yyyy hh24:mi:ss'))
		or (c.tempo_atendimento < (s.tempo_atendimento*60))) THEN 'No Prazo'
		ELSE 'Fora do Prazo' END prazo
		FROM help_chamado c
		JOIN help_subcategoria s ON c.subcategoria = s.subcategoria
		WHERE to_char(to_date(dta_abertura, 'dd/mm/yyyy hh24:mi:ss'), 'mm/yyyy') = '{$mes}/{$ano}' and c.ambiente = '{$ambiente}') c
		GROUP BY to_char(to_date(c.dta_abertura, 'dd/mm/yyyy hh24:mi:ss'),'mm'), c.prazo
		ORDER BY to_char(to_date(c.dta_abertura, 'dd/mm/yyyy hh24:mi:ss'),'mm'), c.prazo DESC) c2 ON c1.mes = c2.mes and c2.prazo = 'No Prazo'
		LEFT JOIN(SELECT to_char(to_date(c.dta_abertura, 'dd/mm/yyyy hh24:mi:ss'),'mm') as mes, c.prazo, count(c.prazo) qtd
		FROM (SELECT c.dta_abertura, 
		CASE WHEN c.status in ('7','9','10') and to_char(to_date(c.dta_fechamento, 'dd/mm/yyyy hh24:mi:ss'),
		'mm/yyyy') =  '{$mes}/{$ano}' and
		((to_date(c.dta_fechamento,'dd/mm/yyyy hh24:mi:ss') <= to_date(c.dta_vencimento,'dd/mm/yyyy hh24:mi:ss'))
		or (c.tempo_atendimento < (s.tempo_atendimento*60))) THEN 'No Prazo'
		ELSE 'Fora do Prazo' END prazo
		FROM help_chamado c
		LEFT JOIN help_subcategoria s ON c.subcategoria = s.subcategoria
		WHERE to_char(to_date(dta_abertura, 'dd/mm/yyyy hh24:mi:ss'), 'mm/yyyy') = '{$mes}/{$ano}' and c.ambiente = '{$ambiente}') c
		GROUP BY to_char(to_date(c.dta_abertura, 'dd/mm/yyyy hh24:mi:ss'),'mm'), c.prazo
		ORDER BY to_char(to_date(c.dta_abertura, 'dd/mm/yyyy hh24:mi:ss'),'mm'), c.prazo DESC) c3 ON c1.mes = c3.mes and c3.prazo = 'Fora do Prazo'
		LEFT JOIN(SELECT to_char(to_date(c.dta_abertura, 'dd/mm/yyyy hh24:mi:ss'),'mm') as mes, count(c.dta_abertura) externo
		FROM help_chamado c 
		WHERE to_char(to_date(dta_abertura, 'dd/mm/yyyy hh24:mi:ss'), 'mm/yyyy') = '{$mes}/{$ano}' 
		and c.ambiente = '{$ambiente}' and c.status = '3'
		GROUP BY to_char(to_date(c.dta_abertura, 'dd/mm/yyyy hh24:mi:ss'),'mm')
		ORDER BY to_char(to_date(c.dta_abertura, 'dd/mm/yyyy hh24:mi:ss'),'mm')) c4 ON c1.mes = c4.mes 
		LEFT JOIN(SELECT to_char(to_date(c.dta_abertura, 'dd/mm/yyyy hh24:mi:ss'),'mm') as mes, count(c.dta_abertura) semfeedback
		FROM help_chamado c 
		WHERE to_char(to_date(dta_abertura, 'dd/mm/yyyy hh24:mi:ss'), 'mm/yyyy') = '{$mes}/{$ano}' 
		and c.ambiente = '{$ambiente}' and c.status = '10'
		GROUP BY to_char(to_date(c.dta_abertura, 'dd/mm/yyyy hh24:mi:ss'),'mm')
		ORDER BY to_char(to_date(c.dta_abertura, 'dd/mm/yyyy hh24:mi:ss'),'mm')) c5 ON c1.mes = c5.mes
		JOIN(SELECT to_char(to_date(c.dta_abertura, 'dd/mm/yyyy hh24:mi:ss'),'mm') as mes,
		round((sum((m.primeiro_movimento - to_date(c.dta_abertura, 'dd/mm/yyyy hh24:mi:ss')) * 1440)/count(c.dta_abertura))/60,2) tempoinicio 
		FROM help_chamado c 
		JOIN (select distinct c.chamado,
		min(to_date(m.dta_movimento,'dd/mm/yyyy hh24:mi:ss')) as primeiro_movimento
		from help_chamado c join help_movimento m ON c.chamado = m.chamado
		where c.ambiente = '{$ambiente}' group by c.chamado) m ON c.chamado = m.chamado
		WHERE to_char(to_date(dta_abertura, 'dd/mm/yyyy hh24:mi:ss'), 'mm/yyyy') = '{$mes}/{$ano}' 
		and c.ambiente = '{$ambiente}'
		GROUP BY to_char(to_date(c.dta_abertura, 'dd/mm/yyyy hh24:mi:ss'),'mm')
		ORDER BY to_char(to_date(c.dta_abertura, 'dd/mm/yyyy hh24:mi:ss'),'mm')) c6 ON c1.mes = c6.mes
		JOIN(SELECT to_char(to_date(c.dta_abertura, 'dd/mm/yyyy hh24:mi:ss'),'mm') as mes, round((sum(c.tempo_atendimento)/count(c.dta_abertura))/60,2) tempoconclusao 
		FROM help_chamado c 
		WHERE to_char(to_date(dta_abertura, 'dd/mm/yyyy hh24:mi:ss'), 'mm/yyyy') = '{$mes}/{$ano}' 
		and c.ambiente = '{$ambiente}'
		GROUP BY to_char(to_date(c.dta_abertura, 'dd/mm/yyyy hh24:mi:ss'),'mm')
		ORDER BY to_char(to_date(c.dta_abertura, 'dd/mm/yyyy hh24:mi:ss'),'mm')) c7 ON c1.mes = c7.mes");
	}

	public function getTecnicos($ambiente, $ano, $mes) {
		return $this->Select("SELECT t.tecnico,u.nome||' '||e.empresa nome, nvl(c1.noprazo,0) noprazo, nvl(c2.comatraso,0) comatraso, nvl(c1.noprazo,0) + nvl(c2.comatraso,0) total
		FROM (select case when tecnico in(18,24,280,1153) then 1117 else
			tecnico end tecnico from help_chamado ch where 
			to_char(to_date(ch.dta_abertura,'dd/mm/yyyy hh24:mi:ss'),'mm/yyyy') = '{$mes}/{$ano}' and
			ch.ambiente = '{$ambiente}' group by case when ch.tecnico in(18,24,280,1153) then 1117 else
			ch.tecnico end) t
		JOIN sis_usuario u ON t.tecnico = u.usuario
		JOIN sis_empresa e ON u.empresa = e.empresa
		LEFT JOIN (select c.tecnico, count(c.ambiente) noprazo
			from (select case when ch.tecnico in(18,24,280,1153) then 1117 else
			ch.tecnico end tecnico from help_chamado ch where 
			to_char(to_date(ch.dta_abertura,'dd/mm/yyyy hh24:mi:ss'),'mm/yyyy') = '{$mes}/{$ano}' and
			ch.ambiente = '{$ambiente}' group by case when ch.tecnico in(18,24,280,1153) then 1117 else
			ch.tecnico end) ch
			left join (select case when c.tecnico in(18,24,280,1153) then 1117 else
			c.tecnico end tecnico,c.ambiente, 
			case when c.status in ('7','9','10') and to_char(to_date(c.dta_fechamento,'dd/mm/yyyy hh24:mi:ss'),'mm/yyyy') = '{$mes}/{$ano}' 
			and ((to_date(c.dta_fechamento,'dd/mm/yyyy hh24:mi:ss') <= to_date(c.dta_vencimento,'dd/mm/yyyy hh24:mi:ss')) 
			or (c.tempo_atendimento < (s.tempo_atendimento*60))) then 'noprazo' else 'comatraso' end Prazo 
			from help_chamado c 
			join help_subcategoria s on c.subcategoria = s.subcategoria 
			where to_char(to_date(dta_abertura,'dd/mm/yyyy hh24:mi:ss'),'mm/yyyy') = '{$mes}/{$ano}' 
			and ambiente = '{$ambiente}') c on ch.tecnico = c.tecnico and c.prazo = 'noprazo'
			group by c.tecnico) c1 ON t.tecnico = c1.tecnico
		
		LEFT JOIN (select c.tecnico, count(c.ambiente) comatraso
			from (select case when tecnico in(18,24,280,1153) then 1117 else
			tecnico end tecnico from help_chamado ch where 
			to_char(to_date(ch.dta_abertura,'dd/mm/yyyy hh24:mi:ss'),'mm/yyyy') = '{$mes}/{$ano}' and
			ch.ambiente = '{$ambiente}' group by case when ch.tecnico in(18,24,280,1153) then 1117 else
			ch.tecnico end) ch
			left join (select case when c.tecnico in(18,24,280,1153) then 1117 else
			c.tecnico end tecnico,c.ambiente, 
			case when c.status in ('7','9','10') and to_char(to_date(c.dta_fechamento,'dd/mm/yyyy hh24:mi:ss'),'mm/yyyy') = '{$mes}/{$ano}' 
			and ((to_date(c.dta_fechamento,'dd/mm/yyyy hh24:mi:ss') <= to_date(c.dta_vencimento,'dd/mm/yyyy hh24:mi:ss')) 
			or (c.tempo_atendimento < (s.tempo_atendimento*60))) then 'noprazo' else 'comatraso' end Prazo 
			from help_chamado c 
			join help_subcategoria s on c.subcategoria = s.subcategoria 
			where to_char(to_date(dta_abertura,'dd/mm/yyyy hh24:mi:ss'),'mm/yyyy') = '{$mes}/{$ano}' 
			and ambiente = '{$ambiente}') c on ch.tecnico = c.tecnico and c.prazo = 'comatraso'
			group by c.tecnico) c2 ON t.tecnico = c2.tecnico
		ORDER BY nvl(c1.noprazo,0) + nvl(c2.comatraso,0) DESC");
	}
	
	public function getCategoria($ambiente, $ano, $mes) {
		return $this->Select("SELECT r1.* FROM
		(select  rownum n,r.* FROM
		(select ca.des_categoria categoria, count(ca.des_categoria)qtd
		from help_chamado c  
		join help_subcategoria s on c.subcategoria = s.subcategoria
		join help_categoria ca on s.categoria = ca.categoria 
		where to_char(to_date(dta_abertura,'dd/mm/yyyy hh24:mi:ss'),'mm/yyyy') = '{$mes}/{$ano}' and c.ambiente = '{$ambiente}'
		group by ca.des_categoria order by qtd desc) r) r1 WHERE r1.n <=4
		UNION
		SELECT 6 n, 'OUTROS' categoria, sum(r2.qtd) FROM
		(select  rownum n,r.* FROM
		(select ca.des_categoria, count(ca.des_categoria)qtd
		from help_chamado c  
		join help_subcategoria s on c.subcategoria = s.subcategoria
		join help_categoria ca on s.categoria = ca.categoria 
		where to_char(to_date(dta_abertura,'dd/mm/yyyy hh24:mi:ss'),'mm/yyyy') = '{$mes}/{$ano}' and c.ambiente = '{$ambiente}'
		group by ca.des_categoria order by qtd desc) r) r2 WHERE r2.n >=5");
	}
	
	public function getDepartamento($ambiente, $ano, $mes) {
		return $this->Select("SELECT r1.* FROM
		(SELECT  rownum n,r.* FROM
		(SELECT c.departamento, count(c.departamento) qtd
		FROM (select case when d.departamento in(2,23,24) then 'VENDAS'
		when d.departamento in(20,3,4,17) then 'POS VENDAS' else
		d.des_departamento end departamento
		FROM help_chamado c  
		JOIN sis_departamento d ON c.departamento = d.departamento 
		WHERE to_char(to_date(dta_abertura,'dd/mm/yyyy hh24:mi:ss'),'mm/yyyy') = '{$mes}/{$ano}' and ambiente = '{$ambiente}') c
		GROUP BY c.departamento ORDER BY QTD DESC) r) r1 WHERE r1.n <=5
		UNION
		SELECT 6 n, 'OUTROS' departamento, sum(r2.qtd) FROM
		(SELECT  rownum n,r.* FROM
		(SELECT c.departamento, count(c.departamento) qtd
		FROM (select case when d.departamento in(2,23,24) then 'VENDAS'
		when d.departamento in(20,3,4,17) then 'POS VENDAS' else
		d.des_departamento end departamento
		FROM help_chamado c  
		JOIN sis_departamento d ON c.departamento = d.departamento 
		WHERE to_char(to_date(dta_abertura,'dd/mm/yyyy hh24:mi:ss'),'mm/yyyy') = '{$mes}/{$ano}' and ambiente = '{$ambiente}') c
		GROUP BY c.departamento ORDER BY QTD DESC) r) r2 WHERE r2.n >=6");
	}
	
	public function getTipo($ambiente, $ano, $mes) {
		return $this->Select("SELECT t.tipo,t.des_tipo tipo, count(t.des_tipo)qtd
		FROM help_chamado c  
		JOIN help_tipo t ON c.tipo = t.tipo
		where to_char(to_date(dta_abertura,'dd/mm/yyyy hh24:mi:ss'),'mm/yyyy') = '{$mes}/{$ano}' and c.ambiente = '{$ambiente}'
		GROUP BY t.tipo,t.des_tipo 
		ORDER BY t.tipo ASC");
	}
	
		/*SELECT c.chamado,c.assunto,u1.nome as criador , u2.nome as tecnico, ca.des_categoria as categoria, 
		s.des_subcategoria as subcategoria, e.des_empresa as empresa, d.des_departamento as departamento, 
		t.des_tipo as ocorrencia, st.des_status, to_char(to_date(c.dta_abertura,'dd/mm/yyyy hh24:mi:ss'),'dd/mm/yyyy') as dta_abertura, 
		round(((m.primeiro_movimento - to_date(c.dta_abertura,'dd/mm/yyyy hh24:mi:ss')) * 1440)) primeiro_movimento, 
		to_char(to_date(c.dta_vencimento,'dd/mm/yyyy hh24:mi:ss'),'dd/mm/yyyy') as dta_vencimento, c.tempo_atendimento,
		c.tempo_aguardando,c.tempo_outros, s.tempo_atendimento as tempo_subcategoria, 
		to_char(to_date(c.dta_fechamento,'dd/mm/yyyy hh24:mi:ss'),'dd/mm/yyyy') as dta_fechamento, 
		CASE WHEN c.status in ('7','9','10') and to_char(to_date(c.dta_fechamento,'dd/mm/yyyy hh24:mi:ss'),'mm/yyyy') = '05/2019' 
		and ((to_date(c.dta_fechamento,'dd/mm/yyyy hh24:mi:ss') <= to_date(c.dta_vencimento,'dd/mm/yyyy hh24:mi:ss')) 
		or (c.tempo_atendimento < (s.tempo_atendimento*60))) THEN 'No Prazo' ELSE 'Fora do Prazo' END Prazo 
		FROM help_chamado c LEFT JOIN (select distinct c.chamado, min(to_date(m.dta_movimento, 'dd/mm/yyyy hh24:mi:ss')) 
		as primeiro_movimento from help_chamado c join help_movimento m ON c.chamado = m.chamado where c.ambiente = '1' 
		group by c.chamado) m ON c.chamado = m.chamado JOIN sis_usuario u1 ON c.solicitante = u1.usuario JOIN sis_usuario 
		u2 ON c.tecnico = u2.usuario JOIN help_subcategoria s ON c.subcategoria = s.subcategoria JOIN help_categoria ca 
		ON s.categoria = ca.categoria JOIN sis_empresa e ON c.empresa = e.empresa JOIN sis_departamento d 
		ON c.departamento = d.departamento JOIN help_tipo t ON c.tipo = t.tipo JOIN help_status st 
		ON c.status = st.status WHERE to_char(to_date(dta_abertura,'dd/mm/yyyy hh24:mi:ss'),'mm/yyyy') = '05/2019' 
		and ambiente = '1' ORDER BY c.chamado*/
}