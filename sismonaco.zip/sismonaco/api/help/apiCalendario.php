<?php

namespace api\help;

use lib\Model;
use obj\help\Calendario;
use helper\PrepareSQL;

class apiCalendario extends Model {
	
	public function getCalendario() {
		return  $this->Select("SELECT c.calendario, c.plantao, c.feriado FROM help_calendario c order by c.calendario ASC");
	}
	
	public function getPlantao($dia){
		return  $this->First($this->Select("SELECT c.calendario, c.plantao, c.feriado FROM help_calendario c WHERE c.calendario = '{$dia}' "));
	}
	
	public function editCalendario(Calendario $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareUpdate($obj,array('calendario' => $obj['calendario']), 'help_calendario');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
	
}