<?php

namespace api\help;

use lib\Model;
use obj\help\Ambiente;
use helper\PrepareSQL;
use helper\Funcoes;

class apiAmbiente extends Model {
	
	public function getAmbiente(Ambiente $obj) {
		return  $this->First($this->Select("SELECT * FROM help_ambiente WHERE ambiente = '{$obj->ambiente}'"));
	}
	
	public function filtroAmbiente($c, $a, $coluna = NULL, $val = NULL) {
		$funcoes = new Funcoes();
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		$condicao = array(
			'1'	=> " WHERE LOWER(a.{$coluna}) = '{$val}' ",
			'2' => " WHERE LOWER(a.{$coluna}) LIKE '%{$val}%' ",
			'3'	=> " ",
		);
		$ativo = array(
			'1' => "AND a.ativo = '1' ",
			'2' => "AND a.ativo = '0' ",
			'3' => "",
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT a.ambiente, a.des_ambiente, a.ativo
		FROM help_ambiente a{$condicao[$c]}{$ativo[$a]}ORDER BY a.des_ambiente ASC) R ) R2");
	}
	
	public function addAmbiente(Ambiente $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_ambiente = strtoupper($funcoes->retiraAcentos(trim($obj->des_ambiente)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'help_ambiente','ambiente');
	}
	
	public function editAmbiente(Ambiente $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_ambiente = strtoupper($funcoes->retiraAcentos(trim($obj->des_ambiente)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'ambiente';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('ambiente' => $obj['ambiente']), 'help_ambiente');
	}
	
	public function delAmbiente(Ambiente $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('ambiente' => $obj->ambiente), 'help_ambiente');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}