<?php

namespace api\help;

use lib\Model;
use obj\help\Chamado;
use helper\PrepareSQL;
use helper\Funcoes;
use obj\help\Movimento;
use obj\help\Chamadonf;
use obj\help\Autorizacao;

class apiChamado extends Model {
	
	public function getChamado(Chamado $obj) {
		return  $this->First($this->Select("SELECT c.chamado, c.ambiente, am.des_ambiente, c.assunto, c.des_chamado, c.solicitante, 
		u.cpf as cpf_solicitante, u.nome as nome_solicitante, tip.des_tipo as tipo_solicitante, ca.cargo as cargo_solicitante, 
		ca.des_cargo as descargo_solicitante, de.departamento as departamento_solicitante, de.des_departamento as desdepartamento_solicitante,
		u.email as email_solicitante, u.telefone as telefone_solicitante, u.celular as celular_solicitante, u.ip, c.tecnico, t.hora_inicio, t.hora_fim, 
		u2.nome as nome_tecnico, u2.email as email_tecnico, u2.telefone as telefone_tecnico, u2.celular as celular_tecnico, 
		s.categoria, c.subcategoria, c.ambiente as ambiente_categoria, s.des_subcategoria, s.tempo_atendimento as tempo_subcategoria, 
		c.departamento, d.des_departamento, c.tipo, ti.des_tipo, c.empresa, e.des_empresa, e.razao_social, c.status, st.des_status, st.situacao,
		c.anexo1, c.anexo2, c.anexo3, c.dta_abertura, c.dta_vencimento, c.dta_fechamento, c.dta_reabertura, c.dta_ult_movimento, 
		c.tempo_atendimento, c.tempo_aguardando, c.tempo_outros, c.chamado_externo, c.chamado_dvi, c.cod_empresa, u3.usuario as funcionario, 
		u3.nome as nome_funcionario, u3.contrato, ca3.cargo as an_cargo, ca3.des_cargo as an_descargo, e3.empresa as an_empresa,
		caf.des_cargo cargo_funcionario, def.des_departamento departamento_funcionario,
		e3.razao_social as an_desempresa, de3.departamento as an_departamento, de3.des_departamento as an_desdepartamento, c.dta_admissao, 
		c.dta_demissao, u4.usuario as funcionario_substituido, u4.nome as nome_substituido, ca2.cargo as m_cargo, ca2.des_cargo as m_descargo,
		c.sigiloso, de2.departamento as m_departamento, de2.des_departamento as m_desdepartamento,c.salario, c.m_salario, 
		e2.empresa as m_empresa, e2.razao_social as m_desempresa, c.motivo, c.avaliacao, c.tempo_funcao, c.dta_vigencia, 
		c.n_vaga, c.genero, c.estado_civil, c.idade, c.perfil, c.justificativa, c.horario, c.campanha_inicio, c.campanha_fim, 
		c.campanha, c.publico, c.loja, c.obs, c.dta_externo, c.comissao, c.aut_situacao, caut.destinatario, caut.autorizante, 
		caut.dta_solicitacao, caut.dta_acao, caut.motivo as aut_motivo, caut.autorizado, u5.nome nome_destinatario, u6.nome nome_autorizante,
		c.dta_inicio, c.dta_fim, c.cc, c.destino
		FROM help_chamado c
        JOIN help_ambiente am ON c.ambiente = am.ambiente
		LEFT JOIN help_chamado_autorizacao caut ON (c.chamado = caut.chamado) AND (c.ambiente = caut.ambiente) AND (c.aut_situacao = caut.situacao)
		LEFT JOIN help_tecnico t ON c.tecnico = t.tecnico
		JOIN sis_usuario u ON c.solicitante = u.usuario
        JOIN sis_cargo ca ON u.cargo = ca.cargo
		LEFT JOIN sis_cargo ca2 ON c.m_cargo = ca2.cargo
		JOIN sis_tipo tip ON u.tipo = tip.tipo
		JOIN sis_departamento de ON u.departamento = de.departamento
        LEFT JOIN sis_usuario u2 ON c.tecnico = u2.usuario
		LEFT JOIN sis_usuario u3 ON c.funcionario = u3.usuario
		LEFT JOIN sis_departamento def ON u3.departamento = def.departamento
		LEFT JOIN sis_cargo caf ON u3.cargo = caf.cargo
        LEFT JOIN sis_cargo ca3  ON c.an_cargo = ca3.cargo
		LEFT JOIN sis_empresa e3  ON c.an_empresa = e3.empresa
		LEFT JOIN sis_departamento de3  ON c.an_departamento = de3.departamento
		LEFT JOIN sis_usuario u4 ON c.funcionario_substituido = u4.usuario
        LEFT JOIN sis_usuario u5 ON caut.destinatario = u5.usuario 
		LEFT JOIN sis_usuario u6 ON caut.autorizante = u6.usuario
		JOIN help_subcategoria s ON c.subcategoria = s.subcategoria
		JOIN sis_departamento d ON c.departamento = d.departamento
		LEFT JOIN sis_departamento de2 ON c.m_departamento = de2.departamento
		JOIN help_tipo ti ON c.tipo = ti.tipo
		JOIN sis_empresa e ON c.empresa = e.empresa
		LEFT JOIN sis_empresa e2 ON c.m_empresa = e2.empresa
		JOIN help_status st ON c.status = st.status
		WHERE c.chamado = '{$obj->chamado}' AND c.ambiente = '{$obj->ambiente}' ORDER BY c.dta_vencimento ASC"));
	}
	
	public function numeroChamado(Chamado $obj) {
		return  $this->First($this->Select("SELECT c.chamado, c.ambiente, am.des_ambiente, c.assunto, c.des_chamado, c.solicitante, 
		u.cpf as cpf_solicitante, u.nome as nome_solicitante, tip.des_tipo as tipo_solicitante, ca.cargo as cargo_solicitante, 
		ca.des_cargo as descargo_solicitante, de.departamento as departamento_solicitante, de.des_departamento as desdepartamento_solicitante,
		u.email as email_solicitante, u.telefone as telefone_solicitante, u.celular as celular_solicitante, u.ip, c.tecnico, t.hora_inicio, t.hora_fim, 
		u2.nome as nome_tecnico, u2.email as email_tecnico, u2.telefone as telefone_tecnico, u2.celular as celular_tecnico, 
		s.categoria, c.subcategoria, c.ambiente as ambiente_categoria, s.des_subcategoria, s.tempo_atendimento as tempo_subcategoria, 
		c.departamento, d.des_departamento, c.tipo, ti.des_tipo, c.empresa, e.des_empresa, e.razao_social, c.status, st.des_status, st.situacao,
		c.anexo1, c.anexo2, c.anexo3, c.dta_abertura, c.dta_vencimento, c.dta_fechamento, c.dta_reabertura, c.dta_ult_movimento, 
		c.tempo_atendimento, c.tempo_aguardando, c.tempo_outros, c.chamado_externo, c.chamado_dvi, c.cod_empresa, u3.usuario as funcionario, 
		u3.nome as nome_funcionario, u3.contrato, ca3.cargo as an_cargo, ca3.des_cargo as an_descargo, e3.empresa as an_empresa,
		caf.des_cargo cargo_funcionario, def.des_departamento departamento_funcionario,
		e3.razao_social as an_desempresa, de3.departamento as an_departamento, de3.des_departamento as an_desdepartamento, c.dta_admissao, 
		c.dta_demissao, u4.usuario as funcionario_substituido, u4.nome as nome_substituido, ca2.cargo as m_cargo, ca2.des_cargo as m_descargo,
		c.sigiloso, de2.departamento as m_departamento, de2.des_departamento as m_desdepartamento,c.salario, c.m_salario, 
		e2.empresa as m_empresa, e2.razao_social as m_desempresa, c.motivo, c.avaliacao, c.tempo_funcao, c.dta_vigencia, 
		c.n_vaga, c.genero, c.estado_civil, c.idade, c.perfil, c.justificativa, c.horario, c.campanha_inicio, c.campanha_fim, 
		c.campanha, c.publico, c.loja, c.obs, c.dta_externo, c.comissao, c.aut_situacao, caut.destinatario, caut.autorizante, 
		caut.dta_solicitacao, caut.dta_acao, caut.motivo as aut_motivo, caut.autorizado, u5.nome nome_destinatario, u5.email email_destinatario, u6.nome nome_autorizante,
		c.dta_inicio, c.dta_fim, c.cc, c.destino
		FROM help_chamado c
        JOIN help_ambiente am ON c.ambiente = am.ambiente
		LEFT JOIN help_chamado_autorizacao caut ON (c.chamado = caut.chamado) AND (c.ambiente = caut.ambiente) AND (c.aut_situacao = caut.situacao)
		LEFT JOIN help_tecnico t ON c.tecnico = t.tecnico
		JOIN sis_usuario u ON c.solicitante = u.usuario
        JOIN sis_cargo ca ON u.cargo = ca.cargo
		LEFT JOIN sis_cargo ca2 ON c.m_cargo = ca2.cargo
		JOIN sis_tipo tip ON u.tipo = tip.tipo
		JOIN sis_departamento de ON u.departamento = de.departamento
        LEFT JOIN sis_usuario u2 ON c.tecnico = u2.usuario
		LEFT JOIN sis_usuario u3 ON c.funcionario = u3.usuario
		LEFT JOIN sis_departamento def ON u3.departamento = def.departamento
		LEFT JOIN sis_cargo caf ON u3.cargo = caf.cargo
        LEFT JOIN sis_cargo ca3  ON c.an_cargo = ca3.cargo
		LEFT JOIN sis_empresa e3  ON c.an_empresa = e3.empresa
		LEFT JOIN sis_departamento de3  ON c.an_departamento = de3.departamento
		LEFT JOIN sis_usuario u4 ON c.funcionario_substituido = u4.usuario
        LEFT JOIN sis_usuario u5 ON caut.destinatario = u5.usuario 
		LEFT JOIN sis_usuario u6 ON caut.autorizante = u6.usuario
		JOIN help_subcategoria s ON c.subcategoria = s.subcategoria
		JOIN sis_departamento d ON c.departamento = d.departamento
		LEFT JOIN sis_departamento de2 ON c.m_departamento = de2.departamento
		JOIN help_tipo ti ON c.tipo = ti.tipo
		JOIN sis_empresa e ON c.empresa = e.empresa
		LEFT JOIN sis_empresa e2 ON c.m_empresa = e2.empresa
		JOIN help_status st ON c.status = st.status
		WHERE c.solicitante = {$obj->solicitante} AND c.chamado = ((SELECT last_number FROM user_sequences WHERE sequence_name = 'SEQ_HELP_CHAMADO_{$obj->ambiente}') - 1)"));
	}
	
	public function notificacaoChamado($usuario) {
		return  $this->Select("SELECT c.chamado, c.ambiente, am.des_ambiente, c.assunto, c.des_chamado, c.solicitante, 
		u.cpf as cpf_solicitante, u.nome as nome_solicitante, tip.des_tipo as tipo_solicitante, ca.des_cargo as cargo_solicitante, 
		de.des_departamento as departamento_solicitante, u.email as email_solicitante, u.telefone as telefone_solicitante, 
		u.celular as celular_solicitante, u.ip, c.tecnico, t.hora_inicio, t.hora_fim,
		u2.nome as nome_tecnico, u2.email as email_tecnico, u2.telefone as telefone_tecnico, u2.celular as celular_tecnico,
		s.categoria, c.subcategoria, c.ambiente as ambiente_categoria, s.des_subcategoria, s.tempo_atendimento as tempo_subcategoria, c.departamento, d.des_departamento, c.tipo, ti.des_tipo, 
		c.empresa, e.des_empresa, e.razao_social, c.status, st.des_status, st.situacao, c.anexo1, c.anexo2, c.anexo3, c.dta_abertura, c.dta_vencimento, 
		c.dta_fechamento, c.dta_reabertura, c.dta_ult_movimento, c.tempo_atendimento, c.tempo_aguardando, c.tempo_outros, 
		c.chamado_externo, c.chamado_dvi, c.cod_empresa, u3.nome as funcionario, c.dta_admissao, c.dta_demissao, u4.nome as funcionario_substituido, 
		ca2.des_cargo as m_cargo, c.sigiloso, de2.des_departamento as m_departamento, c.loja, c.salario, e2.des_empresa as m_empresa, c.motivo, c.avaliacao, c.tempo_funcao, 
		c.dta_vigencia, c.n_vaga, c.genero, c.estado_civil, c.idade, c.perfil, c.justificativa, c.horario, c.campanha_inicio, c.campanha_fim, 
		c.campanha, c.publico, c.loja, c.obs, c.dta_externo, c.comissao, c.aut_situacao, caut.destinatario, caut.autorizante, 
		caut.dta_solicitacao, caut.dta_acao, caut.motivo as aut_motivo, caut.autorizado, u5.nome nome_destinatario, u6.nome nome_autorizante,
		c.dta_inicio, c.dta_fim, c.cc, c.destino
		FROM help_chamado c
        LEFT JOIN help_ambiente am ON c.ambiente = am.ambiente
	    LEFT JOIN help_chamado_autorizacao caut ON (c.chamado = caut.chamado) AND (c.ambiente = caut.ambiente) AND (c.aut_situacao = caut.situacao)
		JOIN help_tecnico t ON c.tecnico = t.tecnico
		JOIN sis_usuario u ON c.solicitante = u.usuario
        JOIN sis_cargo ca ON u.cargo = ca.cargo
		LEFT JOIN sis_cargo ca2 ON c.m_cargo = ca2.cargo
		JOIN sis_tipo tip ON u.tipo = tip.tipo
		JOIN sis_departamento de ON u.departamento = de.departamento
        LEFT JOIN sis_usuario u2 ON c.tecnico = u2.usuario
		LEFT JOIN sis_usuario u3 ON c.funcionario = u3.usuario
		LEFT JOIN sis_usuario u4 ON c.funcionario_substituido = u4.usuario
		LEFT JOIN sis_usuario u5 ON caut.destinatario = u5.usuario 
		LEFT JOIN sis_usuario u6 ON caut.autorizante = u6.usuario
		JOIN help_subcategoria s ON c.subcategoria = s.subcategoria
		JOIN sis_departamento d ON c.departamento = d.departamento
		LEFT JOIN sis_departamento de2 ON c.m_departamento = de2.departamento
		JOIN help_tipo ti ON c.tipo = ti.tipo
		JOIN sis_empresa e ON c.empresa = e.empresa
		LEFT JOIN sis_empresa e2 ON c.m_empresa = e2.empresa
		JOIN help_status st ON c.status = st.status
		WHERE (c.solicitante = '{$usuario}' AND c.status = '4')
		OR (c.tecnico = '{$usuario}' AND c.status = '8')
		ORDER BY c.dta_vencimento ASC");
	}
	
	public function consultaChamado($c, $tecnico, $status, $ambiente, $coluna, $val = NULL, $de = NULL, $ate = NULL) {
		$funcoes = new Funcoes();
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		if ($coluna == 'cn.nota_fiscal'){
			$nf = "LEFT JOIN help_chamado_nf cn ON c.chamado = cn.chamado AND c.ambiente = am.ambiente AND cn.nota_fiscal = '{$val}'";
		}else{
			$nf = "";
		}
		
		if ($status == "tudo"){
			$sta = "WHERE st.situacao is not null ";
		}elseif ($status == "andamento"){
			$sta = "WHERE st.situacao <> 'C' ";
		}else{
			$sta = "WHERE c.status = '{$status}' ";
		}
		
		$condicao = array(
			'1'	=> "AND LOWER({$coluna}) = '{$val}' ",
			'2' => "AND LOWER({$coluna}) LIKE '%{$val}%' ",
			'3' => "",
			'4' => "AND TO_DATE(TO_CHAR(TO_DATE({$coluna}, 'dd/mm/yyyy hh24:mi:ss'), 'dd/mm/yyyy'), 'dd/mm/yyyy') BETWEEN TO_DATE('{$de}','dd/mm/yyyy') AND TO_DATE('{$ate}','dd/mm/yyyy')"
		);
		
		if ($tecnico == NULL){
			$tec = "AND (c.solicitante = '{$_SESSION['usuario_sessao']}' OR c.tecnico = '{$_SESSION['usuario_sessao']}' OR caut.destinatario = '{$_SESSION['usuario_sessao']}') ";
			$amb = " ";
		}elseif ($tecnico == "tudo") {
			$tec = "";
			if ($ambiente == 'tudo'){
				$amb = " ";
			}elseif ($ambiente != NULL){
				$amb = " AND c.ambiente = '{$ambiente}' ";
			}else{
				$amb = " AND c.ambiente = '' ";
			}
		}else{
			$tec = "AND c.tecnico = '{$tecnico}'";
			if ($ambiente == 'tudo'){
				$amb = " ";
			}elseif ($ambiente != NULL){
				$amb = " AND c.ambiente = '{$ambiente}' ";
			}else{
				$amb = " AND c.ambiente = '' ";
			}
		}
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT c.chamado, c.ambiente, am.des_ambiente, c.assunto, c.des_chamado, c.solicitante, 
		u.cpf as cpf_solicitante, u.nome as nome_solicitante, tip.des_tipo as tipo_solicitante, ca.cargo as cargo_solicitante, 
		ca.des_cargo as descargo_solicitante, de.departamento as departamento_solicitante, de.des_departamento as desdepartamento_solicitante,
		u.email as email_solicitante, u.telefone as telefone_solicitante, u.celular as celular_solicitante, u.ip, c.tecnico, t.hora_inicio, t.hora_fim, 
		u2.nome as nome_tecnico, u2.email as email_tecnico, u2.telefone as telefone_tecnico, u2.celular as celular_tecnico, 
		s.categoria, c.subcategoria, c.ambiente as ambiente_categoria, s.des_subcategoria, s.tempo_atendimento as tempo_subcategoria, 
		c.departamento, d.des_departamento, c.tipo, ti.des_tipo, c.empresa, e.des_empresa, e.razao_social, c.status, st.des_status, st.situacao,
		c.anexo1, c.anexo2, c.anexo3, c.dta_abertura, c.dta_vencimento, c.dta_fechamento, c.dta_reabertura, c.dta_ult_movimento, 
		c.tempo_atendimento, c.tempo_aguardando, c.tempo_outros, c.chamado_externo, c.chamado_dvi, c.cod_empresa, u3.usuario as funcionario, 
		u3.nome as nome_funcionario, u3.contrato, ca3.cargo as an_cargo, ca3.des_cargo as an_descargo, e3.empresa as an_empresa,
		caf.des_cargo cargo_funcionario, def.des_departamento departamento_funcionario,
		e3.razao_social as an_desempresa, de3.departamento as an_departamento, de3.des_departamento as an_desdepartamento, c.dta_admissao,
		c.dta_demissao, u4.usuario as funcionario_substituido, u4.nome as nome_substituido, ca2.cargo as m_cargo, ca2.des_cargo as m_descargo,
		c.sigiloso, de2.departamento as m_departamento, de2.des_departamento as m_desdepartamento,c.salario, c.m_salario, 
		e2.empresa as m_empresa, e2.razao_social as m_desempresa, c.motivo, c.avaliacao, c.tempo_funcao, c.dta_vigencia, 
		c.n_vaga, c.genero, c.estado_civil, c.idade, c.perfil, c.justificativa, c.horario, c.campanha_inicio, c.campanha_fim, 
		c.campanha, c.publico, c.loja, c.obs, c.dta_externo, c.comissao, c.aut_situacao, caut.destinatario, caut.autorizante, 
		caut.dta_solicitacao, caut.dta_acao, caut.motivo as aut_motivo, caut.autorizado, u5.nome nome_destinatario, u6.nome nome_autorizante,
		c.dta_inicio, c.dta_fim, c.cc, c.destino
		FROM help_chamado c
        JOIN help_ambiente am ON c.ambiente = am.ambiente
        LEFT JOIN help_chamado_autorizacao caut ON (c.chamado = caut.chamado) AND (c.ambiente = caut.ambiente) AND (c.aut_situacao = caut.situacao)
		LEFT JOIN help_tecnico t ON c.tecnico = t.tecnico
		JOIN sis_usuario u ON c.solicitante = u.usuario
        JOIN sis_cargo ca ON u.cargo = ca.cargo
		LEFT JOIN sis_cargo ca2 ON c.m_cargo = ca2.cargo
		JOIN sis_tipo tip ON u.tipo = tip.tipo
		JOIN sis_departamento de ON u.departamento = de.departamento
        LEFT JOIN sis_usuario u2 ON c.tecnico = u2.usuario
		LEFT JOIN sis_usuario u3 ON c.funcionario = u3.usuario
		LEFT JOIN sis_departamento def ON u3.departamento = def.departamento
		LEFT JOIN sis_cargo caf ON u3.cargo = caf.cargo
		LEFT JOIN sis_cargo ca3  ON c.an_cargo = ca3.cargo
		LEFT JOIN sis_empresa e3  ON c.an_empresa = e3.empresa
		LEFT JOIN sis_departamento de3  ON c.an_departamento = de3.departamento
		LEFT JOIN sis_usuario u4 ON c.funcionario_substituido = u4.usuario
		LEFT JOIN sis_usuario u5 ON caut.destinatario = u5.usuario 
		LEFT JOIN sis_usuario u6 ON caut.autorizante = u6.usuario
		JOIN help_subcategoria s ON c.subcategoria = s.subcategoria
		JOIN sis_departamento d ON c.departamento = d.departamento
		LEFT JOIN sis_departamento de2 ON c.m_departamento = de2.departamento
		JOIN help_tipo ti ON c.tipo = ti.tipo
		JOIN sis_empresa e ON c.empresa = e.empresa
		LEFT JOIN sis_empresa e2 ON c.m_empresa = e2.empresa
		JOIN help_status st ON c.status = st.status {$nf}{$sta}{$condicao[$c]}{$tec}{$amb}
		ORDER BY TO_DATE(c.dta_vencimento, 'dd/mm/yyyy hh24:mi:ss') ASC) R ) R2");
	}
	
	public function consultaSolicitantechamado($c, $solicitante, $status, $coluna, $val = NULL, $de = NULL, $ate = NULL) {
		$funcoes = new Funcoes();
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		
		if ($status == "tudo"){
			$sta = "AND st.situacao is not null ";
		}elseif ($status == "andamento"){
			$sta = "AND st.situacao <> 'C' ";
		}else{
			$sta = "AND c.status = '{$status}' ";
		}
			
		$condicao = array(
			'1'	=> "AND LOWER({$coluna}) = '{$val}' ",
			'2' => "AND LOWER({$coluna}) LIKE '%{$val}%' ",
			'3' => "",
			'4' => "AND TO_DATE(TO_CHAR(TO_DATE({$coluna}, 'dd/mm/yyyy hh24:mi:ss'), 'dd/mm/yyyy'), 'dd/mm/yyyy') BETWEEN TO_DATE('{$de}','dd/mm/yyyy') AND TO_DATE('{$ate}','dd/mm/yyyy')"
		);
	
		
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT c.chamado, c.ambiente, am.des_ambiente, c.assunto, c.des_chamado, c.solicitante, 
		u.cpf as cpf_solicitante, u.nome as nome_solicitante, tip.des_tipo as tipo_solicitante, ca.cargo as cargo_solicitante, 
		ca.des_cargo as descargo_solicitante, de.departamento as departamento_solicitante, de.des_departamento as desdepartamento_solicitante,
		u.email as email_solicitante, u.telefone as telefone_solicitante, u.celular as celular_solicitante, u.ip, c.tecnico, t.hora_inicio, t.hora_fim, 
		u2.nome as nome_tecnico, u2.email as email_tecnico, u2.telefone as telefone_tecnico, u2.celular as celular_tecnico, 
		s.categoria, c.subcategoria, c.ambiente as ambiente_categoria, s.des_subcategoria, s.tempo_atendimento as tempo_subcategoria, 
		c.departamento, d.des_departamento, c.tipo, ti.des_tipo, c.empresa, e.des_empresa, e.razao_social, c.status, st.des_status, st.situacao,
		c.anexo1, c.anexo2, c.anexo3, c.dta_abertura, c.dta_vencimento, c.dta_fechamento, c.dta_reabertura, c.dta_ult_movimento, 
		c.tempo_atendimento, c.tempo_aguardando, c.tempo_outros, c.chamado_externo, c.chamado_dvi, c.cod_empresa, u3.usuario as funcionario, 
		u3.nome as nome_funcionario, ca3.cargo as an_cargo, ca3.des_cargo as an_descargo, e3.empresa as an_empresa, e3.razao_social as an_desempresa,
		caf.des_cargo cargo_funcionario, def.des_departamento departamento_funcionario, 
		de3.departamento as an_departamento, de3.des_departamento as an_desdepartamento, c.dta_admissao, c.dta_demissao, 
		u4.usuario as funcionario_substituido, u4.nome as nome_substituido, ca2.cargo as m_cargo, ca2.des_cargo as m_descargo,
		c.sigiloso, de2.departamento as m_departamento, de2.des_departamento as m_desdepartamento,c.salario, c.m_salario, 
		e2.empresa as m_empresa, e2.razao_social as m_desempresa, c.motivo, c.avaliacao, c.tempo_funcao, c.dta_vigencia, 
		c.n_vaga, c.genero, c.estado_civil, c.idade, c.perfil, c.justificativa, c.horario, c.campanha_inicio, c.campanha_fim, 
		c.campanha, c.publico, c.loja, c.obs, c.dta_externo, c.comissao, c.aut_situacao, caut.destinatario, caut.autorizante, 
		caut.dta_solicitacao, caut.dta_acao, caut.motivo as aut_motivo, caut.autorizado, u5.nome nome_destinatario, u6.nome nome_autorizante,
		c.dta_inicio, c.dta_fim, c.cc, c.destino
		FROM help_chamado c
        JOIN help_ambiente am ON c.ambiente = am.ambiente
		LEFT JOIN help_chamado_autorizacao caut ON (c.chamado = caut.chamado) AND (c.ambiente = caut.ambiente) AND (c.aut_situacao = caut.situacao)
		LEFT JOIN help_tecnico t ON c.tecnico = t.tecnico
		JOIN sis_usuario u ON c.solicitante = u.usuario
        JOIN sis_cargo ca ON u.cargo = ca.cargo
		LEFT JOIN sis_cargo ca2 ON c.m_cargo = ca2.cargo
		JOIN sis_tipo tip ON u.tipo = tip.tipo
		JOIN sis_departamento de ON u.departamento = de.departamento
        LEFT JOIN sis_usuario u2 ON c.tecnico = u2.usuario
		LEFT JOIN sis_usuario u3 ON c.funcionario = u3.usuario
		LEFT JOIN sis_departamento def ON u3.departamento = def.departamento
		LEFT JOIN sis_cargo caf ON u3.cargo = caf.cargo
		LEFT JOIN sis_cargo ca3  ON c.an_cargo = ca3.cargo
		LEFT JOIN sis_empresa e3  ON c.an_empresa = e3.empresa
		LEFT JOIN sis_departamento de3  ON c.an_departamento = de3.departamento
		LEFT JOIN sis_usuario u4 ON c.funcionario_substituido = u4.usuario
		LEFT JOIN sis_usuario u5 ON caut.destinatario = u5.usuario 
		LEFT JOIN sis_usuario u6 ON caut.autorizante = u6.usuario
		JOIN help_subcategoria s ON c.subcategoria = s.subcategoria
		JOIN sis_departamento d ON c.departamento = d.departamento
		LEFT JOIN sis_departamento de2 ON c.m_departamento = de2.departamento
		JOIN help_tipo ti ON c.tipo = ti.tipo
		JOIN sis_empresa e ON c.empresa = e.empresa
		LEFT JOIN sis_empresa e2 ON c.m_empresa = e2.empresa
		JOIN help_status st ON c.status = st.status WHERE (c.solicitante = '{$solicitante}' OR caut.destinatario = '{$solicitante}') {$sta}{$condicao[$c]}
		ORDER BY TO_DATE(c.dta_abertura, 'dd/mm/yyyy hh24:mi:ss') DESC) R ) R2");
	}
	
	public function getMovimento($chamado, $ambiente) {
		return  $this->Select("SELECT m.movimento, m.chamado, m.ambiente, m.usuario, u.nome, m.des_movimento, 
		m.dta_movimento, m.anexo1, m.anexo2, m.anexo3
		FROM help_movimento m
        JOIN help_ambiente a ON m.ambiente = a.ambiente
		JOIN sis_usuario u ON m.usuario = u.usuario
		WHERE m.chamado = '{$chamado}' AND m.ambiente = '{$ambiente}' ORDER BY m.movimento DESC");
	}
	public function getNotafiscal($chamado, $ambiente) {
		return  $this->Select("SELECT cn.chamado, cn.nota_fiscal, cn.fornecedor, cn.valor, cn.dta_repasse, 
		cn.dta_pagamento, cn.situacao
		FROM help_chamado_nf cn
		WHERE cn.chamado = '{$chamado}' AND cn.ambiente = '{$ambiente}' ORDER BY cn.dta_repasse ASC");
	}
	
	public function getChamadoautorizacao(Chamado $obj){
		return $this->Select("SELECT caut.chamado, c.des_chamado, caut.situacao, caut.destinatario,
		u.nome nome_destinatario, u.email email_destinatario, caut.autorizante, u2.nome nome_autorizante, 
		u2.email email_autorizante, caut.dta_solicitacao, caut.dta_acao, caut.motivo, caut.autorizado
		FROM help_chamado_autorizacao caut
		JOIN help_chamado c ON caut.chamado = c.chamado AND caut.ambiente = c.ambiente
		LEFT JOIN sis_usuario u ON caut.destinatario = u.usuario
		LEFT JOIN sis_usuario u2 ON caut.autorizante = u2.usuario
		WHERE caut.chamado = '{$obj->chamado}' AND caut.ambiente = '{$obj->ambiente}' ORDER BY caut.situacao DESC");
	}
	
	public function addChamado(Chamado $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$obj = array_filter($obj, function($v){return $v != 'categoria';}, ARRAY_FILTER_USE_KEY);
		$obj = array_filter($obj, function($v){return $v != 'anexo';}, ARRAY_FILTER_USE_KEY);
		$obj = array_filter($obj, function($v){return $v != 'pcomissao';}, ARRAY_FILTER_USE_KEY);
		$obj = array_filter($obj, function($v){return $v != 'destinatario';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareInsert($obj, 'help_chamado','chamado','',"help_chamado_{$obj['ambiente']}");
	}
	
	public function addMovimento(Movimento $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$obj = array_filter($obj, function($v){return $v != 'anexo';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareInsert($obj, 'help_movimento', 'movimento', '',"help_movimento_{$obj['ambiente']}");
	}
	
	public function addAutorizacao(Autorizacao $obj, $currval = NULL) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		if ($currval != NULL){
			$obj = array_filter($obj, function($v){return $v != 'chamado' && $v != 'anexo';}, ARRAY_FILTER_USE_KEY);
			return $prepare->PrepareInsert($obj, 'help_chamado_autorizacao',"",$currval);
		}else{
			return $prepare->PrepareInsert($obj, 'help_chamado_autorizacao');
		}
	}
	
	public function addNotafiscal(Chamadonf $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareInsert($obj, 'help_chamado_nf');
	}
	
	public function editChamado(Chamado $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v) || $v == "comissao";});
		$obj = array_filter($obj, function($v){return $v != 'anexo'  && $v != 'tempo_vencimento' && $v != 'submeter' && $v != 'pcomissao';}, ARRAY_FILTER_USE_KEY);
		$set = array_filter($obj, function($v){return $v != 'chamado' && $v != 'ambiente';}, ARRAY_FILTER_USE_KEY);
		if ((is_array($set) ? count($set) : 0) > 0){
			return $prepare->PrepareUpdate($set,array('chamado' => $obj['chamado'], 'ambiente' => $obj['ambiente']), 'help_chamado');
		}
	}
	
	public function editAutorizacao(Autorizacao $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'chamado' && $v != 'ambiente' && $v != 'situacao' && $v != 'anexo';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('chamado' => $obj['chamado'], 'ambiente' => $obj['ambiente'], 'situacao' => $obj['situacao']), 'help_chamado_autorizacao');
	}
	
	
	public function delChamado(Chamado $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('chamado' => $obj->chamado, 'ambiente' => $obj->ambiente), 'help_chamado');
	}
	
	public function delNotafiscal(Chamadonf $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('chamado' => $obj->chamado, 'ambiente' => $obj->ambiente), 'help_chamado_nf');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}