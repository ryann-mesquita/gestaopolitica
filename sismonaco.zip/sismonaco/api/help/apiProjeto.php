<?php

namespace api\help;

use lib\Model;
use obj\help\Projeto;
use helper\PrepareSQL;

class apiProjeto extends Model {
	
	public function getProjeto(Projeto $obj) {
		return  $this->First($this->Select("SELECT p.ano, p.mes, p.tecnico, u.nome, p.projeto, p.dta_cadastro FROM help_projeto p
		JOIN sis_usuario u ON p.tecnico = u.usuario
		WHERE p.ano = '{$obj->ano}' AND p.mes = '{$obj->mes}' AND p.tecnico = '{$obj->tecnico}' "));
	}
	
	public function filtroProjeto($c, $ano = NULL, $mes = NULL, $tecnico = NULL) {
		$condicao = array(
		'1'	=> " WHERE p.ano = '{$ano}' AND p.mes = '{$mes}' AND p.tecnico = '{$tecnico}' ",
		'2'	=> " WHERE p.ano = '{$ano}' AND p.mes = '{$mes}' ",
		'3'	=> " WHERE p.tecnico = '{$tecnico}' ",
		'4' => " ",
		'5' => " WHERE {$ano}"
						);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT p.ano, p.mes, p.tecnico, u.nome, p.projeto, p.dta_cadastro
		FROM help_projeto p
		JOIN sis_usuario u ON p.tecnico = u.usuario{$condicao[$c]}ORDER BY p.ano DESC, p.mes DESC) R ) R2");
	}
	
	public function addProjeto(Projeto $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'help_projeto');
	}
	
	public function editProjeto(Projeto $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'ano' && $v != 'mes' && $v != 'tecnico';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('ano' => $obj['ano'], 'mes' => $obj['mes'], 'tecnico' => $obj['tecnico']), 'help_projeto');
	}
	
	public function delProjeto(Projeto $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('ano' => $obj->ano, 'mes' => $obj->mes, 'tecnico' => $obj->tecnico), 'help_projeto');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}