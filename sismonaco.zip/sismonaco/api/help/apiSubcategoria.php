<?php

namespace api\help;

use lib\Model;
use obj\help\Subcategoria;
use helper\PrepareSQL;
use helper\Funcoes;

class apiSubcategoria extends Model {
	
	public function getSubcategoria(Subcategoria $obj) {
		return  $this->First($this->Select("
		SELECT s.subcategoria, s.des_subcategoria, s.categoria, c.des_categoria, s.tempo_atendimento, s.ativo 
		FROM help_subcategoria s 
		JOIN help_categoria c ON s.categoria = c.categoria WHERE s.subcategoria = '{$obj->subcategoria}'"));
	}
	
	public function filtroSubcategoria($c, $a, $coluna = NULL, $val = NULL, $ambiente = NULL, $categoria = NULL) {
		$funcoes = new Funcoes();
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		$condicao = array(
			'1'	=> " WHERE LOWER({$coluna}) = '{$val}' ",
			'2' => " WHERE LOWER({$coluna}) LIKE '%{$val}%' ",
			'3'	=> " ",
		);
		$ativo = array(
			'1' => "AND s.ativo = '1' ",
			'2' => "AND s.ativo = '0' ",
			'3' => " ",
		);
		if ($ambiente == 'tudo'){
			$amb = " ";
		}elseif ($ambiente != NULL){
			$amb = " AND c.ambiente = '{$ambiente}' ";
		}else{
			$amb = " AND c.ambiente = '' ";
		}
		if ($categoria == NULL){
	    	$cat  = " ";
		}else{
			$cat  = "AND s.categoria = '{$categoria}' ";
		}
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT s.subcategoria, s.des_subcategoria, s.categoria, c.des_categoria, a.ambiente, a.des_ambiente,
		s.tempo_atendimento, s.ativo
		FROM help_subcategoria s
		JOIN help_categoria c ON s.categoria = c.categoria
		JOIN help_ambiente a ON c.ambiente = a.ambiente {$condicao[$c]}{$ativo[$a]}{$amb}{$cat}ORDER BY a.des_ambiente ASC, c.des_categoria ASC, s.des_subcategoria ASC) R ) R2");
	}
	
	public function consultaSubcategoria($condicao){
		return $this->Select("SELECT s.subcategoria, s.des_subcategoria, s.categoria, c.des_categoria, s.tempo_atendimento, s.ativo
		FROM help_subcategoria s
		JOIN help_categoria c ON s.categoria = c.categoria WHERE {$condicao}");
	}
	
	public function addSubcategoria(Subcategoria $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_subcategoria = strtoupper($funcoes->retiraAcentos(trim($obj->des_subcategoria)));
		$obj->tempo_atendimento = $funcoes->naoNumerico(trim($obj->tempo_atendimento));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'help_subcategoria','subcategoria');
	}
	
	public function editSubcategoria(Subcategoria $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_subcategoria = strtoupper($funcoes->retiraAcentos(trim($obj->des_subcategoria)));
		$obj->tempo_atendimento = $funcoes->naoNumerico(trim($obj->tempo_atendimento));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'subcategoria';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('subcategoria' => $obj['subcategoria']), 'help_subcategoria');
	}
	
	public function delSubcategoria(Subcategoria $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('subcategoria' => $obj->subcategoria), 'help_subcategoria');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}