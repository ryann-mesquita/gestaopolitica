<?php

namespace api\help;

use lib\Model;
use obj\help\Tecnico;
use helper\PrepareSQL;
use helper\Funcoes;

class apiTecnico extends Model {
	
	public function getTecnico(Tecnico $obj) {
		return  $this->First($this->Select("SELECT t.tecnico, u.nome, u.departamento, ta.ambiente, a.des_ambiente,
		u.email, t.hora_inicio, t.hora_fim, t.intervalo_inicio, t.intervalo_fim, t.plantao, t.dta_cadastro, t.ativo
		FROM help_tecnico t
		JOIN sis_usuario u ON t.tecnico = u.usuario 
		LEFT JOIN help_tecnico_ambiente ta ON t.tecnico = ta.tecnico
		LEFT JOIN help_ambiente a ON ta.ambiente = a.ambiente
		WHERE t.tecnico = '{$obj->tecnico}'"));
	}
	
	public function filtroTecnico($c, $a, $coluna = NULL, $val = NULL, $ambiente = NULL) {
		$funcoes = new Funcoes();
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		$condicao = array(
			'1'	=> " WHERE LOWER({$coluna}) = '{$val}'",
			'2' => " WHERE LOWER({$coluna}) LIKE '%{$val}%'",
			'3'	=> ""
		);
		$ativo = array(
			'1' => " AND t.ativo = '1'",
			'2' => " AND t.ativo = '0'",
			'3' => ""
		);
		if ($ambiente == 'naodefinido'){
			$amb = " AND ta.ambiente is null ";
		}elseif ($ambiente == 'tudo'){
			$amb = " ";
		}elseif ($ambiente != NULL){
			$amb = " AND ta.ambiente = '{$ambiente}' ";
		}else{
			$amb = " AND ta.ambiente = '' ";
		}
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT t.tecnico, ta.ambiente, a.des_ambiente, u.tipo, t.des_tipo, u.departamento, u.cargo, c.des_cargo,
		d.des_departamento, u.cpf, u.nome, u.dta_nascimento, u.dta_admissao, u.dta_demissao, u.email, u.telefone, 
		u.celular, u.ip, u.empresa, e.des_empresa, t.hora_inicio, t.hora_fim, t.intervalo_inicio, t.intervalo_fim, 
		t.plantao, t.dta_cadastro, t.ativo 
		FROM help_tecnico t
		JOIN sis_usuario u ON t.tecnico = u.usuario
		LEFT JOIN help_tecnico_ambiente ta ON t.tecnico = ta.tecnico
		LEFT JOIN help_ambiente a ON ta.ambiente = a.ambiente
		JOIN sis_tipo t ON u.tipo = t.tipo
		JOIN sis_departamento d ON u.departamento = d.departamento
		JOIN sis_cargo c ON u.cargo = c.cargo 
		JOIN sis_empresa e ON u.empresa = e.empresa{$condicao[$c]}{$ativo[$a]}{$amb}ORDER BY a.des_ambiente ASC, u.nome ASC) R ) R2");
	}
	public function addTecnico(Tecnico $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$obj = array_filter($obj, function($v){return $v != 'ambiente';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareInsert($obj, 'help_tecnico');
	}
	public function addTecnicoambiente(Tecnico $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'help_tecnico_ambiente');
	}
	
	public function editTecnico(Tecnico $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'tecnico' && $v != 'ambiente';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('tecnico' => $obj['tecnico']), 'help_tecnico');
	}
	
	public function delTecnico(Tecnico $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('tecnico' => $obj->tecnico), 'help_tecnico');
	}
	
	public function delTecnicoambiente(Tecnico $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('tecnico' => $obj->tecnico, 'ambiente' => $obj->ambiente), 'help_tecnico_ambiente');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}