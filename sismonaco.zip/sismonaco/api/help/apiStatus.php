<?php

namespace api\help;

use lib\Model;
use obj\help\Status;
use helper\PrepareSQL;
use helper\Funcoes;

class apiStatus extends Model {
	
	public function getStatus(Status $obj) {
		return  $this->First($this->Select("SELECT * FROM help_status WHERE status = '{$obj->status}'"));
	}
	
	public function filtroStatus($c, $a, $coluna = NULL, $val = NULL) {
		$funcoes = new Funcoes();
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		$condicao = array(
				'1'	=> " WHERE LOWER(s.{$coluna}) = '{$val}' ",
				'2' => " WHERE LOWER(s.{$coluna}) LIKE '%{$val}%' ",
				'3'	=> " ",
		);
		$ativo = array(
				'1' => "AND s.ativo = '1' ",
				'2' => "AND s.ativo = '0' ",
				'3' => "",
		);
		return $this->Select("SELECT R2.*
				FROM (SELECT rownum n_linha, R.*
				FROM(SELECT s.status, s.des_status, s.situacao, s.ativo
				FROM help_status s{$condicao[$c]}{$ativo[$a]}ORDER BY s.des_status ASC) R ) R2");
	}
	
	public function addStatus(Status $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_status = strtoupper($funcoes->retiraAcentos(trim($obj->des_status)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'help_status','status');
	}
	
	public function editStatus(Status $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_status = strtoupper($funcoes->retiraAcentos(trim($obj->des_status)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'status';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('status' => $obj['status']), 'help_status');
	}
	
	public function delStatus(Status $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('status' => $obj->status), 'help_status');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}