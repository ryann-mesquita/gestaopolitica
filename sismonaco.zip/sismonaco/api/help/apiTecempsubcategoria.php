<?php

namespace api\help;

use lib\Model;
use obj\help\Tecempsubcategoria;
use helper\PrepareSQL;
use obj\help\Envolvidos;
use obj\help\Gestores;

class apiTecempsubcategoria extends Model {
	
	public function getTecempsubcategoria(Tecempsubcategoria $obj) {
		return  $this->First($this->Select("SELECT tes.tecnico, u.nome, tes.empresa, e.des_empresa, 
		tes.subcategoria, s.des_subcategoria
		FROM help_tec_emp_subcategoria tes
		JOIN help_tecnico t ON tes.tecnico = t.tecnico
		JOIN sis_usuario u ON t.tecnico = u.usuario
		JOIN sis_empresa e ON tes.empresa = e.empresa
		JOIN help_subcategoria s ON tes.subcategoria = s.subcategoria
		WHERE tes.tecnico = '{$obj->tecnico}' AND tes.empresa = '{$obj->empresa}' AND tes.subcategoria = '{$obj->subcategoria}'"));
	}
	
	public function vinculoTecnico($tecnico,$empresa) {
		return $this->Select("SELECT tes.tecnico, u.nome, tes.empresa, e.des_empresa, 
		tes.subcategoria, s.des_subcategoria
		FROM help_tec_emp_subcategoria tes
		JOIN help_tecnico t ON tes.tecnico = t.tecnico
		JOIN sis_usuario u ON t.tecnico = u.usuario
		JOIN sis_empresa e ON tes.empresa = e.empresa
		JOIN help_subcategoria s ON tes.subcategoria = s.subcategoria
		WHERE tes.tecnico = '$tecnico' AND tes.empresa = '$empresa'");
	}
	
	public function envolvidosAmbiente($c,$empresa,$ambiente) {
		$condicao = array(
			'1'	=> "where e.empresa = '{$empresa}' and e.ambiente = '{$ambiente}' and u.ativo = 1 ",
			'2' => "where e.empresa = '{$empresa}' and e.ambiente = '{$ambiente}' ",
			'3'	=> "where e.ambiente = '{$ambiente}' "
		);
		return $this->Select("select e.ambiente, e.empresa, u.usuario, u.nome, u.email, e.subcategoria 
		from help_envolvidos e
		join sis_usuario u on e.usuario = u.usuario
		{$condicao[$c]}");
	}
	
	public function gestoresAmbiente($c,$empresa,$ambiente) {
		$condicao = array(
			'1' => "where g.empresa = '{$empresa}' and g.ambiente = '{$ambiente}' ",
			'2'	=> "where g.ambiente = '{$ambiente}' "
		);
		return $this->Select("select g.ambiente, g.empresa, g.gerente_dho, u1.nome nome_gerentedho, 
		u1.email email_gerentedho, g.diretor_dho, u2.nome nome_diretordho, u2.email email_diretordho,
		g.gerente_dp, u3.nome nome_gerentedp, u3.email email_gerentedp
		from help_gestores g
		left join sis_usuario u1 on g.gerente_dho = u1.usuario
		left join sis_usuario u2 on g.diretor_dho = u2.usuario
		left join sis_usuario u3 on g.gerente_dp = u3.usuario
		{$condicao[$c]}");
	}
	
	public function tecnicoVez($empresa,$subcategoria,$hora,$plantao,$horario = NULL) {
		if ($plantao == 1){
			$cond = "tes.empresa = '{$empresa}' AND tes.subcategoria = '{$subcategoria}' AND t.ativo = 1 AND t.plantao = '1'";
		}elseif ($horario != NULL){
			$cond = "tes.empresa = '{$empresa}' AND tes.subcategoria = '{$subcategoria}' AND t.ativo = 1";
		}else{
			$cond = "(tes.empresa = '{$empresa}' AND tes.subcategoria = '{$subcategoria}' AND t.ativo = 1 
			AND to_date(t.hora_inicio,'hh24:mi:ss') < to_date('$hora','hh24:mi:ss')
			AND to_date(t.intervalo_inicio,'hh24:mi:ss') > to_date('$hora','hh24:mi:ss')) 
			OR (tes.empresa = '{$empresa}' AND tes.subcategoria = '{$subcategoria}' AND t.ativo = 1 
			AND to_date(t.intervalo_fim,'hh24:mi:ss') < to_date('$hora','hh24:mi:ss') 
			AND to_date(t.hora_fim,'hh24:mi:ss') > to_date('$hora','hh24:mi:ss'))";	
		}
		return $this->Select("SELECT tes.tecnico,t.ativo,t.plantao,nvl(ch.qtd,0) qtd, nvl(ch2.qtd,0) fechado, t.hora_inicio,t.intervalo_inicio,t.intervalo_fim,
		t.hora_fim,tes.empresa, tes.subcategoria 
		FROM help_tec_emp_subcategoria tes
		JOIN help_tecnico t ON tes.tecnico = t.tecnico
		JOIN help_subcategoria s ON tes.subcategoria = s.subcategoria
		LEFT JOIN (select c.tecnico, nvl(count(c.status),0) qtd 
		from help_chamado c JOIN help_status s ON c.status = s.status 
		where to_char(to_date(c.dta_abertura,'dd/mm/yyyy hh24:mi:ss'),'mm/yyyy') = to_char(sysdate,'mm/yyyy') 
		and s.situacao = 'EA' group by c.tecnico) ch ON tes.tecnico = ch.tecnico
		LEFT JOIN (select c.tecnico, nvl(count(c.status),0) qtd 
		from help_chamado c JOIN help_status s ON c.status = s.status
		where to_char(to_date(c.dta_fechamento,'dd/mm/yyyy hh24:mi:ss'),'mm/yyyy') = to_char(sysdate,'mm/yyyy') 
		and s.situacao = 'C' group by c.tecnico) ch2 ON tes.tecnico = ch2.tecnico
		WHERE {$cond} ORDER BY nvl(ch.qtd,0) ASC, nvl(ch2.qtd,0) ASC");
	}
	
	public function addTecempsubcategoria(Tecempsubcategoria $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareInsert($obj, 'help_tec_emp_subcategoria');
	}
	
	public function delTecempsubcategoria(Tecempsubcategoria $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('tecnico' => $obj->tecnico, 'empresa' => $obj->empresa, 'subcategoria' => $obj->subcategoria), 'help_tec_emp_subcategoria');
	}
	
	public function addEnvolvido(Envolvidos $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareInsert($obj, 'help_envolvidos');
	}
	
	public function addGestores(Gestores $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareInsert($obj, 'help_gestores');
	}
	
	public function editEnvolvido(Envolvidos $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareUpdate($obj, array('ambiente' => $obj->ambiente, 'empresa' => $obj->empresa, 'usuario' => $obj->usuario), 'help_envolvidos');
	}
	
	public function editGestores(Gestores $obj){
		$prepare = new PrepareSQL();
		return $prepare->PrepareUpdate($obj, array('ambiente' => $obj->ambiente, 'empresa' => $obj->empresa), 'help_gestores');
	}
	
	public function delEnvolvido(Envolvidos $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('ambiente' => $obj->ambiente, 'empresa' => $obj->empresa, 'usuario' => $obj->usuario), 'help_envolvidos');
	}
	public function delGestores(Gestores $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('ambiente' => $obj->ambiente, 'empresa' => $obj->empresa ), 'help_gestores');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}