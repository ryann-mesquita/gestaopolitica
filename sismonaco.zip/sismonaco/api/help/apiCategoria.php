<?php

namespace api\help;

use lib\Model;
use obj\help\Categoria;
use helper\PrepareSQL;
use helper\Funcoes;

class apiCategoria extends Model {
	
	public function getCategoria(Categoria $obj) {
		return  $this->First($this->Select("SELECT c.categoria, c.des_categoria, c.ambiente, a.des_ambiente, c.ativo 
		FROM help_categoria c
		JOIN help_ambiente a ON c.ambiente = a.ambiente 
		WHERE c.categoria = '{$obj->categoria}'"));
	}
	
	public function filtroCategoria($c, $a, $coluna = NULL, $val = NULL, $ambiente = NULL) {
		$funcoes = new Funcoes();
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		$condicao = array(
			'1'	=> " WHERE LOWER({$coluna}) = '{$val}' ",
			'2' => " WHERE LOWER({$coluna}) LIKE '%{$val}%' ",
			'3'	=> " ",
			'4'	=> " WHERE {$coluna} in {$val} "
		);
		$ativo = array(
			'1' => "AND c.ativo = '1' ",
			'2' => "AND c.ativo = '0' ",
			'3' => "",
		);

		if ($ambiente == 'tudo'){
			$amb = " ";
		}elseif ($ambiente != NULL){
			$amb = " AND c.ambiente = '{$ambiente}' ";
		}else{
			$amb = " AND c.ambiente = '' ";
		}
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT c.categoria, c.des_categoria, c.ambiente, a.des_ambiente, c.ativo
		FROM help_categoria c
		JOIN help_ambiente a ON c.ambiente = a.ambiente{$condicao[$c]}{$ativo[$a]}{$amb}ORDER BY c.des_categoria ASC) R ) R2");
	}
	
	public function addCategoria(Categoria $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_categoria = strtoupper($funcoes->retiraAcentos(trim($obj->des_categoria)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'help_categoria','categoria');
	}
	
	public function editCategoria(Categoria $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_categoria = strtoupper($funcoes->retiraAcentos(trim($obj->des_categoria)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'categoria';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('categoria' => $obj['categoria']), 'help_categoria');
	}
	
	public function delCategoria(Categoria $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('categoria' => $obj->categoria), 'help_categoria');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}