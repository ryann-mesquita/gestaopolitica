<?php

namespace api\help;

use lib\Model;
use obj\help\Consolidado;
use helper\PrepareSQL;

class apiConsolidado extends Model {
	
	public function getConsolidado(Consolidado $obj) {
		return  $this->First($this->Select("SELECT * FROM help_consolidado WHERE ano = '{$obj->ano}' AND mes = '{$obj->mes}' "));
	}
	
	public function filtroConsolidado($c, $ano = NULL, $mes = NULL) {
		$condicao = array(
			'1'	=> " WHERE c.ano = '{$ano}' AND c.mes = '{$mes}' ",
			'2' => " "
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT c.*
		FROM help_consolidado c{$condicao[$c]}ORDER BY c.ano DESC, c.mes DESC) R ) R2");
	}
	
	public function addConsolidado(Consolidado $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'help_consolidado');
	}
	
	public function editConsolidado(Consolidado $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'ano' && $v != 'mes';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('ano' => $obj['ano'], 'mes' => $obj['mes']), 'help_consolidado');
	}
	
	public function delConsolidado(Consolidado $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('ano' => $obj->ano, 'mes' => $obj->mes), 'help_consolidado');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}