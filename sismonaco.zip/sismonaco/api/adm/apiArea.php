<?php

namespace api\adm;

use lib\Model;
use obj\adm\Area;
use helper\PrepareSQL;
use helper\Funcoes;

class apiArea extends Model {
	
	public function getArea(Area $obj) {
		return  $this->First($this->Select("SELECT * FROM sis_area WHERE area = '{$obj->area}'"));
	}
	
	public function filtroArea($c, $a, $coluna = NULL, $val = NULL) {
		$val = strtolower(trim($val));
		$condicao = array(
				'1'	=> " WHERE LOWER(t.{$coluna}) = '{$val}' ",
				'2' => " WHERE LOWER(t.{$coluna}) LIKE '%{$val}%' ",
				'3'	=> " ",
		);
		$ativo = array(
				'1' => "AND t.ativo = '1' ",
				'2' => "AND t.ativo = '0' ",
				'3' => "",
		);
		return $this->Select("SELECT R2.*
				FROM (SELECT rownum n_linha, R.*
				FROM(SELECT t.area, t.des_area, t.ativo
				FROM sis_area t{$condicao[$c]}{$ativo[$a]}ORDER BY t.des_area ASC) R ) R2");
	}
	
	public function addArea(Area $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_area = strtoupper($funcoes->retiraAcentos(trim($obj->des_area)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'sis_area','area');
	}
	
	public function editArea(Area $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_area = strtoupper($funcoes->retiraAcentos(trim($obj->des_area)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'area';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('area' => $obj['area']), 'sis_area');
	}
	
	public function delArea(Area $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('area' => $obj->area), 'sis_area');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}