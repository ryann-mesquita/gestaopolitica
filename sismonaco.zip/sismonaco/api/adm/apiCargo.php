<?php

namespace api\adm;

use lib\Model;
use obj\adm\Cargo;
use helper\PrepareSQL;
use helper\Funcoes;

class apiCargo extends Model {
	
	public function getCargo(Cargo $obj) {
		return  $this->First($this->Select("SELECT c.cargo, c.departamento, d.des_departamento, c.des_cargo, c.cbo, c.ativo 
		FROM sis_cargo c
		JOIN sis_departamento d ON c.departamento = d.departamento WHERE c.cargo = '{$obj->cargo}'"));
	}
	
	public function filtroCargo($c, $a, $coluna = NULL, $val = NULL) {
		$val = strtolower(trim($val));
		$condicao = array(
			'1'	=> " WHERE LOWER(c.{$coluna}) = '{$val}' ",
			'2' => " WHERE LOWER(c.{$coluna}) LIKE '%{$val}%' ",
			'3'	=> " ",
		);
		$ativo = array(
			'1' => "AND c.ativo = '1' ",
			'2' => "AND c.ativo = '0' ",
			'3' => "",
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT c.cargo, c.departamento, d.des_departamento, c.des_cargo, c.cbo, c.ativo
		FROM sis_cargo c
		JOIN sis_departamento d ON c.departamento = d.departamento{$condicao[$c]}{$ativo[$a]}ORDER BY c.des_cargo ASC) R ) R2");
	}
	
	public function addCargo(Cargo $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_cargo = strtoupper($funcoes->retiraAcentos(trim($obj->des_cargo)));
		$obj->cbo = strtoupper($funcoes->naoNumerico(trim($obj->cbo)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'sis_cargo','cargo');
	}
	
	public function editCargo(Cargo $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_cargo = strtoupper($funcoes->retiraAcentos(trim($obj->des_cargo)));
		$obj->cbo = strtoupper($funcoes->naoNumerico(trim($obj->cbo)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'cargo';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('cargo' => $obj['cargo']), 'sis_cargo');
	}
	
	public function delCargo(Cargo $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('cargo' => $obj->cargo), 'sis_cargo');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}