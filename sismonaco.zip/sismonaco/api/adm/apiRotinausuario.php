<?php

namespace api\adm;

use lib\Model;
use obj\adm\Rotinausuario;
use helper\PrepareSQL;

class apiRotinausuario extends Model {

	public function getRotinausuario(Rotinausuario $obj) {
		return  $this->First($this->Select("SELECT ru.rotina, r.des_reduzida, r.des_rotina, ru.usuario, u.cpf, u.nome
		FROM sis_rotina_usuario ru
		JOIN sis_rotina r ON ru.rotina = r.rotina
		JOIN sis_usuario u ON ru.usuario = r.usuario
		WHERE ru.rotina = '{$obj->rotina}' AND ru.usuario = '{$obj->usuario}'"));
	}

	public function filtroRotinausuario($rotina,$condicao = NULL) {
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM (SELECT ru.rotina, r.des_reduzida, r.des_rotina, ru.usuario, u.cpf, u.nome, u.email
		FROM sis_rotina_usuario ru
		JOIN sis_rotina r ON ru.rotina = r.rotina
		JOIN sis_usuario u ON ru.usuario = u.usuario WHERE ru.rotina = '{$rotina}'{$condicao}
		ORDER BY ru.rotina DESC) R ) R2");
	}

	public function addRotinausuario(Rotinausuario $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareInsert($obj, 'sis_rotina_usuario');
	}

	public function delRotinausuario(Rotinausuario $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('rotina' => $obj->rotina, 'usuario' => $obj->usuario), 'sis_rotina_usuario');
	}

	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}