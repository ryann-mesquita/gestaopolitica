<?php

namespace api\adm;

use lib\Model;
use obj\adm\Permissao;
use helper\PrepareSQL;

class apiPermissao extends Model {

	public function getPermissao(Permissao $obj) {
		return $this->Select("SELECT p.usuario, p.empresa, p.modulo, m.des_reduzida md, m.des_modulo, p.controle,
	    c.des_reduzida ct, c.des_controle, p.acao, a.des_reduzida ac, a.des_acao
		FROM sis_permissao p 
		JOIN sis_modulo m ON p.modulo = m.modulo
		JOIN sis_controle c ON p.controle = c.controle
		JOIN sis_acao a ON p.acao = a.acao 
		WHERE p.usuario = '{$obj->usuario}' AND p.empresa = '{$obj->empresa}' AND
		p.modulo = '{$obj->modulo}' AND p.controle = '{$obj->controle}' AND p.acao = '{$obj->acao}'");
	}

	public function permUsuario(Permissao $obj) {
		return $this->Select("SELECT p.usuario, p.modulo, m.des_reduzida md, m.des_modulo,
		p.controle, c.des_reduzida ct, c.des_controle, p.acao, a.des_reduzida ac, 
		a.des_acao, p.empresa, e.des_empresa 
		FROM sis_permissao p  
		JOIN sis_modulo m ON p.modulo = m.modulo and m.ativo = 1
		JOIN sis_controle c ON p.controle = c.controle
		JOIN sis_acao a ON p.acao = a.acao 
		JOIN sis_empresa e ON p.empresa = e.empresa
		WHERE p.usuario = '{$obj->usuario}' 
		ORDER BY p.empresa,p.modulo,p.controle,p.acao");
	}

	public function permModulo(Permissao $obj) {
		return  $this->Select("SELECT p.modulo, m.des_reduzida, m.des_modulo
		FROM sis_permissao p  
		JOIN sis_modulo m ON p.modulo = m.modulo and m.ativo = 1
		JOIN sis_controle c ON p.controle = c.controle
		JOIN sis_acao a ON p.acao = a.acao 
		JOIN sis_empresa e ON p.empresa = e.empresa
		WHERE p.usuario = '{$obj->usuario}' AND c.des_reduzida = 'index' 
		AND a.des_reduzida = 'index' AND m.des_reduzida <> 'Home' 
		GROUP BY p.modulo, m.des_reduzida, m.des_modulo ORDER BY m.des_reduzida ASC");
	}
	
	public function permEmpresapadrao(Permissao $obj) {
		return $this->Select("SELECT p.usuario, p.modulo, m.des_reduzida md, m.des_modulo,
		p.controle, c.des_reduzida ct, c.des_controle, p.acao, a.des_reduzida ac, 
		a.des_acao, p.empresa, e.des_empresa 
		FROM sis_permissao p  
		JOIN sis_modulo m ON p.modulo = m.modulo
		JOIN sis_controle c ON p.controle = c.controle
		JOIN sis_acao a ON p.acao = a.acao 
		JOIN sis_empresa e ON p.empresa = e.empresa
		WHERE p.usuario = '{$obj->usuario}' AND p.empresa = '{$obj->empresa}'");
	}

	public function permEmpresa(Permissao$obj) {
		return $this->Select("SELECT p.usuario, p.modulo, m.des_reduzida md, m.des_modulo,
		p.controle, c.des_reduzida ct, c.des_controle, p.acao, a.des_reduzida ac, 
		a.des_acao, p.empresa, e.des_empresa 
		FROM sis_permissao p  
		JOIN sis_modulo m ON p.modulo = m.modulo 
		JOIN sis_controle c ON p.controle = c.controle
		JOIN sis_acao a ON p.acao = a.acao 
		JOIN sis_empresa e ON p.empresa = e.empresa
		WHERE p.usuario = '{$obj->usuario}' AND c.des_reduzida = 'index' AND a.des_reduzida = 'index' 
		AND p.modulo = '{$obj->modulo}'  
		ORDER BY e.ordem");
	}
	
	public function permEmpresascontroleacao(Permissao $obj) {
		return $this->Select("SELECT e.empresa, e.des_empresa
		FROM sis_permissao p
		JOIN sis_modulo m ON p.modulo = m.modulo
		JOIN sis_controle c ON p.controle = c.controle
		JOIN sis_acao a ON p.acao = a.acao
		JOIN sis_empresa e ON p.empresa = e.empresa
		WHERE p.usuario = '{$obj->usuario}' AND m.modulo = '$obj->modulo' 
		AND c.controle = '$obj->controle' AND a.acao = '{$obj->acao}'
		ORDER BY e.ordem");
	}

	public function addPermissao(Permissao $obj) {
		$prepare = new PrepareSQL();		
		return $prepare->PrepareInsert($obj, 'sis_permissao');		
	}

	public function delPermissao(Permissao $obj) {
		$prepare = new PrepareSQL();	
		return $prepare->PrepareDelete(array('usuario' => $obj->usuario, 'empresa' => $obj->empresa, 'modulo' => $obj->modulo, 'controle' => $obj->controle, 'acao' => $obj->acao), 'sis_permissao');		
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}