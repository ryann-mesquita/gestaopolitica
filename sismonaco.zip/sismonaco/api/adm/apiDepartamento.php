<?php

namespace api\adm;

use lib\Model;
use obj\adm\Departamento;
use helper\PrepareSQL;
use helper\Funcoes;

class apiDepartamento extends Model {

	public function getDepartamento(Departamento $obj) {
		return  $this->First($this->Select("SELECT d.departamento, d.des_departamento, d.area, a.des_area, d.ativo 
		FROM sis_departamento d LEFT JOIN sis_area a ON d.area = a.area WHERE d.departamento  = '{$obj->departamento}'"));
	}

	public function filtroDepartamento($c, $a, $coluna = NULL, $val = NULL) {
		$val = strtolower(trim($val));
		$condicao = array(
				'1'	=> " WHERE LOWER({$coluna}) = '{$val}' ",
				'2' => " WHERE LOWER({$coluna}) LIKE '%{$val}%' ",
				'3'	=> " ",
		);
		$ativo = array(
				'1' => "AND d.ativo = '1' ",
				'2' => "AND d.ativo = '0' ",
				'3' => "",
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT d.departamento, d.des_departamento, d.area, a.des_area,d.ativo
		FROM sis_departamento d
		LEFT JOIN sis_area a ON d.area = a.area{$condicao[$c]}{$ativo[$a]}ORDER BY d.des_departamento ASC) R ) R2");
	}

	public function addDepartamento(Departamento $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_departamento = strtoupper($funcoes->retiraAcentos(trim($obj->des_departamento)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'sis_departamento','departamento');
	}

	public function editDepartamento(Departamento $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_departamento = strtoupper($funcoes->retiraAcentos(trim($obj->des_departamento)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'departamento';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('departamento' => $obj['departamento']), 'sis_departamento');
	}

	public function delDepartamento(Departamento $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('departamento' => $obj->departamento), 'sis_departamento');
	}

	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}