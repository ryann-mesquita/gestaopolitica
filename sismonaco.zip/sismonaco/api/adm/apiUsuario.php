<?php

namespace api\adm;

use lib\Model;
use obj\adm\Usuario;
use helper\PrepareSQL;
use helper\Funcoes;

class apiUsuario extends Model {
	
    public function getUsuario(Usuario $obj) {
    	return $this->First($this->Select("SELECT u.usuario, u.tipo, t.des_tipo, u.departamento, u.cargo, c.des_cargo,
		d.des_departamento, d.area, u.cpf, u.nome, u.dta_nascimento, u.dta_admissao, u.dta_demissao, u.email, u.senha, u.telefone, 
		u.celular, u.ip, u.empresa, e.des_empresa, u.ativo, u.dta_cadastro, u.dta_ult_ini_ferias, u.dta_ult_fim_ferias,
		u.dta_ult_alteracao, u.dta_ult_acesso, u.status, u.deg, u.contrato 
    	FROM sis_usuario u
    	JOIN sis_tipo t ON u.tipo = t.tipo
		JOIN sis_departamento d ON u.departamento = d.departamento 
		JOIN sis_cargo c ON u.cargo = c.cargo
		JOIN sis_empresa e ON u.empresa = e.empresa
		WHERE u.usuario = '{$obj->usuario}'"));
    }
    
    public function getUsuariomodulo(Usuario $obj) {
    	return $this->Select("SELECT um.usuario, um.modulo, m.des_reduzida, m.des_modulo
    	FROM sis_usuario_modulo um
    	JOIN sis_modulo m ON um.modulo = m.modulo
    	WHERE um.usuario = '{$obj->usuario}' AND um.modulo = '{$obj->modulo}'"); 	
    }
    
    public function getModulousuario(Usuario $obj) {
    	return $this->Select("SELECT um.usuario, um.modulo, m.des_reduzida, m.des_modulo
    	FROM sis_usuario_modulo um
    	JOIN sis_modulo m ON um.modulo = m.modulo
    	WHERE um.usuario = '{$obj->usuario}' AND m.ativo = '1'");
    }
    //Recupera os usu�rios gerentes
    public function getUsuariosdestinatarios($empresa_origem, $empresa_destino, $tipo) {
    	if ($tipo == 2){
    		$t = "AND u.tipo in (3,4)";
    	}elseif ($tipo == 3){
    		$t = "AND u.tipo in (4)";
    	}elseif ($tipo == 4){
    		$t = "AND u.tipo = 5";
    	}
    	elseif ($tipo == 5){
    		$t = "AND u.tipo = 2 AND u.departamento = 13";
    	}
    	elseif ($tipo == 6){
    		$t = "AND u.tipo in(3,4) AND u.departamento = 13";
    	}
    	return $this->Select("SELECT ge.usuario, u.tipo, t.des_tipo, u.nome, u.email
    	FROM sis_gestores_empresa ge
		JOIN sis_usuario u ON ge.usuario = u.usuario
		JOIN sis_tipo t ON u.tipo = t.tipo
    	WHERE (ge.empresa IN ({$empresa_origem},{$empresa_destino}) AND u.ativo = 1 {$t}) 
		GROUP BY ge.usuario, u.tipo, t.des_tipo, u.nome, u.email ORDER BY u.nome ASC");
    }
    //Recupera os usuario de forma geral da tabela sis_usuario
    public function getUsuariosdestinatariosdp($empresa_origem, $empresa_destino, $tipo) {
    	if ($tipo == 1){
    		$t = "AND tes.subcategoria = 60";
    	}
    	return $this->Select("SELECT DISTINCT tec.tecnico, tec.nome FROM ( SELECT tes.tecnico, u.nome, tes.empresa, e.des_empresa, tes.subcategoria, s.des_subcategoria, u.usuario
    	FROM help_tec_emp_subcategoria tes
		JOIN help_tecnico t ON tes.tecnico = t.tecnico
    	JOIN sis_usuario u ON t.tecnico = u.usuario
    	JOIN sis_empresa e ON tes.empresa = e.empresa
    	JOIN help_subcategoria s ON tes.subcategoria = s.subcategoria
    	WHERE (tes.empresa IN ({$empresa_origem},{$empresa_destino}) AND u.ativo = 1 {$t}) 
		ORDER BY u.nome ASC)tec");
    }
    
    public function getUsuariobanco($usuario) {
    	return $this->Select("select u.usuario, u.nome, u.cpf, b.nrobanco, b.nroagencia, b.digitoagencia, c.contacorrente
	    from sis_usuario u
	    join sis_empresa e on u.empresa = e.empresa
	    join metadados.rhestabelecimentos es on e.cnpj = replace(replace(es.inscricao,'/',''),'-','')
	    join metadados.rhpessoas p on  u.cpf = p.cpf and es.empresa = p.empresa
	    join metadados.rhcontratos c on c.contrato = u.contrato and c.unidade = es.estabelecimento
	    left join metadados.rhbancos b on c.bancocredor = b.banco
	    where u.usuario = '{$usuario}' ");
    }
    public function getAtualizausuario($cpf) {
    	return $this->First($this->Select("select * from (select rownum linha, p.* from (select 
		p.situacao, p.folha, p.cpf, p.nome, p.empresa, car.cargo, car.departamento, mc.tipo,
		p.contrato, p.dataadmissao dta_admissao, p.datarescisao dta_demissao, 
		p.nascimento dta_nascimento, p.datainicioferias dta_ult_ini_ferias,
		p.dataterminoferias dta_ult_fim_ferias
		from (select c.situacao, to_date(max(c.ultfolconsdatafolha),'dd/mm/yyyy') folha, 
		p.cpf, p.nome, e.empresa, c.cargo metacargo, c.contrato, c.dataadmissao,
		c.datarescisao, p.nascimento, c.datainicioferias, c.dataterminoferias from 
		(select p.empresa, cpf, pessoa, nome, nascimento from metadados.rhpessoas p
		where cpf = '{$cpf}'
		group by p.empresa, cpf, pessoa, nome, nascimento) p
		join metadados.rhcontratos c on c.pessoa = p. pessoa and p.empresa = c.empresa
		join metadados.rhestabelecimentos es on c.unidade = es.estabelecimento
		join sis_empresa e on replace(replace(es.inscricao,'/',''),'-','') = e.cnpj
		where c.ultfolconsdatafolha is not null
		group by c.situacao, p.cpf, p.nome, e.empresa, c.cargo, c.contrato, c.dataadmissao, c.datarescisao,
		p.nascimento, c.datainicioferias, c.dataterminoferias) p
		join sis_int_metacargo mc on p.metacargo = mc.cargo_metadados
		join sis_cargo car on mc.cargo = car.cargo
		order by p.folha DESC) p) p
		where linha = 1"));
    }
    
    public function getEmailenvolvidos($usuarios) {
    	return $this->Select("SELECT u.usuario, u.tipo, u.nome, u.email
    	FROM sis_usuario u
    	WHERE u.usuario in ({$usuarios}) order by tipo desc");
    }
    
    public function getGestoresempresa($empresa = NULL) {
    	if ($empresa != NULL){
    		$cond = "WHERE ge.empresa = '{$empresa}' ";
    	}else{
    		$cond = " ";
    	}
    	return $this->Select("SELECT ge.usuario, ge.empresa, u.tipo, t.des_tipo, u.nome, u.email
    	FROM sis_gestores_empresa ge
		JOIN sis_usuario u ON ge.usuario = u.usuario
		JOIN sis_tipo t ON u.tipo = t.tipo
    	{$cond}order by u.tipo desc, u.nome asc");
    }
    
    public function filtroUsuario($c, $a, $coluna = NULL, $val = NULL, $empresa = NULL, $de = NULL, $ate = NULL) {
    	$funcoes = new Funcoes();
    	$val = strtolower($funcoes->retiraAcentos(trim($val)));
    	$condicao = array(
    		'1'	=> " WHERE LOWER({$coluna}) = '{$val}' ",
    		'2' => " WHERE LOWER({$coluna}) LIKE '%{$val}%' ",
    		'3'	=> " ",
    		'4' => " WHERE LOWER({$coluna}) LIKE '{$val}%' ",
    		'5' => " WHERE TO_DATE(TO_CHAR(TO_DATE({$coluna}, 'dd/mm/yyyy hh24:mi:ss'), 'dd/mm/yyyy'), 'dd/mm/yyyy') BETWEEN TO_DATE('{$de}','dd/mm/yyyy') AND TO_DATE('{$ate}','dd/mm/yyyy') "
    	);
    	$ativo = array(
    		'1' => "AND u.ativo = '1' ",
    		'2' => "AND u.ativo = '0' ",
    		'3' => "",
    		'4' => "AND u.ativo = '1' AND u.empresa = '{$empresa}' ",
    		'5' => "AND (u.ativo = '1' OR u.ativo = '0')",
    		'6' => "AND u.ativo in(0,1,2,3)"
    	);
    	return $this->Select("SELECT R2.*
    	FROM (SELECT rownum n_linha, R.*
    	FROM(SELECT u.usuario, u.tipo, t.des_tipo, u.departamento, u.cargo, c.des_cargo,
		d.des_departamento, u.cpf, u.nome, u.dta_nascimento, u.dta_admissao, u.dta_demissao, u.email, u.senha, u.telefone, 
		u.celular, u.ip, u.empresa, e.des_empresa, u.ativo, u.dta_cadastro, u.dta_ult_ini_ferias, u.dta_ult_fim_ferias,
		u.dta_ult_alteracao, u.dta_ult_acesso, u.status, u.deg, u.contrato 
    	FROM sis_usuario u
    	JOIN sis_tipo t ON u.tipo = t.tipo
		JOIN sis_departamento d ON u.departamento = d.departamento
		JOIN sis_cargo c ON u.cargo = c.cargo 
		JOIN sis_empresa e ON u.empresa = e.empresa
		{$condicao[$c]}{$ativo[$a]}ORDER BY u.usuario DESC) R ) R2");
    }
    
    public function migracaoUsuario(){
     return $this->Select("select u.usuario,p.cpf, p.nomecompleto nome, p.email,e.empresa 
      from metadados.rhpessoas p
      join metadados.rhcontratos c on p.pessoa = c.pessoa and c.unidade = 0401 
      join metadados.rhestabelecimentos es on c.unidade = es.estabelecimento
      join sis_empresa e on replace(replace(es.inscricao,'/',''),'-','') = e.cnpj
      left join sis_usuario u on p.cpf = u.cpf
      where p.contratosativos = 1 and p.empresa = 0400 and u.usuario is null and p.email is not null
      group by u.usuario,p.cpf, p.nomecompleto, p.email,e.empresa");
    }
    
    public function migracaoUsuarioausente(){
    	return $this->Select("select c1.cpf, c1.nome, c1.email, c1.empresa, c1.des_empresa
		from
		(select p.cpf, p.nomecompleto nome, p.email, e.empresa, e.des_empresa
		from metadados.rhpessoas p
		join metadados.rhcontratos c on p.pessoa = c.pessoa and p.empresa = c.empresa
		join metadados.rhestabelecimentos es on c.unidade = es.estabelecimento
		join sis_empresa e on replace(replace(es.inscricao,'/',''),'-','') = e.cnpj
		where p.contratosativos = 1) c1
		join
		(select substr(ge.email, 1, instr(ge.email, '@')-1) email from grupo_emails ge 
		join sis_rotina r on ge.action = r.des_reduzida
		left join sis_usuario u on  substr(ge.email, 1, instr(ge.email, '@')-1) = substr(u.email, 1, instr(u.email, '@')-1)
		where u.usuario is null group by substr(ge.email, 1, instr(ge.email, '@')-1)) c2 on substr(c1.email, 1, instr(c1.email, '@')-1) = c2.email");
	}
	public function retornoferiasForcado($data){
		return $this->Select("select * from sis_usuario u  where u.dta_ult_ini_ferias = '{$data}' ");
	}
	
	public function dandoPermissao($modulo,$controle,$acao){
		return $this->Select("select p.modulo, u.usuario, u.empresa 
		from sis_usuario u
		left join sis_permissao p on 
		u.usuario = p.usuario and u.empresa =  p.empresa and 
		p.modulo = '{$modulo}' and p.controle = '{$controle}' and p.acao = '{$acao}'
		where p.modulo is null");
	}
    
    public function addUsuario(Usuario $obj){
    	$prepare = new PrepareSQL();
    	$funcoes = new Funcoes();
    	$obj->senha = md5(substr(ucfirst($obj->nome), 0, 2).$obj->cpf);
    	$obj->nome = $funcoes->formataTexto($funcoes->retiraAcentos(trim($obj->nome)));
    	$obj = (array) $obj;
    	$obj = array_filter($obj, function($v){return !is_null($v);});
    	$obj = array_filter($obj, function($v){return $v != 'funcao' && $v != 'modulo';}, ARRAY_FILTER_USE_KEY);
    	return $prepare->PrepareInsert($obj, 'sis_usuario','usuario');	
    }
    
    public function addGestor(Usuario $obj){
    	$prepare = new PrepareSQL();
    	$obj = (array) $obj;
    	$obj = array_filter($obj, function($v){return !is_null($v);});
    	return $prepare->PrepareInsert($obj, 'sis_gestores_empresa');
    }
    
    public function addModulousuario(Usuario $obj,$currval = NULL){
    	$prepare = new PrepareSQL();
    	$obj = array('usuario'=>$obj->usuario,'modulo' => $obj->modulo);
    	if ($currval != NULL){
    		$obj = array_filter($obj, function($v){return $v != 'usuario';}, ARRAY_FILTER_USE_KEY);
    		return $prepare->PrepareInsert($obj, 'sis_usuario_modulo',"",$currval);
    	}else{
    		return $prepare->PrepareInsert($obj, 'sis_usuario_modulo');
    	}
    }
    
    public function editUsuario(Usuario $obj) {
    	$prepare = new PrepareSQL();
    	if (isset($obj->senha) && strlen($obj->senha) < 32 ){
    		$obj->senha = md5($obj->senha);
    	}
    	if (isset($obj->nome)){
    		$funcoes = new Funcoes();
    		$obj->nome = $funcoes->formataTexto($funcoes->retiraAcentos(trim($obj->nome)));
    	}
    	$obj = (array) $obj;
    	$obj = array_filter($obj, function($v){return !is_null($v);});
    	$set = array_filter($obj, function($v){return $v != 'usuario' && $v != 'funcao' && $v != 'modulo';}, ARRAY_FILTER_USE_KEY);
    	return $prepare->PrepareUpdate($set,array('usuario' => $obj['usuario']),'sis_usuario');
    }
    
    public function delUsuario(Usuario $obj) {
    	$prepare = new PrepareSQL();
    	return $prepare->PrepareDelete(array('usuario' => $obj->usuario), 'sis_usuario');

    }
    public function delGestor(Usuario $obj) {
    	$prepare = new PrepareSQL();
    	return $prepare->PrepareDelete(array('usuario' => $obj->usuario, 'empresa' => $obj->empresa), 'sis_gestores_empresa'); 	
    }
    
    public function delModulousuario(Usuario $obj) {
    	$prepare = new PrepareSQL();
    	return $prepare->PrepareDelete(array('usuario' => $obj->usuario, 'modulo' => $obj->modulo), 'sis_usuario_modulo');
    	
    }
    
    public function executeSQL($sql){
    	return $this->Execute($sql);
    }
}