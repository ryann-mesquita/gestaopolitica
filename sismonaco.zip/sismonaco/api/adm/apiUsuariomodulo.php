<?php

namespace api\adm;

use lib\Model;
use obj\adm\Usuariomodulo;
use helper\PrepareSQL;

class apiUsuariomodulo extends Model {
	
	public function getUsuariomodulo(Usuariomodulo $obj) {
		
		return $this->Select("SELECT um.usuario, um.modulo, m.des_reduzida, m.des_modulo 
    	FROM sis_usuario_modulo um
		JOIN sis_modulo m ON um.modulo = m.modulo
		WHERE um.usuario = '{$obj->usuario}' AND um.modulo = '{$obj->modulo}'");
		
	}
	public function filtroUsuariomodulo($c, $a, $coluna = NULL, $val = NULL) {
		$val = strtolower(trim($val));
		$condicao = array(
			'1'	=> " WHERE LOWER(um.{$coluna}) = '{$val}' ",
			'2' => " WHERE LOWER(um.{$coluna}) LIKE '%{$val}%' ",
			'3'	=> " ",
		);
		$ativo = array(
			'1' => "AND m.ativo = '1' ",
			'2' => "AND m.ativo = '0' ",
			'3' => "",
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT um.usuario, um.modulo, m.des_reduzida, m.des_modulo, m.ativo 
    	FROM sis_usuario_modulo um
		JOIN sis_modulo m ON um.modulo = m.modulo
		{$condicao[$c]}{$ativo[$a]}) R ) R2");
	}
	
	public function addUsuariomodule(Usuariomodule $obj, $sql = NULL){
		
		$prepare = new PrepareSQL();
		
		if ($sql != NULL){
			
			return $this->Execute($sql);
			
		}else {
			
			return $prepare->PrepareInsert($obj, 'usuario_module');
			
		}
	}
	
	public function delUsuariomodule(Usuariomodule $obj, $sql = NULL) {
		
		$prepare = new PrepareSQL();
		
		if ($sql != NULL){
			
			return $this->Execute($sql);
			
		}else {
			
			return $prepare->PrepareDelete(array('cpf' => $obj->cpf, 'id_module' => $obj->id_module), 'usuario_module');
			
		}
	}
}