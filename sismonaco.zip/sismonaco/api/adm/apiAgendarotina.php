<?php

namespace api\adm;

use lib\Model;
use obj\adm\Agendarotina;
use helper\PrepareSQL;

class apiAgendarotina extends Model {

	public function getAgendarotina(Agendarotina $obj) {
		return  $this->First($this->Select("SELECT ar.rotina, r.des_reduzida, r.des_rotina, r.ativo, ar.frequencia, ar.segunda,
		ar.terca, ar.quarta, ar.quinta, ar.sexta, ar.sabado, ar.domingo, ar.dia1, ar.dia2, ar.dia3, ar.dia4, ar.dia5, ar.dia6,
		ar.dia7, ar.dia8, ar.dia9, ar.dia10, ar.dia11, ar.dia12, ar.dia13, ar.dia14, ar.dia15, ar.dia16, ar.dia17, ar.dia18,
		ar.dia19, ar.dia20, ar.dia21, ar.dia22, ar.dia23, ar.dia24, ar.dia25, ar.dia26, ar.dia27, ar.dia28, ar.dia29,
		ar.dia30, ar.dia31, ar.hora_execucao, ar.dta_ult_execucao, ar.hora_ult_execucao, ar.erro_ult_execucao, ar.prioridade
	    FROM sis_agenda_rotina ar
		JOIN sis_rotina r ON ar.rotina = r.rotina
		WHERE ar.rotina = '{$obj->rotina}'"));
	}
	public function addAgendarotina(Agendarotina $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareInsert($obj, 'sis_agenda_rotina');
	}
	
	public function editAgendarotina(Agendarotina $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'rotina';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('rotina' => $obj['rotina']), 'sis_agenda_rotina');
	}

	public function getRotinaagendada($prioridade,$data,$hora,$dia,$semana) {
		return $this->Select("SELECT ar.rotina, r.des_reduzida, r.des_rotina, r.ativo, ar.frequencia, ar.segunda,
	    ar.terca, ar.quarta, ar.quinta, ar.sexta, ar.sabado, ar.domingo, ar.dia1, ar.dia2, ar.dia3, ar.dia4, ar.dia5, ar.dia6,
	    ar.dia7, ar.dia8, ar.dia9, ar.dia10, ar.dia11, ar.dia12, ar.dia13, ar.dia14, ar.dia15, ar.dia16, ar.dia17, ar.dia18,
	    ar.dia19, ar.dia20, ar.dia21, ar.dia22, ar.dia23, ar.dia24, ar.dia25, ar.dia26, ar.dia27, ar.dia28, ar.dia29,
	    ar.dia30, ar.dia31, ar.hora_execucao, ar.dta_ult_execucao, ar.hora_ult_execucao, ar.erro_ult_execucao, ar.prioridade
	    FROM sis_agenda_rotina ar
	    JOIN sis_rotina r ON ar.rotina = r.rotina
	    WHERE ar.prioridade = '{$prioridade}' AND 
		((r.ativo = '1' AND ar.frequencia = 'H' AND to_date(ar.dta_ult_execucao ||' '|| ar.hora_ult_execucao, 'dd/mm/yyyy hh24:mi:ss')+(60/1440) <= sysdate)
	    OR (r.ativo = '1' AND ar.frequencia = 'D'  AND to_date(ar.dta_ult_execucao, 'dd/mm/yyyy') < to_date('{$data}','dd/mm/yyyy') 
	    AND to_date('{$hora}', 'hh24:mi:ss' ) >= to_date(ar.hora_execucao,'hh24:mi:ss'))
	    OR (r.ativo = '1' AND ar.frequencia = 'S'  AND ar.{$semana} = '1' AND to_date(ar.dta_ult_execucao, 'dd/mm/yyyy') < to_date('{$data}','dd/mm/yyyy') 
	    AND to_date('{$hora}', 'hh24:mi:ss' ) >= to_date(ar.hora_execucao,'hh24:mi:ss'))
	    OR (r.ativo = '1' AND ar.frequencia = 'Q' AND (to_date(ar.dta_ult_execucao, 'dd/mm/yyyy') + 15) <= to_date('{$data}','dd/mm/yyyy')
    	AND to_date('{$hora}', 'hh24:mi:ss' ) >= to_date(ar.hora_execucao,'hh24:mi:ss'))
	    OR (r.ativo = '1' AND ar.frequencia = 'M' AND ar.dia{$dia} = '1' AND to_date(ar.dta_ult_execucao, 'dd/mm/yyyy') < to_date('{$data}','dd/mm/yyyy')
    	AND to_date('{$hora}', 'hh24:mi:ss' ) >= to_date(ar.hora_execucao,'hh24:mi:ss'))
	    OR (r.ativo = '1' AND ar.frequencia = 'QA' AND add_months(to_date(ar.dta_ult_execucao, 'dd/mm/yyyy'), +4) <= to_date('{$data}','dd/mm/yyyy')
    	AND to_date('{$hora}', 'hh24:mi:ss' ) >= to_date(ar.hora_execucao,'hh24:mi:ss')))");
	}
	
	public function getRotinaemail($data,$hora) {
		return $this->Select("SELECT ar.rotina, r.des_reduzida, r.des_rotina, r.ativo, ar.frequencia, ar.segunda,
		ar.terca, ar.quarta, ar.quinta, ar.sexta, ar.sabado, ar.domingo, ar.dia1, ar.dia2, ar.dia3, ar.dia4, ar.dia5, ar.dia6,
		ar.dia7, ar.dia8, ar.dia9, ar.dia10, ar.dia11, ar.dia12, ar.dia13, ar.dia14, ar.dia15, ar.dia16, ar.dia17, ar.dia18,
		ar.dia19, ar.dia20, ar.dia21, ar.dia22, ar.dia23, ar.dia24, ar.dia25, ar.dia26, ar.dia27, ar.dia28, ar.dia29,
		ar.dia30, ar.dia31, ar.hora_execucao, ar.dta_ult_execucao, ar.hora_ult_execucao, ar.erro_ult_execucao, ar.prioridade
		FROM sis_agenda_rotina ar
		JOIN sis_rotina r ON ar.rotina = r.rotina
		WHERE ar.rotina = '36' AND to_date('{$data} {$hora}','dd/mm/yyyy hh24:mi:ss') >= to_date(to_char(to_date(ar.dta_ult_execucao||' '||ar.hora_ult_execucao,'dd/mm/yyyy hh24:mi:ss') + 60/1440,'dd/mm/yyyy hh24:mi:ss'),'dd/mm/yyyy hh24:mi:ss')");
	}
	
	public function getInconsistenciasNF($de,$ate){
		return $this->Select("SELECT mc.empresa, mc.revenda, r.cnpj, pj.cgc, mc.nfe_chave_acesso, mc.uf_cliente,
		mc.dta_entrada_saida, mc.cod_modelo_nf_usofiscal, mc.serie_nota_fiscal, mc.numero_nota_fiscal
		FROM fat_movimento_capa mc 
		JOIN ger_revenda r ON mc.empresa = r.empresa and mc.revenda = r.revenda
		JOIN fat_pessoa_juridica pj ON mc.cliente = pj.cliente
		WHERE mc.nfe_chave_acesso is not null AND mc.dta_entrada_saida BETWEEN to_date('{$de}','dd/mm/yyyy')
		AND to_date('{$ate}','dd/mm/yyyy') ORDER BY empresa,revenda");
	}
	
	public function getTitulosemaberto(){
		return $this->Select("SELECT t.empresa, t.revenda, t.titulo, t.val_titulo, t.cliente, t.status 
		FROM cnp.fin_titulo t
		WHERE t.status in ('EM') AND t.tipo = 'CP' AND t.cliente = 9 AND t.titulo in (SELECT v.numero_nota_nfentrada FROM cnp.vei_veiculo v WHERE v.situacao = 'TM')
		ORDER BY empresa, revenda");
	}
	
	public function getDespesasanalitico() {
		return $this->Select("select * from cnp.j_despesas_analitico");
	}
	
	public function getDespesassintetico() {	
		return $this->Select("select * from cnp.j_despesas_sintetico");
	}
	
	public function getEstoquegeralhd() {
		return $this->Select("select * from cnp.j_v_estoque_pecas_geral_hd");
	}
	
	public function getEstoquegeralvw() {
		return $this->Select("select * from cnp.j_v_estoque_pecas_geral_vw");
	}
	
	public function getEstoquegeralfiat() {	
		return $this->Select("select * from cnp.j_v_estoque_pecas_geral_fiat");
	}
	
	public function getMaparesultados1() {	
		return $this->Select("select * from cnp.j_mapa_resultados_1");
	}
	
	public function getMapasresultados2() {
		return $this->Select("select * from cnp.j_mapa_resultados_2");
	}
	
	public function getGarantiaaberto30() {
		return $this->Select("SELECT INA.*, INA2.NOME NOME_APROVADOR FROM
		(SELECT J1.*, TP.val_pag, J1.VAL_TITULO - TP.val_pag SALDO_TITULO FROM
		(select DISTINCT T.EMPRESA,T.REVENDA,T.TITULO,T.DUPLICATA,T.CLIENTE,
		y.NOME NOME_CLIENTE, T.TIPO, T.DEPARTAMENTO, u.vendedor, u.NOME NOME_VENDEDOR, T.ORIGEM, G.DES_ORIGEM,
		T.DTA_VENCIMENTO, T.VAL_TITULO, T.PAGAR_RECEBER, T.STATUS, T.OPERACAO
		from FIN_TITULO t JOIN FIN_ORIGEM G on(t.empresa = g.empresa and t.origem = g.origem)
		join fat_vendedor u on(t.empresa = u.empresa and t.revenda = u.revenda and t.usuario = u.usuario)
		join fat_cliente y on (t.cliente = y.cliente)
		where T.EMPRESA IN (1,2,3,4,5,6,7,8,9,10,11,13) and T.ORIGEM IN (1122,1125,1136) AND pagar_receber = 'R' and status IN ('EM','PP')
		AND DTA_VENCIMENTO between TO_DATE('26/12/1990 00:01:00','dd/mm/yyyy HH24:MI:SS') and TO_DATE(to_char(sysdate-30,'dd/mm/yyyy HH24:MI:SS'),'dd/mm/yyyy HH24:MI:SS')
		) J1
		JOIN
		(
		 SELECT p1.Empresa, p1.Revenda, p1.Titulo, p1.Duplicata, p1.Cliente, p1.TIPO, sum(p1.val_pagamento) val_pag
		 FROM FIN_TITULO_PAGAMENTO p1
		 group by p1.Empresa, p1.Revenda, p1.Titulo, p1.Duplicata, p1.Cliente, p1.TIPO
		 ) tp
		ON TP.EMPRESA = J1.EMPRESA AND TP.REVENDA = J1.REVENDA AND
		TP.TITULO = J1.TITULO AND TP.DUPLICATA = J1.DUPLICATA AND TP.CLIENTE = J1.CLIENTE AND TP.TIPO = J1.TIPO
		) INA
		LEFT OUTER JOIN
		(
		select DISTINCT GA.USUARIO_APROV, U1.NOME, CO.OPERACAO, FT9.EMPRESA, FT9.REVENDA, FT9.TITULO, FT9.DUPLICATA, FT9.CLIENTE
		from GER_APROVACAO GA
		JOIN FAT_MOVIMENTO_CAPA CO ON(GA.EMPRESA = CO.EMPRESA AND GA.REVENDA = CO.REVENDA AND GA.CONTATO = CO.CONTATO)
		JOIN GER_USUARIO U1 ON (GA.USUARIO_APROV = U1.USUARIO)
		JOIN FIN_TITULO FT9 ON CO.OPERACAO = FT9.OPERACAO
		where FUNCAO IN (38,61)
		) INA2 ON(INA.EMPRESA = INA2.EMPRESA AND INA.REVENDA = INA2.REVENDA AND INA.TITULO = INA2.TITULO AND
		INA.DUPLICATA = INA2.DUPLICATA AND INA.CLIENTE = INA2.CLIENTE) ");
	}
	
	public function getGarantiaaberto() {
		return $this->Select("SELECT INA.*, INA2.NOME NOME_APROVADOR FROM
		(SELECT J1.*, TP.val_pag, J1.VAL_TITULO - TP.val_pag SALDO_TITULO FROM
		(select DISTINCT T.EMPRESA,T.REVENDA,T.TITULO,T.DUPLICATA,T.CLIENTE,
		y.NOME NOME_CLIENTE, T.TIPO, T.DEPARTAMENTO, u.vendedor, u.NOME NOME_VENDEDOR, T.ORIGEM, G.DES_ORIGEM,
		T.DTA_VENCIMENTO, T.VAL_TITULO, T.PAGAR_RECEBER, T.STATUS, T.OPERACAO
		from FIN_TITULO t JOIN FIN_ORIGEM G on(t.empresa = g.empresa and t.origem = g.origem)
		join fat_vendedor u on(t.empresa = u.empresa and t.revenda = u.revenda and t.usuario = u.usuario)
		join fat_cliente y on (t.cliente = y.cliente)
		where T.EMPRESA IN (1,2,3,4,5,6,7,8,9,10,11,13) and t.origem in (1125,1122,1136) and status IN ('EM','PP')
		AND DTA_VENCIMENTO between TO_DATE('01/01/1990','dd/mm/yyyy') and TO_DATE('31/12/2999','dd/mm/yyyy')
		) J1
		JOIN
		(
		 SELECT p1.Empresa, p1.Revenda, p1.Titulo, p1.Duplicata, p1.Cliente, p1.TIPO, sum(p1.val_pagamento) val_pag
		 FROM FIN_TITULO_PAGAMENTO p1
		 group by p1.Empresa, p1.Revenda, p1.Titulo, p1.Duplicata, p1.Cliente, p1.TIPO
		 ) tp
		ON TP.EMPRESA = J1.EMPRESA AND TP.REVENDA = J1.REVENDA AND
		TP.TITULO = J1.TITULO AND TP.DUPLICATA = J1.DUPLICATA AND TP.CLIENTE = J1.CLIENTE AND TP.TIPO = J1.TIPO
		) INA
		LEFT OUTER JOIN
		(
		select DISTINCT GA.USUARIO_APROV, U1.NOME, CO.OPERACAO, FT9.EMPRESA, FT9.REVENDA, FT9.TITULO, FT9.DUPLICATA, FT9.CLIENTE
		from GER_APROVACAO GA
		JOIN FAT_MOVIMENTO_CAPA CO ON(GA.EMPRESA = CO.EMPRESA AND GA.REVENDA = CO.REVENDA AND GA.CONTATO = CO.CONTATO)
		JOIN GER_USUARIO U1 ON (GA.USUARIO_APROV = U1.USUARIO)
		JOIN FIN_TITULO FT9 ON CO.OPERACAO = FT9.OPERACAO
		where FUNCAO IN (38,61)
		) INA2 ON(INA.EMPRESA = INA2.EMPRESA AND INA.REVENDA = INA2.REVENDA AND INA.TITULO = INA2.TITULO AND
		INA.DUPLICATA = INA2.DUPLICATA AND INA.CLIENTE = INA2.CLIENTE)");
	}
	
	public function getInadiplencia() {
		return $this->Select("SELECT INA.*, INA2.NOME NOME_APROVADOR FROM
		(SELECT J1.*, TP.val_pag, J1.VAL_TITULO - TP.val_pag SALDO_TITULO FROM
		(select DISTINCT T.EMPRESA,T.REVENDA,T.TITULO,T.DUPLICATA,T.CLIENTE,
		y.NOME NOME_CLIENTE, T.TIPO, T.DEPARTAMENTO, u.vendedor, u.NOME NOME_VENDEDOR, T.ORIGEM,
		G.DES_ORIGEM,T.DTA_VENCIMENTO, T.VAL_TITULO, T.PAGAR_RECEBER, T.STATUS, T.OPERACAO
		from FIN_TITULO t JOIN FIN_ORIGEM G on(t.empresa = g.empresa and t.origem = g.origem)
		join fat_vendedor u on(t.empresa = u.empresa and t.revenda = u.revenda and t.usuario = u.usuario)
		join fat_cliente y on (t.cliente = y.cliente)
		where T.EMPRESA IN (1,2,3,4,5,6,7,8,9,10,11,13,50,51,52,53,54) and pagar_receber = 'R'
		and t.origem not in (1125,1136,1122) and t.departamento in (300,400)
		and status IN ('EM','PP')
		AND DTA_VENCIMENTO between TO_DATE(to_char(sysdate-365,'dd/mm/yyyy'),'dd/mm/yyyy') and TO_DATE(to_char(sysdate-180,'dd/mm/yyyy'),'dd/mm/yyyy')
		) J1
		JOIN
		(
		 SELECT p1.Empresa, p1.Revenda, p1.Titulo, p1.Duplicata, p1.Cliente, p1.TIPO, sum(p1.val_pagamento) val_pag
		 FROM FIN_TITULO_PAGAMENTO p1
		 group by p1.Empresa, p1.Revenda, p1.Titulo, p1.Duplicata, p1.Cliente, p1.TIPO
		 ) tp
		ON TP.EMPRESA = J1.EMPRESA AND TP.REVENDA = J1.REVENDA AND
		TP.TITULO = J1.TITULO AND TP.DUPLICATA = J1.DUPLICATA AND TP.CLIENTE = J1.CLIENTE AND TP.TIPO = J1.TIPO
		) INA
		LEFT OUTER JOIN
		(
		select DISTINCT GA.USUARIO_APROV, U1.NOME, CO.OPERACAO, FT9.EMPRESA, FT9.REVENDA, FT9.TITULO, FT9.DUPLICATA, FT9.CLIENTE
		from GER_APROVACAO GA
		JOIN FAT_MOVIMENTO_CAPA CO ON(GA.EMPRESA = CO.EMPRESA AND GA.REVENDA = CO.REVENDA AND GA.CONTATO = CO.CONTATO)
		JOIN GER_USUARIO U1 ON (GA.USUARIO_APROV = U1.USUARIO)
		JOIN FIN_TITULO FT9 ON CO.OPERACAO = FT9.OPERACAO
		where FUNCAO IN (38,61)
		) INA2 ON(INA.EMPRESA = INA2.EMPRESA AND INA.REVENDA = INA2.REVENDA AND INA.TITULO = INA2.TITULO AND
		INA.DUPLICATA = INA2.DUPLICATA AND INA.CLIENTE = INA2.CLIENTE) ");
	}
	
	public function getChequedia(){
		$data = date("m/Y");
		return $this->Select("SELECT TO_CHAR(T.DTA_VENCIMENTO,'dd/MON/YYYY') dia, t.banco, b.des_banco, SUM(T.VAL_TITULO) valor
		FROM  FIN_TITULO T join cnp.fin_banco b on (t.EMPRESA = b.empresa and t.REVENDA = b.revenda and t.BANCO = b.banco)
		WHERE T.EMPRESA <> 12 AND T.STATUS = 'EM' AND t.tipo = 'CH' and to_char(t.dta_vencimento,'mm/yyyy') = '$data'
		GROUP BY t.banco, b.des_banco, TO_CHAR(T.DTA_VENCIMENTO,'dd/MON/YYYY')order by dia, t.banco");
	}
	
	public function getChequemes(){
		return $this->Select("SELECT TO_CHAR(T.DTA_VENCIMENTO,'YYYY') ano, TO_CHAR(T.DTA_VENCIMENTO,'mm') mes,
		TO_CHAR(T.DTA_VENCIMENTO,'MON/YYYY') mesano, t.banco, b.des_banco, SUM(T.VAL_TITULO) valor
		FROM  cnp.FIN_TITULO T join cnp.fin_banco b on (t.EMPRESA = b.empresa and t.REVENDA = b.revenda and t.BANCO = b.banco)
		WHERE T.EMPRESA <> 12 AND T.STATUS = 'EM' AND t.tipo = 'CH' and to_date(t.dta_vencimento,'dd/mm/yyyy') >= to_date(sysdate,'dd/mm/yyyy')
		GROUP BY TO_CHAR(T.DTA_VENCIMENTO,'YYYY'), TO_CHAR(T.DTA_VENCIMENTO,'mm'), TO_CHAR(T.DTA_VENCIMENTO,'MON/YYYY'), t.banco, b.des_banco
		order by TO_CHAR(T.DTA_VENCIMENTO,'YYYY'), TO_CHAR(T.DTA_VENCIMENTO,'mm'), t.banco");
	}
	
	public function getContasreceberdia(){
		$data = date("m/Y");
		return $this->Select("SELECT TO_CHAR(T.DTA_VENCIMENTO,'dd/MON/YYYY')mesano, count(*) quantidade, SUM(T.VAL_TITULO) valor, round(SUM(T.VAL_TITULO)/count(*),2) media
		FROM  cnp.FIN_TITULO T WHERE T.EMPRESA <> 12 AND T.STATUS = 'EM' AND t.tipo = 'CR' and t.banco in(113,108,102,103,101) and to_char(t.dta_vencimento,'mm/yyyy') = '".$data."'
		GROUP BY to_char(T.DTA_VENCIMENTO,'mm'),  TO_CHAR(T.DTA_VENCIMENTO,'yyyy'), TO_CHAR(T.DTA_VENCIMENTO,'dd/MON/YYYY')
		order by mesano");
	}
	
	public function getContasrecebermes(){
		return $this->Select("SELECT TO_CHAR(T.DTA_VENCIMENTO,'mm') mes,  TO_CHAR(T.DTA_VENCIMENTO,'yyyy') ano, TO_CHAR(T.DTA_VENCIMENTO,'MON/YYYY')mesano,
		count(*) quantidade, SUM(T.VAL_TITULO) valor, round(SUM(T.VAL_TITULO)/count(*),2) media FROM  cnp.FIN_TITULO T WHERE T.EMPRESA <> 12 AND
		T.STATUS = 'EM' AND t.tipo = 'CR' and t.banco in(113,108,102,103,101) and to_date(t.dta_vencimento,'dd/mm/yyyy') >= to_date(sysdate,'dd/mm/yyyy')
		GROUP BY to_char(T.DTA_VENCIMENTO,'mm'),  TO_CHAR(T.DTA_VENCIMENTO,'yyyy'), TO_CHAR(T.DTA_VENCIMENTO,'MON/YYYY')
		order by ano, mes");	
	}
	
	public function getMotologistica(){
		return $this->Select("select * from cnp.j_logistica_veiculos_faturados");
	}
	
	public function getEstoquemotos(){	
		return $this->Select("SELECT g.nome_fantasia, V.EMPRESA, V.REVENDA_ORIGEM, V.VEICULO,V.SITUACAO,V.val_custo_contabil,
		V.MODELO, NVL(m.preco_publico,0) preco_publico, TRUNC(SYSDATE - V.DTA_ENTRADA) dias_em_estoques,V.COR,V.LOCALIZACAO FROM CNP.VEI_VEICULO V
		join cnp.vei_modelo m on(v.EMPRESA = m.empresa and v.MODELO = m.modelo) join cnp.ger_revenda g
		on (v.empresa = g.empresa and v.revenda_origem = g.revenda) WHERE V.SITUACAO not in('FT','VD','VE','DC','DD','CH','DE','ED','LX','IM','MI','EM')
		and v.empresa in (2,6,7,8,9,10) AND V.NOVO_USADO IN ('N') ORDER BY V.EMPRESA, V.REVENDA_ORIGEM, m.preco_publico");
	}
	
	public function getSaidademonstracao(){
		return $this->Select("select MV.EMPRESA, MV.REVENDA, MV.NUMERO_NOTA_FISCAL, MV.SERIE_NOTA_FISCAL, MV.TIPO_TRANSACAO, VE.SITUACAO,
		VE.REVENDA_ORIGEM, MV.VEICULO, CO.DES_COR, MD.DES_MODELO, VE.LOCALIZACAO, CL.CLIENTE, CL.NOME,
		MC.DTA_ENTRADA_SAIDA, MC.DTA_ENTRADA_SAIDA+60 DTA_VENCIMENTO, CURRENT_DATE-MC.DTA_ENTRADA_SAIDA DIAS
		from FAT_MOVIMENTO_VEICULO MV
		inner join FAT_MOVIMENTO_CAPA MC on (MC.EMPRESA = MV.EMPRESA and MC.REVENDA = MV.REVENDA and MC.NUMERO_NOTA_FISCAL = MV.NUMERO_NOTA_FISCAL
		and MC.SERIE_NOTA_FISCAL = MV.SERIE_NOTA_FISCAL and MC.TIPO_TRANSACAO = MV.TIPO_TRANSACAO and MC.CONTADOR = MV.CONTADOR)
		inner join FAT_CLIENTE CL on (CL.CLIENTE = MC.CLIENTE) inner join VEI_VEICULO VE on (VE.EMPRESA = MV.EMPRESA and VE.VEICULO = MV.VEICULO)
		inner join VEI_MODELO MD on (MD.EMPRESA = VE.EMPRESA and MD.MODELO = VE.MODELO) inner join VEI_COR CO on (CO.EMPRESA = VE.EMPRESA and CO.COR = VE.COR)
		where MC.TIPO_TRANSACAO in ('M29','M26','M32','M36','M66','M69') and VE.SITUACAO in ('SD')");
	}
	
	public function getVmog(){
		return $this->Select("Select case OS.EMPRESA||OS.REVENDA when '11' then '4700' when '51' then '4731'
		when '52' then '1960' when '41' then '4730' when '42' then '1936' when '111' then '4756' when '31' then '4738'
		when '33' then '1928' when '32' then '4774' else 'Nao e Diesel' end DN,
		OS.NRO_OS OS, OS.DTA_EMISSAO DatadeAbertura , OS.DTA_ENCERRAMENTO DatadeFaturamento,
		CASE TS.TIPO_SERVICO
		WHEN 'CF' THEN 'Cliente'
		WHEN 'CM' THEN 'Cliente'
		WHEN 'CP' THEN 'Cliente'
		WHEN 'CR' THEN 'Cliente'
		WHEN 'ST' THEN 'Cliente'
		WHEN 'DL' THEN 'Garantia'
		WHEN 'GF' THEN 'Garantia'
		WHEN 'GM' THEN 'Garantia'
		WHEN 'GP' THEN 'Garantia'
		WHEN 'GR' THEN 'Garantia'
		WHEN 'GO' THEN 'Interna'
		WHEN 'IA' THEN 'Interna'
		WHEN 'IP' THEN 'Interna'
		WHEN 'IU' THEN 'Interna'
		WHEN 'IVC' THEN 'Interna'
		WHEN 'IVO' THEN 'Interna'
		WHEN 'IVR' THEN 'Interna'
		WHEN 'PO' THEN 'Interna'
		WHEN 'VM' THEN 'Volkstotal'
		WHEN 'VR' THEN 'Volkstotal'
		END FONTEPAGADORA, ATE.CHASSI ChassidoVeiculo, v.des_modelo ModelodoVeiculo, v.modelo modelo,
		CASE CT.IDENTIFICACAO
		WHEN 'M' THEN 'Mecanica'
		WHEN 'V' THEN 'Revisao'
		WHEN 'F' THEN 'Funilaria'
		WHEN 'P' THEN 'Pintura'
		WHEN 'E' THEN 'Eletrica'
		WHEN 'N' THEN 'Servi�o Rapido'
		WHEN 'Z' THEN 'Funilaria'
		WHEN 'B' THEN 'Lubrificacao'
		WHEN 'O' THEN 'MECANICA'
		WHEN 'G' THEN 'Revisao'
		WHEN 'M' THEN 'Deslocamento'
		WHEN 'L' THEN 'Lavagem'
		END NaturezadoServico ,
		SE.MAODEOBRA CodigodoTPR, SOS.DESCRICAO DescricaodoServico, SOS.QUANTIDADE TempoVendido, (SOS.QUANTIDADE*SOS.VAL_SERVICO)-SOS.VAL_DESCONTO ValorFaturado,
		CASE SE.MAODEOBRA WHEN 'ST' THEN 'Nao' else 'Sim' END Oficina,
		CASE SE.MAODEOBRA WHEN 'ST' THEN 'Sim' else 'Nao' END Terceiro,
				
		CASE v.familia WHEN 5 THEN 'Onibus' ELSE 'Caminhoes' END CategoriadoVeiculo,
		CASE SE.MAODEOBRA WHEN 'DESL' THEN 'Sim' else 'Nao' END Deslocamento,
				
		CLI.NOME NomedoCliente,
				
		CASE CLI.FISJUR WHEN 'F' THEN 'Fisica' else 'Juridica' END TipodeCliente,
				
		case when FIS.CPF is null then JUR.CGC when JUR.CGC is null then TO_CHAR(FIS.CPF) else 'NULO' end CGC_CPF,
		CLI.NOME_PAIS Pais, ate.nome_contato Contato, '0'||CLI.DDD_TELEFONE||'-'||CLI.TELEFONE Telefone, '0'||CLI.DDD_CELULAR||'-'||CLI.CELULAR Celular,
		case when CLI.E_MAIL_TRABALHO is null then CLI.E_MAIL_CASA else CLI.E_MAIL_TRABALHO end Email, ATE.KILOMETRAGEM, ATE.PLACA,
				
		CASE WHEN UPPER (V.DES_MODELO) LIKE '%MAN%' THEN 'Man' else 'VW' END MontadoraVW_MAN,
				
		CLI.TIPOVIA_ENTREGA TipoVia,LOGRADOURO_ENTREGA Endereco, CLI.COMPLEMENTO_ENTREGA Complemento, CLI.BAIRRO_ENTREGA Bairro, CLI.MUNICIPIO_ENTREGA Cidade, CLI.UF_ENTREGA UF, CLI.CEP_ENTREGA CEP, CAP.NUMERO_NOTA_FISCAL NotaFiscal, VEN.NOME NomedoConsultor
				
		from OFI_SERVICO_OS SOS
		left outer join OFI_TIPO_SERVICO TS on TS.EMPRESA = SOS.EMPRESA and TS.REVENDA = SOS.REVENDA and TS.TIPO_SERVICO = SOS.TIPO_SERVICO
		left outer join OFI_ORDEM_SERVICO OS on OS.EMPRESA = SOS.EMPRESA and OS.REVENDA = SOS.REVENDA and OS.NRO_OS = SOS.NRO_OS
		left outer join OFI_ATENDIMENTO ATE on ATE.EMPRESA = OS.EMPRESA and ATE.REVENDA = OS.REVENDA and ATE.CONTATO = OS.CONTATO
		left outer join VEI_MODELO V on ate.EMPRESA = v.empresa and ate.MODELO = v.modelo
		left outer join GER_DEPARTAMENTO DEP on DEP.EMPRESA = ATE.EMPRESA and DEP.REVENDA = ATE.REVENDA and DEP.DEPARTAMENTO = ATE.DEPARTAMENTO
		left outer join FAT_VENDEDOR VEN on VEN.EMPRESA = ATE.EMPRESA and VEN.REVENDA = ATE.REVENDA and VEN.VENDEDOR = ATE.VENDEDOR
		left outer join CAC_CONTATO CAC on CAC.EMPRESA = ATE.EMPRESA and CAC.REVENDA = ATE.REVENDA and CAC.CONTATO = ATE.CONTATO
		left outer join FAT_CLIENTE CLI on CLI.CLIENTE = CAC.CLIENTE
		left outer join OFI_SERVICO SE on SE.EMPRESA = SOS.EMPRESA and SE.SERVICO = SOS.SERVICO
		left outer join FAT_PESSOA_FISICA FIS on FIS.CLIENTE = CLI.CLIENTE
		left outer join FAT_PESSOA_JURIDICA JUR on JUR.CLIENTE = CLI.CLIENTE
		left outer join FAT_MOVIMENTO_CAPA CAP on CAP.EMPRESA = CAC.EMPRESA AND CAP.REVENDA = CAC.REVENDA AND CAP.CONTATO = CAC.CONTATO
		left outer join OFI_CATEGORIA_SERVICO CT on CT.EMPRESA = SE.EMPRESA AND CT.CATEGORIA_SERVICO = SE.CATEGORIA_SERVICO
		left outer join OFI_MECANICO MEC on MEC.EMPRESA = SOS.EMPRESA and MEC.REVENDA = SOS.REVENDA and MEC.MECANICO = SOS.MECANICO
		where SOS.EMPRESA in (1,3,4,5,11)
				
		and cap.status ='F' and cap.TOT_SERVICOS > 0.01
				
		and OS.DTA_ENCERRAMENTO between TO_DATE(TO_CHAR(SYSDATE -6,'dd/mm/yyyy'),'dd/mm/yyyy') and TO_DATE(TO_CHAR(SYSDATE,'dd/mm/yyyy'),'dd/mm/yyyy')
				
		UNION ALL
		Select case OS.EMPRESA||OS.REVENDA when '11' then '4700' when '51' then '4731'
		when '52' then '1960' when '41' then '4730' when '42' then '1936' when '111' then '4756' when '31' then '4738'
		when '33' then '1928' when '32' then '4774' else 'Nao e Diesel' end DN,
		OS.NRO_OS OS, OS.DTA_EMISSAO DatadeAbertura, OS.DTA_ENCERRAMENTO DatadeFaturamento,
		CASE TS.TIPO_SERVICO
		WHEN 'CF' THEN 'Cliente'
		WHEN 'CM' THEN 'Cliente'
		WHEN 'CP' THEN 'Cliente'
		WHEN 'CR' THEN 'Cliente'
		WHEN 'ST' THEN 'Cliente'
		WHEN 'DL' THEN 'Garantia'
		WHEN 'GF' THEN 'Garantia'
		WHEN 'GM' THEN 'Garantia'
		WHEN 'GP' THEN 'Garantia'
		WHEN 'GR' THEN 'Garantia'
		WHEN 'GO' THEN 'Interna'
		WHEN 'IA' THEN 'Interna'
		WHEN 'IP' THEN 'Interna'
		WHEN 'IU' THEN 'Interna'
		WHEN 'IVC' THEN 'Interna'
		WHEN 'IVO' THEN 'Interna'
		WHEN 'IVR' THEN 'Interna'
		WHEN 'PO' THEN 'Interna'
		WHEN 'VM' THEN 'Volkstotal'
		WHEN 'VR' THEN 'Volkstotal'
		END FONTEPAGADORA, ATE.CHASSI ChassidoVeiculo, v.des_modelo ModelodoVeiculo, v.modelo modelo,
		CASE CT.IDENTIFICACAO
		WHEN 'M' THEN 'Mecanica'
		WHEN 'V' THEN 'Revisao'
		WHEN 'F' THEN 'Funilaria'
		WHEN 'P' THEN 'Pintura'
		WHEN 'E' THEN 'Eletrica'
		WHEN 'N' THEN 'Servi�o Rapido'
		WHEN 'Z' THEN 'Funilaria'
		WHEN 'B' THEN 'Lubrificacao'
		WHEN 'O' THEN 'MECANICA'
		WHEN 'G' THEN 'Revisao'
		WHEN 'M' THEN 'Deslocamento'
		WHEN 'L' THEN 'Lavagem'
		END NaturezadoServico ,
		SE.MAODEOBRA CodigodoTPR, SOS.DESCRICAO DescricaodoServico, SOS.QUANTIDADE TempoVendido, (SOS.QUANTIDADE*SOS.VAL_SERVICO)-SOS.VAL_DESCONTO ValorFaturado,
		CASE SE.MAODEOBRA WHEN 'ST' THEN 'Nao' else 'Sim' END Oficina,
		CASE SE.MAODEOBRA WHEN 'ST' THEN 'Sim' else 'Nao' END Terceiro,
				
		CASE v.familia WHEN 5 THEN 'Onibus' ELSE 'Caminhoes' END CategoriadoVeiculo,
		CASE SE.MAODEOBRA WHEN 'DESL' THEN 'Sim' else 'Nao' END Deslocamento,
				
		CLI.NOME NomedoCliente,
				
		CASE CLI.FISJUR WHEN 'F' THEN 'Fisica' else 'Juridica' END TipodeCliente,
				
		case when FIS.CPF is null then JUR.CGC when JUR.CGC is null then TO_CHAR(FIS.CPF) else 'NULO' end CGC_CPF,
		CLI.NOME_PAIS Pais,ate.nome_contato Contato, '0'||CLI.DDD_TELEFONE||'-'||CLI.TELEFONE Telefone, '0'||CLI.DDD_CELULAR||'-'||CLI.CELULAR Celular,
		case when CLI.E_MAIL_TRABALHO is null then CLI.E_MAIL_CASA else CLI.E_MAIL_TRABALHO end Email, ATE.KILOMETRAGEM, ATE.PLACA,
				
		CASE WHEN UPPER (V.DES_MODELO) LIKE '%MAN%' THEN 'Man' else 'VW' END MontadoraVW_MAN,
				
		CLI.TIPOVIA_ENTREGA TipoVia,LOGRADOURO_ENTREGA Endereco, CLI.COMPLEMENTO_ENTREGA Complemento, CLI.BAIRRO_ENTREGA Bairro, CLI.MUNICIPIO_ENTREGA Cidade, CLI.UF_ENTREGA UF, CLI.CEP_ENTREGA CEP, CAP.NUMERO_NOTA_FISCAL NotaFiscal, VEN.NOME NomedoConsultor
				
		from OFI_SERVICO_OS SOS
		left outer join OFI_TIPO_SERVICO TS on TS.EMPRESA = SOS.EMPRESA and TS.REVENDA = SOS.REVENDA and TS.TIPO_SERVICO = SOS.TIPO_SERVICO
		left outer join OFI_ORDEM_SERVICO OS on OS.EMPRESA = SOS.EMPRESA and OS.REVENDA = SOS.REVENDA and OS.NRO_OS = SOS.NRO_OS
		left outer join OFI_ATENDIMENTO ATE on ATE.EMPRESA = OS.EMPRESA and ATE.REVENDA = OS.REVENDA and ATE.CONTATO = OS.CONTATO
		left outer join VEI_MODELO V on ate.EMPRESA = v.empresa and ate.MODELO = v.modelo
		left outer join GER_DEPARTAMENTO DEP on DEP.EMPRESA = ATE.EMPRESA and DEP.REVENDA = ATE.REVENDA and DEP.DEPARTAMENTO = ATE.DEPARTAMENTO
		left outer join FAT_VENDEDOR VEN on VEN.EMPRESA = ATE.EMPRESA and VEN.REVENDA = ATE.REVENDA and VEN.VENDEDOR = ATE.VENDEDOR
		left outer join CAC_CONTATO CAC on CAC.EMPRESA = ATE.EMPRESA and CAC.REVENDA = ATE.REVENDA and CAC.CONTATO = ATE.CONTATO
		left outer join FAT_CLIENTE CLI on CLI.CLIENTE = CAC.CLIENTE
		left outer join OFI_SERVICO SE on SE.EMPRESA = SOS.EMPRESA and SE.SERVICO = SOS.SERVICO
		left outer join FAT_PESSOA_FISICA FIS on FIS.CLIENTE = CLI.CLIENTE
		left outer join FAT_PESSOA_JURIDICA JUR on JUR.CLIENTE = CLI.CLIENTE
		left outer join FAT_MOVIMENTO_CAPA CAP on CAP.EMPRESA = CAC.EMPRESA AND CAP.REVENDA = CAC.REVENDA AND CAP.CONTATO = CAC.CONTATO
		left outer join OFI_CATEGORIA_SERVICO CT on CT.EMPRESA = SE.EMPRESA AND CT.CATEGORIA_SERVICO = SE.CATEGORIA_SERVICO
		left outer join OFI_MECANICO MEC on MEC.EMPRESA = SOS.EMPRESA and MEC.REVENDA = SOS.REVENDA and MEC.MECANICO = SOS.MECANICO
		where SOS.EMPRESA in (1,3,4,5,11)
				
		and OS.FONTE_PAGADORA_INT IN (2,3,4,5,6)
				
		and OS.DTA_ENCERRAMENTO between TO_DATE(TO_CHAR(SYSDATE -6,'dd/mm/yyyy'),'dd/mm/yyyy') and TO_DATE(TO_CHAR(SYSDATE,'dd/mm/yyyy'),'dd/mm/yyyy')");
	}
	
	public function getInvempresas(){
		return $this->Select("SELECT R.EMPRESA,R.REVENDA,R.CNPJ,R.RAZAO_SOCIAL FROM CNP.GER_REVENDA R ORDER BY R.EMPRESA,R.REVENDA");
	}
	
	public function getInventarioveiculo($empresa,$revenda,$sitop,$op){
		return $this->Select("SELECT VV.NOVO_USADO, VV.VEICULO, VV.CHASSI, VV.POSICAO_FISCAL, MO.DES_MODELO, VV.FORMULA,
		VV.VAL_CUSTO_CONTABIL, cast('' as varchar(1)) SITUACAO_PAGAR, CASE WHEN (Select COUNT(NUMERO_NOTA_FISCAL) from FAT_MOVIMENTO_CAPA
		where EMPRESA = VV.EMPRESA_NFENTRADA and REVENDA = VV.REVENDA_NFENTRADA and NUMERO_NOTA_FISCAL = VV.NUMERO_NOTA_NFENTRADA and SERIE_NOTA_FISCAL = VV.SERIE_NOTA_NFENTRADA
		and TIPO_TRANSACAO = VV.TIPO_TRANSACAO_NFENTRADA and CONTADOR = VV.CONTADOR_NFENTRADA) > 0 THEN TO_CHAR(VV.DTA_ENTRADA,'YYYY/MM/DD') ||'E'||VV.NUMERO_NOTA_NFENTRADA ELSE
		(Select MAX(TO_CHAR(MC.DTA_ENTRADA_SAIDA,'YYYY/MM/DD') ||'E'||MC.NUMERO_NOTA_FISCAL) from    FAT_MOVIMENTO_VEICULO MV,    FAT_MOVIMENTO_CAPA MC,    FAT_TIPO_TRANSACAO TT
		where    MV.EMPRESA = VV.EMPRESA and    MV.REVENDA = VV.REVENDA_ORIGEM and    MV.VEICULO = VV.VEICULO and    MC.EMPRESA = MV.EMPRESA and    MC.REVENDA = MV.REVENDA and
		MC.NUMERO_NOTA_FISCAL = MV.NUMERO_NOTA_FISCAL and    MC.SERIE_NOTA_FISCAL = MV.SERIE_NOTA_FISCAL and    MC.TIPO_TRANSACAO = MV.TIPO_TRANSACAO and    MC.CONTADOR = MV.CONTADOR
		and MC.STATUS = 'F' and    TT.TIPO_TRANSACAO = MC.TIPO_TRANSACAO and    TT.TIPO = 'E' and    TT.SUBTIPO_TRANSACAO = 'T') END DADOS,
		TO_CHAR(VV.DTA_ENTRADA,'YYYY/MM/DD')||'E'||VV.NUMERO_NOTA_NFENTRADA DADOS,'E' TIPO FROM VEI_VEICULO VV, VEI_MODELO MO
		WHERE VV.EMPRESA = MO.EMPRESA AND VV.MODELO = MO.MODELO AND VV.EMPRESA = {$empresa} AND VV.REVENDA_ORIGEM = {$revenda} AND
		VV.SITUACAO IN ({$sitop}){$op} order by VV.NOVO_USADO, VV.VEICULO, VV.CHASSI,VV.POSICAO_FISCAL");
	}
	public function getAprovacaocredito() {
		return $this->Select("select * from cnp.j_v_aprovacao_credito");
	}
	
	public function getPosicaoos($empresa) {
		$data = date("d/m/Y");
		return $this->Select("SELECT trunc(sysdate)-trunc(OS.DTA_EMISSAO) DIAS_ABERTO, OS.EMPRESA,OS.REVENDA, OS.NRO_OS, OS.DTA_EMISSAO, OS.SITUACAO_OS, OS.SITUACAO_LANCAMENTO, OS.CONTATO,
		ATENDE.VENDEDOR , (SELECT V.NOME FROM FAT_VENDEDOR V WHERE V.EMPRESA = ATENDE.EMPRESA AND V.REVENDA = ATENDE.REVENDA
		AND V.VENDEDOR = ATENDE.VENDEDOR) NOME_VENDEDOR, ATENDE.PLACA, ATENDE.MODELO, ATENDE.DEPARTAMENTO, ATENDE.CHASSI ,
		(SELECT D.NOME FROM GER_DEPARTAMENTO D WHERE D.EMPRESA = ATENDE.EMPRESA AND D.REVENDA = ATENDE.REVENDA AND
		D.DEPARTAMENTO = ATENDE.DEPARTAMENTO) NOME_DEPARTAMENTO, CLIENTE.CLIENTE, CLIENTE.NOME NOME_CLIENTE, CLIENTE.FISJUR,
		OS.CATEGORIA_OS, OS.DEPARTAMENTO_DEBITO, (SELECT D.NOME FROM GER_DEPARTAMENTO D WHERE D.EMPRESA = OS.EMPRESA AND
		D.REVENDA = OS.REVENDA AND D.DEPARTAMENTO = OS.DEPARTAMENTO_DEBITO) NOME_DEPARTAMENTO_DEBITO,
		(SELECT DES_CATEGORIA FROM OFI_CATEGORIA_OS WHERE EMPRESA = OS.EMPRESA AND REVENDA = OS.REVENDA
		AND CATEGORIA_OS = OS.CATEGORIA_OS) NOME_CATEGORIA, COALESCE((SELECT SUM(VAL_UNITARIO * QUANTIDADE - COALESCE(VAL_DESCONTO,0))
		FROM OFI_PECA_OS WHERE EMPRESA = OS.EMPRESA AND REVENDA = OS.REVENDA AND NRO_OS = OS.NRO_OS),0) VAL_TOTAL_PECAS,
		COALESCE((SELECT SUM(VAL_SERVICO * QUANTIDADE - COALESCE(VAL_DESCONTO,0)) FROM OFI_SERVICO_OS WHERE EMPRESA =
		OS.EMPRESA AND REVENDA = OS.REVENDA AND NRO_OS = OS.NRO_OS),0) VAL_TOTAL_SERVICOS,
		COALESCE((SELECT SUM(VAL_UNITARIO * QUANTIDADE - COALESCE(VAL_DESCONTO,0)) FROM OFI_PECA_OS WHERE EMPRESA = OS.EMPRESA
		AND REVENDA = OS.REVENDA AND NRO_OS = OS.NRO_OS),0) + COALESCE((SELECT SUM(VAL_SERVICO * QUANTIDADE - COALESCE(VAL_DESCONTO,0))
		FROM OFI_SERVICO_OS WHERE EMPRESA = OS.EMPRESA AND REVENDA = OS.REVENDA AND NRO_OS = OS.NRO_OS),0) VAL_TOTAL_OS,
		ATENDE.KILOMETRAGEM KILOMETRAGEM, (select max(VF.MARCA) from VEI_FAMILIA VF where VF.FAMILIA in( select VM.FAMILIA
		from VEI_MODELO VM where VM.EMPRESA = VF.EMPRESA and VM.MODELO in (select OFS.MODELO from OFI_FICHA_SEGUIMENTO OFS
		where OFS.EMPRESA = ATENDE.EMPRESA and OFS.CHASSI = ATENDE.CHASSI))) MARCA, (select OFS.DTA_VENDA from OFI_FICHA_SEGUIMENTO OFS
		where OFS.EMPRESA = ATENDE.EMPRESA and OFS.CHASSI = ATENDE.CHASSI) DTA_VENDA from OFI_ORDEM_SERVICO OS, CAC_CONTATO CONTATO,
		OFI_ATENDIMENTO ATENDE, FAT_CLIENTE CLIENTE where ATENDE.EMPRESA = OS.EMPRESA and ATENDE.REVENDA = OS.REVENDA and
		ATENDE.CONTATO = OS.CONTATO and CONTATO.EMPRESA = OS.EMPRESA and CONTATO.REVENDA = OS.REVENDA and CONTATO.CONTATO = OS.CONTATO
		and CLIENTE.CLIENTE = CONTATO.CLIENTE and OS.EMPRESA in ({$empresa}) and OS.REVENDA in
		(1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34) and OS.SITUACAO_OS in (0,1)
		and ( OS.SERVICO_EXTERNO in (1, 8) OR OS.SERVICO_INTERNO in (1, 8) OR OS.SERVICO_GARANTIA in (1, 8) OR OS.SERVICO_REVISAO
		in (1, 8)) and OS.DTA_EMISSAO between TO_DATE('03/02/1900 00:01:00','dd/mm/yyyy HH24:MI:SS')
		and TO_DATE('".$data." 23:59:00','dd/mm/yyyy HH24:MI:SS')");
	}

	public function getEstoque180() {	
		return $this->Select("select * from cnp.j_v_estoque_180_dias");
	}
	
	public function getEstoque360() {
		return $this->Select("select * from cnp.j_v_estoque_360_dias");
	}
	
	public function getVeiculoauditoria() {
		return $this->Select("SELECT VV.EMPRESA, VV.REVENDA_ORIGEM,VV.NOVO_USADO, VV.VEICULO, VV.DTA_FAT_FABRICA,VV.DTA_ENTRADA,
		VV.CHASSI, VV.POSICAO_FISCAL, VV.SITUACAO,MO.DES_MODELO, VV.FORMULA, VV.VAL_CUSTO_CONTABIL,
		cast('' as varchar(1)) SITUACAO_PAGAR, CASE WHEN (Select COUNT(NUMERO_NOTA_FISCAL) from
		FAT_MOVIMENTO_CAPA where EMPRESA = VV.EMPRESA_NFENTRADA and REVENDA = VV.REVENDA_NFENTRADA and
		NUMERO_NOTA_FISCAL = VV.NUMERO_NOTA_NFENTRADA and SERIE_NOTA_FISCAL = VV.SERIE_NOTA_NFENTRADA and
		TIPO_TRANSACAO = VV.TIPO_TRANSACAO_NFENTRADA and CONTADOR = VV.CONTADOR_NFENTRADA) > 0 THEN
		TO_CHAR(VV.DTA_ENTRADA,'YYYY/MM/DD') ||'E'||VV.NUMERO_NOTA_NFENTRADA ELSE
		(Select MAX(TO_CHAR(MC.DTA_ENTRADA_SAIDA,'YYYY/MM/DD') ||'E'||MC.NUMERO_NOTA_FISCAL) from
		FAT_MOVIMENTO_VEICULO MV, FAT_MOVIMENTO_CAPA MC, FAT_TIPO_TRANSACAO TT where
		MV.EMPRESA = VV.EMPRESA and    MV.REVENDA = VV.REVENDA_ORIGEM and MV.VEICULO = VV.VEICULO
		and MC.EMPRESA = MV.EMPRESA and MC.REVENDA = MV.REVENDA and MC.NUMERO_NOTA_FISCAL =
		MV.NUMERO_NOTA_FISCAL and  MC.SERIE_NOTA_FISCAL = MV.SERIE_NOTA_FISCAL and MC.TIPO_TRANSACAO =
		MV.TIPO_TRANSACAO and MC.CONTADOR = MV.CONTADOR and MC.STATUS = 'F' and TT.TIPO_TRANSACAO =
		MC.TIPO_TRANSACAO and TT.TIPO = 'E' and TT.SUBTIPO_TRANSACAO = 'T') END DADOS,
		TO_CHAR(VV.DTA_ENTRADA,'YYYY/MM/DD')||'E'||VV.NUMERO_NOTA_NFENTRADA DADOS, 'E' TIPO FROM
		VEI_VEICULO VV, VEI_MODELO MO WHERE VV.EMPRESA = MO.EMPRESA AND VV.MODELO = MO.MODELO AND
		VV.SITUACAO IN ('LI','SD','ST','IM','AV','BL','EF','ES') AND VV.NOVO_USADO IN ('N','U')
		order by VV.NOVO_USADO, VV.VEICULO, VV.CHASSI, VV.POSICAO_FISCAL");
	}
	
	public function getRelatoriofuncionarios() {
		$data = date( "m-Y", strtotime( "-1 month" ) );	
		return $this->Select("select cf1.unidade, cf1.empresa, cf1.contrato, cf1.nomecompleto as Funcionario,
		cf1.cargo, cf1.departamento, cf1.classificacaocontabil as CC, cf2.totalcc, cf3.salarios, cf4.totalunidade from
				
		(select cf.unidade, u.descricao40 as empresa, cf.contrato, p.nomecompleto, ca.descricao40 as cargo,
		cc.descricao40 as departamento,cf.classificacaocontabil
		from (select distinct unidade,contrato,empresa,cargo,classificacaocontabil,pessoa,situacao
		from metadados.rhcontratosfolha where to_char(datafolha, 'mm-yyyy') = to_char('".$data."')
		and situacao in(1,2))cf
		join metadados.rhunidades u on cf.unidade = u.unidade
		join metadados.rhpessoas p on cf.pessoa = p.pessoa and cf.empresa = p.empresa
		join metadados.rhclasscontabeis cc on cf.classificacaocontabil = cc.classificacaocontabil
		join metadados.rhcargos ca on cf.cargo = ca.cargo) cf1
				
		join
				
		(select cf.unidade, cf.classificacaocontabil, count(cf.classificacaocontabil) as totalcc
		from (select distinct unidade,contrato,empresa,cargo,classificacaocontabil,pessoa,situacao
		from metadados.rhcontratosfolha where to_char(datafolha, 'mm-yyyy') = to_char('".$data."')
		and situacao in(1,2)) cf
		join metadados.rhunidades u on cf.unidade = u.unidade
		join metadados.rhpessoas p on cf.pessoa = p.pessoa and cf.empresa = p.empresa
		join metadados.rhclasscontabeis cc on cf.classificacaocontabil = cc.classificacaocontabil
		join metadados.rhcargos ca on cf.cargo = ca.cargo
		group by cf.unidade, cf.classificacaocontabil) cf2 on cf2.unidade  = cf1.unidade and cf2.classificacaocontabil = cf1.classificacaocontabil
				
		join
				
		(select cf.unidade, cf.classificacaocontabil, sum(valor) as salarios
		from (select distinct unidade,contrato,empresa,cargo,classificacaocontabil,pessoa,situacao
		from metadados.rhcontratosfolha where to_char(datafolha, 'mm-yyyy') = to_char('".$data."')
		and situacao in(1,2)) cf
		join (select distinct datafolha,unidade,contrato,vdb,valor from metadados.rhvdbfolha
		where to_char(datafolha, 'mm-yyyy') = to_char('".$data."') and vdb = 491) vf
		on cf.unidade = vf.unidade and cf.contrato = vf.contrato
		group by cf.unidade, cf.classificacaocontabil) cf3 on cf3.unidade = cf2.unidade and cf3.classificacaocontabil = cf2.classificacaocontabil
				
		join
				
		(select cf.unidade, count(cf.classificacaocontabil) as totalunidade
		from (select distinct unidade,contrato,empresa,cargo,classificacaocontabil,pessoa,situacao
		from metadados.rhcontratosfolha where to_char(datafolha, 'mm-yyyy') = to_char('".$data."')
		and situacao in(1,2)) cf
		group by cf.unidade) cf4 on cf1.unidade = cf4.unidade
				
		order by
		unidade, cc, Funcionario asc");
	}
	
	public function getResumoporunidade() {
		$data = date( "m-Y", strtotime( "-1 month" ) );	
		return $this->Select("select cf1.unidade, cf1.emp as empresa,cf1.departamento,cf1.cc,cf1.totalcc,cf2.totalunidade from
		(select cf.unidade,u.descricao40 as emp,cc.descricao40 as departamento, cf.classificacaocontabil as cc, count(cf.classificacaocontabil) as totalcc
		from (select distinct unidade,contrato,empresa,cargo,classificacaocontabil,pessoa,situacao
		from metadados.rhcontratosfolha where to_char(datafolha, 'mm-yyyy') = to_char('".$data."')
		and situacao in(1,2)) cf
		join metadados.rhunidades u on cf.unidade = u.unidade
		join metadados.rhpessoas p on cf.pessoa = p.pessoa and cf.empresa = p.empresa
		join metadados.rhclasscontabeis cc on cf.classificacaocontabil = cc.classificacaocontabil
		join metadados.rhcargos ca on cf.cargo = ca.cargo
		group by cf.unidade,u.descricao40,cc.descricao40,cf.classificacaocontabil) cf1
				
		join
				
		(select cf.unidade, count(cf.classificacaocontabil) as totalunidade
		from (select distinct unidade,contrato,empresa,cargo,classificacaocontabil,pessoa,situacao
		from metadados.rhcontratosfolha where to_char(datafolha, 'mm-yyyy') = to_char('".$data."')
		and situacao in(1,2)) cf
		group by cf.unidade) cf2 on cf2.unidade = cf1.unidade
				
		order by unidade,CC");
	}
	
	public function getLancamentosbancarios(){
		return $this->Select("select t.empresa, t.revenda, t.titulo, t.duplicata, t.cliente, t.tipo, t.departamento,
        t.banco, u.nome, t.grupo, t.origem, t.dta_emissao, t.dta_vencimento, t.dta_contabil, t.historico, t.val_titulo,
        t.pagar_receber, t.status from fin_titulo t join ger_usuario u on t.usuario = u.usuario
        where t.tipo in ('BC','CX') and dta_emissao between TO_DATE(to_char(add_months(last_day(sysdate)+1,-2),'dd/mm/yyyy'),
        'dd/mm/yyyy') and TO_DATE(to_char(add_months(last_day(sysdate),-1),'dd/mm/yyyy'),'dd/mm/yyyy')");
	}
	
	public function getEstoquecritico(){
		return $this->Select("select * from cnp.j_v_estoque_critico");
	}
	
	public function getEstoqueexcesso(){
		return $this->Select("select * from cnp.j_v_estoque_excesso");
	}
	public function getVendas300(){
		return $this->Select("select * from cnp.j_v_vendas_300");
	}
	public function getVendas400(){
		return $this->Select("select * from cnp.j_v_vendas_400");
	}
	public function getCoaf(){
		return $this->Select("select s1.EMPRESA, s1.REVENDA,s1.CLIENTE, s1.NOME, s1.FISJUR, pf.identidade, pf.orgao_expedidor_id, s1.CGCCPF,
		s1.LOGRADOURO_ENTREGA, s1.CEP_ENTREGA, s1.BAIRRO_ENTREGA,s1.MUNICIPIO_ENTREGA, s1.UF_ENTREGA, s1.OPERACAO,s1.VALOR_OPERACAO, s1.TIPO,s1.CAIXA,
		s1.HISTORICO, s1.PESSOA_POLITICAMENTE_EXPOSTA, s1.ORIGEM, s1.DES_ORIGEM,s1.DTA_EMISSAO,s1.PAGAR_RECEBER
		from (select CLI.CLIENTE, CLI.NOME, CLI.FISJUR, case when CLI.FISJUR = 'F'
		then (select CPF from FAT_PESSOA_FISICA where cliente = CLI.CLIENTE)
		else (select cast(CGC as numeric(14))
		from FAT_PESSOA_JURIDICA where CLIENTE = CLI.CLIENTE) end CGCCPF,
		CLI.LOGRADOURO_ENTREGA,
		CLI.MUNICIPIO_ENTREGA, CLI.UF_ENTREGA,CLI.CEP_ENTREGA,CLI.BAIRRO_ENTREGA,
		SUM((coalesce(FIT.VAL_TITULO,0) - coalesce(FIT.VAL_DESCONTO,0)))
		VALOR_OPERACAO, FIT.OPERACAO, FIT.CAIXA, FIT.HISTORICO,CLI.PESSOA_POLITICAMENTE_EXPOSTA, FIT.ORIGEM, 
    	ORI.DES_ORIGEM,fit.DTA_EMISSAO,fit.TIPO,fit.EMPRESA,fit.REVENDA,fit.Pagar_Receber
		from FIN_TITULO FIT 
		inner join FIN_PARAMETRO FIP on (FIP.EMPRESA = FIT.EMPRESA and FIP.REVENDA = FIT.REVENDA) 
		inner join FAT_CLIENTE CLI on (CLI.CLIENTE = FIT.CLIENTE)
		inner join FIN_ORIGEM ORI on (ORI.EMPRESA = FIT.EMPRESA and ORI.REVENDA = FIT.REVENDA and ORI.ORIGEM = FIT.ORIGEM)
		where FIT.STATUS <> 'CA'
		and coalesce(FIT.TRANSACAO,0) <> coalesce(FIP.TRANS_ESTORNO_SAIDA,0) and FIT.OPERACAO
		not in (select FTP.OPERACAO from FIN_TITULO_PAGAMENTO FTP where FTP.EMPRESA = FIT.EMPRESA
		and FTP.REVENDA_PAGAMENTO = FIT.REVENDA and FTP.OPERACAO = FIT.OPERACAO and FTP.LCTO_ESTORNO
		is not null) and FIT.OPERACAO not in (select FTT.OPERACAO from FIN_TITULO FTT
		where FTT.EMPRESA = FIT.EMPRESA and FTT.OPERACAO = FIT.OPERACAO and FTT.STATUS = 'CA')
		and FIT.DTA_EMISSAO BETWEEN TO_DATE(TO_CHAR(SYSDATE -1,'dd/mm/yyyy')) and TO_DATE(TO_CHAR(SYSDATE -1,'dd/mm/yyyy'))
		and FIT.TIPO in('CX','AD') and Fit.pagar_receber = 'R' and fit.origem in (1101,7000,7026,7029,7032)
		group by CLI.CLIENTE, CLI.NOME, CLI.FISJUR, CLI.MUNICIPIO_ENTREGA, CLI.UF_ENTREGA,
		FIT.HISTORICO,CLI.PESSOA_POLITICAMENTE_EXPOSTA, FIT.OPERACAO, FIT.CAIXA, FIT.ORIGEM, 
    	ORI.DES_ORIGEM,CLI.LOGRADOURO_ENTREGA, fit.DTA_EMISSAO,fit.TIPO,fit.EMPRESA,fit.REVENDA,
    	fit.pagar_receber,CLI.CEP_ENTREGA,CLI.BAIRRO_ENTREGA
		having (SUM(coalesce(FIT.VAL_TITULO,0) - coalesce(FIT.VAL_DESCONTO,0))) >= .01) s1
		left join cnp.FAT_PESSOA_FISICA pf on (s1.cliente = pf.cliente) ");
	}
	
	public function getRmsvw(){
		return $this->Select("Select CAST('1' AS VARCHAR(1)) TIPO, OS.EMPRESA, OS.REVENDA, OS.NRO_OS, OS.DTA_EMISSAO, OS.DTA_ENCERRAMENTO, ATE.PLACA, 
	    SOS.NRO_LANCAMENTO, SE.MODELO_SERVICO, v.familia, v.des_modelo, SE.MAODEOBRA, SOS.DESCRICAO, SOS.TIPO_SERVICO, 
	    SOS.QUANTIDADE HORA_COBRADA, 
	    (Select SUM(HORA_REAL) from OFI_CDT where EMPRESA = SOS.EMPRESA and REVENDA = SOS.REVENDA and NRO_OS = SOS.NRO_OS and NRO_LANCAMENTO = 
	
	    SOS.NRO_LANCAMENTO) HORA_TRABALHADA, 
	    (SOS.VAL_DESCONTO - COALESCE(SOS.VAL_DESCONTO_FRANQUIA,0)) VAL_DESCONTO, SOS.VAL_SERVICO, round(SOS.QUANTIDADE*SOS.VAL_SERVICO,2) val_bruto,
	    round( ((SOS.QUANTIDADE*SOS.VAL_SERVICO)*( case when OS.empresa||OS.revenda in(11,32,41,51,111) then 14.25
	                                                    when OS.empresa||OS.revenda in(31,52) then 12.25 
	                                                    when OS.empresa||OS.revenda in(33) then 13.25 end ))/100,2) val_impostos,
	    round( (SOS.QUANTIDADE*SOS.VAL_SERVICO)-(((SOS.QUANTIDADE*SOS.VAL_SERVICO)*( case when OS.empresa||OS.revenda in(11,32,41,51,111) then 14.25
	                                                                                      when OS.empresa||OS.revenda in(31,52) then 12.25
	                                                                                      when OS.empresa||OS.revenda in(33) then 13.25 end ))/100),2) val_liquido
	
	    from OFI_SERVICO_OS SOS 
	    left outer join OFI_TIPO_SERVICO TS on TS.EMPRESA = SOS.EMPRESA and TS.REVENDA = SOS.REVENDA and TS.TIPO_SERVICO = SOS.TIPO_SERVICO 
	    left outer join OFI_ORDEM_SERVICO OS on OS.EMPRESA = SOS.EMPRESA and OS.REVENDA = SOS.REVENDA and OS.NRO_OS = SOS.NRO_OS 
	    left outer join OFI_ATENDIMENTO ATE on ATE.EMPRESA = OS.EMPRESA and ATE.REVENDA = OS.REVENDA and ATE.CONTATO = OS.CONTATO 
	    left outer join VEI_MODELO V on ate.EMPRESA = v.empresa and ate.MODELO = v.modelo
	    left outer join GER_DEPARTAMENTO DEP on DEP.EMPRESA = ATE.EMPRESA and DEP.REVENDA = ATE.REVENDA and DEP.DEPARTAMENTO = ATE.DEPARTAMENTO 
	    left outer join FAT_VENDEDOR VEN on VEN.EMPRESA = ATE.EMPRESA and VEN.REVENDA = ATE.REVENDA and VEN.VENDEDOR = ATE.VENDEDOR 
	    left outer join CAC_CONTATO CAC on CAC.EMPRESA = ATE.EMPRESA and CAC.REVENDA = ATE.REVENDA and CAC.CONTATO = ATE.CONTATO 
	    left outer join FAT_CLIENTE CLI on CLI.CLIENTE = CAC.CLIENTE 
	    left outer join OFI_SERVICO SE on SE.EMPRESA = SOS.EMPRESA and SE.SERVICO = SOS.SERVICO 
	    left outer join OFI_MECANICO MEC on MEC.EMPRESA = SOS.EMPRESA and MEC.REVENDA = SOS.REVENDA and MEC.MECANICO = SOS.MECANICO where SOS.EMPRESA in (1,3,4,5,11) AND 
	
	    sos.REVENDA in (1,2,3) 
	
	    and OS.DTA_ENCERRAMENTO between trunc(last_day(add_months(sysdate,-2))+1) and trunc(last_day(add_months(sysdate,-1))) and SOS.SITUACAO = 'N' and ATE.DEPARTAMENTO = 400 
	    
	    order by 2, 3, 6, 4");
	}
	
	public function getDescontomotos(){
		return $this->Select("select * from cnp.j_v_venda_motos_oper_desc_emp v1 where empresa = 2");
	}
	
	public function getSincronizasav(){
		return $this->Select("SELECT PRO.EMPRESA SAV_EMPRESA, PRO.PROPOSTA SAV_PROPOSTA, US.NOME NOME_GERENTE, US.CPF CPF_GERENTE, 
		C.CONTATO,  V.NUMERO_NOTA_NFENTRADA AS NF_ENTRADA, V.NUMERO_NOTA_NFSAIDA AS NF_SAIDA, V.NUMERO_NOTA_VENDA_DIRETA AS NF_DIRETA,P.EMPRESA, 
		P.REVENDA, P.PROPOSTA, P.VENDEDOR, F.TIPO_RENAVAM, F.ESPECIE_RENAVAM, P.VEICULO, P.DTA_EMISSAO, P.SITUACAO, P.TIPO_VENDA, 
		N.NEGOCIACAO, L.CLIENTE, L.NOME, V.NOVO_USADO, L.FISJUR, (case when ((L.fisjur = 'F') or (L.fisjur = 'O')) then (select max(cast(FPJ.CPF as varchar(14))) 
		from FAT_PESSOA_FISICA FPJ where FPJ.cliente = L.CLIENTE) else (select max(FPJ.CGC) from FAT_PESSOA_JURIDICA FPJ 
		where FPJ.cliente = L.CLIENTE) end) CPFCNPJ, E.NOME NOME_VENDEDOR, E.CPF CPF_VENDEDOR, F.CHASSI, F.PLACA, V.VAL_CUSTO_CONTABIL , 
		CAST(P.DTA_EMISSAO AS DATE) DTA_EMISSAO, COALESCE ((SELECT MAX(FMC.DTA_ENTRADA_SAIDA) FROM FAT_MOVIMENTO_CAPA FMC 
		WHERE FMC.EMPRESA = P.EMPRESA AND FMC.REVENDA = P.REVENDA AND FMC.CONTATO = P.CONTATO), V.Dta_Venda) DTA_VENDA, 
		CASE WHEN P.VEICULO IS NULL OR P.VEICULO = '' THEN (SELECT M.DES_MODELO FROM VEI_MODELO M, VEI_PROPOSTA_VEICULO R 
		WHERE R.EMPRESA = M.EMPRESA AND R.MODELO = M.MODELO AND R.EMPRESA = P.EMPRESA AND R.REVENDA = P.REVENDA AND 
		R.PROPOSTA = P.PROPOSTA) ELSE (SELECT M.DES_MODELO FROM VEI_MODELO M, VEI_VEICULO V WHERE V.EMPRESA = M.EMPRESA 
		AND V.MODELO = M.MODELO AND V.EMPRESA = P.EMPRESA AND V.VEICULO = P.VEICULO) END DES_MODELO, CASE WHEN P.VEICULO IS NULL 
		OR P.VEICULO = '' THEN (SELECT VF.DES_FAMILIA FROM VEI_MODELO M, VEI_FAMILIA VF, VEI_PROPOSTA_VEICULO R WHERE 
		R.EMPRESA = M.EMPRESA AND R.MODELO = M.MODELO AND R.EMPRESA = P.EMPRESA AND R.REVENDA = P.REVENDA AND 
		R.PROPOSTA = P.PROPOSTA and M.EMPRESA = VF.EMPRESA AND M.FAMILIA = VF.FAMILIA) ELSE (SELECT VF.DES_FAMILIA 
		FROM VEI_MODELO M, VEI_FAMILIA VF, VEI_VEICULO V WHERE V.EMPRESA = M.EMPRESA AND V.MODELO = M.MODELO AND 
		V.EMPRESA = P.EMPRESA AND V.VEICULO = P.VEICULO and M.EMPRESA = VF.EMPRESA AND M.FAMILIA = VF.FAMILIA) END DES_FAMILIA, 
		CASE P.SITUACAO WHEN '0' THEN 'Aberta' WHEN '1' THEN 'Pendente' WHEN '2' THEN 'Aprovada(Ger)' WHEN '5' 
		THEN 'Aprovada(Fin)' WHEN '7' THEN 'NF Emitida' WHEN '8' THEN 'Cancelada' WHEN '9' THEN 'Encerrada' 
		END DES_SITUACAO, (SELECT LOGIN FROM GER_USUARIO WHERE USUARIO = N.USU_GERENCIAL) USU_GERENCIAL, 
		CAST(N.DTA_APR_GERENCIAL AS DATE) DTA_APR_GERENCIAL, CAST(N.DTA_APR_FINANCEIRA AS DATE) DTA_APR_FINANCEIRA, 
		CASE WHEN P.SITUACAO = '8' THEN (SELECT CAST(P1.DTA_PROVIDENCIA AS DATE) FROM CAC_PROVIDENCIA P1 WHERE 
		P1.EMPRESA = C.EMPRESA AND P1.REVENDA = C.REVENDA AND P1.CONTATO = C.CONTATO AND 
		P1.PROVIDENCIA = (SELECT MAX(P2.PROVIDENCIA) FROM CAC_PROVIDENCIA P2 WHERE P2.EMPRESA = P1.EMPRESA 
		AND P2.REVENDA = P1.REVENDA AND P2.CONTATO = P1.CONTATO)) END DTA_CANCELAMENTO, CASE WHEN P.SITUACAO = '8' 
		THEN (SELECT U1.LOGIN FROM CAC_PROVIDENCIA P1, GER_USUARIO U1 WHERE P1.USUARIO = U1.USUARIO AND 
		P1.EMPRESA = C.EMPRESA AND P1.REVENDA = C.REVENDA AND P1.CONTATO = C.CONTATO AND 
		P1.PROVIDENCIA = (SELECT MAX(P2.PROVIDENCIA) FROM CAC_PROVIDENCIA P2 WHERE P2.EMPRESA = P1.EMPRESA AND 
		P2.REVENDA = P1.REVENDA AND P2.CONTATO = P1.CONTATO)) END USU_CANCELAMENTO, CASE WHEN P.NEGOCIACAO_FINAL IS NULL 
		THEN (SELECT SUM(VAL_PAGAMENTO) FROM VEI_PAGAMENTO WHERE EMPRESA = P.EMPRESA AND REVENDA = P.REVENDA AND 
		PROPOSTA = P.PROPOSTA AND NEGOCIACAO = 1) ELSE (SELECT SUM(VAL_PAGAMENTO) FROM VEI_PAGAMENTO WHERE 
		EMPRESA = P.EMPRESA AND REVENDA = P.REVENDA AND PROPOSTA = P.PROPOSTA AND NEGOCIACAO = P.NEGOCIACAO_FINAL) 
		END PAGAMENTOS, COALESCE((SELECT DES_COR FROM VEI_COR WHERE EMPRESA = V.EMPRESA AND COR = V.COR) , 
		( select v.des_cor from vei_proposta_veiculo pr, vei_cor v where pr.empresa=P.EMPRESA and pr.revenda=P.REVENDA 
		and pr.proposta=P.PROPOSTA and v.empresa = pr.empresa and v.cor = pr.cor) ) DES_COR, S.DES_SEGMENTO, V.OPCIONAIS 
		FROM SAV_PROPOSTA PRO INNER JOIN SAV_EMPRESA EM ON PRO.EMPRESA = EM.EMPRESA INNER JOIN SIS_USUARIO US ON PRO.GERENTE = US.USUARIO 
		INNER JOIN VEI_PROPOSTA P ON (EM.EMPRESA_APOLLO = P.EMPRESA AND EM.REVENDA_APOLLO = P.REVENDA AND PRO.PROPOSTA_APOLLO = P.PROPOSTA) 
		INNER JOIN CAC_CONTATO C ON (P.EMPRESA = C.EMPRESA AND P.REVENDA = C.REVENDA AND P.CONTATO = C.CONTATO) 
		INNER JOIN FAT_VENDEDOR E ON (P.EMPRESA = E.EMPRESA AND P.REVENDA = E.REVENDA AND P.VENDEDOR = E.VENDEDOR) 
		INNER JOIN FAT_CLIENTE L ON (C.CLIENTE = L.CLIENTE) LEFT OUTER JOIN VEI_VEICULO V ON (P.EMPRESA_VEICULO = V.EMPRESA) 
		AND(P.VEICULO = V.VEICULO) LEFT OUTER JOIN OFI_FICHA_SEGUIMENTO F ON (V.CHASSI = F.CHASSI) LEFT OUTER 
		JOIN VEI_NEGOCIACAO N ON (P.EMPRESA = N.EMPRESA AND P.REVENDA = N.REVENDA AND P.PROPOSTA = N.PROPOSTA 
		AND P.NEGOCIACAO_FINAL = N.NEGOCIACAO) LEFT OUTER JOIN FAT_SEGMENTO S ON (S.SEGMENTO = P.SEGMENTO_VD) 
		WHERE PRO.SITUACAO NOT IN (7,9) AND PRO.SITUACAO <> P.SITUACAO ORDER BY PRO.EMPRESA, PRO.PROPOSTA");
	}
	public function getTransf(){
		return $this->Select("select T.EMPRESA,T.REVENDA,v.veiculo, l.chassi, l.situacao,m.des_modelo,T.NUMERO_NOTA_FISCAL,T.SERIE_NOTA_FISCAL,T.TIPO_TRANSACAO,
		T.DTA_DOCUMENTO,T.STATUS,T.CLIENTE,c.nome Revenda_Destino, c.municipio_entrega Municipio_Destino,T.USUARIO,T.TOT_MERCADORIA,T.TOT_NOTA_FISCAL
		from FAT_MOVIMENTO_CAPA t
		JOIN FAT_MOVIMENTO_VEICULO V ON (T.EMPRESA = V.EMPRESA and t.revenda = v.revenda and t.numero_nota_fiscal = v.numero_nota_fiscal and t.serie_nota_fiscal = v.serie_nota_fiscal and t.tipo_transacao = v.tipo_transacao)
		JOIN VEI_VEICULO L on (v.empresa = l.empresa and v.veiculo = l.veiculo)
		join vei_modelo m on (l.empresa = m.empresa and l.modelo = m.modelo)
		JOIN FAT_CLIENTE C on (t.cliente = c.cliente)
		where t.tipo_transacao = 'M22' AND t.STATUS ='F' and l.situacao = 'TF'
		AND v.veiculo||'-'||T.DTA_DOCUMENTO IN (
        SELECT S1.VEICULO||'-'||MAX(S1.DTA_DOCUMENTO) DTA_DOCUMENTO
        FROM
        	(
             	select T.EMPRESA,T.REVENDA,v.veiculo, l.chassi, l.situacao,m.des_modelo,T.NUMERO_NOTA_FISCAL,T.SERIE_NOTA_FISCAL,T.TIPO_TRANSACAO,
                T.DTA_DOCUMENTO,T.STATUS,T.CLIENTE,c.nome Revenda_Destino, c.municipio_entrega Municipio_Destino,T.USUARIO,T.TOT_MERCADORIA,T.TOT_NOTA_FISCAL
                from FAT_MOVIMENTO_CAPA t
               	JOIN FAT_MOVIMENTO_VEICULO V ON (T.EMPRESA = V.EMPRESA and t.revenda = v.revenda and t.numero_nota_fiscal = v.numero_nota_fiscal and t.serie_nota_fiscal = v.serie_nota_fiscal and t.tipo_transacao = v.tipo_transacao)
                JOIN VEI_VEICULO L on (v.empresa = l.empresa and v.veiculo = l.veiculo)
                join vei_modelo m on (l.empresa = m.empresa and l.modelo = m.modelo)
                JOIN FAT_CLIENTE C on (t.cliente = c.cliente)
                where t.tipo_transacao = 'M22' AND t.STATUS ='F' and l.situacao = 'TF'
              ) S1
         GROUP BY S1.VEICULO)");
	}
	
	public function getVisitaFiat(){
		return $this->Select("select 
									case 
									      when substr(v.endereco,-4) = 'fiat' then 'Google'
									      when substr(v.endereco,-4) = 'book' then 'Facebook'
									      else 'N�o Definido' end origem, 
									case 
									       when v.forma_interacao = 'T' then 'Telefone'
									       when v.forma_interacao = 'F' then 'Formul�rio'
									       when v.forma_interacao = 'W' then 'Whatsapp'
									       else 'N�o Informado' end tipo,
									count(forma_interacao) qtd from sis_visita v
									where to_date(v.data, 'dd/mm/yyyy') between trunc(sysdate) and trunc(sysdate)
									group by v.endereco, v.forma_interacao order by v.endereco");
	}
	
	public function getSaldobanco(){
		return $this->Select("select c1.empresa, c1.revenda, SUM(COALESCE(VAL_SALDO,0)) VAL_SALDO, 
	    max(DTA_SALDO) dta_referencia 
	    from FIN_SALDO_CAIXA C1 
	    where DTA_SALDO = (SELECT MAX(C2.DTA_SALDO) FROM FIN_SALDO_CAIXA C2 where C2.EMPRESA = C1.EMPRESA and C2.REVENDA = C1.REVENDA 
	    and C2.CAIXA = C1.CAIXA and C2.DTA_SALDO <= trunc(sysdate-1))
	    group by c1.empresa, c1.revenda order by 1,2");
	}
	
	public function getSincronizafinan($categoria,$situacao){
		if ($categoria == 'R'){
			if ($situacao == 6){
				return $this->Select("select a.adiantamento, a.categoria, t.cliente, t.titulo, t.duplicata, t.tipo,
	        	a.dta_fim, t.dta_emissao, t.dta_vencimento, t.dta_contabil,t.val_titulo,t.status,t.empresa, t.revenda
	  			from finan_adiantamento a
	  			join sis_empresa e on a.empresa = e.empresa
	  			join ger_revenda r on r.cnpj = e.cnpj
	  			join fin_titulo t on t.empresa = r.empresa and t.dta_emissao >= to_date(a.dta_fim, 'dd/mm/yyyy')
	  			where a.categoria = 'R' and a.situacao = 5 and t.cliente = a.cliente_apollo
	  			and t.titulo = a.titulo_apollo and t.tipo = 'AD' and trunc(t.duplicata) = trunc(a.duplicata_apollo) and t.status = 'PT' ");
			}else{
				return $this->Select("select a.adiantamento, a.categoria, t.cliente, t.titulo, t.duplicata, t.tipo,
	        	a.dta_fim, t.dta_emissao, t.dta_vencimento, t.dta_contabil,t.val_titulo,t.status,t.empresa, t.revenda,
				p.dir_pasta_adiantamento, a.anexos
	  			from finan_adiantamento a
	  			join sis_empresa e on a.empresa = e.empresa
	  			join ger_revenda r on r.cnpj = e.cnpj
	  			join fin_titulo t on t.empresa = r.empresa and t.dta_emissao >= to_date(a.dta_fim, 'dd/mm/yyyy')
				join fin_parametro p on t.empresa = p.empresa and t.revenda = p.revenda
	  			where a.categoria = 'R' and a.situacao = 5 and t.cliente = a.cliente_apollo
	  			and t.titulo = a.titulo_apollo and t.tipo = 'AD' and trunc(t.duplicata) = trunc(a.duplicata_apollo) and t.status = 'CA' ");
			}	
		}else{
			if ($situacao == 6){
				return $this->Select("select ad.adiantamento, ad.dir_pasta_adiantamento, count(0) from
				(select ad.adiantamento, ad.cliente, ad.dir_pasta_adiantamento, ad.situacao, count(0) from
				(select a.adiantamento, a.categoria, t.cliente,case when
				t.status = 'PT' then 6
				when t.status = 'CA' then 7 else 5 end situacao, p.dir_pasta_adiantamento
				from finan_adiantamento a
				join sis_empresa e on a.empresa = e.empresa
				join ger_revenda r on r.cnpj = e.cnpj
				join fin_titulo t on t.empresa = r.empresa and t.dta_emissao >= to_date(a.dta_fim, 'dd/mm/yyyy')
				join fin_parametro p on t.empresa = p.empresa and t.revenda = p.revenda
				where a.categoria = 'A' and a.situacao = 5 and t.cliente = a.cliente_apollo and
				((t.titulo = a.titulo_apollo and t.tipo = 'AD' and trunc(t.duplicata) = trunc(a.duplicata_apollo) and t.status = 'PT')
				or(t.titulo = a.ad_apollo and t.tipo = 'AD' and trunc(t.duplicata) = trunc(a.ad_duplicata) and t.status = 'PT')
				or(t.titulo = a.cp_apollo and t.tipo = 'CP' and trunc(t.duplicata) = trunc(a.cp_duplicata) and t.status = 'PT'))) ad where ad.situacao in (5,{$situacao}) group by ad.adiantamento, ad.cliente, ad.situacao, ad.dir_pasta_adiantamento) ad group by adiantamento, dir_pasta_adiantamento
				having count(0) < 2");
			}else{
				return $this->Select("select a.adiantamento, a.categoria, t.cliente, t.titulo, t.duplicata, t.tipo,
	        	a.dta_fim, t.dta_emissao, t.dta_vencimento, t.dta_contabil,t.val_titulo,t.status,t.empresa, t.revenda,
				p.dir_pasta_adiantamento, a.anexos, aa.situacao situacao_autorizacao
	  			from finan_adiantamento a
	  			join sis_empresa e on a.empresa = e.empresa
	  			join ger_revenda r on r.cnpj = e.cnpj
	  			join fin_titulo t on t.empresa = r.empresa and t.dta_emissao >= to_date(a.dta_fim, 'dd/mm/yyyy')
				join fin_parametro p on t.empresa = p.empresa and t.revenda = p.revenda
				LEFT JOIN (select adiantamento,max(to_date(dta_solicitacao,'dd/mm/yyyy hh24:mi:ss'))  dta_solicitacao
				from finan_adiantamento_autorizacao group by adiantamento ) aaa on a.adiantamento = aaa.adiantamento 
				LEFT JOIN finan_adiantamento_autorizacao aa on aaa.adiantamento = aa.adiantamento and aaa.dta_solicitacao = to_date(aa.dta_solicitacao,'dd/mm/yyyy hh24:mi:ss')
	  			where a.categoria = 'A' and a.situacao = 5 and t.cliente = a.cliente_apollo
	  			and t.titulo = a.titulo_apollo and t.tipo = 'AD' and trunc(t.duplicata) = trunc(a.duplicata_apollo) and t.status = 'CA' ");
			}
			
		}
	}
	public function getMotosfidc(){
		return $this->Select("select x1.*,
						        case 
						
						             when x1.situacao = 'ES' and x1.dta_emissao_proposta is not null then x1.dta_vencimento_fiscal   
						             when x1.situacao = 'ES' and x1.dta_vencimento_fiscal is not null and x1.dta_emissao_proposta is not null and x1.dta_emissao_proposta >= x1.dta_vencimento_fiscal then x1.dta_emissao_proposta+5 
						             when x1.situacao = 'ES' and x1.dta_emissao_proposta is null then x1.dta_vencimento_fiscal 
						             when x1.situacao = 'ES' and x1.dta_emissao_proposta is null then x1.dta_vencimento_fiscal                   
						            end dta_prov_pagamento,
						         case 
						               when x1.situacao = 'ES' and x1.dta_vencimento_fiscal < trunc(sysdate) then x1.dta_vencimento_fiscal+30 
						               when x1.situacao = 'ES' and x1.dta_emissao_proposta is not null and x1.dta_emissao_proposta > x1.dta_vencimento_fiscal then x1.dta_emissao_proposta+5
						            end pag_fidc
						      from 
						      (        
						            select g1.*, g2.dta_emissao_proposta
						            from
						            (
						                select f1.*, f2.dta_vencimento_fiscal
						                from 
						                (        
						                    select v.empresa, v.revenda_origem, v.veiculo, v.chassi, v.situacao, v.modelo, v.dta_fat_fabrica
						                    from (select sv.* from cnp.vei_veiculo sv   
						                          where sv.situacao = 'TM' and sv.novo_usado = 'N') v
						                      
						                    union all
						                     
						                    select v.empresa, v.revenda_origem, v.veiculo, v.chassi, v.situacao, v.modelo, v.dta_fat_fabrica
						                    from (select sv.* from cnp.vei_veiculo sv   
						                          where sv.situacao = 'ES' and sv.novo_usado = 'N') v
						                ) f1     
						                join
						                ( 
						                  select ti.empresa, ti.revenda, mv.veiculo, ti.dta_vencimento dta_vencimento_fiscal
						                  from cnp.fin_titulo ti 
						                  join cnp.fat_movimento_capa ca on (ti.empresa = ca.empresa and ti.revenda = ca.revenda and ti.operacao = ca.operacao)
						                  join cnp.fat_movimento_veiculo mv on (ca.EMPRESA = mv.empresa and ca.REVENDA = mv.revenda and ca.NUMERO_NOTA_FISCAL = mv.numero_nota_fiscal 
						                                                        and ca.SERIE_NOTA_FISCAL = mv.serie_nota_fiscal and ca.TIPO_TRANSACAO = mv.tipo_transacao and ca.CONTADOR = mv.contador)  
						                  where ti.status in ('EM') and
						                  ti.origem in (1298) -- 1310 
						                ) f2 on (f1.empresa = f2.empresa and f1.veiculo = f2.veiculo)
						            ) g1
						            left join 
						            (
						            select empresa, veiculo, min(dta_emissao) dta_emissao_proposta
						             from cnp.vei_proposta 
						             group by empresa, veiculo
						            ) g2 on g1.empresa = g2.empresa and g1.veiculo = g2.veiculo
						      ) x1 where empresa in (2,7,9) 
						     union
						     select x1.*,
						        case 
						               when x1.situacao = 'TM' and x1.empresa = 2 and x1.revenda_origem <> 2 then x1.dta_fat_fabrica+8              
						               when x1.situacao = 'TM' and x1.empresa = 2 and x1.revenda_origem = 2 then x1.dta_fat_fabrica+9
						               when x1.situacao = 'TM' and x1.empresa = 7 and x1.revenda_origem not in (2,3) then x1.dta_fat_fabrica+16
						               when x1.situacao = 'TM' and x1.empresa = 7 and x1.revenda_origem = 2 then x1.dta_fat_fabrica+18
						               when x1.situacao = 'TM' and x1.empresa = 7 and x1.revenda_origem = 3 then x1.dta_fat_fabrica+19
						               when x1.situacao = 'TM' and x1.empresa = 9 then x1.dta_fat_fabrica+16                 
						            end dta_prov_pagamento,
						       null pag_fidc
						      from 
						      (        
						            select g1.*, g2.dta_emissao_proposta
						            from
						            (
						                select f1.*, null dta_vencimento_fiscal
						                from 
						                (        
						                    select v.empresa, v.revenda_origem, v.veiculo, v.chassi, v.situacao, v.modelo, v.dta_fat_fabrica
						                    from (select sv.* from cnp.vei_veiculo sv   
						                          where sv.situacao = 'TM' and sv.novo_usado = 'N') v
						                ) f1     
						            ) g1
						            left join 
						            (
						             select empresa, veiculo, min(dta_emissao) dta_emissao_proposta
						             from cnp.vei_proposta 
						             group by empresa, veiculo
						            ) g2 on g1.empresa = g2.empresa and g1.veiculo = g2.veiculo
						      ) x1 where empresa in (2,7,9) 
						      order by 1,2
						");
	}
	
	public function getCremaberto(){
		return $this->Select("select t.empresa, t.revenda, t.cliente, y.nome, t.origem, g.des_origem, t.tipo, t.titulo, t.duplicata, t.status, T.DTA_EMISSAO, T.DTA_CONTABIL ,T.DTA_VENCIMENTO, T.PAGAR_RECEBER, t.departamento,
	    t.val_titulo, nvl(ftp.valor_pago,0) valor_pago, t.val_titulo-nvl(ftp.valor_pago,0) saldo
	    from cnp.fin_titulo t
	    left join
	    (
	       select ftp2.empresa, ftp2.revenda, ftp2.titulo, ftp2.duplicata, ftp2.cliente, ftp2.Tipo, nvl(sum(ftp2.val_pagamento)-s1.val_devolucao,sum(ftp2.val_pagamento)) valor_pago
	       from fin_titulo_pagamento ftp2
	       left join
	       (select fch.empresa, fch.revenda, fch.titulo, fch.duplicata, fch.cliente, fch.tipo, sum(fch.val_devolucao) val_devolucao
	       from fin_devolucao_cheque fch
	       group by fch.empresa, fch.revenda, fch.titulo, fch.duplicata, fch.cliente, fch.tipo) s1
	       on (ftp2.EMPRESA = s1.EMPRESA and ftp2.REVENDA = s1.REVENDA and ftp2.TITULO = s1.TITULO and ftp2.DUPLICATA = s1.DUPLICATA and ftp2.CLIENTE = s1.CLIENTE and ftp2.TIPO = s1.TIPO)
	       group by ftp2.empresa, ftp2.revenda, ftp2.titulo, ftp2.duplicata, ftp2.cliente, ftp2.Tipo, s1.val_devolucao
	    ) ftp
	    on (t.EMPRESA = ftp.EMPRESA and t.REVENDA = ftp.REVENDA and t.TITULO = ftp.TITULO and t.DUPLICATA = ftp.DUPLICATA and t.CLIENTE = ftp.CLIENTE and t.TIPO = ftp.TIPO)
	    join fat_cliente y on (t.cliente = y.cliente)
	    left JOIN FIN_ORIGEM G on(t.empresa = g.empresa and t.revenda = g.revenda and t.origem = g.origem)
	    where t.empresa in (1,2,3,4,5,7,9,11,13) and t.status IN ('EM','PP')
	    and t.DTA_VENCIMENTO <= TO_DATE('30/10/2030','dd/mm/yyyy') and
	    t.tipo in ('CR','CT','CH')
	    order by t.empresa, t.revenda, t.titulo, t.tipo, T.DTA_VENCIMENTO");
	}
	
	public function getCpemaberto(){
		return $this->Select("select t.empresa, t.revenda, t.cliente, y.nome, t.origem, g.des_origem, t.tipo, t.titulo, t.duplicata, t.status, T.DTA_EMISSAO, T.DTA_CONTABIL ,T.DTA_VENCIMENTO, T.PAGAR_RECEBER, t.departamento,
	    t.val_titulo, nvl(ftp.valor_pago,0) valor_pago, t.val_titulo-nvl(ftp.valor_pago,0) saldo
	    from cnp.fin_titulo t
	    left join
	    (
	       select ftp2.empresa, ftp2.revenda, ftp2.titulo, ftp2.duplicata, ftp2.cliente, ftp2.Tipo, nvl(sum(ftp2.val_pagamento)-s1.val_devolucao,sum(ftp2.val_pagamento)) valor_pago
	       from fin_titulo_pagamento ftp2
	       left join
	       (select fch.empresa, fch.revenda, fch.titulo, fch.duplicata, fch.cliente, fch.tipo, sum(fch.val_devolucao) val_devolucao
	       from fin_devolucao_cheque fch
	       group by fch.empresa, fch.revenda, fch.titulo, fch.duplicata, fch.cliente, fch.tipo) s1
	       on (ftp2.EMPRESA = s1.EMPRESA and ftp2.REVENDA = s1.REVENDA and ftp2.TITULO = s1.TITULO and ftp2.DUPLICATA = s1.DUPLICATA and ftp2.CLIENTE = s1.CLIENTE and ftp2.TIPO = s1.TIPO)
	       group by ftp2.empresa, ftp2.revenda, ftp2.titulo, ftp2.duplicata, ftp2.cliente, ftp2.Tipo, s1.val_devolucao
	    ) ftp
	    on (t.EMPRESA = ftp.EMPRESA and t.REVENDA = ftp.REVENDA and t.TITULO = ftp.TITULO and t.DUPLICATA = ftp.DUPLICATA and t.CLIENTE = ftp.CLIENTE and t.TIPO = ftp.TIPO)
	    join fat_cliente y on (t.cliente = y.cliente)
	    left JOIN FIN_ORIGEM G on(t.empresa = g.empresa and t.revenda = g.revenda and t.origem = g.origem)
	    where t.empresa in (1,2,3,4,5,7,9,11,13) and t.status IN ('EM','PP')
	    and t.DTA_VENCIMENTO <= TO_DATE('30/10/2030','dd/mm/yyyy') and
	    t.tipo in ('CP')
	    order by t.empresa, t.revenda, t.titulo, t.tipo, T.DTA_VENCIMENTO");
	}
	
	public function getComprasobsoleto(){
		return $this->Select("select b.empresa, b.revenda, b.numero_nota_fiscal, b.serie_nota_fiscal, b.tipo_transacao, b.class_abc, b.item_estoque, b.item_estoque_pub,
		b.dta_entrada, b.dta_ultima_saida, b.des_item_estoque 
		from cnp.j_tab_envio_venda_ob  b
		WHERE TO_DATE(DTA_ENTRADA,'dd/mm/yyyy') = trunc(sysdate-1)
		ORDER BY DTA_ENTRADA");
	}
	
	public function titulosGarantia(){
		return $this->Select("select ss1.empresa, ss1.revenda, ss1.titulo, ss1.duplicata, ss1.dta_emissao, ss1.dta_vencimento, ss1.status,  
   ss1.val_titulo, ss1.pagamento, ss1.saldo, ss1.dta_pagamento, ss1.tipo_os, ss2.tipo_servico, ss1.N_OS, ss1.ORIGEM, ss1.DES_ORIGEM, to_char(ss2.dta_emissao_os,'dd/mm/yyyy') dta_emissao_os, ss1.dta_transmissao_garantia, ss1.dta_transmissao_os dta_transmissao_revisao, ss2.situacao_os
   from
   (
       select s1.empresa, s1.revenda, s1.titulo, s1.duplicata, s1.cliente, s1.tipo, s1.dta_emissao, s1.dta_vencimento, s1.status,
       s1.usuario, s1.nome_usuario, s1.dta_operacao, s1.dta_pagamento, s1.os_garantia_revisao, s1.tipo_os, s1.N_OS, s1.nfse, s1.rps,    
       s1.val_titulo, nvl(s2.pagamento,0) pagamento, s1.val_titulo-nvl(s2.pagamento,0) saldo, sc.dta_reparo dta_reparo_garantia, sc.dta_transmissao dta_transmissao_garantia, vcr.dta_transmissao dta_transmissao_os  
       ,s1.ORIGEM, s1.DES_ORIGEM
       from
       (
           select ft.empresa, FT.REVENDA, FT.TITULO, FT.DUPLICATA, FT.CLIENTE, FT.TIPO, FT.TIPO_COBRANCA, FT.AUTORIZACAO, FT.CAIXA, 
           FT.DTA_EMISSAO, FT.DTA_VENCIMENTO, FT.DTA_CONTABIL, FT.VAL_TITULO, FT.STATUS, FT.ENVIADO, FT.INDICE, FT.TIPO_INDICE, FT.ORIGEM, FO.DES_ORIGEM,FT.USUARIO, USU.NOME NOME_USUARIO, FC.NOME, FC.CATEGORIA , FC.TELEFONE, 
           FC.DDD_TELEFONE ,FT.BANCO, FB.DES_BANCO, FT.DEPARTAMENTO, GD.NOME NOME_DEPARTAMENTO, GO.DTA_OPERACAO, FT.NOSSONUMERO, 
           CASE WHEN (COALESCE(FC.ENDERECO_MALA, 1) = 1) THEN FC.LOGRADOURO_ENTREGA ELSE FC.LOGRADOURO_COBRANCA END ENDERECO, CASE WHEN (COALESCE(FC.ENDERECO_MALA, 1) = 1) THEN FC.BAIRRO_ENTREGA ELSE FC.BAIRRO_COBRANCA END BAIRRO, 
           CASE WHEN (COALESCE(FC.ENDERECO_MALA, 1) = 1) THEN FC.COMPLEMENTO_ENTREGA ELSE FC.COMPLEMENTO_COBRANCA END COMPLEMENTO, 
           CASE WHEN (COALESCE(FC.ENDERECO_MALA, 1) = 1) THEN FC.MUNICIPIO_ENTREGA ELSE FC.MUNICIPIO_COBRANCA END CIDADE, CASE WHEN (COALESCE(FC.ENDERECO_MALA, 1) = 1) THEN FC.UF_ENTREGA ELSE FC.UF_COBRANCA END UF, CASE WHEN (COALESCE(FC.ENDERECO_MALA, 1) = 1) THEN FC.CEP_ENTREGA ELSE FC.CEP_COBRANCA END CEP, CAST(0 AS NUMERIC(13,2)) PAGAMENTO, CAST(0 AS NUMERIC(13,2)) VAL_PAGO, 
           SUM (FT.VAL_OUTRAS_DESPESAS) MULTA, SUM (FT.VAL_DESCONTO) VAL_DESCONTO, SUM (FT.VAL_JUROS_MORA) VAL_JUROS_MORA, SUM (coalesce(FT.VAL_DESCONTO,0) ) DESCONTO, SUM (coalesce(FT.VAL_JUROS_MORA,0) ) ACRESCIMO, SUM (FT.VAL_BONUS ) BONUS, SUM (FT.VAL_FLOOR_PLAN) FLOOR_PLAN , SUM (FT.VAL_HOLD_BACK ) HOLD_BACK, SUM (FT.VAL_CONTRIBUICAO)CONTRIBUICAO, CAST(0 AS NUMERIC(13,2)) DEVOLUCAO, 
           CAST(0 AS NUMERIC(13,2)) DEVOLUCAO_CH, MAX(FTP.DTA_PAGAMENTO) DTA_PAGAMENTO , MAX(FTD.DTA_DEVOLUCAO) DTA_DEVOLUCAO , MAX(FDC.DTA_DEVOLUCAO) DTA_DEVOLUCAO_CH, FT.NUMERO_LOTE_CARTAO , FT.RG_GARANTIA, FT.OPERACAO, FT.HISTORICO, 
           MIN((Select MIN(FM.NRO_OS||' - '||MC.TIPO_OS) from FAT_MOVIMENTO_CAPA MC, OFI_FICHA_MOVIMENTO FM where MC.EMPRESA = FM.EMPRESA and MC.REVENDA = FM.REVENDA and MC.NUMERO_NOTA_FISCAL = FM.NUMERO_NOTA_FISCAL and MC.SERIE_NOTA_FISCAL = FM.SERIE_NOTA_FISCAL 
           and MC.TIPO_TRANSACAO = FM.TIPO_TRANSACAO and MC.CONTADOR = FM.CONTADOR and MC.EMPRESA = FT.EMPRESA and MC.REVENDA = FT.REVENDA and MC.OPERACAO = FT.OPERACAO and MC.STATUS <> 'C')) OS_GARANTIA_REVISAO,
           
           ((Select MIN(MC.TIPO_OS) from FAT_MOVIMENTO_CAPA MC, OFI_FICHA_MOVIMENTO FM where MC.EMPRESA = FM.EMPRESA and MC.REVENDA = FM.REVENDA and MC.NUMERO_NOTA_FISCAL = FM.NUMERO_NOTA_FISCAL and MC.SERIE_NOTA_FISCAL = FM.SERIE_NOTA_FISCAL 
           and MC.TIPO_TRANSACAO = FM.TIPO_TRANSACAO and MC.CONTADOR = FM.CONTADOR and MC.EMPRESA = FT.EMPRESA and MC.REVENDA = FT.REVENDA and MC.OPERACAO = FT.OPERACAO and MC.STATUS <> 'C')) TIPO_OS,
           
           to_number( ((Select MIN(FM.NRO_OS) from FAT_MOVIMENTO_CAPA MC, OFI_FICHA_MOVIMENTO FM where MC.EMPRESA = FM.EMPRESA and MC.REVENDA = FM.REVENDA and MC.NUMERO_NOTA_FISCAL = FM.NUMERO_NOTA_FISCAL and MC.SERIE_NOTA_FISCAL = FM.SERIE_NOTA_FISCAL 
           and MC.TIPO_TRANSACAO = FM.TIPO_TRANSACAO and MC.CONTADOR = FM.CONTADOR and MC.EMPRESA = FT.EMPRESA and MC.REVENDA = FT.REVENDA and MC.OPERACAO = FT.OPERACAO and MC.STATUS <> 'C')) ) N_OS,
            
           MIN((Select MIN(REPLACE(MC.NFSE_CHAVE_ACESSO,'NFS-e: ','')) from FAT_MOVIMENTO_CAPA MC where MC.EMPRESA = FT.EMPRESA and MC.REVENDA = FT.REVENDA and MC.OPERACAO = FT.OPERACAO and MC.STATUS <> 'C')) NFSE, MIN((Select MIN(MC.NUMERO_NOTA_FISCAL) from FAT_MOVIMENTO_CAPA MC where MC.EMPRESA = FT.EMPRESA and MC.REVENDA = FT.REVENDA and MC.OPERACAO = FT.OPERACAO and MC.STATUS <> 'C')) RPS 
           from FIN_TITULO FT, FAT_CLIENTE FC, FIN_BANCO FB, FIN_ORIGEM FO, GER_USUARIO USU, FIN_TITULO_PAGAMENTO FTP, FIN_DEVOLUCAO FTD, FIN_DEVOLUCAO_CHEQUE FDC, GER_DEPARTAMENTO GD, GER_OPERACAO GO 
           where FT.EMPRESA in (1,3,4,5,11) and FC.CLIENTE = FT.CLIENTE and FT.USUARIO = USU.USUARIO and FT.TIPO not in ('BC','CX') and FTP.EMPRESA (+) = FT.EMPRESA AND FTP.REVENDA (+) = FT.REVENDA AND FTP.TITULO (+) = FT.TITULO 
           AND FTP.DUPLICATA (+) = FT.DUPLICATA AND FTP.CLIENTE (+) = FT.CLIENTE AND FTP.TIPO (+) = FT.TIPO and FTD.EMPRESA (+) = FT.EMPRESA AND FTD.REVENDA (+) = FT.REVENDA AND FTD.TITULO (+) = FT.TITULO AND FTD.DUPLICATA (+) = FT.DUPLICATA AND FTD.CLIENTE (+) = FT.CLIENTE AND FTD.TIPO (+) = FT.TIPO and FDC.EMPRESA (+) = FT.EMPRESA AND FDC.REVENDA (+) = FT.REVENDA AND FDC.TITULO (+) = FT.TITULO AND FDC.DUPLICATA (+) = FT.DUPLICATA AND FDC.CLIENTE (+) = FT.CLIENTE AND FDC.TIPO (+) = FT.TIPO and FB.EMPRESA (+) = FT.EMPRESA and FB.REVENDA (+) = FT.REVENDA and FB.BANCO (+) = FT.BANCO and FO.EMPRESA (+) = FT.EMPRESA and FO.REVENDA (+) = FT.REVENDA and FO.ORIGEM (+) = FT.ORIGEM and GD.EMPRESA = FT.EMPRESA and GD.REVENDA = FT.REVENDA and GD.DEPARTAMENTO = FT.DEPARTAMENTO and GO.EMPRESA = FT.EMPRESA and GO.REVENDA = FT.REVENDA and GO.OPERACAO = FT.OPERACAO 
           --and FT.DTA_EMISSAO BETWEEN TO_DATE('07/11/2019','dd/mm/yyyy') and TO_DATE('07/11/2019','dd/mm/yyyy')
           /*and FT.REVENDA in (1)*/ and ( (FT.ENVIADO IN (0,1, 2, 3, 4) or (FT.ENVIADO IS NULL)))
           and exists (Select MC.TIPO_OS from FAT_MOVIMENTO_CAPA MC where MC.EMPRESA = FT.EMPRESA and MC.REVENDA = FT.REVENDA and MC.OPERACAO = FT.OPERACAO
           and MC.STATUS <> 'C' and MC.TIPO_OS in ('G','R'))
           group by ft.empresa, FT.REVENDA, FT.TITULO, FT.DUPLICATA, FT.CLIENTE, FT.TIPO, FT.DEPARTAMENTO, GD.NOME , FT.TIPO_COBRANCA, FT.DTA_VENCIMENTO, FT.DTA_EMISSAO, FT.DTA_CONTABIL,FT.ENVIADO, FT.AUTORIZACAO, FT.CAIXA, FT.VAL_TITULO, FT.STATUS, FC.NOME, FC.CATEGORIA ,
           FC.TELEFONE ,FC.DDD_TELEFONE ,FT.BANCO, FT.INDICE, FT.TIPO_INDICE, FB.DES_BANCO, FT.ORIGEM, FO.DES_ORIGEM, FT.USUARIO, USU.NOME, GO.DTA_OPERACAO, FT.NOSSONUMERO, CASE WHEN (COALESCE(FC.ENDERECO_MALA, 1) = 1) THEN FC.MUNICIPIO_ENTREGA ELSE FC.MUNICIPIO_COBRANCA END, CASE WHEN (COALESCE(FC.ENDERECO_MALA, 1) = 1) THEN FC.LOGRADOURO_ENTREGA ELSE FC.LOGRADOURO_COBRANCA END, CASE WHEN (COALESCE(FC.ENDERECO_MALA, 1) = 1) THEN FC.BAIRRO_ENTREGA ELSE FC.BAIRRO_COBRANCA END, CASE WHEN (COALESCE(FC.ENDERECO_MALA, 1) = 1) THEN FC.COMPLEMENTO_ENTREGA ELSE FC.COMPLEMENTO_COBRANCA END, CASE WHEN (COALESCE(FC.ENDERECO_MALA, 1) = 1) THEN FC.MUNICIPIO_ENTREGA ELSE FC.MUNICIPIO_COBRANCA END, CASE WHEN (COALESCE(FC.ENDERECO_MALA, 1) = 1) THEN FC.UF_ENTREGA ELSE FC.UF_COBRANCA END, CASE WHEN (COALESCE(FC.ENDERECO_MALA, 1) = 1) THEN FC.CEP_ENTREGA ELSE FC.CEP_COBRANCA END, FT.NUMERO_LOTE_CARTAO,FT.RG_GARANTIA, FT.OPERACAO, FT.HISTORICO 
       ) s1
       left join
       (
   
         select t.empresa, t.revenda, t.titulo, t.duplicata, t.cliente , t.tipo, sum(t.val_titulo) val_titulo, 
         t.status, --nvl(tp.val_pagamento,0) pagamento 
         nvl(SUM((tp.VAL_PAGAMENTO + tp.VAL_ACRESCIMO + tp.VAL_MULTA - tp.VAL_DESCONTO)),0) pagamento
        from cnp.fin_titulo t  
         left JOIN FIN_TITULO_PAGAMENTO tp on (t.empresa = tp.empresa and t.revenda = tp.revenda 
         and t.titulo = tp.titulo and t.duplicata = tp.duplicata and t.tipo = tp.tipo and t.departamento = tp.departamento and t.cliente = tp.cliente) 
         where t.status in ('EM','PP')
         group by t.empresa, t.revenda, t.titulo, t.duplicata, t.cliente , t.tipo, t.status
         
       ) s2 on s1.empresa = s2.empresa and s1.revenda = s2.revenda and s1.titulo = s2.titulo and s1.duplicata = s2.duplicata and s1.tipo = s2.tipo
       left join VWB_SG_CAPA sc on s1.empresa = sc.empresa and s1.revenda = sc.revenda and s1.n_os = sc.nro_os
       left join VWB_CUPOM_REVISAO VCR on s1.empresa = vcr.empresa and s1.revenda = vcr.revenda and s1.n_os = vcr.nro_os 
       where s1.status in ('EM','PP')
       --and s1.DTA_EMISSAO BETWEEN TO_DATE('10/05/2019','dd/mm/yyyy') and TO_DATE('10/05/2019','dd/mm/yyyy')
  ) ss1
left join
  (
    select distinct s.empresa, s.revenda, os.tipo_servico, s.nro_os, case when situacao_os = 0 then 'Aberto'
    when situacao_os = 1 then 'Andamento' when situacao_os = 7 then 'cancelado' when situacao_os = 9 then 'faturdado' end situacao_os,
    s.dta_emissao dta_emissao_os  
    from cnp.ofi_ordem_servico s
    join cnp.ofi_servico_os os on (s.EMPRESA = os.empresa and s.REVENDA = os.revenda and s.NRO_OS = os.nro_os)
  ) ss2 on ss1.empresa = ss2.empresa and ss1.revenda = ss2.revenda and ss1.n_os = ss2.nro_os   
  order by 1,2,3, ss2.nro_os ");
	}
	
	public function resumodescontoMotos1(){
		return $this->Select("select s1.empresa, s1.dta_venda, s1.valor_venda, s2.venda_novos, s3.venda_usados, s4.alta_cilindrada, s5.Baixa_Media_Cilindrada, s6.venda_normal, s7.venda_consorcio,
       s1.val_custo_medio, s1.val_margem, round((s1.val_margem/s1.valor_venda)*100,2) pct_margem 
       from
       (   
           select v1.empresa, v1.dta_entrada_saida dta_venda, sum(v1.venda_real) valor_venda, sum(v1.tot_custo_medio) val_custo_medio,  sum(v1.val_margem) val_margem
           from cnp.j_v_venda_motos_oper_desc_emp v1
           group by v1.dta_entrada_saida, v1.empresa
       ) s1
       left join
       (
           select v1.empresa, v1.dta_entrada_saida dta_venda, sum(v1.venda_real) venda_novos
           from cnp.j_v_venda_motos_oper_desc_emp v1 where v1.tipo_de_veiculo = 'Novo' 
           group by v1.dta_entrada_saida, v1.empresa 
       ) s2 on s1.dta_venda = s2.dta_venda and s1.empresa = s2.empresa     
       left join
       (
           select v1.empresa, v1.dta_entrada_saida dta_venda, sum(v1.venda_real) venda_usados
           from cnp.j_v_venda_motos_oper_desc_emp v1 where v1.tipo_de_veiculo = 'Usado' 
           group by v1.dta_entrada_saida, v1.empresa
       ) s3 on s1.dta_venda = s3.dta_venda and s1.empresa = s3.empresa 
       left join
       (
           select v1.empresa, v1.dta_entrada_saida dta_venda, sum(v1.venda_real) alta_cilindrada
           from cnp.j_v_venda_motos_oper_desc_emp v1 where v1.tipo_cilindrada = 'Alta' 
           group by v1.dta_entrada_saida, v1.empresa
       ) s4 on s1.dta_venda = s4.dta_venda and s1.empresa = s4.empresa   
       left join
       (
           select v1.empresa, v1.dta_entrada_saida dta_venda, sum(v1.venda_real) Baixa_Media_Cilindrada
           from cnp.j_v_venda_motos_oper_desc_emp v1 where v1.tipo_cilindrada = 'Baixa/M�dia' 
           group by v1.dta_entrada_saida, v1.empresa 
       ) s5 on s1.dta_venda = s5.dta_venda and s1.empresa = s5.empresa 
       left join
       (
           select v1.empresa, v1.dta_entrada_saida dta_venda, sum(v1.venda_real) venda_normal
           from cnp.j_v_venda_motos_oper_desc_emp v1 where v1.tipo_venda = 'Venda Normal' 
           group by v1.dta_entrada_saida, v1.empresa 
       ) s6 on s1.dta_venda = s6.dta_venda and s1.empresa = s6.empresa 
       left join
       (
           select v1.empresa, v1.dta_entrada_saida dta_venda, sum(v1.venda_real) venda_consorcio
           from cnp.j_v_venda_motos_oper_desc_emp v1 where v1.tipo_venda = 'Venda de Consorcio' 
           group by v1.dta_entrada_saida, v1.empresa
       ) s7 on s1.dta_venda = s7.dta_venda and s1.empresa = s7.empresa 
       where s1.empresa = 2 order by 2");
	}
	
 	public function resumodescontoMotos2(){
 		return $this->Select("select t1.*
  from
  (      
        select * from cnp.j_v_acumulado_vendas_moto_emp 
        union all        
        select * from cnp.j_v_valor_custo_vend_moto_emp
        union all
        select * from cnp.j_v_valor_margem_vend_moto_emp
        union all
        select  p1.empresa, '% Margem' tipo, round((p1.valor_acumulado/p2.valor_acumulado)*100,2) valor_acumulado, round((p1.venda_novos/p2.venda_novos)*100,2) venda_novos, round((p1.venda_usados/p2.venda_usados)*100,2) venda_usados, 
        round((p1.alta_cilindrada/p2.alta_cilindrada)*100,2) alta_cilindrada, round((p1.baixa_media_cilindrada/p2.baixa_media_cilindrada)*100,2), round((p1.venda_normal/p2.venda_normal)*100,2) venda_normal, 
        round((p1.venda_consorcio/p2.venda_consorcio)*100,2) venda_consorcio
        from cnp.j_v_valor_margem_vend_moto_emp p1
        join
        ( select empresa, '% Margem' tipo, valor_acumulado, venda_novos, venda_usados, alta_cilindrada, baixa_media_cilindrada, venda_normal, venda_consorcio
        from cnp.j_v_acumulado_vendas_moto_emp ) p2 on '% Margem' = p2.tipo and p1.empresa = p2.empresa
        order by 1
  ) t1 where t1.empresa = 2");
 	}
 	
 	public function osemabertarevisao(){
 		return $this->Select(" select os.empresa, os.revenda, os.nro_os, to_char(os.dta_emissao,'dd/mm/yyyy') dta_emissao_os, to_char(cr.dta_transmissao,'dd/mm/yyyy') dta_transmissao_os, os.dta_conclusao dta_conclusao_os,
    case when situacao_os = 0 then 'Aberto'
    when situacao_os = 1 then 'Andamento' when situacao_os = 7 then 'cancelado' when situacao_os = 9 then 'faturdado' end situacao_os 
    from cnp.ofi_ordem_servico os
    left join cnp.VWB_CUPOM_REVISAO cr on (os.empresa = cr.empresa and os.revenda = cr.revenda and os.nro_os = cr.nro_os)
    where os.empresa in (1,3,4,5,11) and os.situacao_os = 0 
    and os.servico_revisao = 1
    order by 1,2,3");
 	}
 	
 	public function estoqueveiculos(){
 		return $this->Select(" SELECT distinct s1.empresa, s1.revenda, ss2.des_empresa, ss2.des_negocio, ss2.ID_NUCLEO, s1.veiculo, s1.quilometragem, s1.des_localizacao, s1.chassi, s1.modelo, s1.des_modelo,
    s1.des_familia, s1.combustivel, s1.situacao, s1.novo_usado, s1.departamento, s1.placa, s1.acabamento, s1.ano_fabricacao, s1.ano_modelo,
    s1.contabil, s1.transito, s1.reservado, s1.negociado, s1.tem_proposta, s1.disponivel, s1.vendido, s1.proposta, s1.des_cor, s1.opcionais,
    s1.val_custo_contabil, s1.val_compra, s1.custo, s1.custo_pres, f1.tot_nota_fiscal, f1.tipo_transacao,  s1.tipo_comercializacao, s1.des_categoria_veiculo, 
    s1.numero_nota_nfentrada, s1.dta_entrada, trunc(sysdate)-s1.dta_entrada as dias, s1.sit_veic,
    s1.Empresa_Nfentrada, s1.Revenda_Nfentrada, 
    to_char(sysdate,'yyyy') ano_processamento, to_char(sysdate,'mm') mes_processamento 
    FROM
      ( 
        SELECT V.EMPRESA, V.REVENDA_ORIGEM REVENDA, (SELECT NOME_FANTASIA FROM GER_REVENDA WHERE EMPRESA = V.EMPRESA AND REVENDA = V.REVENDA_ORIGEM) NOME_FANTASIA, 
        null DTA_FAT_FABRICA, null DTA_VENDA, V.EMPRESA EMPRESA_NOTA, V.REVENDA_ORIGEM REVENDA_NOTA, V.EMPRESA EMPRESA_ORIGEM_NOTA, V.REVENDA_ORIGEM REVENDA_ORIGEM_NOTA, 
        CAST(0 AS INTEGER) EST_MEDIO, CAST(V.MODELO AS VARCHAR(20)) VEICULO, CAST(0 AS INTEGER) QUILOMETRAGEM, CAST(' ' AS VARCHAR(20)) LOCALIZACAO, CAST(' ' AS VARCHAR(50)) DES_LOCALIZACAO, 
        CAST(V.CHASSI AS VARCHAR(17)) CHASSI, M.MODELO, M.DES_MODELO, CAST(' ' AS VARCHAR(1)) EDICAO, FA.TEMPO_ESTOQUE_DIF, FA.QTD_DIAS_INI_PRETO, FA.QTD_DIAS_FIM_PRETO, FA.QTD_DIAS_INI_CINZA, 
        FA.QTD_DIAS_FIM_CINZA, FA.QTD_DIAS_INI_VERDE, FA.QTD_DIAS_FIM_VERDE, FA.QTD_DIAS_INI_AZUL, FA.QTD_DIAS_FIM_AZUL, FA.QTD_DIAS_INI_VERMELHO, FA.QTD_DIAS_FIM_VERMELHO, FA.FAMILIA, 
        (select OS.DES_SEGUIMENTO from OFI_FICHA_SEGUIMENTO OFS, OFI_SEGUIMENTO OS where OFS.CHASSI = V.CHASSI and OS.SEGUIMENTO = OFS.SEGUIMENTO) SEGUIMENTO, (select OFS.VERSAO from OFI_FICHA_SEGUIMENTO OFS where OFS.CHASSI = V.CHASSI) VERSAO, 
        (select OFS.PNEUS from OFI_FICHA_SEGUIMENTO OFS where OFS.CHASSI = V.CHASSI) PNEUS, FA.DES_FAMILIA, CAST(' ' AS CHAR(1)) COMBUSTIVEL , CAST(V.SITUACAO AS VARCHAR(2)) SITUACAO, CAST(' ' AS CHAR(1)) NOVO_USADO, cast(0 AS INTEGER) DEPARTAMENTO, 
        CAST(' ' AS VARCHAR(7)) PLACA, CAST(' ' AS VARCHAR(4)) ACABAMENTO, V.ANO_FABRICACAO, V.ANO_MODELO, CAST(' ' AS VARCHAR(10)) PACOTE, CAST(' ' AS VARCHAR(10)) COR_CARRETA, CAST(0 AS NUMERIC(1)) CONTABIL, CAST(0 AS NUMERIC(1)) TRANSITO, 
        CASE WHEN V.DTA_FIM_RESERVA > sysdate THEN 1 ELSE 0 END RESERVADO, CAST(0 AS NUMERIC(1)) NEGOCIADO, CASE WHEN (SELECT COUNT(*) FROM VEI_PROPOSTA WHERE EMPRESA = V.EMPRESA AND PEDIDO = V.PEDIDO AND SITUACAO IN ('0','1','2','5')) > 0 THEN 1 ELSE 0 END TEM_PROPOSTA, 
        CAST(0 AS NUMERIC(1)) DISPONIVEL, CAST(0 AS NUMERIC(1)) VENDIDO, CAST(0 AS NUMERIC(1)) VENDADIR, CAST(0 AS NUMERIC(1)) DEVOLUCOES, CAST(1 AS NUMERIC(1)) PEDIDO, (SELECT MAX(PROPOSTA*1000+NEGOCIACAO_FINAL) FROM VEI_PROPOSTA WHERE EMPRESA = V.EMPRESA AND PEDIDO = V.PEDIDO AND SITUACAO IN ('7','9')) PROPOSTA, 
        (SELECT DES_COR FROM VEI_COR WHERE EMPRESA = V.EMPRESA AND COR = V.COR) DES_COR, CAST(V.OPCIONAIS AS VARCHAR(144)) OPCIONAIS, CAST('4' AS CHAR(1)) VCR, COALESCE(P.PRECO_PUBLICO,M.PRECO_PUBLICO,0)+ COALESCE(M.FRETE_VENDA,0)+ COALESCE(M.VAL_SEGURO,0)+ (SELECT SUM(OM.VAL_OPCIONAL) FROM VEI_PEDIDO_OPCIONAL PO, VEI_OPCIONAL_MODELO OM WHERE PO.EMPRESA = V.EMPRESA AND PO.PEDIDO = V.PEDIDO AND PO.MODELO = V.MODELO AND PO.EMPRESA = OM.EMPRESA AND PO.MODELO = OM.MODELO AND PO.OPCIONAL = OM.OPCIONAL) VAL_VENDA, 
        M.FRETE_VENDA FRETE, M.VAL_SEGURO SEGURO, M.CUSTO, M.CUSTO CUSTO_PRES, V.PEDIDO_FABRICA, CAST(V.DTA_PROGRAMADA AS DATE) DTA_PROGRAMADA, CAST(V.DTA_PROVAVEL AS DATE) DTA_PROVAVEL, CAST(0 AS NUMERIC(1)) VAL_COMPRA, CAST(0 AS NUMERIC(1)) VAL_CUSTO_CONTABIL, CAST(0 AS NUMERIC(1)) PRECO_MINIMO_COMERCIALIZACAO, 
        CAST(0 AS NUMERIC(1)) PRECO_CONCESSIONARIA, CAST(' ' AS VARCHAR(12)) VERSAO_RENAULT, CAST(' ' AS VARCHAR(1)) VEICULO_RESERVADO, CAST(0 AS NUMERIC(1)) VENDEDOR_RESERVA, CAST(NULL AS DATE) DTA_FIM_RESERVA, CAST(NULL AS DATE) DTA_GARANTIA_USADO, CAST(0 AS NUMERIC(1)) VAL_BONUS, CAST(0 AS NUMERIC(1)) NUMERO_PORTAS, '' TIPO_PINTURA, '' TIPO_COMERCIALIZACAO, '' DES_CATEGORIA_VEICULO, 
        CAST(' ' AS VARCHAR(35)) IDENTIFICACAO, CAST(V.DTA_PROGRAMADA AS DATE) DTA_ENTRADA, NULL DTA_ENTRADA_ESTOQUE, CAST(0 AS NUMERIC(17,2)) VENDA, CAST(0 AS NUMERIC(17,2)) BONUS, CAST(0 AS NUMERIC(17,2)) PRECO_TABELA, CAST(' ' AS VARCHAR(40)) NOME_VENDEDOR, FVE.NOME NOME_VENDEDOR_RESERVA, CAST(0 AS NUMERIC(1)) USUARIO_RESERVA, CLI.NOME NOME_CLIENTE_RESERVA, 
        (select max(FTP.status) from FAT_MOVIMENTO_CAPA FME, FIN_TITULO FTP where VEI.EMPRESA_NFENTRADA = FME.EMPRESA and VEI.REVENDA_NFENTRADA = FME.REVENDA and VEI.NUMERO_NOTA_NFENTRADA = FME.NUMERO_NOTA_FISCAL and VEI.SERIE_NOTA_NFENTRADA = FME.SERIE_NOTA_FISCAL and VEI.TIPO_TRANSACAO_NFENTRADA = FME.TIPO_TRANSACAO and VEI.CONTADOR_NFENTRADA = FME.CONTADOR and FME.EMPRESA = FTP.EMPRESA and FME.REVENDA = FTP.REVENDA and FME.NUMERO_NOTA_FISCAL = FTP.TITULO and FME.CLIENTE = FTP.CLIENTE and 'CP' = FTP.TIPO and ftp.val_titulo >= ( select max(x.val_titulo) from fin_titulo x where FME.EMPRESA = x.EMPRESA and FME.REVENDA = x.REVENDA and FME.NUMERO_NOTA_FISCAL = x.TITULO and FME.CLIENTE = x.CLIENTE and 'CP' = FTP.TIPO )) SIT_VEIC, 
        VEI.NUMERO_NOTA_NFENTRADA, (select FMC.DTA_DOCUMENTO from FAT_MOVIMENTO_CAPA FMC where VEI.EMPRESA_NFENTRADA = FMC.EMPRESA and VEI.REVENDA_NFENTRADA = FMC.REVENDA and VEI.NUMERO_NOTA_NFENTRADA = FMC.NUMERO_NOTA_FISCAL and VEI.SERIE_NOTA_NFENTRADA = FMC.SERIE_NOTA_FISCAL and VEI.TIPO_TRANSACAO_NFENTRADA = FMC.TIPO_TRANSACAO and VEI.CONTADOR_NFENTRADA = FMC.CONTADOR ) DTA_DOCUMENTO_FABRICA, (select GEM.NOME_MARCA from GER_MARCA GEM where GEM.MARCA = FA.MARCA) NOME_MARCA, VEI.VEI_OBS, VEI.Empresa_Nfentrada, VEI.Revenda_Nfentrada
        FROM VEI_MODELO M, VEI_FAMILIA FA, VEI_PEDIDO V 
        left outer join VEI_VEICULO VEI on ( VEI.EMPRESA = V.EMPRESA) and ( VEI.CHASSI = V.CHASSI) 
        left outer join VEI_MODELO_PRECO P on (VEI.EMPRESA = P.EMPRESA and VEI.MODELO = P.MODELO and VEI.REVENDA_ORIGEM = P.REVENDA) 
        left outer join FAT_CLIENTE CLI on V.CLIENTE_RESERVA = CLI.CLIENTE 
        left outer join FAT_VENDEDOR FVE on V.EMPRESA = FVE.EMPRESA and V.REVENDA_RESERVA = FVE.REVENDA and V.VENDEDOR_RESERVA = FVE.VENDEDOR 
        WHERE V.EMPRESA = M.EMPRESA AND V.MODELO = M.MODELO AND FA.EMPRESA = M.EMPRESA AND FA.FAMILIA = M.FAMILIA AND V.SITUACAO IN (0,1) 
        and FA.EMPRESA IN V.EMPRESA AND V.PEDIDO = -1 
        UNION ALL 
        SELECT V.EMPRESA, V.REVENDA_ORIGEM REVENDA, (SELECT NOME_FANTASIA FROM GER_REVENDA WHERE EMPRESA = V.EMPRESA AND REVENDA = V.REVENDA_ORIGEM) NOME_FANTASIA, V.DTA_FAT_FABRICA, V.DTA_VENDA, V.EMPRESA EMPRESA_NOTA, V.REVENDA_ORIGEM REVENDA_NOTA, V.EMPRESA EMPRESA_ORIGEM_NOTA, V.REVENDA_ORIGEM REVENDA_ORIGEM_NOTA, 
        CAST(0 AS INTEGER) EST_MEDIO, V.VEICULO, V.QUILOMETRAGEM, V.LOCALIZACAO, (SELECT DES_LOCALIZACAO FROM VEI_LOCALIZACAO WHERE LOCALIZACAO = V.LOCALIZACAO) DES_LOCALIZACAO, V.CHASSI, M.MODELO, M.DES_MODELO, F.EDICAO, FA.TEMPO_ESTOQUE_DIF, FA.QTD_DIAS_INI_PRETO, FA.QTD_DIAS_FIM_PRETO, FA.QTD_DIAS_INI_CINZA, FA.QTD_DIAS_FIM_CINZA, 
        FA.QTD_DIAS_INI_VERDE, FA.QTD_DIAS_FIM_VERDE, FA.QTD_DIAS_INI_AZUL, FA.QTD_DIAS_FIM_AZUL, FA.QTD_DIAS_INI_VERMELHO, FA.QTD_DIAS_FIM_VERMELHO, FA.FAMILIA, (select OS. DES_SEGUIMENTO from OFI_SEGUIMENTO OS where OS.SEGUIMENTO = F.SEGUIMENTO) SEGUIMENTO, F.VERSAO, F.PNEUS, FA.DES_FAMILIA, F.COMBUSTIVEL , V.SITUACAO, V.NOVO_USADO, 
        V.DEPARTAMENTO, F.PLACA, F.ACABAMENTO, F.ANO_FABRICACAO, F.ANO_MODELO, F.PACOTE, F.COR_CARRETA, CASE WHEN (V.SITUACAO IN (SELECT SITUACAO FROM VEI_SITUACAO WHERE EMPRESA = V.EMPRESA AND LOCALIZACAO = 'E') AND V.SITUACAO NOT IN (SELECT COALESCE(SITUACAO,' ') FROM VEI_PARAMETRO WHERE EMPRESA = V.EMPRESA AND REVENDA = V.REVENDA_ORIGEM)) THEN 1 ELSE 0 END CONTABIL, 
        CASE V.SITUACAO WHEN (SELECT SITUACAO FROM VEI_PARAMETRO WHERE EMPRESA = V.EMPRESA AND REVENDA = V.REVENDA_ORIGEM) THEN 1 ELSE 0 END TRANSITO, CASE WHEN (V.SITUACAO IN (SELECT SITUACAO FROM VEI_SITUACAO WHERE EMPRESA = V.EMPRESA AND LOCALIZACAO = 'E') AND V.RESERVADO = 'S' AND V.DTA_FIM_RESERVA > sysdate AND V.VEICULO NOT IN (SELECT VEICULO FROM VEI_PROPOSTA WHERE EMPRESA = V.EMPRESA AND VEICULO = V.VEICULO AND SITUACAO IN ('2','5'))) THEN 1 ELSE 0 END RESERVADO, 
        CASE WHEN (SELECT COUNT(*) FROM VEI_PROPOSTA WHERE EMPRESA = V.EMPRESA AND VEICULO = V.VEICULO AND SITUACAO IN ('2','5')) > 0 THEN 1 ELSE 0 END NEGOCIADO, CASE WHEN (SELECT COUNT(*) FROM VEI_PROPOSTA WHERE EMPRESA = V.EMPRESA AND VEICULO = V.VEICULO AND SITUACAO IN ('0','1','2','5')) > 0 THEN 1 ELSE 0 END TEM_PROPOSTA, CAST(0 AS NUMERIC(1)) DISPONIVEL, CAST(0 AS NUMERIC(1)) VENDIDO, CAST(0 AS NUMERIC(1)) VENDADIR, CAST(0 AS NUMERIC(1)) DEVOLUCOES, CAST(0 AS NUMERIC(1)) PEDIDO, 
        (SELECT MAX(PROPOSTA*1000+NEGOCIACAO_FINAL) FROM VEI_PROPOSTA WHERE EMPRESA = V.EMPRESA AND VEICULO = V.VEICULO AND SITUACAO IN ('2','5')) PROPOSTA, (SELECT DES_COR FROM VEI_COR WHERE EMPRESA = V.EMPRESA AND COR = V.COR) DES_COR, V.OPCIONAIS, (SELECT VAL_VEICULO_C_R FROM VEI_PARAMETRO WHERE EMPRESA = V.EMPRESA AND REVENDA = V.REVENDA_ORIGEM) VCR, CAST(0 AS NUMERIC(17,2)) VAL_VENDA, M.FRETE_VENDA FRETE, M.VAL_SEGURO SEGURO,
        COALESCE((SELECT SUM(C.VAL_HISTORICO) FROM VEI_VEICULO_CUSTEIO C, VEI_FORMULA_LINHA L WHERE C.EMPRESA = V.EMPRESA AND C.VEICULO = V.VEICULO AND C.EMPRESA = L.EMPRESA AND C.FORMULA = L.FORMULA AND C.LINHA_FORMULA = L.LINHA_FORMULA AND (L.CUSTO_TOTAL = '+' or (L.TIPO = 'B' AND (L.INCIDENCIA = '(' OR L.INCIDENCIA = ')'))) AND L.STATUS = 'A' GROUP BY C.EMPRESA, C.VEICULO),0)- COALESCE((SELECT SUM(C.VAL_HISTORICO) FROM VEI_VEICULO_CUSTEIO C, VEI_FORMULA_LINHA L WHERE C.EMPRESA = V.EMPRESA AND C.VEICULO = V.VEICULO AND C.EMPRESA = L.EMPRESA AND C.FORMULA = L.FORMULA AND C.LINHA_FORMULA = L.LINHA_FORMULA AND L.CUSTO_TOTAL = '-' AND L.STATUS = 'A' GROUP BY C.EMPRESA, C.VEICULO),0) CUSTO, 
        COALESCE((SELECT SUM(C.VAL_PRESENTE) FROM VEI_VEICULO_CUSTEIO C, VEI_FORMULA_LINHA L WHERE C.EMPRESA = V.EMPRESA AND C.VEICULO = V.VEICULO AND C.EMPRESA = L.EMPRESA AND C.FORMULA = L.FORMULA AND C.LINHA_FORMULA = L.LINHA_FORMULA AND (L.CUSTO_TOTAL = '+' or (L.TIPO = 'B' AND (L.INCIDENCIA = '(' OR L.INCIDENCIA = ')'))) AND L.STATUS = 'A' GROUP BY C.EMPRESA, C.VEICULO),0)- COALESCE((SELECT SUM(C.VAL_PRESENTE) FROM VEI_VEICULO_CUSTEIO C, VEI_FORMULA_LINHA L WHERE C.EMPRESA = V.EMPRESA AND C.VEICULO = V.VEICULO AND C.EMPRESA = L.EMPRESA AND C.FORMULA = L.FORMULA AND C.LINHA_FORMULA = L.LINHA_FORMULA AND L.CUSTO_TOTAL = '-' AND L.STATUS = 'A' GROUP BY C.EMPRESA, C.VEICULO),0) CUSTO_PRES, 
        (select (P.PEDIDO_FABRICA) from VEI_PEDIDO P where P.EMPRESA = V.EMPRESA and P.PEDIDO = V.PEDIDO) PEDIDO_FABRICA, CAST(NULL AS DATE) DTA_PROGRAMADA, CAST(NULL AS DATE) DTA_PROVAVEL, V.VAL_COMPRA, V.VAL_CUSTO_CONTABIL , V.PRECO_MINIMO_COMERCIALIZACAO, V.PRECO_CONCESSIONARIA, V.VERSAO_RENAULT, V.RESERVADO VEICULO_RESERVADO, V.VENDEDOR_RESERVA, case when V.DTA_FIM_RESERVA > sysdate then V.DTA_FIM_RESERVA else NULL end DTA_FIM_RESERVA, F.DTA_GARANTIA_USADO, V.VAL_BONUS, F.PORTAS NUMERO_PORTAS, F.TIPO_PINTURA, (select DES_COMERCIALIZACAO from VEI_TIPO_COMERCIALIZACAO where EMPRESA = V.EMPRESA and TIPO_COMERCIALIZACAO = V.TIPO_COMERCIALIZACAO) TIPO_COMERCIALIZACAO, 
        (select DES_CATEGORIA_VEICULO from VEI_CATEGORIA_VEICULO where EMPRESA = V.EMPRESA and CATEGORIA_VEICULO = V.CATEGORIA_VEICULO) DES_CATEGORIA_VEICULO, F.IDENTIFICACAO, CAST(V.DTA_ENTRADA AS DATE) DTA_ENTRADA, V.DTA_ENTRADA_ESTOQUE, CAST(0 AS NUMERIC(17,2)) VENDA, CAST(0 AS NUMERIC(17,2)) BONUS, CAST(0 AS NUMERIC(17,2)) PRECO_TABELA, (select max(NOME) from FAT_VENDEDOR VEN, FAT_NOTAS_VENDEDOR FMNE where VEN.EMPRESA = FMNE.EMPRESA    and VEN.REVENDA = FMNE.REVENDA and VEN.VENDEDOR = FMNE.VENDEDOR and V.EMPRESA_NFENTRADA = FMNE.EMPRESA and V.REVENDA_NFENTRADA = FMNE.REVENDA and V.NUMERO_NOTA_NFENTRADA = FMNE.NUMERO_NOTA_FISCAL and V.SERIE_NOTA_NFENTRADA = FMNE.SERIE_NOTA_FISCAL and V.TIPO_TRANSACAO_NFENTRADA = FMNE.TIPO_TRANSACAO and V.CONTADOR_NFENTRADA = FMNE.CONTADOR) NOME_VENDEDOR, 
        coalesce((select VEN.NOME from FAT_VENDEDOR VEN where V.VENDEDOR_RESERVA = VEN.VENDEDOR and V.EMPRESA_VENDEDOR_RESERVA = VEN.EMPRESA and V.REVENDA_VENDEDOR_RESERVA = VEN.REVENDA and V.DTA_FIM_RESERVA > sysdate ), '') NOME_VENDEDOR_RESERVA, coalesce((select VEN.USUARIO from FAT_VENDEDOR VEN where V.VENDEDOR_RESERVA = VEN.VENDEDOR and V.EMPRESA_VENDEDOR_RESERVA = VEN.EMPRESA and V.REVENDA_VENDEDOR_RESERVA = VEN.REVENDA and V.DTA_FIM_RESERVA > sysdate ), 0) USUARIO_RESERVA, coalesce((select CLI.NOME from FAT_CLIENTE CLI where V.CLIENTE_RESERVA = CLI.CLIENTE and V.DTA_FIM_RESERVA > sysdate ), '') NOME_CLIENTE_RESERVA , (select max(FTP.status) from FAT_MOVIMENTO_CAPA FME, FIN_TITULO FTP where V.EMPRESA_NFENTRADA = FME.EMPRESA and V.REVENDA_NFENTRADA = FME.REVENDA and V.NUMERO_NOTA_NFENTRADA = FME.NUMERO_NOTA_FISCAL and V.SERIE_NOTA_NFENTRADA = FME.SERIE_NOTA_FISCAL and V.TIPO_TRANSACAO_NFENTRADA = FME.TIPO_TRANSACAO and V.CONTADOR_NFENTRADA = FME.CONTADOR and FME.EMPRESA = FTP.EMPRESA and FME.REVENDA = FTP.REVENDA and FME.NUMERO_NOTA_FISCAL = FTP.TITULO and FME.CLIENTE = FTP.CLIENTE and FTP.TIPO = 'CP' and ftp.val_titulo >= ( select max(x.val_titulo) from fin_titulo x where FME.EMPRESA = x.EMPRESA and FME.REVENDA = x.REVENDA and FME.NUMERO_NOTA_FISCAL = x.TITULO and FME.CLIENTE = x.CLIENTE and x.TIPO = 'CP')) SIT_VEIC, 
        V.NUMERO_NOTA_NFENTRADA, (select FMC.DTA_DOCUMENTO from FAT_MOVIMENTO_CAPA FMC where V.EMPRESA_NFENTRADA = FMC.EMPRESA and V.REVENDA_NFENTRADA = FMC.REVENDA and V.NUMERO_NOTA_NFENTRADA = FMC.NUMERO_NOTA_FISCAL and V.SERIE_NOTA_NFENTRADA = FMC.SERIE_NOTA_FISCAL and V.TIPO_TRANSACAO_NFENTRADA = FMC.TIPO_TRANSACAO and V.CONTADOR_NFENTRADA = FMC.CONTADOR ) DTA_DOCUMENTO_FABRICA, (select GEM.NOME_MARCA from GER_MARCA GEM where GEM.MARCA = FA.MARCA) NOME_MARCA, V.VEI_OBS, V.Empresa_Nfentrada, V.Revenda_Nfentrada 
        FROM VEI_VEICULO V, OFI_FICHA_SEGUIMENTO F, VEI_MODELO M, VEI_FAMILIA FA
        WHERE V.CHASSI = F.CHASSI AND V.EMPRESA = M.EMPRESA AND V.MODELO = M.MODELO AND FA.EMPRESA = M.EMPRESA AND FA.FAMILIA = M.FAMILIA AND V.SITUACAO IN (SELECT SITUACAO FROM VEI_SITUACAO WHERE EMPRESA = M.EMPRESA AND LOCALIZACAO = 'E') 
        AND EXISTS (SELECT S1.SITUACAO FROM VEI_SITUACAO S1 WHERE S1.EMPRESA = V.EMPRESA AND S1.SITUACAO = V.SITUACAO AND S1.LOCALIZACAO = 'E') 
        AND V.NOVO_USADO in ('N', 'U') and FA.EMPRESA IN V.EMPRESA 
      ) S1       
      join
      (
       select  fc2.empresa, fc2.revenda, fc2.numero_nota_fiscal, fc2.cliente, cl2.nome nome_cliente, fc2.tot_nota_fiscal, fc2.tipo_transacao
       from VEI_VEICULO V2 
       join fat_movimento_capa fc2 on v2.EMPRESA_NFENTRADA = fc2.empresa and v2.REVENDA_NFENTRADA = fc2.revenda and v2.NUMERO_NOTA_NFENTRADA = fc2.numero_nota_fiscal 
       join fat_cliente cl2 on fc2.cliente = cl2.cliente
       and v2.SERIE_NOTA_NFENTRADA = fc2.serie_nota_fiscal and v2.TIPO_TRANSACAO_NFENTRADA = fc2.tipo_transacao and v2.CONTADOR_NFENTRADA = fc2.contador
      ) f1 on s1.empresa_nfentrada = f1.empresa and s1.revenda_nfentrada = f1.revenda and s1.numero_nota_nfentrada = f1.numero_nota_fiscal
      
      join
      ( 
        select u.ID, e.cnpj, ge.empresa, ge.revenda, e.des_empresa, n.DES_NEGOCIO, u.ID_NUCLEO
        from degmonaco.j_v_deg_unidade u
        join degmonaco.j_v_deg_empresa e on (e.id_unidade = u.ID)
        join degmonaco.j_v_deg_negocio n on (n.ID = u.ID_NEGOCIO)
        join cnp.ger_revenda ge on (ge.cnpj = e.cnpj)
      ) ss2 on (s1.empresa = ss2.empresa and s1.revenda = ss2.revenda)
      WHERE S1.SITUACAO IN ('ES','SD','TF','BL','ST')
      and S1.EMPRESA in (1,2,3,4,5,7,9,11,13)");}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}