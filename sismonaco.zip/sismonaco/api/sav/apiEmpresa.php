<?php

namespace api\sav;

use lib\Model;
use obj\sav\Empresa;
use helper\PrepareSQL;
use helper\Funcoes;

class apiEmpresa extends Model {
	
	public function getEmpresa(Empresa $obj) {
		return  $this->First($this->Select("SELECT e.empresa, em.des_empresa, e.gerente_novos, e.gerente_usados, 
		e.diretor, u3.nome as nome_diretor, u.nome as nome_novos, u.cpf as cpf_novos, u2.nome as nome_usados, 
		u2.cpf as cpf_usados, e.empresa_apollo, e.revenda_apollo, e.dn, e.descricao, e.uf, e.cidade 
		FROM sav_empresa e
		JOIN sis_empresa em ON e.empresa = em.empresa
		JOIN sis_usuario u ON e.gerente_novos = u.usuario 
        JOIN sis_usuario u2 ON e.gerente_usados = u2.usuario 
        JOIN sis_usuario u3 ON e.diretor = u3.usuario WHERE e.empresa = '{$obj->empresa}'"));
	}
	
	public function filtroEmpresa($c, $coluna = NULL, $val = NULL) {
		$funcoes = new Funcoes();
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		$condicao = array(
			'1'	=> " WHERE LOWER(e.{$coluna}) = '{$val}' ",
			'2' => " WHERE LOWER(e.{$coluna}) LIKE '%{$val}%' ",
			'3' => " "
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT e.empresa, em.des_empresa, e.gerente_novos, e.gerente_usados, e.diretor,  u3.nome as nome_diretor, 
		u.nome as nome_novos, u.cpf as cpf_novos, u2.nome as nome_usados, u2.cpf as cpf_usados, e.empresa_apollo, 
		e.revenda_apollo, e.dn, e.descricao, e.uf, e.cidade 
		FROM sav_empresa e
		JOIN sis_empresa em ON e.empresa = em.empresa
		JOIN sis_usuario u ON e.gerente_novos = u.usuario 
        JOIN sis_usuario u2 ON e.gerente_usados = u2.usuario
		JOIN sis_usuario u3 ON e.diretor = u3.usuario
		{$condicao[$c]}ORDER BY e.empresa_apollo, e.revenda_apollo) R ) R2");
	}
	
	public function addEmpresa(Empresa $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->descricao = strtoupper($funcoes->retiraAcentos(trim($obj->descricao)));
		$obj->uf = strtoupper($funcoes->retiraAcentos(trim($obj->uf)));
		$obj->cidade = strtoupper($funcoes->retiraAcentos(trim($obj->cidade)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'sav_empresa');
	}
	
	public function editEmpresa(Empresa $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->descricao = strtoupper($funcoes->retiraAcentos(trim($obj->descricao)));
		$obj->uf = strtoupper($funcoes->retiraAcentos(trim($obj->uf)));
		$obj->cidade = strtoupper($funcoes->retiraAcentos(trim($obj->cidade)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'empresa';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('empresa' => $obj['empresa']), 'sav_empresa');
	}
	
	public function delEmpresa(Empresa $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('empresa' => $obj->empresa), 'sav_empresa');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}