<?php

namespace api\sav;

use lib\Model;

class apiDashboard extends Model {

	public function getVendedores($empresa) {
		return  $this->Select("select p.vendedor, u.nome from sav_proposta p
	    join sis_usuario u on p.vendedor = u.usuario
	    where p.empresa = '{$empresa}' and p.situacao in (7,9)
	    group by p.vendedor,u.nome order by u.nome");
	}
	
	/*public function getDashboard($empresa,$dashboard,$data,$vendedor) {
		if ($dashboard == "comissao"){
			if ($vendedor != "todos"){
				$ve = "p.vendedor = '{$vendedor}' and ";
			}else{
				$ve = "";
			}
			return  $this->Select("select p.vendedor_nome, sum(p.val_venda) val_venda, sum(p.comissao) val_comissao, sum(p.lucro_bruto) margem, 
			round(sum(p.lucro_bruto)/sum(p.val_venda) * 100,2) as rent from sav_proposta p 
			where p.empresa = '{$empresa}' and p.situacao in (7,9) and {$ve}
			to_char(to_date(p.dta_conclusao,'dd/mm/yyyy'),'mm/yyyy') = '{$data}'
			group by p.vendedor_nome
			order by p.vendedor_nome");
		}
	}*/
	
	public function getDashboard($empresa,$dashboard,$data,$vendedor) {
		if ($dashboard == "comissao"){
			if ($vendedor != "todos"){
				$ve = "p.vendedor = '{$vendedor}' and ";
			}else{
				$ve = "";
			}
			return  $this->Select("select p1.vendedor, p1.nome vendedor_nome, p2.val_venda + p3.val_venda val_venda, 
			p2.val_comissao + p3.val_comissao val_comissao, p2.margem + p3.margem margem,
		    case when ( p2.margem + p3.margem) = 0 then 0 
            else round(((p2.margem + p3.margem) / (p2.val_venda + p3.val_venda)) * 100 ,2) end rent
			
			from

			(select p.vendedor, u.nome from sav_proposta p
			join sis_usuario u on p.vendedor = u.usuario
			where p.empresa = '{$empresa}' and {$ve}p.situacao in (7,9)
			group by p.vendedor,u.nome) p1
			
			left join (select v.vendedor, nvl(p.val_venda,0) val_venda, nvl(p.val_comissao,0) val_comissao,
			nvl(p.margem,0) margem from
			(select p.vendedor, u.nome from sav_proposta p
			join sis_usuario u on p.vendedor = u.usuario
			where p.empresa = '{$empresa}' and {$ve}p.situacao in (7,9)
			group by p.vendedor,u.nome ) v
			left join(
			select p.vendedor,p.vendedor_nome,
			sum(p.val_venda) val_venda, 
			sum(p.comissao) val_comissao, 
			sum(p.lucro_bruto) margem from sav_proposta p
			where p.empresa = '{$empresa}' and {$ve}p.situacao in (7,9) and
			to_char(to_date(p.dta_conclusao,'dd/mm/yyyy'),'mm/yyyy') = '{$data}'
			group by p.vendedor, p.vendedor_nome) p on v.vendedor = p.vendedor) p2 on p1.vendedor = p2.vendedor
			
			left join (
			select v.vendedor, nvl(p.val_venda,0) val_venda, nvl(p.val_comissao,0) val_comissao,
			nvl(p.margem,0) margem from
			(select p.vendedor, u.nome from sav_proposta p
			join sis_usuario u on p.vendedor = u.usuario
			where p.empresa = '{$empresa}' and {$ve}p.situacao in (7,9)
			group by p.vendedor,u.nome) v
			left join(
			select p.vendedor,p.vendedor_nome,
			nvl(sum(-1 * p.val_venda),0) val_venda, 
			nvl(sum(-1 * p.comissao),0) val_comissao, 
			nvl(sum(-1 * p.lucro_bruto),0) margem
			from sav_proposta p
			join sav_empresa e on p.empresa = e.empresa
			join sis_usuario u on p.gerente = u.usuario
			left join fat_movimento_capa fmc on (e.empresa_apollo = fmc.empresa and e.revenda_apollo = fmc.revenda and fmc.numero_nota_fiscal = p.nf_saida and fmc.tipo_transacao = 'C21')
			left join fat_movimento_capa fmc2 on (fmc.empresa = fmc2.empresa and fmc.revenda = fmc2.revenda and fmc.fatoperacao = fmc2.fatoperacao_original)
			where  p.empresa = '{$empresa}' and p.situacao in (7,9) and to_char(fmc2.dta_entrada_saida,'mm/yyyy') = '{$data}'
			group by p.vendedor,p.vendedor_nome) p on v.vendedor = p.vendedor) p3 on p1.vendedor = p3.vendedor
			order by p1.nome");
		}
		
		if ($dashboard == "fechamento"){
			return  $this->Select("select p1.tipo_venda, p2.val_venda + p3.val_venda val_venda,
			p2.val_comissao + p3.val_comissao val_comissao, p2.margem + p3.margem margem,
            case when ( p2.margem + p3.margem) = 0 then 0 
       		else round(((p2.margem + p3.margem) / (p2.val_venda + p3.val_venda)) * 100 ,2) end rent
			
			from
			
			(select p.tipo_venda from sav_proposta p
			where p.empresa = '{$empresa}' and p.situacao in (7,9)
			group by p.tipo_venda order by p.tipo_venda) p1
			
			left join (select v.tipo_venda, nvl(p.val_venda,0) val_venda, nvl(p.val_comissao,0) val_comissao,
			nvl(p.margem,0) margem from
			(select p.tipo_venda from sav_proposta p
			where p.empresa = '{$empresa}' and p.situacao in (7,9)
			group by p.tipo_venda) v
			left join(
			select p.tipo_venda,
			sum(p.val_venda) val_venda,
			sum(p.comissao) val_comissao,
			sum(p.lucro_bruto) margem from sav_proposta p
			where p.empresa = '{$empresa}' and p.situacao in (7,9) and
			to_char(to_date(p.dta_conclusao,'dd/mm/yyyy'),'mm/yyyy') = '{$data}'
			group by p.tipo_venda) p on v.tipo_venda = p.tipo_venda) p2 on p1.tipo_venda = p2.tipo_venda
			
			left join (
			select v.tipo_venda, nvl(p.val_venda,0) val_venda, nvl(p.val_comissao,0) val_comissao,
			nvl(p.margem,0) margem from
			(select p.tipo_venda from sav_proposta p
			where p.empresa = '{$empresa}' and p.situacao in (7,9)
			group by p.tipo_venda) v
			left join(
			select p.tipo_venda,
			nvl(sum(-1 * p.val_venda),0) val_venda,
			nvl(sum(-1 * p.comissao),0) val_comissao,
			nvl(sum(-1 * p.lucro_bruto),0) margem
			from sav_proposta p
			join sav_empresa e on p.empresa = e.empresa
			left join fat_movimento_capa fmc on (e.empresa_apollo = fmc.empresa and e.revenda_apollo = fmc.revenda and fmc.numero_nota_fiscal = p.nf_saida and fmc.tipo_transacao = 'C21')
			left join fat_movimento_capa fmc2 on (fmc.empresa = fmc2.empresa and fmc.revenda = fmc2.revenda and fmc.fatoperacao = fmc2.fatoperacao_original)
			where  p.empresa = '{$empresa}' and p.situacao in (7,9) and to_char(fmc2.dta_entrada_saida,'mm/yyyy') = '{$data}'
			group by p.tipo_venda) p on v.tipo_venda = p.tipo_venda) p3 on p1.tipo_venda = p3.tipo_venda
			order by p1.tipo_venda");
		}
	}
	
	/*public function getRelatorio($empresa,$dashboard,$data,$vendedor) {
		if ($dashboard == "comissao"){
			if ($vendedor != "todos"){
				$ve = "p.vendedor = '{$vendedor}' and ";
			}else{
				$ve = "";
			}
			return  $this->Select("select u.nome as nome_gerente, p.* from sav_proposta p
			join sis_usuario u on p.gerente = u.usuario
			where p.empresa = '{$empresa}' and p.situacao in (7,9) and {$ve}to_char(to_date(p.dta_conclusao,'dd/mm/yyyy'),'mm/yyyy') = '{$data}' order by p.vendedor_nome, p.proposta");
		}
	}*/
	
	public function getRelatorio($empresa,$dashboard,$data,$vendedor) {
		if ($dashboard == "comissao"){
			if ($vendedor != "todos"){
				$ve = "p.vendedor = '{$vendedor}' and ";
			}else{
				$ve = "";
			}
			return  $this->Select("select u.nome as nome_gerente, fmc2.numero_nota_fiscal as nf_devolucao, 
			fmc2.dta_entrada_saida as dta_devolucao,
			case 
			  when to_char(to_date(p.dta_conclusao,'dd/mm/yyyy'),'mm/yyyy') = '$data' 
			    and to_char(fmc2.dta_entrada_saida,'mm/yyyy') = '$data' then 'A' 
			  when to_char(fmc2.dta_entrada_saida,'mm/yyyy') = '$data' then 'S'
			    else 'N' end devolucao, p.* 
			from sav_proposta p
			join sav_empresa e on p.empresa = e.empresa
			join sis_usuario u on p.gerente = u.usuario
			left join fat_movimento_capa fmc on (e.empresa_apollo = fmc.empresa and e.revenda_apollo = fmc.revenda and fmc.numero_nota_fiscal = p.nf_saida and fmc.tipo_transacao = 'C21')
			left join fat_movimento_capa fmc2 on (fmc.empresa = fmc2.empresa and fmc.revenda = fmc2.revenda and fmc.fatoperacao = fmc2.fatoperacao_original)
			where p.empresa = '{$empresa}' and p.situacao in (7,9) and {$ve}((to_char(to_date(p.dta_conclusao,'dd/mm/yyyy'),'mm/yyyy') = '$data') or (to_char(fmc2.dta_entrada_saida,'mm/yyyy') = '$data'))
			order by p.vendedor_nome, p.proposta");
		}
		
		if ($dashboard == "fechamento"){
			return  $this->Select("select u.nome as nome_gerente, fmc.nf_devolucao, fmc.dta_devolucao, v.dta_entrada,
	        case when fmdl.nf_vci is null then '' else 'V' end vci, fmdl.dta_emissao_vci,fmdl.vci_departamento, fmdl.nf_vci, 
	        fmdl.nf_prefeitura, fmdl.val_vci, case when to_char(to_date(p.dta_conclusao,'dd/mm/yyyy'),'mm/yyyy') = '{$data}'
	        and to_char(fmc.dta_devolucao,'mm/yyyy') = '{$data}' then 'A' when to_char(fmc.dta_devolucao,'mm/yyyy') = '{$data}' then 'S'
	      	else 'N' end devolucao, p.* from sav_proposta p
	        join sis_usuario u on p.gerente = u.usuario
	        left join (select fmc.numero_nota_fiscal nf_saida, fmc.dta_entrada_saida dta_saida, fmc2.numero_nota_fiscal nf_devolucao, fmc2.dta_entrada_saida dta_devolucao 
	        	from fat_movimento_capa fmc join sav_empresa e on e.empresa = '{$empresa}' left join fat_movimento_capa fmc2 on (fmc.empresa = fmc2.empresa 
	        	and fmc.revenda = fmc2.revenda and fmc.fatoperacao = fmc2.fatoperacao_original)
	        	where fmc.empresa = e.empresa_apollo and fmc.revenda = e.revenda_apollo and fmc.status = 'F' and fmc.tipo_transacao in ('C21','U21') 
	        	and (to_char(fmc.dta_entrada_saida, 'mm/yyyy') = '{$data}' or to_char(fmc2.dta_entrada_saida, 'mm/yyyy') = '{$data}')) fmc
	        	on p.nf_saida = fmc.nf_saida 
			left join (select fmc.empresa, fmc.revenda, fmdl.descricao, fmc.numero_nota_fiscal nf_vci, 
	      		substr(fmc.nfse_chave_acesso,8) nf_prefeitura, fmc.departamento vci_departamento, 
	      		fmc.tot_nota_fiscal val_vci, fmc.dta_entrada_saida dta_emissao_vci 
	      		from fat_movimento_capa fmc join sav_empresa e on e.empresa = '{$empresa}' join fat_movimento_desc_livre fmdl on 
	      		(fmc.empresa = fmdl.empresa and fmc.revenda = fmdl.revenda and 
	      		fmc.numero_nota_fiscal = fmdl.numero_nota_fiscal and fmc.serie_nota_fiscal = fmdl.serie_nota_fiscal 
	     	    and fmc.tipo_transacao = fmdl.tipo_transacao)
	      		where fmc.empresa = e.empresa_apollo and fmc.revenda = e.revenda_apollo and to_char(fmc.dta_entrada_saida, 'mm/yyyy') = '{$data}' 
	      		and fmc.tipo_transacao = 'L21' and fmc.status = 'F') fmdl on (fmdl.descricao like ('%'||substr(p.chassi,-8,8)||'%'))
	      	left join vei_veiculo v on (p.nf_entrada = v.numero_nota_nfentrada and p.chassi = v.chassi)
	      	where p.empresa = '{$empresa}' and p.situacao in (7,9) and ((to_char(to_date(p.dta_conclusao,'dd/mm/yyyy'),'mm/yyyy') = '{$data}') or (to_char(fmc.dta_devolucao,'mm/yyyy') = '{$data}'))
	      	order by p.vendedor_nome, p.proposta");
		}
	}
}