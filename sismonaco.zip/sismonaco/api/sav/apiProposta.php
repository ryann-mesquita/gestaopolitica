<?php

namespace api\sav;

use lib\Model;
use obj\sav\Proposta;
use helper\PrepareSQL;
use helper\Funcoes;

class apiProposta extends Model {
	
	public function getProposta(Proposta $obj) {
		return  $this->First($this->Select("SELECT p.empresa, p.proposta, p.proposta_apollo, p.usuario, u.nome as nome_criador, 
        p.gerente, u2.cpf as cpf_gerente, u2.nome as nome_gerente, p.vendedor, p.vendedor_nome, p.cliente, p.cliente_nome, 
		p.nf_entrada, p.nf_saida, p.nf_direta, p.tipo_renavam, p.chassi, p.modelo, p.tipo_venda, p.val_emissao_nf, 
		p.val_nf_fabrica, p.val_venda, p.comissao_fabrica, p.val_comissao_fabrica, val_dif_nffabrica_nfvenda, 
		p.val_outras_receitas_op, p.perc_icms, p.val_icms, p.val_custo_operacional, 
		p.val_frete, p.val_outros_custos, p.val_pis_cofins_compra, p.val_juros_op_cheque, p.cmv, p.lucro_bruto, p.lucro_liquido, 
		p.perc_lucro, p.val_fabrica, p.perc_credito_icms, p.val_credito_icms, p.val_implemento, p.perc_icms_imp, p.val_icms_imp, 
		p.perc_bonus_fab, p.credito_bonus, p.bonus_fabrica, p.custo_veiculo, p.desconto_comissao, p.veiculo_usado, p.base_calculo, 
		p.perc_comissao, p.bonificacao, p.comissao, p.obs1, p.obs2, p.obs3, p.des_pagamento, p.des_frete, p.des_outros_custos, p.des_implemento, 
		p.des_veiculo_usado, p.des_bonus, p.des_vendedor, p.dta_inclusao, p.dta_conclusao, p.dta_ult_alteracao, p.situacao FROM sav_proposta p
		JOIN sis_empresa e ON p.empresa = e.empresa
		JOIN sis_usuario u ON p.usuario = u.usuario
		JOIN sis_usuario u2 ON p.gerente = u2.usuario 
		WHERE p.proposta = '{$obj->proposta}' AND p.empresa = '{$obj->empresa}' "));
	}
	
	public function filtroProposta($situacao, $c, $empresa, $coluna = NULL, $val = NULL, $de = NULL, $ate = NULL) {
		$val = strtolower(trim($val));
		if ($situacao != 'tudo'){
			$sit = " WHERE p.situacao = '{$situacao}' AND ";
		}else{
			$sit =  "WHERE ";
		}
		
		$condicao = array(
			'1'	=> "LOWER(p.{$coluna}) = '{$val}' AND",
			'2' => "LOWER(p.{$coluna}) LIKE '%{$val}%' AND",
			'3'	=> "",
			'4' => "TO_DATE(TO_CHAR(TO_DATE({$coluna}, 'dd/mm/yyyy hh24:mi:ss'), 'dd/mm/yyyy'), 'dd/mm/yyyy') BETWEEN TO_DATE('{$de}','dd/mm/yyyy') AND TO_DATE('{$ate}','dd/mm/yyyy') AND",
			'5'	=> "p.proposta_apollo is null AND"
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT p.empresa, p.proposta, p.proposta_apollo, p.usuario, u.nome as nome_criador, p.gerente, u2.cpf as cpf_gerente, 
		u2.nome as nome_gerente, p.vendedor, p.vendedor_nome, p.cliente, p.cliente_nome, p.nf_entrada, p.nf_saida, p.nf_direta, p.tipo_renavam, p.chassi, p.modelo, 
		p.tipo_venda, p.val_emissao_nf, p.val_nf_fabrica, p.val_venda, p.comissao_fabrica, p.val_comissao_fabrica, val_dif_nffabrica_nfvenda, 
		p.val_outras_receitas_op, p.perc_icms, p.val_icms, p.val_custo_operacional, p.val_frete, p.val_outros_custos, 
		p.val_pis_cofins_compra, p.val_juros_op_cheque, p.cmv, p.lucro_bruto, p.lucro_liquido, p.perc_lucro, p.val_fabrica, 
		p.perc_credito_icms, p.val_credito_icms, p.val_implemento, p.perc_icms_imp, p.val_icms_imp, p.perc_bonus_fab, 
		p.credito_bonus, p.bonus_fabrica, p.custo_veiculo, p.desconto_comissao, p.veiculo_usado, p.base_calculo, 
		p.perc_comissao, p.bonificacao, p.comissao, p.obs1, p.obs2, p.obs3, p.des_pagamento, p.des_frete, p.des_outros_custos, p.des_implemento, 
		p.des_veiculo_usado, p.des_bonus, p.des_vendedor, p.dta_inclusao, p.dta_conclusao, p.dta_ult_alteracao, p.situacao FROM sav_proposta p
		JOIN sis_empresa e ON p.empresa = e.empresa
		JOIN sis_usuario u ON p.usuario = u.usuario
		JOIN sis_usuario u2 ON p.gerente = u2.usuario {$sit}{$condicao[$c]} p.empresa = '{$empresa}' ORDER BY p.proposta DESC) R ) R2");
	}
	
	public function addProposta(Proposta $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'sav_proposta','proposta','',"sav_proposta_{$obj['empresa']}");
	}
	
	public function editProposta(Proposta $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'proposta' && $v != 'empresa';}, ARRAY_FILTER_USE_KEY);
		$set = array_replace($set,array_fill_keys(array_keys($set, "excluir"), null));
		return $prepare->PrepareUpdate($set,array('proposta' => $obj['proposta'], 'empresa' => $obj['empresa']), 'sav_proposta');
	}
	
	public function delProposta(Proposta $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('proposta' => $obj->proposta, 'empresa' => $obj->empresa), 'sav_proposta');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}