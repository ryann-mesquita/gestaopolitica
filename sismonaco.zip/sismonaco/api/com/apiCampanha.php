<?php

namespace api\com;

use lib\Model;
use obj\com\Campanha;
use helper\PrepareSQL;
use helper\Funcoes;
use obj\com\Regra;

class apiCampanha extends Model {

	public function getCampanha(Campanha $obj, $empresa) {
		return  $this->First($this->Select("SELECT c.campanha, c.des_reduzida, c.des_campanha, c.empresa, e.des_empresa
		FROM com_campanha c
		JOIN sis_empresa e on e.empresa = c.empresa
		JOIN ger_revenda r on e.cnpj = r.cnpj
		WHERE r.empresa = '{$empresa}' AND c.campanha = '{$obj->campanha}'"));
	}

	public function filtroCampanha($c, $empresa, $coluna = NULL, $val = NULL) {
		$funcoes = new Funcoes();
		$val = strtolower(trim($funcoes->retiraAcentos($val)));
		$condicao = array(
			'1'	=> " AND LOWER(c.{$coluna}) = '{$val}' ",
			'2' => " AND LOWER(c.{$coluna}) LIKE '%{$val}%' ",
			'3'	=> " ",
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT c.campanha, c.des_reduzida, c.des_campanha, c.empresa, e.des_empresa
		FROM com_campanha c
		JOIN sis_empresa e on e.empresa = c.empresa
		JOIN ger_revenda r on e.cnpj = r.cnpj
		WHERE r.empresa = '{$empresa}'{$condicao[$c]}ORDER BY c.empresa DESC, c.campanha DESC) R ) R2");
	}
	
	public function getRegra(Campanha $obj){
		return $this->Select("SELECT cr.* FROM com_campanha_regra cr WHERE cr.campanha = '$obj->campanha' ORDER BY cr.regra ASC");
	}

	public function addCampanha(Campanha $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'com_campanha','campanha');
	}
	
	public function addRegra(Regra $obj, $currval = NULL) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$obj = array_filter($obj, function($v){return $v != 'campanha';}, ARRAY_FILTER_USE_KEY);
		if ($currval != NULL){
			return $prepare->PrepareInsert($obj, 'com_campanha_regra',"",$currval);
		}else{
			return $prepare->PrepareInsert($obj, 'com_campanha_regra');
		}
	}

	public function editCampanha(Campanha $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'campanha';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('campanha' => $obj['campanha']), 'com_campanha');
	}
	
	public function editRegra(Regra $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'campanha' && $v != 'regra';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('campanha' => $obj['campanha'], 'regra' => $obj['regra']), 'com_campanha_regra');
	}

	public function delCampanha(Campanha $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('campanha' => $obj->campanha), 'com_campanha');
	}
	
	public function delTodasRegras(Campanha $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('campanha' => $obj->campanha), 'com_campanha_regra');
	}
	
	public function delRegra(Regra $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('campanha' => $obj->campanha, 'regra' => $obj->regra), 'com_campanha_regra');
	}

	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}