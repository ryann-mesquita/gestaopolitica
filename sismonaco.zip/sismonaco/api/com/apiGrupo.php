<?php

namespace api\com;

use lib\Model;
use obj\com\Grupo;
use helper\PrepareSQL;
use helper\Funcoes;

class apiGrupo extends Model {
	
	public function getGrupo(Grupo $obj) {
		return  $this->First($this->Select("SELECT g.tipo, t.des_tipo, g.empresa, e.des_empresa, g.grupo,
		g.des_grupo, g.des_formula, g.campo_formula 
		FROM com_grupo g 
		JOIN com_tipo t ON g.tipo = t.tipo
		JOIN sis_empresa e ON g.empresa = e.empresa
		WHERE e.empresa = '{$obj->empresa}' AND g.grupo = '{$obj->grupo}'"));
	}
	
	public function filtroGrupo($c, $empresa, $coluna = NULL, $val = NULL, $tipo = NULL) {
		$val = strtolower(trim($val));
		$condicao = array(
			'1'	=> " AND LOWER(g.{$coluna}) = '{$val}' ",
			'2' => " AND LOWER(g.{$coluna}) LIKE '%{$val}%' ",
			'3'	=> " ",
			'4'	=> " AND g.tipo = '{$tipo}' AND LOWER(g.{$coluna}) LIKE '%{$val}%' ",
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT g.tipo, t.des_tipo, g.empresa, e.des_empresa, g.grupo, 
		g.des_grupo, g.des_formula, g.campo_formula
		FROM com_grupo g
		JOIN com_tipo t ON g.tipo = t.tipo
        JOIN sis_empresa e ON g.empresa = e.empresa 
		WHERE g.empresa = '{$empresa}'{$condicao[$c]}ORDER BY g.des_grupo ASC) R ) R2");
	}
	
	public function addGrupo(Grupo $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'com_grupo','grupo');
	}
	
	public function editGrupo(Grupo $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'grupo';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('grupo' => $obj['grupo']), 'com_grupo');
	}
	
	public function delGrupo(Grupo $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('grupo' => $obj->grupo), 'com_grupo');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}