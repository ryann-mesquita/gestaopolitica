<?php

namespace api\com;

use lib\Model;

class apiIndex extends Model {
	
	public function getCalculo($sq) {
		return  $this->Select("{$sq}");
	}
	
	public function getPrecomaoobra($emprev, $politica){
		return $this->First($this->Select("select pp.prc_publico from ofi_politica_preco pp 
		where pp.empresa||'.'||pp.revenda = '{$emprev}' and pp.politica_preco = '{$politica}'
		group by pp.prc_publico"));
	}
	
	public function getParametros($emprev, $data){
		return $this->First($this->Select("select * from com_parametros mo
		where mo.empresa||'.'||mo.revenda = '{$emprev}' and mo.mes||'/'||mo.ano = '{$data}'"));
	}
	
	public function getCalendario($data, $calendario){
		return $this->Select("select f.dataferiado from metadados.rhferiados f
		where to_char(f.dataferiado,'mm/yyyy') = '{$data}' and f.calendario = '{$calendario}'");
	}
	
	public function getComissao($grupo, $emp, $rev, $tip, $por, $auto, $produtividade, $parametros, $i, $campo_formula, $de, $ate, $empresa, $tipo, $vendedor, $considerar, $equipe, $departamento, $equipen, $equipeu, $equiped){
		if ($emp == 13){
			if ($tip == 5 || $tip == 7){
				if ($por == "FAI"){
					$case = "case ";
					$casep = "case ";
					$premio1 = (isset($campo_formula['PREMIO1'])) ? ($campo_formula['PREMIO1'] > 0) ? $campo_formula['PREMIO1'] : 0 : 0;
					$premio2 = (isset($campo_formula['PREMIO2'])) ? ($campo_formula['PREMIO2'] > 0) ? $campo_formula['PREMIO2'] : 0 : 0;
					$premio3 = (isset($campo_formula['PREMIO3'])) ? ($campo_formula['PREMIO3'] > 0) ? $campo_formula['PREMIO3'] : 0 : 0;
					$premio4 = (isset($campo_formula['PREMIO4'])) ? ($campo_formula['PREMIO4'] > 0) ? $campo_formula['PREMIO4'] : 0 : 0;
					if ($auto == "S"){
						if ($tip == 5){
							$per1 = ($parametros->MEC_PROD1 > 0) ? ($parametros->MEC_PROD1/100) : 0;
							$per2 = ($parametros->MEC_PROD2 > 0) ? ($parametros->MEC_PROD2/100) : 0;
							$per3 = ($parametros->MEC_PROD3 > 0) ? ($parametros->MEC_PROD3/100) : 0;
							$per4 = ($parametros->MEC_PROD4 > 0) ? ($parametros->MEC_PROD4/100) : 0;
						}else{
							$per1 = ($parametros->ELE_PROD1 > 0) ? ($parametros->ELE_PROD1/100) : 0;
							$per2 = ($parametros->ELE_PROD2 > 0) ? ($parametros->ELE_PROD2/100) : 0;
							$per3 = ($parametros->ELE_PROD3 > 0) ? ($parametros->ELE_PROD3/100) : 0;
							$per4 = ($parametros->ELE_PROD4 > 0) ? ($parametros->ELE_PROD4/100) : 0;
						}
						$fai_de1 = 0;
						$fai_ate1 = $produtividade * $per1;
						$fai_de2 = ($produtividade * $per1) + 0.01;
						$fai_ate2 = $produtividade * $per2;
						$fai_de3 = ($produtividade * $per2) + 0.01;
						$fai_ate3 = $produtividade * $per3;
						$fai_de4 = ($produtividade * $per3) + 0.01;
						$fai_ate4 = $produtividade;
						
						if (isset($campo_formula['FAI_COMISSAO1'])){
							$case .= "when x1.valor_calc between {$fai_de1} and {$fai_ate1} then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO1'])." ";
							$com = $campo_formula['FAI_COMISSAO1'];
							$casep .= "when x1.valor_calc between {$fai_de1} and {$fai_ate1} then 0 ";
						}
						if (isset($campo_formula['FAI_COMISSAO2'])){
							$case .= "when x1.valor_calc between {$fai_de2} and {$fai_ate2} then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO2'])." ";
							$com = $campo_formula['FAI_COMISSAO2'];
							$casep .= "when x1.valor_calc between {$fai_de2} and {$fai_ate2} then ".str_replace(",", ".", $premio1)." ";
							$pre = $premio1;
						}
						if (isset($campo_formula['FAI_COMISSAO3'])){
							$case .= "when x1.valor_calc between {$fai_de3} and {$fai_ate3} then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO3'])." ";
							$com = $campo_formula['FAI_COMISSAO3'];
							$casep .= "when x1.valor_calc between {$fai_de3} and {$fai_ate3} then ".str_replace(",", ".", $premio2)." ";
							$pre = $premio2;
						}
						if (isset($campo_formula['FAI_COMISSAO4'])){
							$case .= "when x1.valor_calc between {$fai_de4} and {$fai_ate4} then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO4'])." ";
							$com = $campo_formula['FAI_COMISSAO4'];
							$casep .= "when x1.valor_calc between {$fai_de4} and {$fai_ate4} then ".str_replace(",", ".", $premio3)." ";
							$pre = $premio3;
						}
						$case .= "when x1.valor_calc > 0 then ".str_replace(",", ".", $com)." ";
						$casep .= "when x1.valor_calc > 0 then ".str_replace(",", ".", $pre)." "; 
					}else{
						$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE1'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE1'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO1'])."";
						$com = $campo_formula['FAI_COMISSAO1'];
						$casep .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE1'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE1'])." then 0";
						if (isset($campo_formula["FAI_DE2"])){
							$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE2'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE2'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO2'])."";
							$com = $campo_formula['FAI_COMISSAO2'];
							$casep .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE2'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE2'])." then ".str_replace(",", ".", $premio1)."";
							$pre = $premio1;
						}
						if (isset($campo_formula["FAI_DE3"])){
							$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE3'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE3'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO3'])."";
							$com = $campo_formula['FAI_COMISSAO3'];
							$casep .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE3'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE3'])." then ".str_replace(",", ".", $premio2)."";
							$pre = $premio2;
						}
						if (isset($campo_formula["FAI_DE4"])){
							$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE4'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE4'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO4'])."";
							$com = $campo_formula['FAI_COMISSAO4'];
							$casep .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE4'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE4'])." then ".str_replace(",", ".", $premio3)."";
							$pre = $premio3;
						}
						if (isset($campo_formula["FAI_DE5"])){
							$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE5'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE5'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO5'])."";
							$com = $campo_formula['FAI_COMISSAO5'];
							$casep .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE5'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE5'])." then ".str_replace(",", ".", $premio4)."";
							$pre = $premio4;
						}
						$case .= "when x1.valor_calc > 0 then ".str_replace(",", ".", $com)." "; 
						$casep .= "when x1.valor_calc > 0 then ".str_replace(",", ".", $pre)." "; 
					}
					$casem = "case  ";
					if (in_array("N", $considerar)){
						$casem .= "when x1.tipo_item = 'N' then {$campo_formula['META_NOVOS']} ";
					}
					if (in_array("U", $considerar)){
						$casem .= "when x1.tipo_item = 'U' then {$campo_formula['META_USADOS']} ";
					}
					if (in_array("D", $considerar)){
						$casem .= "when x1.tipo_item = 'D' then {$campo_formula['META_DIRETO']} ";
					}
					if (in_array("C", $considerar)){
						$casem .= "when x1.tipo_item = 'C' then {$campo_formula['META_CONSORCIO']} ";
					}
					if (in_array("P", $considerar)){
						$casem .= "when x1.tipo_item = 'P' then {$campo_formula['META_PECAS']} ";
					}
					if (in_array("S", $considerar)){
						$casem .= "when x1.tipo_item = 'S' then {$campo_formula['META_MAODEOBRA']} ";
					}
					$case .= "else  0 end pct_comissao";
					$casep .= "else  0 end premio";
					$casem .= "else  0 end metadados";
					$metapremio = (isset($campo_formula['META_PREMIO'])) ? ($campo_formula['META_PREMIO'] != "") ? $campo_formula['META_PREMIO'] : 0 : 0;
					
					return "select {$grupo} grupo, b{$i}.empresa, b{$i}.usuario, gu.nome, b{$i}.tipo_item, b{$i}.mes_referencia,
							b{$i}.ano_referencia, b{$i}.valor_faturado, b{$i}.val_desconto, b{$i}.valor_total, to_char(b{$i}.pct_comissao) pct_comissao, 
							b{$i}.metadados, to_char(round((b{$i}.valor_total*b{$i}.pct_comissao)/100,2)) valor_comissao, to_char(b{$i}.premio) premio,
							{$metapremio} metapremio, gu.cpf
							from
							(
								select x1.empresa, x1.usuario, x1.tipo_item, x1.mes_referencia, x1.ano_referencia,
								to_char(sum(x1.valor_faturado)) valor_faturado, to_char(sum(x1.val_desconto)) val_desconto, to_char(sum(x1.valor_faturado)-sum(x1.val_desconto)) valor_total,
								{$case}, {$casep}, {$casem}
								from
								(
									select a1.empresa, a1.revenda, a1.nome, a1.usuario, a1.tipo_item, a1.mes_referencia, a1.ano_referencia,
									a1.valor_faturado, nvl(a2.val_desconto,0) val_desconto, a1.valor_faturado-nvl(a2.val_desconto,0) valor_total,
									(
										select valor_calc 
										from (
											    select a1.usuario, a1.valor_faturado-nvl(a2.val_desconto,0) valor_calc
												from 
												(
													select s1.* from(select m.usuario, sum(m.valor) valor_faturado
													from qlik.j_v_fat_mecanico m
													where m.dta_referencia between
													to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
													and m.empresa||'.'||m.revenda in ('{$empresa}')
													and m.tipo_item in ('{$tipo}')
													and m.usuario in ({$vendedor})
													group by m.usuario) s1 
											 	) a1
											  	left join 
											  	(
													select c.usuario_fat, sum(c.val_desconto) val_desconto
											  		from qlik.j_v_cancelamento_nota c
											  		where c.dta_cancelamento_nota between
											 		to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
											  		and c.empresa||'.'||c.revenda in ('{$empresa}')
											  		and c.tipo in ('{$tipo}') group by c.usuario_fat
												) a2
											  	on a1.usuario = a2.usuario_fat
										) calc where calc.usuario = a1.usuario
									) valor_calc
									from
									(
										select s1.*
										from
										(
											select m.empresa, m.revenda, m.usuario, m.nome_mecanico nome, m.mecanico, m.tipo_item, 
											m.mes_referencia, m.ano_referencia, sum(m.valor) valor_faturado
											from qlik.j_v_fat_mecanico m
											where m.dta_referencia between
											to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
											and m.empresa||'.'||m.revenda in ('{$empresa}')
											and m.tipo_item in ('{$tipo}')
											and m.usuario in ({$vendedor})
											group by m.empresa, m.revenda, m.usuario, m.nome_mecanico, m.mecanico,
											m.tipo_item, m.mes_referencia, m.ano_referencia
										) s1
									) a1
									left join
									(
										select c.empresa, c.revenda, c.usuario_fat, c.mecanico, c.numero_nota_fiscal, c.serie_nota_fiscal, c.mes_emissao, c.ano_emissao, 
										c.mes_cancelamento, c.ano_cancelamento, c.tipo, c.val_desconto
										from qlik.j_v_cancelamento_nota c
										where c.dta_cancelamento_nota between
										to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
										and c.empresa||'.'||c.revenda in ('{$empresa}')
										and c.tipo in ('{$tipo}')
									) a2
									on ( a1.empresa = a2.empresa and a1.revenda = a2.revenda
									and a1.mes_referencia = a2.mes_cancelamento and a1.ano_referencia = a2.ano_cancelamento
									and a1.tipo_item = a2.tipo and a1.mecanico = a2.mecanico )
								) x1 group by x1.empresa, x1.usuario, x1.tipo_item, x1.mes_referencia, x1.ano_referencia, x1.valor_calc
							) b{$i} join ger_usuario gu on b{$i}.usuario = gu.usuario union ";
				}elseif ($por == "TIP"){
					$case = "case  ";
					$casem = "case  ";
					if (in_array("N", $considerar)){
						$case .= "when x1.tipo_item = 'N' then ".str_replace(",", ".", $campo_formula['COMISSAO_NOVOS'])." ";
						$casem .= "when x1.tipo_item = 'N' then {$campo_formula['META_NOVOS']}";
					}
					if (in_array("U", $considerar)){
						$case .= "when x1.tipo_item = 'U' then ".str_replace(",", ".", $campo_formula['COMISSAO_USADOS'])." ";
						$casem .= "when x1.tipo_item = 'U' then {$campo_formula['META_USADOS']}";
					}
					if (in_array("D", $considerar)){
						$case .= "when x1.tipo_item = 'D' then ".str_replace(",", ".", $campo_formula['COMISSAO_DIRETO'])." ";
						$casem .= "when x1.tipo_item = 'D' then {$campo_formula['META_DIRETO']}";
					}
					if (in_array("C", $considerar)){
						$case .= "when x1.tipo_item = 'C' then ".str_replace(",", ".", $campo_formula['COMISSAO_CONSORCIO'])." ";
						$casem .= "when x1.tipo_item = 'C' then {$campo_formula['META_CONSORCIO']}";
					}
					if (in_array("P", $considerar)){
						$case .= "when x1.tipo_item = 'P' then ".str_replace(",", ".", $campo_formula['COMISSAO_PECAS'])." ";
						$casem .= "when x1.tipo_item = 'P' then {$campo_formula['META_PECAS']}";
					}
					if (in_array("S", $considerar)){
						$case .= "when x1.tipo_item = 'S' then ".str_replace(",", ".", $campo_formula['COMISSAO_MAODEOBRA'])." ";
						$casem .= "when x1.tipo_item = 'S' then {$campo_formula['META_MAODEOBRA']}";
					}
					$case .= "else  0 end pct_comissao";
					$casem .= "else  0 end metadados ";
					$metapremio = (isset($campo_formula['META_PREMIO'])) ? ($campo_formula['META_PREMIO'] != "") ? $campo_formula['META_PREMIO'] : 0 : 0;
					
					return "select {$grupo} grupo, b{$i}.empresa, b{$i}.usuario, gu.nome, b{$i}.tipo_item, b{$i}.mes_referencia,
							b{$i}.ano_referencia, b{$i}.valor_faturado, b{$i}.val_desconto, b{$i}.valor_total, to_char(b{$i}.pct_comissao) pct_comissao, 
							b{$i}.metadados, to_char(round((b{$i}.valor_total*b{$i}.pct_comissao)/100,2)) valor_comissao, to_char(0) premio, {$metapremio} metapremio, gu.cpf
							from
							(
								select x1.empresa, x1.usuario, x1.tipo_item, x1.mes_referencia, x1.ano_referencia,
								to_char(sum(x1.valor_faturado)) valor_faturado, to_char(sum(x1.val_desconto)) val_desconto, to_char(sum(x1.valor_faturado)-sum(x1.val_desconto)) valor_total,
								{$case}, {$casem}
								from
								(
									select a1.empresa, a1.revenda, a1.nome, a1.usuario, a1.tipo_item, a1.mes_referencia, a1.ano_referencia,
									a1.valor_faturado, nvl(a2.val_desconto,0) val_desconto, a1.valor_faturado-nvl(a2.val_desconto,0) valor_total
									from
									(
										select s1.*
										from
										(
											select m.empresa, m.revenda, m.usuario, m.nome_mecanico nome, m.mecanico, m.tipo_item, m.mes_referencia, m.ano_referencia,
											sum(m.valor) valor_faturado
											from qlik.j_v_fat_mecanico m
											where m.dta_referencia between
											to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
											and m.empresa||'.'||m.revenda in ('{$empresa}')
											and m.tipo_item in ('{$tipo}')
											and m.usuario in ({$vendedor})
											group by m.empresa, m.revenda, m.usuario, m.nome_mecanico, m.mecanico,
											m.tipo_item, m.mes_referencia, m.ano_referencia
										) s1
									) a1
									left join
									(
										select c.empresa, c.revenda, c.usuario_fat, c.mecanico, c.numero_nota_fiscal, c.serie_nota_fiscal, c.mes_emissao, c.ano_emissao, 
										c.mes_cancelamento, c.ano_cancelamento, c.tipo, c.val_desconto
										from qlik.j_v_cancelamento_nota c
										where c.dta_cancelamento_nota between
										to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
										and c.empresa||'.'||c.revenda in ('{$empresa}')
										and c.tipo in ('{$tipo}')
									) a2
									on ( a1.empresa = a2.empresa and a1.revenda = a2.revenda
									and a1.mes_referencia = a2.mes_cancelamento and a1.ano_referencia = a2.ano_cancelamento
									and a1.tipo_item = a2.tipo and a1.mecanico = a2.mecanico )
								) x1 group by x1.empresa, x1.usuario, x1.tipo_item, x1.mes_referencia, x1.ano_referencia
							) b{$i} join ger_usuario gu on b{$i}.usuario = gu.usuario union ";
				}
			}elseif ($tip == 1 || $tip == 4){
				if (($tip == 1) && (in_array("N", $considerar) || in_array("U", $considerar) || in_array("D", $considerar))){
					if ($por == "FAI"){
							
					}elseif ($por == "TIP"){
						$casem = "case  ";
						if (in_array("N", $considerar)){
							$casem .= "when g1.tipo_item = 'N' then {$campo_formula['META_NOVOS']}";
						}
						if (in_array("U", $considerar)){
							$casem .= "when g1.tipo_item = 'U' then {$campo_formula['META_USADOS']}";
						}
						if (in_array("D", $considerar)){
							$casem .= "when g1.tipo_item = 'D' then {$campo_formula['META_DIRETO']}";
						}
						if (in_array("C", $considerar)){
							$casem .= "when g1.tipo_item = 'C' then {$campo_formula['META_CONSORCIO']}";
						}
						if (in_array("P", $considerar)){
							$casem .= "when g1.tipo_item = 'P' then {$campo_formula['META_PECAS']}";
						}
						if (in_array("S", $considerar)){
							$casem .= "when g1.tipo_item = 'S' then {$campo_formula['META_MAODEOBRA']}";
						}
						$casem .= " else  0 end metadados ";
						$exp = explode('/',$de);
						//$metapremio = (isset($campo_formula['META_PREMIO'])) ? ($campo_formula['META_PREMIO'] != "") ? $campo_formula['META_PREMIO'] : 0 : 0;
						$metapremio = 126;
						return "select {$grupo} grupo, b{$i}.*
								from
								(
								   select g1.empresa, g1.vendedor usuario, g1.nome_vendedor nome, g1.tipo_item, g1.mes_referencia, g1.ano_referencia,
								   g1.valor_venda||';'||g1.valor_retorno||';'||g1.valor_total_acessorio valor_faturado, 
								   g1.val_cancelamento||';'||g1.valor_retorno_cancelado val_desconto,
								   g1.valor_total||';'||g1.valor_total_retorno||';'||g1.valor_total_acessorio valor_total,
								   g1.pct_comissao_venda||';'||g1.pct_comissao_retorno||';'||g1.pct_comissao_acessorio pct_comissao, {$campo_formula['META_NOVOS']} metadados,
								   g1.valor_comissao_venda||';'||g1.valor_comissao_retorno||';'||g1.valor_comissao_acessorio||';'||g1.valor_comissao_emplacamento valor_comissao,

									(SELECT to_char(SUM(X2.PREMIACAO)) PREMIACAO
									FROM
									(
									   SELECT X1.EMPRESA, X1.REVENDA, X1.VENDEDOR, X1.TIPO_ITEM, X1.BONUS_QUANTIDADE+X1.BONUS_MARGEM+X1.BONUS_MODELO PREMIACAO
									   FROM
									   (
									       select p1.empresa, p1.revenda, p1.vendedor, p1.tipo_item, sum(p1.valor_venda) valor_venda, sum(p1.quantidade) quantidade,
									       case when sum(p1.quantidade) >= 12 and p1.tipo_item = 'N' then 50*sum(p1.quantidade) else 0 end bonus_quantidade, 
									       sum(p1.bonus_margem) bonus_margem, sum(p1.bonus_modelo) bonus_modelo     
									       from
									       (
									         ---------------------------------------->
									           select h1.*,
									           case when h1.tipo_item = 'N' and h1.tipo = 'S' and h1.margem_operacional >= 5.5 then 50
									                when h1.tipo_item = 'N' and h1.tipo = 'E' and h1.margem_operacional >= 5.5 then 50*-1
									                when h1.tipo_item = 'U' and h1.tipo = 'S' and h1.margem_operacional >= 16 then 300
									                when h1.tipo_item = 'U' and h1.tipo = 'E' and h1.margem_operacional >= 16 then 300*-1 else 0 end bonus_margem,
									            case when h1.tipo_item = 'N' and h1.tipo = 'S' and replace(lower(h1.des_modelo),' ','') like '%mobilike%' then 200 
									                 when h1.tipo_item = 'N' and h1.tipo = 'E' and replace(lower(h1.des_modelo),' ','') like '%mobilike%' then 200*-1 
									            when h1.tipo_item = 'N' and h1.tipo = 'S' and replace(lower(h1.des_modelo),' ','') like '%siena%' then 300 
									            when h1.tipo_item = 'N' and h1.tipo = 'E' and replace(lower(h1.des_modelo),' ','') like '%siena%' then 300*-1
									            when h1.tipo_item = 'N' and h1.tipo = 'S' and replace(lower(h1.des_modelo),' ','') like '%cronos%' then 500
									            when h1.tipo_item = 'N' and h1.tipo = 'E' and replace(lower(h1.des_modelo),' ','') like '%cronos%' then 500*-1
									            when h1.tipo_item = 'N' and h1.tipo = 'S' and (replace(lower(h1.des_modelo),' ','') like '%argo%1.0%' or replace(lower(h1.des_modelo),' ','') like '%argo%1.3%' ) and replace(lower(h1.des_modelo),' ','') not like '%argo trekking%' then 300
									            when h1.tipo_item = 'N' and h1.tipo = 'E' and (replace(lower(h1.des_modelo),' ','') like '%argo%1.0%' or replace(lower(h1.des_modelo),' ','') like '%argo%1.3%' ) and replace(lower(h1.des_modelo),' ','') not like '%argo trekking%' then 300*-1              
									            when h1.tipo_item = 'N' and h1.tipo = 'S' and replace(lower(h1.des_modelo),' ','') like '%strada%' then 600
									            when h1.tipo_item = 'N' and h1.tipo = 'E' and replace(lower(h1.des_modelo),' ','') like '%strada%' then 600*-1
									            when h1.tipo_item = 'N' and h1.tipo = 'S' and replace(lower(h1.des_modelo),' ','') like '%strada%' and h1.margem_operacional >= 20 then 800
									            when h1.tipo_item = 'N' and h1.tipo = 'E' and replace(lower(h1.des_modelo),' ','') like '%strada%' and h1.margem_operacional >= 20 then 800*-1           
									            when (h1.tipo_item = ('N') and h1.tipo = 'S' and replace(lower(h1.des_modelo),' ','') like '%toro%') and h1.margem_operacional between 5.5 and 9.99 then 800
									            when (h1.tipo_item = ('N') and h1.tipo = 'E' and replace(lower(h1.des_modelo),' ','') like '%toro%') and h1.margem_operacional between 5.5 and 9.99 then 800*-1 
									            when (h1.tipo_item = ('N') and h1.tipo = 'S' and replace(lower(h1.des_modelo),' ','') like '%toro%') and h1.margem_operacional between 10 and 14.99 then 1000
									            when (h1.tipo_item = ('N') and h1.tipo = 'E' and replace(lower(h1.des_modelo),' ','') like '%toro%') and h1.margem_operacional between 10 and 14.99 then 1000*-1  
									            when (h1.tipo_item = ('N') and h1.tipo = 'S' and replace(lower(h1.des_modelo),' ','') like '%toro%') and h1.margem_operacional between 15 and 29.99 then 1500
									            when (h1.tipo_item = ('N') and h1.tipo = 'E' and replace(lower(h1.des_modelo),' ','') like '%toro%') and h1.margem_operacional between 15 and 29.99 then 1500*-1 
									            when (h1.tipo_item = ('N') and h1.tipo = 'S' and replace(lower(h1.des_modelo),' ','') like '%toro%') and h1.margem_operacional >= 30 then 2500
									            when (h1.tipo_item = ('N') and h1.tipo = 'E' and replace(lower(h1.des_modelo),' ','') like '%toro%') and h1.margem_operacional >= 30 then 2500*-1
									            when (h1.tipo_item = ('N') and h1.tipo = 'S' and replace(lower(h1.des_modelo),' ','') like '%ducato%' and replace(lower(h1.des_modelo),' ','') not like '%ducato%ambul%') and h1.margem_operacional >= 20 then 2500
									            when (h1.tipo_item = ('N') and h1.tipo = 'E' and replace(lower(h1.des_modelo),' ','') like '%ducato%' and replace(lower(h1.des_modelo),' ','') not like '%ducato%ambul%') and h1.margem_operacional >= 20 then 2500*-1
									            when (h1.tipo_item = ('N') and h1.tipo = 'S' and replace(lower(h1.des_modelo),' ','') like '%ducato%ambul%') and h1.margem_operacional >= 20 then 3500
									            when (h1.tipo_item = ('N') and h1.tipo = 'E' and replace(lower(h1.des_modelo),' ','') like '%ducato%ambul%') and h1.margem_operacional >= 20 then 3500*-1
									             else 0 end bonus_modelo 
									    from
									    (   
									       select v.*,
									       case when v.tipo_item = 'N' then round(abs(v.valor_venda) - (((abs(v.valor_custo_contabil) ) )+nvl(vr.val_retorno_r,0)),2)
									            when v.tipo_item = 'U' then round(abs(v.valor_venda) - (((abs(v.valor_custo_contabil) ) )+nvl(vr.val_retorno_r,0)),2) end valor_lucro,
									       case when v.tipo_item = 'N' then round(((round(abs(v.valor_venda) - (((abs(v.valor_custo_contabil) )  )+nvl(vr.val_retorno_r,2)),2))/abs(v.valor_venda))*100,2)
									            when v.tipo_item = 'U' then round(((round(abs(v.valor_venda) - (((abs(v.valor_custo_contabil) )  )+nvl(vr.val_retorno_r,2)),2))/abs(v.valor_venda))*100,2) end margem_operacional             
									       from qlik.j_tab_vendedor_veiculo v  
									       ---------------------------------------->
									       left join 
									             ( select empresa, revenda, proposta, sum(val_retorno)*-1 val_retorno_r
									               from cnp.vei_retorno 
									               group by empresa, revenda, proposta 
									             ) vr on v.empresa = vr.empresa and v.revenda = vr.revenda and v.proposta = vr.proposta
									             left join qlik.j_v_novos_icms_pis_cofins c on v.empresa = c.empresa and v.tipo_item = c.tipo_tem 
									             left join qlik.j_v_usados_icms_pis_cofins c2 on v.empresa = c2.empresa and v.tipo_item = c2.tipo_tem
									             where v.empresa||'.'||v.revenda in ('{$empresa}') 
									             and v.tipo_item in ('N','U')
									             and v.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
									          ) h1     
									             
									       ) p1 group by p1.empresa, p1.revenda, p1.vendedor, p1.tipo_item     
									   ) X1 
									       
									   ) X2 WHERE X2.VENDEDOR = g1.vendedor GROUP BY X2.VENDEDOR) premio
									, {$metapremio} metapremio, g1.cpf
								   from
								   (
										select x1.empresa, x1.revenda, x1.vendedor, x1.nome_vendedor, x1.tipo_item, x1.valor_venda, x1.valor_retorno, x1.val_cancelamento, x1.valor_retorno_cancelado, x1.valor_total, x1.valor_total_retorno, x1.valor_total_acessorio,
								        -------- Faturamento ---------
								        case when x1.quantidade between 1 and 9 then round((x1.valor_total*0.45)/100,2) 
								             when x1.quantidade between 10 and 14 then round((x1.valor_total*0.50)/100,2)  
								             when x1.quantidade between 15 and 17 then (x1.valor_total*0.55)/100  
								             when x1.quantidade >= 18 then round((x1.valor_total*0.60)/100,2)
								             when x1.quantidade >= 1 then round((x1.valor_total*0.45)/100,2) 
								             else 0 end valor_comissao_venda, 
								       
								        case when x1.quantidade between 1 and 9 then '0,45'
								             when x1.quantidade between 10 and 14 then '0,50' 
								             when x1.quantidade between 15 and 17 then '0,55' 
								             when x1.quantidade >= 18 then '0,60'
								             when x1.quantidade >= 1 then '0,45' 
								             else '0' end pct_comissao_venda, 
								   
								       ---------- Retorno Financiamento ----------     
								       case  
								             when x1.valor_total >= 800000 and 
								               (
								                select v.vendedor
								                from qlik.j_tab_vendedor_veiculo v 
								                 where v.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
								                and v.tipo_item = x1.tipo_item and v.tipo_transacao not in ('V07','V20','M20','M07','C07','C18','C51','U14','U15','U07') 
								                AND trunc(sysdate)-(v.dta_fat_fabrica+1) >= 90 and v.empresa = x1.empresa and v.revenda = x1.revenda and v.vendedor = x1.vendedor
								                group by v.empresa, v.revenda, v.vendedor, v.tipo_item
								                having count(0) >= 2 
								               ) = x1.vendedor then round((x1.valor_total_retorno*20)/100,2)
								             when x1.valor_total >= 1000000 and 
								               (
								                select v.vendedor
								                from qlik.j_tab_vendedor_veiculo v 
								                where v.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
								                and v.tipo_item = x1.tipo_item and v.tipo_transacao not in ('V07','V20','M20','M07','C07','C18','C51','U14','U15','U07') 
								                AND trunc(sysdate)-(v.dta_fat_fabrica+1) >= 120 and v.empresa = x1.empresa and v.revenda = x1.revenda and v.vendedor = x1.vendedor
								                group by v.empresa, v.revenda, v.vendedor, v.tipo_item
								                having count(0) >= 2
								               ) = x1.vendedor then round((x1.valor_total_retorno*30)/100,2)                                   
								             when x1.valor_total >= 1200000 then round((x1.valor_total_retorno*30)/100,2)
								             when x1.quantidade >= 1 then round((x1.valor_total_retorno*10)/100,2) else 0 end valor_comissao_retorno, 
								       
								        case 
								             when x1.valor_total >= 800000 and 
								               (
								                select v.vendedor
								                from qlik.j_tab_vendedor_veiculo v 
								                where v.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
								                and v.tipo_item = x1.tipo_item and v.tipo_transacao not in ('V07','V20','M20','M07','C07','C18','C51','U14','U15','U07') 
								                AND trunc(sysdate)-(v.dta_fat_fabrica+1) >= 90 and v.empresa = x1.empresa and v.revenda = x1.revenda and v.vendedor = x1.vendedor
								                group by v.empresa, v.revenda, v.vendedor, v.tipo_item
								                having count(0) >= 2 
								               ) = x1.vendedor then '20'
								             when x1.valor_total >= 1000000 and 
								               (
								                select v.vendedor
								                from qlik.j_tab_vendedor_veiculo v 
								                where v.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
								                and v.tipo_item = x1.tipo_item and v.tipo_transacao not in ('V07','V20','M20','M07','C07','C18','C51','U14','U15','U07') 
								                AND trunc(sysdate)-(v.dta_fat_fabrica+1) >= 120 and v.empresa = x1.empresa and v.revenda = x1.revenda and v.vendedor = x1.vendedor
								                group by v.empresa, v.revenda, v.vendedor, v.tipo_item
								                having count(0) >= 2
								               ) = x1.vendedor then '30'                                   
								             when x1.valor_total >= 1200000 then '30'
								             when x1.quantidade >= 1 then '10' else '0' end pct_comissao_retorno,
								       
								       --------- Acessrios------------------
								        case 
								             when x1.valor_total >= 800000 and 
								               (
								                select v.vendedor
								                from qlik.j_tab_vendedor_veiculo v 
								                where v.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
								                and v.tipo_item = x1.tipo_item and v.tipo_transacao not in ('V07','V20','M20','M07','C07','C18','C51','U14','U15','U07') 
								                AND trunc(sysdate)-(v.dta_fat_fabrica+1) >= 90 and v.empresa = x1.empresa and v.revenda = x1.revenda and v.vendedor = x1.vendedor
								                group by v.empresa, v.revenda, v.vendedor, v.tipo_item
								                having count(0) >= 2 
								               ) = x1.vendedor then round((x1.valor_total_acessorio*8)/100,2)
								             when x1.valor_total >= 1000000 and 
								               (
								                select v.vendedor
								                from qlik.j_tab_vendedor_veiculo v 
								                where v.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
								                and v.tipo_item = x1.tipo_item and v.tipo_transacao not in ('V07','V20','M20','M07','C07','C18','C51','U14','U15','U07') 
								                AND trunc(sysdate)-(v.dta_fat_fabrica+1) >= 120 and v.empresa = x1.empresa and v.revenda = x1.revenda and v.vendedor = x1.vendedor
								                group by v.empresa, v.revenda, v.vendedor, v.tipo_item
								                having count(0) >= 2
								               ) = x1.vendedor then round((x1.valor_total_acessorio*10)/100,2)                                   
								             when x1.valor_total >= 1200000 then round((x1.valor_total_acessorio*10)/100,2)
								             when x1.quantidade >= 1 then round((x1.valor_total_acessorio*6)/100,2) else 0 end valor_comissao_acessorio, 
								               
								        case 
								             when x1.valor_total >= 800000 and 
								               (
								                select v.vendedor
								                from qlik.j_tab_vendedor_veiculo v 
								                where v.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
								                and v.tipo_item = x1.tipo_item and v.tipo_transacao not in ('V07','V20','M20','M07','C07','C18','C51','U14','U15','U07') 
								                AND trunc(sysdate)-(v.dta_fat_fabrica+1) >= 90 and v.empresa = x1.empresa and v.revenda = x1.revenda and v.vendedor = x1.vendedor
								                group by v.empresa, v.revenda, v.vendedor, v.tipo_item
								                having count(0) >= 2 
								               ) = x1.vendedor then '8'
								             when x1.valor_total >= 1000000 and 
								               (
								                select v.vendedor
								                from qlik.j_tab_vendedor_veiculo v 
								                where v.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
								                and v.tipo_item = x1.tipo_item and v.tipo_transacao not in ('V07','V20','M20','M07','C07','C18','C51','U14','U15','U07') 
								                AND trunc(sysdate)-(v.dta_fat_fabrica+1) >= 120 and v.empresa = x1.empresa and v.revenda = x1.revenda and v.vendedor = x1.vendedor
								                group by v.empresa, v.revenda, v.vendedor, v.tipo_item
								                having count(0) >= 2
								               ) = x1.vendedor then '10'                                 
								             when x1.valor_total >= 1200000 then '10'
								             when x1.quantidade >= 1 then '6' else '0' end pct_comissao_acessorio,   
								             
								             ----------- Emplacamento -----------
								             x1.n_emplacamento*35 valor_comissao_emplacamento,  
								             x1.mes_referencia, x1.ano_referencia, u.cpf 
								        from
								        (
								             select s1.*, nvl(s2.val_cancelamento,0) val_cancelamento, s1.valor_venda-nvl(s2.val_cancelamento,0) valor_total,
								             nvl(s2.valor_financiado_cancelado,0) valor_financiado_cancelado, s1.valor_financiado-nvl(s2.valor_financiado_cancelado,0) valor_total_financiado, 
								             nvl(s2.val_retorno_financ,0) valor_retorno_cancelado, s1.valor_retorno-nvl(s2.val_retorno_financ,0) valor_total_retorno, nvl(ann.valor_acessorio,0) valor_total_acessorio 
								             from
								             (
								               select v.empresa, v.revenda, v.vendedor, v.nome_vendedor, v.tipo_item, sum(v.valor_venda)-nvl(sum(dv.valor_dv),0) valor_venda, 
								               nvl(sum(f9.valor_financiado),0) valor_financiado, nvl(sum(f9.valor_retorno),0) valor_retorno, sum(v.quantidade) quantidade,
								               to_number(to_char(v.DTA_ENTRADA_SAIDA,'mm')) mes_referencia, to_number(to_char(v.DTA_ENTRADA_SAIDA,'yyyy')) ano_referencia, nvl(sum(n.acessorio),0) n_emplacamento
								               from qlik.j_tab_vendedor_veiculo v
								               left join
								                         (
								                           select empresa, revenda, proposta, fat_oper, sum(valor_dv) valor_dv
								                           from qlik.j_v_fiat_dv group by empresa, revenda, proposta, fat_oper 
								                         ) dv on v.empresa = dv.empresa and v.revenda = dv.revenda and v.fat_oper = dv.fat_oper and nvl(v.proposta,0) = dv.proposta
								               left join ( select an.empresa, an.revenda, an.vendedor, an.veiculo, an.fat_oper, an.valor_venda, an.proposta, an.dta_entrada_saida,
								                           nvl(an.acessorio,(select sum(acessorio)*-1 from qlik.j_v_emplacamentp_novos where valor_venda >=0 and empresa = an.empresa and revenda = an.revenda and fat_oper = an.fat_oper)) acessorio 
								                           from qlik.j_v_emplacamentp_novos an
								                         ) n on v.empresa = n.empresa and v.revenda = n.revenda and v.veiculo = n.veiculo and v.vendedor = n.vendedor and v.fat_oper = n.fat_oper 
								               left join 
								                         (
								                            select f10.EMPRESA, f10.REVENDA, f10.VENDEDOR, f10.VEICULO, f10.PROPOSTA, f10.FAT_OPER, f10.DTA_ENTRADA_SAIDA, f10.VALOR_FINANCIADO,
								                            f10.taxa_retorno, f10.val_retorno_financ, f10.ila,
								                            f10.val_retorno_financ+((f10.val_retorno_financ*f10.ila)/100) valor_retorno
								                            from
								                            (  
								                              select f1.EMPRESA, f1.REVENDA, f1.VENDEDOR, f1.VEICULO, f1.PROPOSTA, f1.FAT_OPER, f1.DTA_ENTRADA_SAIDA, f1.VALOR_FINANCIADO,  
								                              nvl(f1.taxa_retorno,(select taxa_retorno from qlik.j_v_financiamento_novos where valor_financiado >=0 and empresa = f1.empresa and revenda = f1.revenda and fat_oper = f1.fat_oper)) taxa_retorno,
								                              nvl(f1.val_retorno_financ,(select val_retorno_financ*-1 from qlik.j_v_financiamento_novos where valor_financiado >=0 and empresa = f1.empresa and revenda = f1.revenda and fat_oper = f1.fat_oper)) val_retorno_financ,
								                              nvl(cp.ila,0) ila
								                              from qlik.j_v_financiamento_novos f1 
								                              left join (select empresa, revenda, mes, ano, ila 
								                                             from sismonaco.com_parametros where mes = '{$exp[1]}' and ano = '{$exp[2]}'
								                                        ) cp on (f1.empresa = cp.empresa and f1.revenda = cp.revenda)
								                              where f1.empresa = {$emp}
								                            ) f10   
								                         ) f9 on v.empresa = f9.empresa and v.revenda = f9.revenda and v.fat_oper = f9.fat_oper 
								               where v.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
								               and v.tipo_item = 'N' 
								               and v.empresa||'.'||v.revenda in ('{$empresa}')
								               group by v.empresa, v.revenda, v.vendedor, v.nome_vendedor, v.tipo_item,
								               to_number(to_char(v.DTA_ENTRADA_SAIDA,'mm')), to_number(to_char(v.DTA_ENTRADA_SAIDA,'yyyy'))
								             ) s1
								             left join 
								             (
								                 select a1.empresa, a1.revenda, a1.nome, a1.usuario, 'N' tipo_item, a1.mes_referencia, a1.ano_referencia,
								                   a1.valor_faturado, nvl(a2.val_desconto,0) val_desconto, a1.valor_faturado-nvl(a2.val_desconto,0) valor_acessorio
								                   from
								                   (
								                          select s1.*
								                          from
								                          ( 
								                                 select m.empresa, m.revenda, m.usuario, m.nome_vendedor nome, 
								                                 to_number(to_char(m.dta_referencia,'mm')) mes_referencia, to_number(to_char(m.dta_referencia,'yyyy')) ano_referencia,
								                                 sum(m.valor_venda) valor_faturado
								                                 from qlik.j_tab_fat_vendedor m
								                                 where m.dta_referencia between
																 to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
																 and m.empresa||'.'||m.revenda in ('{$empresa}')
								                                 group by m.empresa, m.revenda, m.usuario, m.nome_vendedor,
								                                 to_number(to_char(m.dta_referencia,'mm')), to_number(to_char(m.dta_referencia,'yyyy'))
								                          ) s1
								                   ) a1
								                   left join
								                   (
								                          select c.empresa, c.revenda, c.usuario_fat, c.mes_cancelamento, c.ano_cancelamento, sum(c.val_desconto) val_desconto
								                          from qlik.j_v_cancelamento_nota c
								                          where c.dta_cancelamento_nota between
								                          to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
														  and c.empresa||'.'||c.revenda in ('{$empresa}')
								                          group by c.empresa, c.revenda, c.usuario_fat, c.mes_cancelamento, c.ano_cancelamento
								                   ) a2
								                   on ( a1.empresa = a2.empresa and a1.revenda = a2.revenda
								                   and a1.mes_referencia = a2.mes_cancelamento and a1.ano_referencia = a2.ano_cancelamento
								                   and a1.usuario = a2.usuario_fat )
								             ) ann on (s1.empresa = ann.empresa and s1.revenda = ann.revenda and s1.vendedor = ann.usuario and s1.tipo_item = ann.tipo_item) 
								             left join
								             (
								              select cv.empresa, cv.revenda, cv.usuario_fat, cv.tipo_item, sum(cv.tot_nota_fiscal) val_cancelamento, 
								              sum(cv.valor_financiado) valor_financiado_cancelado, sum(cv.val_retorno_financ) val_retorno_financ
								              from qlik.j_v_cancelamento_nota_veiculo cv
								              where cv.dta_cancelamento_nota between to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
								              group by cv.empresa, cv.revenda, cv.usuario_fat, cv.tipo_item
								             ) s2 on (s1.empresa = s2.empresa and s1.revenda = s2.revenda and s1.vendedor = s2.usuario_fat and s1.tipo_item = s2.tipo_item)
								       ) x1 left join cnp.ger_usuario u on x1.vendedor = u.usuario
								   ) g1

								   union all
								    select g1.empresa, g1.vendedor usuario, g1.nome_vendedor nome, g1.tipo_item, g1.mes_referencia, g1.ano_referencia, 
								    g1.valor_venda||';'||g1.valor_retorno||';'||g1.valor_total_acessorio valor_faturado, 
								    g1.val_cancelamento||';'||g1.valor_retorno_cancelado val_desconto,
								    g1.valor_total||';'||g1.valor_total_retorno||';'||g1.valor_total_acessorio valor_total,
								    g1.pct_comissao_venda||';'||g1.pct_comissao_retorno||';'||g1.pct_comissao_acessorio pct_comissao, {$campo_formula['META_USADOS']} metadados,
								    g1.valor_comissao_venda||';'||g1.valor_comissao_retorno||';'||g1.valor_comissao_acessorio||';'||g1.valor_comissao_emplacamento valor_comissao, to_char(0) premio, {$metapremio} metapremio, g1.cpf 
								    from
								    (
								          select x1.empresa, x1.revenda, x1.vendedor, x1.nome_vendedor, x1.tipo_item, x1.valor_venda, x1.val_cancelamento, x1.valor_retorno, x1.valor_retorno_cancelado,  x1.valor_total, x1.valor_total_retorno, x1.valor_total_acessorio,
								         -------- Faturamento --------- 
								          case when x1.quantidade >= 1 then round((x1.valor_total*0.5)/100,2) else 0 end valor_comissao_venda, 
								          case when x1.quantidade >= 1 then '0.5' else '0' end pct_comissao_venda,
								         ---------- Retorno Financiamento ----------     
								          case when x1.quantidade >= 1 then round((x1.valor_total_retorno*10)/100,2) else 0 end valor_comissao_retorno, 
								          case when x1.quantidade >= 1 then '10' else '0' end pct_comissao_retorno, 
								         --------- Acessrios------------------
								          case when x1.quantidade >= 1 then round((x1.valor_total_acessorio*6)/100,2) else 0 end valor_comissao_acessorio, 
								          case when x1.quantidade >= 1 then 6 else 0 end pct_comissao_acessorio,
								         ----------- Emplacamento -----------
								           x1.n_emplacamento*35 valor_comissao_emplacamento,  
								           x1.mes_referencia, x1.ano_referencia, u.cpf  
								          from
								          (
								               select s1.*, nvl(s2.val_cancelamento,0) val_cancelamento, s1.valor_venda-nvl(s2.val_cancelamento,0) valor_total,
								               nvl(s2.valor_financiado_cancelado,0) valor_financiado_cancelado, s1.valor_financiado-nvl(s2.valor_financiado_cancelado,0) valor_total_financiado,  
								               nvl(s2.valor_retorno_cancelado,0) valor_retorno_cancelado, 
								               s1.valor_retorno-nvl(s2.valor_retorno_cancelado,0) valor_total_retorno, s1.valor_acessorio valor_total_acessorio 
								               from
								               (
								                 select v.empresa, v.revenda, v.vendedor, v.nome_vendedor, v.tipo_item, sum(v.valor_venda)-nvl(sum(dv.valor_dv),0) valor_venda, 
								                 nvl(sum(f9.valor_financiado),0) valor_financiado, nvl(sum(f9.valor_retorno),0) valor_retorno, 0 valor_acessorio, sum(v.quantidade) quantidade,
								                 to_number(to_char(v.DTA_ENTRADA_SAIDA,'mm')) mes_referencia, to_number(to_char(v.DTA_ENTRADA_SAIDA,'yyyy')) ano_referencia, nvl(sum(n.acessorio),0) n_emplacamento
								                 from qlik.j_tab_vendedor_veiculo v
								                 left join
								                         (
								                           select empresa, revenda, proposta, fat_oper, sum(valor_dv) valor_dv
								                           from qlik.j_v_fiat_dv group by empresa, revenda, proposta, fat_oper 
								                         ) dv on v.empresa = dv.empresa and v.revenda = dv.revenda and v.fat_oper = dv.fat_oper and nvl(v.proposta,0) = dv.proposta
								                 left join ( select an.empresa, an.revenda, an.vendedor, an.veiculo, an.fat_oper, an.valor_venda, an.proposta, an.dta_entrada_saida,
								                             nvl(an.acessorio,(select sum(acessorio)*-1 from qlik.j_v_emplacamentp_novos where valor_venda >=0 and empresa = an.empresa and revenda = an.revenda and fat_oper = an.fat_oper)) acessorio 
								                             from qlik.j_v_emplacamentp_usados an
								                           ) n on v.empresa = n.empresa and v.revenda = n.revenda and v.veiculo = n.veiculo and v.vendedor = n.vendedor and v.fat_oper = n.fat_oper 
								                 left join 
								                           (
								                              select f10.EMPRESA, f10.REVENDA, f10.VENDEDOR, f10.VEICULO, f10.PROPOSTA, f10.FAT_OPER, f10.DTA_ENTRADA_SAIDA, f10.VALOR_FINANCIADO,
								                              f10.taxa_retorno, f10.val_retorno_financ, f10.ila,
								                              f10.val_retorno_financ+((f10.val_retorno_financ*f10.ila)/100) valor_retorno
								                              from
								                              (  
								                                select f1.EMPRESA, f1.REVENDA, f1.VENDEDOR, f1.VEICULO, f1.PROPOSTA, f1.FAT_OPER, f1.DTA_ENTRADA_SAIDA, f1.VALOR_FINANCIADO,  
								                                nvl(f1.taxa_retorno,(select taxa_retorno from qlik.j_v_financiamento_novos where valor_financiado >=0 and empresa = f1.empresa and revenda = f1.revenda and fat_oper = f1.fat_oper)) taxa_retorno,
								                                nvl(f1.val_retorno_financ,(select val_retorno_financ*-1 from qlik.j_v_financiamento_novos where valor_financiado >=0 and empresa = f1.empresa and revenda = f1.revenda and fat_oper = f1.fat_oper)) val_retorno_financ,
								                                nvl(cp.ila,0) ila
								                                from qlik.j_v_financiamento_usados f1 
								                                left join (select empresa, revenda, mes, ano, ila 
								                                               from sismonaco.com_parametros where mes = '{$exp[1]}' and ano = '{$exp[2]}'
								                                          ) cp on (f1.empresa = cp.empresa and f1.revenda = cp.revenda)
								                                where f1.empresa = 13 
								                              ) f10   
								                           ) f9 on v.empresa = f9.empresa and v.revenda = f9.revenda and v.fat_oper = f9.fat_oper 
								                 where v.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
								                 and v.tipo_item = 'U' 
								                 and v.empresa||'.'||v.revenda in ('{$empresa}')
								                 group by v.empresa, v.revenda, v.vendedor, v.nome_vendedor, v.tipo_item,
								                 to_number(to_char(v.DTA_ENTRADA_SAIDA,'mm')), to_number(to_char(v.DTA_ENTRADA_SAIDA,'yyyy'))
								               ) s1
								               left join
								               (
								                select cv.empresa, cv.revenda, cv.usuario_fat, cv.tipo_item, sum(cv.tot_nota_fiscal) val_cancelamento, 
								                sum(cv.valor_financiado) valor_financiado_cancelado, sum(cv.val_retorno_financ) valor_retorno_cancelado
								                from qlik.j_v_cancelamento_nota_veiculo cv
								                where cv.dta_cancelamento_nota between to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
								                group by cv.empresa, cv.revenda, cv.usuario_fat, cv.tipo_transacao, cv.tipo_item
								               ) s2 on (s1.empresa = s2.empresa and s1.revenda = s2.revenda and s1.vendedor = s2.usuario_fat and s1.tipo_item = s2.tipo_item)
								         ) x1 left join cnp.ger_usuario u on x1.vendedor = u.usuario
								    ) g1
								    
								    union all
								    
								   select g1.empresa, g1.vendedor usuario, g1.nome_vendedor nome, g1.tipo_item, g1.mes_referencia, g1.ano_referencia,
								   g1.val_fat_retorno||';'||g1.valor_retorno||';'||g1.valor_total_acessorio valor_faturado, 
								   0||';'||g1.valor_retorno_cancelado val_desconto,
								   g1.val_fat_retorno||';'||g1.valor_total_retorno||';'||g1.valor_total_acessorio valor_total,
								   g1.pct_comissao_venda||';'||g1.pct_comissao_retorno||';'||g1.pct_comissao_acessorio pct_comissao, {$campo_formula['META_DIRETO']} metadados,
								   g1.valor_comissao_venda||';'||g1.valor_comissao_retorno||';'||g1.valor_comissao_acessorio||';'||g1.valor_comissao_emplacamento valor_comissao, to_char(0) premio, {$metapremio} metapremio, g1.cpf
								   from
								   (
								       select x1.empresa, x1.revenda, x1.vendedor, x1.nome_vendedor, x1.tipo_item, x1.val_fat_retorno, x1.val_cancelamento, x1.valor_total, x1.valor_total_financiado, 
								              x1.valor_retorno, x1.valor_retorno_cancelado, x1.valor_total_retorno, x1.valor_total_acessorio, u.cpf,
								          -------- Faturamento ---------
								         round((x1.val_fat_retorno*10)/100,2) valor_comissao_venda, 
								                 
								         10 pct_comissao_venda, 
								         -------- Retorno Financeiro ---------
								         case when x1.quantidade >= 1 then round((x1.valor_total_retorno*10)/100,2) else 0 end valor_comissao_retorno,
								         
								         case when x1.quantidade >= 1 then '10' else '0' end pct_comissao_retorno,        
								         --------- Acessrios------------------
								         case when x1.quantidade >= 1 then nvl((x1.valor_total_acessorio*6)/100,0) else 0 end valor_comissao_acessorio, 
								         
								         case when x1.quantidade >= 1 then '6' else '0' end pct_comissao_acessorio,
								               x1.n_emplacamento*35 valor_comissao_emplacamento,  
								               x1.mes_referencia, x1.ano_referencia   
								          from
								          (
								               select s1.*, nvl(s2.val_cancelamento,0) val_cancelamento, s1.valor_venda-nvl(s2.val_cancelamento,0) valor_total,
								               nvl(s2.valor_financiado_cancelado,0) valor_financiado_cancelado, s1.valor_financiado-nvl(s2.valor_financiado_cancelado,0) valor_total_financiado, 
								               nvl(s2.val_retorno_financ,0) valor_retorno_cancelado, s1.valor_retorno-nvl(s2.val_retorno_financ,0) valor_total_retorno, s1.valor_acessorio valor_total_acessorio
								               from
								               (
								                 select v.empresa, v.revenda, v.vendedor, v.nome_vendedor, v.tipo_item, sum(v.valor_venda) valor_venda, nvl(sum(s2.valor_financiado),0) valor_financiado, nvl(sum(s2.valor_retorno),0) valor_retorno, 0 valor_acessorio, sum(v.quantidade) quantidade,
								                 to_number(to_char(v.DTA_ENTRADA_SAIDA,'mm')) mes_referencia, to_number(to_char(v.DTA_ENTRADA_SAIDA,'yyyy')) ano_referencia, nvl(sum(n.acessorio),0) n_emplacamento, nvl(sum(re.val_retorno),0)-nvl(sum((re.val_retorno*1.5)/100),0) val_fat_retorno
								                 from qlik.j_tab_vendedor_veiculo v
								                 left join (
								                             select r.empresa, r.revenda, sum(r.val_retorno) val_retorno, p.veiculo, p.vendedor 
								                             from cnp.vei_retorno r join cnp.vei_proposta p on r.empresa = p.empresa and r.revenda = p.revenda and r.proposta = p.proposta 
								                             group by r.empresa, r.revenda, p.veiculo, p.vendedor  
								                           ) re on v.empresa = re.empresa and v.revenda = re.revenda and v.vendedor = re.vendedor and v.veiculo = re.veiculo
								                 left join ( select an.empresa, an.revenda, an.vendedor, an.veiculo, an.fat_oper, an.valor_venda, an.proposta, an.dta_entrada_saida,
								                             nvl(an.acessorio,(select sum(acessorio)*-1 from qlik.j_v_emplacamento_direto where valor_venda >=0 and empresa = an.empresa and revenda = an.revenda and veiculo = an.veiculo)) acessorio 
								                             from qlik.j_v_emplacamento_direto an
								                           ) n on v.empresa = n.empresa and v.revenda = n.revenda and v.veiculo = n.veiculo and v.vendedor = n.vendedor and v.fat_oper = n.fat_oper 
								                 left join  
								                           ( 
								                               select f1.empresa, f1.revenda, f1.proposta, f1.vendedor, f1.veiculo, f1.valor_financiado,
								                               f2.taxa_retorno, f2.pct_ila, f2.valor_retorno
								                               from
								                               (
								                                 select p.empresa, p.revenda, p.proposta, p.vendedor, p.veiculo, pg.val_pagamento valor_financiado 
								                                 from cnp.vei_proposta p 
								                                 join (select empresa, revenda, proposta, val_pagamento from cnp.vei_pagamento where condicao = 141) pg 
								                                 on ( p.empresa = pg.empresa and p.revenda = pg.revenda and p.proposta = pg.proposta )
								                                 where p.tipo_venda in ('D','F')
								                               ) f1
								                               join
								                               (
								                                  select p.empresa, p.revenda, p.proposta, p.vendedor, p.veiculo, nvl(vn.val_financiado,0) val_financiado, 
								                                  nvl(vn.taxa_retorno,0) taxa_retorno, nvl(vn.val_retorno_financ,0) val_retorno_financ, nvl(cp.ila,0) pct_ila, 
								                                  (nvl(vn.val_retorno_financ,0)*nvl(cp.ila,0))/100 valor_ila, 
								                                  nvl(vn.val_retorno_financ,0)+((nvl(vn.val_retorno_financ,0)*nvl(cp.ila,0))/100) valor_retorno        
								                                  from cnp.vei_proposta p 
								                                  join cnp.vei_negociacao vn on (vn.empresa = p.empresa and vn.revenda = p.revenda and vn.proposta = p.proposta) 
								                                  left join (select empresa, revenda, mes, ano, ila 
								                                             from sismonaco.com_parametros where mes = '{$exp[1]}' and ano = '{$exp[2]}'
								                                            ) cp on (p.empresa = cp.empresa and p.revenda = cp.revenda) 
								                                  where p.tipo_venda in ('D','F')
								                               ) f2 on (f1.empresa = f2.empresa and f1.revenda = f2.revenda and f1.proposta = f2.proposta)  
								                           ) s2 on v.empresa = s2.empresa and v.revenda = s2.revenda and v.veiculo = s2.veiculo and v.vendedor = s2.vendedor 
								                 where v.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
								                 and v.tipo_item = 'D' 
								                 and v.empresa||'.'||v.revenda in ('{$empresa}')
								                 group by v.empresa, v.revenda, v.vendedor, v.nome_vendedor, v.tipo_item,
								                 to_number(to_char(v.DTA_ENTRADA_SAIDA,'mm')), to_number(to_char(v.DTA_ENTRADA_SAIDA,'yyyy'))
								               ) s1
								               left join
								               (
								                select cv.empresa, cv.revenda, cv.usuario_fat, cv.tipo_item, sum(cv.tot_nota_fiscal) val_cancelamento, 
								                sum(cv.valor_financiado) valor_financiado_cancelado, sum(cv.val_retorno_financ) val_retorno_financ
								                from qlik.j_v_cancelamento_nota_veiculo cv
								                where cv.dta_cancelamento_nota between to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
								                group by cv.empresa, cv.revenda, cv.usuario_fat, cv.tipo_transacao, cv.tipo_item
								               ) s2 on (s1.empresa = s2.empresa and s1.revenda = s2.revenda and s1.vendedor = s2.usuario_fat and s1.tipo_item = s2.tipo_item)
								               
								         ) x1 left join cnp.ger_usuario u on x1.vendedor = u.usuario
								     ) g1

								) b{$i} where b{$i}.tipo_item in ('{$tipo}') union ";
					}
				}else{
					if ($por == "FAI"){
						$case = "case ";
						$casep = "case ";
						$premio1 = (isset($campo_formula['PREMIO1'])) ? ($campo_formula['PREMIO1'] > 0) ? $campo_formula['PREMIO1'] : 0 : 0;
						$premio2 = (isset($campo_formula['PREMIO2'])) ? ($campo_formula['PREMIO2'] > 0) ? $campo_formula['PREMIO2'] : 0 : 0;
						$premio3 = (isset($campo_formula['PREMIO3'])) ? ($campo_formula['PREMIO3'] > 0) ? $campo_formula['PREMIO3'] : 0 : 0;
						$premio4 = (isset($campo_formula['PREMIO4'])) ? ($campo_formula['PREMIO4'] > 0) ? $campo_formula['PREMIO4'] : 0 : 0;
						if ($auto == "S"){
							if ($tip == 4){
								$m = ($parametros->MEC_PROD4 > 0) ? ($parametros->MEC_PROD4/100) : 0;
								$mv = (($produtividade * $m) * $parametros->QTD_MECA);
								$e = ($parametros->ELE_PROD4 > 0) ? ($parametros->ELE_PROD4/100) : 0;
								$ev = (($produtividade * $e) * $parametros->QTD_ELET);
								
								
								$perc = ($parametros->CON_PROD1 > 0) ? ($parametros->CON_PROD1/100) : 0;
								$fai_de1 = 0;
								$fai_ate1 = ((($mv + $ev)/$parametros->QTD_CONS) * $perc);
								$fai_de2 = ((($mv + $ev)/$parametros->QTD_CONS) * $perc) + 0.01;
								$perc = ($parametros->CON_PROD2 > 0) ? ($parametros->CON_PROD2/100) : 0;
								$fai_ate2 = ((($mv + $ev)/$parametros->QTD_CONS) * $perc);
								$fai_de3 = ((($mv + $ev)/$parametros->QTD_CONS) * $perc) + 0.01;
								$perc = ($parametros->CON_PROD3 > 0) ? ($parametros->CON_PROD3/100) : 0;
								$fai_ate3 = ((($mv + $ev)/$parametros->QTD_CONS) * $perc);
								$fai_de4 = ((($mv + $ev)/$parametros->QTD_CONS) * $perc) + 0.01;
								$fai_ate4 = (($mv + $ev)/$parametros->QTD_CONS);
							}else{
								$fai_de1 = 0;
								$fai_ate1 = $produtividade * 0.7;
								$fai_de2 = ($produtividade * 0.7) + 0.01;
								$fai_ate2 = $produtividade * 0.8;
								$fai_de3 = ($produtividade * 0.8) + 0.01;
								$fai_ate3 = $produtividade * 0.9;
								$fai_de4 = ($produtividade * 0.9) + 0.01;
								$fai_ate4 = $produtividade;
							}
							
							if (isset($campo_formula['FAI_COMISSAO1'])){
								$case .= "when x1.valor_calc between {$fai_de1} and {$fai_ate1} then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO1'])." ";
								$com = $campo_formula['FAI_COMISSAO1'];
								$casep .= "when x1.valor_calc between {$fai_de1} and {$fai_ate1} then 0 ";
							}
							if (isset($campo_formula['FAI_COMISSAO2'])){
								$case .= "when x1.valor_calc between {$fai_de2} and {$fai_ate2} then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO2'])." ";
								$com = $campo_formula['FAI_COMISSAO2'];
								$casep .= "when x1.valor_calc between {$fai_de2} and {$fai_ate2} then ".str_replace(",", ".", $premio1)." ";
								$pre = $premio1;
							}
							if (isset($campo_formula['FAI_COMISSAO3'])){
								$case .= "when x1.valor_calc between {$fai_de3} and {$fai_ate3} then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO3'])." ";
								$com = $campo_formula['FAI_COMISSAO3'];
								$casep .= "when x1.valor_calc between {$fai_de3} and {$fai_ate3} then ".str_replace(",", ".", $premio2)." ";
								$pre = $premio2;
							}
							if (isset($campo_formula['FAI_COMISSAO4'])){
								$case .= "when x1.valor_calc between {$fai_de4} and {$fai_ate4} then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO4'])." ";
								$com = $campo_formula['FAI_COMISSAO4'];
								$casep .= "when x1.valor_calc between {$fai_de4} and {$fai_ate4} then ".str_replace(",", ".", $premio3)." ";
								$pre = $premio3;
							}
							$case .= "when x1.valor_calc > 0 then ".str_replace(",", ".", $com)." ";
							$casep .= "when x1.valor_calc > 0 then ".str_replace(",", ".", $pre)." ";
						}else{
							$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE1'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE1'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO1'])."";
							$com = $campo_formula['FAI_COMISSAO1'];
							$casep .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE1'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE1'])." then 0";
							if (isset($campo_formula["FAI_DE2"])){
								$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE2'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE2'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO2'])."";
								$com = $campo_formula['FAI_COMISSAO2'];
								$casep .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE2'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE2'])." then ".str_replace(",", ".", $premio1)."";
								$pre = $premio1;
							}
							if (isset($campo_formula["FAI_DE3"])){
								$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE3'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE3'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO3'])."";
								$com = $campo_formula['FAI_COMISSAO3'];
								$casep .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE3'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE3'])." then ".str_replace(",", ".", $premio2)."";
								$pre = $premio2;
							}
							if (isset($campo_formula["FAI_DE4"])){
								$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE4'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE4'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO4'])."";
								$com = $campo_formula['FAI_COMISSAO4'];
								$casep .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE4'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE4'])." then ".str_replace(",", ".", $premio3)."";
								$pre = $premio3;
							}
							if (isset($campo_formula["FAI_DE5"])){
								$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE5'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE5'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO5'])."";
								$com = $campo_formula['FAI_COMISSAO5'];
								$casep .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE5'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE5'])." then ".str_replace(",", ".", $premio4)."";
								$pre = $premio4;
							}
							$case .= "when x1.valor_calc > 0 then ".str_replace(",", ".", $com)." ";
							$casep .= "when x1.valor_calc > 0 then ".str_replace(",", ".", $pre)." "; 
						}
						
						$casem = "case  ";
						if (in_array("N", $considerar)){
							$casem .= "when x1.tipo_item = 'N' then {$campo_formula['META_NOVOS']} ";
						}
						if (in_array("U", $considerar)){
							$casem .= "when x1.tipo_item = 'U' then {$campo_formula['META_USADOS']} ";
						}
						if (in_array("D", $considerar)){
							$casem .= "when x1.tipo_item = 'D' then {$campo_formula['META_DIRETO']} ";
						}
						if (in_array("C", $considerar)){
							$casem .= "when x1.tipo_item = 'C' then {$campo_formula['META_CONSORCIO']} ";
						}
						if (in_array("P", $considerar)){
							$casem .= "when x1.tipo_item = 'P' then {$campo_formula['META_PECAS']} ";
						}
						if (in_array("S", $considerar)){
							$casem .= "when x1.tipo_item = 'S' then {$campo_formula['META_MAODEOBRA']} ";
						}
						$case .= "else  0 end pct_comissao";
						$casep .= "else  0 end premio";
						$casem .= "else  0 end metadados";
						$metapremio = (isset($campo_formula['META_PREMIO'])) ? ($campo_formula['META_PREMIO'] != "") ? $campo_formula['META_PREMIO'] : 0 : 0;
						return "select {$grupo} grupo, b{$i}.empresa, b{$i}.usuario, gu.nome, b{$i}.tipo_item, b{$i}.mes_referencia,
								b{$i}.ano_referencia, b{$i}.valor_faturado, b{$i}.val_desconto, b{$i}.valor_total, to_char(b{$i}.pct_comissao) pct_comissao, 
								b{$i}.metadados, to_char(round((b{$i}.valor_total*b{$i}.pct_comissao)/100,2)) valor_comissao, to_char(b{$i}.premio) premio, {$metapremio} metapremio, gu.cpf
								from
								(
									select x1.empresa, x1.usuario, x1.tipo_item, x1.mes_referencia, x1.ano_referencia,
									to_char(sum(x1.valor_faturado)) valor_faturado, to_char(sum(x1.val_desconto)) val_desconto, to_char(sum(x1.valor_faturado)-sum(x1.val_desconto)) valor_total,
									{$case}, {$casep}, {$casem}
									from
									(
										select a1.empresa, a1.revenda, a1.nome, a1.usuario, a1.tipo_item, a1.departamento, a1.mes_referencia, a1.ano_referencia,
										a1.valor_faturado, nvl(a2.val_desconto,0) val_desconto, a1.valor_faturado-nvl(a2.val_desconto,0) valor_total,
										(
											select valor_calc 
											from 
											(
												select a1.usuario, a1.valor_faturado-nvl(a2.val_desconto,0) valor_calc
												from 
												(
													select s1.* 
													from
													(	
														select m.usuario, sum(m.valor_venda) valor_faturado
														from qlik.j_tab_fat_vendedor m
														where m.dta_referencia between
														to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
														and m.empresa||'.'||m.revenda in ('{$empresa}')
														and m.tipo in ('{$tipo}')
														and m.usuario in ({$vendedor})
														group by m.usuario
													) s1 
												) a1
											left join 
											(
												select c.usuario_fat, sum(c.val_desconto) val_desconto
												from qlik.j_v_cancelamento_nota c
												where c.dta_cancelamento_nota between
												to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
												and c.empresa||'.'||c.revenda in ('{$empresa}')
												and c.tipo in ('{$tipo}') group by c.usuario_fat
											) a2
											on a1.usuario = a2.usuario_fat
											)calc where calc.usuario = a1.usuario
										) valor_calc
									from
									(
										select s1.*
										from
										(
											select m.empresa, m.revenda, m.usuario, m.nome_vendedor nome,  m.tipo tipo_item, m.departamento,
											to_number(to_char(m.dta_referencia,'mm')) mes_referencia, to_number(to_char(m.dta_referencia,'yyyy')) ano_referencia,
											sum(m.valor_venda) valor_faturado
											from qlik.j_tab_fat_vendedor m
											where m.dta_referencia between
											to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
											and m.empresa||'.'||m.revenda in ('{$empresa}')
											and m.tipo in ('{$tipo}')
											and m.usuario in ({$vendedor})
											group by m.empresa, m.revenda, m.usuario, m.nome_vendedor,
											m.tipo, m.departamento, to_number(to_char(m.dta_referencia,'mm')), to_number(to_char(m.dta_referencia,'yyyy'))
										) s1
									) a1
									left join
									(
										select c.empresa, c.revenda, c.usuario_fat, c.mecanico, c.numero_nota_fiscal, c.serie_nota_fiscal, c.mes_emissao, c.ano_emissao, c.mes_cancelamento, c.ano_cancelamento, c.tipo, c.departamento, c.val_desconto
										from qlik.j_v_cancelamento_nota c
										where c.dta_cancelamento_nota between
										to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
										and c.empresa||'.'||c.revenda in ('{$empresa}')
										and c.tipo in ('{$tipo}')
										and c.usuario_fat in ({$vendedor})
									) a2
									on ( a1.empresa = a2.empresa and a1.revenda = a2.revenda
									and a1.mes_referencia = a2.mes_cancelamento and a1.ano_referencia = a2.ano_cancelamento
									and a1.tipo_item = a2.tipo and a1.departamento = a2.departamento and a1.usuario = a2.usuario_fat )
								) x1 group by x1.empresa, x1.usuario, x1.tipo_item, x1.mes_referencia, x1.ano_referencia, x1.valor_calc
							) b{$i} join ger_usuario gu on b{$i}.usuario = gu.usuario union ";
					}elseif ($por == "TIP"){
						$case = "case  ";
						$casem = "case  ";
						if (in_array("P", $considerar)){
							$case .= "when x1.tipo_item = 'P' then ".str_replace(",", ".", $campo_formula['COMISSAO_PECAS'])."";
							$casem .= "when x1.tipo_item = 'P' then {$campo_formula['META_PECAS']}";
						}
						if (in_array("S", $considerar)){
							$case .= "when x1.tipo_item = 'S' then ".str_replace(",", ".", $campo_formula['COMISSAO_MAODEOBRA'])."";
							$casem .= "when x1.tipo_item = 'S' then {$campo_formula['META_MAODEOBRA']}";
						}
						$case .= "else  0 end pct_comissao";
						$casem .= "else  0 end metadados ";
						$metapremio = (isset($campo_formula['META_PREMIO'])) ? ($campo_formula['META_PREMIO'] != "") ? $campo_formula['META_PREMIO'] : 0 : 0;
						return "select {$grupo} grupo, b{$i}.empresa, b{$i}.usuario, gu.nome, b{$i}.tipo_item, b{$i}.mes_referencia,
								b{$i}.ano_referencia, b{$i}.valor_faturado, b{$i}.val_desconto, b{$i}.valor_total, to_char(b{$i}.pct_comissao) pct_comissao, 
								b{$i}.metadados, to_char(round((b{$i}.valor_total*b{$i}.pct_comissao)/100,2)) valor_comissao, to_char(0) premio, {$metapremio} metapremio, gu.cpf
								from
								(
									select x1.empresa, x1.usuario, x1.tipo_item, x1.mes_referencia, x1.ano_referencia,
									to_char(sum(x1.valor_faturado)) valor_faturado, to_char(sum(x1.val_desconto)) val_desconto, to_char(sum(x1.valor_faturado)-sum(x1.val_desconto)) valor_total,
									{$case}, {$casem}
									from
									(
										select a1.empresa, a1.revenda, a1.nome, a1.usuario, a1.tipo_item, a1.departamento, a1.mes_referencia, a1.ano_referencia,
										a1.valor_faturado, nvl(a2.val_desconto,0) val_desconto, a1.valor_faturado-nvl(a2.val_desconto,0) valor_total
										from
										(
											select s1.*
											from
											( 
												select m.empresa, m.revenda, m.usuario, m.nome_vendedor nome,  m.tipo tipo_item, m.departamento,
												to_number(to_char(m.dta_referencia,'mm')) mes_referencia, to_number(to_char(m.dta_referencia,'yyyy')) ano_referencia,
												sum(m.valor_venda) valor_faturado
												from qlik.j_tab_fat_vendedor m
												where m.dta_referencia between
												to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
												and m.empresa||'.'||m.revenda in ('{$empresa}')
												and m.tipo in ('{$tipo}')
												and m.usuario in ({$vendedor})
												group by m.empresa, m.revenda, m.usuario, m.nome_vendedor,
												m.tipo, m.departamento, to_number(to_char(m.dta_referencia,'mm')), to_number(to_char(m.dta_referencia,'yyyy'))
											) s1
										) a1
										left join
										(
											select c.empresa, c.revenda, c.usuario_fat, c.mecanico, c.numero_nota_fiscal, c.serie_nota_fiscal, c.mes_emissao, c.ano_emissao, c.mes_cancelamento, c.ano_cancelamento, c.tipo, c.departamento, c.val_desconto
											from qlik.j_v_cancelamento_nota c
											where c.dta_cancelamento_nota between
											to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
											and c.empresa||'.'||c.revenda in ('{$empresa}')
											and c.tipo in ('{$tipo}')
											and c.usuario_fat in ({$vendedor})
										) a2
										on ( a1.empresa = a2.empresa and a1.revenda = a2.revenda
										and a1.mes_referencia = a2.mes_cancelamento and a1.ano_referencia = a2.ano_cancelamento
										and a1.tipo_item = a2.tipo and a1.departamento = a2.departamento and a1.usuario = a2.usuario_fat )
									) x1 group by x1.empresa, x1.usuario, x1.tipo_item, x1.mes_referencia, x1.ano_referencia
								) b{$i} join ger_usuario gu on b{$i}.usuario = gu.usuario union ";
					}
				}
			}elseif ($tip == 2){
				if ($por == "FAI"){
					$case = "case ";
					if ($auto == "S"){
						$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE1'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE1'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO1'])." ";
						$com = $campo_formula['FAI_COMISSAO1'];
						if (isset($campo_formula["FAI_DE2"])){
							$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE2'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE2'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO2'])." ";
							$com = $campo_formula['FAI_COMISSAO2'];
						}
						if (isset($campo_formula["FAI_DE3"])){
							$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE3'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE3'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO3'])." ";
							$com = $campo_formula['FAI_COMISSAO3'];
						}
						if (isset($campo_formula["FAI_DE4"])){
							$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE4'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE4'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO4'])." ";
							$com = $campo_formula['FAI_COMISSAO4'];
						}
						if (isset($campo_formula["FAI_DE5"])){
							$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE5'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE5'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO5'])." ";
							$com = $campo_formula['FAI_COMISSAO5'];
						}
						$case .= "when x1.valor_calc > 0 then ".str_replace(",", ".", $com)." ";
					}else{
						$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE1'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE1'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO1'])." ";
						$com = $campo_formula['FAI_COMISSAO1'];
						if (isset($campo_formula["FAI_DE2"])){
							$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE2'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE2'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO2'])." ";
							$com = $campo_formula['FAI_COMISSAO2'];
						}
						if (isset($campo_formula["FAI_DE3"])){
							$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE3'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE3'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO3'])." ";
							$com = $campo_formula['FAI_COMISSAO3'];
						}
						if (isset($campo_formula["FAI_DE4"])){
							$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE4'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE4'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO4'])." ";
							$com = $campo_formula['FAI_COMISSAO4'];
						}
						if (isset($campo_formula["FAI_DE5"])){
							$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE5'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE5'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO5'])." ";
							$com = $campo_formula['FAI_COMISSAO5'];
						}
						$case .= "when x1.valor_calc > 0 then ".str_replace(",", ".", $com)." ";
					}
					$casem = "case  ";
					if (in_array("N", $considerar)){
						$casem .= "when x1.tipo = 'N' then {$campo_formula['META_NOVOS']} ";
					}
					if (in_array("U", $considerar)){
						$casem .= "when x1.tipo = 'U' then {$campo_formula['META_USADOS']} ";
					}
					if (in_array("D", $considerar)){
						$casem .= "when x1.tipo = 'D' then {$campo_formula['META_DIRETO']} ";
					}
					if (in_array("C", $considerar)){
						$casem .= "when x1.tipo = 'C' then {$campo_formula['META_CONSORCIO']} ";
					}
					if (in_array("P", $considerar)){
						$casem .= "when x1.tipo = 'P' then {$campo_formula['META_PECAS']} ";
					}
					if (in_array("S", $considerar)){
						$casem .= "when x1.tipo = 'S' then {$campo_formula['META_MAODEOBRA']} ";
					}
					$case .= "else  0 end pct_comissao";
					$casem .= "else  0 end metadados";
					$metapremio = (isset($campo_formula['META_PREMIO'])) ? ($campo_formula['META_PREMIO'] != "") ? $campo_formula['META_PREMIO'] : 0 : 0;
					return "select {$grupo} grupo, b{$i}.empresa, b{$i}.usuario, b{$i}.nome, b{$i}.tipo tipo_item, b{$i}.mes_referencia,
							b{$i}.ano_referencia, b{$i}.valor_faturado, b{$i}.val_desconto, b{$i}.valor_total, to_char(b{$i}.pct_comissao) pct_comissao, 
							b{$i}.metadados, to_char(round((b{$i}.valor_total*b{$i}.pct_comissao)/100,2)) valor_comissao, to_char(0) premio, {$metapremio} metapremio, b{$i}.cpf
							from
							(
								select x1.empresa, x2.usuario, x2.nome, x2.cpf, x1.tipo, x1.mes_referencia, x1.ano_referencia,
								to_char(sum(x1.valor_faturado)) valor_faturado, to_char(sum(x1.val_desconto)) val_desconto, 
								to_char(sum(x1.valor_faturado)-sum(x1.val_desconto)) valor_total,
								{$case}, {$casem}
								from
								(
									select a1.empresa, a1.revenda, a1.nome, a1.usuario, a1.tipo, a1.departamento, a1.mes_referencia, a1.ano_referencia,
									a1.valor_faturado, nvl(a2.val_desconto,0) val_desconto,
									(
										select a1.valor_faturado-nvl((select sum(c.val_desconto) val_desconto
										from qlik.j_v_cancelamento_nota c
										where c.dta_cancelamento_nota between to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
										and c.empresa||'.'||c.revenda in ('{$empresa}') and c.tipo in ('{$tipo}') group by c.empresa),0)
										from
										(
											select sum(m.valor_venda) valor_faturado
											from qlik.j_tab_fat_vendedor m
											where m.dta_referencia between
											to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
											and m.empresa||'.'||m.revenda in ('{$empresa}')
											{$equipe}{$departamento}
											and m.tipo in ('{$tipo}')
										) a1
									) valor_calc
									from
									(
										select s1.*
										from
										(
											select m.empresa, m.revenda, m.usuario, m.nome_vendedor nome,  m.tipo, m.departamento,
											to_number(to_char(m.dta_referencia,'mm')) mes_referencia, to_number(to_char(m.dta_referencia,'yyyy')) ano_referencia,
											sum(m.valor_venda) valor_faturado
											from qlik.j_tab_fat_vendedor m
											where m.dta_referencia between
											to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
											and m.empresa||'.'||m.revenda in ('{$empresa}')
											{$equipe}{$departamento}
											and m.tipo in ('{$tipo}')
											group by m.empresa, m.revenda, m.usuario, m.nome_vendedor,
											m.tipo, m.departamento, to_number(to_char(m.dta_referencia,'mm')), to_number(to_char(m.dta_referencia,'yyyy'))
										) s1
									) a1
									left join
									(
										select c.empresa, c.revenda, c.usuario_fat, c.mecanico, c.numero_nota_fiscal, c.serie_nota_fiscal, c.mes_emissao, c.ano_emissao, c.mes_cancelamento, c.ano_cancelamento, c.tipo, c.departamento, c.val_desconto
										from qlik.j_v_cancelamento_nota c
										where c.dta_cancelamento_nota between
										to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
										and c.empresa||'.'||c.revenda in ('{$empresa}')
										and c.tipo in ('{$tipo}')
									) a2
									on ( a1.empresa = a2.empresa and a1.revenda = a2.revenda
									and a1.mes_referencia = a2.mes_cancelamento and a1.ano_referencia = a2.ano_cancelamento
									and a1.tipo = a2.tipo and a1.departamento = a2.departamento and a1.usuario = a2.usuario_fat )
								) x1 cross join (select b1.usuario, b1.nome, b1.cpf from ger_usuario b1 where b1.usuario in ({$vendedor})) x2 group by x1.empresa, x2.usuario, x2.nome, x2.cpf,x1.tipo,x1.mes_referencia, x1.ano_referencia, x1.valor_calc
							) b{$i} union ";
				}elseif ($por == "TIP"){
					$case = "case  ";
					$casem = "case  ";
					if (in_array("N", $considerar)){
						$case .= "when x1.tipo = 'N' then ".str_replace(",", ".", $campo_formula['COMISSAO_NOVOS'])."";
						$casem .= "when x1.tipo = 'N' then {$campo_formula['META_NOVOS']}";
					}
					if (in_array("U", $considerar)){
						$case .= "when x1.tipo = 'U' then ".str_replace(",", ".", $campo_formula['COMISSAO_USADOS'])."";
						$casem .= "when x1.tipo = 'U' then {$campo_formula['META_USADOS']}";
					}
					if (in_array("D", $considerar)){
						$case .= "when x1.tipo = 'D' then ".str_replace(",", ".", $campo_formula['COMISSAO_DIRETO'])." ";
						$casem .= "when x1.tipo = 'D' then {$campo_formula['META_DIRETO']}";
					}
					if (in_array("C", $considerar)){
						$case .= "when x1.tipo = 'C' then ".str_replace(",", ".", $campo_formula['COMISSAO_CONSORCIO'])." ";
						$casem .= "when x1.tipo = 'C' then {$campo_formula['META_CONSORCIO']}";
					}
					if (in_array("P", $considerar)){
						$case .= "when x1.tipo = 'P' then ".str_replace(",", ".", $campo_formula['COMISSAO_PECAS'])." ";
						$casem .= "when x1.tipo = 'P' then {$campo_formula['META_PECAS']}";
					}
					if (in_array("S", $considerar)){
						$case .= "when x1.tipo = 'S' then ".str_replace(",", ".", $campo_formula['COMISSAO_MAODEOBRA'])." ";
						$casem .= "when x1.tipo = 'S' then {$campo_formula['META_MAODEOBRA']}";
					}
					$case .= " else  0 end pct_comissao";
					$casem .= "else  0 end metadados";
					$metapremio = (isset($campo_formula['META_PREMIO'])) ? ($campo_formula['META_PREMIO'] != "") ? $campo_formula['META_PREMIO'] : 0 : 0;
					return "select {$grupo} grupo, b{$i}.empresa, b{$i}.usuario, b{$i}.nome, b{$i}.tipo tipo_item, b{$i}.mes_referencia,
							b{$i}.ano_referencia, b{$i}.valor_faturado, b{$i}.val_desconto, b{$i}.valor_total, to_char(b{$i}.pct_comissao) pct_comissao,
							b{$i}.metadados, to_char(round((b{$i}.valor_total*b{$i}.pct_comissao)/100,2)) valor_comissao, to_char(0) premio, {$metapremio} metapremio, b{$i}.cpf
							from
							(
								select x1.empresa, x2.usuario, x2.nome, x2.cpf, x1.tipo, x1.mes_referencia, x1.ano_referencia,
								to_char(sum(x1.valor_faturado)) valor_faturado, to_char(sum(x1.val_desconto)) val_desconto, 
								to_char(sum(x1.valor_faturado)-sum(x1.val_desconto)) valor_total,
								{$case}, {$casem}
								from
								(
									select a1.empresa, a1.revenda, a1.nome, a1.usuario, a1.tipo, a1.departamento, a1.mes_referencia, a1.ano_referencia,
									a1.valor_faturado, nvl(a2.val_desconto,0) val_desconto, a1.valor_faturado-nvl(a2.val_desconto,0) valor_total
									from
									(
										select s1.*
										from
										( 
											select m.empresa, m.revenda, m.usuario, m.nome_vendedor nome,  m.tipo, m.departamento,
											to_number(to_char(m.dta_referencia,'mm')) mes_referencia, to_number(to_char(m.dta_referencia,'yyyy')) ano_referencia,
											sum(m.valor_venda) valor_faturado
											from qlik.j_tab_fat_vendedor m
											where m.dta_referencia between
											to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
											and m.empresa||'.'||m.revenda in ('{$empresa}')
											{$equipe}{$departamento}
											and m.tipo in ('{$tipo}')
											group by m.empresa, m.revenda, m.usuario, m.nome_vendedor,
											m.tipo, m.departamento, to_number(to_char(m.dta_referencia,'mm')), to_number(to_char(m.dta_referencia,'yyyy'))
										) s1
									) a1
									left join
									(
										select c.empresa, c.revenda, c.usuario_fat, c.mecanico, c.numero_nota_fiscal, c.serie_nota_fiscal, c.mes_emissao, c.ano_emissao, c.mes_cancelamento, c.ano_cancelamento, c.tipo, c.departamento, c.val_desconto
										from qlik.j_v_cancelamento_nota c
										where c.dta_cancelamento_nota between
										to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
										and c.empresa||'.'||c.revenda in ('{$empresa}')
										and c.tipo in ('{$tipo}')
									) a2
									on ( a1.empresa = a2.empresa and a1.revenda = a2.revenda
									and a1.mes_referencia = a2.mes_cancelamento and a1.ano_referencia = a2.ano_cancelamento
									and a1.tipo = a2.tipo and a1.departamento = a2.departamento and a1.usuario = a2.usuario_fat )
								) x1 cross join (select b1.usuario, b1.nome, b1.cpf from ger_usuario b1 where b1.usuario in ({$vendedor})) x2 group by x1.empresa, x2.usuario, x2.nome, x2.cpf,x1.tipo,x1.mes_referencia, x1.ano_referencia
							) b{$i} union ";
				}
			}elseif ($tip == 3){
				if (($tip == 3) && (in_array("N", $considerar) || in_array("U", $considerar) || in_array("D", $considerar))){
					if ($por == "FAI"){
						
					}elseif ($por == "TIP"){
						$case = "case ";
						$casem = "case ";
						if (in_array("N", $considerar)){
							$case .= "when s1.tipo_item = 'N' then ".str_replace(",", ".", $campo_formula['COMISSAO_NOVOS'])."";
							$casem .= "when k1.tipo_item = 'N' then {$campo_formula['META_NOVOS']}";
						}
						if (in_array("U", $considerar)){
							$case .= "when s1.tipo_item = 'U' then ".str_replace(",", ".", $campo_formula['COMISSAO_USADOS'])."";
							$casem .= "when k1.tipo_item = 'U' then {$campo_formula['META_USADOS']}";
						}
						if (in_array("D", $considerar)){
							$case .= "when s1.tipo_item = 'D' then ".str_replace(",", ".", $campo_formula['COMISSAO_DIRETO'])."";
							$casem .= "when k1.tipo_item = 'D' then {$campo_formula['META_DIRETO']}";
						}
						$casem .= "else  0 end pct_comissao";
						$casem .= "else  0 end metadados";
						$metapremio = (isset($campo_formula['META_PREMIO'])) ? ($campo_formula['META_PREMIO'] != "") ? $campo_formula['META_PREMIO'] : 0 : 0;
						return "select {$grupo} grupo, b{$i}.empresa, b{$i}.usuario, b{$i}.nome, b{$i}.tipo_item, b{$i}.mes_referencia, 
								b{$i}.ano_referencia, b{$i}.valor_faturado, b{$i}.val_desconto, b{$i}.valor_total, b{$i}.pct_comissao, 
								b{$i}.metadados, b{$i}.valor_comissao, to_char(0) premio, {$metapremio} metapremio,
								b{$i}.cpf
								from
								(
									select k1.*,
									{$casem},k2.usuario, k2.nome, k2.cpf 
									from
									(
										select g1.empresa, g1.tipo_item, g1.mes_referencia, g1.ano_referencia,
										to_char(g1.valor_venda) valor_faturado, to_char(g1.val_desconto) val_desconto, to_char(g1.valor_total) valor_total,    
										from
										( 
										     select x1.empresa, x1.revenda, sum(x1.valor_venda) valor_venda, sum(x1.val_cancelamento) val_desconto, sum(x1.valor_total) valor_total,
										     to_char(round((sum(x1.valor_total)*x1.pct_comissao)/100,2)) valor_comissao, x1.pct_comissao, X1.mes_referencia, x1.ano_referencia, x1.tipo_item
										     from
										     (
										           select {$case}, s1.*, nvl(s2.val_cancelamento,0) val_cancelamento, s1.valor_venda-nvl(s2.val_cancelamento,0) valor_total
										           from
										           (
										             select v.empresa, v.revenda, case when v.tipo_item = 'R' then 'U' else v.tipo_item end tipo_item, sum(v.valor_venda)-nvl(sum(dv.valor_dv),0) valor_venda, 
										             to_number(to_char(v.DTA_ENTRADA_SAIDA,'mm')) mes_referencia, to_number(to_char(v.DTA_ENTRADA_SAIDA,'yyyy')) ano_referencia
										             from qlik.j_tab_vendedor_veiculo v
										             left join
										             (
										               select empresa, revenda, proposta, fat_oper, sum(valor_dv) valor_dv
										               from qlik.j_v_fiat_dv group by empresa, revenda, proposta, fat_oper 
										             ) dv on v.empresa = dv.empresa and v.revenda = dv.revenda and v.fat_oper = dv.fat_oper and nvl(v.proposta,0) = dv.proposta
										             where v.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
										             and ( (v.tipo_item in ('N') and v.empresa||'.'||v.revenda in ('{$empresa}') {$equipen}) or
										                   (v.tipo_item in ('U') and v.empresa||'.'||v.revenda in ('{$empresa}') {$equipeu}) or
										                   (v.tipo_item in ('D') and v.empresa||'.'||v.revenda in ('{$empresa}') {$equiped}) or
										                   (v.tipo_item in ('R') and v.empresa||'.'||v.revenda in ('{$empresa}') {$equipeu}) )
										             group by  v.empresa, v.revenda, v.tipo_item,
										             to_number(to_char(v.DTA_ENTRADA_SAIDA,'mm')), to_number(to_char(v.DTA_ENTRADA_SAIDA,'yyyy'))
										           ) s1
										           left join 
										           (
										              select  cv.empresa, cv.revenda, case when cv.TIPO_ITEM = 'R' then 'U' else cv.TIPO_ITEM end TIPO_ITEM, sum(cv.tot_nota_fiscal) val_cancelamento,
										              cv.MES_CANCELAMENTO, cv.ANO_CANCELAMENTO
										              from qlik.j_v_cancelamento_nota_veiculo cv
										              where cv.dta_cancelamento_nota between to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
										              group by cv.empresa, cv.revenda, cv.tipo_item, cv.MES_CANCELAMENTO, cv.ANO_CANCELAMENTO
										           ) s2 on (s1.empresa = s2.empresa and s1.revenda = s2.revenda and s1.tipo_item = s2.tipo_item and s1.mes_referencia = s2.MES_CANCELAMENTO and s1.ano_referencia = s2.ANO_CANCELAMENTO)
										      ) x1 group by x1.empresa, x1.revenda, X1.mes_referencia, x1.ano_referencia, x1.tipo_item
										 ) g1
								 	) k1
									cross join
								 	(
										select b1.usuario, b1.nome, b1.cpf from ger_usuario b1 where b1.usuario in ({$vendedor})
									) k2
									where k1.tipo_item in ('{$tipo}')
								) b{$i} union ";
					}
				}else{
					if ($campo_formula["FATURAMENTO"] == "M"){
						$case = "case  ";
						$case .= "when k1.pct_valor between ".str_replace(",", ".", $campo_formula['MARG_DE1'])." and ".str_replace(",", ".", $campo_formula['MARG_ATE1'])." then ".str_replace(",", ".", $campo_formula['MARG_COMISSAO1'])." ";
						$com = $campo_formula['MARG_COMISSAO1'];
						if (isset($campo_formula["MARG_DE2"])){
							$case .= "when k1.pct_valor between ".str_replace(",", ".", $campo_formula['MARG_DE2'])." and ".str_replace(",", ".", $campo_formula['MARG_ATE2'])." then ".str_replace(",", ".", $campo_formula['MARG_COMISSAO2'])." ";
							$com = $campo_formula['MARG_COMISSAO2'];
						}
						if (isset($campo_formula["MARG_DE3"])){
							$case .= "when k1.pct_valor between ".str_replace(",", ".", $campo_formula['MARG_DE3'])." and ".str_replace(",", ".", $campo_formula['MARG_ATE3'])." then ".str_replace(",", ".", $campo_formula['MARG_COMISSAO3'])." ";
							$com = $campo_formula['MARG_COMISSAO3'];
						}
						if (isset($campo_formula["MARG_DE4"])){
							$case .= "when k1.pct_valor between ".str_replace(",", ".", $campo_formula['MARG_DE4'])." and ".str_replace(",", ".", $campo_formula['MARG_ATE4'])." then ".str_replace(",", ".", $campo_formula['MARG_COMISSAO4'])." ";
							$com = $campo_formula['MARG_COMISSAO4'];
						}
						if (isset($campo_formula["MARG_DE5"])){
							$case .= "when k1.pct_valor between ".str_replace(",", ".", $campo_formula['MARG_DE5'])." and ".str_replace(",", ".", $campo_formula['MARG_ATE5'])." then ".str_replace(",", ".", $campo_formula['MARG_COMISSAO5'])." ";
							$com = $campo_formula['MARG_COMISSAO5'];
						}
						$case .= "when k1.pct_valor > 0 then ".str_replace(",", ".", $com)." ";
						
						$casem = "case  ";
						if (in_array("N", $considerar)){
							$casem .= "when k1.tipo_item = 'N' then {$campo_formula['META_NOVOS']} ";
						}
						if (in_array("U", $considerar)){
							$casem .= "when k1.tipo_item = 'U' then {$campo_formula['META_USADOS']} ";
						}
						if (in_array("D", $considerar)){
							$casem .= "when k1.tipo_item = 'D' then {$campo_formula['META_DIRETO']} ";
						}
						if (in_array("C", $considerar)){
							$casem .= "when k1.tipo_item = 'C' then {$campo_formula['META_CONSORCIO']} ";
						}
						if (in_array("P", $considerar)){
							$casem .= "when k1.tipo_item = 'P' then {$campo_formula['META_PECAS']} ";
						}
						if (in_array("S", $considerar)){
							$casem .= "when k1.tipo_item = 'S' then {$campo_formula['META_MAODEOBRA']} ";
						}
						$case .= "else  0 end pct_comissao";
						$casem .= "else  0 end metadados";
						$metapremio = (isset($campo_formula['META_PREMIO'])) ? ($campo_formula['META_PREMIO'] != "") ? $campo_formula['META_PREMIO'] : 0 : 0;
						return	"select {$grupo} grupo, b{$i}.empresa, b{$i}.usuario, b{$i}.nome, b{$i}.tipo_item, b{$i}.mes_referencia, b{$i}.ano_referencia,
								b{$i}.valor_faturado, b{$i}.val_desconto, b{$i}.valor_total, to_char(b{$i}.pct_comissao) pct_comissao, b{$i}.metadados,
								to_char(round((b{$i}.valor_total*b{$i}.pct_comissao)/100,2)) valor_comissao, to_char(0) premio, {$metapremio} metapremio, b{$i}.cpf
								from
								(
									select k1.*,
									{$case}, {$casem}, k2.usuario, k2.nome, k2.cpf
									from
									(
										select v1.empresa, v1.revenda, v1.tipo_item, v1.mes_referencia, v1.ano_referencia, v1.valor_faturado,
									   	v1.val_desconto, v1.valor_total, v1.pct_comissao, round((v1.valor_total*v1.pct_comissao)/100,2) valor_comissao
									   	from
									   	(
									   		select h1.empresa, h1.revenda, h1.tipo_item, (h1.receita-h1.despesa)-nvl(h2.valor,0) valor_faturado, (h1.receita-h1.despesa)-nvl(h2.valor,0) valor_total, 
									     	h1.val_desconto, h1.mes_referencia, h1.ano_referencia,
									     	round((((h1.receita-h1.despesa)-nvl(h2.valor,0))/h1.receita)*100,2) pct_valor, 
									     	case when round((((h1.receita-h1.despesa)-nvl(h2.valor,0))/h1.receita)*100,2) between 20 and 30.9 then 1.5
									        	when round((((h1.receita-h1.despesa)-nvl(h2.valor,0))/h1.receita)*100,2) between 31 and 40 then 2
									          	when round((((h1.receita-h1.despesa)-nvl(h2.valor,0))/h1.receita)*100,2) > 40 then 2.4 else 0 end pct_comissao
									     
									     	from
									     	(  
									       		select g1.empresa, g1.revenda, case when g1.familia = 'Assist�ncia T�cnica' then 'S' when g1.familia = 'Pe�as' then 'P' end tipo_item, 
									       		sum(g1.valor) receita, sum(g2.valor) despesa, 0 val_desconto, 
									      	 	g1.mes_referencia, g2.ano_referencia
									       		from
									       		(
									          		select x1.empresa, x1.revenda, x1.FAMILIA, sum(x1.valor) valor, x1.MES_REFERENCIA, x1.ANO_REFERENCIA
									          		from qlik.j_v_deg_receitas x1
									          		where x1.data between to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy') 
									          		and x1.empresa||'.'||x1.revenda in ('{$empresa}')
									          		group by x1.empresa, x1.revenda, x1.familia, x1.mes_referencia, x1.ano_referencia  
									       		) g1
									       		join    
									       		(   
									          		select x1.empresa, x1.revenda, x1.FAMILIA, sum(x1.valor) valor, x1.MES_REFERENCIA, x1.ANO_REFERENCIA
									          		from qlik.j_v_deg_desp_cust x1
									          		where  x1.data between to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
									         		and x1.empresa||'.'||x1.revenda in ('{$empresa}')
									          		group by x1.empresa, x1.revenda, x1.familia, x1.mes_referencia, x1.ano_referencia  
									       		) g2 on (g1.empresa = g2.empresa and g1.revenda = g2.revenda and g1.familia = g2.familia 
									                and g1.mes_referencia = g1.mes_referencia and g1.ano_referencia = g2.ano_referencia)  
									       		group by g1.empresa, g1.revenda, g1.familia, g1.mes_referencia, g2.ano_referencia 
									     	) h1
										     left join 
										     ( select m.* from qlik.j_v_desp_nivel_3_mes_anteior m 
										       where m.DATA between last_day(add_months(to_date('{$de}','dd/mm/yyyy'),-2))+1
										       and last_day(add_months(to_date('{$ate}','dd/mm/yyyy'),-1))
										     ) h2
									     	on h1.empresa = h2.EMPRESA and h1.REVENDA = h2.REVENDA and h1.tipo_item = h2.tipo_item
									   ) v1 

									) k1
									cross join 
									(
										select b1.usuario, b1.nome, b1.cpf from ger_usuario b1 where b1.usuario in ({$vendedor})
									) k2
									where k1.tipo_item in ('{$tipo}')
								) b{$i} union ";
					}elseif ($por == "FAI"){
						$case = "case ";
						if ($auto == "S"){
							$case .= "when k1.valor_total between ".str_replace(",", ".", $campo_formula['FAI_DE1'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE1'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO1'])."";
							$com = $campo_formula['FAI_COMISSAO1'];
							if (isset($campo_formula["FAI_DE2"])){
								$case .= "when k1.valor_total between ".str_replace(",", ".", $campo_formula['FAI_DE2'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE2'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO2'])."";
								$com = $campo_formula['FAI_COMISSAO2'];
							}
							if (isset($campo_formula["FAI_DE3"])){
								$case .= "when k1.valor_total between ".str_replace(",", ".", $campo_formula['FAI_DE3'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE3'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO3'])." ";
								$com = $campo_formula['FAI_COMISSAO3'];
							}
							if (isset($campo_formula["FAI_DE4"])){
								$case .= "when k1.valor_total between ".str_replace(",", ".", $campo_formula['FAI_DE4'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE4'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO4'])." ";
								$com = $campo_formula['FAI_COMISSAO4'];
							}
							if (isset($campo_formula["FAI_DE5"])){
								$case .= "when k1.valor_total between ".str_replace(",", ".", $campo_formula['FAI_DE5'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE5'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO5'])." ";
								$com = $campo_formula['FAI_COMISSAO5'];
							}
							$case .= "when k1.valor_total > 0 then ".str_replace(",", ".", $com)." ";
						}else{
							$case .= "when k1.valor_total between ".str_replace(",", ".", $campo_formula['FAI_DE1'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE1'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO1'])." ";
							$com = $campo_formula['FAI_COMISSAO1'];
							if (isset($campo_formula["FAI_DE2"])){
								$case .= "when k1.valor_total between ".str_replace(",", ".", $campo_formula['FAI_DE2'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE2'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO2'])." ";
								$com = $campo_formula['FAI_COMISSAO2'];
							}
							if (isset($campo_formula["FAI_DE3"])){
								$case .= "when k1.valor_total between ".str_replace(",", ".", $campo_formula['FAI_DE3'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE3'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO3'])." ";
								$com = $campo_formula['FAI_COMISSAO3'];
							}
							if (isset($campo_formula["FAI_DE4"])){
								$case .= "when k1.valor_total between ".str_replace(",", ".", $campo_formula['FAI_DE4'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE4'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO4'])." ";
								$com = $campo_formula['FAI_COMISSAO4'];
							}
							if (isset($campo_formula["FAI_DE5"])){
								$case .= "when k1.valor_total between ".str_replace(",", ".", $campo_formula['FAI_DE5'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE5'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO5'])." ";
								$com = $campo_formula['FAI_COMISSAO5'];
							}
							$case .= "when k1.valor_total > 0 then ".str_replace(",", ".", $com)." ";
						}
						
						$casem = "case  ";
						if (in_array("N", $considerar)){
							$casem .= "when k1.tipo_item = 'N' then {$campo_formula['META_NOVOS']} ";
						}
						if (in_array("U", $considerar)){
							$casem .= "when k1.tipo_item = 'U' then {$campo_formula['META_USADOS']} ";
						}
						if (in_array("D", $considerar)){
							$casem .= "when k1.tipo_item = 'D' then {$campo_formula['META_DIRETO']} ";
						}
						if (in_array("C", $considerar)){
							$casem .= "when k1.tipo_item = 'C' then {$campo_formula['META_CONSORCIO']} ";
						}
						if (in_array("P", $considerar)){
							$casem .= "when k1.tipo_item = 'P' then {$campo_formula['META_PECAS']} ";
						}
						if (in_array("S", $considerar)){
							$casem .= "when k1.tipo_item = 'S' then {$campo_formula['META_MAODEOBRA']} ";
						}
						$case .= "else  0 end pct_comissao";
						$casem .= "else  0 end metadados";
						$metapremio = (isset($campo_formula['META_PREMIO'])) ? ($campo_formula['META_PREMIO'] != "") ? $campo_formula['META_PREMIO'] : 0 : 0;
						return "select {$grupo} grupo, b{$i}.empresa, b{$i}.usuario, b{$i}.nome, b{$i}.tipo_item, b{$i}.mes_referencia, b{$i}.ano_referencia,
								b{$i}.valor_faturado, b{$i}.val_desconto, b{$i}.valor_total, to_char(b{$i}.pct_comissao) pct_comissao, b{$i}.metadados,
								to_char(round((b{$i}.valor_total*b{$i}.pct_comissao)/100,2)) valor_comissao, to_char(0) premio, {$metapremio} metapremio, b{$i}.cpf
								from
								(
									select k1.*,
									{$case}, {$casem}, k2.usuario, k2.nome, k2.cpf
									from
									(
										select g1.empresa, g1.tipo_item,
										to_char(sum(g1.valor)-sum(g2.valor)) valor_faturado, to_char(0) val_desconto,
										to_char(sum(g1.valor)-sum(g2.valor)) valor_total,
										round(((sum(g1.valor)-sum(g2.valor))/sum(g1.valor))*100,2) pct_valor,
										g1.mes_referencia, g2.ano_referencia
										from
										(
											select x1.empresa, x1.revenda, x1.familia, case when x1.familia = 'Assist�ncia T�cnica' then 'S' when x1.familia = 'Pe�as' then 'P' end tipo_item,
											sum(x1.valor) valor, x1.MES_REFERENCIA, x1.ANO_REFERENCIA
											from qlik.j_v_deg_receitas x1
											where x1.data between
											to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
											and x1.empresa||'.'||x1.revenda in ('{$empresa}')
											group by x1.empresa, x1.revenda, x1.familia,x1.mes_referencia, x1.ano_referencia
										) g1
										join
										(
											select x1.empresa, x1.revenda, x1.FAMILIA, sum(x1.valor) valor, x1.MES_REFERENCIA, x1.ANO_REFERENCIA
											from qlik.j_v_deg_desp_cust x1
											where  x1.data between
											to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
											and x1.empresa||'.'||x1.revenda in ('{$empresa}')
											group by x1.empresa, x1.revenda, x1.familia, x1.mes_referencia, x1.ano_referencia
										) g2
										on (g1.empresa = g2.empresa and g1.revenda = g2.revenda and g1.familia = g2.familia
										and g1.mes_referencia = g1.mes_referencia and g1.ano_referencia = g2.ano_referencia)
										group by g1.empresa, g1.tipo_item, g1.mes_referencia, g2.ano_referencia
									) k1
									cross join 
									(
										select b1.usuario, b1.nome, b1.cpf from ger_usuario b1 where b1.usuario in ({$vendedor})
									) k2
									where k1.tipo_item in ('{$tipo}')
								) b{$i} union ";
					}elseif ($por == "TIP"){
						$case = "case  ";
						$casem = "case  ";
						if (in_array("N", $considerar)){
							$case .= "when k1.tipo_item = 'N' then ".str_replace(",", ".", $campo_formula['COMISSAO_NOVOS'])."";
							$casem .= "when k1.tipo_item = 'N' then {$campo_formula['META_NOVOS']}";
						}
						if (in_array("U", $considerar)){
							$case .= "when k1.tipo_item = 'U' then ".str_replace(",", ".", $campo_formula['COMISSAO_USADOS'])."";
							$casem .= "when k1.tipo_item = 'U' then {$campo_formula['META_USADOS']}";
						}
						if (in_array("D", $considerar)){
							$case .= "when k1.tipo_item = 'D' then ".str_replace(",", ".", $campo_formula['COMISSAO_DIRETO'])." ";
							$casem .= "when k1.tipo_item = 'D' then {$campo_formula['META_DIRETO']}";
						}
						if (in_array("C", $considerar)){
							$case .= "when k1.tipo_item = 'C' then ".str_replace(",", ".", $campo_formula['COMISSAO_CONSORCIO'])."";
							$casem .= "when k1.tipo_item = 'C' then {$campo_formula['META_CONSORCIO']}";
						}
						if (in_array("P", $considerar)){
							$case .= "when k1.tipo_item = 'P' then ".str_replace(",", ".", $campo_formula['COMISSAO_PECAS'])."";
							$casem .= "when k1.tipo_item = 'P' then {$campo_formula['META_PECAS']}";
						}
						if (in_array("S", $considerar)){
							$case .= "when k1.tipo_item = 'S' then ".str_replace(",", ".", $campo_formula['COMISSAO_MAODEOBRA'])."";
							$casem .= "when k1.tipo_item = 'S' then {$campo_formula['META_MAODEOBRA']}";
						}
						$case .= "else  0 end pct_comissao";
						$casem .= "else  0 end metadados ";
						$metapremio = (isset($campo_formula['META_PREMIO'])) ? ($campo_formula['META_PREMIO'] != "") ? $campo_formula['META_PREMIO'] : 0 : 0;
						
						return "select {$grupo} grupo, b{$i}.empresa, b{$i}.usuario, b{$i}.nome, b{$i}.tipo_item, b{$i}.mes_referencia, b{$i}.ano_referencia,
								b{$i}.valor_faturado, b{$i}.val_desconto, b{$i}.valor_total, to_char(b{$i}.pct_comissao) pct_comissao, b{$i}.metadados,
								to_char(round((b{$i}.valor_total*b{$i}.pct_comissao)/100,2)) valor_comissao, to_char(0) premio, {$metapremio} metapremio, b{$i}.cpf
								from
								(
									select k1.*,
									{$case}, {$casem}, k2.usuario, k2.nome, k2.cpf
									from
									(
										select g1.empresa, g1.tipo_item,
										to_char(sum(g1.valor)-sum(g2.valor)) valor_faturado, to_char(0) val_desconto,
										to_char(sum(g1.valor)-sum(g2.valor)) valor_total,
										round(((sum(g1.valor)-sum(g2.valor))/sum(g1.valor))*100,2) pct_valor,
										g1.mes_referencia, g2.ano_referencia
										from
										(
											select x1.empresa, x1.revenda, x1.familia, case when x1.familia = 'Assist�ncia T�cnica' then 'S' when x1.familia = 'Pe�as' then 'P' end tipo_item,
											sum(x1.valor) valor, x1.MES_REFERENCIA, x1.ANO_REFERENCIA
											from qlik.j_v_deg_receitas x1
											where x1.data between
											to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
											and x1.empresa||'.'||x1.revenda in ('{$empresa}')
											group by x1.empresa, x1.revenda, x1.familia,x1.mes_referencia, x1.ano_referencia
										) g1
										join
										(
											select x1.empresa, x1.revenda, x1.FAMILIA, sum(x1.valor) valor, x1.MES_REFERENCIA, x1.ANO_REFERENCIA
											from qlik.j_v_deg_desp_cust x1
											where  x1.data between
											to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
											and x1.empresa||'.'||x1.revenda in ('{$empresa}')
											group by x1.empresa, x1.revenda, x1.familia, x1.mes_referencia, x1.ano_referencia
										) g2
										on (g1.empresa = g2.empresa and g1.revenda = g2.revenda and g1.familia = g2.familia
										and g1.mes_referencia = g1.mes_referencia and g1.ano_referencia = g2.ano_referencia)
										group by g1.empresa, g1.tipo_item, g1.mes_referencia, g2.ano_referencia
									) k1
									cross join 
									(
										select b1.usuario, b1.nome, b1.cpf from ger_usuario b1 where b1.usuario in ({$vendedor})
									) k2
									where k1.tipo_item in ('{$tipo}')
								) b{$i} union ";
					}
				}
			}elseif ($tip == 8){
				if ($por == "FAI"){
					
				}elseif ($por == "TIP"){
					$casem = "case  ";
					if (in_array("N", $considerar)){
						$casem .= "when k1.tipo_item = 'N' then {$campo_formula['META_NOVOS']}";
					}
					if (in_array("U", $considerar)){
						$casem .= "when k1.tipo_item = 'U' then {$campo_formula['META_USADOS']}";
					}
					if (in_array("U", $considerar)){
						$casem .= "when k1.tipo_item = 'D' then {$campo_formula['META_DIRETO']}";
					}
					$casem .= "else  0 end metadados";
					$metapremio = (isset($campo_formula['META_PREMIO'])) ? ($campo_formula['META_PREMIO'] != "") ? $campo_formula['META_PREMIO'] : 0 : 0;
					return "select {$grupo} grupo, b{$i}.empresa, b{$i}.usuario, b{$i}.nome, b{$i}.tipo_item, b{$i}.mes_referencia, b{$i}.ano_referencia,
							b{$i}.valor_faturado, b{$i}.val_desconto, b{$i}.valor_total, b{$i}.pct_comissao, b{$i}.metadados,
							b{$i}.valor_comissao, to_char(0) premio, {$metapremio} metapremio, b{$i}.cpf
							from
							(
								select x1.empresa, x1.revenda, x2.nome, x2.cpf, x1.tipo_item, x1.mes_referencia, x1.ano_referencia, 
							    to_char(x1.val_p_contrato) valor_faturado,
							    to_char(x1.valor_p_contrato_cancelado) val_desconto,
							    to_char(x1.valor_p_contrato) valor_total,
							    to_char(0) pct_comissao, {$casem},
							    to_char(x1.valor_p_contrato) valor_comissao
							    from
							    (
									select s1.empresa, s1.revenda, s1.tipo_item, s1.mes_referencia, s1.ano_referencia, 
						          	s1.val_p_contrato, nvl(s2.valor_p_contrato_cancelado,0) valor_p_contrato_cancelado, 
						          	s1.val_p_contrato-nvl(s2.valor_p_contrato_cancelado,0) valor_p_contrato  
						          	from
						          	(
						            	select c1.empresa, c1.revenda, c1.tipo_item, to_number(to_char(c1.DTA_ENTRADA_SAIDA,'mm')) mes_referencia, to_number(to_char(c1.DTA_ENTRADA_SAIDA,'yyyy')) ano_referencia,
						              	sum(nvl(c1.valor_p_contrato,2)) val_p_contrato
						              	from qlik.j_v_operador_FeI_NDU_fiat  c1
						              	where c1.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
						              	and c1.empresa||'.'||c1.revenda in ('{$empresa}')
						              	group by c1.empresa, c1.revenda, c1.tipo_item,
						              	to_number(to_char(c1.DTA_ENTRADA_SAIDA,'mm')), to_number(to_char(c1.DTA_ENTRADA_SAIDA,'yyyy'))
						          	) s1
						          	left join
						          	(
						            	select cv.empresa, cv.revenda, cv.TIPO_ITEM, sum(cv.tot_nota_fiscal) val_cancelamento,
						              	sum(nvl(cv.valor_financiado,0)) valor_financiado_cancelado, sum(nvl2(cv.valor_financiado,18,0)) valor_p_contrato_cancelado, sum(nvl(cv.valor_acessorio_financiado,0)) valor_acess_finan_cancelado 
						              	from qlik.j_v_cancelamento_nota_veiculo cv
						              	where cv.TIPO_ITEM in ('{$tipo}')  
						              	and cv.dta_cancelamento_nota between to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
						              	group by cv.empresa, cv.revenda, cv.tipo_transacao,  cv.TIPO_ITEM
						          	) s2 on (s1.empresa = s2.empresa and s1.revenda = s2.revenda and s1.tipo_item = s2.tipo_item)
								) x1 cross join (select b1.usuario, b1.nome, b1.cpf from ger_usuario b1 where b1.usuario in ({$vendedor})) x2 group by x1.empresa, x2.usuario, x2.nome, x2.cpf,x1.tipo,x1.mes_referencia, x1.ano_referencia
							) b{$i} union ";
				}
			}elseif ($tip == 9){
				if ($por == "FAI"){
					
				}elseif ($por == "TIP"){
					$casem = "case  ";
					if (in_array("U", $considerar)){
						$casem .= "when g1.tipo_item = 'U' then {$campo_formula['META_USADOS']}";
					}
					$casem .= "else  0 end metadados";
					$metapremio = (isset($campo_formula['META_PREMIO'])) ? ($campo_formula['META_PREMIO'] != "") ? $campo_formula['META_PREMIO'] : 0 : 0;
					return "select b{$i}.grupo, b{$i}.empresa, b1.usuario, b{$i}.nome, b{$i}.tipo_item, b{$i}.mes_referencia, b{$i}.ano_referencia, to_char(sum(b{$i}.valor_faturado)) valor_faturado, 
							to_char(sum(b{$i}.val_desconto)) val_desconto, to_char(sum(b{$i}.valor_total)) valor_total, to_char(sum(b{$i}.pct_comissao)) pct_comissao, b{$i}.metadados, to_char(sum(b{$i}.valor_comissao)) valor_comissao,
							to_char(sum(b{$i}.premio)) premio, b{$i}.metapremio, b{$i}.cpf   
							from
							(
								select {$grupo} grupo, b{$i}.*
								from
								(
									select g1.empresa, g1.avaliador usuario, g1.nome_avaliador nome, g1.tipo_item, g1.mes_referencia, g1.ano_referencia, 
								    to_char(g1.valor_saida) valor_faturado,  
								    to_char(g1.val_p_saida_cancelado) val_desconto, to_char(g1.valor_total_saida) valor_total, to_char(0) pct_comissao, {$casem}, 
									to_char(g1.valor_total_saida) valor_comissao, to_char(0) premio, {$metapremio} metapremio, g1.cpf  
								    from
								    (
								    	select x1.empresa, x1.revenda, x1.avaliador, x1.nome_avaliador, x1.tipo_item, sum(x1.valor_saida) valor_saida,   
								        sum(x1.val_p_saida_cancelado) val_p_saida_cancelado, sum(x1.valor_total_saida) valor_total_saida,
								        x1.mes_referencia, x1.ano_referencia, u.cpf   
								        from
								        (
								        	select s1.*, nvl(s2.val_p_saida_cancelado,0) val_p_saida_cancelado, 
								            s1.valor_saida-nvl(s2.val_p_saida_cancelado,0) valor_total_saida
								            from
								            (
								            	select v.empresa, v.revenda, v.vendedor, ss1.avaliador, ss1.nome nome_avaliador, 'U' tipo_item, sum(ss1.valor_saida) valor_saida, 
								                to_number(to_char(v.DTA_ENTRADA_SAIDA,'mm')) mes_referencia, to_number(to_char(v.DTA_ENTRADA_SAIDA,'yyyy')) ano_referencia
								                from qlik.j_tab_vendedor_veiculo v
								                join 
								                (
								                	select s1.*, 100 valor_saida, av.avaliador, av.usuario, av.nome
								                    from
								                    (
								                    	select distinct ve.empresa, ve.revenda, ve.veiculo, vi.chassi
								                        from cnp.fat_movimento_veiculo ve
								                        join cnp.fat_movimento_capa fc 
								                        on ve.EMPRESA = fc.empresa and ve.REVENDA = fc.revenda and ve.NUMERO_NOTA_FISCAL = fc.numero_nota_fiscal and 
								                        ve.SERIE_NOTA_FISCAL = fc.serie_nota_fiscal and ve.TIPO_TRANSACAO = fc.tipo_transacao and ve.CONTADOR = fc.contador
								                        join cnp.vei_veiculo vi on ve.empresa = vi.empresa and ve.veiculo = vi.veiculo
								                        where ve.tipo_transacao = 'U21' 
								                        and ve.empresa||'.'||ve.revenda in ('{$empresa}')
								                        and fc.dta_entrada_saida between to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
								                      ) s1
								                      join                  
								                      (  
								                        select ve.empresa, ve.revenda, ve.veiculo, vi.chassi
								                        from cnp.fat_movimento_veiculo ve
								                        join cnp.vei_veiculo vi on ve.empresa = vi.empresa and ve.veiculo = vi.veiculo
								                        where ve.tipo_transacao = 'U01' 
								                        and ve.empresa||'.'||ve.revenda in ('{$empresa}')
								                      ) s2
								                      on s1.chassi = s2.chassi and s1.veiculo = s2.veiculo
								                      join
								                      (  
								                        select av0.chassi, max(av0.dta_avaliacao) dta_avaliacao, av0.avaliador,  u.usuario, u.nome 
								                        from cnp.vei_avaliacao av0 join cnp.ger_usuario u on av0.avaliador = u.usuario 
								                        group by av0.chassi, av0.avaliador,  u.usuario, u.nome 
								                      ) av on s1.chassi = av.chassi
								                 ) ss1 on ss1.empresa = v.empresa and ss1.revenda = v.revenda and v.veiculo =  ss1.veiculo 
								                 where v.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
								                 and v.tipo_transacao = 'U21' 
								                 and v.empresa||'.'||v.revenda in ('{$empresa}')
								                 group by v.empresa, v.revenda, v.vendedor, v.tipo_item,  ss1.avaliador, ss1.nome,
								                 to_number(to_char(v.DTA_ENTRADA_SAIDA,'mm')), to_number(to_char(v.DTA_ENTRADA_SAIDA,'yyyy'))
								            ) s1
								            left join
								            (
								            	select cv.empresa, cv.revenda, cv.usuario_fat, cv.tipo_item, sum(cv.val_p_saida) val_p_saida_cancelado
								                from qlik.j_v_cancelamento_nota_veiculo cv
								                where cv.dta_cancelamento_nota between to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
								                group by cv.empresa, cv.revenda, cv.usuario_fat, cv.tipo_transacao, cv.tipo_item
								             ) s2 on (s1.empresa = s2.empresa and s1.revenda = s2.revenda and s1.vendedor = s2.usuario_fat and s1.tipo_item = s2.tipo_item)
								
								         ) x1 left join cnp.ger_usuario u on x1.avaliador = u.usuario 
								         group by x1.empresa, x1.revenda, x1.avaliador, x1.nome_avaliador, x1.tipo_item, x1.mes_referencia, x1.ano_referencia, u.cpf
								    ) g1
	
									union all							  
							
								   	select g1.empresa, g1.avaliador usuario, g1.nome_avaliador nome, g1.tipo_item, g1.mes_referencia, g1.ano_referencia, to_char(g1.valor_total_entrada) valor_faturado,  
								   	to_char(0) val_desconto, to_char(g1.valor_total_entrada) valor_total, to_char(0) pct_comissao, {$casem}, to_char(g1.valor_total_entrada) valor_comissao, to_char(0) premio, {$metapremio} metapremio, g1.cpf   
								   	from
								   	(     
								    	select x1.empresa, x1.revenda, x1.avaliador, x1.nome_avaliador, x1.tipo_item, sum(x1.valor_total_entrada) valor_total_entrada, 
								        sum(0) val_p_saida_cancelado,
								        x1.mes_referencia, x1.ano_referencia, u.cpf   
								        from
								        (
								        	select s1.empresa, s1.revenda, s1.avaliador, s1.nome nome_avaliador, 'U' tipo_item, s1.valor_entrada valor_total_entrada, s1.dta_entrada,
								            to_number(to_char(s1.dta_entrada,'mm')) mes_referencia, to_number(to_char(s1.dta_entrada,'yyyy')) ano_referencia
								            from
								            (
								                select s2.empresa, s2.revenda, s1.*, s2.dta_entrada, s2.veiculo, 100 valor_entrada
								                from
								                (
								                  select ve.empresa, ve.revenda, ve.veiculo, vi.chassi, vi.dta_entrada 
								                  from cnp.fat_movimento_veiculo ve
								                  join cnp.vei_veiculo vi on ve.empresa = vi.empresa and ve.veiculo = vi.veiculo
								                  where ve.tipo_transacao = 'U01' 
								                  and ve.empresa||'.'||ve.revenda in ('{$empresa}')
								                  and vi.dta_entrada between to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
								                ) s2 
								                join
								                (  
								                  select av0.chassi, max(av0.dta_avaliacao) dta_avaliacao, av0.avaliador,  u.usuario, u.nome 
								                  from cnp.vei_avaliacao av0 join cnp.ger_usuario u on av0.avaliador = u.usuario 
								                  group by av0.chassi, av0.avaliador,  u.usuario, u.nome  
								                ) s1  
								                on s1.chassi = s2.chassi
								            ) s1
								        ) x1 left join cnp.ger_usuario u on x1.avaliador = u.usuario 
								        group by x1.empresa, x1.revenda, x1.avaliador, x1.nome_avaliador, x1.tipo_item, x1.mes_referencia, x1.ano_referencia, u.cpf
								   	) g1
								) b{$i} where b{$i}.usuario in('{$vendedor}')
							) b{$i} group by b{$i}.grupo, b{$i}.empresa, b{$i}.usuario, b{$i}.nome, b{$i}.tipo_item, b{$i}.mes_referencia, b{$i}.ano_referencia, b{$i}.metadados, b{$i}.metapremio, b{$i}.cpf union ";
				}
			}elseif ($tip == 10){
				if ($por == "FAI"){
					
				}elseif ($por == "TIP"){
					$casem = "case  ";
					if (in_array("U", $considerar)){
						$casem .= "when s1.tipo_item = 'U' then {$campo_formula['META_USADOS']}";
					}
					$casem .= "else  0 end metadados";
					$metapremio = (isset($campo_formula['META_PREMIO'])) ? ($campo_formula['META_PREMIO'] != "") ? $campo_formula['META_PREMIO'] : 0 : 0;
					return "select {$grupo} grupo, b{$i}.*
							from
							(
								select s1.empresa, s1.usuario, s1.nome, s1.tipo_item, s1.mes_referencia, s1.ano_referencia, to_char(s1.valor_lucro) valor_faturado,
							  	to_char(nvl(s2.valor_lucro_cancelado,0)) val_desconto, to_char(s1.valor_lucro-nvl(s2.valor_lucro_cancelado,0)) valor_total, to_char(10) pct_comissao,
								{$casem},
							    to_char(round(((s1.valor_lucro-nvl(s2.valor_lucro_cancelado,0))*10)/100,2)) valor_comissao, to_char(0) premio, {$metapremio} metapremio, u.cpf   
							   	from
							   	(
							    	select a1.empresa, a1.revenda, a1.vendedor usuario, a1.nome_vendedor nome, 'U' tipo_item, sum(a1.valor_venda), sum(a1.valor_custo_contabil), 
							      	sum(a1.valor_lucro) valor_lucro, 
							      	to_number(to_char(a1.DTA_ENTRADA_SAIDA,'mm')) mes_referencia,  to_number(to_char(a1.DTA_ENTRADA_SAIDA,'yyyy')) ano_referencia 
							      	from
							      	(  
								         select v.*, c.icms, c.pis_cofins, 
								         case when v.valor_venda-(v.valor_custo_contabil+(round((valor_venda*c.icms)/100,2))+(round(((v.valor_venda-v.valor_custo_contabil)*c.pis_cofins)/100,2))) < 0 then 0
								         else v.valor_venda-(v.valor_custo_contabil+(round((valor_venda*c.icms)/100,2))+(round(((v.valor_venda-v.valor_custo_contabil)*c.pis_cofins)/100,2))) end valor_lucro 
								         from qlik.j_tab_vendedor_veiculo v 
								         left join qlik.j_v_repasse_icms_pis_cofins c on v.empresa = c.empresa 
								         where v.empresa||'.'||v.revenda in ('{$empresa}') 
								         and v.tipo_item = 'R'
								         and v.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
							      	) a1 group by a1.empresa, a1.revenda, a1.vendedor, a1.nome_vendedor, a1.tipo_item,
							      	to_number(to_char(a1.DTA_ENTRADA_SAIDA,'mm')),  to_number(to_char(a1.DTA_ENTRADA_SAIDA,'yyyy'))  
								) s1
							   	left join
							   	(
							   		select cv0.empresa, cv0.revenda, cv0.usuario_fat, cv0.tipo_item, sum(cv0.val_cancelamento) val_cancelamento,
							        sum(cv0.valor_lucro_cancelado) valor_lucro_cancelado 
							        from
							        ( 
								        select cv.empresa, cv.revenda, cv.usuario_fat, cv.tipo_item, cv.tipo_transacao, cv.tot_nota_fiscal val_cancelamento, 
								        cv.valor_financiado valor_financiado_cancelado, cv.val_retorno_financ val_retorno_financ, cv.VALOR_CUSTO_CONTABIL, nvl(c.icms,0), nvl(c.pis_cofins,0),
								        case when cv.tot_nota_fiscal-(cv.valor_custo_contabil+(round((cv.TOT_NOTA_FISCAL*nvl(c.icms,0))/100,2))+(round(((cv.TOT_NOTA_FISCAL-cv.valor_custo_contabil)*nvl(c.pis_cofins,0))/100,2))) < 0 then 0
								        else cv.TOT_NOTA_FISCAL-(cv.valor_custo_contabil+(round((cv.TOT_NOTA_FISCAL*nvl(c.icms,0))/100,2))+(round(((cv.TOT_NOTA_FISCAL-cv.valor_custo_contabil)*nvl(c.pis_cofins,0))/100,2))) end valor_lucro_cancelado    
								        from qlik.j_v_cancelamento_nota_veiculo cv
								        left join qlik.j_v_repasse_icms_pis_cofins c on cv.empresa = c.empresa 
								        where cv.dta_cancelamento_nota between to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
							        ) cv0 group by cv0.empresa, cv0.revenda, cv0.usuario_fat, cv0.tipo_item
							   	) s2 on (s1.empresa = s2.empresa and s1.revenda = s2.revenda and s1.usuario = s2.usuario_fat and s1.tipo_item = s2.tipo_item)
							   	left join cnp.ger_usuario u on s1.usuario = u.usuario
							)b{$i} where b{$i}.usuario in('{$vendedor}') union ";
				}
			}elseif ($tip == 11){
				if ($por == "FAI"){
				
				}elseif ($por == "TIP"){
					$case = "case  ";
					$casem = "case  ";
					if (in_array("N", $considerar)){
						$case .= "when x1.tipo_item = 'N' then ".str_replace(",", ".", $campo_formula['COMISSAO_NOVOS'])."";
						$casem .= "when x1.tipo_item = 'N' then {$campo_formula['META_NOVOS']}";
					}
					if (in_array("U", $considerar)){
						$case .= "when x1.tipo_item = 'U' then ".str_replace(",", ".", $campo_formula['COMISSAO_USADOS'])."";
						$casem .= "when x1.tipo_item = 'U' then {$campo_formula['META_USADOS']}";
					}
					if (in_array("D", $considerar)){
						$case .= "when x1.tipo_item = 'D' then ".str_replace(",", ".", $campo_formula['COMISSAO_DIRETO'])." ";
						$casem .= "when x1.tipo_item = 'D' then {$campo_formula['META_DIRETO']}";
					}
					if (in_array("C", $considerar)){
						$case .= "when x1.tipo_item = 'C' then ".str_replace(",", ".", $campo_formula['COMISSAO_CONSORCIO'])." ";
						$casem .= "when x1.tipo_item = 'C' then {$campo_formula['META_CONSORCIO']}";
					}
					if (in_array("P", $considerar)){
						$case .= "when x1.tipo_item = 'P' then ".str_replace(",", ".", $campo_formula['COMISSAO_PECAS'])." ";
						$casem .= "when x1.tipo_item = 'P' then {$campo_formula['META_PECAS']}";
					}
					if (in_array("S", $considerar)){
						$case .= "when x1.tipo_item = 'S' then ".str_replace(",", ".", $campo_formula['COMISSAO_MAODEOBRA'])." ";
						$casem .= "when x1.tipo_item = 'S' then {$campo_formula['META_MAODEOBRA']}";
					}
					$case .= " else  0 end pct_comissao";
					$casem .= "else  0 end metadados";
					$metapremio = (isset($campo_formula['META_PREMIO'])) ? ($campo_formula['META_PREMIO'] != "") ? $campo_formula['META_PREMIO'] : 0 : 0;
					return "select {$grupo} grupo, b{$i}.empresa, b{$i}.usuario, b{$i}.nome, b{$i}.tipo_item, b{$i}.mes_referencia,
					b{$i}.ano_referencia, b{$i}.valor_faturado, b{$i}.val_desconto, b{$i}.valor_total, to_char(b{$i}.pct_comissao) pct_comissao,
					b{$i}.metadados, to_char(round((b{$i}.valor_total*b{$i}.pct_comissao)/100,2)) valor_comissao, to_char(0) premio, {$metapremio} metapremio, b{$i}.cpf
					from
					(
						select x1.empresa, x1.revenda, x2.nome, x2.cpf, x1.tipo_item, x1.mes_referencia, x1.ano_referencia, 
					    x1.valor_total_financiado valor_faturado,
					    x1.valor_financiado_cancelado val_desconto,
					    x1.valor_total_financiado valor_total,
					    {$case}, {$casem}
						from
						(
							select s1.empresa, s1.revenda, s1.tipo_item, s1.mes_referencia, s1.ano_referencia, 
				          	s1.valor_financiado, nvl(s2.valor_financiado_cancelado,0) valor_financiado_cancelado, 
				          	s1.valor_financiado-nvl(s2.valor_financiado_cancelado,0) valor_total_financiado  
				          	from
				          	(
				              select c1.empresa, c1.revenda, c1.tipo_item, to_number(to_char(c1.DTA_ENTRADA_SAIDA,'mm')) mes_referencia, to_number(to_char(c1.DTA_ENTRADA_SAIDA,'yyyy')) ano_referencia,
				              sum(nvl(c1.valor_financiado,2)) valor_financiado
				              from qlik.v_j_cordenador_FI_Fiat  c1
				              where c1.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
				              and c1.empresa||'.'||c1.revenda in ('{$empresa}')
				              group by c1.empresa, c1.revenda, c1.tipo_item,
				              to_number(to_char(c1.DTA_ENTRADA_SAIDA,'mm')), to_number(to_char(c1.DTA_ENTRADA_SAIDA,'yyyy'))
				          	) s1
				          	left join
				          	(
				              select cv.empresa, cv.revenda, cv.TIPO_ITEM, sum(nvl(cv.valor_financiado,0)) valor_financiado_cancelado
				              from qlik.j_v_cancelamento_nota_veiculo cv
				              where cv.dta_cancelamento_nota between to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
				              group by cv.empresa, cv.revenda, cv.tipo_transacao,  cv.TIPO_ITEM
				          	) s2 on (s1.empresa = s2.empresa and s1.revenda = s2.revenda and s1.tipo_item = s2.tipo_item)
						) x1 cross join (select b1.usuario, b1.nome, b1.cpf from ger_usuario b1 where b1.usuario in ({$vendedor})) x2 group by x1.empresa, x2.usuario, x2.nome, x2.cpf,x1.tipo,x1.mes_referencia, x1.ano_referencia
					) b{$i} union ";
				}
			}
		}else{
			if ($tip == 5 || $tip == 7){
				if ($por == "FAI"){
					$case = "case ";
					$casep = "case ";
					$premio1 = (isset($campo_formula['PREMIO1'])) ? ($campo_formula['PREMIO1'] > 0) ? $campo_formula['PREMIO1'] : 0 : 0;
					$premio2 = (isset($campo_formula['PREMIO2'])) ? ($campo_formula['PREMIO2'] > 0) ? $campo_formula['PREMIO2'] : 0 : 0;
					$premio3 = (isset($campo_formula['PREMIO3'])) ? ($campo_formula['PREMIO3'] > 0) ? $campo_formula['PREMIO3'] : 0 : 0;
					$premio4 = (isset($campo_formula['PREMIO4'])) ? ($campo_formula['PREMIO4'] > 0) ? $campo_formula['PREMIO4'] : 0 : 0;
					if ($auto == "S"){
						if ($tip == 5){
							$per1 = ($parametros->MEC_PROD1 > 0) ? ($parametros->MEC_PROD1/100) : 0;
							$per2 = ($parametros->MEC_PROD2 > 0) ? ($parametros->MEC_PROD2/100) : 0;
							$per3 = ($parametros->MEC_PROD3 > 0) ? ($parametros->MEC_PROD3/100) : 0;
							$per4 = ($parametros->MEC_PROD4 > 0) ? ($parametros->MEC_PROD4/100) : 0;
						}else{
							$per1 = ($parametros->ELE_PROD1 > 0) ? ($parametros->ELE_PROD1/100) : 0;
							$per2 = ($parametros->ELE_PROD2 > 0) ? ($parametros->ELE_PROD2/100) : 0;
							$per3 = ($parametros->ELE_PROD3 > 0) ? ($parametros->ELE_PROD3/100) : 0;
							$per4 = ($parametros->ELE_PROD4 > 0) ? ($parametros->ELE_PROD4/100) : 0;
						}
						$fai_de1 = 0;
						$fai_ate1 = $produtividade * $per1;
						$fai_de2 = ($produtividade * $per1) + 0.01;
						$fai_ate2 = $produtividade * $per2;
						$fai_de3 = ($produtividade * $per2) + 0.01;
						$fai_ate3 = $produtividade * $per3;
						$fai_de4 = ($produtividade * $per3) + 0.01;
						$fai_ate4 = $produtividade;
						
						if (isset($campo_formula['FAI_COMISSAO1'])){
							$case .= "when x1.valor_calc between {$fai_de1} and {$fai_ate1} then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO1'])." ";
							$com = $campo_formula['FAI_COMISSAO1'];
							$casep .= "when x1.valor_calc between {$fai_de1} and {$fai_ate1} then 0 ";
						}
						if (isset($campo_formula['FAI_COMISSAO2'])){
							$case .= "when x1.valor_calc between {$fai_de2} and {$fai_ate2} then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO2'])." ";
							$com = $campo_formula['FAI_COMISSAO2'];
							$casep .= "when x1.valor_calc between {$fai_de2} and {$fai_ate2} then ".str_replace(",", ".", $premio1)." ";
							$pre = $premio1;
						}
						if (isset($campo_formula['FAI_COMISSAO3'])){
							$case .= "when x1.valor_calc between {$fai_de3} and {$fai_ate3} then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO3'])." ";
							$com = $campo_formula['FAI_COMISSAO3'];
							$casep .= "when x1.valor_calc between {$fai_de3} and {$fai_ate3} then ".str_replace(",", ".", $premio2)." ";
							$pre = $premio2;
						}
						if (isset($campo_formula['FAI_COMISSAO4'])){
							$case .= "when x1.valor_calc between {$fai_de4} and {$fai_ate4} then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO4'])." ";
							$com = $campo_formula['FAI_COMISSAO4'];
							$casep .= "when x1.valor_calc between {$fai_de4} and {$fai_ate4} then ".str_replace(",", ".", $premio3)." ";
							$pre = $premio3;
						}
						$case .= "when x1.valor_calc > 0 then ".str_replace(",", ".", $com)." ";
						$casep .= "when x1.valor_calc > 0 then ".str_replace(",", ".", $pre)." ";
					}else{
						$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE1'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE1'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO1'])."";
						$com = $campo_formula['FAI_COMISSAO1'];
						$casep .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE1'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE1'])." then 0";
						if (isset($campo_formula["FAI_DE2"])){
							$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE2'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE2'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO2'])."";
							$com = $campo_formula['FAI_COMISSAO2'];
							$casep .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE2'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE2'])." then ".str_replace(",", ".", $premio1)."";
							$pre = $premio1;
						}
						if (isset($campo_formula["FAI_DE3"])){
							$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE3'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE3'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO3'])."";
							$com = $campo_formula['FAI_COMISSAO3'];
							$casep .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE3'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE3'])." then ".str_replace(",", ".", $premio2)."";
							$pre = $premio2;
						}
						if (isset($campo_formula["FAI_DE4"])){
							$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE4'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE4'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO4'])."";
							$com = $campo_formula['FAI_COMISSAO4'];
							$casep .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE4'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE4'])." then ".str_replace(",", ".", $premio3)."";
							$pre = $premio3;
						}
						if (isset($campo_formula["FAI_DE5"])){
							$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE5'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE5'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO5'])."";
							$com = $campo_formula['FAI_COMISSAO5'];
							$casep .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE5'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE5'])." then ".str_replace(",", ".", $premio4)."";
							$pre = $premio4;
						}
						$case .= "when x1.valor_calc > 0 then ".str_replace(",", ".", $com)." ";
						$casep .= "when x1.valor_calc > 0 then ".str_replace(",", ".", $pre)." "; 
					}
					$casem = "case  ";
					if (in_array("N", $considerar)){
						$casem .= "when x1.tipo_item = 'N' then {$campo_formula['META_NOVOS']} ";
					}
					if (in_array("U", $considerar)){
						$casem .= "when x1.tipo_item = 'U' then {$campo_formula['META_USADOS']} ";
					}
					if (in_array("D", $considerar)){
						$casem .= "when x1.tipo_item = 'D' then {$campo_formula['META_DIRETO']} ";
					}
					if (in_array("C", $considerar)){
						$casem .= "when x1.tipo_item = 'C' then {$campo_formula['META_CONSORCIO']} ";
					}
					if (in_array("P", $considerar)){
						$casem .= "when x1.tipo_item = 'P' then {$campo_formula['META_PECAS']} ";
					}
					if (in_array("S", $considerar)){
						$casem .= "when x1.tipo_item = 'S' then {$campo_formula['META_MAODEOBRA']} ";
					}
					$case .= "else  0 end pct_comissao";
					$casep .= "else  0 end premio";
					$casem .= "else  0 end metadados";
					$metapremio = (isset($campo_formula['META_PREMIO'])) ? ($campo_formula['META_PREMIO'] != "") ? $campo_formula['META_PREMIO'] : 0 : 0;
					return "select {$grupo} grupo, b{$i}.empresa, b{$i}.usuario, gu.nome, b{$i}.tipo_item, b{$i}.mes_referencia,
							b{$i}.ano_referencia, b{$i}.valor_faturado, b{$i}.val_desconto, b{$i}.valor_total, to_char(b{$i}.pct_comissao) pct_comissao,
							b{$i}.metadados, to_char(round((b{$i}.valor_total*b{$i}.pct_comissao)/100,2)) valor_comissao, to_char(b{$i}.premio) premio,
							{$metapremio} metapremio, gu.cpf
							from
							(
								select x1.empresa, x1.usuario, x1.tipo_item, x1.mes_referencia, x1.ano_referencia,
								to_char(sum(x1.valor_faturado)) valor_faturado, to_char(sum(x1.val_desconto)) val_desconto, to_char(sum(x1.valor_faturado)-sum(x1.val_desconto)) valor_total,
								{$case}, {$casep}, {$casem}
								from
								(
									select a1.empresa, a1.revenda, a1.nome, a1.usuario, a1.tipo_item, a1.mes_referencia, a1.ano_referencia,
									a1.valor_faturado, nvl(a2.val_desconto,0) val_desconto, a1.valor_faturado-nvl(a2.val_desconto,0) valor_total,
									(
										select valor_calc
										from (
										select a1.usuario, a1.valor_faturado-nvl(a2.val_desconto,0) valor_calc
										from
										(
											select s1.* from(select m.usuario, sum(m.valor) valor_faturado
											from qlik.j_v_fat_mecanico m
											where m.dta_referencia between
											to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
											and m.empresa||'.'||m.revenda in ('{$empresa}')
											and m.tipo_item in ('{$tipo}')
											and m.usuario in ({$vendedor})
											group by m.usuario) s1
										) a1
										left join
										(
											select c.usuario_fat, sum(c.val_desconto) val_desconto
											from qlik.j_v_cancelamento_nota c
											where c.dta_cancelamento_nota between
											to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
											and c.empresa||'.'||c.revenda in ('{$empresa}')
											and c.tipo in ('{$tipo}') group by c.usuario_fat
										) a2
										on a1.usuario = a2.usuario_fat
										) calc where calc.usuario = a1.usuario
									) valor_calc
									from
									(
										select s1.*
										from
										(
											select m.empresa, m.revenda, m.usuario, m.nome_mecanico nome, m.mecanico, m.tipo_item,
											m.mes_referencia, m.ano_referencia, sum(m.valor) valor_faturado
											from qlik.j_v_fat_mecanico m
											where m.dta_referencia between
											to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
											and m.empresa||'.'||m.revenda in ('{$empresa}')
											and m.tipo_item in ('{$tipo}')
											and m.usuario in ({$vendedor})
											group by m.empresa, m.revenda, m.usuario, m.nome_mecanico, m.mecanico,
											m.tipo_item, m.mes_referencia, m.ano_referencia
										) s1
									) a1
									left join
									(
										select c.empresa, c.revenda, c.usuario_fat, c.mecanico, c.numero_nota_fiscal, c.serie_nota_fiscal, c.mes_emissao, c.ano_emissao,
										c.mes_cancelamento, c.ano_cancelamento, c.tipo, c.val_desconto
										from qlik.j_v_cancelamento_nota c
										where c.dta_cancelamento_nota between
										to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
										and c.empresa||'.'||c.revenda in ('{$empresa}')
										and c.tipo in ('{$tipo}')
									) a2
									on ( a1.empresa = a2.empresa and a1.revenda = a2.revenda
									and a1.mes_referencia = a2.mes_cancelamento and a1.ano_referencia = a2.ano_cancelamento
									and a1.tipo_item = a2.tipo and a1.mecanico = a2.mecanico )
								) x1 group by x1.empresa, x1.usuario, x1.tipo_item, x1.mes_referencia, x1.ano_referencia, x1.valor_calc
							) b{$i} join ger_usuario gu on b{$i}.usuario = gu.usuario union ";
				}elseif ($por == "TIP"){
					$case = "case  ";
					$casem = "case  ";
					if (in_array("N", $considerar)){
						$case .= "when x1.tipo_item = 'N' then ".str_replace(",", ".", $campo_formula['COMISSAO_NOVOS'])." ";
						$casem .= "when x1.tipo_item = 'N' then {$campo_formula['META_NOVOS']}";
					}
					if (in_array("U", $considerar)){
						$case .= "when x1.tipo_item = 'U' then ".str_replace(",", ".", $campo_formula['COMISSAO_USADOS'])." ";
						$casem .= "when x1.tipo_item = 'U' then {$campo_formula['META_USADOS']}";
					}
					if (in_array("D", $considerar)){
						$case .= "when x1.tipo_item = 'D' then ".str_replace(",", ".", $campo_formula['COMISSAO_DIRETO'])." ";
						$casem .= "when x1.tipo_item = 'D' then {$campo_formula['META_DIRETO']}";
					}
					if (in_array("C", $considerar)){
						$case .= "when x1.tipo_item = 'C' then ".str_replace(",", ".", $campo_formula['COMISSAO_CONSORCIO'])." ";
						$casem .= "when x1.tipo_item = 'C' then {$campo_formula['META_CONSORCIO']}";
					}
					if (in_array("P", $considerar)){
						$case .= "when x1.tipo_item = 'P' then ".str_replace(",", ".", $campo_formula['COMISSAO_PECAS'])." ";
						$casem .= "when x1.tipo_item = 'P' then {$campo_formula['META_PECAS']}";
					}
					if (in_array("S", $considerar)){
						$case .= "when x1.tipo_item = 'S' then ".str_replace(",", ".", $campo_formula['COMISSAO_MAODEOBRA'])." ";
						$casem .= "when x1.tipo_item = 'S' then {$campo_formula['META_MAODEOBRA']}";
					}
					$case .= "else  0 end pct_comissao";
					$casem .= "else  0 end metadados ";
					$metapremio = (isset($campo_formula['META_PREMIO'])) ? ($campo_formula['META_PREMIO'] != "") ? $campo_formula['META_PREMIO'] : 0 : 0;
					
					return "select {$grupo} grupo, b{$i}.empresa, b{$i}.usuario, gu.nome, b{$i}.tipo_item, b{$i}.mes_referencia,
							b{$i}.ano_referencia, b{$i}.valor_faturado, b{$i}.val_desconto, b{$i}.valor_total, to_char(b{$i}.pct_comissao) pct_comissao,
							b{$i}.metadados, to_char(round((b{$i}.valor_total*b{$i}.pct_comissao)/100,2)) valor_comissao, to_char(0) premio,
							{$metapremio} metapremio, gu.cpf
							from
							(
								select x1.empresa, x1.usuario, x1.tipo_item, x1.mes_referencia, x1.ano_referencia,
								to_char(sum(x1.valor_faturado)) valor_faturado, to_char(sum(x1.val_desconto)) val_desconto, to_char(sum(x1.valor_faturado)-sum(x1.val_desconto)) valor_total,
								{$case}, {$casem}
								from
								(
									select a1.empresa, a1.revenda, a1.nome, a1.usuario, a1.tipo_item, a1.mes_referencia, a1.ano_referencia,
									a1.valor_faturado, nvl(a2.val_desconto,0) val_desconto, a1.valor_faturado-nvl(a2.val_desconto,0) valor_total
									from
									(
										select s1.*
										from
										(
											select m.empresa, m.revenda, m.usuario, m.nome_mecanico nome, m.mecanico, m.tipo_item, m.mes_referencia, m.ano_referencia,
											sum(m.valor) valor_faturado
											from qlik.j_v_fat_mecanico m
											where m.dta_referencia between
											to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
											and m.empresa||'.'||m.revenda in ('{$empresa}')
											and m.tipo_item in ('{$tipo}')
											and m.usuario in ({$vendedor})
											group by m.empresa, m.revenda, m.usuario, m.nome_mecanico, m.mecanico,
											m.tipo_item, m.mes_referencia, m.ano_referencia
										) s1
									) a1
									left join
									(
										select c.empresa, c.revenda, c.usuario_fat, c.mecanico, c.numero_nota_fiscal, c.serie_nota_fiscal, c.mes_emissao, c.ano_emissao,
										c.mes_cancelamento, c.ano_cancelamento, c.tipo, c.val_desconto
										from qlik.j_v_cancelamento_nota c
										where c.dta_cancelamento_nota between
										to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
										and c.empresa||'.'||c.revenda in ('{$empresa}')
										and c.tipo in ('{$tipo}')
									) a2
									on ( a1.empresa = a2.empresa and a1.revenda = a2.revenda
									and a1.mes_referencia = a2.mes_cancelamento and a1.ano_referencia = a2.ano_cancelamento
									and a1.tipo_item = a2.tipo and a1.mecanico = a2.mecanico )
								) x1 group by x1.empresa, x1.usuario, x1.tipo_item, x1.mes_referencia, x1.ano_referencia
							) b{$i} join ger_usuario gu on b{$i}.usuario = gu.usuario union ";
				}
			}elseif ($tip == 1 || $tip == 4){
				if (($tip == 1) && (in_array("N", $considerar) || in_array("U", $considerar) || in_array("D", $considerar))){
					if ($por == "FAI"){
						
					}elseif ($por == "TIP"){
						$casem = "case  ";
						if (in_array("N", $considerar)){
							$casem .= "when g1.tipo_item = 'N' then {$campo_formula['META_NOVOS']}";
						}
						if (in_array("U", $considerar)){
							$casem .= "when g1.tipo_item = 'U' then {$campo_formula['META_USADOS']}";
						}
						if (in_array("D", $considerar)){
							$casem .= "when g1.tipo_item = 'D' then {$campo_formula['META_DIRETO']}";
						}
						if (in_array("C", $considerar)){
							$casem .= "when g1.tipo_item = 'C' then {$campo_formula['META_CONSORCIO']}";
						}
						if (in_array("P", $considerar)){
							$casem .= "when g1.tipo_item = 'P' then {$campo_formula['META_PECAS']}";
						}
						if (in_array("S", $considerar)){
							$casem .= "when g1.tipo_item = 'S' then {$campo_formula['META_MAODEOBRA']}";
						}
						$casem .= " else  0 end metadados ";
						$exp = explode('/',$de);
						$metapremio = (isset($campo_formula['META_PREMIO'])) ? ($campo_formula['META_PREMIO'] != "") ? $campo_formula['META_PREMIO'] : 0 : 0;
						return "select {$grupo} grupo, b{$i}.*
								from
								(
								   select g1.empresa, g1.vendedor usuario, g1.nome_vendedor nome, g1.tipo_item, g1.mes_referencia, g1.ano_referencia,
								   g1.valor_venda||';'||g1.valor_retorno||';'||g1.valor_total_acessorio valor_faturado, 
								   g1.val_cancelamento||';'||g1.valor_retorno_cancelado val_desconto,
								   g1.valor_total||';'||g1.valor_total_retorno||';'||g1.valor_total_acessorio valor_total,
								   g1.pct_comissao_venda||';'||g1.pct_comissao_retorno||';'||g1.pct_comissao_acessorio pct_comissao, {$campo_formula['META_NOVOS']} metadados,
								   g1.valor_comissao_venda||';'||g1.valor_comissao_retorno||';'||g1.valor_comissao_acessorio||';'||g1.valor_comissao_emplacamento valor_comissao,

									(SELECT to_char(SUM(X2.PREMIACAO)) PREMIACAO
									FROM
									(
									   SELECT X1.EMPRESA, X1.REVENDA, X1.VENDEDOR, X1.TIPO_ITEM, X1.BONUS_QUANTIDADE+X1.BONUS_MARGEM+X1.BONUS_MODELO PREMIACAO
									   FROM
									   (
									       select p1.empresa, p1.revenda, p1.vendedor, p1.tipo_item, sum(p1.valor_venda) valor_venda, sum(p1.quantidade) quantidade,
									       case when sum(p1.quantidade) >= 12 and p1.tipo_item = 'N' then 50*sum(p1.quantidade) else 0 end bonus_quantidade, 
									       sum(p1.bonus_margem) bonus_margem, sum(p1.bonus_modelo) bonus_modelo     
									       from
									       (
									         ---------------------------------------->
									           select h1.*,
									           case when h1.tipo_item = 'N' and h1.tipo = 'S' and h1.margem_operacional >= 5.5 then 50
									                when h1.tipo_item = 'N' and h1.tipo = 'E' and h1.margem_operacional >= 5.5 then 50*-1
									                when h1.tipo_item = 'U' and h1.tipo = 'S' and h1.margem_operacional >= 16 then 300
									                when h1.tipo_item = 'U' and h1.tipo = 'E' and h1.margem_operacional >= 16 then 300*-1 else 0 end bonus_margem,
									            case when h1.tipo_item = 'N' and h1.tipo = 'S' and replace(lower(h1.des_modelo),' ','') like '%mobilike%' then 200 
									                 when h1.tipo_item = 'N' and h1.tipo = 'E' and replace(lower(h1.des_modelo),' ','') like '%mobilike%' then 200*-1 
									            when h1.tipo_item = 'N' and h1.tipo = 'S' and replace(lower(h1.des_modelo),' ','') like '%siena%' then 300 
									            when h1.tipo_item = 'N' and h1.tipo = 'E' and replace(lower(h1.des_modelo),' ','') like '%siena%' then 300*-1
									            when h1.tipo_item = 'N' and h1.tipo = 'S' and replace(lower(h1.des_modelo),' ','') like '%cronos%' then 500
									            when h1.tipo_item = 'N' and h1.tipo = 'E' and replace(lower(h1.des_modelo),' ','') like '%cronos%' then 500*-1
									            when h1.tipo_item = 'N' and h1.tipo = 'S' and (replace(lower(h1.des_modelo),' ','') like '%argo%1.0%' or replace(lower(h1.des_modelo),' ','') like '%argo%1.3%' ) and replace(lower(h1.des_modelo),' ','') not like '%argo trekking%' then 300
									            when h1.tipo_item = 'N' and h1.tipo = 'E' and (replace(lower(h1.des_modelo),' ','') like '%argo%1.0%' or replace(lower(h1.des_modelo),' ','') like '%argo%1.3%' ) and replace(lower(h1.des_modelo),' ','') not like '%argo trekking%' then 300*-1              
									            when h1.tipo_item = 'N' and h1.tipo = 'S' and replace(lower(h1.des_modelo),' ','') like '%strada%' then 600
									            when h1.tipo_item = 'N' and h1.tipo = 'E' and replace(lower(h1.des_modelo),' ','') like '%strada%' then 600*-1
									            when h1.tipo_item = 'N' and h1.tipo = 'S' and replace(lower(h1.des_modelo),' ','') like '%strada%' and h1.margem_operacional >= 20 then 800
									            when h1.tipo_item = 'N' and h1.tipo = 'E' and replace(lower(h1.des_modelo),' ','') like '%strada%' and h1.margem_operacional >= 20 then 800*-1           
									            when (h1.tipo_item = ('N') and h1.tipo = 'S' and replace(lower(h1.des_modelo),' ','') like '%toro%') and h1.margem_operacional between 5.5 and 9.99 then 800
									            when (h1.tipo_item = ('N') and h1.tipo = 'E' and replace(lower(h1.des_modelo),' ','') like '%toro%') and h1.margem_operacional between 5.5 and 9.99 then 800*-1 
									            when (h1.tipo_item = ('N') and h1.tipo = 'S' and replace(lower(h1.des_modelo),' ','') like '%toro%') and h1.margem_operacional between 10 and 14.99 then 1000
									            when (h1.tipo_item = ('N') and h1.tipo = 'E' and replace(lower(h1.des_modelo),' ','') like '%toro%') and h1.margem_operacional between 10 and 14.99 then 1000*-1  
									            when (h1.tipo_item = ('N') and h1.tipo = 'S' and replace(lower(h1.des_modelo),' ','') like '%toro%') and h1.margem_operacional between 15 and 29.99 then 1500
									            when (h1.tipo_item = ('N') and h1.tipo = 'E' and replace(lower(h1.des_modelo),' ','') like '%toro%') and h1.margem_operacional between 15 and 29.99 then 1500*-1 
									            when (h1.tipo_item = ('N') and h1.tipo = 'S' and replace(lower(h1.des_modelo),' ','') like '%toro%') and h1.margem_operacional >= 30 then 2500
									            when (h1.tipo_item = ('N') and h1.tipo = 'E' and replace(lower(h1.des_modelo),' ','') like '%toro%') and h1.margem_operacional >= 30 then 2500*-1
									            when (h1.tipo_item = ('N') and h1.tipo = 'S' and replace(lower(h1.des_modelo),' ','') like '%ducato%' and replace(lower(h1.des_modelo),' ','') not like '%ducato%ambul%') and h1.margem_operacional >= 20 then 2500
									            when (h1.tipo_item = ('N') and h1.tipo = 'E' and replace(lower(h1.des_modelo),' ','') like '%ducato%' and replace(lower(h1.des_modelo),' ','') not like '%ducato%ambul%') and h1.margem_operacional >= 20 then 2500*-1
									            when (h1.tipo_item = ('N') and h1.tipo = 'S' and replace(lower(h1.des_modelo),' ','') like '%ducato%ambul%') and h1.margem_operacional >= 20 then 3500
									            when (h1.tipo_item = ('N') and h1.tipo = 'E' and replace(lower(h1.des_modelo),' ','') like '%ducato%ambul%') and h1.margem_operacional >= 20 then 3500*-1
									             else 0 end bonus_modelo 
									    from
									    (   
									       select v.*,
									       case when v.tipo_item = 'N' then round(abs(v.valor_venda) - (((abs(v.valor_custo_contabil) ) )+nvl(vr.val_retorno_r,0)),2)
									            when v.tipo_item = 'U' then round(abs(v.valor_venda) - (((abs(v.valor_custo_contabil) ) )+nvl(vr.val_retorno_r,0)),2) end valor_lucro,
									       case when v.tipo_item = 'N' then round(((round(abs(v.valor_venda) - (((abs(v.valor_custo_contabil) )  )+nvl(vr.val_retorno_r,2)),2))/abs(v.valor_venda))*100,2)
									            when v.tipo_item = 'U' then round(((round(abs(v.valor_venda) - (((abs(v.valor_custo_contabil) )  )+nvl(vr.val_retorno_r,2)),2))/abs(v.valor_venda))*100,2) end margem_operacional             
									       from qlik.j_tab_vendedor_veiculo v  
									       ---------------------------------------->
									       left join 
									             ( select empresa, revenda, proposta, sum(val_retorno)*-1 val_retorno_r
									               from cnp.vei_retorno 
									               group by empresa, revenda, proposta 
									             ) vr on v.empresa = vr.empresa and v.revenda = vr.revenda and v.proposta = vr.proposta
									             left join qlik.j_v_novos_icms_pis_cofins c on v.empresa = c.empresa and v.tipo_item = c.tipo_tem 
									             left join qlik.j_v_usados_icms_pis_cofins c2 on v.empresa = c2.empresa and v.tipo_item = c2.tipo_tem
									             where v.empresa||'.'||v.revenda in ('{$empresa}') 
									             and v.tipo_item in ('N','U')
									             and v.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
									          ) h1     
									             
									       ) p1 group by p1.empresa, p1.revenda, p1.vendedor, p1.tipo_item     
									   ) X1 
									       
									   ) X2 WHERE X2.VENDEDOR = g1.vendedor GROUP BY X2.VENDEDOR) premio
									, {$metapremio} metapremio, g1.cpf
								   from
								   (
										select x1.empresa, x1.revenda, x1.vendedor, x1.nome_vendedor, x1.tipo_item, x1.valor_venda, x1.valor_retorno, x1.val_cancelamento, x1.valor_retorno_cancelado, x1.valor_total, x1.valor_total_retorno, x1.valor_total_acessorio,
								        -------- Faturamento ---------
								        case when x1.quantidade between 1 and 9 then round((x1.valor_total*0.45)/100,2) 
								             when x1.quantidade between 10 and 14 then round((x1.valor_total*0.50)/100,2)  
								             when x1.quantidade between 15 and 17 then (x1.valor_total*0.55)/100  
								             when x1.quantidade >= 18 then round((x1.valor_total*0.60)/100,2)
								             when x1.quantidade >= 1 then round((x1.valor_total*0.45)/100,2) 
								             else 0 end valor_comissao_venda, 
								       
								        case when x1.quantidade between 1 and 9 then '0,45'
								             when x1.quantidade between 10 and 14 then '0,50' 
								             when x1.quantidade between 15 and 17 then '0,55' 
								             when x1.quantidade >= 18 then '0,60'
								             when x1.quantidade >= 1 then '0,45' 
								             else '0' end pct_comissao_venda, 
								   
								       ---------- Retorno Financiamento ----------     
								       case  
								             when x1.valor_total >= 800000 and 
								               (
								                select v.vendedor
								                from qlik.j_tab_vendedor_veiculo v 
								                 where v.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
								                and v.tipo_item = x1.tipo_item and v.tipo_transacao not in ('V07','V20','M20','M07','C07','C18','C51','U14','U15','U07') 
								                AND trunc(sysdate)-(v.dta_fat_fabrica+1) >= 90 and v.empresa = x1.empresa and v.revenda = x1.revenda and v.vendedor = x1.vendedor
								                group by v.empresa, v.revenda, v.vendedor, v.tipo_item
								                having count(0) >= 2 
								               ) = x1.vendedor then round((x1.valor_total_retorno*20)/100,2)
								             when x1.valor_total >= 1000000 and 
								               (
								                select v.vendedor
								                from qlik.j_tab_vendedor_veiculo v 
								                where v.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
								                and v.tipo_item = x1.tipo_item and v.tipo_transacao not in ('V07','V20','M20','M07','C07','C18','C51','U14','U15','U07') 
								                AND trunc(sysdate)-(v.dta_fat_fabrica+1) >= 120 and v.empresa = x1.empresa and v.revenda = x1.revenda and v.vendedor = x1.vendedor
								                group by v.empresa, v.revenda, v.vendedor, v.tipo_item
								                having count(0) >= 2
								               ) = x1.vendedor then round((x1.valor_total_retorno*30)/100,2)                                   
								             when x1.valor_total >= 1200000 then round((x1.valor_total_retorno*30)/100,2)
								             when x1.quantidade >= 1 then round((x1.valor_total_retorno*10)/100,2) else 0 end valor_comissao_retorno, 
								       
								        case 
								             when x1.valor_total >= 800000 and 
								               (
								                select v.vendedor
								                from qlik.j_tab_vendedor_veiculo v 
								                where v.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
								                and v.tipo_item = x1.tipo_item and v.tipo_transacao not in ('V07','V20','M20','M07','C07','C18','C51','U14','U15','U07') 
								                AND trunc(sysdate)-(v.dta_fat_fabrica+1) >= 90 and v.empresa = x1.empresa and v.revenda = x1.revenda and v.vendedor = x1.vendedor
								                group by v.empresa, v.revenda, v.vendedor, v.tipo_item
								                having count(0) >= 2 
								               ) = x1.vendedor then '20'
								             when x1.valor_total >= 1000000 and 
								               (
								                select v.vendedor
								                from qlik.j_tab_vendedor_veiculo v 
								                where v.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
								                and v.tipo_item = x1.tipo_item and v.tipo_transacao not in ('V07','V20','M20','M07','C07','C18','C51','U14','U15','U07') 
								                AND trunc(sysdate)-(v.dta_fat_fabrica+1) >= 120 and v.empresa = x1.empresa and v.revenda = x1.revenda and v.vendedor = x1.vendedor
								                group by v.empresa, v.revenda, v.vendedor, v.tipo_item
								                having count(0) >= 2
								               ) = x1.vendedor then '30'                                   
								             when x1.valor_total >= 1200000 then '30'
								             when x1.quantidade >= 1 then '10' else '0' end pct_comissao_retorno,
								       
								       --------- Acessrios------------------
								        case 
								             when x1.valor_total >= 800000 and 
								               (
								                select v.vendedor
								                from qlik.j_tab_vendedor_veiculo v 
								                where v.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
								                and v.tipo_item = x1.tipo_item and v.tipo_transacao not in ('V07','V20','M20','M07','C07','C18','C51','U14','U15','U07') 
								                AND trunc(sysdate)-(v.dta_fat_fabrica+1) >= 90 and v.empresa = x1.empresa and v.revenda = x1.revenda and v.vendedor = x1.vendedor
								                group by v.empresa, v.revenda, v.vendedor, v.tipo_item
								                having count(0) >= 2 
								               ) = x1.vendedor then round((x1.valor_total_acessorio*8)/100,2)
								             when x1.valor_total >= 1000000 and 
								               (
								                select v.vendedor
								                from qlik.j_tab_vendedor_veiculo v 
								                where v.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
								                and v.tipo_item = x1.tipo_item and v.tipo_transacao not in ('V07','V20','M20','M07','C07','C18','C51','U14','U15','U07') 
								                AND trunc(sysdate)-(v.dta_fat_fabrica+1) >= 120 and v.empresa = x1.empresa and v.revenda = x1.revenda and v.vendedor = x1.vendedor
								                group by v.empresa, v.revenda, v.vendedor, v.tipo_item
								                having count(0) >= 2
								               ) = x1.vendedor then round((x1.valor_total_acessorio*10)/100,2)                                   
								             when x1.valor_total >= 1200000 then round((x1.valor_total_acessorio*10)/100,2)
								             when x1.quantidade >= 1 then round((x1.valor_total_acessorio*6)/100,2) else 0 end valor_comissao_acessorio, 
								               
								        case 
								             when x1.valor_total >= 800000 and 
								               (
								                select v.vendedor
								                from qlik.j_tab_vendedor_veiculo v 
								                where v.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
								                and v.tipo_item = x1.tipo_item and v.tipo_transacao not in ('V07','V20','M20','M07','C07','C18','C51','U14','U15','U07') 
								                AND trunc(sysdate)-(v.dta_fat_fabrica+1) >= 90 and v.empresa = x1.empresa and v.revenda = x1.revenda and v.vendedor = x1.vendedor
								                group by v.empresa, v.revenda, v.vendedor, v.tipo_item
								                having count(0) >= 2 
								               ) = x1.vendedor then '8'
								             when x1.valor_total >= 1000000 and 
								               (
								                select v.vendedor
								                from qlik.j_tab_vendedor_veiculo v 
								                where v.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
								                and v.tipo_item = x1.tipo_item and v.tipo_transacao not in ('V07','V20','M20','M07','C07','C18','C51','U14','U15','U07') 
								                AND trunc(sysdate)-(v.dta_fat_fabrica+1) >= 120 and v.empresa = x1.empresa and v.revenda = x1.revenda and v.vendedor = x1.vendedor
								                group by v.empresa, v.revenda, v.vendedor, v.tipo_item
								                having count(0) >= 2
								               ) = x1.vendedor then '10'                                 
								             when x1.valor_total >= 1200000 then '10'
								             when x1.quantidade >= 1 then '6' else '0' end pct_comissao_acessorio,   
								             
								             ----------- Emplacamento -----------
								             x1.n_emplacamento*35 valor_comissao_emplacamento,  
								             x1.mes_referencia, x1.ano_referencia, u.cpf 
								        from
								        (
								             select s1.*, nvl(s2.val_cancelamento,0) val_cancelamento, s1.valor_venda-nvl(s2.val_cancelamento,0) valor_total,
								             nvl(s2.valor_financiado_cancelado,0) valor_financiado_cancelado, s1.valor_financiado-nvl(s2.valor_financiado_cancelado,0) valor_total_financiado, 
								             nvl(s2.val_retorno_financ,0) valor_retorno_cancelado, s1.valor_retorno-nvl(s2.val_retorno_financ,0) valor_total_retorno, nvl(ann.valor_acessorio,0) valor_total_acessorio 
								             from
								             (
								               select v.empresa, v.revenda, v.vendedor, v.nome_vendedor, v.tipo_item, sum(v.valor_venda)-nvl(sum(dv.valor_dv),0) valor_venda, 
								               nvl(sum(f9.valor_financiado),0) valor_financiado, nvl(sum(f9.valor_retorno),0) valor_retorno, sum(v.quantidade) quantidade,
								               to_number(to_char(v.DTA_ENTRADA_SAIDA,'mm')) mes_referencia, to_number(to_char(v.DTA_ENTRADA_SAIDA,'yyyy')) ano_referencia, nvl(sum(n.acessorio),0) n_emplacamento
								               from qlik.j_tab_vendedor_veiculo v
								               left join
								                         (
								                           select empresa, revenda, proposta, fat_oper, sum(valor_dv) valor_dv
								                           from qlik.j_v_fiat_dv group by empresa, revenda, proposta, fat_oper 
								                         ) dv on v.empresa = dv.empresa and v.revenda = dv.revenda and v.fat_oper = dv.fat_oper and nvl(v.proposta,0) = dv.proposta
								               left join ( select an.empresa, an.revenda, an.vendedor, an.veiculo, an.fat_oper, an.valor_venda, an.proposta, an.dta_entrada_saida,
								                           nvl(an.acessorio,(select sum(acessorio)*-1 from qlik.j_v_emplacamentp_novos where valor_venda >=0 and empresa = an.empresa and revenda = an.revenda and fat_oper = an.fat_oper)) acessorio 
								                           from qlik.j_v_emplacamentp_novos an
								                         ) n on v.empresa = n.empresa and v.revenda = n.revenda and v.veiculo = n.veiculo and v.vendedor = n.vendedor and v.fat_oper = n.fat_oper 
								               left join 
								                         (
								                            select f10.EMPRESA, f10.REVENDA, f10.VENDEDOR, f10.VEICULO, f10.PROPOSTA, f10.FAT_OPER, f10.DTA_ENTRADA_SAIDA, f10.VALOR_FINANCIADO,
								                            f10.taxa_retorno, f10.val_retorno_financ, f10.ila,
								                            f10.val_retorno_financ+((f10.val_retorno_financ*f10.ila)/100) valor_retorno
								                            from
								                            (  
								                              select f1.EMPRESA, f1.REVENDA, f1.VENDEDOR, f1.VEICULO, f1.PROPOSTA, f1.FAT_OPER, f1.DTA_ENTRADA_SAIDA, f1.VALOR_FINANCIADO,  
								                              nvl(f1.taxa_retorno,(select taxa_retorno from qlik.j_v_financiamento_novos where valor_financiado >=0 and empresa = f1.empresa and revenda = f1.revenda and fat_oper = f1.fat_oper)) taxa_retorno,
								                              nvl(f1.val_retorno_financ,(select val_retorno_financ*-1 from qlik.j_v_financiamento_novos where valor_financiado >=0 and empresa = f1.empresa and revenda = f1.revenda and fat_oper = f1.fat_oper)) val_retorno_financ,
								                              nvl(cp.ila,0) ila
								                              from qlik.j_v_financiamento_novos f1 
								                              left join (select empresa, revenda, mes, ano, ila 
								                                             from sismonaco.com_parametros where mes = '{$exp[1]}' and ano = '{$exp[2]}'
								                                        ) cp on (f1.empresa = cp.empresa and f1.revenda = cp.revenda)
								                              where f1.empresa = {$emp}
								                            ) f10   
								                         ) f9 on v.empresa = f9.empresa and v.revenda = f9.revenda and v.fat_oper = f9.fat_oper 
								               where v.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
								               and v.tipo_item = 'N' 
								               and v.empresa||'.'||v.revenda in ('{$empresa}')
								               group by v.empresa, v.revenda, v.vendedor, v.nome_vendedor, v.tipo_item,
								               to_number(to_char(v.DTA_ENTRADA_SAIDA,'mm')), to_number(to_char(v.DTA_ENTRADA_SAIDA,'yyyy'))
								             ) s1
								             left join 
								             (
								                 select a1.empresa, a1.revenda, a1.nome, a1.usuario, 'N' tipo_item, a1.mes_referencia, a1.ano_referencia,
								                   a1.valor_faturado, nvl(a2.val_desconto,0) val_desconto, a1.valor_faturado-nvl(a2.val_desconto,0) valor_acessorio
								                   from
								                   (
								                          select s1.*
								                          from
								                          ( 
								                                 select m.empresa, m.revenda, m.usuario, m.nome_vendedor nome, 
								                                 to_number(to_char(m.dta_referencia,'mm')) mes_referencia, to_number(to_char(m.dta_referencia,'yyyy')) ano_referencia,
								                                 sum(m.valor_venda) valor_faturado
								                                 from qlik.j_tab_fat_vendedor m
								                                 where m.dta_referencia between
																 to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
																 and m.empresa||'.'||m.revenda in ('{$empresa}')
								                                 group by m.empresa, m.revenda, m.usuario, m.nome_vendedor,
								                                 to_number(to_char(m.dta_referencia,'mm')), to_number(to_char(m.dta_referencia,'yyyy'))
								                          ) s1
								                   ) a1
								                   left join
								                   (
								                          select c.empresa, c.revenda, c.usuario_fat, c.mes_cancelamento, c.ano_cancelamento, sum(c.val_desconto) val_desconto
								                          from qlik.j_v_cancelamento_nota c
								                          where c.dta_cancelamento_nota between
								                          to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
														  and c.empresa||'.'||c.revenda in ('{$empresa}')
								                          group by c.empresa, c.revenda, c.usuario_fat, c.mes_cancelamento, c.ano_cancelamento
								                   ) a2
								                   on ( a1.empresa = a2.empresa and a1.revenda = a2.revenda
								                   and a1.mes_referencia = a2.mes_cancelamento and a1.ano_referencia = a2.ano_cancelamento
								                   and a1.usuario = a2.usuario_fat )
								             ) ann on (s1.empresa = ann.empresa and s1.revenda = ann.revenda and s1.vendedor = ann.usuario and s1.tipo_item = ann.tipo_item) 
								             left join
								             (
								              select cv.empresa, cv.revenda, cv.usuario_fat, cv.tipo_item, sum(cv.tot_nota_fiscal) val_cancelamento, 
								              sum(cv.valor_financiado) valor_financiado_cancelado, sum(cv.val_retorno_financ) val_retorno_financ
								              from qlik.j_v_cancelamento_nota_veiculo cv
								              where cv.dta_cancelamento_nota between to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
								              group by cv.empresa, cv.revenda, cv.usuario_fat, cv.tipo_item
								             ) s2 on (s1.empresa = s2.empresa and s1.revenda = s2.revenda and s1.vendedor = s2.usuario_fat and s1.tipo_item = s2.tipo_item)
								       ) x1 left join cnp.ger_usuario u on x1.vendedor = u.usuario
								   ) g1
								   
								   union all
								   
								     select g1.empresa, g1.vendedor usuario, g1.nome_vendedor nome, g1.tipo_item, g1.mes_referencia, g1.ano_referencia, 
								    g1.valor_venda||';'||g1.valor_retorno||';'||g1.valor_total_acessorio valor_faturado, 
								    g1.val_cancelamento||';'||g1.valor_retorno_cancelado val_desconto,
								    g1.valor_total||';'||g1.valor_total_retorno||';'||g1.valor_total_acessorio valor_total,
								    g1.pct_comissao_venda||';'||g1.pct_comissao_retorno||';'||g1.pct_comissao_acessorio pct_comissao, {$campo_formula['META_USADOS']} metadados,
								    g1.valor_comissao_venda||';'||g1.valor_comissao_retorno||';'||g1.valor_comissao_acessorio||';'||g1.valor_comissao_emplacamento valor_comissao, to_char(0) premio, {$metapremio} metapremio, g1.cpf 
								    from
								    (
								          select x1.empresa, x1.revenda, x1.vendedor, x1.nome_vendedor, x1.tipo_item, x1.valor_venda, x1.val_cancelamento, x1.valor_retorno, x1.valor_retorno_cancelado,  x1.valor_total, x1.valor_total_retorno, x1.valor_total_acessorio,
								         -------- Faturamento --------- 
								          case when x1.quantidade >= 1 then round((x1.valor_total*0.5)/100,2) else 0 end valor_comissao_venda, 
								          case when x1.quantidade >= 1 then '0.5' else '0' end pct_comissao_venda,
								         ---------- Retorno Financiamento ----------     
								          case when x1.quantidade >= 1 then round((x1.valor_total_retorno*10)/100,2) else 0 end valor_comissao_retorno, 
								          case when x1.quantidade >= 1 then '10' else '0' end pct_comissao_retorno, 
								         --------- Acessrios------------------
								          case when x1.quantidade >= 1 then round((x1.valor_total_acessorio*6)/100,2) else 0 end valor_comissao_acessorio, 
								          case when x1.quantidade >= 1 then 6 else 0 end pct_comissao_acessorio,
								         ----------- Emplacamento -----------
								           x1.n_emplacamento*35 valor_comissao_emplacamento,  
								           x1.mes_referencia, x1.ano_referencia, u.cpf  
								          from
								          (
								               select s1.*, nvl(s2.val_cancelamento,0) val_cancelamento, s1.valor_venda-nvl(s2.val_cancelamento,0) valor_total,
								               nvl(s2.valor_financiado_cancelado,0) valor_financiado_cancelado, s1.valor_financiado-nvl(s2.valor_financiado_cancelado,0) valor_total_financiado,  
								               nvl(s2.valor_retorno_cancelado,0) valor_retorno_cancelado, 
								               s1.valor_retorno-nvl(s2.valor_retorno_cancelado,0) valor_total_retorno, s1.valor_acessorio valor_total_acessorio 
								               from
								               (
								                 select v.empresa, v.revenda, v.vendedor, v.nome_vendedor, v.tipo_item, sum(v.valor_venda)-nvl(sum(dv.valor_dv),0) valor_venda, 
								                 nvl(sum(f9.valor_financiado),0) valor_financiado, nvl(sum(f9.valor_retorno),0) valor_retorno, 0 valor_acessorio, sum(v.quantidade) quantidade,
								                 to_number(to_char(v.DTA_ENTRADA_SAIDA,'mm')) mes_referencia, to_number(to_char(v.DTA_ENTRADA_SAIDA,'yyyy')) ano_referencia, nvl(sum(n.acessorio),0) n_emplacamento
								                 from qlik.j_tab_vendedor_veiculo v
								                 left join
								                         (
								                           select empresa, revenda, proposta, fat_oper, sum(valor_dv) valor_dv
								                           from qlik.j_v_fiat_dv group by empresa, revenda, proposta, fat_oper 
								                         ) dv on v.empresa = dv.empresa and v.revenda = dv.revenda and v.fat_oper = dv.fat_oper and nvl(v.proposta,0) = dv.proposta
								                 left join ( select an.empresa, an.revenda, an.vendedor, an.veiculo, an.fat_oper, an.valor_venda, an.proposta, an.dta_entrada_saida,
								                             nvl(an.acessorio,(select sum(acessorio)*-1 from qlik.j_v_emplacamentp_novos where valor_venda >=0 and empresa = an.empresa and revenda = an.revenda and fat_oper = an.fat_oper)) acessorio 
								                             from qlik.j_v_emplacamentp_usados an
								                           ) n on v.empresa = n.empresa and v.revenda = n.revenda and v.veiculo = n.veiculo and v.vendedor = n.vendedor and v.fat_oper = n.fat_oper 
								                 left join 
								                           (
								                              select f10.EMPRESA, f10.REVENDA, f10.VENDEDOR, f10.VEICULO, f10.PROPOSTA, f10.FAT_OPER, f10.DTA_ENTRADA_SAIDA, f10.VALOR_FINANCIADO,
								                              f10.taxa_retorno, f10.val_retorno_financ, f10.ila,
								                              f10.val_retorno_financ+((f10.val_retorno_financ*f10.ila)/100) valor_retorno
								                              from
								                              (  
								                                select f1.EMPRESA, f1.REVENDA, f1.VENDEDOR, f1.VEICULO, f1.PROPOSTA, f1.FAT_OPER, f1.DTA_ENTRADA_SAIDA, f1.VALOR_FINANCIADO,  
								                                nvl(f1.taxa_retorno,(select taxa_retorno from qlik.j_v_financiamento_novos where valor_financiado >=0 and empresa = f1.empresa and revenda = f1.revenda and fat_oper = f1.fat_oper)) taxa_retorno,
								                                nvl(f1.val_retorno_financ,(select val_retorno_financ*-1 from qlik.j_v_financiamento_novos where valor_financiado >=0 and empresa = f1.empresa and revenda = f1.revenda and fat_oper = f1.fat_oper)) val_retorno_financ,
								                                nvl(cp.ila,0) ila
								                                from qlik.j_v_financiamento_usados f1 
								                                left join (select empresa, revenda, mes, ano, ila 
								                                               from sismonaco.com_parametros where mes = '{$exp[1]}' and ano = '{$exp[2]}'
								                                          ) cp on (f1.empresa = cp.empresa and f1.revenda = cp.revenda)
								                                where f1.empresa = {$emp} 
								                              ) f10   
								                           ) f9 on v.empresa = f9.empresa and v.revenda = f9.revenda and v.fat_oper = f9.fat_oper 
								                 where v.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
								                 and v.tipo_item = 'U' 
								                 and v.empresa||'.'||v.revenda in ('{$empresa}')
								                 group by v.empresa, v.revenda, v.vendedor, v.nome_vendedor, v.tipo_item,
								                 to_number(to_char(v.DTA_ENTRADA_SAIDA,'mm')), to_number(to_char(v.DTA_ENTRADA_SAIDA,'yyyy'))
								               ) s1
								               left join
								               (
								                select cv.empresa, cv.revenda, cv.usuario_fat, cv.tipo_item, sum(cv.tot_nota_fiscal) val_cancelamento, 
								                sum(cv.valor_financiado) valor_financiado_cancelado, sum(cv.val_retorno_financ) valor_retorno_cancelado
								                from qlik.j_v_cancelamento_nota_veiculo cv
								                where cv.dta_cancelamento_nota between to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
								                group by cv.empresa, cv.revenda, cv.usuario_fat, cv.tipo_transacao, cv.tipo_item
								               ) s2 on (s1.empresa = s2.empresa and s1.revenda = s2.revenda and s1.vendedor = s2.usuario_fat and s1.tipo_item = s2.tipo_item)
								         ) x1 left join cnp.ger_usuario u on x1.vendedor = u.usuario
								    ) g1
								    
								    union all
								    
								   select g1.empresa, g1.vendedor usuario, g1.nome_vendedor nome, g1.tipo_item, g1.mes_referencia, g1.ano_referencia,
								   g1.val_fat_retorno||';'||g1.valor_retorno||';'||g1.valor_total_acessorio valor_faturado, 
								   0||';'||g1.valor_retorno_cancelado val_desconto,
								   g1.val_fat_retorno||';'||g1.valor_total_retorno||';'||g1.valor_total_acessorio valor_total,
								   g1.pct_comissao_venda||';'||g1.pct_comissao_retorno||';'||g1.pct_comissao_acessorio pct_comissao, {$campo_formula['META_DIRETO']} metadados,
								   g1.valor_comissao_venda||';'||g1.valor_comissao_retorno||';'||g1.valor_comissao_acessorio||';'||g1.valor_comissao_emplacamento valor_comissao, to_char(0) premio, {$metapremio} metapremio, g1.cpf
								   from
								   (
								       select x1.empresa, x1.revenda, x1.vendedor, x1.nome_vendedor, x1.tipo_item, x1.val_fat_retorno, x1.val_cancelamento, x1.valor_total, x1.valor_total_financiado, 
								              x1.valor_retorno, x1.valor_retorno_cancelado, x1.valor_total_retorno, x1.valor_total_acessorio, u.cpf,
								          -------- Faturamento ---------
								         round((x1.val_fat_retorno*10)/100,2) valor_comissao_venda, 
								                 
								         10 pct_comissao_venda, 
								         -------- Retorno Financeiro ---------
								         case when x1.quantidade >= 1 then round((x1.valor_total_retorno*10)/100,2) else 0 end valor_comissao_retorno,
								         
								         case when x1.quantidade >= 1 then '10' else '0' end pct_comissao_retorno,        
								         --------- Acessrios------------------
								         case when x1.quantidade >= 1 then nvl((x1.valor_total_acessorio*6)/100,0) else 0 end valor_comissao_acessorio, 
								         
								         case when x1.quantidade >= 1 then '6' else '0' end pct_comissao_acessorio,
								               x1.n_emplacamento*35 valor_comissao_emplacamento,  
								               x1.mes_referencia, x1.ano_referencia   
								          from
								          (
								               select s1.*, nvl(s2.val_cancelamento,0) val_cancelamento, s1.valor_venda-nvl(s2.val_cancelamento,0) valor_total,
								               nvl(s2.valor_financiado_cancelado,0) valor_financiado_cancelado, s1.valor_financiado-nvl(s2.valor_financiado_cancelado,0) valor_total_financiado, 
								               nvl(s2.val_retorno_financ,0) valor_retorno_cancelado, s1.valor_retorno-nvl(s2.val_retorno_financ,0) valor_total_retorno, s1.valor_acessorio valor_total_acessorio
								               from
								               (
								                 select v.empresa, v.revenda, v.vendedor, v.nome_vendedor, v.tipo_item, sum(v.valor_venda) valor_venda, nvl(sum(s2.valor_financiado),0) valor_financiado, nvl(sum(s2.valor_retorno),0) valor_retorno, 0 valor_acessorio, sum(v.quantidade) quantidade,
								                 to_number(to_char(v.DTA_ENTRADA_SAIDA,'mm')) mes_referencia, to_number(to_char(v.DTA_ENTRADA_SAIDA,'yyyy')) ano_referencia, nvl(sum(n.acessorio),0) n_emplacamento, nvl(sum(re.val_retorno),0)-nvl(sum((re.val_retorno*1.5)/100),0) val_fat_retorno
								                 from qlik.j_tab_vendedor_veiculo v
								                 left join (
								                             select r.empresa, r.revenda, sum(r.val_retorno) val_retorno, p.veiculo, p.vendedor 
								                             from cnp.vei_retorno r join cnp.vei_proposta p on r.empresa = p.empresa and r.revenda = p.revenda and r.proposta = p.proposta 
								                             group by r.empresa, r.revenda, p.veiculo, p.vendedor  
								                           ) re on v.empresa = re.empresa and v.revenda = re.revenda and v.vendedor = re.vendedor and v.veiculo = re.veiculo
								                 left join ( select an.empresa, an.revenda, an.vendedor, an.veiculo, an.fat_oper, an.valor_venda, an.proposta, an.dta_entrada_saida,
								                             nvl(an.acessorio,(select sum(acessorio)*-1 from qlik.j_v_emplacamento_direto where valor_venda >=0 and empresa = an.empresa and revenda = an.revenda and veiculo = an.veiculo)) acessorio 
								                             from qlik.j_v_emplacamento_direto an
								                           ) n on v.empresa = n.empresa and v.revenda = n.revenda and v.veiculo = n.veiculo and v.vendedor = n.vendedor and v.fat_oper = n.fat_oper 
								                 left join  
								                           ( 
								                               select f1.empresa, f1.revenda, f1.proposta, f1.vendedor, f1.veiculo, f1.valor_financiado,
								                               f2.taxa_retorno, f2.pct_ila, f2.valor_retorno
								                               from
								                               (
								                                 select p.empresa, p.revenda, p.proposta, p.vendedor, p.veiculo, pg.val_pagamento valor_financiado 
								                                 from cnp.vei_proposta p 
								                                 join (select empresa, revenda, proposta, val_pagamento from cnp.vei_pagamento where condicao = 141) pg 
								                                 on ( p.empresa = pg.empresa and p.revenda = pg.revenda and p.proposta = pg.proposta )
								                                 where p.tipo_venda in ('D','F')
								                               ) f1
								                               join
								                               (
								                                  select p.empresa, p.revenda, p.proposta, p.vendedor, p.veiculo, nvl(vn.val_financiado,0) val_financiado, 
								                                  nvl(vn.taxa_retorno,0) taxa_retorno, nvl(vn.val_retorno_financ,0) val_retorno_financ, nvl(cp.ila,0) pct_ila, 
								                                  (nvl(vn.val_retorno_financ,0)*nvl(cp.ila,0))/100 valor_ila, 
								                                  nvl(vn.val_retorno_financ,0)+((nvl(vn.val_retorno_financ,0)*nvl(cp.ila,0))/100) valor_retorno        
								                                  from cnp.vei_proposta p 
								                                  join cnp.vei_negociacao vn on (vn.empresa = p.empresa and vn.revenda = p.revenda and vn.proposta = p.proposta) 
								                                  left join (select empresa, revenda, mes, ano, ila 
								                                             from sismonaco.com_parametros where mes = '{$exp[1]}' and ano = '{$exp[2]}' 
								                                            ) cp on (p.empresa = cp.empresa and p.revenda = cp.revenda) 
								                                  where p.tipo_venda in ('D','F')
								                               ) f2 on (f1.empresa = f2.empresa and f1.revenda = f2.revenda and f1.proposta = f2.proposta)  
								                           ) s2 on v.empresa = s2.empresa and v.revenda = s2.revenda and v.veiculo = s2.veiculo and v.vendedor = s2.vendedor 
								                 where v.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
								                 and v.tipo_item = 'D' 
								                 and v.empresa||'.'||v.revenda in ('{$empresa}')
								                 group by v.empresa, v.revenda, v.vendedor, v.nome_vendedor, v.tipo_item,
								                 to_number(to_char(v.DTA_ENTRADA_SAIDA,'mm')), to_number(to_char(v.DTA_ENTRADA_SAIDA,'yyyy'))
								               ) s1
								               left join
								               (
								                select cv.empresa, cv.revenda, cv.usuario_fat, cv.tipo_item, sum(cv.tot_nota_fiscal) val_cancelamento, 
								                sum(cv.valor_financiado) valor_financiado_cancelado, sum(cv.val_retorno_financ) val_retorno_financ
								                from qlik.j_v_cancelamento_nota_veiculo cv
								                where cv.dta_cancelamento_nota between to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
								                group by cv.empresa, cv.revenda, cv.usuario_fat, cv.tipo_transacao, cv.tipo_item
								               ) s2 on (s1.empresa = s2.empresa and s1.revenda = s2.revenda and s1.vendedor = s2.usuario_fat and s1.tipo_item = s2.tipo_item)
								               
								         ) x1 left join cnp.ger_usuario u on x1.vendedor = u.usuario
								     ) g1

								) b{$i} where b{$i}.tipo_item in ('{$tipo}') union ";
					}
				}else{
					if ($por == "FAI"){
						$case = "case ";
						$casep = "case ";
						$premio1 = (isset($campo_formula['PREMIO1'])) ? ($campo_formula['PREMIO1'] > 0) ? $campo_formula['PREMIO1'] : 0 : 0;
						$premio2 = (isset($campo_formula['PREMIO2'])) ? ($campo_formula['PREMIO2'] > 0) ? $campo_formula['PREMIO2'] : 0 : 0;
						$premio3 = (isset($campo_formula['PREMIO3'])) ? ($campo_formula['PREMIO3'] > 0) ? $campo_formula['PREMIO3'] : 0 : 0;
						$premio4 = (isset($campo_formula['PREMIO4'])) ? ($campo_formula['PREMIO4'] > 0) ? $campo_formula['PREMIO4'] : 0 : 0;
						if ($auto == "S"){
							if ($tip == 4){
								$m = ($parametros->MEC_PROD4 > 0) ? ($parametros->MEC_PROD4/100) : 0;
								$mv = (($produtividade * $m) * $parametros->QTD_MECA);
								$e = ($parametros->ELE_PROD4 > 0) ? ($parametros->ELE_PROD4/100) : 0;
								$ev = (($produtividade * $e) * $parametros->QTD_ELET);
								
								
								$perc = ($parametros->CON_PROD1 > 0) ? ($parametros->CON_PROD1/100) : 0;
								$fai_de1 = 0;
								$fai_ate1 = ((($mv + $ev)/$parametros->QTD_CONS) * $perc);
								$fai_de2 = ((($mv + $ev)/$parametros->QTD_CONS) * $perc) + 0.01;
								$perc = ($parametros->CON_PROD2 > 0) ? ($parametros->CON_PROD2/100) : 0;
								$fai_ate2 = ((($mv + $ev)/$parametros->QTD_CONS) * $perc);
								$fai_de3 = ((($mv + $ev)/$parametros->QTD_CONS) * $perc) + 0.01;
								$perc = ($parametros->CON_PROD3 > 0) ? ($parametros->CON_PROD3/100) : 0;
								$fai_ate3 = ((($mv + $ev)/$parametros->QTD_CONS) * $perc);
								$fai_de4 = ((($mv + $ev)/$parametros->QTD_CONS) * $perc) + 0.01;
								$fai_ate4 = (($mv + $ev)/$parametros->QTD_CONS);
								
							}else{
								$fai_de1 = 0;
								$fai_ate1 = $produtividade * 0.7;
								$fai_de2 = ($produtividade * 0.7) + 0.01;
								$fai_ate2 = $produtividade * 0.8;
								$fai_de3 = ($produtividade * 0.8) + 0.01;
								$fai_ate3 = $produtividade * 0.9;
								$fai_de4 = ($produtividade * 0.9) + 0.01;
								$fai_ate4 = $produtividade;
							}
							
							if (isset($campo_formula['FAI_COMISSAO1'])){
								$case .= "when x1.valor_calc between {$fai_de1} and {$fai_ate1} then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO1'])." ";
								$com = $campo_formula['FAI_COMISSAO1'];
								$casep .= "when x1.valor_calc between {$fai_de1} and {$fai_ate1} then 0 ";
							}
							if (isset($campo_formula['FAI_COMISSAO2'])){
								$case .= "when x1.valor_calc between {$fai_de2} and {$fai_ate2} then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO2'])." ";
								$com = $campo_formula['FAI_COMISSAO2'];
								$casep .= "when x1.valor_calc between {$fai_de2} and {$fai_ate2} then ".str_replace(",", ".", $premio1)." ";
								$pre = $premio1;
							}
							if (isset($campo_formula['FAI_COMISSAO3'])){
								$case .= "when x1.valor_calc between {$fai_de3} and {$fai_ate3} then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO3'])." ";
								$com = $campo_formula['FAI_COMISSAO3'];
								$casep .= "when x1.valor_calc between {$fai_de3} and {$fai_ate3} then ".str_replace(",", ".", $premio2)." ";
								$pre = $premio2;
							}
							if (isset($campo_formula['FAI_COMISSAO4'])){
								$case .= "when x1.valor_calc between {$fai_de4} and {$fai_ate4} then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO4'])." ";
								$com = $campo_formula['FAI_COMISSAO4'];
								$casep .= "when x1.valor_calc between {$fai_de4} and {$fai_ate4} then ".str_replace(",", ".", $premio3)." ";
								$pre = $premio3;
							}
							$case .= "when x1.valor_calc > 0 then ".str_replace(",", ".", $com)." ";
							$casep .= "when x1.valor_calc > 0 then ".str_replace(",", ".", $pre)." ";
						}else{
							$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE1'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE1'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO1'])."";
							$com = $campo_formula['FAI_COMISSAO1'];
							$casep .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE1'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE1'])." then 0";
							if (isset($campo_formula["FAI_DE2"])){
								$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE2'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE2'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO2'])."";
								$com = $campo_formula['FAI_COMISSAO2'];
								$casep .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE2'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE2'])." then ".str_replace(",", ".", $premio1)."";
								$pre = $premio1;
							}
							if (isset($campo_formula["FAI_DE3"])){
								$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE3'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE3'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO3'])."";
								$com = $campo_formula['FAI_COMISSAO3'];
								$casep .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE3'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE3'])." then ".str_replace(",", ".", $premio2)."";
								$pre = $premio2;
							}
							if (isset($campo_formula["FAI_DE4"])){
								$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE4'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE4'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO4'])."";
								$com = $campo_formula['FAI_COMISSAO4'];
								$casep .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE4'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE4'])." then ".str_replace(",", ".", $premio3)."";
								$pre = $premio3;
							}
							if (isset($campo_formula["FAI_DE5"])){
								$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE5'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE5'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO5'])."";
								$com = $campo_formula['FAI_COMISSAO5'];
								$casep .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE5'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE5'])." then ".str_replace(",", ".", $premio4)."";
								$pre = $premio4;
							}
							$case .= "when x1.valor_calc > 0 then ".str_replace(",", ".", $com)." ";
							$casep .= "when x1.valor_calc > 0 then ".str_replace(",", ".", $pre)." "; 
						}
						
						$casem = "case  ";
						if (in_array("N", $considerar)){
							$casem .= "when x1.tipo_item = 'N' then {$campo_formula['META_NOVOS']} ";
						}
						if (in_array("U", $considerar)){
							$casem .= "when x1.tipo_item = 'U' then {$campo_formula['META_USADOS']} ";
						}
						if (in_array("D", $considerar)){
							$casem .= "when x1.tipo_item = 'D' then {$campo_formula['META_DIRETO']} ";
						}
						if (in_array("C", $considerar)){
							$casem .= "when x1.tipo_item = 'C' then {$campo_formula['META_CONSORCIO']} ";
						}
						if (in_array("P", $considerar)){
							$casem .= "when x1.tipo_item = 'P' then {$campo_formula['META_PECAS']} ";
						}
						if (in_array("S", $considerar)){
							$casem .= "when x1.tipo_item = 'S' then {$campo_formula['META_MAODEOBRA']} ";
						}
						$case .= "else  0 end pct_comissao";
						$casep .= "else  0 end premio";
						$casem .= "else  0 end metadados";
						$metapremio = (isset($campo_formula['META_PREMIO'])) ? ($campo_formula['META_PREMIO'] != "") ? $campo_formula['META_PREMIO'] : 0 : 0;
						return "select {$grupo} grupo, b{$i}.empresa, b{$i}.usuario, gu.nome, b{$i}.tipo_item, b{$i}.mes_referencia,
								b{$i}.ano_referencia, b{$i}.valor_faturado, b{$i}.val_desconto, b{$i}.valor_total, to_char(b{$i}.pct_comissao) pct_comissao,
								b{$i}.metadados, to_char(round((b{$i}.valor_total*b{$i}.pct_comissao)/100,2)) valor_comissao, to_char(b{$i}.premio) premio,
								{$metapremio} metapremio, gu.cpf
								from
								(
									select x1.empresa, x1.usuario, x1.tipo_item, x1.mes_referencia, x1.ano_referencia,
									to_char(sum(x1.valor_faturado)) valor_faturado, to_char(sum(x1.val_desconto)) val_desconto, to_char(sum(x1.valor_faturado)-sum(x1.val_desconto)) valor_total,
									{$case}, {$casep}, {$casem}
									from
									(
										select a1.empresa, a1.revenda, a1.nome, a1.usuario, a1.tipo_item, a1.departamento, a1.mes_referencia, a1.ano_referencia,
										a1.valor_faturado, nvl(a2.val_desconto,0) val_desconto, a1.valor_faturado-nvl(a2.val_desconto,0) valor_total,
										(
											select valor_calc
											from
											(
												select a1.usuario, a1.valor_faturado-nvl(a2.val_desconto,0) valor_calc
												from
												(
													select s1.*
													from
													(
													select m.usuario, sum(m.valor_venda) valor_faturado
													from qlik.j_tab_fat_vendedor m
													where m.dta_referencia between
													to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
													and m.empresa||'.'||m.revenda in ('{$empresa}')
													and m.tipo in ('{$tipo}')
													and m.usuario in ({$vendedor})
													group by m.usuario
													) s1
												) a1
												left join
												(
													select c.usuario_fat, sum(c.val_desconto) val_desconto
													from qlik.j_v_cancelamento_nota c
													where c.dta_cancelamento_nota between
													to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
													and c.empresa||'.'||c.revenda in ('{$empresa}')
													and c.tipo in ('{$tipo}') group by c.usuario_fat
												) a2
												on a1.usuario = a2.usuario_fat
											)calc where calc.usuario = a1.usuario
										) valor_calc
										from
										(
											select s1.*
											from
											(
												select m.empresa, m.revenda, m.usuario, m.nome_vendedor nome,  m.tipo tipo_item, m.departamento,
												to_number(to_char(m.dta_referencia,'mm')) mes_referencia, to_number(to_char(m.dta_referencia,'yyyy')) ano_referencia,
												sum(m.valor_venda) valor_faturado
												from qlik.j_tab_fat_vendedor m
												where m.dta_referencia between
												to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
												and m.empresa||'.'||m.revenda in ('{$empresa}')
												and m.tipo in ('{$tipo}')
												and m.usuario in ({$vendedor})
												group by m.empresa, m.revenda, m.usuario, m.nome_vendedor,
												m.tipo, m.departamento, to_number(to_char(m.dta_referencia,'mm')), to_number(to_char(m.dta_referencia,'yyyy'))
											) s1
										) a1
										left join
										(
											select c.empresa, c.revenda, c.usuario_fat, c.mecanico, c.numero_nota_fiscal, c.serie_nota_fiscal, c.mes_emissao, c.ano_emissao, c.mes_cancelamento, c.ano_cancelamento, c.tipo, c.departamento, c.val_desconto
											from qlik.j_v_cancelamento_nota c
											where c.dta_cancelamento_nota between
											to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
											and c.empresa||'.'||c.revenda in ('{$empresa}')
											and c.tipo in ('{$tipo}')
											and c.usuario_fat in ({$vendedor})
										) a2
										on ( a1.empresa = a2.empresa and a1.revenda = a2.revenda
										and a1.mes_referencia = a2.mes_cancelamento and a1.ano_referencia = a2.ano_cancelamento
										and a1.tipo_item = a2.tipo and a1.departamento = a2.departamento and a1.usuario = a2.usuario_fat )
									) x1 group by x1.empresa, x1.usuario, x1.tipo_item, x1.mes_referencia, x1.ano_referencia, x1.valor_calc
								) b{$i} join ger_usuario gu on b{$i}.usuario = gu.usuario union ";
					}elseif ($por == "TIP"){
						$case = "case  ";
						$casem = "case  ";
						if (in_array("P", $considerar)){
							$case .= "when x1.tipo_item = 'P' then ".str_replace(",", ".", $campo_formula['COMISSAO_PECAS'])."";
							$casem .= "when x1.tipo_item = 'P' then {$campo_formula['META_PECAS']}";
						}
						if (in_array("S", $considerar)){
							$case .= "when x1.tipo_item = 'S' then ".str_replace(",", ".", $campo_formula['COMISSAO_MAODEOBRA'])."";
							$casem .= "when x1.tipo_item = 'S' then {$campo_formula['META_MAODEOBRA']}";
						}
						$case .= "else  0 end pct_comissao";
						$casem .= "else  0 end metadados ";
						$metapremio = (isset($campo_formula['META_PREMIO'])) ? ($campo_formula['META_PREMIO'] != "") ? $campo_formula['META_PREMIO'] : 0 : 0;
						return "select {$grupo} grupo, b{$i}.empresa, b{$i}.usuario, gu.nome, b{$i}.tipo_item, b{$i}.mes_referencia,
								b{$i}.ano_referencia, b{$i}.valor_faturado, b{$i}.val_desconto, b{$i}.valor_total, to_char(b{$i}.pct_comissao) pct_comissao,
								b{$i}.metadados, to_char(round((b{$i}.valor_total*b{$i}.pct_comissao)/100,2)) valor_comissao, to_char(0) premio, 
								{$metapremio} metapremio, gu.cpf
								from
								(
									select x1.empresa, x1.usuario, x1.tipo_item, x1.mes_referencia, x1.ano_referencia,
									to_char(sum(x1.valor_faturado)) valor_faturado, to_char(sum(x1.val_desconto)) val_desconto, to_char(sum(x1.valor_faturado)-sum(x1.val_desconto)) valor_total,
									{$case}, {$casem}
									from
									(
										select a1.empresa, a1.revenda, a1.nome, a1.usuario, a1.tipo_item, a1.departamento, a1.mes_referencia, a1.ano_referencia,
										a1.valor_faturado, nvl(a2.val_desconto,0) val_desconto, a1.valor_faturado-nvl(a2.val_desconto,0) valor_total
										from
										(
											select s1.*
											from
											(
												select m.empresa, m.revenda, m.usuario, m.nome_vendedor nome,  m.tipo tipo_item, m.departamento,
												to_number(to_char(m.dta_referencia,'mm')) mes_referencia, to_number(to_char(m.dta_referencia,'yyyy')) ano_referencia,
												sum(m.valor_venda) valor_faturado
												from qlik.j_tab_fat_vendedor m
												where m.dta_referencia between
												to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
												and m.empresa||'.'||m.revenda in ('{$empresa}')
												and m.tipo in ('{$tipo}')
												and m.usuario in ({$vendedor})
												group by m.empresa, m.revenda, m.usuario, m.nome_vendedor,
												m.tipo, m.departamento, to_number(to_char(m.dta_referencia,'mm')), to_number(to_char(m.dta_referencia,'yyyy'))
											) s1
										) a1
										left join
										(
											select c.empresa, c.revenda, c.usuario_fat, c.mecanico, c.numero_nota_fiscal, c.serie_nota_fiscal, c.mes_emissao, c.ano_emissao, c.mes_cancelamento, c.ano_cancelamento, c.tipo, c.departamento, c.val_desconto
											from qlik.j_v_cancelamento_nota c
											where c.dta_cancelamento_nota between
											to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
											and c.empresa||'.'||c.revenda in ('{$empresa}')
											and c.tipo in ('{$tipo}')
											and c.usuario_fat in ({$vendedor})
										) a2
										on ( a1.empresa = a2.empresa and a1.revenda = a2.revenda
										and a1.mes_referencia = a2.mes_cancelamento and a1.ano_referencia = a2.ano_cancelamento
										and a1.tipo_item = a2.tipo and a1.departamento = a2.departamento and a1.usuario = a2.usuario_fat )
									) x1 group by x1.empresa, x1.usuario, x1.tipo_item, x1.mes_referencia, x1.ano_referencia
								) b{$i} join ger_usuario gu on b{$i}.usuario = gu.usuario union ";
					}
				}
			}elseif ($tip == 2){
				if ($por == "FAI"){
					$case = "case ";
					if ($auto == "S"){
						$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE1'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE1'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO1'])." ";
						$com = $campo_formula['FAI_COMISSAO1'];
						if (isset($campo_formula["FAI_DE2"])){
							$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE2'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE2'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO2'])." ";
							$com = $campo_formula['FAI_COMISSAO2'];
						}
						if (isset($campo_formula["FAI_DE3"])){
							$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE3'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE3'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO3'])." ";
							$com = $campo_formula['FAI_COMISSAO3'];
						}
						if (isset($campo_formula["FAI_DE4"])){
							$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE4'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE4'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO4'])." ";
							$com = $campo_formula['FAI_COMISSAO4'];
						}
						if (isset($campo_formula["FAI_DE5"])){
							$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE5'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE5'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO5'])." ";
							$com = $campo_formula['FAI_COMISSAO5'];
						}
						$case .= "when x1.valor_calc > 0 then ".str_replace(",", ".", $com)." ";
					}else{
						$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE1'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE1'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO1'])." ";
						$com = $campo_formula['FAI_COMISSAO1'];
						if (isset($campo_formula["FAI_DE2"])){
							$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE2'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE2'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO2'])." ";
							$com = $campo_formula['FAI_COMISSAO2'];
						}
						if (isset($campo_formula["FAI_DE3"])){
							$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE3'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE3'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO3'])." ";
							$com = $campo_formula['FAI_COMISSAO3'];
						}
						if (isset($campo_formula["FAI_DE4"])){
							$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE4'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE4'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO4'])." ";
							$com = $campo_formula['FAI_COMISSAO4'];
						}
						if (isset($campo_formula["FAI_DE5"])){
							$case .= "when x1.valor_calc between ".str_replace(",", ".", $campo_formula['FAI_DE5'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE5'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO5'])." ";
							$com = $campo_formula['FAI_COMISSAO5'];
						}
						$case .= "when x1.valor_calc > 0 then ".str_replace(",", ".", $com)." ";
					}
					$casem = "case  ";
					if (in_array("N", $considerar)){
						$casem .= "when x1.tipo = 'N' then {$campo_formula['META_NOVOS']} ";
					}
					if (in_array("U", $considerar)){
						$casem .= "when x1.tipo = 'U' then {$campo_formula['META_USADOS']} ";
					}
					if (in_array("D", $considerar)){
						$casem .= "when x1.tipo = 'D' then {$campo_formula['META_DIRETO']} ";
					}
					if (in_array("C", $considerar)){
						$casem .= "when x1.tipo = 'C' then {$campo_formula['META_CONSORCIO']} ";
					}
					if (in_array("P", $considerar)){
						$casem .= "when x1.tipo = 'P' then {$campo_formula['META_PECAS']} ";
					}
					if (in_array("S", $considerar)){
						$casem .= "when x1.tipo = 'S' then {$campo_formula['META_MAODEOBRA']} ";
					}
					$case .= "else  0 end pct_comissao";
					$casem .= "else  0 end metadados";
					$metapremio = (isset($campo_formula['META_PREMIO'])) ? ($campo_formula['META_PREMIO'] != "") ? $campo_formula['META_PREMIO'] : 0 : 0;
					return "select {$grupo} grupo, b{$i}.empresa, b{$i}.usuario, b{$i}.nome, b{$i}.tipo tipo_item, b{$i}.mes_referencia,
							b{$i}.ano_referencia, b{$i}.valor_faturado, b{$i}.val_desconto, b{$i}.valor_total, to_char(b{$i}.pct_comissao) pct_comissao,
							b{$i}.metadados, to_char(round((b{$i}.valor_total*b{$i}.pct_comissao)/100,2)) valor_comissao, to_char(0) premio,
							{$metapremio} metapremio, b{$i}.cpf
							from
							(
								select x1.empresa, x2.usuario, x2.nome, x2.cpf, x1.tipo, x1.mes_referencia, x1.ano_referencia,
								to_char(sum(x1.valor_faturado)) valor_faturado, to_char(sum(x1.val_desconto)) val_desconto,
								to_char(sum(x1.valor_faturado)-sum(x1.val_desconto)) valor_total,
								{$case}, {$casem}
								from
								(
									select a1.empresa, a1.revenda, a1.nome, a1.usuario, a1.tipo, a1.departamento, a1.mes_referencia, a1.ano_referencia,
									a1.valor_faturado, nvl(a2.val_desconto,0) val_desconto,
									(
										select a1.valor_faturado-nvl((select sum(c.val_desconto) val_desconto
										from qlik.j_v_cancelamento_nota c
										where c.dta_cancelamento_nota between to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
										and c.empresa||'.'||c.revenda in ('{$empresa}') and c.tipo in ('{$tipo}') group by c.empresa),0)
										from
										(
											select sum(m.valor_venda) valor_faturado
											from qlik.j_tab_fat_vendedor m
											where m.dta_referencia between
											to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
											and m.empresa||'.'||m.revenda in ('{$empresa}')
											{$equipe}{$departamento}
											and m.tipo in ('{$tipo}')
										) a1
									) valor_calc
									from
									(
										select s1.*
										from
										(
											select m.empresa, m.revenda, m.usuario, m.nome_vendedor nome,  m.tipo, m.departamento,
											to_number(to_char(m.dta_referencia,'mm')) mes_referencia, to_number(to_char(m.dta_referencia,'yyyy')) ano_referencia,
											sum(m.valor_venda) valor_faturado
											from qlik.j_tab_fat_vendedor m
											where m.dta_referencia between
											to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
											and m.empresa||'.'||m.revenda in ('{$empresa}')
											{$equipe}{$departamento}
											and m.tipo in ('{$tipo}')
											group by m.empresa, m.revenda, m.usuario, m.nome_vendedor,
											m.tipo, m.departamento, to_number(to_char(m.dta_referencia,'mm')), to_number(to_char(m.dta_referencia,'yyyy'))
										) s1
									) a1
									left join
									(
										select c.empresa, c.revenda, c.usuario_fat, c.mecanico, c.numero_nota_fiscal, c.serie_nota_fiscal, c.mes_emissao, c.ano_emissao, c.mes_cancelamento, c.ano_cancelamento, c.tipo, c.departamento, c.val_desconto
										from qlik.j_v_cancelamento_nota c
										where c.dta_cancelamento_nota between
										to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
										and c.empresa||'.'||c.revenda in ('{$empresa}')
										and c.tipo in ('{$tipo}')
									) a2
									on ( a1.empresa = a2.empresa and a1.revenda = a2.revenda
									and a1.mes_referencia = a2.mes_cancelamento and a1.ano_referencia = a2.ano_cancelamento
									and a1.tipo = a2.tipo and a1.departamento = a2.departamento and a1.usuario = a2.usuario_fat )
								) x1 cross join (select b1.usuario, b1.nome, b1.cpf from ger_usuario b1 where b1.usuario in ({$vendedor})) x2 group by x1.empresa, x2.usuario, x2.nome, x2.cpf,x1.tipo,x1.mes_referencia, x1.ano_referencia, x1.valor_calc
							) b{$i} union ";
				}elseif ($por == "TIP"){
					$case = "case  ";
					$casem = "case  ";
					if (in_array("N", $considerar)){
						$case .= "when x1.tipo = 'N' then ".str_replace(",", ".", $campo_formula['COMISSAO_NOVOS'])."";
						$casem .= "when x1.tipo = 'N' then {$campo_formula['META_NOVOS']}";
					}
					if (in_array("U", $considerar)){
						$case .= "when x1.tipo = 'U' then ".str_replace(",", ".", $campo_formula['COMISSAO_USADOS'])."";
						$casem .= "when x1.tipo = 'U' then {$campo_formula['META_USADOS']}";
					}
					if (in_array("D", $considerar)){
						$case .= "when x1.tipo = 'D' then ".str_replace(",", ".", $campo_formula['COMISSAO_DIRETO'])." ";
						$casem .= "when x1.tipo = 'D' then {$campo_formula['META_DIRETO']}";
					}
					if (in_array("C", $considerar)){
						$case .= "when x1.tipo = 'C' then ".str_replace(",", ".", $campo_formula['COMISSAO_CONSORCIO'])." ";
						$casem .= "when x1.tipo = 'C' then {$campo_formula['META_CONSORCIO']}";
					}
					if (in_array("P", $considerar)){
						$case .= "when x1.tipo = 'P' then ".str_replace(",", ".", $campo_formula['COMISSAO_PECAS'])." ";
						$casem .= "when x1.tipo = 'P' then {$campo_formula['META_PECAS']}";
					}
					if (in_array("S", $considerar)){
						$case .= "when x1.tipo = 'S' then ".str_replace(",", ".", $campo_formula['COMISSAO_MAODEOBRA'])." ";
						$casem .= "when x1.tipo = 'S' then {$campo_formula['META_MAODEOBRA']}";
					}
					$case .= " else  0 end pct_comissao";
					$casem .= "else  0 end metadados";
					$metapremio = (isset($campo_formula['META_PREMIO'])) ? ($campo_formula['META_PREMIO'] != "") ? $campo_formula['META_PREMIO'] : 0 : 0;
					return "select {$grupo} grupo, b{$i}.empresa, b{$i}.usuario, b{$i}.nome, b{$i}.tipo tipo_item, b{$i}.mes_referencia,
							b{$i}.ano_referencia, b{$i}.valor_faturado, b{$i}.val_desconto, b{$i}.valor_total, to_char(b{$i}.pct_comissao) pct_comissao,
							b{$i}.metadados, to_char(round((b{$i}.valor_total*b{$i}.pct_comissao)/100,2)) valor_comissao, to_char(0) premio,
							{$metapremio} metapremio, b{$i}.cpf
							from
							(
								select x1.empresa, x2.usuario, x2.nome, x2.cpf, x1.tipo, x1.mes_referencia, x1.ano_referencia,
								to_char(sum(x1.valor_faturado)) valor_faturado, to_char(sum(x1.val_desconto)) val_desconto,
								to_char(sum(x1.valor_faturado)-sum(x1.val_desconto)) valor_total,
								{$case}, {$casem}
								from
								(
									select a1.empresa, a1.revenda, a1.nome, a1.usuario, a1.tipo, a1.departamento, a1.mes_referencia, a1.ano_referencia,
									a1.valor_faturado, nvl(a2.val_desconto,0) val_desconto, a1.valor_faturado-nvl(a2.val_desconto,0) valor_total
									from
									(
										select s1.*
										from
										(
											select m.empresa, m.revenda, m.usuario, m.nome_vendedor nome,  m.tipo, m.departamento,
											to_number(to_char(m.dta_referencia,'mm')) mes_referencia, to_number(to_char(m.dta_referencia,'yyyy')) ano_referencia,
											sum(m.valor_venda) valor_faturado
											from qlik.j_tab_fat_vendedor m
											where m.dta_referencia between
											to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
											and m.empresa||'.'||m.revenda in ('{$empresa}')
											{$equipe}{$departamento}
											and m.tipo in ('{$tipo}')
											group by m.empresa, m.revenda, m.usuario, m.nome_vendedor,
											m.tipo, m.departamento, to_number(to_char(m.dta_referencia,'mm')), to_number(to_char(m.dta_referencia,'yyyy'))
										) s1
									) a1
									left join
									(
										select c.empresa, c.revenda, c.usuario_fat, c.mecanico, c.numero_nota_fiscal, c.serie_nota_fiscal, c.mes_emissao, c.ano_emissao, c.mes_cancelamento, c.ano_cancelamento, c.tipo, c.departamento, c.val_desconto
										from qlik.j_v_cancelamento_nota c
										where c.dta_cancelamento_nota between
										to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
										and c.empresa||'.'||c.revenda in ('{$empresa}')
										and c.tipo in ('{$tipo}')
									) a2
									on ( a1.empresa = a2.empresa and a1.revenda = a2.revenda
									and a1.mes_referencia = a2.mes_cancelamento and a1.ano_referencia = a2.ano_cancelamento
									and a1.tipo = a2.tipo and a1.departamento = a2.departamento and a1.usuario = a2.usuario_fat )
								) x1 cross join (select b1.usuario, b1.nome, b1.cpf from ger_usuario b1 where b1.usuario in ({$vendedor})) x2 group by x1.empresa, x2.usuario, x2.nome, x2.cpf,x1.tipo,x1.mes_referencia, x1.ano_referencia
							) b{$i} union ";
				}
			}elseif ($tip == 3){
				if (($tip == 3) && (in_array("N", $considerar) || in_array("U", $considerar) || in_array("D", $considerar))){
					if ($por == "FAI"){
						
					}elseif ($por == "TIP"){
						$case = "case ";
						$casem = "case ";
						if (in_array("N", $considerar)){
							$case .= "when s1.tipo_item = 'N' then ".str_replace(",", ".", $campo_formula['COMISSAO_NOVOS'])."";
							$casem .= "when k1.tipo_item = 'N' then {$campo_formula['META_NOVOS']}";
						}
						if (in_array("U", $considerar)){
							$case .= "when s1.tipo_item = 'U' then ".str_replace(",", ".", $campo_formula['COMISSAO_USADOS'])."";
							$casem .= "when k1.tipo_item = 'U' then {$campo_formula['META_USADOS']}";
						}
						if (in_array("D", $considerar)){
							$case .= "when s1.tipo_item = 'D' then ".str_replace(",", ".", $campo_formula['COMISSAO_DIRETO'])."";
							$casem .= "when k1.tipo_item = 'D' then {$campo_formula['META_DIRETO']}";
						}
						$casem .= "else  0 end pct_comissao";
						$casem .= "else  0 end metadados";
						$metapremio = (isset($campo_formula['META_PREMIO'])) ? ($campo_formula['META_PREMIO'] != "") ? $campo_formula['META_PREMIO'] : 0 : 0;
						return "select {$grupo} grupo, b{$i}.empresa, b{$i}.usuario, b{$i}.nome, b{$i}.tipo_item, b{$i}.mes_referencia,
								b{$i}.ano_referencia, b{$i}.valor_faturado, b{$i}.val_desconto, b{$i}.valor_total, b{$i}.pct_comissao,
								b{$i}.metadados, b{$i}.valor_comissao, to_char(0) premio, {$metapremio} metapremio, 
								b{$i}.cpf
								from
								(
									select k1.*,
									{$casem},k2.usuario, k2.nome, k2.cpf
									from
									(
										select g1.empresa, g1.tipo_item, g1.mes_referencia, g1.ano_referencia,
										to_char(g1.valor_venda) valor_faturado, to_char(g1.val_desconto) val_desconto, to_char(g1.valor_total) valor_total,
										from
										(
											select x1.empresa, x1.revenda, sum(x1.valor_venda) valor_venda, sum(x1.val_cancelamento) val_desconto, sum(x1.valor_total) valor_total,
											to_char(round((sum(x1.valor_total)*x1.pct_comissao)/100,2)) valor_comissao, x1.pct_comissao, X1.mes_referencia, x1.ano_referencia, x1.tipo_item
											from
											(
												select {$case}, s1.*, nvl(s2.val_cancelamento,0) val_cancelamento, s1.valor_venda-nvl(s2.val_cancelamento,0) valor_total
												from
												(
													select v.empresa, v.revenda, case when v.tipo_item = 'R' then 'U' else v.tipo_item end tipo_item, sum(v.valor_venda)-nvl(sum(dv.valor_dv),0) valor_venda,
													to_number(to_char(v.DTA_ENTRADA_SAIDA,'mm')) mes_referencia, to_number(to_char(v.DTA_ENTRADA_SAIDA,'yyyy')) ano_referencia
													from qlik.j_tab_vendedor_veiculo v
													left join
													(
														select empresa, revenda, proposta, fat_oper, sum(valor_dv) valor_dv
														from qlik.j_v_fiat_dv group by empresa, revenda, proposta, fat_oper
													) dv on v.empresa = dv.empresa and v.revenda = dv.revenda and v.fat_oper = dv.fat_oper and nvl(v.proposta,0) = dv.proposta
													where v.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
													and ( (v.tipo_item in ('N') and v.empresa||'.'||v.revenda in ('{$empresa}') {$equipen}) or
													(v.tipo_item in ('U') and v.empresa||'.'||v.revenda in ('{$empresa}') {$equipeu}) or
													(v.tipo_item in ('D') and v.empresa||'.'||v.revenda in ('{$empresa}') {$equiped}) or
													(v.tipo_item in ('R') and v.empresa||'.'||v.revenda in ('{$empresa}') {$equipeu}) )
													group by  v.empresa, v.revenda, v.tipo_item,
													to_number(to_char(v.DTA_ENTRADA_SAIDA,'mm')), to_number(to_char(v.DTA_ENTRADA_SAIDA,'yyyy'))
												) s1
												left join
												(
													select  cv.empresa, cv.revenda, case when cv.TIPO_ITEM = 'R' then 'U' else cv.TIPO_ITEM end TIPO_ITEM, sum(cv.tot_nota_fiscal) val_cancelamento,
													cv.MES_CANCELAMENTO, cv.ANO_CANCELAMENTO
													from qlik.j_v_cancelamento_nota_veiculo cv
													where cv.dta_cancelamento_nota between to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
													group by cv.empresa, cv.revenda, cv.tipo_item, cv.MES_CANCELAMENTO, cv.ANO_CANCELAMENTO
												) s2 on (s1.empresa = s2.empresa and s1.revenda = s2.revenda and s1.tipo_item = s2.tipo_item and s1.mes_referencia = s2.MES_CANCELAMENTO and s1.ano_referencia = s2.ANO_CANCELAMENTO)
											) x1 group by x1.empresa, x1.revenda, X1.mes_referencia, x1.ano_referencia, x1.tipo_item
										) g1
									) k1
									cross join
									(
										select b1.usuario, b1.nome, b1.cpf from ger_usuario b1 where b1.usuario in ({$vendedor})
									) k2
									where k1.tipo_item in ('{$tipo}')
								) b{$i} union ";
					}
				}else{
					if ($campo_formula["FATURAMENTO"] == "M"){
						$case = "case  ";
						$case .= "when k1.pct_valor between ".str_replace(",", ".", $campo_formula['MARG_DE1'])." and ".str_replace(",", ".", $campo_formula['MARG_ATE1'])." then ".str_replace(",", ".", $campo_formula['MARG_COMISSAO1'])." ";
						$com = $campo_formula['MARG_COMISSAO1'];
						if (isset($campo_formula["MARG_DE2"])){
							$case .= "when k1.pct_valor between ".str_replace(",", ".", $campo_formula['MARG_DE2'])." and ".str_replace(",", ".", $campo_formula['MARG_ATE2'])." then ".str_replace(",", ".", $campo_formula['MARG_COMISSAO2'])." ";
							$com = $campo_formula['MARG_COMISSAO2'];
						}
						if (isset($campo_formula["MARG_DE3"])){
							$case .= "when k1.pct_valor between ".str_replace(",", ".", $campo_formula['MARG_DE3'])." and ".str_replace(",", ".", $campo_formula['MARG_ATE3'])." then ".str_replace(",", ".", $campo_formula['MARG_COMISSAO3'])." ";
							$com = $campo_formula['MARG_COMISSAO3'];
						}
						if (isset($campo_formula["MARG_DE4"])){
							$case .= "when k1.pct_valor between ".str_replace(",", ".", $campo_formula['MARG_DE4'])." and ".str_replace(",", ".", $campo_formula['MARG_ATE4'])." then ".str_replace(",", ".", $campo_formula['MARG_COMISSAO4'])." ";
							$com = $campo_formula['MARG_COMISSAO4'];
						}
						if (isset($campo_formula["MARG_DE5"])){
							$case .= "when k1.pct_valor between ".str_replace(",", ".", $campo_formula['MARG_DE5'])." and ".str_replace(",", ".", $campo_formula['MARG_ATE5'])." then ".str_replace(",", ".", $campo_formula['MARG_COMISSAO5'])." ";
							$com = $campo_formula['MARG_COMISSAO5'];
						}
						$case .= "when k1.pct_valor > 0 then ".str_replace(",", ".", $com)." ";
						
						$casem = "case  ";
						if (in_array("N", $considerar)){
							$casem .= "when k1.tipo_item = 'N' then {$campo_formula['META_NOVOS']} ";
						}
						if (in_array("U", $considerar)){
							$casem .= "when k1.tipo_item = 'U' then {$campo_formula['META_USADOS']} ";
						}
						if (in_array("D", $considerar)){
							$casem .= "when k1.tipo_item = 'D' then {$campo_formula['META_DIRETO']} ";
						}
						if (in_array("C", $considerar)){
							$casem .= "when k1.tipo_item = 'C' then {$campo_formula['META_CONSORCIO']} ";
						}
						if (in_array("P", $considerar)){
							$casem .= "when k1.tipo_item = 'P' then {$campo_formula['META_PECAS']} ";
						}
						if (in_array("S", $considerar)){
							$casem .= "when k1.tipo_item = 'S' then {$campo_formula['META_MAODEOBRA']} ";
						}
						$case .= "else  0 end pct_comissao";
						$casem .= "else  0 end metadados";
						$metapremio = (isset($campo_formula['META_PREMIO'])) ? ($campo_formula['META_PREMIO'] != "") ? $campo_formula['META_PREMIO'] : 0 : 0;
						return	"select {$grupo} grupo, b{$i}.empresa, b{$i}.usuario, b{$i}.nome, b{$i}.tipo_item, b{$i}.mes_referencia, b{$i}.ano_referencia,
								b{$i}.valor_faturado, b{$i}.val_desconto, b{$i}.valor_total, to_char(b{$i}.pct_comissao) pct_comissao, b{$i}.metadados,
								to_char(round((b{$i}.valor_total*b{$i}.pct_comissao)/100,2)) valor_comissao, to_char(0) premio, {$metapremio} metapremio, b{$i}.cpf
								from
								(
									select k1.*,
									{$case}, {$casem}, k2.usuario, k2.nome, k2.cpf
									from
									(
										select v1.empresa, v1.revenda, v1.tipo_item, v1.mes_referencia, v1.ano_referencia, v1.valor_faturado,
									   	v1.val_desconto, v1.valor_total, v1.pct_comissao, round((v1.valor_total*v1.pct_comissao)/100,2) valor_comissao
									   	from
									   	(
									   		select h1.empresa, h1.revenda, h1.tipo_item, (h1.receita-h1.despesa)-nvl(h2.valor,0) valor_faturado, (h1.receita-h1.despesa)-nvl(h2.valor,0) valor_total, 
									     	h1.val_desconto, h1.mes_referencia, h1.ano_referencia,
									     	round((((h1.receita-h1.despesa)-nvl(h2.valor,0))/h1.receita)*100,2) pct_valor, 
									     	case when round((((h1.receita-h1.despesa)-nvl(h2.valor,0))/h1.receita)*100,2) between 20 and 30.9 then 1.5
									        	when round((((h1.receita-h1.despesa)-nvl(h2.valor,0))/h1.receita)*100,2) between 31 and 40 then 2
									          	when round((((h1.receita-h1.despesa)-nvl(h2.valor,0))/h1.receita)*100,2) > 40 then 2.4 else 0 end pct_comissao
									     
									     	from
									     	(  
									       		select g1.empresa, g1.revenda, case when g1.familia = 'Assist�ncia T�cnica' then 'S' when g1.familia = 'Pe�as' then 'P' end tipo_item, 
									       		sum(g1.valor) receita, sum(g2.valor) despesa, 0 val_desconto, 
									      	 	g1.mes_referencia, g2.ano_referencia
									       		from
									       		(
									          		select x1.empresa, x1.revenda, x1.FAMILIA, sum(x1.valor) valor, x1.MES_REFERENCIA, x1.ANO_REFERENCIA
									          		from qlik.j_v_deg_receitas x1
									          		where x1.data between to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy') 
									          		and x1.empresa||'.'||x1.revenda in ('{$empresa}')
									          		group by x1.empresa, x1.revenda, x1.familia, x1.mes_referencia, x1.ano_referencia  
									       		) g1
									       		join    
									       		(   
									          		select x1.empresa, x1.revenda, x1.FAMILIA, sum(x1.valor) valor, x1.MES_REFERENCIA, x1.ANO_REFERENCIA
									          		from qlik.j_v_deg_desp_cust x1
									          		where  x1.data between to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
									         		and x1.empresa||'.'||x1.revenda in ('{$empresa}')
									          		group by x1.empresa, x1.revenda, x1.familia, x1.mes_referencia, x1.ano_referencia  
									       		) g2 on (g1.empresa = g2.empresa and g1.revenda = g2.revenda and g1.familia = g2.familia 
									                and g1.mes_referencia = g1.mes_referencia and g1.ano_referencia = g2.ano_referencia)  
									       		group by g1.empresa, g1.revenda, g1.familia, g1.mes_referencia, g2.ano_referencia 
									     	) h1
										     left join 
										     ( select m.* from qlik.j_v_desp_nivel_3_mes_anteior m 
										       where m.DATA between last_day(add_months(to_date('{$de}','dd/mm/yyyy'),-2))+1
										       and last_day(add_months(to_date('{$ate}','dd/mm/yyyy'),-1))
										     ) h2
									     	on h1.empresa = h2.EMPRESA and h1.REVENDA = h2.REVENDA and h1.tipo_item = h2.tipo_item
									   ) v1 
									) k1
									cross join
									(
										select b1.usuario, b1.nome, b1.cpf from ger_usuario b1 where b1.usuario in ({$vendedor})
									) k2
									where k1.tipo_item in ('{$tipo}')
								) b{$i} union ";
					}elseif ($por == "FAI"){
						$case = "case ";
						if ($auto == "S"){
							$case .= "when k1.valor_total between ".str_replace(",", ".", $campo_formula['FAI_DE1'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE1'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO1'])."";
							$com = $campo_formula['FAI_COMISSAO1'];
							if (isset($campo_formula["FAI_DE2"])){
								$case .= "when k1.valor_total between ".str_replace(",", ".", $campo_formula['FAI_DE2'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE2'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO2'])."";
								$com = $campo_formula['FAI_COMISSAO2'];
							}
							if (isset($campo_formula["FAI_DE3"])){
								$case .= "when k1.valor_total between ".str_replace(",", ".", $campo_formula['FAI_DE3'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE3'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO3'])." ";
								$com = $campo_formula['FAI_COMISSAO3'];
							}
							if (isset($campo_formula["FAI_DE4"])){
								$case .= "when k1.valor_total between ".str_replace(",", ".", $campo_formula['FAI_DE4'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE4'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO4'])." ";
								$com = $campo_formula['FAI_COMISSAO4'];
							}
							if (isset($campo_formula["FAI_DE5"])){
								$case .= "when k1.valor_total between ".str_replace(",", ".", $campo_formula['FAI_DE5'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE5'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO5'])." ";
								$com = $campo_formula['FAI_COMISSAO5'];
							}
							$case .= "when k1.valor_total > 0 then ".str_replace(",", ".", $com)." ";
						}else{
							$case .= "when k1.valor_total between ".str_replace(",", ".", $campo_formula['FAI_DE1'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE1'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO1'])." ";
							$com = $campo_formula['FAI_COMISSAO1'];
							if (isset($campo_formula["FAI_DE2"])){
								$case .= "when k1.valor_total between ".str_replace(",", ".", $campo_formula['FAI_DE2'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE2'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO2'])." ";
								$com = $campo_formula['FAI_COMISSAO2'];
							}
							if (isset($campo_formula["FAI_DE3"])){
								$case .= "when k1.valor_total between ".str_replace(",", ".", $campo_formula['FAI_DE3'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE3'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO3'])." ";
								$com = $campo_formula['FAI_COMISSAO3'];
							}
							if (isset($campo_formula["FAI_DE4"])){
								$case .= "when k1.valor_total between ".str_replace(",", ".", $campo_formula['FAI_DE4'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE4'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO4'])." ";
								$com = $campo_formula['FAI_COMISSAO4'];
							}
							if (isset($campo_formula["FAI_DE5"])){
								$case .= "when k1.valor_total between ".str_replace(",", ".", $campo_formula['FAI_DE5'])." and ".str_replace(",", ".", $campo_formula['FAI_ATE5'])." then ".str_replace(",", ".", $campo_formula['FAI_COMISSAO5'])." ";
								$com = $campo_formula['FAI_COMISSAO5'];
							}
							$case .= "when k1.valor_total > 0 then ".str_replace(",", ".", $com)." ";
						}
						
						$casem = "case  ";
						if (in_array("N", $considerar)){
							$casem .= "when k1.tipo_item = 'N' then {$campo_formula['META_NOVOS']} ";
						}
						if (in_array("U", $considerar)){
							$casem .= "when k1.tipo_item = 'U' then {$campo_formula['META_USADOS']} ";
						}
						if (in_array("D", $considerar)){
							$casem .= "when k1.tipo_item = 'D' then {$campo_formula['META_DIRETO']} ";
						}
						if (in_array("C", $considerar)){
							$casem .= "when k1.tipo_item = 'C' then {$campo_formula['META_CONSORCIO']} ";
						}
						if (in_array("P", $considerar)){
							$casem .= "when k1.tipo_item = 'P' then {$campo_formula['META_PECAS']} ";
						}
						if (in_array("S", $considerar)){
							$casem .= "when k1.tipo_item = 'S' then {$campo_formula['META_MAODEOBRA']} ";
						}
						$case .= "else  0 end pct_comissao";
						$casem .= "else  0 end metadados";
						$metapremio = (isset($campo_formula['META_PREMIO'])) ? ($campo_formula['META_PREMIO'] != "") ? $campo_formula['META_PREMIO'] : 0 : 0;
						return "select {$grupo} grupo, b{$i}.empresa, b{$i}.usuario, b{$i}.nome, b{$i}.tipo_item, b{$i}.mes_referencia, b{$i}.ano_referencia,
								b{$i}.valor_faturado, b{$i}.val_desconto, b{$i}.valor_total, to_char(b{$i}.pct_comissao) pct_comissao, b{$i}.metadados,
								to_char(round((b{$i}.valor_total*b{$i}.pct_comissao)/100,2)) valor_comissao, to_char(0), {$metapremio} metapremio, b{$i}.cpf
								from
								(
									select k1.*,
									{$case}, {$casem}, k2.usuario, k2.nome, k2.cpf
									from
									(
										select g1.empresa, g1.tipo_item,
										to_char(sum(g1.valor)-sum(g2.valor)) valor_faturado, to_char(0) val_desconto,
										to_char(sum(g1.valor)-sum(g2.valor)) valor_total,
										round(((sum(g1.valor)-sum(g2.valor))/sum(g1.valor))*100,2) pct_valor,
										g1.mes_referencia, g2.ano_referencia
										from
										(
											select x1.empresa, x1.revenda, x1.familia, case when x1.familia = 'Assist�ncia T�cnica' then 'S' when x1.familia = 'Pe�as' then 'P' end tipo_item,
											sum(x1.valor) valor, x1.MES_REFERENCIA, x1.ANO_REFERENCIA
											from qlik.j_v_deg_receitas x1
											where x1.data between
											to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
											and x1.empresa||'.'||x1.revenda in ('{$empresa}')
											group by x1.empresa, x1.revenda, x1.familia,x1.mes_referencia, x1.ano_referencia
										) g1
										join
										(
											select x1.empresa, x1.revenda, x1.FAMILIA, sum(x1.valor) valor, x1.MES_REFERENCIA, x1.ANO_REFERENCIA
											from qlik.j_v_deg_desp_cust x1
											where  x1.data between
											to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
											and x1.empresa||'.'||x1.revenda in ('{$empresa}')
											group by x1.empresa, x1.revenda, x1.familia, x1.mes_referencia, x1.ano_referencia
										) g2
										on (g1.empresa = g2.empresa and g1.revenda = g2.revenda and g1.familia = g2.familia
										and g1.mes_referencia = g1.mes_referencia and g1.ano_referencia = g2.ano_referencia)
										group by g1.empresa, g1.tipo_item, g1.mes_referencia, g2.ano_referencia
									) k1
									cross join
									(
										select b1.usuario, b1.nome, b1.cpf from ger_usuario b1 where b1.usuario in ({$vendedor})
									) k2
									where k1.tipo_item in ('{$tipo}')
								) b{$i} union ";
					}elseif ($por == "TIP"){
						$case = "case  ";
						$casem = "case  ";
						if (in_array("N", $considerar)){
							$case .= "when k1.tipo_item = 'N' then ".str_replace(",", ".", $campo_formula['COMISSAO_NOVOS'])."";
							$casem .= "when k1.tipo_item = 'N' then {$campo_formula['META_NOVOS']}";
						}
						if (in_array("U", $considerar)){
							$case .= "when k1.tipo_item = 'U' then ".str_replace(",", ".", $campo_formula['COMISSAO_USADOS'])."";
							$casem .= "when k1.tipo_item = 'U' then {$campo_formula['META_USADOS']}";
						}
						if (in_array("D", $considerar)){
							$case .= "when k1.tipo_item = 'D' then ".str_replace(",", ".", $campo_formula['COMISSAO_DIRETO'])." ";
							$casem .= "when k1.tipo_item = 'D' then {$campo_formula['META_DIRETO']}";
						}
						if (in_array("C", $considerar)){
							$case .= "when k1.tipo_item = 'C' then ".str_replace(",", ".", $campo_formula['COMISSAO_CONSORCIO'])."";
							$casem .= "when k1.tipo_item = 'C' then {$campo_formula['META_CONSORCIO']}";
						}
						if (in_array("P", $considerar)){
							$case .= "when k1.tipo_item = 'P' then ".str_replace(",", ".", $campo_formula['COMISSAO_PECAS'])."";
							$casem .= "when k1.tipo_item = 'P' then {$campo_formula['META_PECAS']}";
						}
						if (in_array("S", $considerar)){
							$case .= "when k1.tipo_item = 'S' then ".str_replace(",", ".", $campo_formula['COMISSAO_MAODEOBRA'])."";
							$casem .= "when k1.tipo_item = 'S' then {$campo_formula['META_MAODEOBRA']}";
						}
						$case .= "else  0 end pct_comissao";
						$casem .= "else  0 end metadados ";
						$metapremio = (isset($campo_formula['META_PREMIO'])) ? ($campo_formula['META_PREMIO'] != "") ? $campo_formula['META_PREMIO'] : 0 : 0;
						return "select {$grupo} grupo, b{$i}.empresa, b{$i}.usuario, b{$i}.nome, b{$i}.tipo_item, b{$i}.mes_referencia, b{$i}.ano_referencia,
								b{$i}.valor_faturado, b{$i}.val_desconto, b{$i}.valor_total, to_char(b{$i}.pct_comissao) pct_comissao, b{$i}.metadados,
								to_char(round((b{$i}.valor_total*b{$i}.pct_comissao)/100,2)) valor_comissao, to_char(0) premio, {$metapremio} metapremio, b{$i}.cpf
								from
								(
									select k1.*,
									{$case}, {$casem}, k2.usuario, k2.nome, k2.cpf
									from
									(
										select g1.empresa, g1.tipo_item,
										to_char(sum(g1.valor)-sum(g2.valor)) valor_faturado, to_char(0) val_desconto,
										to_char(sum(g1.valor)-sum(g2.valor)) valor_total,
										round(((sum(g1.valor)-sum(g2.valor))/sum(g1.valor))*100,2) pct_valor,
										g1.mes_referencia, g2.ano_referencia
										from
										(
											select x1.empresa, x1.revenda, x1.familia, case when x1.familia = 'Assist�ncia T�cnica' then 'S' when x1.familia = 'Pe�as' then 'P' end tipo_item,
											sum(x1.valor) valor, x1.MES_REFERENCIA, x1.ANO_REFERENCIA
											from qlik.j_v_deg_receitas x1
											where x1.data between
											to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
											and x1.empresa||'.'||x1.revenda in ('{$empresa}')
											group by x1.empresa, x1.revenda, x1.familia,x1.mes_referencia, x1.ano_referencia
										) g1
										join
										(
											select x1.empresa, x1.revenda, x1.FAMILIA, sum(x1.valor) valor, x1.MES_REFERENCIA, x1.ANO_REFERENCIA
											from qlik.j_v_deg_desp_cust x1
											where  x1.data between
											to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
											and x1.empresa||'.'||x1.revenda in ('{$empresa}')
											group by x1.empresa, x1.revenda, x1.familia, x1.mes_referencia, x1.ano_referencia
										) g2
										on (g1.empresa = g2.empresa and g1.revenda = g2.revenda and g1.familia = g2.familia
										and g1.mes_referencia = g1.mes_referencia and g1.ano_referencia = g2.ano_referencia)
										group by g1.empresa, g1.tipo_item, g1.mes_referencia, g2.ano_referencia
									) k1
									cross join
									(
										select b1.usuario, b1.nome, b1.cpf from ger_usuario b1 where b1.usuario in ({$vendedor})
									) k2
									where k1.tipo_item in ('{$tipo}')
								) b{$i} union ";
					}
				}
			}elseif ($tip == 8){
				if ($por == "FAI"){
					
				}elseif ($por == "TIP"){
					$casem = "case  ";
					if (in_array("N", $considerar)){
						$casem .= "when k1.tipo_item = 'N' then {$campo_formula['META_NOVOS']}";
					}
					if (in_array("U", $considerar)){
						$casem .= "when k1.tipo_item = 'U' then {$campo_formula['META_USADOS']}";
					}
					if (in_array("U", $considerar)){
						$casem .= "when k1.tipo_item = 'D' then {$campo_formula['META_DIRETO']}";
					}
					$casem .= "else  0 end metadados";
					$metapremio = (isset($campo_formula['META_PREMIO'])) ? ($campo_formula['META_PREMIO'] != "") ? $campo_formula['META_PREMIO'] : 0 : 0;
					return "select {$grupo} grupo, b{$i}.empresa, b{$i}.usuario, b{$i}.nome, b{$i}.tipo_item, b{$i}.mes_referencia, b{$i}.ano_referencia,
							b{$i}.valor_faturado, b{$i}.val_desconto, b{$i}.valor_total, b{$i}.pct_comissao, b{$i}.metadados,
							b{$i}.valor_comissao, to_char(0) premio, {$metapremio} metapremio, b{$i}.cpf
							from
							(
								select x1.empresa, x1.revenda, x2.nome, x2.cpf, x1.tipo_item, x1.mes_referencia, x1.ano_referencia,
								to_char(x1.val_p_contrato) valor_faturado,
								to_char(x1.valor_p_contrato_cancelado) val_desconto,
								to_char(x1.valor_p_contrato) valor_total,
								to_char(0) pct_comissao, {$casem},
								to_char(x1.valor_p_contrato) valor_comissao
								from
								(
									select s1.empresa, s1.revenda, s1.tipo_item, s1.mes_referencia, s1.ano_referencia,
									s1.val_p_contrato, nvl(s2.valor_p_contrato_cancelado,0) valor_p_contrato_cancelado,
									s1.val_p_contrato-nvl(s2.valor_p_contrato_cancelado,0) valor_p_contrato
									from
									(
										select c1.empresa, c1.revenda, c1.tipo_item, to_number(to_char(c1.DTA_ENTRADA_SAIDA,'mm')) mes_referencia, to_number(to_char(c1.DTA_ENTRADA_SAIDA,'yyyy')) ano_referencia,
										sum(nvl(c1.valor_p_contrato,2)) val_p_contrato
										from qlik.j_v_operador_FeI_NDU_fiat  c1
										where c1.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
										and c1.empresa||'.'||c1.revenda in ('{$empresa}')
										group by c1.empresa, c1.revenda, c1.tipo_item,
										to_number(to_char(c1.DTA_ENTRADA_SAIDA,'mm')), to_number(to_char(c1.DTA_ENTRADA_SAIDA,'yyyy'))
									) s1
									left join
									(
										select cv.empresa, cv.revenda, cv.TIPO_ITEM, sum(cv.tot_nota_fiscal) val_cancelamento,
										sum(nvl(cv.valor_financiado,0)) valor_financiado_cancelado, sum(nvl2(cv.valor_financiado,18,0)) valor_p_contrato_cancelado, sum(nvl(cv.valor_acessorio_financiado,0)) valor_acess_finan_cancelado
										from qlik.j_v_cancelamento_nota_veiculo cv
										where cv.TIPO_ITEM in ('{$tipo}')
										and cv.dta_cancelamento_nota between to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
										group by cv.empresa, cv.revenda, cv.tipo_transacao,  cv.TIPO_ITEM
									) s2 on (s1.empresa = s2.empresa and s1.revenda = s2.revenda and s1.tipo_item = s2.tipo_item)
								) x1 cross join (select b1.usuario, b1.nome, b1.cpf from ger_usuario b1 where b1.usuario in ({$vendedor})) x2 group by x1.empresa, x2.usuario, x2.nome, x2.cpf,x1.tipo,x1.mes_referencia, x1.ano_referencia
							) b{$i} union ";
				}
			}elseif ($tip == 9){
				if ($por == "FAI"){
					
				}elseif ($por == "TIP"){
					$casem = "case  ";
					if (in_array("U", $considerar)){
						$casem .= "when g1.tipo_item = 'U' then {$campo_formula['META_USADOS']}";
					}
					$casem .= "else  0 end metadados";
					$metapremio = (isset($campo_formula['META_PREMIO'])) ? ($campo_formula['META_PREMIO'] != "") ? $campo_formula['META_PREMIO'] : 0 : 0;
					return "select b{$i}.grupo, b{$i}.empresa, b1.usuario, b{$i}.nome, b{$i}.tipo_item, b{$i}.mes_referencia, b{$i}.ano_referencia, to_char(sum(b{$i}.valor_faturado)) valor_faturado, 
							to_char(sum(b{$i}.val_desconto)) val_desconto, to_char(sum(b{$i}.valor_total)) valor_total, to_char(sum(b{$i}.pct_comissao)) pct_comissao, b{$i}.metadados, to_char(sum(b{$i}.valor_comissao)) valor_comissao,
							to_char(sum(b{$i}.premio)) premio, b{$i}.metapremio, b{$i}.cpf   
							from
							(
								select {$grupo} grupo, b{$i}.*
								from
								(
									select g1.empresa, g1.avaliador usuario, g1.nome_avaliador nome, g1.tipo_item, g1.mes_referencia, g1.ano_referencia,
									to_char(g1.valor_saida) valor_faturado,
									to_char(g1.val_p_saida_cancelado) val_desconto, to_char(g1.valor_total_saida) valor_total, to_char(0) pct_comissao, {$casem},
									to_char(g1.valor_total_saida) valor_comissao, to_char(0) premio, {$metapremio} metapremio, g1.cpf
									from
									(
										select x1.empresa, x1.revenda, x1.avaliador, x1.nome_avaliador, x1.tipo_item, sum(x1.valor_saida) valor_saida,
										sum(x1.val_p_saida_cancelado) val_p_saida_cancelado, sum(x1.valor_total_saida) valor_total_saida,
										x1.mes_referencia, x1.ano_referencia, u.cpf
										from
										(
											select s1.*, nvl(s2.val_p_saida_cancelado,0) val_p_saida_cancelado,
											s1.valor_saida-nvl(s2.val_p_saida_cancelado,0) valor_total_saida
											from
											(
												select v.empresa, v.revenda, v.vendedor, ss1.avaliador, ss1.nome nome_avaliador, 'U' tipo_item, sum(ss1.valor_saida) valor_saida,
												to_number(to_char(v.DTA_ENTRADA_SAIDA,'mm')) mes_referencia, to_number(to_char(v.DTA_ENTRADA_SAIDA,'yyyy')) ano_referencia
												from qlik.j_tab_vendedor_veiculo v
												join
												(
													select s1.*, 100 valor_saida, av.avaliador, av.usuario, av.nome
													from
													(
														select distinct ve.empresa, ve.revenda, ve.veiculo, vi.chassi
														from cnp.fat_movimento_veiculo ve
														join cnp.fat_movimento_capa fc
														on ve.EMPRESA = fc.empresa and ve.REVENDA = fc.revenda and ve.NUMERO_NOTA_FISCAL = fc.numero_nota_fiscal and
														ve.SERIE_NOTA_FISCAL = fc.serie_nota_fiscal and ve.TIPO_TRANSACAO = fc.tipo_transacao and ve.CONTADOR = fc.contador
														join cnp.vei_veiculo vi on ve.empresa = vi.empresa and ve.veiculo = vi.veiculo
														where ve.tipo_transacao = 'U21'
														and ve.empresa||'.'||ve.revenda in ('{$empresa}')
														and fc.dta_entrada_saida between to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
													) s1
													join
													(
														select ve.empresa, ve.revenda, ve.veiculo, vi.chassi
														from cnp.fat_movimento_veiculo ve
														join cnp.vei_veiculo vi on ve.empresa = vi.empresa and ve.veiculo = vi.veiculo
														where ve.tipo_transacao = 'U01'
														and ve.empresa||'.'||ve.revenda in ('{$empresa}')
													) s2
													on s1.chassi = s2.chassi and s1.veiculo = s2.veiculo
													join
													(
														select av0.chassi, max(av0.dta_avaliacao) dta_avaliacao, av0.avaliador,  u.usuario, u.nome
														from cnp.vei_avaliacao av0 join cnp.ger_usuario u on av0.avaliador = u.usuario
														group by av0.chassi, av0.avaliador,  u.usuario, u.nome
													) av on s1.chassi = av.chassi
												) ss1 on ss1.empresa = v.empresa and ss1.revenda = v.revenda and v.veiculo =  ss1.veiculo
												where v.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
												and v.tipo_transacao = 'U21'
												and v.empresa||'.'||v.revenda in ('{$empresa}')
												group by v.empresa, v.revenda, v.vendedor, v.tipo_item,  ss1.avaliador, ss1.nome,
												to_number(to_char(v.DTA_ENTRADA_SAIDA,'mm')), to_number(to_char(v.DTA_ENTRADA_SAIDA,'yyyy'))
											) s1
											left join
											(
												select cv.empresa, cv.revenda, cv.usuario_fat, cv.tipo_item, sum(cv.val_p_saida) val_p_saida_cancelado
												from qlik.j_v_cancelamento_nota_veiculo cv
												where cv.dta_cancelamento_nota between to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
												group by cv.empresa, cv.revenda, cv.usuario_fat, cv.tipo_transacao, cv.tipo_item
											) s2 on (s1.empresa = s2.empresa and s1.revenda = s2.revenda and s1.vendedor = s2.usuario_fat and s1.tipo_item = s2.tipo_item)	
										) x1 left join cnp.ger_usuario u on x1.avaliador = u.usuario
										group by x1.empresa, x1.revenda, x1.avaliador, x1.nome_avaliador, x1.tipo_item, x1.mes_referencia, x1.ano_referencia, u.cpf
									) g1
									
									union all
									
									select g1.empresa, g1.avaliador usuario, g1.nome_avaliador nome, g1.tipo_item, g1.mes_referencia, g1.ano_referencia, to_char(g1.valor_total_entrada) valor_faturado,
									to_char(0) val_desconto, to_char(g1.valor_total_entrada) valor_total, to_char(0) pct_comissao, {$casem}, to_char(g1.valor_total_entrada) valor_comissao, to_char(0) premio, {$metapremio} metapremio, g1.cpf
									from
									(
										select x1.empresa, x1.revenda, x1.avaliador, x1.nome_avaliador, x1.tipo_item, sum(x1.valor_total_entrada) valor_total_entrada,
										sum(0) val_p_saida_cancelado,
										x1.mes_referencia, x1.ano_referencia, u.cpf
										from
										(
											select s1.empresa, s1.revenda, s1.avaliador, s1.nome nome_avaliador, 'U' tipo_item, s1.valor_entrada valor_total_entrada, s1.dta_entrada,
											to_number(to_char(s1.dta_entrada,'mm')) mes_referencia, to_number(to_char(s1.dta_entrada,'yyyy')) ano_referencia
											from
											(
												select s2.empresa, s2.revenda, s1.*, s2.dta_entrada, s2.veiculo, 100 valor_entrada
												from
												(
													select ve.empresa, ve.revenda, ve.veiculo, vi.chassi, vi.dta_entrada
													from cnp.fat_movimento_veiculo ve
													join cnp.vei_veiculo vi on ve.empresa = vi.empresa and ve.veiculo = vi.veiculo
													where ve.tipo_transacao = 'U01'
													and ve.empresa||'.'||ve.revenda in ('{$empresa}')
													and vi.dta_entrada between to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
												) s2
												join
												(
													select av0.chassi, max(av0.dta_avaliacao) dta_avaliacao, av0.avaliador,  u.usuario, u.nome
													from cnp.vei_avaliacao av0 join cnp.ger_usuario u on av0.avaliador = u.usuario
													group by av0.chassi, av0.avaliador,  u.usuario, u.nome
												) s1
												on s1.chassi = s2.chassi
											) s1
										) x1 left join cnp.ger_usuario u on x1.avaliador = u.usuario
										group by x1.empresa, x1.revenda, x1.avaliador, x1.nome_avaliador, x1.tipo_item, x1.mes_referencia, x1.ano_referencia, u.cpf
									) g1
	'							) b{$i} where b{$i}.usuario in('{$vendedor}')
							) b{$i} group by b{$i}.grupo, b{$i}.empresa, b{$i}.usuario, b{$i}.nome, b{$i}.tipo_item, b{$i}.mes_referencia, b{$i}.ano_referencia, b{$i}.metadados, b{$i}.metapremio, b{$i}.cpf union ";
				}
			}elseif ($tip == 10){
				if ($por == "FAI"){
					
				}elseif ($por == "TIP"){
					$casem = "case  ";
					if (in_array("U", $considerar)){
						$casem .= "when s1.tipo_item = 'U' then {$campo_formula['META_USADOS']}";
					}
					$casem .= "else  0 end metadados";
					$metapremio = (isset($campo_formula['META_PREMIO'])) ? ($campo_formula['META_PREMIO'] != "") ? $campo_formula['META_PREMIO'] : 0 : 0;
					return "select {$grupo} grupo, b{$i}.*
							from
							(
								select s1.empresa, s1.usuario, s1.nome, s1.tipo_item, s1.mes_referencia, s1.ano_referencia, to_char(s1.valor_lucro) valor_faturado,
								to_char(nvl(s2.valor_lucro_cancelado,0)) val_desconto, to_char(s1.valor_lucro-nvl(s2.valor_lucro_cancelado,0)) valor_total, to_char(10) pct_comissao,
								{$casem},
								to_char(round(((s1.valor_lucro-nvl(s2.valor_lucro_cancelado,0))*10)/100,2)) valor_comissao, to_char(0) premio, {$metapremio} metapremio, u.cpf
								from
								(
									select a1.empresa, a1.revenda, a1.vendedor usuario, a1.nome_vendedor nome, 'U' tipo_item, sum(a1.valor_venda), sum(a1.valor_custo_contabil),
									sum(a1.valor_lucro) valor_lucro,
									to_number(to_char(a1.DTA_ENTRADA_SAIDA,'mm')) mes_referencia,  to_number(to_char(a1.DTA_ENTRADA_SAIDA,'yyyy')) ano_referencia
									from
									(
										select v.*, c.icms, c.pis_cofins,
										case when v.valor_venda-(v.valor_custo_contabil+(round((valor_venda*c.icms)/100,2))+(round(((v.valor_venda-v.valor_custo_contabil)*c.pis_cofins)/100,2))) < 0 then 0
										else v.valor_venda-(v.valor_custo_contabil+(round((valor_venda*c.icms)/100,2))+(round(((v.valor_venda-v.valor_custo_contabil)*c.pis_cofins)/100,2))) end valor_lucro
										from qlik.j_tab_vendedor_veiculo v
										left join qlik.j_v_repasse_icms_pis_cofins c on v.empresa = c.empresa
										where v.empresa||'.'||v.revenda in ('{$empresa}')
										and v.tipo_item = 'R'
										and v.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
									) a1 group by a1.empresa, a1.revenda, a1.vendedor, a1.nome_vendedor, a1.tipo_item,
									to_number(to_char(a1.DTA_ENTRADA_SAIDA,'mm')),  to_number(to_char(a1.DTA_ENTRADA_SAIDA,'yyyy'))
								) s1
								left join
								(
									select cv0.empresa, cv0.revenda, cv0.usuario_fat, cv0.tipo_item, sum(cv0.val_cancelamento) val_cancelamento,
									sum(cv0.valor_lucro_cancelado) valor_lucro_cancelado
									from
									(
										select cv.empresa, cv.revenda, cv.usuario_fat, cv.tipo_item, cv.tipo_transacao, cv.tot_nota_fiscal val_cancelamento,
										cv.valor_financiado valor_financiado_cancelado, cv.val_retorno_financ val_retorno_financ, cv.VALOR_CUSTO_CONTABIL, nvl(c.icms,0), nvl(c.pis_cofins,0),
										case when cv.tot_nota_fiscal-(cv.valor_custo_contabil+(round((cv.TOT_NOTA_FISCAL*nvl(c.icms,0))/100,2))+(round(((cv.TOT_NOTA_FISCAL-cv.valor_custo_contabil)*nvl(c.pis_cofins,0))/100,2))) < 0 then 0
										else cv.TOT_NOTA_FISCAL-(cv.valor_custo_contabil+(round((cv.TOT_NOTA_FISCAL*nvl(c.icms,0))/100,2))+(round(((cv.TOT_NOTA_FISCAL-cv.valor_custo_contabil)*nvl(c.pis_cofins,0))/100,2))) end valor_lucro_cancelado
										from qlik.j_v_cancelamento_nota_veiculo cv
										left join qlik.j_v_repasse_icms_pis_cofins c on cv.empresa = c.empresa
										where cv.dta_cancelamento_nota between to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
									) cv0 group by cv0.empresa, cv0.revenda, cv0.usuario_fat, cv0.tipo_item
								) s2 on (s1.empresa = s2.empresa and s1.revenda = s2.revenda and s1.usuario = s2.usuario_fat and s1.tipo_item = s2.tipo_item)
								left join cnp.ger_usuario u on s1.usuario = u.usuario
							)b{$i} where b{$i}.usuario in('{$vendedor}') union ";
				}
			}elseif ($tip == 11){
				if ($por == "FAI"){
					
				}elseif ($por == "TIP"){
					$case = "case  ";
					$casem = "case  ";
					if (in_array("N", $considerar)){
						$case .= "when x1.tipo_item = 'N' then ".str_replace(",", ".", $campo_formula['COMISSAO_NOVOS'])."";
						$casem .= "when x1.tipo_item = 'N' then {$campo_formula['META_NOVOS']}";
					}
					if (in_array("U", $considerar)){
						$case .= "when x1.tipo_item = 'U' then ".str_replace(",", ".", $campo_formula['COMISSAO_USADOS'])."";
						$casem .= "when x1.tipo_item = 'U' then {$campo_formula['META_USADOS']}";
					}
					if (in_array("D", $considerar)){
						$case .= "when x1.tipo_item = 'D' then ".str_replace(",", ".", $campo_formula['COMISSAO_DIRETO'])." ";
						$casem .= "when x1.tipo_item = 'D' then {$campo_formula['META_DIRETO']}";
					}
					if (in_array("C", $considerar)){
						$case .= "when x1.tipo_item = 'C' then ".str_replace(",", ".", $campo_formula['COMISSAO_CONSORCIO'])." ";
						$casem .= "when x1.tipo_item = 'C' then {$campo_formula['META_CONSORCIO']}";
					}
					if (in_array("P", $considerar)){
						$case .= "when x1.tipo_item = 'P' then ".str_replace(",", ".", $campo_formula['COMISSAO_PECAS'])." ";
						$casem .= "when x1.tipo_item = 'P' then {$campo_formula['META_PECAS']}";
					}
					if (in_array("S", $considerar)){
						$case .= "when x1.tipo_item = 'S' then ".str_replace(",", ".", $campo_formula['COMISSAO_MAODEOBRA'])." ";
						$casem .= "when x1.tipo_item = 'S' then {$campo_formula['META_MAODEOBRA']}";
					}
					$case .= " else  0 end pct_comissao";
					$casem .= "else  0 end metadados";
					$metapremio = (isset($campo_formula['META_PREMIO'])) ? ($campo_formula['META_PREMIO'] != "") ? $campo_formula['META_PREMIO'] : 0 : 0;
					return "select {$grupo} grupo, b{$i}.empresa, b{$i}.usuario, b{$i}.nome, b{$i}.tipo_item, b{$i}.mes_referencia,
					b{$i}.ano_referencia, b{$i}.valor_faturado, b{$i}.val_desconto, b{$i}.valor_total, to_char(b{$i}.pct_comissao) pct_comissao,
					b{$i}.metadados, to_char(round((b{$i}.valor_total*b{$i}.pct_comissao)/100,2)) valor_comissao, to_char(0) premio,
					{$metapremio} metapremio, b{$i}.cpf
					from
					(
						select x1.empresa, x1.revenda, x2.nome, x2.cpf, x1.tipo_item, x1.mes_referencia, x1.ano_referencia,
						x1.valor_total_financiado valor_faturado,
						x1.valor_financiado_cancelado val_desconto,
						x1.valor_total_financiado valor_total,
						{$case}, {$casem}
						from
						(
							select s1.empresa, s1.revenda, s1.tipo_item, s1.mes_referencia, s1.ano_referencia,
							s1.valor_financiado, nvl(s2.valor_financiado_cancelado,0) valor_financiado_cancelado,
							s1.valor_financiado-nvl(s2.valor_financiado_cancelado,0) valor_total_financiado
							from
							(
								select c1.empresa, c1.revenda, c1.tipo_item, to_number(to_char(c1.DTA_ENTRADA_SAIDA,'mm')) mes_referencia, to_number(to_char(c1.DTA_ENTRADA_SAIDA,'yyyy')) ano_referencia,
								sum(nvl(c1.valor_financiado,2)) valor_financiado
								from qlik.v_j_cordenador_FI_Fiat  c1
								where c1.DTA_ENTRADA_SAIDA between TO_DATE('{$de}','dd/mm/yyyy') and TO_DATE('{$ate}','dd/mm/yyyy')
								and c1.empresa||'.'||c1.revenda in ('{$empresa}')
								group by c1.empresa, c1.revenda, c1.tipo_item,
								to_number(to_char(c1.DTA_ENTRADA_SAIDA,'mm')), to_number(to_char(c1.DTA_ENTRADA_SAIDA,'yyyy'))
							) s1
							left join
							(
								select cv.empresa, cv.revenda, cv.TIPO_ITEM, sum(nvl(cv.valor_financiado,0)) valor_financiado_cancelado
								from qlik.j_v_cancelamento_nota_veiculo cv
								where cv.dta_cancelamento_nota between to_date('{$de}','dd/mm/yyyy') and to_date('{$ate}','dd/mm/yyyy')
								group by cv.empresa, cv.revenda, cv.tipo_transacao,  cv.TIPO_ITEM
							) s2 on (s1.empresa = s2.empresa and s1.revenda = s2.revenda and s1.tipo_item = s2.tipo_item)
						) x1 cross join (select b1.usuario, b1.nome, b1.cpf from ger_usuario b1 where b1.usuario in ({$vendedor})) x2 group by x1.empresa, x2.usuario, x2.nome, x2.cpf,x1.tipo,x1.mes_referencia, x1.ano_referencia
					) b{$i} union ";
				}
			}
		}
	}
}