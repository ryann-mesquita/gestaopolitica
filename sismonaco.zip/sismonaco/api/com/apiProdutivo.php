<?php

namespace api\com;

use lib\Model;
use obj\com\Produtivo;
use helper\PrepareSQL;
use helper\Funcoes;
use obj\com\Parametros;

class apiProdutivo extends Model {
	
	public function getProdutivo(Produtivo $obj) {
		return  $this->First($this->Select("SELECT * FROM com_produtivo WHERE empresa = '{$obj->empresa}' and revenda = '{$obj->revenda}'"));
	}
	
	public function getParametrosBD($empresa, $revenda, $ano = NULL, $mes = NULL){
		if ($ano != NULL){
			$cond = "and p.ano = '{$ano}' and p.mes = '{$mes}' ";
		}else{
			$cond = "";
		}
		return $this->Select("select * from com_parametros p where p.empresa = '{$empresa}' and p.revenda = '{$revenda}' {$cond}
		order by p.empresa, p.revenda, p.ano desc, p.mes desc ");
	}
	
	public function addProdutivo(Produtivo $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'com_produtivo');
	}
	
	public function addParametros(Parametros $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'com_parametros');
	}
	
	public function editProdutivo(Produtivo $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'empresa' && $v != 'revenda';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('empresa' => $obj['empresa'], 'revenda' => $obj['revenda']), 'com_produtivo');
	}
	
	public function editParametros(Parametros $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'empresa' && $v != 'revenda' && $v != 'mes' && $v != 'ano';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('empresa' => $obj['empresa'], 'revenda' => $obj['revenda'], 'mes' => $obj['mes'], 'ano' =>$obj['ano']), 'com_parametros');	
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}