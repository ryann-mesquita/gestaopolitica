<?php

namespace api\gpj;

use lib\Model;
use obj\gpj\Movimento;
use helper\PrepareSQL;
use helper\Funcoes;
use obj\gpj\Processo;

class apiMovimento extends Model {
	
	public function getMovimento(Movimento $obj) {
		return  $this->First($this->Select("SELECT m.movimento, m.processo, m.tipo, t.des_tipo, m.des_movimento, m.usuario, 
		u.nome, m.dta_movimento, p.n_processo, p.ativo
		FROM gpj_movimento m
		JOIN gpj_tipo t ON m.tipo = t.tipo
		JOIN gpj_processo p ON m.processo = p.processo
		LEFT JOIN sis_usuario u ON m.preposto = u.usuario WHERE m.movimento = '{$obj->movimento}'"));
	}
	
	public function filtroMovimento($c, $a, $coluna = NULL, $val = NULL) {
		$funcoes = new Funcoes();
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		$condicao = array(
			'1'	=> " WHERE LOWER({$coluna}) = '{$val}' ",
			'2' => " WHERE LOWER({$coluna}) LIKE '%{$val}%' ",
			'3'	=> " ",
		);
		$ativo = array(
			'1' => "AND ativo = '1' ",
			'2' => "AND ativo = '0' ",
			'3' => "",
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT m.movimento, m.processo, m.tipo, t.des_tipo, m.des_movimento, m.usuario, u.nome, m.dta_movimento, 
		p.n_processo, p.ativo
		FROM gpj_movimento m
		JOIN gpj_tipo t ON m.tipo = t.tipo
		JOIN gpj_processo p ON m.processo = p.processo
		LEFT JOIN sis_usuario u ON m.usuario = u.usuario{$condicao[$c]}{$ativo[$a]}ORDER BY to_date(m.dta_movimento , 'dd/mm/yyyy hh24:mi:ss') DESC) R ) R2");
	}
	
	public function addMovimento(Movimento $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'gpj_movimento','movimento');
	}
	
	public function delMovimento(Movimento $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('movimento' => $obj->movimento), 'gpj_movimento');
	}
	
	public function delMovimentoprocesso(Processo $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('processo' => $obj->processo), 'gpj_movimento');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}