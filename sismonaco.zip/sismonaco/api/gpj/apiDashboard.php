<?php
namespace api\gpj;

use lib\Model;

class apiDashboard extends Model{
	
	public function getDashboard($empresa, $natureza, $departamento, $dashboard, $de, $ate){
		
		if ($dashboard == "agenda"){
			return $this->Select("SELECT R2.*
		    FROM (select ge.empresa||'.'||ge.revenda||' - '||e.razao_social empresa, p.n_processo, 
			v.des_vara vara, n.des_natureza natureza, c.des_cidade, p.nome_reclamante reclamante, dta_proxima_acao, 
			p.preposto, s.des_status, CASE WHEN p.terceiro = 'N' 
			THEN (SELECT u.departamento FROM sis_usuario u WHERE u.cpf = p.reclamante)
			ELSE r.departamento END departamento,
			CASE WHEN p.terceiro = 'N' 
			THEN (SELECT d.des_departamento FROM sis_usuario u JOIN sis_departamento d ON 
			u.departamento = d.departamento WHERE u.cpf = p.reclamante)
			ELSE d.des_departamento END des_departamento 
			from  gpj_processo p
			join gpj_vara v on p.vara = v.vara
			join gpj_natureza n on p.natureza = n.natureza
			join gpj_cidade c on p.cidade = c.cidade
			join gpj_status s on p.status = s.status
			join sis_empresa e on p.empresa = e.empresa
			join ger_revenda ge on e.cnpj = ge.cnpj
            left join gpj_reclamante r ON p.reclamante = r.reclamante
			left join sis_departamento d ON r.departamento = d.departamento
			where e.empresa in ('{$empresa}') and p.natureza in ('{$natureza}') and 
			to_date(to_char(to_date(p.dta_proxima_acao,'dd/mm/yyyy hh24:mi:ss'), 'dd/mm/yyyy'),'dd/mm/yyyy') 
			between '{$de}' and '{$ate}' 
			order by to_date(p.dta_proxima_acao,'dd/mm/yyyy hh24:mi:ss') asc) R2 WHERE r2.departamento in('{$departamento}')");
			
		}elseif ($dashboard == "acoes"){
			return $this->Select("SELECT R2.*
		    FROM (SELECT rownum n_linha, R.*
		    FROM(select e.empresa, ge.empresa||'.'||ge.revenda||' - '||e.razao_social razao_social, p.n_processo, P.terceiro, 
			n.des_natureza natureza, r.nome nome_terceiro, p.nome_reclamante reclamante, 
			p.val_causa, p.val_sentenca, case when nvl(p.val_causa, 0) = 0 then 0 else round(p.val_sentenca / p.val_causa * 100,0) end perc_acordo,
			(select nvl(sum(val_parcela),0) from gpj_parcela where processo = p.processo and situacao = 1) total_pago,
			case when nvl(p.val_sentenca, 0) = 0 then 0 else round((select nvl(sum(val_parcela), 0)
            from gpj_parcela where processo = p.processo and situacao = 1) / p.val_sentenca * 100, 0) end perc_pago,
			CASE WHEN p.terceiro = 'N' 
			THEN (SELECT u.departamento FROM sis_usuario u WHERE u.cpf = p.reclamante)
			ELSE r.departamento END departamento,
			CASE WHEN p.terceiro = 'N' 
			THEN (SELECT d.des_departamento FROM sis_usuario u JOIN sis_departamento d ON 
			u.departamento = d.departamento WHERE u.cpf = p.reclamante)
			ELSE d.des_departamento END des_departamento  
			from  gpj_processo p
			join gpj_natureza n on p.natureza = n.natureza
			left join gpj_reclamante r on p.reclamante = r.reclamante
			join gpj_vara v on p.vara = v.vara
			join sis_empresa e on p.empresa = e.empresa
			join ger_revenda ge on e.cnpj = ge.cnpj
			left join gpj_reclamante r ON p.reclamante = r.reclamante
			left join sis_departamento d ON r.departamento = d.departamento
			where e.empresa in ('{$empresa}') and p.natureza in ('{$natureza}') and 
			(to_date(p.dta_inicio,'dd/mm/yyyy') between '{$de}' and '{$ate}') and 
			(to_date(p.dta_encerramento,'dd/mm/yyyy') >= '{$ate}' or p.dta_encerramento is null)
			order by  p.terceiro asc, e.empresa asc, to_date(p.dta_inicio,'dd/mm/yyyy') asc) R) R2 WHERE r2.departamento in('{$departamento}')");
			
		}elseif ($dashboard == "pagar"){
			return $this->Select("SELECT R2.*
			FROM (SELECT rownum n_linha, R.*
			FROM(SELECT pa.processo, ge.empresa||'.'||ge.revenda||' - '||e.razao_social empresa, p.n_processo, 
			p.nome_reclamante reclamante, n.des_natureza natureza,
			(select count(pa.processo) from gpj_parcela pa where pa.processo = p.processo and pa.situacao = 1) parcela, 
			(select count(pa.processo) from gpj_parcela pa where pa.processo = p.processo) n_parcela,pa.val_parcela, pa.dta_vencimento, 
			CASE WHEN p.terceiro = 'N' 
			THEN (SELECT u.departamento FROM sis_usuario u WHERE u.cpf = p.reclamante)
			ELSE r.departamento END departamento,
			CASE WHEN p.terceiro = 'N' 
			THEN (SELECT d.des_departamento FROM sis_usuario u JOIN sis_departamento d ON 
			u.departamento = d.departamento WHERE u.cpf = p.reclamante)
			ELSE d.des_departamento END des_departamento
			FROM gpj_processo p
			join gpj_natureza n on p.natureza = n.natureza
			JOIN sis_empresa e ON p.empresa = e.empresa
			join ger_revenda ge on e.cnpj = ge.cnpj
			JOIN gpj_parcela pa ON p.processo = pa.processo
			left join gpj_reclamante r ON p.reclamante = r.reclamante
			left join sis_departamento d ON r.departamento = d.departamento
			WHERE e.empresa in ('{$empresa}') and p.natureza in ('{$natureza}') and 
			((to_date(pa.dta_vencimento,'dd/mm/yyyy') BETWEEN '{$de}' AND '{$ate}')) AND pa.situacao = 0
			ORDER BY to_date(pa.dta_vencimento,'dd/mm/yyyy') ASC) R) R2 WHERE r2.departamento in('{$departamento}')");
		}
	}
	
	public function getAgendaaudiencia(){
		return $this->Select($sql);
	}
}