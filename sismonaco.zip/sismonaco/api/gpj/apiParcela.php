<?php

namespace api\gpj;

use lib\Model;
use obj\gpj\Parcela;
use helper\PrepareSQL;

class apiParcela extends Model {
	
	public function getParcela(Parcela $obj) {
		return  $this->First($this->Select("SELECT a.processo, a.dta_vencimento, a.val_parcela, a.situacao 
        FROM gpj_parcela a WHERE a.processo = '{$obj->processo}' AND a.dta_vencimento = '{$obj->dta_vencimento}'"));
	}
	
	public function getParcelaprocesso($processo) {
		return  $this->Select("SELECT a.processo, a.dta_vencimento, a.val_parcela, a.situacao
		FROM gpj_parcela a WHERE a.processo = '{$processo}' order by to_date(a.dta_vencimento, 'dd/mm/yyyy') ASC");
	}
	
	public function addParcela(Parcela $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'gpj_parcela');
	}
	
	public function delParcela(Parcela $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('processo' => $obj->processo), 'gpj_parcela');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}