<?php

namespace api\gpj;

use lib\Model;
use obj\gpj\Consultor;
use helper\PrepareSQL;
use helper\Funcoes;

class apiConsultor extends Model {
	
	public function getConsultor(Consultor $obj) {
		return  $this->First($this->Select("SELECT c.consultor, u.nome, c.natureza, n.des_natureza
		FROM gpj_consultor c JOIN sis_usuario u ON c.consultor = u.usuario
		JOIN gpj_natureza n ON c.natureza = n.natureza WHERE c.consultor = '{$obj->consultor}' AND c.natureza = '{$obj->natureza}' "));
	}
	
	public function filtroConsultor($c, $n, $coluna = NULL, $val = NULL) {
		$funcoes = new Funcoes();
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		$condicao = array(
			'1'	=> " WHERE LOWER({$coluna}) = '{$val}' ",
			'2' => " WHERE LOWER({$coluna}) LIKE '%{$val}%' ",
			'3'	=> " ",
		);
		if ($n == 'tudo') {
			$natureza = " ";
		}else{
			$natureza = "AND c.natureza = '{$n}' ";
		}
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT c.consultor, u.nome, c.natureza, n.des_natureza
		FROM gpj_consultor c JOIN sis_usuario u ON c.consultor = u.usuario
		JOIN gpj_natureza n on c.natureza = n.natureza{$condicao[$c]}{$natureza}ORDER BY u.nome ASC, n.des_natureza ASC) R ) R2");
	}
	
	public function addConsultor(Consultor $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'gpj_consultor');
	}
	
	public function delConsultor(Consultor $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('consultor' => $obj->consultor, 'natureza' => $obj->natureza), 'gpj_consultor');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}