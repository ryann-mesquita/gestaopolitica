<?php

namespace api\gpj;

use lib\Model;
use obj\gpj\Reclamante;
use helper\PrepareSQL;
use helper\Funcoes;

class apiReclamante extends Model {
	
	public function getReclamante(Reclamante $obj) {
		return  $this->First($this->Select("SELECT * FROM gpj_reclamante WHERE reclamante = '{$obj->reclamante}'"));
	}
	
	public function filtroReclamante($c, $a, $coluna = NULL, $val = NULL) {
		$funcoes = new Funcoes();
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		$condicao = array(
				'1'	=> " WHERE LOWER(r.{$coluna}) = '{$val}' ",
				'2' => " WHERE LOWER(r.{$coluna}) LIKE '%{$val}%' ",
				'3'	=> " ",
		);
		$ativo = array(
				'1' => "AND r.ativo = '1' ",
				'2' => "AND r.ativo = '0' ",
				'3' => "",
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT r.reclamante, r.nome, r.departamento, d.des_departamento
		FROM gpj_reclamante r
		JOIN sis_departamento d ON r.departamento = d.departamento{$condicao[$c]}{$ativo[$a]}ORDER BY r.reclamante DESC) R ) R2");
	}
	
	public function addReclamante(Reclamante $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'gpj_reclamante');
	}
	
	public function editReclamante(Reclamante $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'reclamante';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('reclamante' => $obj['reclamante']), 'gpj_reclamante');
	}
	
	public function delReclamante(Reclamante $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('reclamante' => $obj->reclamante), 'gpj_reclamante');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}