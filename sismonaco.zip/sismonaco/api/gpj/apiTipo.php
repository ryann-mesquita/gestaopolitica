<?php

namespace api\gpj;

use lib\Model;
use obj\gpj\Tipo;
use helper\PrepareSQL;
use helper\Funcoes;

class apiTipo extends Model {
	
	public function getTipo(Tipo $obj) {
		return  $this->First($this->Select("SELECT t.tipo, t.natureza, n.des_natureza, t.des_tipo, t.ativo
		FROM gpj_tipo t
		JOIN gpj_natureza n on t.natureza = n.natureza WHERE t.tipo = '{$obj->tipo}'"));
	}
	
	public function filtroTipo($c, $a, $coluna = NULL, $val = NULL, $natureza = NULL) {
		$funcoes = new Funcoes();
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		$condicao = array(
			'1'	=> " AND LOWER(t.{$coluna}) = '{$val}'",
			'2' => " AND LOWER(t.{$coluna}) LIKE '%{$val}%'",
			'3'	=> "",
		);
		$ativo = array(
			'1' => " AND t.ativo = '1' ",
			'2' => " AND t.ativo = '0' ",
			'3' => " ",
		);
		if ($natureza == 'tudo'){
			$n = "t.natureza is not null";
		}else{
			$n = "t.natureza = '{$natureza}'";
		}
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT t.tipo, t.natureza, n.des_natureza, t.des_tipo, t.ativo
		FROM gpj_tipo t
		JOIN gpj_natureza n on t.natureza = n.natureza
		WHERE {$n}{$condicao[$c]}{$ativo[$a]}ORDER BY t.des_tipo ASC) R ) R2");
	}
	
	public function addTipo(Tipo $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_tipo = strtoupper($funcoes->retiraAcentos(trim($obj->des_tipo)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'gpj_tipo','tipo');
	}
	
	public function editTipo(Tipo $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_tipo = strtoupper($funcoes->retiraAcentos(trim($obj->des_tipo)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'tipo';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('tipo' => $obj['tipo']), 'gpj_tipo');
	}
	
	public function delTipo(Tipo $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('tipo' => $obj->tipo), 'gpj_tipo');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}