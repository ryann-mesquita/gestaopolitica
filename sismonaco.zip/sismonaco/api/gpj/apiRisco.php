<?php

namespace api\gpj;

use lib\Model;
use obj\gpj\Risco;
use helper\PrepareSQL;
use helper\Funcoes;

class apiRisco extends Model {
	
	public function getRisco(Risco $obj) {
		return  $this->First($this->Select("SELECT * FROM gpj_risco WHERE risco = '{$obj->risco}'"));
	}
	
	public function filtroRisco($c, $a, $coluna = NULL, $val = NULL) {
		$funcoes = new Funcoes();
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		$condicao = array(
			'1'	=> " WHERE LOWER(r.{$coluna}) = '{$val}' ",
			'2' => " WHERE LOWER(r.{$coluna}) LIKE '%{$val}%' ",
			'3'	=> " ",
		);
		$ativo = array(
			'1' => "AND r.ativo = '1' ",
			'2' => "AND r.ativo = '0' ",
			'3' => "",
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT r.risco, r.des_risco, r.ativo
		FROM gpj_risco r{$condicao[$c]}{$ativo[$a]}ORDER BY r.des_risco ASC) R ) R2");
	}
	
	public function addRisco(Risco $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_risco = strtoupper($funcoes->retiraAcentos(trim($obj->des_risco)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'gpj_risco','risco');
	}
	
	public function editRisco(Risco $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_risco = strtoupper($funcoes->retiraAcentos(trim($obj->des_risco)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'risco';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('risco' => $obj['risco']), 'gpj_risco');
	}
	
	public function delRisco(Risco $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('risco' => $obj->risco), 'gpj_risco');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}