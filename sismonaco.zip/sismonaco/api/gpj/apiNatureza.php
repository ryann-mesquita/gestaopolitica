<?php

namespace api\gpj;

use lib\Model;
use obj\gpj\Natureza;
use helper\PrepareSQL;
use helper\Funcoes;

class apiNatureza extends Model {
	
	public function getNatureza(Natureza $obj) {
		return  $this->First($this->Select("SELECT * FROM gpj_natureza WHERE natureza = '{$obj->natureza}'"));
	}
	
	public function filtroNatureza($c, $a, $coluna = NULL, $val = NULL) {
		$funcoes = new Funcoes();
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		$condicao = array(
			'1'	=> " WHERE LOWER(n.{$coluna}) = '{$val}' ",
			'2' => " WHERE LOWER(n.{$coluna}) LIKE '%{$val}%' ",
			'3'	=> " ",
		);
		$ativo = array(
			'1' => "AND n.ativo = '1' ",
			'2' => "AND n.ativo = '0' ",
			'3' => " ",
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT n.natureza, n.des_natureza, n.ativo
		FROM gpj_natureza n{$condicao[$c]}{$ativo[$a]}ORDER BY n.des_natureza ASC) R ) R2");
	}
	
	public function addNatureza(Natureza $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_natureza = strtoupper($funcoes->retiraAcentos(trim($obj->des_natureza)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'gpj_natureza','natureza');
	}
	
	public function editNatureza(Natureza $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_natureza = strtoupper($funcoes->retiraAcentos(trim($obj->des_natureza)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'natureza';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('natureza' => $obj['natureza']), 'gpj_natureza');
	}
	
	public function delNatureza(Natureza $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('natureza' => $obj->natureza), 'gpj_natureza');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}