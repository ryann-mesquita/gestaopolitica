<?php

namespace api\gpj;

use lib\Model;
use obj\gpj\Vara;
use helper\PrepareSQL;
use helper\Funcoes;

class apiVara extends Model {
	
	public function getVara(Vara $obj) {
		return  $this->First($this->Select("SELECT v.vara, v.natureza, n.des_natureza, v.des_vara, v.ativo 
		FROM gpj_vara v
		JOIN gpj_natureza n on v.natureza = n.natureza WHERE v.vara = '{$obj->vara}'"));
	}
	
	public function filtroVara($c, $a, $coluna = NULL, $val = NULL, $natureza = NULL) {
		$funcoes = new Funcoes();
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		$condicao = array(
			'1'	=> " AND LOWER(v.{$coluna}) = '{$val}'",
			'2' => " AND LOWER(v.{$coluna}) LIKE '%{$val}%'",
			'3'	=> "",
		);
		$ativo = array(
			'1' => " AND v.ativo = '1' ",
			'2' => " AND v.ativo = '0' ",
			'3' => " ",
		);
		if ($natureza == 'tudo'){
			$n = "v.natureza is not null";
		}else{
			$n = "v.natureza = '{$natureza}'";
		}
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT v.vara, v.natureza, n.des_natureza, v.des_vara, v.ativo
		FROM gpj_vara v
		JOIN gpj_natureza n on v.natureza = n.natureza
		WHERE {$n}{$condicao[$c]}{$ativo[$a]}ORDER BY v.des_vara ASC) R ) R2");
	}
	
	public function addVara(Vara $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$search = array("�", "�");
		$obj->des_vara = strtoupper(str_replace($search, "", $funcoes->retiraAcentos(trim($obj->des_vara))));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'gpj_vara','vara');
	}
	
	public function editVara(Vara $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$search = array("�", "�");
		$obj->des_vara = strtoupper(str_replace($search, "", $funcoes->retiraAcentos(trim($obj->des_vara))));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'vara';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('vara' => $obj['vara']), 'gpj_vara');
	}
	
	public function delVara(Vara $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('vara' => $obj->vara), 'gpj_vara');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}