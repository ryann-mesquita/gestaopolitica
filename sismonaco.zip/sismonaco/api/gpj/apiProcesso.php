<?php

namespace api\gpj;

use lib\Model;
use obj\gpj\Processo;
use helper\PrepareSQL;
use helper\Funcoes;

class apiProcesso extends Model {
	
	public function getProcesso(Processo $obj) {
		return  $this->First($this->Select("SELECT p.processo, p.n_processo, p.des_processo, p.natureza, n.des_natureza, 
		p.vara, v.des_vara, p.cidade, c.des_cidade, c.uf, p.terceiro, 
		CASE WHEN p.terceiro = 'N' 
		THEN (SELECT u.departamento FROM sis_usuario u WHERE u.cpf = p.reclamante)
		ELSE r.departamento END departamento, 
		CASE WHEN p.terceiro = 'N' 
		THEN (SELECT d.des_departamento FROM sis_usuario u JOIN sis_departamento d ON 
		u.departamento = d.departamento WHERE u.cpf = p.reclamante)
		ELSE d.des_departamento END des_departamento, p.reclamante, 
		CASE WHEN p.terceiro = 'N' 
		THEN (p.nome_reclamante)
		ELSE r.nome END reclamante_nome, p.preposto, p.nome_reclamante, p.testemunha_emp1, p.testemunha_emp2, p.testemunha_emp3,
		p.testemunha_recl1, p.testemunha_recl2, p.testemunha_recl3,     
		p.val_causa, p.val_sentenca, p.val_quitacao, p.dta_inicio, p.dta_proxima_acao, p.dta_encerramento, p.dta_cadastro, p.empresa, 
		e.des_empresa, p.status, s.des_status, p.ativo, p.risco, r.des_risco, p.polo,
		(select nvl(sum(val_parcela),0) from gpj_parcela where processo = p.processo and situacao = 1) total_pago 
		FROM gpj_processo p
		JOIN gpj_natureza n ON p.natureza = n.natureza
		JOIN gpj_vara v ON p.vara = v.vara
		JOIN gpj_cidade c ON p.cidade = c.cidade
		JOIN gpj_risco r ON p.risco = r.risco
		LEFT JOIN gpj_reclamante r ON p.reclamante = r.reclamante
		LEFT JOIN sis_departamento d ON r.departamento = d.departamento
		JOIN gpj_status s ON p.status = s.status
		JOIN sis_empresa e ON p.empresa = e.empresa WHERE p.empresa = '{$obj->empresa}' AND p.processo = '{$obj->processo}' "));
	}
	
	public function filtroProcesso($empresa, $natureza, $c, $a, $coluna = NULL, $val = NULL) {
		$funcoes = new Funcoes();
		if ($natureza != 'tudo'){
			$n = " AND p.natureza = '{$natureza}'";
		}
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		$condicao = array(
			'1'	=> " AND LOWER(p.{$coluna}) = '{$val}'",
			'2' => " AND LOWER(p.{$coluna}) LIKE '%{$val}%'",
			'3'	=> "",
		);
		$ativo = array(
			'1' => " AND p.ativo = '1' ",
			'2' => " AND p.ativo = '0' ",
			'3' => " ",
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT p.processo, p.n_processo, p.des_processo, p.natureza, n.des_natureza, 
		p.vara, v.des_vara, p.cidade, c.des_cidade, c.uf, p.terceiro, 
		CASE WHEN p.terceiro = 'N' 
		THEN (SELECT u.departamento FROM sis_usuario u WHERE u.cpf = p.reclamante)
		ELSE r.departamento END departamento, 
		CASE WHEN p.terceiro = 'N' 
		THEN (SELECT d.des_departamento FROM sis_usuario u JOIN sis_departamento d ON 
		u.departamento = d.departamento WHERE u.cpf = p.reclamante)
		ELSE d.des_departamento END des_departamento, p.reclamante, 
		CASE WHEN p.terceiro = 'N' 
		THEN (p.nome_reclamante)
		ELSE r.nome END reclamante_nome, p.preposto, p.nome_reclamante, p.testemunha_emp1, p.testemunha_emp2, p.testemunha_emp3,
		p.testemunha_recl1, p.testemunha_recl2, p.testemunha_recl3,     
		p.val_causa, p.val_sentenca, p.val_quitacao, p.dta_inicio, p.dta_proxima_acao, p.dta_encerramento, p.dta_cadastro, p.empresa, 
		e.des_empresa, p.status, s.des_status, p.ativo, p.risco, r.des_risco, p.polo,
		(select nvl(sum(val_parcela),0) from gpj_parcela where processo = p.processo and situacao = 1) total_pago
		FROM gpj_processo p
		JOIN gpj_natureza n ON p.natureza = n.natureza
		JOIN gpj_vara v ON p.vara = v.vara
		JOIN gpj_cidade c ON p.cidade = c.cidade
		JOIN gpj_risco r ON p.risco = r.risco
		LEFT JOIN gpj_reclamante r ON p.reclamante = r.reclamante
		LEFT JOIN sis_departamento d ON r.departamento = d.departamento
		JOIN gpj_status s ON p.status = s.status
		JOIN sis_empresa e ON p.empresa = e.empresa WHERE p.empresa = '{$empresa}'{$n}{$condicao[$c]}{$ativo[$a]}ORDER BY p.processo DESC) R ) R2");
		
	}
	
	public function addProcesso(Processo $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_processo = strtoupper($funcoes->retiraAcentos(trim($obj->des_processo)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'gpj_processo','processo');
	}
	
	public function editProcesso(Processo $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'processo';}, ARRAY_FILTER_USE_KEY);
		if ((is_array($set) ? count($set) : 0) > 0){
			return $prepare->PrepareUpdate($set,array('processo' => $obj['processo']), 'gpj_processo');
		}
	}
	
	public function delProcesso(Processo $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('processo' => $obj->processo), 'gpj_processo');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}