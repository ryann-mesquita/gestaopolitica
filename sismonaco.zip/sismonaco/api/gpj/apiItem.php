<?php

namespace api\gpj;

use lib\Model;
use obj\gpj\Item;
use helper\PrepareSQL;
use helper\Funcoes;
use obj\gpj\Itemprocesso;
use obj\gpj\Processo;

class apiItem extends Model {
	
	public function getItem(Item $obj) {
		return  $this->First($this->Select("SELECT i.item, i.natureza, n.des_natureza, i.des_item, i.ativo
		FROM gpj_item i
		JOIN gpj_natureza n on i.natureza = n.natureza WHERE i.item = '{$obj->item}'"));
	}
	
	public function getItemprocesso(Processo $obj){
		return $this->Select("SELECT ip.processo, ip.item, i.des_item, ip.valor, ip.sentenca FROM gpj_item_processo ip
		JOIN gpj_item i ON ip.item = i.item
		WHERE ip.processo = '{$obj->processo}'");
	}
	public function filtroItem($c, $a, $coluna = NULL, $val = NULL, $natureza = NULL) {
		$funcoes = new Funcoes();
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		$condicao = array(
			'1'	=> " AND LOWER(i.{$coluna}) = '{$val}'",
			'2' => " AND LOWER(i.{$coluna}) LIKE '%{$val}%'",
			'3'	=> "",
		);
		$ativo = array(
			'1' => " AND i.ativo = '1' ",
			'2' => " AND i.ativo = '0' ",
			'3' => " ",
		);
		if ($natureza == 'tudo'){
			$n = "i.natureza is not null";
		}else{
			$n = "i.natureza = '{$natureza}'";
		}
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT i.item, i.natureza, n.des_natureza, i.des_item, i.ativo
		FROM gpj_item i
		JOIN gpj_natureza n on i.natureza = n.natureza
		WHERE {$n}{$condicao[$c]}{$ativo[$a]}ORDER BY i.des_item ASC) R ) R2");
	}
	
	public function addItem(Item $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_item = strtoupper($funcoes->retiraAcentos(trim($obj->des_item)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'gpj_item','item');
	}
	
	public function addItemprocesso(Itemprocesso $obj,$currval = NULL) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'gpj_item_processo',"",$currval);
	}
	
	public function editItem(Item $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_item = strtoupper($funcoes->retiraAcentos(trim($obj->des_item)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'item';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('item' => $obj['item']), 'gpj_item');
	}
	
	public function delItem(Item $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('item' => $obj->item), 'gpj_item');
	}
	
	public function delItemprocesso(Itemprocesso $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('processo' => $obj->processo), 'gpj_item_processo');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}