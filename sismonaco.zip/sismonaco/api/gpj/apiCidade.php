<?php

namespace api\gpj;

use lib\Model;
use obj\gpj\Cidade;
use helper\PrepareSQL;
use helper\Funcoes;

class apiCidade extends Model {
	
	public function getCidade(Cidade $obj) {
		return  $this->First($this->Select("SELECT * FROM gpj_cidade WHERE cidade = '{$obj->cidade}'"));
	}
	
	public function filtroCidade($c, $a, $coluna = NULL, $val = NULL) {
		$funcoes = new Funcoes();
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		$condicao = array(
			'1'	=> " WHERE LOWER(c.{$coluna}) = '{$val}' ",
			'2' => " WHERE LOWER(c.{$coluna}) LIKE '%{$val}%' ",
			'3'	=> " ",
		);
		$ativo = array(
			'1' => "AND c.ativo = '1' ",
			'2' => "AND c.ativo = '0' ",
			'3' => "",
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT c.cidade, c.des_cidade, c.uf, c.ativo
		FROM gpj_cidade c{$condicao[$c]}{$ativo[$a]}ORDER BY c.des_cidade ASC) R ) R2");
	}
	
	public function addCidade(Cidade $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_cidade = strtoupper($funcoes->retiraAcentos(trim($obj->des_cidade)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'gpj_cidade','cidade');
	}
	
	public function editCidade(Cidade $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_cidade = strtoupper($funcoes->retiraAcentos(trim($obj->des_cidade)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'cidade';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('cidade' => $obj['cidade']), 'gpj_cidade');
	}
	
	public function delCidade(Cidade $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('cidade' => $obj->cidade), 'gpj_cidade');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}