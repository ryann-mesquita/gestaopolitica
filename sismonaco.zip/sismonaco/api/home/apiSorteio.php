<?php

namespace api\home;

use lib\Model;
use helper\PrepareSQL;
use helper\Funcoes;
use obj\home\Codigo;

class apiSorteio extends Model {

public function addSorteio(Sorteio $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert2($obj, 'sis_sorteio','codigo');
}

public function editSorteio(Codigo $obj) {
	$prepare = new PrepareSQL();
	$funcoes = new Funcoes();
	$obj = (array) $obj;
	$obj = array_filter($obj, function($v){return !is_null($v);});
	$set = array_filter($obj, function($v){return $v != 'codigo';}, ARRAY_FILTER_USE_KEY);
	if ((is_array($set) ? count($set) : 0) > 0){
		return $prepare->PrepareUpdate($set,array('codigo' => $obj['codigo']), 'sis_sorteio_codigo');
	}
}

public function getLastIdSorteio(Codigo $obj) {
	return $this->First($this->Select("SELECT s.codigo, s.status, s.usuario
									   FROM sis_sorteio_codigo s 
									   WHERE s.usuario = '{$obj->usuario}'"));
}

public function getTotalUsuarios(){
	return $this->Select("select count(codigo) total from sis_sorteio_codigo where status = 1");
}

public function getCodigo(){
	$valido = false;
	$num = 0;
	while ($valido == false){
		$this->codigo = $this->Select("SELECT codigo, status FROM sis_sorteio_codigo
		where status = 0 and codigo = (select ROUND(DBMS_RANDOM.VALUE(00001, 99999)) from dual)");	
		if(!empty($this->codigo)){
			$valido = true;
		}
	}
	return $this->codigo;
}

public function retiraAprendiz(){
 return $this->Select("select u.usuario from sis_usuario u where TO_DATE(TO_CHAR(TO_DATE(dta_nascimento, 'dd/mm/yyyy hh24:mi:ss'), 'dd/mm/yyyy'), 'dd/mm/yyyy') >= TO_DATE('11/06/2002', 'dd/mm/yyyy') order by dta_nascimento asc");	
}
	 
public function retiraAfastados(){
	return $this->Select("select u.usuario from sis_usuario u where ativo = 2");
}

public function retiraDemitidos(){
	return $this->Select("select * from sis_usuario where ativo = 3");
}

	
public function executeSQL($sql){
	return $this->Execute($sql);
}
	
}