<?php

namespace api\home;

use lib\Model;
use obj\home\Auth;
use obj\adm\Permissao;
use api\adm\apiPermissao;
use api\adm\apiUsuario;
use obj\adm\Usuario;
use api\dev\apiFuncao;
use helper\Funcoes;
use helper\PrepareSQL;
use api\geral\apiPadrao;
use api\monaco\apiDisc;
use obj\geral\Pandion;
use api\geral\apiPandion;
use obj\geral\Visita;

class apiAuth extends Model {
	
	public function login(Auth $obj) {
		if( (@$_SESSION['captcha'] == @$_POST['captcha']) || $_SESSION['tentativa'] < 3){
			$login = strtolower(trim($obj->usuario));
			$senha = md5(trim($obj->senha));
			
			$sql = "SELECT * FROM sis_usuario WHERE (LOWER(email) = '{$login}@grupomonaco.com.br' AND
			ativo = '1') OR (LOWER(email) = '{$login}@grupomonaco.net.br' AND ativo = '1') OR (cpf = '{$login}' AND ativo = '1')";
			$rs = $this->First($this->Select($sql));
			
			if (isset($rs->SENHA) || isset($_SESSION['cadastro_sessao'])) {
				if (($senha == $rs->SENHA) ||isset($_SESSION['cadastro_sessao'])) {
					if (($rs->DEPARTAMENTO == '1') || ($rs->CARGO == '1') || ($rs->TELEFONE == NULL) || ($rs->CELULAR == NULL) || ($rs->IP == NULL) ||isset($_SESSION['cadastro_sessao'])){
						if (isset($_SESSION['cadastro_sessao'])){
							$funcoes = new Funcoes();
							if (isset($_POST['departamento'])){
								$usuario->departamento = $_POST['departamento'];
							}
							if (isset($_POST['cargo'])){
								$usuario->cargo = $_POST['cargo'];
							}
							if (isset($_POST['telefone'])){
								$usuario->telefone = $funcoes->naoNumerico($_POST['telefone']);
							}
							if (isset($_POST['celular'])){
								$usuario->celular = $funcoes->naoNumerico($_POST['celular']);
							}
							if (isset($_POST['ip'])){
								$usuario->ip = $funcoes->naoNumerico($_POST['ip']);
							}
							$obj = (array) $usuario;
							$obj = array_filter($obj, function($v){return !is_null($v);});
							$prepare = new PrepareSQL();
							$sql = array();
							$sql[0] = $prepare->PrepareUpdate($obj,array('usuario' => $_SESSION['cadastro_sessao']->USUARIO),'sis_usuario');
							$this->Execute($sql);
							header('location:' . APP_ROOT . 'home/auth/logout');
						}else{
							if (isset($_SERVER['HTTP_CLIENT_IP'])){
								$_SESSION['ip_sessao'] = $_SERVER['HTTP_CLIENT_IP'];
							}elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])){
								$_SESSION['ip_sessao'] = $_SERVER['HTTP_X_FORWARDED_FOR'];
							}else{
								$_SESSION['ip_sessao'] = $_SERVER['REMOTE_ADDR'];
							}
							$_SESSION['cadastro_sessao'] = $rs;
							$sql = "SELECT * FROM sis_departamento ORDER BY des_departamento ASC";
							$_SESSION['departamento_sessao'] = $this->Select($sql);
							$sql = "SELECT * FROM sis_cargo ORDER BY des_cargo ASC";
							$_SESSION['cargo_sessao'] = $this->Select($sql);
							header('location:' . APP_ROOT . 'home/auth/auth');
						}
					}else{
						$funcoes = new Funcoes();
						$_SESSION['usuario_sessao'] = $rs->USUARIO;
						$_SESSION['tipo_sessao'] = $rs->TIPO;
						$_SESSION['nome_sessao'] = $rs->NOME;
						$_SESSION['empresa_sessao'] = $rs->EMPRESA;
						$_SESSION['empresa_padrao_sessao'] = $rs->EMPRESA;
						$_SESSION['tempo_sessao'] = time();
						if (isset($_SERVER['HTTP_CLIENT_IP'])){
							$_SESSION['ip_sessao'] = $_SERVER['HTTP_CLIENT_IP'];
						}elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])){
							$_SESSION['ip_sessao'] = $_SERVER['HTTP_X_FORWARDED_FOR'];
						}else{
							$_SESSION['ip_sessao'] = $_SERVER['REMOTE_ADDR'];
						}
						$permissao = new Permissao();
						$permissao->usuario = $rs->USUARIO;
						$apiPermissao = new apiPermissao();
						$perm = $apiPermissao->permUsuario($permissao);
						foreach ($perm as $rs) {
							$_SESSION['permissao_sessao']["{$rs->EMPRESA}-{$rs->MODULO}-{$rs->CONTROLE}-{$rs->ACAO}"] = true;
						}
						$usuario = new Usuario();
						$usuario->usuario = $rs->USUARIO;
						$apiFuncao = new apiFuncao();
						$funcao = $apiFuncao->funcaoUsuario($usuario);
						foreach ($funcao as $rs) {
							$_SESSION['funcao_sessao']["{$rs->MODULO}-{$rs->FUNCAO}"] = true;
						}
						$apiPadrao = new apiPadrao();
						$padrao = $apiPadrao->getPadroes($rs->USUARIO);
						foreach ($padrao as $rs){
							$_SESSION['padrao_sessao']["{$rs->MODULO}-{$rs->CONTROLE}-{$rs->ACAO}"] = $rs->PADRAO;
						}
						$sql = array();
						$dta_acesso = date("d/m/Y H:i:s");
						$exp = explode(".", $_SESSION['ip_sessao']);
						$ip = str_pad($exp[0], 3, "0", STR_PAD_LEFT).str_pad($exp[1], 3, "0", STR_PAD_LEFT).str_pad($exp[2], 3, "0", STR_PAD_LEFT).str_pad($exp[3], 3, "0", STR_PAD_LEFT);
						$sql[0] = "UPDATE sis_usuario SET status = 1, dta_ult_acesso = '{$dta_acesso}', ip = '{$ip}'
						WHERE LOWER(email) = '{$login}@grupomonaco.com.br'
						OR LOWER(email) = '{$login}@grupomonaco.net.br' OR cpf = '{$login}'";
						$rs = $this->Execute($sql);
						if ($rs[4] == 'sucesso') {
							/*$ano = date('Y');
							 $apiPesquisaclima = new apiPesquisaclima();
							 $resposta = $apiPesquisaclima->getRespostaformulario($usuario->usuario,$ano);*/
							$usuario = new Usuario();
							$usuario->usuario = $_SESSION['usuario_sessao'];
							$apiUsuario = new apiUsuario();
							$pessoa = $apiUsuario->getUsuario($usuario);
							$cpf = $pessoa->CPF;
							$apiDisc = new apiDisc();
							$resposta = $apiDisc->getPessoa($cpf);
							if ((is_array($resposta) ? count($resposta) : 0) > 0){
								header('location:' . APP_ROOT . 'home');
							}else{
								header('location:' . APP_ROOT . 'monaco');
							}
						}
					}
				}else {
					$_SESSION['tentativa'] = $_SESSION['tentativa'] +1;
					
					$_SESSION[$login] = $_SESSION[$login] + 1;
					
					if ($_SESSION[$login] == 6) {
						
						$sql = array();
						$sql = "UPDATE sis_usuario SET ativo = 0 WHERE (LOWER(email) = '{$login}@grupomonaco.com.br')
						OR (LOWER(email) = '{$login}@grupomonaco.net.br') OR (cpf = '{$login}') ";
						
						$apiUsuario = new apiUsuario();
						$rs = $apiUsuario->executeSQL($sql);
						
						$_SESSION['loginErro'] = "Usu�rio Bloqueado por Tentativas de Acesso";
						if ($rs[4] == 'sucesso') {
							header('location:' . APP_ROOT . 'home/auth/auth');
						}
						
					}else {
						$_SESSION['loginErro'] = "Usu�rio ou Senha Inv�lida";
						header('location:' . APP_ROOT . 'home/auth/auth');
					}
				}
			}else {
				if (is_numeric($login)) {
					$login = str_pad(trim($login), 11, "0", STR_PAD_LEFT);
					$sql = "SELECT * FROM sis_usuario WHERE cpf = '{$login}'";
					$rs = $this->First($this->Select($sql));
					
					if (isset($rs->ATIVO)) {
						if($rs->ATIVO == 1){
							$_SESSION['loginErro'] = "Senha ou CPF digitado errado!";
							header('location:' . APP_ROOT . 'home/auth/auth');
						}else{
							$_SESSION['loginErro'] = "Usu�rio Inativo! F�rias ou Desligamento";
							header('location:' . APP_ROOT . 'home/auth/auth');
						}		
					}else{
						$sql = "SELECT c.contrato, p.cpf, p.nomecompleto nome, mca.tipo, car.cargo,
						car.departamento, p.nascimento as dta_nascimento, c.dataadmissao as dta_admissao, 
						case when p.emailcorporativo is null then p.email
						else p.emailcorporativo end email, em.empresa,p.contratosativos ativo
						FROM metadados.rhpessoas p
						JOIN metadados.rhcontratos c ON (p.pessoa = c.pessoa) AND (p.empresa = c.empresa)
						LEFT JOIN sis_int_metacargo mca ON c.cargo = mca.cargo_metadados
            			LEFT JOIN sis_cargo car ON mca.cargo = car.cargo
						JOIN metadados.rhestabelecimentos e ON c.unidade = e.estabelecimento
						JOIN sis_empresa em ON replace(replace(e.inscricao,'/',''),'-','') = em.cnpj
						WHERE p.cpf = '{$login}' AND p.contratosativos = '1'";
						$rs = $this->First($this->Select($sql));
						
						if (isset($rs->CPF)){
							//Cria��o de Usu�rio
							$sql = array();
							$apiUsuario = new apiUsuario();
							$usuario = new Usuario();
							$usuario->contrato = $rs->CONTRATO;
							$usuario->tipo = ($rs->TIPO != "") ? $rs->TIPO : 2;
							$usuario->departamento = ($rs->DEPARTAMENTO != "") ? $rs->DEPARTAMENTO : 1;
							$usuario->cargo = ($rs->CARGO != "") ? $rs->CARGO : 1;
							$usuario->cpf = "<str>".str_pad(trim($rs->CPF), 11, "0", STR_PAD_LEFT);
							$usuario->nome = strtolower(trim($rs->NOME));
							$usuario->dta_nascimento = trim($rs->DTA_NASCIMENTO);
							$usuario->dta_admissao = trim($rs->DTA_ADMISSAO);
							$usuario->email = strtolower(str_replace("'", "", trim($rs->EMAIL)));
							$usuario->empresa = $rs->EMPRESA;
							$usuario->ativo = $rs->ATIVO;
							$usuario->dta_cadastro = date("d/m/Y H:i:s");
							$sql[0] = $apiUsuario->addUsuario($usuario);
							$sql[1] = "INSERT INTO sis_permissao (usuario,modulo,controle,acao,empresa) VALUES (seq_sis_usuario.currval,'7','1','1','{$rs->EMPRESA}')";
							$sql[2] = "INSERT INTO sis_permissao (usuario,modulo,controle,acao,empresa) VALUES (seq_sis_usuario.currval,'7','40','1','{$rs->EMPRESA}')";
							$sql[3] = "INSERT INTO sis_permissao (usuario,modulo,controle,acao,empresa) VALUES (seq_sis_usuario.currval,'7','40','2','{$rs->EMPRESA}')";
							$sql[4] = "INSERT INTO sis_permissao (usuario,modulo,controle,acao,empresa) VALUES (seq_sis_usuario.currval,'7','40','3','{$rs->EMPRESA}')";
							$sql[5] = "INSERT INTO sis_permissao (usuario,modulo,controle,acao,empresa) VALUES (seq_sis_usuario.currval,'5','1','1','{$rs->EMPRESA}')";
							$sql[6] = "INSERT INTO sis_permissao (usuario,modulo,controle,acao,empresa) VALUES (seq_sis_usuario.currval,'9','1','1','{$rs->EMPRESA}')";
							$sql[7] = "INSERT INTO sis_permissao (usuario,modulo,controle,acao,empresa) VALUES (seq_sis_usuario.currval,'9','52','1','{$rs->EMPRESA}')";
							$sql[8] = "INSERT INTO sis_permissao (usuario,modulo,controle,acao,empresa) VALUES (seq_sis_usuario.currval,'9','52','2','{$rs->EMPRESA}')";
							$sql[9] = "INSERT INTO sis_permissao (usuario,modulo,controle,acao,empresa) VALUES (seq_sis_usuario.currval,'9','52','3','{$rs->EMPRESA}')";
					
							$r = $apiUsuario->executeSQL($sql);	
							if ($r[4] == 'sucesso'){
								//Cria��o de Usu�rio na AD
								$em = explode("@", $usuario->email);
								if (end($em) == "grupomonaco.com.br"){
									$ldap_server = "10.3.101.2";
									$user = "grupomonaco\administrator";
									$ldap_porta = "389";
									$ldap_pass   = "4dM.4dM.m0n4c0";
									$ldapcon = ldap_connect($ldap_server, $ldap_porta) or die("N�o Conseguiu conectar ao servidor de LDAP.");
									if ($ldapcon){
										$bind = ldap_bind($ldapcon, $user, $ldap_pass);
										if ($bind) {
											$adduserAD["cn"] = current(explode("@", $usuario->email));
											$adduserAD["givenname"] = current(explode(" ", $usuario->nome));
											$adduserAD["sn"] = current(explode(" ", $usuario->nome));
											$adduserAD["sAMAccountName"] = current(explode("@", $usuario->email));
											$adduserAD['userPrincipalName'] = current(explode("@", $usuario->email))."@grupomonaco.local";
											$adduserAD["objClass"] = "user";
											$adduserAD["displayname"] = ucfirst($usuario->nome);
											$adduserAD["mail"] = $usuario->email;
											$adduserAD["userPassword"] = substr(ucfirst($usuario->nome), 0, 2).$rs->CPF;
											$adduserAD["userAccountControl"] = "66080";
											
											$base_dn = "cn={$adduserAD["cn"]},ou=usuarios,DC=grupomonaco,DC=local";
											try {
												$bind = ldap_add($ldapcon, $base_dn, $adduserAD);
												echo "Cria��o de usu�rio no AD: " . $bind . "<br>";
											} catch (adLDAPException $e) {
												echo "Erro na cria��o de usu�rio no AD: " . $bind . "<br>";
											}
											ldap_close($ldapcon);
										} else {
											echo "LDAP N�o comunicou";
										}
									}
									//Cria��o de Usu�rio Pandion
									$pandion = new Pandion();
									$pandion->username = $adduserAD["givenname"];
									$pandion->password =substr(ucfirst($usuario->nome), 0, 2).$rs->CPF;
									$apiPandion = new apiPandion();
									$apiPandion->addUsuario($pandion);
								}
								$_SESSION['loginErro'] = "Usu�rio Cadastrado Tente Acessar Novamente!";
								header('location:' . APP_ROOT . 'home/auth/auth');
							}
							
						}else {
							$_SESSION['loginErro'] = "CPF N�o Cadastrado";
							header('location:' . APP_ROOT . 'home/auth/auth');
						}
					}
					
				}else {
					$_SESSION['loginErro'] = "Usu�rio N�o Cadastrado Ou Inativo";
					header('location:' . APP_ROOT . 'home/auth/auth');
				}
			}
			
		}else{
			$_SESSION['loginErro'] = "C�digo digitado Errado";
			header('location:' . APP_ROOT . 'home/auth/auth');
		}
	}
	
	public function logout(){
		$apiUsuario = new apiUsuario();
		$sql[0] = "UPDATE sis_usuario SET status = 0 WHERE usuario = '{$_SESSION['usuario_sessao']}' ";
		$apiUsuario->executeSQL($sql);
		session_unset();
		header('location:' . APP_ROOT . 'home/auth/auth');
	}
	
	public function getVisita($c, $ip, $data){
		$condicao = array(
			'1'	=> " WHERE v.ip = '{$ip}' AND v.data = '{$data}' ",
			'2'	=> " ",
		);
		$this->Select("SELECT * FROM sis_visita v{$condicao[$c]}");
	}
	
	public function addVisita(Visita $obj){
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'sis_visita','visita');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}