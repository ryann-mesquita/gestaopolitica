<?php

namespace api\monaco;

use lib\Model;

class apiPosvenda extends Model {

	public function getEmpresarevenda($cnpj){
		return $this->Select("SELECT gr.empresa, gr.revenda, pj.dn, gr.razao_social, gr.cnpj, gr.insc_estadual, pj.dta_fundacao, pj.registro_junta,
		gr.endereco, gr.nro_endereco, gr.bairro, gr.cidade, gr.uf FROM cnp.ger_revenda gr
		JOIN fat_pessoa_juridica pj ON pj.CLIENTE = gr.CLIENTE WHERE gr.cnpj = '{$cnpj}' ");
	}

	public function getOs($empresa,$revenda,$os){
		return $this->Select("Select case OS.EMPRESA||OS.REVENDA when '11' then '4700' when '51' then '4731'
		when '52' then '1960' when '41' then '4730' when '42' then '1936' when '111' then '4756' when '31' then '4738'
		when '33' then '1928' when '32' then '4774' else 'Nao e Diesel' end DN,
		OS.NRO_OS OS, OS.DTA_EMISSAO DatadeAbertura , OS.DTA_ENCERRAMENTO DatadeFaturamento,
		CASE TS.TIPO_SERVICO
		WHEN 'CF' THEN 'CLIENTE'
		WHEN 'CM' THEN 'CLIENTE'
		WHEN 'CP' THEN 'CLIENTE'
		WHEN 'CR' THEN 'CLIENTE'
		WHEN 'ST' THEN 'CLIENTE'
		WHEN 'DL' THEN 'GARANTIA'
		WHEN 'GF' THEN 'GARANTIA'
		WHEN 'GM' THEN 'GARANTIA'
		WHEN 'GP' THEN 'GARANTIA'
		WHEN 'GR' THEN 'GARANTIA'
		WHEN 'GO' THEN 'INTERNA'
		WHEN 'IA' THEN 'INTERNA'
		WHEN 'IP' THEN 'INTERNA'
		WHEN 'IU' THEN 'INTERNA'
		WHEN 'IVC' THEN 'INTERNA'
		WHEN 'IVO' THEN 'INTERNA'
		WHEN 'IVR' THEN 'INTERNA'
		WHEN 'PO' THEN 'INTERNA'
		WHEN 'VM' THEN 'VOLKSTOTAL'
		WHEN 'VR' THEN 'VOLKSTOTAL'
		END FONTEPAGADORA, ATE.CHASSI ChassidoVeiculo, FS.ANO_FABRICACAO, FS.ANO_MODELO, CO.DES_COR,
		FS.COMBUSTIVEL,FS.DIFERENCIAL,FS.MOTOR,FS.NUMERO_SERIE, FS.POTENCIA_MOTOR,FS.DTA_IMPORTACAO,FS.DTA_FATURA_FAB,
		FS.DTA_FIM_GARANTIA,FS.CILINDRADA,FS.RENAVAM,FS.COD_FROTA,
		v.des_modelo ModelodoVeiculo,
		CASE CT.IDENTIFICACAO
		WHEN 'M' THEN 'MECANICA'
		WHEN 'V' THEN 'REVISAO'
		WHEN 'F' THEN 'FUNILARIA'
		WHEN 'P' THEN 'PINTURA'
		WHEN 'E' THEN 'ELETRICA'
		WHEN 'N' THEN 'SERVI�O RAPIDO'
		WHEN 'Z' THEN 'FUNILARIA'
		WHEN 'B' THEN 'LUBRIFICACAO'
		WHEN 'O' THEN 'MECANICA'
		WHEN 'G' THEN 'REVISAO'
		WHEN 'M' THEN 'DESLOCAMENTO'
		WHEN 'L' THEN 'LAVAGEM'
		END NaturezadoServico ,
		SE.MAODEOBRA CodigodoTPR, SOS.DESCRICAO DescricaodoServico, SOS.QUANTIDADE TempoVendido, (SOS.QUANTIDADE*SOS.VAL_SERVICO)-SOS.VAL_DESCONTO ValorFaturado,
		CASE SE.MAODEOBRA WHEN 'ST' THEN 'Nao' else 'Sim' END Oficina,
		CASE SE.MAODEOBRA WHEN 'ST' THEN 'Sim' else 'Nao' END Terceiro,

		CASE v.familia WHEN 5 THEN 'ONIBUS' ELSE 'CAMINHOES' END CategoriadoVeiculo,
		CASE SE.MAODEOBRA WHEN 'DESL' THEN 'Sim' else 'Nao' END DESLOCAMENTO,

		CLI.NOME NomedoCLIENTE,

		CASE CLI.FISJUR WHEN 'F' THEN 'Fisica' else 'Juridica' END TipodeCLIENTE,

		case when FIS.CPF is null then JUR.CGC when JUR.CGC is null then TO_CHAR(FIS.CPF) else 'NULO' end CGC_CPF,
		CLI.NOME_PAIS Pais, ate.nome_contato Contato, '0'||CLI.DDD_TELEFONE||'-'||CLI.TELEFONE Telefone, '0'||CLI.DDD_CELULAR||'-'||CLI.CELULAR Celular,
		case when CLI.E_MAIL_TRABALHO is null then CLI.E_MAIL_CASA else CLI.E_MAIL_TRABALHO end Email, ATE.KILOMETRAGEM, ATE.PLACA,

		CASE WHEN UPPER (V.DES_MODELO) LIKE '%MAN%' THEN 'Man' else 'VW' END MontadoraVW_MAN,

		CLI.TIPOVIA_ENTREGA TipoVia,LOGRADOURO_ENTREGA Endereco, CLI.COMPLEMENTO_ENTREGA Complemento, CLI.BAIRRO_ENTREGA Bairro, CLI.MUNICIPIO_ENTREGA Cidade, CLI.UF_ENTREGA UF, CLI.CEP_ENTREGA CEP, CAP.NUMERO_NOTA_FISCAL NotaFiscal, VEN.NOME NomedoConsultor

		from OFI_SERVICO_OS SOS
		left outer join OFI_TIPO_SERVICO TS on TS.EMPRESA = SOS.EMPRESA and TS.REVENDA = SOS.REVENDA and TS.TIPO_SERVICO = SOS.TIPO_SERVICO
		left outer join OFI_ORDEM_SERVICO OS on OS.EMPRESA = SOS.EMPRESA and OS.REVENDA = SOS.REVENDA and OS.NRO_OS = SOS.NRO_OS
		left outer join OFI_ATENDIMENTO ATE on ATE.EMPRESA = OS.EMPRESA and ATE.REVENDA = OS.REVENDA and ATE.CONTATO = OS.CONTATO
		left outer join VEI_MODELO V on ate.EMPRESA = v.empresa and ate.MODELO = v.modelo
		left outer join GER_DEPARTAMENTO DEP on DEP.EMPRESA = ATE.EMPRESA and DEP.REVENDA = ATE.REVENDA and DEP.DEPARTAMENTO = ATE.DEPARTAMENTO
		left outer join FAT_VENDEDOR VEN on VEN.EMPRESA = ATE.EMPRESA and VEN.REVENDA = ATE.REVENDA and VEN.VENDEDOR = ATE.VENDEDOR
		left outer join CAC_CONTATO CAC on CAC.EMPRESA = ATE.EMPRESA and CAC.REVENDA = ATE.REVENDA and CAC.CONTATO = ATE.CONTATO
		left outer join FAT_CLIENTE CLI on CLI.CLIENTE = CAC.CLIENTE
		left outer join OFI_SERVICO SE on SE.EMPRESA = SOS.EMPRESA and SE.SERVICO = SOS.SERVICO
		left outer join FAT_PESSOA_FISICA FIS on FIS.CLIENTE = CLI.CLIENTE
		left outer join FAT_PESSOA_JURIDICA JUR on JUR.CLIENTE = CLI.CLIENTE
		left outer join FAT_MOVIMENTO_CAPA CAP on CAP.EMPRESA = CAC.EMPRESA AND CAP.REVENDA = CAC.REVENDA AND CAP.CONTATO = CAC.CONTATO
		left outer join OFI_CATEGORIA_SERVICO CT on CT.EMPRESA = SE.EMPRESA AND CT.CATEGORIA_SERVICO = SE.CATEGORIA_SERVICO
		left outer join OFI_MECANICO MEC on MEC.EMPRESA = SOS.EMPRESA and MEC.REVENDA = SOS.REVENDA and MEC.MECANICO = SOS.MECANICO
		left outer join OFI_FICHA_SEGUIMENTO FS on ATE.CHASSI = FS.CHASSI
		left outer join VEI_COR CO on CO.EMPRESA = FS.EMPRESA AND CO.COR = FS.COR
		where SOS.EMPRESA = {$empresa}

		and SOS.REVENDA = {$revenda}

		and cap.status ='F' and cap.TOT_SERVICOS > 0.01

		and OS.NRO_OS = '{$os}'

		UNION ALL
		Select case OS.EMPRESA||OS.REVENDA when '11' then '4700' when '51' then '4731'
		when '52' then '1960' when '41' then '4730' when '42' then '1936' when '111' then '4756' when '31' then '4738'
		when '33' then '1928' when '32' then '4774' else 'Nao e Diesel' end DN,
		OS.NRO_OS OS, OS.DTA_EMISSAO DatadeAbertura, OS.DTA_ENCERRAMENTO DatadeFaturamento,
		CASE TS.TIPO_SERVICO
		WHEN 'CF' THEN 'CLIENTE'
		WHEN 'CM' THEN 'CLIENTE'
		WHEN 'CP' THEN 'CLIENTE'
		WHEN 'CR' THEN 'CLIENTE'
		WHEN 'ST' THEN 'CLIENTE'
		WHEN 'DL' THEN 'GARANTIA'
		WHEN 'GF' THEN 'GARANTIA'
		WHEN 'GM' THEN 'GARANTIA'
		WHEN 'GP' THEN 'GARANTIA'
		WHEN 'GR' THEN 'GARANTIA'
		WHEN 'GO' THEN 'INTERNA'
		WHEN 'IA' THEN 'INTERNA'
		WHEN 'IP' THEN 'INTERNA'
		WHEN 'IU' THEN 'INTERNA'
		WHEN 'IVC' THEN 'INTERNA'
		WHEN 'IVO' THEN 'INTERNA'
		WHEN 'IVR' THEN 'INTERNA'
		WHEN 'PO' THEN 'INTERNA'
		WHEN 'VM' THEN 'VOLKSTOTAL'
		WHEN 'VR' THEN 'VOLKSTOTAL'
		END FONTEPAGADORA, ATE.CHASSI ChassidoVeiculo, FS.ANO_FABRICACAO, FS.ANO_MODELO, CO.DES_COR,
		FS.COMBUSTIVEL,FS.DIFERENCIAL,FS.MOTOR,FS.NUMERO_SERIE, FS.POTENCIA_MOTOR,FS.DTA_IMPORTACAO,FS.DTA_FATURA_FAB,
		FS.DTA_FIM_GARANTIA,FS.CILINDRADA,FS.RENAVAM,FS.COD_FROTA,
		v.des_modelo ModelodoVeiculo ,
		CASE CT.IDENTIFICACAO
		WHEN 'M' THEN 'MECANICA'
		WHEN 'V' THEN 'REVISAO'
		WHEN 'F' THEN 'FUNILARIA'
		WHEN 'P' THEN 'PINTURA'
		WHEN 'E' THEN 'ELETRICA'
		WHEN 'N' THEN 'SERVI�O RAPIDO'
		WHEN 'Z' THEN 'FUNILARIA'
		WHEN 'B' THEN 'LUBRIFICACAO'
		WHEN 'O' THEN 'MECANICA'
		WHEN 'G' THEN 'REVISAO'
		WHEN 'M' THEN 'DESLOCAMENTO'
		WHEN 'L' THEN 'LAVAGEM'
		END NaturezadoServico ,
		SE.MAODEOBRA CodigodoTPR, SOS.DESCRICAO DescricaodoServico, SOS.QUANTIDADE TempoVendido, (SOS.QUANTIDADE*SOS.VAL_SERVICO)-SOS.VAL_DESCONTO ValorFaturado,
		CASE SE.MAODEOBRA WHEN 'ST' THEN 'Nao' else 'Sim' END Oficina,
		CASE SE.MAODEOBRA WHEN 'ST' THEN 'Sim' else 'Nao' END Terceiro,

		CASE v.familia WHEN 5 THEN 'ONIBUS' ELSE 'CAMINHOES' END CategoriadoVeiculo,
		CASE SE.MAODEOBRA WHEN 'DESL' THEN 'Sim' else 'Nao' END DESLOCAMENTO,

		CLI.NOME NomedoCLIENTE,

		CASE CLI.FISJUR WHEN 'F' THEN 'Fisica' else 'Juridica' END TipodeCLIENTE,

		case when FIS.CPF is null then JUR.CGC when JUR.CGC is null then TO_CHAR(FIS.CPF) else 'NULO' end CGC_CPF,
		CLI.NOME_PAIS Pais,ate.nome_contato Contato, '0'||CLI.DDD_TELEFONE||'-'||CLI.TELEFONE Telefone, '0'||CLI.DDD_CELULAR||'-'||CLI.CELULAR Celular,
		case when CLI.E_MAIL_TRABALHO is null then CLI.E_MAIL_CASA else CLI.E_MAIL_TRABALHO end Email, ATE.KILOMETRAGEM, ATE.PLACA,

		CASE WHEN UPPER (V.DES_MODELO) LIKE '%MAN%' THEN 'Man' else 'VW' END MontadoraVW_MAN,

		CLI.TIPOVIA_ENTREGA TipoVia,LOGRADOURO_ENTREGA Endereco, CLI.COMPLEMENTO_ENTREGA Complemento, CLI.BAIRRO_ENTREGA Bairro, CLI.MUNICIPIO_ENTREGA Cidade, CLI.UF_ENTREGA UF, CLI.CEP_ENTREGA CEP, CAP.NUMERO_NOTA_FISCAL NotaFiscal, VEN.NOME NomedoConsultor

		from OFI_SERVICO_OS SOS
		left outer join OFI_TIPO_SERVICO TS on TS.EMPRESA = SOS.EMPRESA and TS.REVENDA = SOS.REVENDA and TS.TIPO_SERVICO = SOS.TIPO_SERVICO
		left outer join OFI_ORDEM_SERVICO OS on OS.EMPRESA = SOS.EMPRESA and OS.REVENDA = SOS.REVENDA and OS.NRO_OS = SOS.NRO_OS
		left outer join OFI_ATENDIMENTO ATE on ATE.EMPRESA = OS.EMPRESA and ATE.REVENDA = OS.REVENDA and ATE.CONTATO = OS.CONTATO
		left outer join VEI_MODELO V on ate.EMPRESA = v.empresa and ate.MODELO = v.modelo
		left outer join GER_DEPARTAMENTO DEP on DEP.EMPRESA = ATE.EMPRESA and DEP.REVENDA = ATE.REVENDA and DEP.DEPARTAMENTO = ATE.DEPARTAMENTO
		left outer join FAT_VENDEDOR VEN on VEN.EMPRESA = ATE.EMPRESA and VEN.REVENDA = ATE.REVENDA and VEN.VENDEDOR = ATE.VENDEDOR
		left outer join CAC_CONTATO CAC on CAC.EMPRESA = ATE.EMPRESA and CAC.REVENDA = ATE.REVENDA and CAC.CONTATO = ATE.CONTATO
		left outer join FAT_CLIENTE CLI on CLI.CLIENTE = CAC.CLIENTE
		left outer join OFI_SERVICO SE on SE.EMPRESA = SOS.EMPRESA and SE.SERVICO = SOS.SERVICO
		left outer join FAT_PESSOA_FISICA FIS on FIS.CLIENTE = CLI.CLIENTE
		left outer join FAT_PESSOA_JURIDICA JUR on JUR.CLIENTE = CLI.CLIENTE
		left outer join FAT_MOVIMENTO_CAPA CAP on CAP.EMPRESA = CAC.EMPRESA AND CAP.REVENDA = CAC.REVENDA AND CAP.CONTATO = CAC.CONTATO
		left outer join OFI_CATEGORIA_SERVICO CT on CT.EMPRESA = SE.EMPRESA AND CT.CATEGORIA_SERVICO = SE.CATEGORIA_SERVICO
		left outer join OFI_MECANICO MEC on MEC.EMPRESA = SOS.EMPRESA and MEC.REVENDA = SOS.REVENDA and MEC.MECANICO = SOS.MECANICO
		left outer join OFI_FICHA_SEGUIMENTO FS on ATE.CHASSI = FS.CHASSI
		left outer join VEI_COR CO on CO.EMPRESA = FS.EMPRESA AND CO.COR = FS.COR
		where SOS.EMPRESA = {$empresa}

		and SOS.REVENDA = {$revenda}

		and OS.FONTE_PAGADORA_INT IN (2,3,4,5,6)

		and OS.NRO_OS = '$os' ");
	}

	public function  getOsservico($empresa,$revenda,$os){
		return $this->Select("Select SOS.*, SERV.MODELO_SERVICO, (SERV.MAODEOBRA ||' '|| COALESCE(SERV.DETALHAMENTO_ENGENHARIA, '') ||' '|| COALESCE(SERV.ADICIONAL_SERVICO, '')) MAODEOBRA,
		SERV.VAL_SERVICO_UNITARIO, MO.DES_RESUMIDA, TIPO.TIPO_SERVICO_OS, (SOS.VAL_DESCONTO - COALESCE(SOS.VAL_DESCONTO_FRANQUIA, 0)) VAL_DESCONTO_REAL
		from OFI_SERVICO_OS SOS, OFI_SERVICO SERV, OFI_MAODEOBRA MO, OFI_TIPO_SERVICO TIPO where SOS.EMPRESA = {$empresa}
		and SOS.REVENDA = {$revenda} and SOS.NRO_OS = {$os} and SERV.EMPRESA = SOS.EMPRESA and SERV.SERVICO = SOS.SERVICO and MO.EMPRESA = SERV.EMPRESA and MO.MAODEOBRA = SERV.MAODEOBRA
		and TIPO.EMPRESA = SOS.EMPRESA and TIPO.REVENDA = SOS.REVENDA and TIPO.TIPO_SERVICO = SOS.TIPO_SERVICO ORDER BY SOS.NRO_LANCAMENTO");
	}

	public function  getOspecas($empresa,$revenda,$os){
		return $this->Select("Select PECAOS.*, IE.ITEM_ESTOQUE_PUB, IE.DES_ITEM_ESTOQUE, TIPO.TIPO_SERVICO_OS, TIPO.TIPO_SERVICO,
		MEC.NOME, SOL.NRO_ORCAMENTO, SOL.POLITICA_PRECO_PECA, IR.PCT_MARGEM_LUCRO,
		CAST((PECAOS.VAL_DESCONTO - COALESCE(PECAOS.VAL_DESCONTO_FRANQUIA,0)) AS NUMERIC (11,2)) VAL_DESCONTO_REAL,
		(IR.LOCACAO_ZONA || ' ' || IR.LOCACAO_RUA || ' ' || IR.LOCACAO_ESTANTE || ' ' || IR.LOCACAO_PRATELEIRA || ' ' || IR.LOCACAO_NUMERO) LOCACAO
		from OFI_PECA_OS PECAOS, PEC_ITEM_ESTOQUE IE, OFI_TIPO_SERVICO TIPO, OFI_MECANICO MEC, PEC_ITEM_REVENDA IR,
		OFI_SOLICITACAO SOL where PECAOS.EMPRESA = {$empresa} and PECAOS.REVENDA = {$revenda} and PECAOS.NRO_OS = {$os} and
		IE.EMPRESA = PECAOS.EMPRESA and IE.ITEM_ESTOQUE = PECAOS.ITEM_ESTOQUE and IR.EMPRESA = PECAOS.EMPRESA
		and IR.REVENDA = PECAOS.REVENDA and IR.ITEM_ESTOQUE = PECAOS.ITEM_ESTOQUE and TIPO.EMPRESA = PECAOS.EMPRESA
		and TIPO.REVENDA = PECAOS.REVENDA and TIPO.TIPO_SERVICO = PECAOS.TIPO_SERVICO and SOL.EMPRESA = PECAOS.EMPRESA
		and SOL.REVENDA = PECAOS.REVENDA and SOL.CONTATO = PECAOS.CONTATO and SOL.NRO_SOLICITACAO = PECAOS.NRO_SOLICITACAO
		and MEC.EMPRESA (+) = PECAOS.EMPRESA and MEC.REVENDA (+) = PECAOS.REVENDA and MEC.MECANICO (+) = PECAOS.MECANICO
		order by PECAOS.NRO_LANCAMENTO");

	}

	public function getOsobservacao($empresa,$revenda,$os){
		return $this->Select("Select S.Nro_Solicitacao,s.des_solicitacao,s.tipo_servico,s.tipo_servico_os
		from Ofi_Ordem_Servico OS
		join OFI_SOLICITACAO S on s.empresa = os.empresa and s.revenda = os.revenda and s.contato = os.contato
		where os.empresa = {$empresa} and os.revenda = {$revenda} and os.nro_os = {$os} and SITUACAO in (9) Order by NRO_SOLICITACAO");
	}

	public function getOscondicaopagamento($empresa,$revenda,$os){
		return $this->Select("select fp.empresa, fp.revenda, fp.nro_os, fp.origem, os.contato, cp.des_condicao,
		case when fp.origem = 'S' then (select max(numero_nota_fiscal||' - '||serie_nota_fiscal) from fat_movimento_capa where empresa = fp.empresa and revenda = fp.revenda and status = 'F' and contato = os.contato and tot_mercadoria = 0) else
		(select max(numero_nota_fiscal||' - '||serie_nota_fiscal) from fat_movimento_capa where empresa = fp.empresa and revenda = fp.revenda and status = 'F' and contato = os.contato and tot_mercadoria <> 0)
		end nota , fp.valor from ofi_forma_pagamento_os fp
		join fat_condicao_pagamento cp on cp.empresa = fp.empresa and cp.condicao = fp.condicao
		join ofi_ordem_servico os on os.empresa = fp.empresa and os.revenda = fp.revenda and os.nro_os = fp.nro_os
		where fp.empresa = {$empresa} and fp.revenda = $revenda and fp.nro_os = {$os} and fp.origem in ('S','P')");
	}

	public function getCargainicial($empresa,$revenda){
		$data = implode("/",array_reverse(explode("-",date('Y-m-d', strtotime('-1 years')))));
		return $this->Select("select case when (t.marca = 'FIAT') then 00001 else 09999 end COD_FABRICANTE,
		case when (t.marca = 'FIAT') then 'FIAT AUTOMOVEIS S.A' else 'DIVERSOS' end NOME_FABRICANTE,
		0 PRAZO_COMPRA, 0 DESCONTO_FABRICANTE,t.ITEM_ESTOQUE_PUB COD_ITEM_FABRICANTE,
		t.DES_ITEM_ESTOQUE NOME_ITEM_FABRICANTE, case (PG.IDENTIFICACAO_GRUPO) when 'P' THEN
		'PECAS' when 'A' THEN 'ACESSORIOS' when 'C' THEN 'COMBUSTIVEIS' when 'L' THEN
		'LUBRIFICANTES' when 'O' THEN 'OUTROS' end ESPECIFICACAO_ITEM, case (PG.IDENTIFICACAO_GRUPO)
		when 'P' THEN 'PEC' when 'A' THEN 'ACES' when 'C' THEN 'COMB' when 'L' THEN 'LUB'
		when 'O' THEN 'OUT' end ABREV_ESPEC_ITEM,t.grupo_desconto,t.preco_publico_atual,
		r.val_estoque custo_medio, t.preco_garantia, t.preco_alternativo,
        case when t.dta_do_cadastro is null then r.dta_ult_entrada else t.dta_do_cadastro end dta_do_cadastro,
		r.dta_ult_entrada, case when r.dta_saida < r.dta_ult_entrada then to_date('01/04/2017','dd/mm/yyyy') else r.dta_saida end dta_saida,(r.locacao_zona||r.locacao_rua||r.locacao_estante||
		r.locacao_prateleira||r.locacao_numero) localizacao_fisica,((r.qtd_contabil) - (r.qtd_negociacao + r.qtd_alocada + r.qtd_orcada + r.qtd_litigio + r.qtd_terceiros + r.qtd_conferencia + r.qtd_comprometida)) qtd_disponivel,
		round(r.qtd_contabil,0) qtd_contabil,round(r.qtd_pedida,0) qtd_pedida,round(t.qtd_embalagem,0) qtd_embalagem,case when (t.SITUACAO = 'E') then 'S' else 'N' end ITEM_BLOQUEADO,round(r.qtd_alocada)qtd_alocada
		from PEC_ITEM_ESTOQUE t 
		join pec_item_revenda r on (t.empresa = r.empresa and t.item_estoque = r.item_estoque)
		join pec_grupo pg on t.marca = pg.marca and t.grupo = pg.grupo
		where t.empresa = {$empresa} and r.revenda = {$revenda} and r.class_abc = 'D' and ((r.qtd_contabil) - (r.qtd_negociacao + r.qtd_alocada + r.qtd_orcada + r.qtd_litigio + r.qtd_terceiros + r.qtd_conferencia + r.qtd_comprometida)) > 0 
		and r.dta_ult_compra < TO_DATE('{$data}', 'dd/mm/yyyy') and r.dta_prim_entrada < TO_DATE('{$data}', 'dd/mm/yyyy')");	
	}
}