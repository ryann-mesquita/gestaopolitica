<?php

namespace api\monaco;

use lib\Model;

class apiContabilidade extends Model {

	public function getEmpresarevenda($empresa,$revenda){
		return $this->Select("SELECT gr.empresa, gr.revenda, pj.dn, gr.razao_social, gr.cnpj, gr.insc_estadual, pj.dta_fundacao, pj.registro_junta,
		gr.endereco, gr.nro_endereco, gr.bairro, gr.cidade, gr.uf FROM cnp.ger_revenda gr
		JOIN fat_pessoa_juridica pj ON pj.CLIENTE = gr.CLIENTE WHERE gr.empresa = {$empresa} and gr.revenda = {$revenda}");
	}

	public function getBalancete($empresa,$ano,$mes,$ano_anterior,$mes_anterior) {

		if ($mes == "01") {

			return $this->Select("select ctb1.ordem ordem, ctb1.conta conta, nvl(ctb2.debito,0) debito,
			nvl(ctb3.credito,0) credito,nvl(ctb2.debito,0) - nvl(ctb3.credito,0) movimento_mes,nvl(ctb2.debito,0) - nvl(ctb3.credito,0) + nvl(ctb1.saldo,0) saldo ,
			nvl(ctb1.saldo,0) saldo_ano_anterior

			from

			(select cc.ordem,cc.conta,case when c.saldo <> 0 then c.saldo else cc.saldo
			end saldo from monaco_conta_contabil cc

			left join

			(select case
			when sa.conta like '1110101%' then substr(sa.conta,1,2)
			when sa.conta like '1110102%' then substr(sa.conta,1,2)
			when sa.conta like '1150301%' then substr(sa.conta,1,2)
			when sa.conta = 1120101002 then substr (sa.conta,1,10)
			when sa.conta in (1120101001,1120101003) then substr (sa.conta,1,9)
			when sa.conta like '113%' then substr(sa.conta,1,3)
			when sa.conta like '1150102%' then substr(sa.conta,1,3)
			when sa.conta like '11502%' then substr(sa.conta,1,3)
			when sa.conta like '1230101%' then substr(sa.conta,1,3)
			when sa.conta = '1230201001' then substr(sa.conta,1,3)
			when sa.conta = '1120101002' then sa.conta
			when sa.conta in ('2110101001','2110102002') then substr (sa.conta,1,5)
			when sa.conta = '2110101002' then substr (sa.conta,1,10)
			when sa.conta like '2140101%'then substr (sa.conta,1,5)
			when sa.conta like '2140102%'then substr (sa.conta,1,5)
			when sa.conta = '2120101005' then substr(sa.conta,1,10)
			when sa.conta = '2130102001' then substr(sa.conta,1,10)
			when sa.conta like '2130102%' then substr(sa.conta,1,5)
			when sa.conta like '2130103%' then substr(sa.conta,1,5)
			when sa.conta like '311%' then substr(sa.conta,1,3)
			when sa.conta like '312%' then substr(sa.conta,1,3)
			when sa.conta like '32101%' then substr(sa.conta,1,2)
			when sa.conta = '3220102010' then substr(sa.conta,1,10)
			when sa.conta like '32201%' then substr(sa.conta,1,2)
			when sa.conta = '3310102018' then substr(sa.conta,1,8)
			when sa.conta = '3310102083' then substr(sa.conta,1,8)
			when sa.conta like '3310102%' then substr(sa.conta,1,5)
			when sa.conta like '3310103%' then substr(sa.conta,1,5)
			when sa.conta like '35101%' then substr(sa.conta,1,5)
			when sa.conta = '3610101002' then substr(sa.conta,1,10)
			when sa.conta = '3610101001' then substr(sa.conta,1,10)
			else substr (sa.conta,1,7) end conta, sum(sa.saldo) saldo
			from ctb_saldo_anterior sa where sa.empresa = {$empresa}
			and sa.ano = {$ano_anterior} and (sa.conta like '1110101%' or sa.conta like '1110102%'
			or sa.conta like '1150301%' or sa.conta like '1110103%' or sa.conta like '1150101%'
			or sa.conta like '1120201%' or sa.conta like '1130101%' or sa.conta like '1130102%'
			or sa.conta like '1130103%' or sa.conta like '1130201%' or sa.conta like '1140401%'
			or sa.conta like '1150102%' or sa.conta like '1150201%' or sa.conta like '1210101%'
			or sa.conta like '1220101%' or sa.conta like '1230101%' or sa.conta like '1240101%'
			or sa.conta like '1230102%' or sa.conta like '1240102%' or sa.conta like '2150101%'
			or sa.conta like '2140101%' or sa.conta like '2140102%' or sa.conta like '2120101%'
			or sa.conta like '2130102%' or sa.conta like '2130103%' or sa.conta like '2130101%'
			or sa.conta like '2170102%' or sa.conta like '2220101%' or sa.conta like '2210101%'
			or sa.conta like '2210102%' or sa.conta like '2240101%' or sa.conta like '2310101%'
			or sa.conta like '2310201%' or sa.conta like '2340101%' or sa.conta like '2350101%'
			or sa.conta like '3110101%' or sa.conta like '3110102%' or sa.conta like '3110103%'
			or sa.conta like '3110201%' or sa.conta like '3110202%' or sa.conta like '3120101%'
			or sa.conta like '3120103%' or sa.conta like '3210101%' or sa.conta like '3210102%'
			or sa.conta like '3210103%' or sa.conta like '3210104%' or sa.conta like '3220101%'
			or sa.conta like '3220102%' or sa.conta like '3310101%' or sa.conta like '3310102%'
			or sa.conta like '3310103%' or sa.conta like '3510101%' or sa.conta like '3510102%'
			or sa.conta like '3410101%' or sa.conta like '3410102%' or sa.conta in ('1120101001',
			'1120101002','1120101003','1230201001','2110101001','2110101002','2110102002',
			'3610101002','3610101001')) and sa.conta not in ('1110101','1110102','1150301',
			'1110103','1150101','1120201','1130101','1130102','1130103','1130201','1140401',
			'1150102','1150201','1210101','1220101','1230101','1240101','1230102',1240102,
			'2150101','2140101','2140102','2120101','2130102','2130103','2130101','2170102',
			'2220101','2210101','2210102','2240101','2310101','2310201','2340101','2350101',
			'3110101','3110102','3110103','3110201',3110202,'3120101','3120103','3210101',
			'3210102','3210103','3210104','3220101','3220102','3310101','3310102','3310103',
			'3510101','3510102','3410101','3410102')
			group by case
			when sa.conta like '1110101%' then substr(sa.conta,1,2)
			when sa.conta like '1110102%' then substr(sa.conta,1,2)
			when sa.conta like '1150301%' then substr(sa.conta,1,2)
			when sa.conta = 1120101002 then substr (sa.conta,1,10)
			when sa.conta in (1120101001,1120101003) then substr (sa.conta,1,9)
			when sa.conta like '113%' then substr(sa.conta,1,3)
			when sa.conta like '1150102%' then substr(sa.conta,1,3)
			when sa.conta like '11502%' then substr(sa.conta,1,3)
			when sa.conta like '1230101%' then substr(sa.conta,1,3)
			when sa.conta = '1230201001' then substr(sa.conta,1,3)
			when sa.conta = '1120101002' then sa.conta
			when sa.conta in ('2110101001','2110102002') then substr (sa.conta,1,5)
			when sa.conta = '2110101002' then substr (sa.conta,1,10)
			when sa.conta like '2140101%'then substr (sa.conta,1,5)
			when sa.conta like '2140102%'then substr (sa.conta,1,5)
			when sa.conta = '2120101005' then substr(sa.conta,1,10)
			when sa.conta = '2130102001' then substr(sa.conta,1,10)
			when sa.conta like '2130102%' then substr(sa.conta,1,5)
			when sa.conta like '2130103%' then substr(sa.conta,1,5)
			when sa.conta like '311%' then substr(sa.conta,1,3)
			when sa.conta like '312%' then substr(sa.conta,1,3)
			when sa.conta like '32101%' then substr(sa.conta,1,2)
			when sa.conta = '3220102010' then substr(sa.conta,1,10)
			when sa.conta like '32201%' then substr(sa.conta,1,2)
			when sa.conta = '3310102018' then substr(sa.conta,1,8)
			when sa.conta = '3310102083' then substr(sa.conta,1,8)
			when sa.conta like '3310102%' then substr(sa.conta,1,5)
			when sa.conta like '3310103%' then substr(sa.conta,1,5)
			when sa.conta like '35101%' then substr(sa.conta,1,5)
			when sa.conta = '3610101002' then substr(sa.conta,1,10)
			when sa.conta = '3610101001' then substr(sa.conta,1,10)
			else substr (sa.conta,1,7) end) c on cc.conta = c.conta
			order by cc.ordem )ctb1

			left join

			(select case
			when l.conta like '1110101%' then substr(l.conta,1,2)
			when l.conta like '1110102%' then substr(l.conta,1,2)
			when l.conta like '1150301%' then substr(l.conta,1,2)
			when l.conta = 1120101002 then substr (l.conta,1,10)
			when l.conta in (1120101001,1120101003) then substr (l.conta,1,9)
			when l.conta like '113%' then substr(l.conta,1,3)
			when l.conta like '1150102%' then substr(l.conta,1,3)
			when l.conta like '11502%' then substr(l.conta,1,3)
			when l.conta like '1230101%' then substr(l.conta,1,3)
			when l.conta = '1230201001' then substr(l.conta,1,3)
			when l.conta = '1120101002' then l.conta
			when l.conta in ('2110101001','2110102002') then substr (l.conta,1,5)
			when l.conta = '2110101002' then substr (l.conta,1,10)
			when l.conta like '2140101%'then substr (l.conta,1,5)
			when l.conta like '2140102%'then substr (l.conta,1,5)
			when l.conta = '2120101005' then substr(l.conta,1,10)
			when l.conta = '2130102001' then substr(l.conta,1,10)
			when l.conta like '2130102%' then substr(l.conta,1,5)
			when l.conta like '2130103%' then substr(l.conta,1,5)
			when l.conta like '311%' then substr(l.conta,1,3)
			when l.conta like '312%' then substr(l.conta,1,3)
			when l.conta like '32101%' then substr(l.conta,1,2)
			when l.conta = '3220102010' then substr(l.conta,1,10)
			when l.conta like '32201%' then substr(l.conta,1,2)
			when l.conta = '3310102018' then substr(l.conta,1,8)
			when l.conta = '3310102083' then substr(l.conta,1,8)
			when l.conta like '3310102%' then substr(l.conta,1,5)
			when l.conta like '3310103%' then substr(l.conta,1,5)
			when l.conta like '35101%' then substr(l.conta,1,5)
			when l.conta = '3610101002' then substr(l.conta,1,10)
			when l.conta = '3610101001' then substr(l.conta,1,10)
			else substr (l.conta,1,7) end conta,l.natureza, sum(d.val_divisao) debito
			from ctb_lancamento_dividido d, ctb_lancamento l where l.lancamento = d.lancamento
			and l.empresa = d.empresa and l.revenda = d.revenda and l.ano_mes = d.ano_mes
			and l.empresa = {$empresa} and l.ano_mes = {$ano}{$mes} and l.natureza = 'D' and
			(l.conta like '1110101%' or l.conta like '1110102%'
			or l.conta like '1150301%' or l.conta like '1110103%' or l.conta like '1150101%'
			or l.conta like '1120201%' or l.conta like '1130101%' or l.conta like '1130102%'
			or l.conta like '1130103%' or l.conta like '1130201%' or l.conta like '1140401%'
			or l.conta like '1150102%' or l.conta like '1150201%' or l.conta like '1210101%'
			or l.conta like '1220101%' or l.conta like '1230101%' or l.conta like '1240101%'
			or l.conta like '1230102%' or l.conta like '1240102%' or l.conta like '2150101%'
			or l.conta like '2140101%' or l.conta like '2140102%' or l.conta like '2120101%'
			or l.conta like '2130102%' or l.conta like '2130103%' or l.conta like '2130101%'
			or l.conta like '2170102%' or l.conta like '2220101%' or l.conta like '2210101%'
			or l.conta like '2210102%' or l.conta like '2240101%' or l.conta like '2310101%'
			or l.conta like '2310201%' or l.conta like '2340101%' or l.conta like '2350101%'
			or l.conta like '3110101%' or l.conta like '3110102%' or l.conta like '3110103%'
			or l.conta like '3110201%' or l.conta like '3110202%' or l.conta like '3120101%'
			or l.conta like '3120103%' or l.conta like '3210101%' or l.conta like '3210102%'
			or l.conta like '3210103%' or l.conta like '3210104%' or l.conta like '3220101%'
			or l.conta like '3220102%' or l.conta like '3310101%' or l.conta like '3310102%'
			or l.conta like '3310103%' or l.conta like '3510101%' or l.conta like '3510102%'
			or l.conta like '3410101%' or l.conta like '3410102%' or l.conta in ('1120101001',
			'1120101002','1120101003','1230201001','2110101001','2110101002','2110102002',
			'3610101002','3610101001'))
			group by case
			when l.conta like '1110101%' then substr(l.conta,1,2)
			when l.conta like '1110102%' then substr(l.conta,1,2)
			when l.conta like '1150301%' then substr(l.conta,1,2)
			when l.conta = 1120101002 then substr (l.conta,1,10)
			when l.conta in (1120101001,1120101003) then substr (l.conta,1,9)
			when l.conta like '113%' then substr(l.conta,1,3)
			when l.conta like '1150102%' then substr(l.conta,1,3)
			when l.conta like '11502%' then substr(l.conta,1,3)
			when l.conta like '1230101%' then substr(l.conta,1,3)
			when l.conta = '1230201001' then substr(l.conta,1,3)
			when l.conta = '1120101002' then l.conta
			when l.conta in ('2110101001','2110102002') then substr (l.conta,1,5)
			when l.conta = '2110101002' then substr (l.conta,1,10)
			when l.conta like '2140101%'then substr (l.conta,1,5)
			when l.conta like '2140102%'then substr (l.conta,1,5)
			when l.conta = '2120101005' then substr(l.conta,1,10)
			when l.conta = '2130102001' then substr(l.conta,1,10)
			when l.conta like '2130102%' then substr(l.conta,1,5)
			when l.conta like '2130103%' then substr(l.conta,1,5)
			when l.conta like '311%' then substr(l.conta,1,3)
			when l.conta like '312%' then substr(l.conta,1,3)
			when l.conta like '32101%' then substr(l.conta,1,2)
			when l.conta = '3220102010' then substr(l.conta,1,10)
			when l.conta like '32201%' then substr(l.conta,1,2)
			when l.conta = '3310102018' then substr(l.conta,1,8)
			when l.conta = '3310102083' then substr(l.conta,1,8)
			when l.conta like '3310102%' then substr(l.conta,1,5)
			when l.conta like '3310103%' then substr(l.conta,1,5)
			when l.conta like '35101%' then substr(l.conta,1,5)
			when l.conta = '3610101002' then substr(l.conta,1,10)
			when l.conta = '3610101001' then substr(l.conta,1,10)
			else substr (l.conta,1,7) end,l.natureza) ctb2 on ctb1.conta = ctb2.conta

			left join

			(select case
			when l.conta like '1110101%' then substr(l.conta,1,2)
			when l.conta like '1110102%' then substr(l.conta,1,2)
			when l.conta like '1150301%' then substr(l.conta,1,2)
			when l.conta = 1120101002 then substr (l.conta,1,10)
			when l.conta in (1120101001,1120101003) then substr (l.conta,1,9)
			when l.conta like '113%' then substr(l.conta,1,3)
			when l.conta like '1150102%' then substr(l.conta,1,3)
			when l.conta like '11502%' then substr(l.conta,1,3)
			when l.conta like '1230101%' then substr(l.conta,1,3)
			when l.conta = '1230201001' then substr(l.conta,1,3)
			when l.conta = '1120101002' then l.conta
			when l.conta in ('2110101001','2110102002') then substr (l.conta,1,5)
			when l.conta = '2110101002' then substr (l.conta,1,10)
			when l.conta like '2140101%'then substr (l.conta,1,5)
			when l.conta like '2140102%'then substr (l.conta,1,5)
			when l.conta = '2120101005' then substr(l.conta,1,10)
			when l.conta = '2130102001' then substr(l.conta,1,10)
			when l.conta like '2130102%' then substr(l.conta,1,5)
			when l.conta like '2130103%' then substr(l.conta,1,5)
			when l.conta like '311%' then substr(l.conta,1,3)
			when l.conta like '312%' then substr(l.conta,1,3)
			when l.conta like '32101%' then substr(l.conta,1,2)
			when l.conta = '3220102010' then substr(l.conta,1,10)
			when l.conta like '32201%' then substr(l.conta,1,2)
			when l.conta = '3310102018' then substr(l.conta,1,8)
			when l.conta = '3310102083' then substr(l.conta,1,8)
			when l.conta like '3310102%' then substr(l.conta,1,5)
			when l.conta like '3310103%' then substr(l.conta,1,5)
			when l.conta like '35101%' then substr(l.conta,1,5)
			when l.conta = '3610101002' then substr(l.conta,1,10)
			when l.conta = '3610101001' then substr(l.conta,1,10)
			else substr (l.conta,1,7) end conta,l.natureza, sum(d.val_divisao) credito
			from ctb_lancamento_dividido d, ctb_lancamento l where l.lancamento = d.lancamento
			and l.empresa = d.empresa and l.revenda = d.revenda and l.ano_mes = d.ano_mes
			and l.empresa = {$empresa} and l.ano_mes = {$ano}{$mes} and l.natureza = 'C' and
			(l.conta like '1110101%' or l.conta like '1110102%'
			or l.conta like '1150301%' or l.conta like '1110103%' or l.conta like '1150101%'
			or l.conta like '1120201%' or l.conta like '1130101%' or l.conta like '1130102%'
			or l.conta like '1130103%' or l.conta like '1130201%' or l.conta like '1140401%'
			or l.conta like '1150102%' or l.conta like '1150201%' or l.conta like '1210101%'
			or l.conta like '1220101%' or l.conta like '1230101%' or l.conta like '1240101%'
			or l.conta like '1230102%' or l.conta like '1240102%' or l.conta like '2150101%'
			or l.conta like '2140101%' or l.conta like '2140102%' or l.conta like '2120101%'
			or l.conta like '2130102%' or l.conta like '2130103%' or l.conta like '2130101%'
			or l.conta like '2170102%' or l.conta like '2220101%' or l.conta like '2210101%'
			or l.conta like '2210102%' or l.conta like '2240101%' or l.conta like '2310101%'
			or l.conta like '2310201%' or l.conta like '2340101%' or l.conta like '2350101%'
			or l.conta like '3110101%' or l.conta like '3110102%' or l.conta like '3110103%'
			or l.conta like '3110201%' or l.conta like '3110202%' or l.conta like '3120101%'
			or l.conta like '3120103%' or l.conta like '3210101%' or l.conta like '3210102%'
			or l.conta like '3210103%' or l.conta like '3210104%' or l.conta like '3220101%'
			or l.conta like '3220102%' or l.conta like '3310101%' or l.conta like '3310102%'
			or l.conta like '3310103%' or l.conta like '3510101%' or l.conta like '3510102%'
			or l.conta like '3410101%' or l.conta like '3410102%' or l.conta in ('1120101001',
			'1120101002','1120101003','1230201001','2110101001','2110101002','2110102002',
			'3610101002','3610101001'))
			group by case
			when l.conta like '1110101%' then substr(l.conta,1,2)
			when l.conta like '1110102%' then substr(l.conta,1,2)
			when l.conta like '1150301%' then substr(l.conta,1,2)
			when l.conta = 1120101002 then substr (l.conta,1,10)
			when l.conta in (1120101001,1120101003) then substr (l.conta,1,9)
			when l.conta like '113%' then substr(l.conta,1,3)
			when l.conta like '1150102%' then substr(l.conta,1,3)
			when l.conta like '11502%' then substr(l.conta,1,3)
			when l.conta like '1230101%' then substr(l.conta,1,3)
			when l.conta = '1230201001' then substr(l.conta,1,3)
			when l.conta = '1120101002' then l.conta
			when l.conta in ('2110101001','2110102002') then substr (l.conta,1,5)
			when l.conta = '2110101002' then substr (l.conta,1,10)
			when l.conta like '2140101%'then substr (l.conta,1,5)
			when l.conta like '2140102%'then substr (l.conta,1,5)
			when l.conta = '2120101005' then substr(l.conta,1,10)
			when l.conta = '2130102001' then substr(l.conta,1,10)
			when l.conta like '2130102%' then substr(l.conta,1,5)
			when l.conta like '2130103%' then substr(l.conta,1,5)
			when l.conta like '311%' then substr(l.conta,1,3)
			when l.conta like '312%' then substr(l.conta,1,3)
			when l.conta like '32101%' then substr(l.conta,1,2)
			when l.conta = '3220102010' then substr(l.conta,1,10)
			when l.conta like '32201%' then substr(l.conta,1,2)
			when l.conta = '3310102018' then substr(l.conta,1,8)
			when l.conta = '3310102083' then substr(l.conta,1,8)
			when l.conta like '3310102%' then substr(l.conta,1,5)
			when l.conta like '3310103%' then substr(l.conta,1,5)
			when l.conta like '35101%' then substr(l.conta,1,5)
			when l.conta = '3610101002' then substr(l.conta,1,10)
			when l.conta = '3610101001' then substr(l.conta,1,10)
			else substr (l.conta,1,7) end,l.natureza) ctb3 on ctb1.conta = ctb3.conta

			order by ctb1.ordem");

		}else{

			return $this->Select("select ctb1.ordem ordem, ctb1.conta conta, nvl(ctb2.debito,0) debito,
			nvl(ctb3.credito,0) credito,nvl(ctb2.debito,0) - nvl(ctb3.credito,0) movimento_mes,nvl(ctb2.debito,0) - nvl(ctb3.credito,0) + nvl(ctb1.saldo,0) + nvl(ctb4.debito_anterior,0) - nvl(ctb5.credito_anterior,0) saldo ,
			nvl(ctb1.saldo,0) saldo_ano_anterior

			from

			(select cc.ordem,cc.conta,case when c.saldo <> 0 then c.saldo else cc.saldo
			end saldo from monaco_conta_contabil cc

			left join

			(select case
			when sa.conta like '1110101%' then substr(sa.conta,1,2)
			when sa.conta like '1110102%' then substr(sa.conta,1,2)
			when sa.conta like '1150301%' then substr(sa.conta,1,2)
			when sa.conta = 1120101002 then substr (sa.conta,1,10)
			when sa.conta in (1120101001,1120101003) then substr (sa.conta,1,9)
			when sa.conta like '113%' then substr(sa.conta,1,3)
			when sa.conta like '1150102%' then substr(sa.conta,1,3)
			when sa.conta like '11502%' then substr(sa.conta,1,3)
			when sa.conta like '1230101%' then substr(sa.conta,1,3)
			when sa.conta = '1230201001' then substr(sa.conta,1,3)
			when sa.conta = '1120101002' then sa.conta
			when sa.conta in ('2110101001','2110102002') then substr (sa.conta,1,5)
			when sa.conta = '2110101002' then substr (sa.conta,1,10)
			when sa.conta like '2140101%'then substr (sa.conta,1,5)
			when sa.conta like '2140102%'then substr (sa.conta,1,5)
			when sa.conta = '2120101005' then substr(sa.conta,1,10)
			when sa.conta = '2130102001' then substr(sa.conta,1,10)
			when sa.conta like '2130102%' then substr(sa.conta,1,5)
			when sa.conta like '2130103%' then substr(sa.conta,1,5)
			when sa.conta like '311%' then substr(sa.conta,1,3)
			when sa.conta like '312%' then substr(sa.conta,1,3)
			when sa.conta like '32101%' then substr(sa.conta,1,2)
			when sa.conta = '3220102010' then substr(sa.conta,1,10)
			when sa.conta like '32201%' then substr(sa.conta,1,2)
			when sa.conta = '3310102018' then substr(sa.conta,1,8)
			when sa.conta = '3310102083' then substr(sa.conta,1,8)
			when sa.conta like '3310102%' then substr(sa.conta,1,5)
			when sa.conta like '3310103%' then substr(sa.conta,1,5)
			when sa.conta like '35101%' then substr(sa.conta,1,5)
			when sa.conta = '3610101002' then substr(sa.conta,1,10)
			when sa.conta = '3610101001' then substr(sa.conta,1,10)
			else substr (sa.conta,1,7) end conta, sum(sa.saldo) saldo
			from ctb_saldo_anterior sa where sa.empresa = {$empresa}
			and sa.ano = {$ano_anterior} and (sa.conta like '1110101%' or sa.conta like '1110102%'
			or sa.conta like '1150301%' or sa.conta like '1110103%' or sa.conta like '1150101%'
			or sa.conta like '1120201%' or sa.conta like '1130101%' or sa.conta like '1130102%'
			or sa.conta like '1130103%' or sa.conta like '1130201%' or sa.conta like '1140401%'
			or sa.conta like '1150102%' or sa.conta like '1150201%' or sa.conta like '1210101%'
			or sa.conta like '1220101%' or sa.conta like '1230101%' or sa.conta like '1240101%'
			or sa.conta like '1230102%' or sa.conta like '1240102%' or sa.conta like '2150101%'
			or sa.conta like '2140101%' or sa.conta like '2140102%' or sa.conta like '2120101%'
			or sa.conta like '2130102%' or sa.conta like '2130103%' or sa.conta like '2130101%'
			or sa.conta like '2170102%' or sa.conta like '2220101%' or sa.conta like '2210101%'
			or sa.conta like '2210102%' or sa.conta like '2240101%' or sa.conta like '2310101%'
			or sa.conta like '2310201%' or sa.conta like '2340101%' or sa.conta like '2350101%'
			or sa.conta like '3110101%' or sa.conta like '3110102%' or sa.conta like '3110103%'
			or sa.conta like '3110201%' or sa.conta like '3110202%' or sa.conta like '3120101%'
			or sa.conta like '3120103%' or sa.conta like '3210101%' or sa.conta like '3210102%'
			or sa.conta like '3210103%' or sa.conta like '3210104%' or sa.conta like '3220101%'
			or sa.conta like '3220102%' or sa.conta like '3310101%' or sa.conta like '3310102%'
			or sa.conta like '3310103%' or sa.conta like '3510101%' or sa.conta like '3510102%'
			or sa.conta like '3410101%' or sa.conta like '3410102%' or sa.conta in ('1120101001',
			'1120101002','1120101003','1230201001','2110101001','2110101002','2110102002',
			'3610101002','3610101001')) and sa.conta not in ('1110101','1110102','1150301',
			'1110103','1150101','1120201','1130101','1130102','1130103','1130201','1140401',
			'1150102','1150201','1210101','1220101','1230101','1240101','1230102',1240102,
			'2150101','2140101','2140102','2120101','2130102','2130103','2130101','2170102',
			'2220101','2210101','2210102','2240101','2310101','2310201','2340101','2350101',
			'3110101','3110102','3110103','3110201',3110202,'3120101','3120103','3210101',
			'3210102','3210103','3210104','3220101','3220102','3310101','3310102','3310103',
			'3510101','3510102','3410101','3410102')
			group by case
			when sa.conta like '1110101%' then substr(sa.conta,1,2)
			when sa.conta like '1110102%' then substr(sa.conta,1,2)
			when sa.conta like '1150301%' then substr(sa.conta,1,2)
			when sa.conta = 1120101002 then substr (sa.conta,1,10)
			when sa.conta in (1120101001,1120101003) then substr (sa.conta,1,9)
			when sa.conta like '113%' then substr(sa.conta,1,3)
			when sa.conta like '1150102%' then substr(sa.conta,1,3)
			when sa.conta like '11502%' then substr(sa.conta,1,3)
			when sa.conta like '1230101%' then substr(sa.conta,1,3)
			when sa.conta = '1230201001' then substr(sa.conta,1,3)
			when sa.conta = '1120101002' then sa.conta
			when sa.conta in ('2110101001','2110102002') then substr (sa.conta,1,5)
			when sa.conta = '2110101002' then substr (sa.conta,1,10)
			when sa.conta like '2140101%'then substr (sa.conta,1,5)
			when sa.conta like '2140102%'then substr (sa.conta,1,5)
			when sa.conta = '2120101005' then substr(sa.conta,1,10)
			when sa.conta = '2130102001' then substr(sa.conta,1,10)
			when sa.conta like '2130102%' then substr(sa.conta,1,5)
			when sa.conta like '2130103%' then substr(sa.conta,1,5)
			when sa.conta like '311%' then substr(sa.conta,1,3)
			when sa.conta like '312%' then substr(sa.conta,1,3)
			when sa.conta like '32101%' then substr(sa.conta,1,2)
			when sa.conta = '3220102010' then substr(sa.conta,1,10)
			when sa.conta like '32201%' then substr(sa.conta,1,2)
			when sa.conta = '3310102018' then substr(sa.conta,1,8)
			when sa.conta = '3310102083' then substr(sa.conta,1,8)
			when sa.conta like '3310102%' then substr(sa.conta,1,5)
			when sa.conta like '3310103%' then substr(sa.conta,1,5)
			when sa.conta like '35101%' then substr(sa.conta,1,5)
			when sa.conta = '3610101002' then substr(sa.conta,1,10)
			when sa.conta = '3610101001' then substr(sa.conta,1,10)
			else substr (sa.conta,1,7) end) c on cc.conta = c.conta
			order by cc.ordem )ctb1

			left join

			(select case
			when l.conta like '1110101%' then substr(l.conta,1,2)
			when l.conta like '1110102%' then substr(l.conta,1,2)
			when l.conta like '1150301%' then substr(l.conta,1,2)
			when l.conta = 1120101002 then substr (l.conta,1,10)
			when l.conta in (1120101001,1120101003) then substr (l.conta,1,9)
			when l.conta like '113%' then substr(l.conta,1,3)
			when l.conta like '1150102%' then substr(l.conta,1,3)
			when l.conta like '11502%' then substr(l.conta,1,3)
			when l.conta like '1230101%' then substr(l.conta,1,3)
			when l.conta = '1230201001' then substr(l.conta,1,3)
			when l.conta = '1120101002' then l.conta
			when l.conta in ('2110101001','2110102002') then substr (l.conta,1,5)
			when l.conta = '2110101002' then substr (l.conta,1,10)
			when l.conta like '2140101%'then substr (l.conta,1,5)
			when l.conta like '2140102%'then substr (l.conta,1,5)
			when l.conta = '2120101005' then substr(l.conta,1,10)
			when l.conta = '2130102001' then substr(l.conta,1,10)
			when l.conta like '2130102%' then substr(l.conta,1,5)
			when l.conta like '2130103%' then substr(l.conta,1,5)
			when l.conta like '311%' then substr(l.conta,1,3)
			when l.conta like '312%' then substr(l.conta,1,3)
			when l.conta like '32101%' then substr(l.conta,1,2)
			when l.conta = '3220102010' then substr(l.conta,1,10)
			when l.conta like '32201%' then substr(l.conta,1,2)
			when l.conta = '3310102018' then substr(l.conta,1,8)
			when l.conta = '3310102083' then substr(l.conta,1,8)
			when l.conta like '3310102%' then substr(l.conta,1,5)
			when l.conta like '3310103%' then substr(l.conta,1,5)
			when l.conta like '35101%' then substr(l.conta,1,5)
			when l.conta = '3610101002' then substr(l.conta,1,10)
			when l.conta = '3610101001' then substr(l.conta,1,10)
			else substr (l.conta,1,7) end conta,l.natureza, sum(d.val_divisao) debito
			from ctb_lancamento_dividido d, ctb_lancamento l where l.lancamento = d.lancamento
			and l.empresa = d.empresa and l.revenda = d.revenda and l.ano_mes = d.ano_mes
			and l.empresa = {$empresa} and l.ano_mes = {$ano}{$mes} and l.natureza = 'D' and
			(l.conta like '1110101%' or l.conta like '1110102%'
			or l.conta like '1150301%' or l.conta like '1110103%' or l.conta like '1150101%'
			or l.conta like '1120201%' or l.conta like '1130101%' or l.conta like '1130102%'
			or l.conta like '1130103%' or l.conta like '1130201%' or l.conta like '1140401%'
			or l.conta like '1150102%' or l.conta like '1150201%' or l.conta like '1210101%'
			or l.conta like '1220101%' or l.conta like '1230101%' or l.conta like '1240101%'
			or l.conta like '1230102%' or l.conta like '1240102%' or l.conta like '2150101%'
			or l.conta like '2140101%' or l.conta like '2140102%' or l.conta like '2120101%'
			or l.conta like '2130102%' or l.conta like '2130103%' or l.conta like '2130101%'
			or l.conta like '2170102%' or l.conta like '2220101%' or l.conta like '2210101%'
			or l.conta like '2210102%' or l.conta like '2240101%' or l.conta like '2310101%'
			or l.conta like '2310201%' or l.conta like '2340101%' or l.conta like '2350101%'
			or l.conta like '3110101%' or l.conta like '3110102%' or l.conta like '3110103%'
			or l.conta like '3110201%' or l.conta like '3110202%' or l.conta like '3120101%'
			or l.conta like '3120103%' or l.conta like '3210101%' or l.conta like '3210102%'
			or l.conta like '3210103%' or l.conta like '3210104%' or l.conta like '3220101%'
			or l.conta like '3220102%' or l.conta like '3310101%' or l.conta like '3310102%'
			or l.conta like '3310103%' or l.conta like '3510101%' or l.conta like '3510102%'
			or l.conta like '3410101%' or l.conta like '3410102%' or l.conta in ('1120101001',
			'1120101002','1120101003','1230201001','2110101001','2110101002','2110102002',
			'3610101002','3610101001'))
			group by case
			when l.conta like '1110101%' then substr(l.conta,1,2)
			when l.conta like '1110102%' then substr(l.conta,1,2)
			when l.conta like '1150301%' then substr(l.conta,1,2)
			when l.conta = 1120101002 then substr (l.conta,1,10)
			when l.conta in (1120101001,1120101003) then substr (l.conta,1,9)
			when l.conta like '113%' then substr(l.conta,1,3)
			when l.conta like '1150102%' then substr(l.conta,1,3)
			when l.conta like '11502%' then substr(l.conta,1,3)
			when l.conta like '1230101%' then substr(l.conta,1,3)
			when l.conta = '1230201001' then substr(l.conta,1,3)
			when l.conta = '1120101002' then l.conta
			when l.conta in ('2110101001','2110102002') then substr (l.conta,1,5)
			when l.conta = '2110101002' then substr (l.conta,1,10)
			when l.conta like '2140101%'then substr (l.conta,1,5)
			when l.conta like '2140102%'then substr (l.conta,1,5)
			when l.conta = '2120101005' then substr(l.conta,1,10)
			when l.conta = '2130102001' then substr(l.conta,1,10)
			when l.conta like '2130102%' then substr(l.conta,1,5)
			when l.conta like '2130103%' then substr(l.conta,1,5)
			when l.conta like '311%' then substr(l.conta,1,3)
			when l.conta like '312%' then substr(l.conta,1,3)
			when l.conta like '32101%' then substr(l.conta,1,2)
			when l.conta = '3220102010' then substr(l.conta,1,10)
			when l.conta like '32201%' then substr(l.conta,1,2)
			when l.conta = '3310102018' then substr(l.conta,1,8)
			when l.conta = '3310102083' then substr(l.conta,1,8)
			when l.conta like '3310102%' then substr(l.conta,1,5)
			when l.conta like '3310103%' then substr(l.conta,1,5)
			when l.conta like '35101%' then substr(l.conta,1,5)
			when l.conta = '3610101002' then substr(l.conta,1,10)
			when l.conta = '3610101001' then substr(l.conta,1,10)
			else substr (l.conta,1,7) end,l.natureza) ctb2 on ctb1.conta = ctb2.conta

			left join

			(select case
			when l.conta like '1110101%' then substr(l.conta,1,2)
			when l.conta like '1110102%' then substr(l.conta,1,2)
			when l.conta like '1150301%' then substr(l.conta,1,2)
			when l.conta = 1120101002 then substr (l.conta,1,10)
			when l.conta in (1120101001,1120101003) then substr (l.conta,1,9)
			when l.conta like '113%' then substr(l.conta,1,3)
			when l.conta like '1150102%' then substr(l.conta,1,3)
			when l.conta like '11502%' then substr(l.conta,1,3)
			when l.conta like '1230101%' then substr(l.conta,1,3)
			when l.conta = '1230201001' then substr(l.conta,1,3)
			when l.conta = '1120101002' then l.conta
			when l.conta in ('2110101001','2110102002') then substr (l.conta,1,5)
			when l.conta = '2110101002' then substr (l.conta,1,10)
			when l.conta like '2140101%'then substr (l.conta,1,5)
			when l.conta like '2140102%'then substr (l.conta,1,5)
			when l.conta = '2120101005' then substr(l.conta,1,10)
			when l.conta = '2130102001' then substr(l.conta,1,10)
			when l.conta like '2130102%' then substr(l.conta,1,5)
			when l.conta like '2130103%' then substr(l.conta,1,5)
			when l.conta like '311%' then substr(l.conta,1,3)
			when l.conta like '312%' then substr(l.conta,1,3)
			when l.conta like '32101%' then substr(l.conta,1,2)
			when l.conta = '3220102010' then substr(l.conta,1,10)
			when l.conta like '32201%' then substr(l.conta,1,2)
			when l.conta = '3310102018' then substr(l.conta,1,8)
			when l.conta = '3310102083' then substr(l.conta,1,8)
			when l.conta like '3310102%' then substr(l.conta,1,5)
			when l.conta like '3310103%' then substr(l.conta,1,5)
			when l.conta like '35101%' then substr(l.conta,1,5)
			when l.conta = '3610101002' then substr(l.conta,1,10)
			when l.conta = '3610101001' then substr(l.conta,1,10)
			else substr (l.conta,1,7) end conta,l.natureza, sum(d.val_divisao) credito
			from ctb_lancamento_dividido d, ctb_lancamento l where l.lancamento = d.lancamento
			and l.empresa = d.empresa and l.revenda = d.revenda and l.ano_mes = d.ano_mes
			and l.empresa = {$empresa} and l.ano_mes = {$ano}{$mes} and l.natureza = 'C' and
			(l.conta like '1110101%' or l.conta like '1110102%'
			or l.conta like '1150301%' or l.conta like '1110103%' or l.conta like '1150101%'
			or l.conta like '1120201%' or l.conta like '1130101%' or l.conta like '1130102%'
			or l.conta like '1130103%' or l.conta like '1130201%' or l.conta like '1140401%'
			or l.conta like '1150102%' or l.conta like '1150201%' or l.conta like '1210101%'
			or l.conta like '1220101%' or l.conta like '1230101%' or l.conta like '1240101%'
			or l.conta like '1230102%' or l.conta like '1240102%' or l.conta like '2150101%'
			or l.conta like '2140101%' or l.conta like '2140102%' or l.conta like '2120101%'
			or l.conta like '2130102%' or l.conta like '2130103%' or l.conta like '2130101%'
			or l.conta like '2170102%' or l.conta like '2220101%' or l.conta like '2210101%'
			or l.conta like '2210102%' or l.conta like '2240101%' or l.conta like '2310101%'
			or l.conta like '2310201%' or l.conta like '2340101%' or l.conta like '2350101%'
			or l.conta like '3110101%' or l.conta like '3110102%' or l.conta like '3110103%'
			or l.conta like '3110201%' or l.conta like '3110202%' or l.conta like '3120101%'
			or l.conta like '3120103%' or l.conta like '3210101%' or l.conta like '3210102%'
			or l.conta like '3210103%' or l.conta like '3210104%' or l.conta like '3220101%'
			or l.conta like '3220102%' or l.conta like '3310101%' or l.conta like '3310102%'
			or l.conta like '3310103%' or l.conta like '3510101%' or l.conta like '3510102%'
			or l.conta like '3410101%' or l.conta like '3410102%' or l.conta in ('1120101001',
			'1120101002','1120101003','1230201001','2110101001','2110101002','2110102002',
			'3610101002','3610101001'))
			group by case
			when l.conta like '1110101%' then substr(l.conta,1,2)
			when l.conta like '1110102%' then substr(l.conta,1,2)
			when l.conta like '1150301%' then substr(l.conta,1,2)
			when l.conta = 1120101002 then substr (l.conta,1,10)
			when l.conta in (1120101001,1120101003) then substr (l.conta,1,9)
			when l.conta like '113%' then substr(l.conta,1,3)
			when l.conta like '1150102%' then substr(l.conta,1,3)
			when l.conta like '11502%' then substr(l.conta,1,3)
			when l.conta like '1230101%' then substr(l.conta,1,3)
			when l.conta = '1230201001' then substr(l.conta,1,3)
			when l.conta = '1120101002' then l.conta
			when l.conta in ('2110101001','2110102002') then substr (l.conta,1,5)
			when l.conta = '2110101002' then substr (l.conta,1,10)
			when l.conta like '2140101%'then substr (l.conta,1,5)
			when l.conta like '2140102%'then substr (l.conta,1,5)
			when l.conta = '2120101005' then substr(l.conta,1,10)
			when l.conta = '2130102001' then substr(l.conta,1,10)
			when l.conta like '2130102%' then substr(l.conta,1,5)
			when l.conta like '2130103%' then substr(l.conta,1,5)
			when l.conta like '311%' then substr(l.conta,1,3)
			when l.conta like '312%' then substr(l.conta,1,3)
			when l.conta like '32101%' then substr(l.conta,1,2)
			when l.conta = '3220102010' then substr(l.conta,1,10)
			when l.conta like '32201%' then substr(l.conta,1,2)
			when l.conta = '3310102018' then substr(l.conta,1,8)
			when l.conta = '3310102083' then substr(l.conta,1,8)
			when l.conta like '3310102%' then substr(l.conta,1,5)
			when l.conta like '3310103%' then substr(l.conta,1,5)
			when l.conta like '35101%' then substr(l.conta,1,5)
			when l.conta = '3610101002' then substr(l.conta,1,10)
			when l.conta = '3610101001' then substr(l.conta,1,10)
			else substr (l.conta,1,7) end,l.natureza) ctb3 on ctb1.conta = ctb3.conta

			left join

			(select case
			when l.conta like '1110101%' then substr(l.conta,1,2)
			when l.conta like '1110102%' then substr(l.conta,1,2)
			when l.conta like '1150301%' then substr(l.conta,1,2)
			when l.conta = 1120101002 then substr (l.conta,1,10)
			when l.conta in (1120101001,1120101003) then substr (l.conta,1,9)
			when l.conta like '113%' then substr(l.conta,1,3)
			when l.conta like '1150102%' then substr(l.conta,1,3)
			when l.conta like '11502%' then substr(l.conta,1,3)
			when l.conta like '1230101%' then substr(l.conta,1,3)
			when l.conta = '1230201001' then substr(l.conta,1,3)
			when l.conta = '1120101002' then l.conta
			when l.conta in ('2110101001','2110102002') then substr (l.conta,1,5)
			when l.conta = '2110101002' then substr (l.conta,1,10)
			when l.conta like '2140101%'then substr (l.conta,1,5)
			when l.conta like '2140102%'then substr (l.conta,1,5)
			when l.conta = '2120101005' then substr(l.conta,1,10)
			when l.conta = '2130102001' then substr(l.conta,1,10)
			when l.conta like '2130102%' then substr(l.conta,1,5)
			when l.conta like '2130103%' then substr(l.conta,1,5)
			when l.conta like '311%' then substr(l.conta,1,3)
			when l.conta like '312%' then substr(l.conta,1,3)
			when l.conta like '32101%' then substr(l.conta,1,2)
			when l.conta = '3220102010' then substr(l.conta,1,10)
			when l.conta like '32201%' then substr(l.conta,1,2)
			when l.conta = '3310102018' then substr(l.conta,1,8)
			when l.conta = '3310102083' then substr(l.conta,1,8)
			when l.conta like '3310102%' then substr(l.conta,1,5)
			when l.conta like '3310103%' then substr(l.conta,1,5)
			when l.conta like '35101%' then substr(l.conta,1,5)
			when l.conta = '3610101002' then substr(l.conta,1,10)
			when l.conta = '3610101001' then substr(l.conta,1,10)
			else substr (l.conta,1,7) end conta,l.natureza, sum(d.val_divisao) debito_anterior
			from ctb_lancamento_dividido d, ctb_lancamento l where l.lancamento = d.lancamento
			and l.empresa = d.empresa and l.revenda = d.revenda and l.ano_mes = d.ano_mes
			and l.empresa = {$empresa} and l.ano_mes between {$ano}01 and {$ano}{$mes_anterior}
			and l.natureza = 'D' and (l.conta like '1110101%' or l.conta like '1110102%'
			or l.conta like '1150301%' or l.conta like '1110103%' or l.conta like '1150101%'
			or l.conta like '1120201%' or l.conta like '1130101%' or l.conta like '1130102%'
			or l.conta like '1130103%' or l.conta like '1130201%' or l.conta like '1140401%'
			or l.conta like '1150102%' or l.conta like '1150201%' or l.conta like '1210101%'
			or l.conta like '1220101%' or l.conta like '1230101%' or l.conta like '1240101%'
			or l.conta like '1230102%' or l.conta like '1240102%' or l.conta like '2150101%'
			or l.conta like '2140101%' or l.conta like '2140102%' or l.conta like '2120101%'
			or l.conta like '2130102%' or l.conta like '2130103%' or l.conta like '2130101%'
			or l.conta like '2170102%' or l.conta like '2220101%' or l.conta like '2210101%'
			or l.conta like '2210102%' or l.conta like '2240101%' or l.conta like '2310101%'
			or l.conta like '2310201%' or l.conta like '2340101%' or l.conta like '2350101%'
			or l.conta like '3110101%' or l.conta like '3110102%' or l.conta like '3110103%'
			or l.conta like '3110201%' or l.conta like '3110202%' or l.conta like '3120101%'
			or l.conta like '3120103%' or l.conta like '3210101%' or l.conta like '3210102%'
			or l.conta like '3210103%' or l.conta like '3210104%' or l.conta like '3220101%'
			or l.conta like '3220102%' or l.conta like '3310101%' or l.conta like '3310102%'
			or l.conta like '3310103%' or l.conta like '3510101%' or l.conta like '3510102%'
			or l.conta like '3410101%' or l.conta like '3410102%' or l.conta in ('1120101001',
			'1120101002','1120101003','1230201001','2110101001','2110101002','2110102002',
			'3610101002','3610101001'))
			group by case
			when l.conta like '1110101%' then substr(l.conta,1,2)
			when l.conta like '1110102%' then substr(l.conta,1,2)
			when l.conta like '1150301%' then substr(l.conta,1,2)
			when l.conta = 1120101002 then substr (l.conta,1,10)
			when l.conta in (1120101001,1120101003) then substr (l.conta,1,9)
			when l.conta like '113%' then substr(l.conta,1,3)
			when l.conta like '1150102%' then substr(l.conta,1,3)
			when l.conta like '11502%' then substr(l.conta,1,3)
			when l.conta like '1230101%' then substr(l.conta,1,3)
			when l.conta = '1230201001' then substr(l.conta,1,3)
			when l.conta = '1120101002' then l.conta
			when l.conta in ('2110101001','2110102002') then substr (l.conta,1,5)
			when l.conta = '2110101002' then substr (l.conta,1,10)
			when l.conta like '2140101%'then substr (l.conta,1,5)
			when l.conta like '2140102%'then substr (l.conta,1,5)
			when l.conta = '2120101005' then substr(l.conta,1,10)
			when l.conta = '2130102001' then substr(l.conta,1,10)
			when l.conta like '2130102%' then substr(l.conta,1,5)
			when l.conta like '2130103%' then substr(l.conta,1,5)
			when l.conta like '311%' then substr(l.conta,1,3)
			when l.conta like '312%' then substr(l.conta,1,3)
			when l.conta like '32101%' then substr(l.conta,1,2)
			when l.conta = '3220102010' then substr(l.conta,1,10)
			when l.conta like '32201%' then substr(l.conta,1,2)
			when l.conta = '3310102018' then substr(l.conta,1,8)
			when l.conta = '3310102083' then substr(l.conta,1,8)
			when l.conta like '3310102%' then substr(l.conta,1,5)
			when l.conta like '3310103%' then substr(l.conta,1,5)
			when l.conta like '35101%' then substr(l.conta,1,5)
			when l.conta = '3610101002' then substr(l.conta,1,10)
			when l.conta = '3610101001' then substr(l.conta,1,10)
			else substr (l.conta,1,7) end,l.natureza) ctb4 on ctb1.conta = ctb4.conta

			left join

			(select case
			when l.conta like '1110101%' then substr(l.conta,1,2)
			when l.conta like '1110102%' then substr(l.conta,1,2)
			when l.conta like '1150301%' then substr(l.conta,1,2)
			when l.conta = 1120101002 then substr (l.conta,1,10)
			when l.conta in (1120101001,1120101003) then substr (l.conta,1,9)
			when l.conta like '113%' then substr(l.conta,1,3)
			when l.conta like '1150102%' then substr(l.conta,1,3)
			when l.conta like '11502%' then substr(l.conta,1,3)
			when l.conta like '1230101%' then substr(l.conta,1,3)
			when l.conta = '1230201001' then substr(l.conta,1,3)
			when l.conta = '1120101002' then l.conta
			when l.conta in ('2110101001','2110102002') then substr (l.conta,1,5)
			when l.conta = '2110101002' then substr (l.conta,1,10)
			when l.conta like '2140101%'then substr (l.conta,1,5)
			when l.conta like '2140102%'then substr (l.conta,1,5)
			when l.conta = '2120101005' then substr(l.conta,1,10)
			when l.conta = '2130102001' then substr(l.conta,1,10)
			when l.conta like '2130102%' then substr(l.conta,1,5)
			when l.conta like '2130103%' then substr(l.conta,1,5)
			when l.conta like '311%' then substr(l.conta,1,3)
			when l.conta like '312%' then substr(l.conta,1,3)
			when l.conta like '32101%' then substr(l.conta,1,2)
			when l.conta = '3220102010' then substr(l.conta,1,10)
			when l.conta like '32201%' then substr(l.conta,1,2)
			when l.conta = '3310102018' then substr(l.conta,1,8)
			when l.conta = '3310102083' then substr(l.conta,1,8)
			when l.conta like '3310102%' then substr(l.conta,1,5)
			when l.conta like '3310103%' then substr(l.conta,1,5)
			when l.conta like '35101%' then substr(l.conta,1,5)
			when l.conta = '3610101002' then substr(l.conta,1,10)
			when l.conta = '3610101001' then substr(l.conta,1,10)
			else substr (l.conta,1,7) end conta,l.natureza, sum(d.val_divisao) credito_anterior
			from ctb_lancamento_dividido d, ctb_lancamento l where l.lancamento = d.lancamento
			and l.empresa = d.empresa and l.revenda = d.revenda and l.ano_mes = d.ano_mes
			and l.empresa = {$empresa} and l.ano_mes between {$ano}01 and {$ano}{$mes_anterior}
			and l.natureza = 'C' and (l.conta like '1110101%' or l.conta like '1110102%'
			or l.conta like '1150301%' or l.conta like '1110103%' or l.conta like '1150101%'
			or l.conta like '1120201%' or l.conta like '1130101%' or l.conta like '1130102%'
			or l.conta like '1130103%' or l.conta like '1130201%' or l.conta like '1140401%'
			or l.conta like '1150102%' or l.conta like '1150201%' or l.conta like '1210101%'
			or l.conta like '1220101%' or l.conta like '1230101%' or l.conta like '1240101%'
			or l.conta like '1230102%' or l.conta like '1240102%' or l.conta like '2150101%'
			or l.conta like '2140101%' or l.conta like '2140102%' or l.conta like '2120101%'
			or l.conta like '2130102%' or l.conta like '2130103%' or l.conta like '2130101%'
			or l.conta like '2170102%' or l.conta like '2220101%' or l.conta like '2210101%'
			or l.conta like '2210102%' or l.conta like '2240101%' or l.conta like '2310101%'
			or l.conta like '2310201%' or l.conta like '2340101%' or l.conta like '2350101%'
			or l.conta like '3110101%' or l.conta like '3110102%' or l.conta like '3110103%'
			or l.conta like '3110201%' or l.conta like '3110202%' or l.conta like '3120101%'
			or l.conta like '3120103%' or l.conta like '3210101%' or l.conta like '3210102%'
			or l.conta like '3210103%' or l.conta like '3210104%' or l.conta like '3220101%'
			or l.conta like '3220102%' or l.conta like '3310101%' or l.conta like '3310102%'
			or l.conta like '3310103%' or l.conta like '3510101%' or l.conta like '3510102%'
			or l.conta like '3410101%' or l.conta like '3410102%' or l.conta in ('1120101001',
			'1120101002','1120101003','1230201001','2110101001','2110101002','2110102002',
			'3610101002','3610101001'))
			group by case
			when l.conta like '1110101%' then substr(l.conta,1,2)
			when l.conta like '1110102%' then substr(l.conta,1,2)
			when l.conta like '1150301%' then substr(l.conta,1,2)
			when l.conta = 1120101002 then substr (l.conta,1,10)
			when l.conta in (1120101001,1120101003) then substr (l.conta,1,9)
			when l.conta like '113%' then substr(l.conta,1,3)
			when l.conta like '1150102%' then substr(l.conta,1,3)
			when l.conta like '11502%' then substr(l.conta,1,3)
			when l.conta like '1230101%' then substr(l.conta,1,3)
			when l.conta = '1230201001' then substr(l.conta,1,3)
			when l.conta = '1120101002' then l.conta
			when l.conta in ('2110101001','2110102002') then substr (l.conta,1,5)
			when l.conta = '2110101002' then substr (l.conta,1,10)
			when l.conta like '2140101%'then substr (l.conta,1,5)
			when l.conta like '2140102%'then substr (l.conta,1,5)
			when l.conta = '2120101005' then substr(l.conta,1,10)
			when l.conta = '2130102001' then substr(l.conta,1,10)
			when l.conta like '2130102%' then substr(l.conta,1,5)
			when l.conta like '2130103%' then substr(l.conta,1,5)
			when l.conta like '311%' then substr(l.conta,1,3)
			when l.conta like '312%' then substr(l.conta,1,3)
			when l.conta like '32101%' then substr(l.conta,1,2)
			when l.conta = '3220102010' then substr(l.conta,1,10)
			when l.conta like '32201%' then substr(l.conta,1,2)
			when l.conta = '3310102018' then substr(l.conta,1,8)
			when l.conta = '3310102083' then substr(l.conta,1,8)
			when l.conta like '3310102%' then substr(l.conta,1,5)
			when l.conta like '3310103%' then substr(l.conta,1,5)
			when l.conta like '35101%' then substr(l.conta,1,5)
			when l.conta = '3610101002' then substr(l.conta,1,10)
			when l.conta = '3610101001' then substr(l.conta,1,10)
			else substr (l.conta,1,7) end,l.natureza) ctb5 on ctb1.conta = ctb5.conta

			order by ctb1.ordem");
		}
	}
}