<?php

namespace api\monaco;

use lib\Model;
use helper\PrepareSQL;
use obj\monaco\Notafiscal;
use helper\Funcoes;

class apiNotafiscal extends Model {

	public function getNotafiscal(Notafiscal $obj) {
		return $this->First($this->Select("SELECT * FROM monaco_nota_fiscal WHERE cliente = '{$obj->cliente}' AND n_nota = '{$obj->n_nota}' AND s_nota = '{$obj->s_nota}' AND empresa = '{$obj->empresa}'"));
	}

	public function filtroNotafiscal($empresa, $c, $de, $ate, $coluna = NULL, $val = NULL) {
		$funcoes = new Funcoes();
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		$condicao = array(
			'1'	=> "LOWER(nf.{$coluna}) = '{$val}' AND to_date(nf.dta_entrada, 'dd/mm/yyyy hh24:mi:ss') BETWEEN to_date('{$de} 00:00:00','dd/mm/yyyy hh24:mi:ss') AND
			to_date('{$ate} 23:59:59','dd/mm/yyyy hh24:mi:ss')",
			'2' => "LOWER(nf.{$coluna}) LIKE '%{$val}%' ",
			'3'	=> "to_date(nf.dta_entrada, 'dd/mm/yyyy hh24:mi:ss') BETWEEN to_date('{$de} 00:00:00','dd/mm/yyyy hh24:mi:ss') AND
			to_date('{$ate} 23:59:59','dd/mm/yyyy hh24:mi:ss') ",
			'4' => " "
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT nf.cliente, nf.n_nota, nf.s_nota, nf.empresa, 
		nf.dta_entrada, nf.usuario,nf.situacao
		FROM monaco_nota_fiscal nf WHERE nf.empresa = '{$empresa}' AND {$condicao[$c]}
		ORDER BY to_date(nf.dta_entrada, 'dd/mm/yyyy hh24:mi:ss') DESC) R ) R2");
	}

	public function addNotafiscal(Notafiscal $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$obj = array_filter($obj, function($v){return $v != 'anexo';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareInsert($obj, 'monaco_nota_fiscal');
	}

	public function editNotafiscal($cliente,$nota,$serie,Notafiscal $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$obj = array_filter($obj, function($v){return $v != 'anexo';}, ARRAY_FILTER_USE_KEY);
		
		return $prepare->PrepareUpdate($obj,array('cliente' => $cliente, 'n_nota' => $nota, 's_nota' => $serie, 'empresa' => $obj['empresa']), 'monaco_nota_fiscal');			
	}

	public function delNotafiscal(Notafiscal $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('cliente' => $obj->cliente, 'n_nota' => $obj->n_nota, 's_nota' => $obj->s_nota, 'empresa' => $obj->empresa), 'monaco_nota_fiscal');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}