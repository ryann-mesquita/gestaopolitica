<?php

namespace api\monaco;

use lib\Model;
use obj\monaco\Respostaformulario;
use helper\PrepareSQL;
use obj\monaco\Sugestao;

class apiPesquisaclima extends Model {

	public function getFormulariopergunta($formulario) {
		return $this->Select("SELECT fp.formulario, fp.ordem_pergunta, fp.pergunta,
		p.des_pergunta 
		FROM psc_formulario_pergunta fp
		JOIN psc_pergunta p ON fp.pergunta = p.pergunta
		WHERE fp.formulario = '{$formulario}' ORDER BY fp.ordem_pergunta ASC");
	}
	
	public function getPerguntaresposta() {
		return $this->Select("SELECT pr.pergunta, pr.ordem_resposta, pr.resposta,
		r.des_resposta
		FROM psc_pergunta_resposta pr
		JOIN psc_resposta r ON pr.resposta = r.resposta
		ORDER BY pr.ordem_resposta ASC");
	}
	
	public function getRespostaformulario($usuario, $ano) {
		return $this->Select("SELECT rf.usuario, rf.formulario, f.formulario, rf.pergunta, p.pergunta,
		rf.resposta, r.resposta, rf.empresa, e.des_empresa, rf.dta_resposta
		FROM psc_resposta_formulario rf
		JOIN psc_formulario f ON rf.formulario = f.formulario
		JOIN psc_pergunta p ON rf.pergunta = p.pergunta
		JOIN psc_resposta r ON rf.resposta = r.resposta
		JOIN sis_empresa e ON rf.empresa = e.empresa
		WHERE rf.usuario = '{$usuario}' and to_char(to_date(rf.dta_Resposta, 'dd/mm/yyyy hh24:mi:ss'), 'yyyy') = '{$ano}'");
	}
	
	public function getArea() {
		return $this->Select("SELECT * FROM sis_area WHERE ativo = '1' ORDER BY area");
	}
	
	public function getPesquisa($ano) {
		return $this->Select("SELECT p1.ano,p1.empresa,p1.des_empresa, p1.area, p1.des_area, p1.topico, p1.des_topico, 
	    p1.pergunta, p1.des_pergunta, p1.resposta, p1.des_resposta, p1.ea_quantidade, 
	    (p1.ea_satisfacao_topico /p5.total) ea_satisfacao_topico, p1.ea_satisfacao_pergunta, p2.e_quantidade, 
	    (p2.e_satisfacao_topico /p5.total) e_satisfacao_topico,
	    p2.e_satisfacao_pergunta, p3.ga_quantidade, 
	    (p3.ga_satisfacao_topico /p5.total) ga_satisfacao_topico, 
        p3.ga_satisfacao_pergunta,
	    p4.g_quantidade, (p4.g_satisfacao_topico / p5.total) g_satisfacao_topico, 
	    p4.g_satisfacao_pergunta
	    
	    FROM
      
      (SELECT p1.ano,p1.empresa,p1.des_empresa, p1.area, p1.des_area, p1.topico, p2.des_topico, 
      p1.pergunta, p3.des_pergunta, p1.resposta, p1.des_resposta, p1.qtd ea_quantidade, 
      p2.qtd ea_satisfacao_topico, p3.qtd ea_satisfacao_pergunta 
      FROM
      (SELECT rf.ano,rf.empresa,e.des_empresa,rf.area,a.des_area,t.topico,rf.pergunta,r.des_resposta,
      rf.resposta,count(rf.resposta) qtd
      FROM psc_resposta_formulario rf
      JOIN Psc_Resposta r ON rf.resposta = r.resposta
      JOIN psc_pergunta p ON rf.pergunta = p.pergunta
      JOIN psc_topico t ON p.topico = t.topico
      JOIN sis_usuario u ON rf.usuario = u.usuario
      JOIN sis_empresa e ON rf.empresa = e.empresa
      JOIN sis_area a ON rf.area = a.area
      JOIN psc_formulario_pergunta fp ON rf.pergunta = fp.pergunta
      GROUP BY rf.ano,rf.empresa,e.des_empresa,rf.area,a.des_area,t.topico,fp.ordem_pergunta,rf.pergunta,rf.resposta,r.des_resposta) p1
      JOIN
      (SELECT rf.ano,rf.empresa,rf.area,t.topico,t.des_topico,count(r.val_resposta) qtd,r.val_resposta 
      FROM psc_resposta_formulario rf
      JOIN psc_pergunta p ON rf.pergunta = p.pergunta
      JOIN psc_topico t ON p.topico = t.topico
      JOIN psc_resposta r ON rf.resposta = r.resposta
      JOIN sis_empresa e ON rf.empresa = e.empresa
      WHERE r.val_resposta = 'P' 
      GROUP BY rf.ano,rf.empresa,rf.area,t.topico,t.des_topico,r.val_resposta) p2 ON p1.ano = p2.ano AND p1.empresa = p2.empresa AND p1.area = p2.area AND p1.topico = p2.topico
      JOIN
      (SELECT rf.ano,rf.empresa,rf.area,p.pergunta,p.des_pergunta,count(r.val_resposta) qtd,r.val_resposta 
      FROM psc_resposta_formulario rf
      JOIN psc_pergunta p ON rf.pergunta = p.pergunta
      JOIN psc_topico t ON p.topico = t.topico
      JOIN psc_resposta r ON rf.resposta = r.resposta
      JOIN sis_empresa e ON rf.empresa = e.empresa
      WHERE r.val_resposta = 'P' 
      GROUP BY rf.ano,rf.empresa,rf.area,p.pergunta,p.des_pergunta,r.val_resposta) p3 ON p1.ano = p3.ano AND p1.empresa = p3.empresa AND p1.area = p3.area AND p1.pergunta = p3.pergunta) p1
      
      JOIN
      
      (SELECT p1.ano,p1.empresa,p1.des_empresa, p1.topico, p2.des_topico, 
      p1.pergunta, p3.des_pergunta, p1.resposta, p1.des_resposta, p1.qtd e_quantidade, 
      p2.qtd e_satisfacao_topico, p3.qtd e_satisfacao_pergunta 
      FROM
      (SELECT rf.ano,rf.empresa,e.des_empresa,t.topico,rf.pergunta,r.des_resposta,
      rf.resposta,count(rf.resposta) qtd
      FROM psc_resposta_formulario rf
      JOIN Psc_Resposta r ON rf.resposta = r.resposta
      JOIN psc_pergunta p ON rf.pergunta = p.pergunta
      JOIN psc_topico t ON p.topico = t.topico
      JOIN sis_empresa e ON rf.empresa = e.empresa
      JOIN psc_formulario_pergunta fp ON rf.pergunta = fp.pergunta
      GROUP BY rf.ano,rf.empresa,e.des_empresa,t.topico,fp.ordem_pergunta,rf.pergunta,rf.resposta,r.des_resposta) p1
      JOIN
      (SELECT rf.ano,rf.empresa,t.topico,t.des_topico,count(r.val_resposta) qtd,r.val_resposta 
      FROM psc_resposta_formulario rf
      JOIN psc_pergunta p ON rf.pergunta = p.pergunta
      JOIN psc_topico t ON p.topico = t.topico
      JOIN psc_resposta r ON rf.resposta = r.resposta
      JOIN sis_empresa e ON rf.empresa = e.empresa
      WHERE r.val_resposta = 'P' 
      GROUP BY rf.ano,rf.empresa,t.topico,t.des_topico,r.val_resposta) p2 ON p1.ano = p2.ano AND p1.empresa = p2.empresa AND p1.topico = p2.topico
      JOIN
      (SELECT rf.ano,rf.empresa,p.pergunta,p.des_pergunta,count(r.val_resposta) qtd,r.val_resposta 
      FROM psc_resposta_formulario rf
      JOIN psc_pergunta p ON rf.pergunta = p.pergunta
      JOIN psc_topico t ON p.topico = t.topico
      JOIN psc_resposta r ON rf.resposta = r.resposta
      JOIN sis_empresa e ON rf.empresa = e.empresa
      WHERE r.val_resposta = 'P' 
      GROUP BY rf.ano,rf.empresa,p.pergunta,p.des_pergunta,r.val_resposta) p3 ON p1.ano = p3.ano AND p1.empresa = p3.empresa AND p1.pergunta = p3.pergunta) p2 
      ON p1.ano = p2.ano AND p1.empresa = p2.empresa AND p1.topico = p2.topico AND p1.pergunta  = p2.pergunta AND p1.resposta = p2.resposta
      
      JOIN
      
      (SELECT p1.ano,p1.area, p1.des_area, p1.topico, p2.des_topico, 
      p1.pergunta, p3.des_pergunta, p1.resposta, p1.des_resposta, p1.qtd ga_quantidade, 
      p2.qtd ga_satisfacao_topico, p3.qtd ga_satisfacao_pergunta 
      FROM
      (SELECT rf.ano,rf.area,a.des_area,t.topico,rf.pergunta,r.des_resposta,
      rf.resposta,count(rf.resposta) qtd
      FROM psc_resposta_formulario rf
      JOIN Psc_Resposta r ON rf.resposta = r.resposta
      JOIN psc_pergunta p ON rf.pergunta = p.pergunta
      JOIN psc_topico t ON p.topico = t.topico
      JOIN sis_usuario u ON rf.usuario = u.usuario
      JOIN sis_area a ON rf.area = a.area
      JOIN psc_formulario_pergunta fp ON rf.pergunta = fp.pergunta
      GROUP BY rf.ano,rf.area,a.des_area,t.topico,fp.ordem_pergunta,rf.pergunta,rf.resposta,r.des_resposta) p1
      JOIN
      (SELECT rf.ano,rf.area,t.topico,t.des_topico,count(r.val_resposta) qtd,r.val_resposta 
      FROM psc_resposta_formulario rf
      JOIN psc_pergunta p ON rf.pergunta = p.pergunta
      JOIN psc_topico t ON p.topico = t.topico
      JOIN psc_resposta r ON rf.resposta = r.resposta
      WHERE r.val_resposta = 'P' 
      GROUP BY rf.ano,rf.area,t.topico,t.des_topico,r.val_resposta) p2 ON p1.ano = p2.ano AND p1.area = p2.area AND p1.topico = p2.topico
      JOIN
      (SELECT rf.ano,rf.area,p.pergunta,p.des_pergunta,count(r.val_resposta) qtd,r.val_resposta 
      FROM psc_resposta_formulario rf
      JOIN psc_pergunta p ON rf.pergunta = p.pergunta
      JOIN psc_topico t ON p.topico = t.topico
      JOIN psc_resposta r ON rf.resposta = r.resposta
      JOIN sis_empresa e ON rf.empresa = e.empresa
      WHERE r.val_resposta = 'P' 
      GROUP BY rf.ano,rf.area,p.pergunta,p.des_pergunta,r.val_resposta) p3 ON p1.ano = p3.ano AND p1.area = p3.area AND p1.pergunta = p3.pergunta) p3 
      ON p1.ano = p3.ano AND p1.area = p3.area AND p1.topico = p3.topico AND p1.pergunta  = p3.pergunta AND p1.resposta = p3.resposta
      
      JOIN
      
      (SELECT p1.ano,p1.topico, p2.des_topico, 
      p1.pergunta, p3.des_pergunta, p1.resposta, p1.des_resposta, p1.qtd g_quantidade, 
      p2.qtd g_satisfacao_topico, p3.qtd g_satisfacao_pergunta 
      FROM
      (SELECT rf.ano,t.topico,rf.pergunta,r.des_resposta,
      rf.resposta,count(rf.resposta) qtd
      FROM psc_resposta_formulario rf
      JOIN Psc_Resposta r ON rf.resposta = r.resposta
      JOIN psc_pergunta p ON rf.pergunta = p.pergunta
      JOIN psc_topico t ON p.topico = t.topico
      JOIN psc_formulario_pergunta fp ON rf.pergunta = fp.pergunta
      GROUP BY rf.ano,t.topico,fp.ordem_pergunta,rf.pergunta,rf.resposta,r.des_resposta) p1
      JOIN
      (SELECT rf.ano,t.topico,t.des_topico,count(r.val_resposta) qtd,r.val_resposta 
      FROM psc_resposta_formulario rf
      JOIN psc_pergunta p ON rf.pergunta = p.pergunta
      JOIN psc_topico t ON p.topico = t.topico
      JOIN psc_resposta r ON rf.resposta = r.resposta
      WHERE r.val_resposta = 'P' 
      GROUP BY rf.ano,t.topico,t.des_topico,r.val_resposta) p2 ON p1.ano = p2.ano AND p1.topico = p2.topico
      JOIN
      (SELECT rf.ano,p.pergunta,p.des_pergunta,count(r.val_resposta) qtd,r.val_resposta 
      FROM psc_resposta_formulario rf
      JOIN psc_pergunta p ON rf.pergunta = p.pergunta
      JOIN psc_topico t ON p.topico = t.topico
      JOIN psc_resposta r ON rf.resposta = r.resposta
      JOIN sis_empresa e ON rf.empresa = e.empresa
      WHERE r.val_resposta = 'P' 
      GROUP BY rf.ano,p.pergunta,p.des_pergunta,r.val_resposta) p3 ON p1.ano = p3.ano AND p1.pergunta = p3.pergunta) p4
      ON p1.ano = p4.ano AND p1.topico = p4.topico AND p1.pergunta  = p4.pergunta AND p1.resposta = p4.resposta
      
      JOIN
      
      (select t.topico, count(t.topico) total from psc_formulario_pergunta fp
      join psc_pergunta p on fp.pergunta = p.pergunta
      join psc_topico t on p.topico = t.topico
      group by t.topico
      order by topico) p5 on p1.topico = p5.topico
      
      WHERE p1.ano = '{$ano}'
      
      ORDER BY p1.ano ASC, p1.empresa ASC, p1.area ASC, p1.topico ASC, p1.pergunta ASC, p1.resposta ASC");
	}
	
	/*public function getPesquisa() {
		return $this->Select("SELECT p1.empresa,p1.des_empresa, p1.area, p1.des_area, p1.topico, p1.des_topico,
	    p1.pergunta, p1.des_pergunta, p1.resposta, p1.des_resposta, p1.ea_quantidade,
	    (p1.ea_satisfacao_topico /p5.total) ea_satisfacao_topico, p1.ea_satisfacao_pergunta, p2.e_quantidade,
	    (p2.e_satisfacao_topico /p5.total) e_satisfacao_topico,
	    p2.e_satisfacao_pergunta, p3.ga_quantidade,
	    (p3.ga_satisfacao_topico /p5.total) ga_satisfacao_topico,
        p3.ga_satisfacao_pergunta,
	    p4.g_quantidade, (p4.g_satisfacao_topico / p5.total) g_satisfacao_topico,
	    p4.g_satisfacao_pergunta
				
	    FROM
				
	    (SELECT p1.empresa,p1.des_empresa, p1.area, p1.des_area, p1.topico, p2.des_topico,
	    p1.pergunta, p3.des_pergunta, p1.resposta, p1.des_resposta, p1.qtd ea_quantidade,
	    p2.qtd ea_satisfacao_topico, p3.qtd ea_satisfacao_pergunta
	    FROM
	    (SELECT rf.empresa,e.des_empresa,rf.area,a.des_area,t.topico,rf.pergunta,r.des_resposta,
	    rf.resposta,count(rf.resposta) qtd
	    FROM psc_resposta_formulario rf
	    JOIN Psc_Resposta r ON rf.resposta = r.resposta
	    JOIN psc_pergunta p ON rf.pergunta = p.pergunta
	    JOIN psc_topico t ON p.topico = t.topico
	    JOIN sis_usuario u ON rf.usuario = u.usuario
	    JOIN sis_empresa e ON u.empresa = e.empresa
	    JOIN sis_area a ON rf.area = a.area
	    JOIN psc_formulario_pergunta fp ON rf.pergunta = fp.pergunta
	    GROUP BY rf.empresa,e.des_empresa,rf.area,a.des_area,t.topico,fp.ordem_pergunta,rf.pergunta,rf.resposta,r.des_resposta) p1
	    JOIN
	    (SELECT e.empresa,rf.area,t.topico,t.des_topico,count(r.val_resposta) qtd,r.val_resposta
	    FROM psc_resposta_formulario rf
	    JOIN psc_pergunta p ON rf.pergunta = p.pergunta
	    JOIN psc_topico t ON p.topico = t.topico
	    JOIN psc_resposta r ON rf.resposta = r.resposta
	    JOIN sis_empresa e ON rf.empresa = e.empresa
	    WHERE r.val_resposta = 'P'
	    GROUP BY e.empresa,rf.area,t.topico,t.des_topico,r.val_resposta) p2 ON p1.empresa = p2.empresa AND p1.area = p2.area AND p1.topico = p2.topico
	    JOIN
	    (SELECT e.empresa,rf.area,p.pergunta,p.des_pergunta,count(r.val_resposta) qtd,r.val_resposta
	    FROM psc_resposta_formulario rf
	    JOIN psc_pergunta p ON rf.pergunta = p.pergunta
	    JOIN psc_topico t ON p.topico = t.topico
	    JOIN psc_resposta r ON rf.resposta = r.resposta
	    JOIN sis_empresa e ON rf.empresa = e.empresa
	    WHERE r.val_resposta = 'P'
	    GROUP BY e.empresa,rf.area,p.pergunta,p.des_pergunta,r.val_resposta) p3 ON p1.empresa = p3.empresa AND p1.area = p3.area AND p1.pergunta = p3.pergunta) p1
				
	    JOIN
				
	    (SELECT p1.empresa,p1.des_empresa, p1.topico, p2.des_topico,
	    p1.pergunta, p3.des_pergunta, p1.resposta, p1.des_resposta, p1.qtd e_quantidade,
	    p2.qtd e_satisfacao_topico, p3.qtd e_satisfacao_pergunta
	    FROM
	    (SELECT rf.empresa,e.des_empresa,t.topico,rf.pergunta,r.des_resposta,
	    rf.resposta,count(rf.resposta) qtd
	    FROM psc_resposta_formulario rf
	    JOIN Psc_Resposta r ON rf.resposta = r.resposta
	    JOIN psc_pergunta p ON rf.pergunta = p.pergunta
	    JOIN psc_topico t ON p.topico = t.topico
	    JOIN sis_empresa e ON rf.empresa = e.empresa
	    JOIN psc_formulario_pergunta fp ON rf.pergunta = fp.pergunta
	    GROUP BY rf.empresa,e.des_empresa,t.topico,fp.ordem_pergunta,rf.pergunta,rf.resposta,r.des_resposta) p1
	    JOIN
	    (SELECT e.empresa,t.topico,t.des_topico,count(r.val_resposta) qtd,r.val_resposta
	    FROM psc_resposta_formulario rf
	    JOIN psc_pergunta p ON rf.pergunta = p.pergunta
	    JOIN psc_topico t ON p.topico = t.topico
	    JOIN psc_resposta r ON rf.resposta = r.resposta
	    JOIN sis_empresa e ON rf.empresa = e.empresa
	    WHERE r.val_resposta = 'P'
	    GROUP BY e.empresa,t.topico,t.des_topico,r.val_resposta) p2 ON p1.empresa = p2.empresa AND p1.topico = p2.topico
	    JOIN
	    (SELECT e.empresa,p.pergunta,p.des_pergunta,count(r.val_resposta) qtd,r.val_resposta
	    FROM psc_resposta_formulario rf
	    JOIN psc_pergunta p ON rf.pergunta = p.pergunta
	    JOIN psc_topico t ON p.topico = t.topico
	    JOIN psc_resposta r ON rf.resposta = r.resposta
	    JOIN sis_empresa e ON rf.empresa = e.empresa
	    WHERE r.val_resposta = 'P'
	    GROUP BY e.empresa,p.pergunta,p.des_pergunta,r.val_resposta) p3 ON p1.empresa = p3.empresa AND p1.pergunta = p3.pergunta) p2
	    ON p1.empresa = p2.empresa AND p1.topico = p2.topico AND p1.pergunta  = p2.pergunta AND p1.resposta = p2.resposta
				
	    JOIN
				
	    (SELECT p1.area, p1.des_area, p1.topico, p2.des_topico,
	    p1.pergunta, p3.des_pergunta, p1.resposta, p1.des_resposta, p1.qtd ga_quantidade,
	    p2.qtd ga_satisfacao_topico, p3.qtd ga_satisfacao_pergunta
	    FROM
	    (SELECT rf.area,a.des_area,t.topico,rf.pergunta,r.des_resposta,
	    rf.resposta,count(rf.resposta) qtd
	    FROM psc_resposta_formulario rf
	    JOIN Psc_Resposta r ON rf.resposta = r.resposta
	    JOIN psc_pergunta p ON rf.pergunta = p.pergunta
	    JOIN psc_topico t ON p.topico = t.topico
	    JOIN sis_usuario u ON rf.usuario = u.usuario
	    JOIN sis_area a ON rf.area = a.area
	    JOIN psc_formulario_pergunta fp ON rf.pergunta = fp.pergunta
	    GROUP BY rf.area,a.des_area,t.topico,fp.ordem_pergunta,rf.pergunta,rf.resposta,r.des_resposta) p1
	    JOIN
	    (SELECT rf.area,t.topico,t.des_topico,count(r.val_resposta) qtd,r.val_resposta
	    FROM psc_resposta_formulario rf
	    JOIN psc_pergunta p ON rf.pergunta = p.pergunta
	    JOIN psc_topico t ON p.topico = t.topico
	    JOIN psc_resposta r ON rf.resposta = r.resposta
	    WHERE r.val_resposta = 'P'
	    GROUP BY rf.area,t.topico,t.des_topico,r.val_resposta) p2 ON p1.area = p2.area AND p1.topico = p2.topico
	    JOIN
	    (SELECT rf.area,p.pergunta,p.des_pergunta,count(r.val_resposta) qtd,r.val_resposta
	    FROM psc_resposta_formulario rf
	    JOIN psc_pergunta p ON rf.pergunta = p.pergunta
	    JOIN psc_topico t ON p.topico = t.topico
	    JOIN psc_resposta r ON rf.resposta = r.resposta
	    JOIN sis_empresa e ON rf.empresa = e.empresa
	    WHERE r.val_resposta = 'P'
	    GROUP BY rf.area,p.pergunta,p.des_pergunta,r.val_resposta) p3 ON p1.area = p3.area AND p1.pergunta = p3.pergunta) p3
	    ON p1.area = p3.area AND p1.topico = p3.topico AND p1.pergunta  = p3.pergunta AND p1.resposta = p3.resposta
				
	    JOIN
				
	    (SELECT p1.topico, p2.des_topico,
	    p1.pergunta, p3.des_pergunta, p1.resposta, p1.des_resposta, p1.qtd g_quantidade,
	    p2.qtd g_satisfacao_topico, p3.qtd g_satisfacao_pergunta
	    FROM
	    (SELECT t.topico,rf.pergunta,r.des_resposta,
	    rf.resposta,count(rf.resposta) qtd
	    FROM psc_resposta_formulario rf
	    JOIN Psc_Resposta r ON rf.resposta = r.resposta
	    JOIN psc_pergunta p ON rf.pergunta = p.pergunta
	    JOIN psc_topico t ON p.topico = t.topico
	    JOIN psc_formulario_pergunta fp ON rf.pergunta = fp.pergunta
	    GROUP BY t.topico,fp.ordem_pergunta,rf.pergunta,rf.resposta,r.des_resposta) p1
	    JOIN
	    (SELECT t.topico,t.des_topico,count(r.val_resposta) qtd,r.val_resposta
	    FROM psc_resposta_formulario rf
	    JOIN psc_pergunta p ON rf.pergunta = p.pergunta
	    JOIN psc_topico t ON p.topico = t.topico
	    JOIN psc_resposta r ON rf.resposta = r.resposta
	    WHERE r.val_resposta = 'P'
	    GROUP BY t.topico,t.des_topico,r.val_resposta) p2 ON p1.topico = p2.topico
	    JOIN
	    (SELECT p.pergunta,p.des_pergunta,count(r.val_resposta) qtd,r.val_resposta
	    FROM psc_resposta_formulario rf
	    JOIN psc_pergunta p ON rf.pergunta = p.pergunta
	    JOIN psc_topico t ON p.topico = t.topico
	    JOIN psc_resposta r ON rf.resposta = r.resposta
	    JOIN sis_empresa e ON rf.empresa = e.empresa
	    WHERE r.val_resposta = 'P'
	    GROUP BY p.pergunta,p.des_pergunta,r.val_resposta) p3 ON p1.pergunta = p3.pergunta) p4
	    ON p1.topico = p4.topico AND p1.pergunta  = p4.pergunta AND p1.resposta = p4.resposta
				
	    JOIN
				
	    (select t.topico, count(t.topico) total from psc_formulario_pergunta fp
	    join psc_pergunta p on fp.pergunta = p.pergunta
	    join psc_topico t on p.topico = t.topico
	    group by t.topico
	    order by topico) p5 on p1.topico = p5.topico
				
	    ORDER BY p1.empresa ASC, p1.area ASC, p1.topico ASC, p1.pergunta ASC, p1.resposta ASC");
	}*/
	
	public function getTotalpesquisa($ano) {
		return $this->Select("SELECT p1.ano, p1.empresa, p1.des_empresa, p1.area, p1.des_area, p1.val_resposta,
	    p1.ea_quantidade, p2.e_quantidade, p3.ga_quantidade, p4.g_quantidade
	    
	    FROM
	    
	    (SELECT rf.ano,rf.empresa, e.des_empresa,a.area,a.des_area,count(r.val_resposta) ea_quantidade,r.val_resposta 
	    FROM psc_resposta_formulario rf
	    JOIN psc_resposta r ON rf.resposta = r.resposta
	    JOIN sis_area a ON rf.area = a.area
	    JOIN sis_empresa e ON rf.empresa = e.empresa
	    GROUP BY rf.ano,rf.empresa,e.des_empresa,a.area,a.des_area,r.val_resposta) p1
	    
	    JOIN
	    
	    (SELECT rf.ano,rf.empresa,count(r.val_resposta) e_quantidade,r.val_resposta 
	    FROM psc_resposta_formulario rf
	    JOIN psc_resposta r ON rf.resposta = r.resposta
	    GROUP BY rf.ano,rf.empresa,r.val_resposta) p2 
	    ON p1.ano = p2.ano AND p1.empresa = p2.empresa AND p1.val_resposta = p2.val_resposta
	        
	    JOIN
	     
	    (SELECT rf.ano,rf.area,count(r.val_resposta) ga_quantidade,r.val_resposta 
	    FROM psc_resposta_formulario rf
	    JOIN psc_resposta r ON rf.resposta = r.resposta
	    GROUP BY rf.ano,rf.area,r.val_resposta) p3 
	    ON p1.ano = p3.ano AND p1.area = p3.area AND p1.val_resposta = p3.val_resposta
	        
	    JOIN
	      
	    (SELECT rf.ano,count(r.val_resposta) g_quantidade,r.val_resposta 
	    FROM psc_resposta_formulario rf
	    JOIN psc_resposta r ON rf.resposta = r.resposta
	    GROUP BY rf.ano,r.val_resposta) p4
	    ON p1.ano = p4.ano AND p1.val_resposta = p4.val_resposta
	      
		WHERE p1.ano = '{$ano}'
  
	    ORDER BY p1.ano, p1.empresa, p1.area");
	}
	
	/*public function getTotalpesquisa() {
		return $this->Select("SELECT p1.empresa, p1.des_empresa, p1.area, p1.des_area, p1.val_resposta,
		p1.ea_quantidade, p2.e_quantidade, p3.ga_quantidade, p4.g_quantidade
				
		FROM
				
		(SELECT e.empresa, e.des_empresa,a.area,a.des_area,count(r.val_resposta) ea_quantidade,r.val_resposta
		FROM psc_resposta_formulario rf
		JOIN psc_resposta r ON rf.resposta = r.resposta
		JOIN sis_area a ON rf.area = a.area
		JOIN sis_empresa e ON rf.empresa = e.empresa
		GROUP BY e.empresa,e.des_empresa,a.area,a.des_area,r.val_resposta) p1
				
		JOIN
				
		(SELECT rf.empresa,count(r.val_resposta) e_quantidade,r.val_resposta
		FROM psc_resposta_formulario rf
		JOIN psc_resposta r ON rf.resposta = r.resposta
		GROUP BY rf.empresa,r.val_resposta) p2
		ON p1.empresa = p2.empresa AND p1.val_resposta = p2.val_resposta
				
		JOIN
				
		(SELECT rf.area,count(r.val_resposta) ga_quantidade,r.val_resposta
		FROM psc_resposta_formulario rf
		JOIN psc_resposta r ON rf.resposta = r.resposta
		GROUP BY rf.area,r.val_resposta) p3
		ON p1.area = p3.area AND p1.val_resposta = p3.val_resposta
				
		JOIN
				
		(SELECT count(r.val_resposta) g_quantidade,r.val_resposta
		FROM psc_resposta_formulario rf
		JOIN psc_resposta r ON rf.resposta = r.resposta
		GROUP BY r.val_resposta) p4
		ON p1.val_resposta = p4.val_resposta
				
		ORDER BY p1.empresa, p1.area");
	}*/
	
	public function getQuemrespondeu($ano) {
		return $this->Select("SELECT p1.ano,p1.empresa,p1.des_empresa,p1.area,p1.des_area,
	    p1.ea_respondidos,p2.e_respondidos, p3.ga_respondidos, p4.g_respondidos
	    
	    FROM
	    
	    (SELECT p.ano,p.empresa,p.des_empresa,p.area,p.des_area,
	    count(p.usuario) ea_respondidos 
	    FROM 
	    (SELECT rf.ano,rf.empresa,e.des_empresa,a.area,a.des_area,rf.usuario 
	    FROM psc_resposta_formulario rf
	    JOIN sis_area a ON rf.area = a.area
	    JOIN sis_empresa e ON rf.empresa = e.empresa
	    GROUP BY rf.ano,rf.empresa,e.des_empresa,a.area,a.des_area,rf.usuario) p
	    GROUP BY p.ano,p.empresa,p.des_empresa,p.area,p.des_area) p1
	    
	    JOIN
	    
	    (SELECT p.ano,p.empresa,count(p.usuario) e_respondidos 
	    FROM 
	    (SELECT rf.ano,rf.empresa,rf.usuario 
	    FROM psc_resposta_formulario rf
	    GROUP BY rf.ano,rf.empresa,rf.usuario) p
	    GROUP BY p.ano,p.empresa) p2 ON p1.ano = p2.ano AND p1.empresa = p2.empresa
	    
	    JOIN
	    
	    (SELECT p.ano,p.area,count(p.usuario) ga_respondidos 
	    FROM 
	    (SELECT rf.ano,rf.area,rf.usuario 
	    FROM psc_resposta_formulario rf
	    GROUP BY rf.ano,rf.area,rf.usuario) p
	    GROUP BY p.ano,p.area) p3 ON p1.ano = p3.ano AND p1.area = p3.area
	    
	    JOIN 
	    (SELECT  p.ano, count(p.ano) g_respondidos 
	    FROM 
	    (SELECT rf.ano,rf.usuario 
	    FROM psc_resposta_formulario rf
	    GROUP BY rf.ano,rf.usuario) p
	    GROUP BY p.ano) p4 ON p1.ano = p4.ano 
	    
	    WHERE p1.ano = '{$ano}'
	    
	    ORDER BY p1.ano, p1.empresa, p1.area");
	}
	
	/*public function getQuemrespondeu() {
		return $this->Select("SELECT p1.empresa,p1.des_empresa,p1.area,p1.des_area,
		p1.ea_respondidos,p2.e_respondidos, p3.ga_respondidos,
		(SELECT count(p.usuario) g_respondidos 
		FROM 
		(SELECT rf.usuario 
		FROM psc_resposta_formulario rf
		GROUP BY rf.usuario) p) g_respondidos
		
		FROM
		
		(SELECT p.empresa,p.des_empresa,p.area,p.des_area,
		count(p.usuario) ea_respondidos 
		FROM 
		(SELECT e.empresa,e.des_empresa,a.area,a.des_area,rf.usuario 
		FROM psc_resposta_formulario rf
		JOIN sis_area a ON rf.area = a.area
		JOIN sis_empresa e ON rf.empresa = e.empresa
		GROUP BY e.empresa,e.des_empresa,a.area,a.des_area,rf.usuario) p
		GROUP BY p.empresa,p.des_empresa,p.area,p.des_area) p1
		
		JOIN
		
		(SELECT p.empresa,count(p.usuario) e_respondidos 
		FROM 
		(SELECT rf.empresa,rf.usuario 
		FROM psc_resposta_formulario rf
		GROUP BY rf.empresa,rf.usuario) p
		GROUP BY p.empresa) p2 ON p1.empresa = p2.empresa
		
		JOIN
		
		(SELECT p.area,count(p.usuario) ga_respondidos 
		FROM 
		(SELECT rf.area,rf.usuario 
		FROM psc_resposta_formulario rf
		GROUP BY rf.area,rf.usuario) p
		GROUP BY p.area) p3 ON p1.area = p3.area
		
		ORDER BY p1.empresa,p1.area");
	}*/
	
	public function getEmpresasugestao(){
		return $this->Select("SELECT e.empresa, e.des_empresa
	    FROM psc_sugestao s
	    JOIN sis_usuario u ON s.usuario = u.usuario
	    JOIN sis_empresa e ON u.empresa = e.empresa
	    GROUP BY e.empresa,e.des_empresa
	    ORDER BY e.empresa");
	}
	public function getSugestoes($empresa,$ano) {
		return $this->Select("SELECT s.sugestao, s.dta_sugestao
		FROM psc_sugestao s
		JOIN sis_usuario u ON s.usuario = u.usuario
		WHERE u.empresa = '{$empresa}' and to_char(to_date(s.dta_sugestao,'dd/mm/yyyy hh24:mi:ss'),'yyyy') = '{$ano}' ");
	}
	public function  addRespostaformulario(Respostaformulario $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'psc_resposta_formulario');
	}
	
	public function  addSugestao(Sugestao $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'psc_sugestao');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}