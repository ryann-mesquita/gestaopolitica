<?php

namespace api\monaco;

use lib\Model;
use obj\monaco\Pessoa;
use helper\PrepareSQL;
use helper\Funcoes;
use obj\monaco\Resultado;

class apiDisc extends Model {
	
	public function getPerfil($perfil){
		return $this->Select("SELECT * FROM (SELECT * FROM disc_opcao ORDER BY DBMS_RANDOM.VALUE)
		WHERE  perfil = '{$perfil}'");
	}
	
	public function getPessoa($cpf){
		return $this->Select("SELECT p.pessoa, p.nome, p.empresa, p.dta_cadastro, e.des_empresa FROM disc_pessoa p
							LEFT JOIN sis_empresa e on p.empresa = e.empresa  
							WHERE pessoa = '{$cpf}'");
	}
	
	public function getPessoaavaliada($empresa,$nome){
		return $this->Select("SELECT DISTINCT r.pessoa,p.nome,p.empresa FROM disc_resultado r
		JOIN disc_pessoa p on r.pessoa = p.pessoa
		WHERE p.empresa = '{$empresa}' AND p.nome LIKE '%{$nome}%'");
	}
	
	public function getPermissaoExcluir($usuario, $empresa){
		return	$this->Select("select p.usuario from sis_permissao p
		left join sis_modulo m on p.modulo = m.modulo
		left join sis_controle c on p.controle = c.controle
		left join sis_acao a on p.acao = a.acao
		where p.modulo = 5 and p.controle = 33 and p.acao = 4 and p.usuario = '{$usuario}' and p.empresa = '{$empresa}'");

	}
	
	public function getResultado($cpf){
		return $this->Select("SELECT p1.pessoa, p1.nome, NVL(p2.D,0) D, NVL(p3.I,0) I, NVL(p4.S,0) S, NVL(p5.C,0) C FROM disc_pessoa p1
		LEFT JOIN (SELECT r.pessoa,COUNT(p.des_perfil) D FROM disc_resultado r
		JOIN disc_opcao o ON r.opcao = o.opcao
		JOIN disc_perfil p ON o.perfil = p.perfil
		WHERE p.des_perfil = 'D'
		GROUP BY r.pessoa,p.des_perfil) p2 ON p1.pessoa = p2.pessoa
		LEFT JOIN (SELECT r.pessoa,COUNT(p.des_perfil) I FROM disc_resultado r
		JOIN disc_opcao o ON r.opcao = o.opcao
		JOIN disc_perfil p ON o.perfil = p.perfil
		WHERE p.des_perfil = 'I'
		GROUP BY r.pessoa,p.des_perfil) p3 ON p1.pessoa = p3.pessoa
		LEFT JOIN (SELECT r.pessoa,COUNT(p.des_perfil) S FROM disc_resultado r
		JOIN disc_opcao o ON r.opcao = o.opcao
		JOIN disc_perfil p ON o.perfil = p.perfil
		WHERE p.des_perfil = 'S'
		GROUP BY r.pessoa,p.des_perfil) p4 ON p1.pessoa = p4.pessoa
		LEFT JOIN (SELECT r.pessoa,COUNT(p.des_perfil) C FROM disc_resultado r
		JOIN disc_opcao o ON r.opcao = o.opcao
		JOIN disc_perfil p ON o.perfil = p.perfil
		WHERE p.des_perfil = 'C'
		GROUP BY r.pessoa,p.des_perfil) p5 ON p1.pessoa = p5.pessoa
		WHERE p1.pessoa = '{$cpf}'");
	}
	public function filtroDisc($empresa, $c, $coluna = NULL, $val = NULL){
		$funcoes = new Funcoes();
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		$condicao = array(
			'1'	=> " AND LOWER(p.{$coluna}) = '{$val}' ",
			'2' => " AND LOWER(p.{$coluna}) LIKE '%{$val}%' ",
			'3'	=> " ",
			'4' => "AND LOWER({$coluna}) = '{$val}'"
		);
	
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT p.pessoa, p.nome, p.empresa, p.dta_cadastro FROM disc_pessoa p
		WHERE p.empresa = '{$empresa}'{$condicao[$c]}ORDER BY p.nome ASC) R ) R2");
	}
	public function addPessoa(Pessoa $obj){
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->nome = strtoupper($funcoes->retiraAcentos(trim($obj->nome)));
		return $prepare->PrepareInsert($obj, 'disc_pessoa');	
	}
	
	public function editPessoa(Pessoa $obj){
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'pessoa';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('pessoa' => $obj['pessoa']), 'disc_pessoa');
	}
	
	public function addResultado(Resultado $obj){
		$prepare = new PrepareSQL();
		return $prepare->PrepareInsert($obj, 'disc_resultado');
	}

	public function delDiscResultado(Pessoa $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('pessoa' => $obj->pessoa), 'disc_resultado');
	}
	public function delDiscPessoa(Pessoa $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('pessoa' => $obj->pessoa), 'disc_pessoa');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}