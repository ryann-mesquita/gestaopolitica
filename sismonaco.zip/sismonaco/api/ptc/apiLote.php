<?php

namespace api\ptc;

use lib\Model;
use obj\ptc\Lote;
use helper\PrepareSQL;
use helper\Funcoes;

class apiLote extends Model {

	public function getLote(Lote $obj) {
		return  $this->First($this->Select("SELECT l.lote, l.empresa_origem, e1.des_empresa des_empresa_origem, l.situacao, l.empresa_destino , e2.des_empresa des_empresa_destino,
        l.dta_criacao, l.dta_recepcao, l.usuario_criacao, u.nome nome_usuario, l.usuario_recepcao, l.n_cheque, l.val_lote, l.val_recepcao, l.n_cheque_recepcao
        FROM ptc_lote l 
		JOIN sis_usuario u on l.usuario_criacao = u.usuario
		JOIN sis_empresa e1 on l.empresa_origem  = e1.empresa
		JOIN sis_empresa e2 on l.empresa_destino = e2.empresa
		WHERE l.lote = '{$obj->lote}'"));
		
		
	}
	public function filtroLote($c, $a, $coluna = NULL, $val = NULL, $de = NULL, $ate = NULL, $empresa = NULL) {				
		//$val = strtolower(trim($val));
		
				
		$condicao = array(
			'1'	=> " WHERE LOWER(l.{$coluna}) = '{$val}' ",
			'2' => " WHERE LOWER(l.{$coluna}) LIKE '%{$val}%'",
			'3'	=> "",
			'4' => " WHERE TO_DATE(TO_CHAR(TO_DATE({$coluna}, 'dd/mm/yyyy hh24:mi:ss'), 'dd/mm/yyyy'), 'dd/mm/yyyy') BETWEEN TO_DATE('{$de}','dd/mm/yyyy') AND TO_DATE('{$ate}','dd/mm/yyyy')",
			'5' => " WHERE l.situacao in({$val}) AND (l.empresa_origem = '{$empresa}' OR l.empresa_destino = '{$empresa}') ",
			'6' => " WHERE l.situacao is not null AND (l.empresa_origem = '{$empresa}' OR l.empresa_destino = '{$empresa}') ",
			'7' => " WHERE l.situacao is not null AND (l.empresa_origem in({$val}) OR l.empresa_destino in({$val}))"
		);
		

		$ativo = array(
			'1' => "AND l.situacao = '0' AND (l.empresa_origem = '{$empresa}' OR l.empresa_destino = '{$empresa}') ",
			'2' => "AND l.situacao = '1' AND (l.empresa_origem = '{$empresa}' OR l.empresa_destino = '{$empresa}') ",
			'3' => "AND l.situacao = '2' AND (l.empresa_origem = '{$empresa}' OR l.empresa_destino = '{$empresa}')",
			'4' => "AND l.situacao = '3' AND (l.empresa_origem = '{$empresa}' OR l.empresa_destino = '{$empresa}')",
			'5' => "AND l.situacao = '4' AND (l.empresa_origem = '{$empresa}' OR l.empresa_destino = '{$empresa}')",
			'6' => "AND (l.empresa_origem = '{$empresa}' OR l.empresa_destino = '{$empresa}')",
			'7' => "AND l.situacao is not null AND (l.empresa_origem = '{$empresa}' OR l.empresa_destino = '{$empresa}') ",
			'8' => ""
		);
		

		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT l.lote, l.empresa_origem, e1.des_empresa des_empresa_origem, l.situacao, l.empresa_destino , e2.des_empresa des_empresa_destino,
        l.dta_criacao, l.dta_recepcao, l.usuario_criacao, u.nome nome_usuario, l.usuario_recepcao, l.n_cheque, l.val_lote, l.val_recepcao, l.n_cheque_recepcao
		FROM ptc_lote l
		JOIN sis_usuario u on l.usuario_criacao = u.usuario
		JOIN sis_empresa e1 on l.empresa_origem  = e1.empresa
		JOIN sis_empresa e2 on l.empresa_destino = e2.empresa
		{$condicao[$c]}{$ativo[$a]}ORDER BY l.lote ASC) R ) R2");
		
	}
	
	public function addLote(Lote $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		//$obj->des_pagamento = strtoupper($funcoes->retiraAcentos(trim($obj->des_pagamento)));
		$obj = (array) $obj;
		
		$obj = array_filter($obj, function($v){return !is_null($v);});
		
		return $prepare->PrepareInsert($obj, 'ptc_lote', 'lote');
	}
	
	public function loteRecebido(Lote $obj)
	{
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'lote';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('lote' => $obj['lote']), 'ptc_lote');
		
	}
	
	public function situacaoLote (Lote $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'lote';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('lote' => $obj['lote']), 'ptc_lote');
	}
	
	public function cancelaLote (Lote $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'lote';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('lote' => $obj['lote']), 'ptc_lote');
	}
	
	public function valorLote(Lote $obj)
	{
		$prepare = new PrepareSQL();
		$obj = (array) $obj;

		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'lote';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('lote' => $obj['lote']), 'ptc_lote');
	}
	
	public function fechamentoLote(Lote $obj)
	{
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'lote';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('lote' => $obj['lote']), 'ptc_lote');
	}
	
	

   public function executeSQL($sql){
  	return $this->Execute($sql);
  }
}