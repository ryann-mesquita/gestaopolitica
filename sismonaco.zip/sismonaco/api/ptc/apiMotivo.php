<?php

namespace api\ptc;

use lib\Model;

class apiMotivo extends Model {

	public function getMotivo() {
		return  $this->Select("SELECT * FROM ptc_motivo ");
	}

	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}