<?php

namespace api\ptc;

use lib\Model;
use obj\ptc\Cheque;
use obj\ptc\Lote;
use helper\PrepareSQL;
use helper\Funcoes;

class apiCheque extends Model {

	public function getCheque(Lote $obj) {
		return  $this->Select("SELECT c.cheque, c.valor, c.dta_vencimento, c.lote, c.origem, c.motivo, c.forma,
							   c.conciliado, c.cliente_nome, c.cliente_cpfcnpj, c.dta_inclusao, c.dta_conciliacao, 
							   c.origem, o.des_origem, c.motivo, m.des_motivo			
							   FROM ptc_cheque c
							   JOIN ptc_origem o on c.origem = o.origem
							   JOIN ptc_motivo m on c.motivo = m.motivo
							   WHERE c.lote = '{$obj->lote}'");		
	}
	
	public function getChequeUnidade(Cheque $cheque, Lote $lote){
		return $this->Select("SELECT c.cheque, c.valor, c.dta_vencimento, c.lote, c.origem, c.motivo, c.forma,
							   c.conciliado, c.cliente_nome, c.cliente_cpfcnpj, c.dta_inclusao, c.dta_conciliacao, 
							   c.origem, o.des_origem, c.motivo, m.des_motivo			
							   FROM ptc_cheque c
							   JOIN ptc_origem o on c.origem = o.origem
							   JOIN ptc_motivo m on c.motivo = m.motivo
							   WHERE c.lote = '{$lote->lote}' and c.cheque = '{$cheque->cheque}'");
	}
	
	public function countCheque(Lote $obj){
		return $this->select("SELECT COUNT(c.cheque) count_cheque
							  FROM ptc_cheque c
							  WHERE c.lote = '{$obj->lote}'");
	}
	
	public function conciliaCheque(Cheque $obj)
	{
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'cheque';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('cheque' => $obj['cheque']), 'ptc_cheque');
	}
	
	public function checarConciliacao(Lote $obj){
		return $this->select("SELECT * 
							  FROM ptc_cheque c
							  WHERE c.lote = '{$obj->lote}' and c.conciliado = 'n'");
							
	}
	
	public function addCheque(Cheque $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		
		$obj = (array) $obj;
		
		$obj = array_filter($obj, function($v){return !is_null($v);});
		
		return $prepare->PrepareInsert($obj,'ptc_cheque');
	}
	
	public function delCheque(Cheque $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('cheque' => $obj->cheque, 'lote' => $obj->lote), 'ptc_cheque');
		
	}

   public function executeSQL($sql){
  	return $this->Execute($sql);
  }
}