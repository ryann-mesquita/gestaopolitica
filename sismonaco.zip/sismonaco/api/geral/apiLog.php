<?php 

namespace api\geral;

use lib\Model;
use obj\geral\Log;
use helper\PrepareSQL;

class apiLog extends Model {
	
	public function getLog(Log $obj) {
		return $this->First($this->Select("SELECT * FROM sis_log WHERE cod = '{$obj->cod}'"));
	}
	
	public function filtroLog(Log $obj, $de, $ate) {
		return $this->Select("SELECT l.usuario, u.nome,m.des_reduzida md, c.des_reduzida ct, a.des_reduzida ac, 
		e.des_empresa, l.tipo, l.historico, l.dta_registro 
		FROM sis_log l
		JOIN sis_usuario u ON l.usuario = u.usuario
		JOIN sis_modulo m ON l.modulo = m.modulo
		JOIN sis_controle c ON l.controle = c.controle
		JOIN sis_acao a ON l.acao = a.acao
		JOIN sis_empresa e ON l.empresa = e.empresa
		WHERE l.tipo = '{$obj->tipo}' AND
		".($obj->usuario != NULL ? "l.usuario = '{$obj->usuario}' AND" : "")."  
		".($obj->modulo != NULL ? "l.modulo = '{$obj->modulo}' AND" : "")." 
		".($obj->controle != NULL ? "l.controle = '{$obj->controle}' AND" : "")."
		".($obj->acao != NULL ? "l.acao = '{$obj->acao}' AND" : "")."
		to_date(l.dta_registro, 'dd/mm/yyyy hh24:mi:ss') 
		between to_date('{$de} 00:00:00', 'dd/mm/yyyy hh24:mi:ss') 
		AND to_date('{$ate} 23:59:59', 'dd/mm/yyyy hh24:mi:ss')
		ORDER BY to_date(l.dta_registro, 'dd/mm/yyyy hh24:mi:ss') DESC");
	}
	
	public function filtroLogacesso($de, $ate, $usuario = NULL) {
		if ($usuario != NULL){
			$cond = "u.usuario = '{$usuario}' and ";
		}else{
			$cond = "";
		}
		return $this->Select("SELECT u.usuario, u.nome, u.dta_ult_acesso, u.ativo
		FROM sis_usuario u
		WHERE {$cond}to_date(u.dta_ult_acesso, 'dd/mm/yyyy hh24:mi:ss') 
		between to_date('{$de} 00:00:00', 'dd/mm/yyyy hh24:mi:ss') 
		AND to_date('{$ate} 23:59:59', 'dd/mm/yyyy hh24:mi:ss')
		ORDER BY to_date(u.dta_ult_acesso, 'dd/mm/yyyy hh24:mi:ss') DESC");
	}
	
	public function addLog(Log $obj) {	
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$obj = array_filter($obj, function($v){return $v != 'anexo';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareInsert($obj, 'sis_log','cod');	
	}
	
	public function addLogacesso(Log $obj) {	
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$obj = array_filter($obj, function($v){return $v != 'anexo';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareInsert($obj, 'sis_log_acesso','cod');	
	}
	
	public function delLog(Log $obj) {	
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('id' => $obj->id), 'sis_log');	
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}