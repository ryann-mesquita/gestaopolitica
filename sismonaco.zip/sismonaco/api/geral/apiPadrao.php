<?php

namespace api\geral;

use lib\Model;
use obj\geral\Padrao;
use helper\PrepareSQL;

class apiPadrao extends Model {
	
	public function getPadrao(Padrao $obj) {
		return  $this->First($this->Select("SELECT * FROM sis_padrao p WHERE p.modulo = '{$obj->modulo}' AND p.controle = '{$obj->controle}' 
		AND p.acao = '{$obj->acao}' AND p.usuario = '{$obj->usuario}'"));
	}
	
	public function getPadroes($usuario) {
		return $this->Select("SELECT * FROM sis_padrao p WHERE p.usuario = '{$usuario}'");
	}
	
	public function addPadrao(Padrao $obj){
		$prepare = new PrepareSQL();
		return $prepare->PrepareInsert($obj, 'sis_padrao');
	}
	
	public function editPadrao(Padrao $obj){
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$set = array_filter($obj, function($v){return $v != 'modulo' && $v != 'controle' && $v != 'acao' && $v != 'usuario' && $v != 'empresa';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('modulo' => $obj['modulo'], 'controle' => $obj['controle'], 'acao' => $obj['acao'], 'usuario' => $obj['usuario']), 'sis_padrao');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
	
}