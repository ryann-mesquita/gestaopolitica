<?php

namespace api\geral;

use lib\Modelmysql;
use obj\geral\Pandion;

class apiPandion extends Modelmysql {
	
	public function __construct(){
		parent::__construct("pandion");
	}
		
	public function getUsuario(Pandion $obj){
		return $this->First($this->Select("SELECT * FROM users WHERE username = '{$obj->username}'"));
	}
	
	public function allUsuarios(){
		return $this->Select("SELECT * FROM users");
	}
	
	public function addUsuario(Pandion $obj){
		return $this->Insert($obj, "users");
	}
	
	public function editUsuario(Pandion $obj){	
		return $this->Update($obj, array('username' => $obj->username), "users");
	}
}