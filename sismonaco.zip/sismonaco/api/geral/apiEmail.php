<?php

namespace api\geral;

use lib\Model;
use helper\PrepareSQL;
use obj\geral\Email;

class apiEmail extends Model {

	public function getEmail($data,$hora,$de,$ate) {
		return $this->Select("SELECT R2.* FROM (SELECT rownum n_linha, R.* FROM(SELECT e.cod, e.dta_envio, e.hora_envio, 
		e.rotina, e.remetente, e.destinatario, e.assunto, e.mensagem, e.anexo, e.dta_enviado, e.situacao, e.mensagem_erro
		FROM sis_email e WHERE e.situacao in ('P','N') AND 
		to_date('{$data} {$hora}','dd/mm/yyyy hh24:mi:ss') >= to_date(e.dta_envio||' '||e.hora_envio,'dd/mm/yyyy hh24:mi:ss')
		ORDER BY e.cod ASC) R ) R2 WHERE R2.n_linha BETWEEN {$de} AND {$ate} ");
	}

	public  function getGruporotina($data,$hora,$de,$ate) {
		return $this->Select("SELECT R2.* FROM (SELECT rownum n_linha, R.* FROM (SELECT e.rotina FROM sis_email e
		WHERE e.situacao in ('P','N') AND 
		to_date('{$data} {$hora}','dd/mm/yyyy hh24:mi:ss') >= to_date(e.dta_envio||' '||e.hora_envio,'dd/mm/yyyy hh24:mi:ss')
		GROUP BY e.rotina) R ) R2 WHERE R2.n_linha BETWEEN {$de} AND {$ate} ");
	}

	public function addEmail(Email $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$obj = array_filter($obj, function($v){return $v != 'cod';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareInsert($obj, 'sis_email','cod');
	}

	public function editEmail(Email $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'cod';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('cod' => substr($obj['cod'],0,-1)), 'sis_email','in');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}