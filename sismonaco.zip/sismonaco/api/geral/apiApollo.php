<?php

namespace api\geral;

use lib\Model;
use obj\geral\Usuarioapollo;
use helper\PrepareSQL;

class apiApollo extends Model {

	public function getClientepf($term) {
		return $this->Select("SELECT c.nome, LPAD(pf.cpf,11,0)cpf FROM fat_cliente c
		JOIN fat_pessoa_fisica pf ON c.cliente = pf.cliente
		WHERE LPAD(pf.cpf,11,0) LIKE '{$term}%' ORDER BY c.nome");
	}

	public function getClientepj($term) {
		return $this->Select("SELECT c.nome, LPAD(pj.cgc,14,0)cnpj FROM fat_cliente c
		JOIN fat_pessoa_juridica pj ON c.cliente = pj.cliente
		WHERE LPAD(pj.cgc,14,0) LIKE '{$term}%' ORDER BY c.nome");
	}
	
	public function getClienteApollo($id){
		return $this->Select("SELECT C.CLIENTE,C.NOME,C.DDD_TELEFONE,C.DDD_CELULAR,C.TELEFONE,
        C.CELULAR,C.CEP_COBRANCA, C.MUNICIPIO_COBRANCA,C.UF_COBRANCA,C.LOGRADOURO_COBRANCA,
        C.BAIRRO_COBRANCA,C.E_MAIL_CASA, C.E_MAIL_TRABALHO,B.CONTA_CORRENTE,B.NRO_BANCO,
        B.DES_BANCO,B.NRO_AGENCIA,B.DES_AGENCIA, B.DIGITO_CONTA,B.DIGITO_AGENCIA,J.CGC,P.CPF
        FROM CNP.FAT_CLIENTE C
        LEFT JOIN CNP.FAT_CLIENTE_BANCO B ON(B.CLIENTE = C.CLIENTE)
        LEFT JOIN CNP.FAT_PESSOA_JURIDICA J ON(J.CLIENTE = C.CLIENTE)
        LEFT JOIN CNP.FAT_PESSOA_FISICA P ON(P.CLIENTE = C.CLIENTE)
        WHERE C.CLIENTE = '$id'");
	}
	
	public function filtroClienteApollo($campo, $filtro){
		$campo = strtoupper(trim($campo));
		if ($filtro == "cnpj"){
			return $this->Select("SELECT C.CLIENTE,C.NOME,J.CGC
			FROM CNP.FAT_CLIENTE C
			INNER JOIN CNP.FAT_PESSOA_JURIDICA J ON(J.CLIENTE = C.CLIENTE)
			WHERE LPAD(J.CGC, 14,'0') LIKE '%$campo%'");			
		}elseif ($filtro == "cpf"){
			return $this->Select("SELECT C.CLIENTE,C.NOME,P.CPF
			FROM CNP.FAT_CLIENTE C
			INNER JOIN CNP.FAT_PESSOA_FISICA P ON(P.CLIENTE = C.CLIENTE)
			WHERE LPAD(P.CPF,11,'0') LIKE '%$campo%'");
		}else{
			return $this->select("SELECT C.CLIENTE,C.NOME,P.CPF,J.CGC
			FROM CNP.FAT_CLIENTE C
			LEFT JOIN CNP.FAT_PESSOA_JURIDICA J ON(J.CLIENTE = C.CLIENTE)
			LEFT JOIN CNP.FAT_PESSOA_FISICA P ON(P.CLIENTE = C.CLIENTE)
			WHERE C.NOME LIKE '%$campo%'");  
		}
	}
	
	
	public function getUsuarioapollo($login, $cpf, $email) {
		return $this->Select("SELECT u.usuario, u.login, u.nome, u.email FROM ger_usuario u 
		WHERE u.usuario IN (select usuario from ger_usuario where login = '{$login}' 
		or lpad(cpf,11,'0') = '$cpf' or email = '$email')");
	}
	
	public function atualizaUsuario(Usuarioapollo $obj){
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'usuario' && $v != 'status';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('usuario' => $obj['usuario']), 'ger_usuario');
	}
	
	public function atualizaVendedor(Usuarioapollo $obj){
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'usuario' && $v != 'grupo' && $v != 'usuario_rede' && $v != 'dta_inativacao' && $v != 'status';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('usuario' => $obj['usuario']), 'fat_vendedor');
	}
	
	public function atualizaMecanico(Usuarioapollo $obj){
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'usuario' && $v != 'grupo' && $v != 'usuario_rede' && $v != 'dta_inativacao' && $v != 'ativo';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('usuario' => $obj['usuario']), 'ofi_mecanico');
	}
	
	public function getPropostaApollo($empresa, $revenda, $proposta){
		return $this->First($this->Select("SELECT C.CONTATO,  V.NUMERO_NOTA_NFENTRADA AS NF_ENTRADA,
       	V.NUMERO_NOTA_NFSAIDA AS NF_SAIDA, V.NUMERO_NOTA_VENDA_DIRETA AS NF_DIRETA,P.EMPRESA, P.REVENDA, P.PROPOSTA, P.VENDEDOR, 
		F.TIPO_RENAVAM, F.ESPECIE_RENAVAM, P.VEICULO, P.DTA_EMISSAO, P.SITUACAO, P.TIPO_VENDA, N.NEGOCIACAO, L.CLIENTE, L.NOME,
        V.NOVO_USADO, L.FISJUR, (case when ((L.fisjur = 'F') or (L.fisjur = 'O')) then (select max(cast(FPJ.CPF as varchar(14))) 
		from FAT_PESSOA_FISICA FPJ where FPJ.cliente = L.CLIENTE) else (select max(FPJ.CGC) from FAT_PESSOA_JURIDICA FPJ 
		where FPJ.cliente = L.CLIENTE) end) CPFCNPJ, E.NOME NOME_VENDEDOR, E.CPF CPF_VENDEDOR, F.CHASSI, F.PLACA, V.VAL_CUSTO_CONTABIL , 
		CAST(P.DTA_EMISSAO AS DATE) DTA_EMISSAO, COALESCE ((SELECT MAX(FMC.DTA_ENTRADA_SAIDA) FROM FAT_MOVIMENTO_CAPA FMC 
		WHERE FMC.EMPRESA = P.EMPRESA AND FMC.REVENDA = P.REVENDA AND FMC.CONTATO = P.CONTATO), V.Dta_Venda) DTA_VENDA, 
		CASE WHEN P.VEICULO IS NULL OR P.VEICULO = '' THEN (SELECT M.DES_MODELO FROM VEI_MODELO M, VEI_PROPOSTA_VEICULO R 
		WHERE R.EMPRESA = M.EMPRESA AND R.MODELO = M.MODELO AND R.EMPRESA = P.EMPRESA AND R.REVENDA = P.REVENDA AND 
		R.PROPOSTA = P.PROPOSTA) ELSE (SELECT M.DES_MODELO FROM VEI_MODELO M, VEI_VEICULO V WHERE V.EMPRESA = M.EMPRESA 
		AND V.MODELO = M.MODELO AND V.EMPRESA = P.EMPRESA AND V.VEICULO = P.VEICULO) END DES_MODELO, CASE WHEN P.VEICULO IS NULL 
		OR P.VEICULO = '' THEN (SELECT VF.DES_FAMILIA FROM VEI_MODELO M, VEI_FAMILIA VF, VEI_PROPOSTA_VEICULO R WHERE 
		R.EMPRESA = M.EMPRESA AND R.MODELO = M.MODELO AND R.EMPRESA = P.EMPRESA AND R.REVENDA = P.REVENDA AND 
		R.PROPOSTA = P.PROPOSTA and M.EMPRESA = VF.EMPRESA AND M.FAMILIA = VF.FAMILIA) ELSE (SELECT VF.DES_FAMILIA 
		FROM VEI_MODELO M, VEI_FAMILIA VF, VEI_VEICULO V WHERE V.EMPRESA = M.EMPRESA AND V.MODELO = M.MODELO AND 
		V.EMPRESA = P.EMPRESA AND V.VEICULO = P.VEICULO and M.EMPRESA = VF.EMPRESA AND M.FAMILIA = VF.FAMILIA) END DES_FAMILIA, 
		CASE P.SITUACAO WHEN '0' THEN 'Aberta' WHEN '1' THEN 'Pendente' WHEN '2' THEN 'Aprovada(Ger)' WHEN '5' 
		THEN 'Aprovada(Fin)' WHEN '7' THEN 'NF Emitida' WHEN '8' THEN 'Cancelada' WHEN '9' THEN 'Encerrada' 
		END DES_SITUACAO, (SELECT LOGIN FROM GER_USUARIO WHERE USUARIO = N.USU_GERENCIAL) USU_GERENCIAL, 
		CAST(N.DTA_APR_GERENCIAL AS DATE) DTA_APR_GERENCIAL, CAST(N.DTA_APR_FINANCEIRA AS DATE) DTA_APR_FINANCEIRA, 
		CASE WHEN P.SITUACAO = '8' THEN (SELECT CAST(P1.DTA_PROVIDENCIA AS DATE) FROM CAC_PROVIDENCIA P1 WHERE 
		P1.EMPRESA = C.EMPRESA AND P1.REVENDA = C.REVENDA AND P1.CONTATO = C.CONTATO AND 
		P1.PROVIDENCIA = (SELECT MAX(P2.PROVIDENCIA) FROM CAC_PROVIDENCIA P2 WHERE P2.EMPRESA = P1.EMPRESA 
		AND P2.REVENDA = P1.REVENDA AND P2.CONTATO = P1.CONTATO)) END DTA_CANCELAMENTO, CASE WHEN P.SITUACAO = '8' 
		THEN (SELECT U1.LOGIN FROM CAC_PROVIDENCIA P1, GER_USUARIO U1 WHERE P1.USUARIO = U1.USUARIO AND 
		P1.EMPRESA = C.EMPRESA AND P1.REVENDA = C.REVENDA AND P1.CONTATO = C.CONTATO AND 
		P1.PROVIDENCIA = (SELECT MAX(P2.PROVIDENCIA) FROM CAC_PROVIDENCIA P2 WHERE P2.EMPRESA = P1.EMPRESA AND 
		P2.REVENDA = P1.REVENDA AND P2.CONTATO = P1.CONTATO)) END USU_CANCELAMENTO, CASE WHEN P.NEGOCIACAO_FINAL IS NULL 
		THEN (SELECT SUM(VAL_PAGAMENTO) FROM VEI_PAGAMENTO WHERE EMPRESA = P.EMPRESA AND REVENDA = P.REVENDA AND 
		PROPOSTA = P.PROPOSTA AND NEGOCIACAO = 1) ELSE (SELECT SUM(VAL_PAGAMENTO) FROM VEI_PAGAMENTO WHERE 
		EMPRESA = P.EMPRESA AND REVENDA = P.REVENDA AND PROPOSTA = P.PROPOSTA AND NEGOCIACAO = P.NEGOCIACAO_FINAL) 
		END PAGAMENTOS, COALESCE((SELECT DES_COR FROM VEI_COR WHERE EMPRESA = V.EMPRESA AND COR = V.COR) , 
		( select v.des_cor from vei_proposta_veiculo pr, vei_cor v where pr.empresa=P.EMPRESA and pr.revenda=P.REVENDA 
		and pr.proposta=P.PROPOSTA and v.empresa = pr.empresa and v.cor = pr.cor) ) DES_COR, S.DES_SEGMENTO, V.OPCIONAIS 
		FROM VEI_PROPOSTA P INNER JOIN CAC_CONTATO C ON (P.EMPRESA = C.EMPRESA AND P.REVENDA = C.REVENDA AND P.CONTATO = 
		C.CONTATO) INNER JOIN FAT_VENDEDOR E ON (P.EMPRESA = E.EMPRESA AND P.REVENDA = E.REVENDA AND P.VENDEDOR = E.VENDEDOR) 
		INNER JOIN FAT_CLIENTE L ON (C.CLIENTE = L.CLIENTE) LEFT OUTER JOIN VEI_VEICULO V ON (P.EMPRESA_VEICULO = V.EMPRESA) 
		AND(P.VEICULO = V.VEICULO) LEFT OUTER JOIN OFI_FICHA_SEGUIMENTO F ON (V.CHASSI = F.CHASSI) LEFT OUTER 
		JOIN VEI_NEGOCIACAO N ON (P.EMPRESA = N.EMPRESA AND P.REVENDA = N.REVENDA AND P.PROPOSTA = N.PROPOSTA 
		AND P.NEGOCIACAO_FINAL = N.NEGOCIACAO) LEFT OUTER JOIN FAT_SEGMENTO S ON (S.SEGMENTO = P.SEGMENTO_VD) 
		WHERE P.SITUACAO <> 'I' and P.EMPRESA = '{$empresa}' and P.REVENDA = '{$revenda}' AND P.PROPOSTA = '{$proposta}' ORDER BY P.PROPOSTA"));
	}
	
	public function getAdapollo($empresa, $cliente, $titulo, $duplicata){
		return $this->First($this->Select("select t.cliente, t.titulo, t.duplicata, t.tipo, t.dta_emissao, t.dta_vencimento, 
		t.dta_contabil, t.val_titulo, t.status, t.empresa, t.revenda, p.dir_pasta_adiantamento
		from fin_titulo t
		join ger_revenda r on t.empresa = r.empresa and t.revenda = r.revenda
		join sis_empresa e on r.cnpj = e.cnpj
		join fin_parametro p on t.empresa = p.empresa and t.revenda = p.revenda
		where substr(e.cnpj,0,10) = substr(r.cnpj,0,10) and t.cliente = '{$cliente}' and t.titulo = '{$titulo}' and t.tipo = 'AD' and t.duplicata = {$duplicata} and t.status = 'EM' "));
	}
	
	public function getCpapollo($empresa, $cliente, $titulo, $duplicata){
		return $this->First($this->Select("select t.cliente, t.titulo, t.duplicata, t.tipo, t.dta_emissao, t.dta_vencimento,
		t.dta_contabil, t.val_titulo, t.status, t.empresa, t.revenda, p.dir_pasta_adiantamento
		from fin_titulo t
		join ger_revenda r on t.empresa = r.empresa and t.revenda = r.revenda
		join sis_empresa e on r.cnpj = e.cnpj
		join fin_parametro p on t.empresa = p.empresa and t.revenda = p.revenda
		where substr(e.cnpj,0,10) = substr(r.cnpj,0,10) and t.cliente = '{$cliente}' and t.titulo = '{$titulo}' and t.tipo = 'CP' and t.duplicata = {$duplicata} and t.status = 'EM' "));
	}
	
	public function getEmpresaapollo($empresa){
		return $this->Select("select r.empresa, r.revenda, r.razao_social 
		from sis_empresa e
		join ger_revenda r on substr(e.cnpj,0,10) = substr(r.cnpj,0,10)
		where e.empresa = '{$empresa}' order by r.revenda asc");
	}
	public function getAllempresaapollo(){
		return $this->Select("select r.empresa, r.revenda, r.razao_social
		from sis_empresa e
		join ger_revenda r on e.cnpj = r.cnpj
		order by r.empresa asc, r.revenda asc");
	}
	
	public function getDepartamentoapollo($empresa){
		return $this->Select("select d.departamento, d.nome
	    from sis_empresa e
	    join ger_revenda r on substr(e.cnpj,0,10) = substr(r.cnpj,0,10)
	    join ger_departamento d on r.empresa = d.empresa and r.revenda = d.revenda
	    where e.empresa = '{$empresa}' 
	    group by d.departamento, d.nome
	    order by d.departamento");
	}
	
	public function getVendedoresapollo($empresa){
		return $this->Select("select u.usuario, u.login, u.nome, u.grupo 
		from ger_usuario u
		join ger_usuario_revenda ur on u.usuario = ur.usuario AND ur.padrao = 'S'
		join ger_revenda r on ur.empresa = r.empresa and ur.revenda = r.revenda
		where u.ativo = 'S' AND 
		ur.empresa = (select r.empresa from ger_revenda r join sis_empresa e on  r.cnpj = e.cnpj and e.empresa = '{$empresa}')
		order by u.nome ");
	}
}
