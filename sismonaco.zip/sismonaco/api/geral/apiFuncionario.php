<?php

namespace api\geral;

use lib\Model;

class apiFuncionario extends Model {
	
	public function getFuncionariosemail($empresa) {
		return $this->Select("SELECT CASE WHEN p.email is null THEN p.emailcorporativo ELSE p.email END email
	    FROM metadados.rhpessoas p 
	    JOIN metadados.rhcontratos c ON p.empresa = c.empresa AND p.pessoa = c.pessoa
	    JOIN metadados.rhestabelecimentos es ON c.unidade = es.estabelecimento
	    JOIN sis_empresa e ON replace(replace(es.inscricao,'/',''),'-','') = e.cnpj
	    WHERE p.contratosativos = 1 AND e.empresa in ('{$empresa}') 
	    GROUP BY CASE WHEN p.email is null THEN p.emailcorporativo ELSE p.email END");
	}
	
	public function atualizaEmail(){
		return $this->Select("SELECT u.usuario,u.cpf,u.nome,p.email
		FROM sis_usuario u
		JOIN (select p.cpf, case when p.email is null then p.emailcorporativo else p.email end email from metadados.rhpessoas p 
		where p.contratosativos = 1
		group by cpf,case when p.email is null then p.emailcorporativo else p.email end) p ON u.cpf = p.cpf 
		WHERE (u.email = 'naodefinido@grupomonaco.com.br' AND p.email IS NOT NULL) OR (u.email not like '%@grupomonaco.com.br' AND p.email IS NOT NULL)");
	}
	
	public function getAdmissao(){
		return $this->Select("SELECT c.contrato, p.cpf, p.nomecompleto nome, mca.tipo,
		car.cargo, car.departamento, p.nascimento as dta_nascimento, c.dataadmissao as dta_admissao, 
		case when p.emailcorporativo is null then p.email 
		else p.emailcorporativo end email, em.empresa,p.contratosativos ativo
		FROM metadados.rhpessoas p
		JOIN metadados.rhcontratos c ON (p.pessoa = c.pessoa) AND (p.empresa = c.empresa)
		LEFT JOIN sis_int_metacargo mca ON c.cargo = mca.cargo_metadados
        LEFT JOIN sis_cargo car ON mca.cargo = car.cargo
		JOIN metadados.rhestabelecimentos e ON c.unidade = e.estabelecimento
		JOIN sis_empresa em ON replace(replace(e.inscricao,'/',''),'-','') = em.cnpj
		LEFT JOIN sis_usuario u on LPAD(p.cpf, 11, '0') = LPAD(u.cpf, 11, '0')
		WHERE c.dataadmissao = TO_DATE(TO_CHAR(SYSDATE,'dd/mm/yyyy')) AND u.usuario is null");
	}
	
	public function getDemissao(){
		return $this->Select("SELECT u.usuario, u.empresa, u.cpf, u.nome, u.email
		FROM metadados.rhpessoas p
		JOIN metadados.rhcontratos c ON (p.pessoa = c.pessoa) AND (p.empresa = c.empresa)
		JOIN metadados.rhestabelecimentos e ON c.unidade = e.estabelecimento
		JOIN sis_empresa em ON replace(replace(e.inscricao,'/',''),'-','') = em.cnpj
		JOIN sis_usuario u on LPAD(p.cpf, 11, '0') = LPAD(u.cpf, 11, '0')
		WHERE c.datarescisao = TO_DATE(TO_CHAR(SYSDATE,'dd/mm/yyyy')) AND u.ativo = '1'");
	}
	
	public function getFeriasinicio(){
		return $this->Select("SELECT u.usuario, u.empresa, u.cpf, u.nome, u.email, c.datainicioferias, c.dataterminoferias
	    FROM metadados.rhpessoas p
	    JOIN metadados.rhcontratos c ON (p.pessoa = c.pessoa) AND (p.empresa = c.empresa) AND c.situacao = '1'
	    JOIN metadados.rhestabelecimentos e ON c.unidade = e.estabelecimento
	    JOIN sis_empresa em ON replace(replace(e.inscricao,'/',''),'-','') = em.cnpj
	    JOIN sis_usuario u on LPAD(p.cpf, 11, '0') = LPAD(u.cpf, 11, '0')
	    WHERE c.datainicioferias = TO_DATE(TO_CHAR(SYSDATE,'dd/mm/yyyy')) AND u.ativo = '1'
	    AND TRUNC(TO_DATE(u.dta_ult_alteracao, 'dd/mm/yyyy hh24:mi:ss')) < TRUNC(SYSDATE)");
	}
	public function getFeriastermino(){
		return $this->Select("SELECT u.usuario, u.empresa, u.cpf, u.nome, u.email, c.datainicioferias, c.dataterminoferias
		FROM metadados.rhpessoas p
		JOIN metadados.rhcontratos c ON (p.pessoa = c.pessoa) AND (p.empresa = c.empresa) AND c.situacao = '1'
		JOIN metadados.rhestabelecimentos e ON c.unidade = e.estabelecimento
		JOIN sis_empresa em ON replace(replace(e.inscricao,'/',''),'-','') = em.cnpj
		LEFT JOIN sis_usuario u on LPAD(p.cpf, 11, '0') = LPAD(u.cpf, 11, '0')
		WHERE (c.dataterminoferias = trunc(SYSDATE+1) AND
       	u.ativo = '0' AND trunc(to_date(u.dta_ult_alteracao,'dd/mm/yyyy hh24:mi:ss')) < trunc(SYSDATE))
    	OR (c.dataterminoferias = trunc(SYSDATE-1) AND u.ativo = '0' AND c.datarescisao is null)");
	}
	
	public function getAfastamentoinicio(){
		return $this->Select("select r.unidade, r.contrato, u.usuario, u.cpf, u.nome, u.email, o.ocorrencia,
		o.descricao40, r.datainicioocorrencia, r.dataterminoocorrencia 
		from metadados.rhregocorrencias r
		join metadados.rhocorrencias o on r.ocorrencia = o.ocorrencia
		join metadados.rhestabelecimentos es on r.unidade = es.estabelecimento
		join sis_empresa e on replace(replace(es.inscricao,'/',''),'-','') = e.cnpj
		join sis_usuario u  on r.contrato = u.contrato and e.empresa = u.empresa
		where r.ocorrencia in ('004','007','008','009','501','504','505','506') and 
		r.datainicioocorrencia = trunc(sysdate) and u.ativo = 1
		and r.dataterminoocorrencia - r.datainicioocorrencia >= 5 ");
	}
	public function getAfastamentotermino(){
		return $this->Select("select r.unidade, r.contrato, u.usuario, u.cpf, u.nome, u.email, o.ocorrencia, 
		o.descricao40, r.datainicioocorrencia, r.dataterminoocorrencia 
		from metadados.rhregocorrencias r
		join metadados.rhocorrencias o on r.ocorrencia = o.ocorrencia
		join metadados.rhestabelecimentos es on r.unidade = es.estabelecimento
		join sis_empresa e on replace(replace(es.inscricao,'/',''),'-','') = e.cnpj
		join sis_usuario u  on r.contrato = u.contrato and e.empresa = u.empresa
		where r.ocorrencia in ('004','007','008','009','501','504','505','506') and
		r.dataterminoocorrencia = trunc(sysdate) and u.ativo = 0
		and r.dataterminoocorrencia - r.datainicioocorrencia >= 5");
	}
	
	public function validaEmail($email){
		return $this->Select("SELECT email from sis_usuario WHERE LOWER(email) = '{$email}'");
	}
}