<?php

namespace api\geral;

use lib\Model;
use obj\geral\Empresa;
use helper\PrepareSQL;
use helper\Funcoes;

class apiEmpresa extends Model {
	
	public function getEmpresa(Empresa $obj) {
		return  $this->First($this->Select("SELECT * FROM sis_empresa WHERE empresa = '{$obj->empresa}'"));
	}
	
	public function filtroEmpresa($c, $a, $coluna = NULL, $val = NULL, Empresa $obj = NULL) {
		$funcoes = new Funcoes();
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		$condicao = array(
			'1'	=> " WHERE LOWER(e.{$coluna}) = '{$val}' ",
			'2' => " WHERE LOWER(e.{$coluna}) LIKE '%{$val}%' ",
			'3'	=> " WHERE e.empresa is not null ",
			'4' => " WHERE LOWER(e.des_empresa) LIKE '%".@$funcoes->retiraAcentos(trim($obj->des_empresa))."%' OR LOWER(e.cnpj) = '".@$obj->cnpj."' "
		);
		$ativo = array(
			'1' => "AND e.ativo = '1' ",	
			'2' => "AND e.ativo = '0' ",
			'3' => "",
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT e.empresa, e.ordem, e.des_empresa, e.razao_social, e.cnpj, e.endereco, 
		e.nro_endereco, e.uf, e.cidade, e.bairro, e.cep, e.ativo
		FROM sis_empresa e{$condicao[$c]}{$ativo[$a]}ORDER BY e.ordem) R ) R2");
	}
	public function getMatrizes() {
		return $this->Select("SELECT gr.empresa, gr.revenda, gr.cnpj, gr.razao_social, pj.dta_fundacao, 
		pj.registro_junta, gr.uf, gr.cidade 
		FROM cnp.ger_revenda gr
		JOIN cnp.fat_pessoa_juridica pj ON gr.cliente = pj.cliente 
		WHERE gr.cnpj in (05024583000104,05285816000122,05442121000107,
		07811058000164,09597026000133,84189950000104,08904510000103,05298654000167,07431634000148,
		02952676000100,13976589000100,18548319000111) ORDER BY gr.empresa ASC, gr.revenda ASC");
	}
	
	public function geEmpresarevenda($empresa) {
		return $this->First($this->Select("SELECT gr.empresa, gr.revenda, gr.cnpj, gr.razao_social, pj.dta_fundacao,
		pj.registro_junta, gr.uf, gr.cidade
		FROM cnp.ger_revenda gr
		JOIN cnp.fat_pessoa_juridica pj ON gr.cliente = pj.cliente
		JOIN sis_empresa e ON gr.cnpj = e.cnpj
		WHERE e.empresa = '{$empresa}' ORDER BY gr.empresa ASC, gr.revenda ASC"));
	}
	
	public function getMatrizefiliais($empresa){
		return $this->Select("select e.empresa, e.ordem, e.des_empresa, e.razao_social, e.cnpj 
		from sis_empresa e 
		where substr(e.cnpj,0,10) = (select substr(cnpj,0,10) from sis_empresa where empresa = '{$empresa}')
		order by ordem");
	}
	
	public function addEmpresa(Empresa $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_empresa = strtoupper($funcoes->retiraAcentos(trim($obj->des_empresa)));
		$obj->razao_social = strtoupper($funcoes->retiraAcentos(trim($obj->razao_social)));
		$obj->endereco = strtoupper($funcoes->retiraAcentos(trim($obj->endereco)));
		$obj->uf = strtoupper($funcoes->retiraAcentos(trim($obj->uf)));
		$obj->cidade = strtoupper($funcoes->retiraAcentos(trim($obj->cidade)));
		$obj->bairro = strtoupper($funcoes->retiraAcentos(trim($obj->bairro)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'sis_empresa','empresa');
	}
	
	public function editEmpresa(Empresa $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_empresa = strtoupper($funcoes->retiraAcentos(trim($obj->des_empresa)));
		$obj->razao_social = strtoupper($funcoes->retiraAcentos(trim($obj->razao_social)));
		$obj->endereco = strtoupper($funcoes->retiraAcentos(trim($obj->endereco)));
		$obj->uf = strtoupper($funcoes->retiraAcentos(trim($obj->uf)));
		$obj->cidade = strtoupper($funcoes->retiraAcentos(trim($obj->cidade)));
		$obj->bairro = strtoupper($funcoes->retiraAcentos(trim($obj->bairro)));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'empresa';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('empresa' => $obj['empresa']), 'sis_empresa');
	}
	
	public function delEmpresa(Empresa $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('empresa' => $obj->empresa), 'sis_empresa');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}