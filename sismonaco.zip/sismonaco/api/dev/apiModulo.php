<?php

namespace api\dev;

use lib\Model;
use obj\dev\Modulo;
use helper\PrepareSQL;
use helper\Funcoes;

class apiModulo extends Model {

	public function getModulo(Modulo $obj) {
		return  $this->First($this->Select("SELECT * FROM sis_modulo WHERE modulo = '{$obj->modulo}'"));
	}

	public function filtroModulo($c, $a, $coluna = NULL, $val = NULL) {
		$funcoes = new Funcoes();
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		$condicao = array(
			'1'	=> " WHERE LOWER(TRANSLATE(m.{$coluna},
			'�������������������������������������������������������',
			'SZszYACEIOUAEIOUAEIOUAOEUIONYaaceiouaeiouaeiouaoeuionyy')) = '{$val}' ",
			'2' => " WHERE LOWER(TRANSLATE(m.{$coluna},
			'�������������������������������������������������������',
			'SZszYACEIOUAEIOUAEIOUAOEUIONYaaceiouaeiouaeiouaoeuionyy')) LIKE '%{$val}%' ",
			'3'	=> " ",
		);
		$ativo = array(
			'1' => "AND m.ativo = '1' ",
			'2' => "AND m.ativo = '0' ",
			'3' => "",
		);
		return $this->Select("SELECT R2.* 
		FROM (SELECT rownum n_linha, R.* 
		FROM(SELECT m.modulo, m.des_reduzida, m.des_modulo, m.ativo 
		FROM sis_modulo m{$condicao[$c]}{$ativo[$a]}ORDER BY m.modulo DESC) R ) R2");	
	}

	public function addModulo(Modulo $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_reduzida = ucfirst(trim($obj->des_reduzida));
		$obj->des_modulo = $funcoes->formataTexto(trim($obj->des_modulo));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'sis_modulo','modulo');	
	}

	public function editModulo(Modulo $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_reduzida = ucfirst(trim($obj->des_reduzida));
		$obj->des_modulo = $funcoes->formataTexto(trim($obj->des_modulo));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'modulo';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('modulo' => $obj['modulo']), 'sis_modulo');
	}

	public function delModulo(Modulo $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('modulo' => $obj->modulo), 'sis_modulo');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}