<?php

namespace api\dev;

use lib\Model;
use obj\dev\Rotina;
use helper\PrepareSQL;
use helper\Funcoes;

class apiRotina extends Model {
	
	public function getRotina(Rotina $obj) {
		return  $this->First($this->Select("SELECT r.rotina, ar.frequencia, r.des_reduzida, r.des_rotina, 
		r.ativo , ar.hora_execucao, ar.dta_ult_execucao, ar.hora_ult_execucao,
		ar.erro_ult_execucao, ar.prioridade
		FROM sis_rotina r
		LEFT JOIN sis_agenda_rotina ar ON r.rotina = ar.rotina 
		WHERE r.rotina = '{$obj->rotina}'"));
	}
	
	public function filtroRotina($c, $a, $prioridade, $coluna = NULL, $val = NULL) {
		$funcoes = new Funcoes();
		if ($prioridade != "tudo"){
			$pri = "WHERE ar.prioridade = '{$prioridade}' ";
		}else{
			$pri = "WHERE r.rotina is not null ";
			
		}
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		$condicao = array(
			'1'	=> "AND LOWER(TRANSLATE({$coluna},
			'�������������������������������������������������������',
            'SZszYACEIOUAEIOUAEIOUAOEUIONYaaceiouaeiouaeiouaoeuionyy')) = '{$val}' ",
			'2' => "AND LOWER(TRANSLATE({$coluna},
			'�������������������������������������������������������',
            'SZszYACEIOUAEIOUAEIOUAOEUIONYaaceiouaeiouaeiouaoeuionyy')) LIKE '%{$val}%' ",
			'3'	=> " ",
		);
		$ativo = array(
			'1' => "AND r.ativo = '1' ",
			'2' => "AND r.ativo = '0' ",
			'3' => " ",
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM (SELECT r.rotina, ar.frequencia, r.des_reduzida, r.des_rotina, 
		r.ativo , ar.hora_execucao, ar.dta_ult_execucao, ar.hora_ult_execucao, 
		ar.erro_ult_execucao, ar.prioridade
		FROM sis_rotina r
		LEFT JOIN sis_agenda_rotina ar ON r.rotina = ar.rotina
		{$pri}{$condicao[$c]}{$ativo[$a]}ORDER BY r.rotina DESC) R ) R2");
	}
	
	public function addRotina(Rotina $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_reduzida = strtolower($funcoes->retiraAcentos(trim($obj->des_reduzida)));
		$obj->des_rotina = $funcoes->formataTexto(trim($obj->des_rotina));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'sis_rotina','rotina');
	}
	
	public function editRotina(Rotina $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_reduzida = strtolower($funcoes->retiraAcentos(trim($obj->des_reduzida)));
		$obj->des_rotina = $funcoes->formataTexto(trim($obj->des_rotina));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'rotina';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('rotina' => $obj['rotina']), 'sis_rotina');
	}
	
	public function delRotina(Rotina $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('rotina' => $obj->rotina), 'sis_rotina');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}