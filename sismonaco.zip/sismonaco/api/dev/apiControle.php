<?php

namespace api\dev;

use lib\Model;
use obj\dev\Controle;
use helper\PrepareSQL;
use helper\Funcoes;

class apiControle extends Model {

	public function getControle(Controle $obj) {
		return  $this->First($this->Select("SELECT * FROM sis_controle WHERE controle = '{$obj->controle}'"));
	}

	public function filtroControle($c, $a, $coluna = NULL, $val = NULL) {
		$funcoes = new Funcoes();
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		$condicao = array(
			'1'	=> " WHERE LOWER(TRANSLATE(c.{$coluna},
			'�������������������������������������������������������',
			'SZszYACEIOUAEIOUAEIOUAOEUIONYaaceiouaeiouaeiouaoeuionyy')) = '{$val}' ",
			'2' => " WHERE LOWER(TRANSLATE(c.{$coluna},
			'�������������������������������������������������������',
			'SZszYACEIOUAEIOUAEIOUAOEUIONYaaceiouaeiouaeiouaoeuionyy')) LIKE '%{$val}%' ",
			'3'	=> " ",
		);
		$ativo = array(
			'1' => "AND c.ativo = '1' ",
			'2' => "AND c.ativo = '0' ",
			'3' => "",
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT c.controle, c.des_reduzida, c.des_controle, c.ativo
		FROM sis_controle c{$condicao[$c]}{$ativo[$a]}ORDER BY c.controle DESC) R ) R2");
	}

	public function addControle(Controle $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_reduzida = strtolower($funcoes->retiraAcentos(trim($obj->des_reduzida)));
		$obj->des_controle = $funcoes->formataTexto(trim($obj->des_controle));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'sis_controle','controle');
	}

	public function editControle(Controle $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_reduzida = strtolower($funcoes->retiraAcentos(trim($obj->des_reduzida)));
		$obj->des_controle = $funcoes->formataTexto(trim($obj->des_controle));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'controle';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('controle' => $obj['controle']), 'sis_controle');
	}

	public function delControle(Controle $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('controle' => $obj->controle), 'sis_controle');
	}

	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}