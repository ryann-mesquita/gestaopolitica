<?php

namespace api\dev;

use lib\Model;
use obj\dev\Modulocontroleacao;
use helper\PrepareSQL;

class apiModulocontroleacao extends Model {
	
	public function getModulocontroleacao(Modulocontroleacao $obj) {
		return  $this->First($this->Select("SELECT mca.modulo, m.des_reduzida md, m.des_modulo, 
		mca.controle, c.des_reduzida ct, c.des_controle, mca.acao, a.des_reduzida ac, a.des_acao 
		FROM sis_modulo_controle_acao mca
		JOIN sis_modulo m ON mca.modulo = m.modulo
        JOIN sis_controle c ON mca.controle = c.controle
		JOIN sis_acao a ON mca.acao = a.acao  
		WHERE mca.modulo = '{$obj->modulo}' AND mca.controle = '{$obj->controle}' AND mca.acao = '{$obj->acao}'"));
	}
	
	public function filtroModulocontroleacao($condicao) {
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM( SELECT mca.modulo, m.des_reduzida md, m.des_modulo, 
		mca.controle, c.des_reduzida ct, c.des_controle, mca.acao, a.des_reduzida ac, a.des_acao 
		FROM sis_modulo_controle_acao mca
		JOIN sis_modulo m ON mca.modulo = m.modulo
        JOIN sis_controle c ON mca.controle = c.controle
		JOIN sis_acao a ON mca.acao = a.acao WHERE {$condicao} 
		ORDER BY mca.modulo DESC, mca.controle DESC, mca.acao DESC) R ) R2");
	}
	
	public function alloModulocontroleacao() {
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM( SELECT mca.modulo, m.des_reduzida md, m.des_modulo,
		mca.controle, c.des_reduzida ct, c.des_controle, mca.acao, a.des_reduzida ac, a.des_acao
		FROM sis_modulo_controle_acao mca
		JOIN sis_modulo m ON mca.modulo = m.modulo
		JOIN sis_controle c ON mca.controle = c.controle
		JOIN sis_acao a ON mca.acao = a.acao WHERE m.ativo = '1' 
		AND c.ativo = '1' AND a.ativo = '1'
		ORDER BY mca.modulo ASC, mca.controle ASC, mca.acao ASC) R ) R2");
	}
	
	public function addModulocontroleacao(Modulocontroleacao $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareInsert($obj, 'sis_modulo_controle_acao');
	}
	
	public function delModulocontroleacao(Modulocontroleacao $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('modulo' => $obj->modulo, 'controle' => $obj->controle, 'acao' => $obj->acao), 'sis_modulo_controle_acao');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}