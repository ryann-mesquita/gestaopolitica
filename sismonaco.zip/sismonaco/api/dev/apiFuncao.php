<?php

namespace api\dev;

use lib\Model;
use obj\dev\Funcao;
use obj\adm\Usuario;
use helper\PrepareSQL;
use helper\Funcoes;

class apiFuncao extends Model {
	
	public function getFuncao(Funcao $obj) {
		return  $this->First($this->Select("SELECT f.funcao, f.des_funcao, f.modulo, m.des_reduzida, m.des_modulo, f.ativo
		FROM sis_funcao f JOIN sis_modulo m ON f.modulo = m.modulo WHERE f.funcao = '{$obj->funcao}' AND f.modulo = '{$obj->modulo}'"));
	}

	public function funcaoUsuario(Usuario $obj) {
		return $this->Select("SELECT fu.funcao, f.des_funcao, fu.modulo, m.des_reduzida, m.des_modulo,
 		fu.usuario, u.nome, u.cpf
		FROM sis_funcao_usuario fu
		JOIN sis_funcao f ON fu.funcao = f.funcao
		JOIN sis_usuario u ON fu.usuario = u.usuario
		JOIN sis_modulo m ON fu.modulo = m.modulo
		WHERE fu.usuario = '{$obj->usuario}' AND f.ativo = '1'
		ORDER BY f.modulo,fu.funcao");
	}
	
	public function filtroFuncao($c, $a, $coluna = NULL, $val = NULL, $modulo = NULL) {
		$funcoes = new Funcoes();
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		$condicao = array(
			'1'	=> " WHERE LOWER(TRANSLATE({$coluna},
			'�������������������������������������������������������',
            'SZszYACEIOUAEIOUAEIOUAOEUIONYaaceiouaeiouaeiouaoeuionyy')) = '{$val}' ",
			'2' => " WHERE LOWER(TRANSLATE({$coluna},
            '�������������������������������������������������������',
            'SZszYACEIOUAEIOUAEIOUAOEUIONYaaceiouaeiouaeiouaoeuionyy')) LIKE '%{$val}%' ",
			'3'	=> " ",
			'4'	=> " WHERE LOWER(TRANSLATE({$coluna},
			'�������������������������������������������������������',
            'SZszYACEIOUAEIOUAEIOUAOEUIONYaaceiouaeiouaeiouaoeuionyy')) = '{$val}' AND f.modulo = '{$modulo}' ",
		);
		$ativo = array(
			'1' => "AND a.ativo = '1' ",
			'2' => "AND a.ativo = '0' ",
			'3' => "",
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT f.funcao, f.des_funcao, f.modulo, m.des_reduzida, m.des_modulo, f.ativo
		FROM sis_funcao f JOIN sis_modulo m ON f.modulo = m.modulo{$condicao[$c]}{$ativo[$a]}ORDER BY f.funcao ASC) R ) R2");
	}
	
	public function addFuncao(Funcao $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_funcao = $funcoes->formataTexto(trim($obj->des_funcao));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'sis_funcao');
	}
	
	public function addFuncaousuario(Funcao $obj,$currval = NULL) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		if ($currval != NULL){
			$obj = array_filter($obj, function($v){return $v != 'usuario';}, ARRAY_FILTER_USE_KEY);
			return $prepare->PrepareInsert($obj, 'sis_funcao_usuario',"",$currval);
		}else{
			return $prepare->PrepareInsert($obj, 'sis_funcao_usuario');
		}
	}
	
	public function editFuncao(Funcao $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_funcao = $funcoes->formataTexto(trim($obj->des_funcao));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'funcao' && $v != 'modulo';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('funcao' => $obj['funcao'], 'modulo' => $obj['modulo']), 'sis_funcao');
	}
	
	public function delFuncao(Funcao $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('funcao' => $obj->funcao, 'modulo' => $obj->modulo), 'sis_funcao');
	}
	
	public function delFuncaousuario(Funcao $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('funcao' => $obj->funcao, 'usuario' => $obj->usuario, 'modulo' => $obj->modulo), 'sis_funcao_usuario');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}