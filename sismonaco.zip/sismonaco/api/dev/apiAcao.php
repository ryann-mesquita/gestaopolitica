<?php

namespace api\dev;

use lib\Model;
use obj\dev\Acao;
use helper\PrepareSQL;
use helper\Funcoes;

class apiAcao extends Model {

	public function getAcao(Acao $obj) {
		return  $this->First($this->Select("SELECT * FROM sis_acao WHERE acao = '{$obj->acao}'"));
	}

	public function filtroAcao($c, $a, $coluna = NULL, $val = NULL) {
		$val = strtolower(trim($val));
		$condicao = array(
			'1'	=> " WHERE LOWER(a.{$coluna}) = '{$val}' ",
			'2' => " WHERE LOWER(a.{$coluna}) LIKE '%{$val}%' ",
			'3'	=> " ",
		);
		$ativo = array(
			'1' => "AND a.ativo = '1' ",
			'2' => "AND a.ativo = '0' ",
			'3' => "",
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT a.acao, a.des_reduzida, a.des_acao, a.ativo
		FROM sis_acao a{$condicao[$c]}{$ativo[$a]}ORDER BY a.acao DESC) R ) R2");
	}

	public function addAcao(Acao $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_reduzida = strtolower($funcoes->retiraAcentos(trim($obj->des_reduzida)));
		$obj->des_acao = $funcoes->formataTexto(trim($obj->des_acao));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'sis_acao','acao');
	}

	public function editAcao(Acao $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_reduzida = strtolower($funcoes->retiraAcentos(trim($obj->des_reduzida)));
		$obj->des_acao = $funcoes->formataTexto(trim($obj->des_acao));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'acao';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('acao' => $obj['acao']), 'sis_acao');
	}

	public function delAcao(Acao $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('acao' => $obj->acao), 'sis_acao');
	}

	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}