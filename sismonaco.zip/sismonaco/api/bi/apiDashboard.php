<?php

namespace api\bi;

use lib\Model;
use helper\PrepareSQL;
use helper\Funcoes;

class apiDashboard extends Model {
	
	public function filtroDashboard($c, $a, $coluna = NULL, $val = NULL, $de = NULL, $ate = NULL){
		$val = strtolower(trim($val));
		$condicao = array(
				'1'	=> " AND LOWER(t.{$coluna}) = '{$val}' ",
				'2' => " AND LOWER(t.{$coluna}) LIKE '%{$val}%' ",
				'3'	=> "",
				'4' => "",
		);
		$ativo = array(
				'1' => "",
				'2' => "",
				'3' => "",
		);
		
		return $this->Select("SELECT R2.*
				FROM (SELECT rownum n_linha, R.*
				FROM(select t.empresa, t.revenda, t.cliente, y.nome, t.origem, g.des_origem, t.tipo, t.titulo, t.duplicata, t.status, T.DTA_EMISSAO, T.DTA_CONTABIL ,T.DTA_VENCIMENTO, T.PAGAR_RECEBER, t.departamento,
				t.val_titulo, nvl(ftp.valor_pago,0) valor_pago, t.val_titulo-nvl(ftp.valor_pago,0) saldo
				from cnp.fin_titulo t
				left join
				(select ftp2.empresa, ftp2.revenda, ftp2.titulo, ftp2.duplicata, ftp2.cliente, ftp2.Tipo, nvl(sum(ftp2.val_pagamento)-s1.val_devolucao,sum(ftp2.val_pagamento)) valor_pago
						from fin_titulo_pagamento ftp2
						left join
						(select fch.empresa, fch.revenda, fch.titulo, fch.duplicata, fch.cliente, fch.tipo, sum(fch.val_devolucao) val_devolucao
								from fin_devolucao_cheque fch
								group by fch.empresa, fch.revenda, fch.titulo, fch.duplicata, fch.cliente, fch.tipo) s1
						on (ftp2.EMPRESA = s1.EMPRESA and ftp2.REVENDA = s1.REVENDA and ftp2.TITULO = s1.TITULO and ftp2.DUPLICATA = s1.DUPLICATA and ftp2.CLIENTE = s1.CLIENTE and ftp2.TIPO = s1.TIPO)
						group by ftp2.empresa, ftp2.revenda, ftp2.titulo, ftp2.duplicata, ftp2.cliente, ftp2.Tipo, s1.val_devolucao
						) ftp
				on (t.EMPRESA = ftp.EMPRESA and t.REVENDA = ftp.REVENDA and t.TITULO = ftp.TITULO and t.DUPLICATA = ftp.DUPLICATA and t.CLIENTE = ftp.CLIENTE and t.TIPO = ftp.TIPO)
				join fat_cliente y on (t.cliente = y.cliente)
				left JOIN FIN_ORIGEM G on(t.empresa = g.empresa and t.revenda = g.revenda and t.origem = g.origem)
				where t.empresa in (1,2,3,4,5,7,9,11,13) and t.status IN ('EM','PP')
				and t.DTA_VENCIMENTO <= TO_DATE('30/10/2030','dd/mm/yyyy') and
				t.tipo in ('CR','CT','CH')
				{$condicao[$c]}{$ativo[$a]} order by t.empresa, t.revenda, t.titulo, t.tipo, T.DTA_VENCIMENTO) R ) R2");
				
	}
}