<?php

namespace api\bi;

use lib\Model;
use obj\bi\Relatorio;
use helper\PrepareSQL;
use helper\Funcoes;

class apiRelatorio extends Model {
	
	public function getRelatorio(Relatorio $obj) {
		return  $this->First($this->Select("SELECT *
		FROM bi_relatorio r
		WHERE r.relatorio = '{$obj->relatorio}'"));
	}
	
	public function filtroRelatorio($c, $a, $coluna = NULL, $val = NULL) {
		$funcoes = new Funcoes();
	//	$val = strtolower($funcoes->retiraAcentos(trim($val)));
		$condicao = array(
				'1'	=> " WHERE LOWER(r.{$coluna}) = '{$val}' ",
				'2' => " WHERE LOWER(r.{$coluna}) LIKE '%{$val}%' ",
				'3'	=> "",
				'4' => "",
		);
		$ativo = array(
			'1' => "AND r.ativo = '1' ",
			'2' => "AND r.ativo = '0' ",
			'3' => "",
		);
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM (SELECT *
		FROM bi_relatorio r
		{$condicao[$c]}{$ativo[$a]}ORDER BY r.relatorio DESC) R ) R2");
	}
	
	public function addRelatorio(Relatorio $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_reduzida = strtolower($funcoes->retiraAcentos(trim($obj->des_reduzida)));
		$obj->des_relatorio = $funcoes->formataTexto(trim($obj->des_relatorio));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'bi_relatorio','relatorio');
	}
	
	public function editRelatorio(Relatorio $obj) {
		$prepare = new PrepareSQL();
		$funcoes = new Funcoes();
		$obj->des_reduzida = strtolower($funcoes->retiraAcentos(trim($obj->des_reduzida)));
		$obj->des_relatorio = $funcoes->retiraAcentos(trim($obj->des_relatorio));
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		$set = array_filter($obj, function($v){return $v != 'relatorio';}, ARRAY_FILTER_USE_KEY);
		return $prepare->PrepareUpdate($set,array('relatorio' => $obj['relatorio']), 'bi_relatorio');
	}
	
	public function delRelatorio(Relatorio $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('relatorio' => $obj->relatorio), 'bi_relatorio');
	}
	
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}