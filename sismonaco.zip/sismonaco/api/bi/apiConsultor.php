<?php

namespace api\bi;

use lib\Model;
use obj\bi\Consultor;
use helper\PrepareSQL;
use helper\Funcoes;

class apiConsultor extends Model {
	
	public function getConsultor(Consultor $obj) {
		return  $this->First($this->Select("SELECT c.consultor, u.nome, c.departamento, d.des_departamento
		FROM bi_consultor c JOIN sis_usuario u ON c.consultor = u.usuario
		JOIN sis_departamento d ON c.departamento = d.departamento WHERE c.consultor = '{$obj->consultor}' AND c.departamento = '{$obj->departamento}' "));
	}
	
	public function filtroConsultor($c, $d, $coluna = NULL, $val = NULL) {
		$funcoes = new Funcoes();
		$val = strtolower($funcoes->retiraAcentos(trim($val)));
		$condicao = array(
			'1'	=> " WHERE LOWER({$coluna}) = '{$val}' ",
			'2' => " WHERE LOWER({$coluna}) LIKE '%{$val}%' ",
			'3'	=> " ",
		);
		if ($d == 'tudo') {
			$departamento = " ";
		}else{
			$departamento = "AND c.departamento = '{$d}' ";
		}
		return $this->Select("SELECT R2.*
		FROM (SELECT rownum n_linha, R.*
		FROM(SELECT c.consultor, u.nome, c.departamento, d.des_departamento
		FROM bi_consultor c JOIN sis_usuario u ON c.consultor = u.usuario
		JOIN sis_departamento d on c.departamento = d.departamento
		{$condicao[$c]}{$departamento}ORDER BY u.nome ASC, d.des_departamento ASC) R ) R2");
	}
	
	public function getDepartamento(){
		return $this->Select("SELECT DISTINCT c.departamento, d.des_departamento FROM bi_consultor c
		LEFT JOIN sis_departamento d ON c.departamento = d.departamento");
	}

	public function addConsultor(Consultor $obj) {
		$prepare = new PrepareSQL();
		$obj = (array) $obj;
		$obj = array_filter($obj, function($v){return !is_null($v);});
		return $prepare->PrepareInsert($obj, 'bi_consultor');
	}
	
	public function delConsultor(Consultor $obj) {
		$prepare = new PrepareSQL();
		return $prepare->PrepareDelete(array('consultor' => $obj->consultor, 'departamento' => $obj->departamento), 'bi_consultor');
	}
	public function executeSQL($sql){
		return $this->Execute($sql);
	}
}