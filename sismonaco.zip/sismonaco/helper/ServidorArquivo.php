<?php

namespace helper;

class ServidorArquivo {

	private $resSFTP;

	public function __construct() {
		$strServer = "10.3.101.20";
		$strServerPort = "22";
		$strServerUsername = "apollo";
		$strServerPassword = "m0n4c0";
		$resConnection = ssh2_connect($strServer, $strServerPort);
		if(ssh2_auth_password($resConnection, $strServerUsername, $strServerPassword)){		
			$this->resSFTP = ssh2_sftp($resConnection);	
		}
	}

	public function MandaArquivo($local,$nome_arquivo) {
		$mes = strtolower(date('F'));
		$pasta = date('d-m-Y');
		if ($mes == "january"){
			$mes = "Janeiro";
		}elseif ($mes == "february"){
			$mes = "Fevereiro";
		}elseif ($mes == "march"){
			$mes = "Marco";
		}elseif ($mes == "april"){
			$mes = "Abril";
		}elseif ($mes == "may"){
			$mes = "Maio";
		}elseif ($mes == "june"){
			$mes = "Junho";
		}elseif ($mes == "july"){
			$mes = "Julho";
		}elseif ($mes == "august"){
			$mes = "Agosto";
		}elseif ($mes == "september"){
			$mes = "Setembro";
		}elseif ($mes == "october"){
			$mes = "Outubro";
		}elseif ($mes == "november"){
			$mes = "Novembro";
		}elseif ($mes == "december"){
			$mes = "Dezembro";
		}
		mkdir("ssh2.sftp://". intval($this->resSFTP)."/{$local}/".$mes."");
		mkdir("ssh2.sftp://". intval($this->resSFTP)."/{$local}/".$mes."/".$pasta, 0775,true);
		$localfile = APP_ROOT.$nome_arquivo;
		if (copy($localfile, "ssh2.sftp://". intval($this->resSFTP)."/{$local}/{$mes}/{$pasta}/{$nome_arquivo}") && unlink(__DIR__."/../{$nome_arquivo}")){
			return 'sucesso';		
		}else{	
			return 'falha';
		}		
	}

	public function ImportaNota($arquivo,$nome_arquivo,$empresa,$cnpj) {
		if (($cnpj == "05024583000104")||($cnpj == "05024583000295")||($cnpj == "05024583000538")||
			($cnpj == "07811058000164")||($cnpj == "07811058000245")||($cnpj == "07811058000326")||
			($cnpj == "07811058000407")||($cnpj == "07811058000598")||($cnpj == "05285816000122")||
			($cnpj == "05285816000203")||($cnpj == "05442121000107")||($cnpj == "05442121000298")||
			($cnpj == "05442121000530")||($cnpj == "09597026000133")){
				$pasta = $empresa."-VW";
		}elseif(($cnpj == "84189950000104")||($cnpj == "84189950000287")||($cnpj == "84189950000368")||
			($cnpj == "84189950000449")||($cnpj == "08904510000103")||($cnpj == "13976589000100")||
			($cnpj == "13976589000290")||($cnpj == "13976589000371")||($cnpj == "13976589000452")||
			($cnpj == "13976589000533")||($cnpj == "13976589000703")||($cnpj == "05298654000167")||
			($cnpj == "07431634000148")||($cnpj == "07431634000490")||($cnpj == "02952676000100")||
			($cnpj == "02952676000453")||($cnpj == "02952676000704")||($cnpj == "02952676000887")){
				$pasta = $empresa."-HONDA";
		}elseif (($cnpj == "19954308000102")||($cnpj == "19954308000285")){
			$pasta = $empresa."-AUTOMOTORES";
		}elseif (($cnpj == "18548319000111")||($cnpj == "18548319000200")||($cnpj == "18548319000464")){
			$pasta = $empresa."-VEICULOS";
		}elseif (($cnpj == "09163579000188")||($cnpj == "02671917000143")||($cnpj == "07031623000170")){
			$pasta = $empresa."-PARTICIPACOES";
		}
		mkdir("ssh2.sftp://". intval($this->resSFTP)."/apollo_notas/".$pasta, 0775,true);
		if (move_uploaded_file($arquivo, "ssh2.sftp://". intval($this->resSFTP)."/apollo_notas/".$pasta."/".$nome_arquivo.".pdf")){
			return 'sucesso';
		}else{
			return 'falha';
		}
			
	}
	public function RenomearNota($nome_antigo,$nome_novo,$empresa,$cnpj) {
		if (($cnpj == "05024583000104")||($cnpj == "05024583000295")||($cnpj == "05024583000538")||
			($cnpj == "07811058000164")||($cnpj == "07811058000245")||($cnpj == "07811058000326")||
			($cnpj == "07811058000407")||($cnpj == "07811058000598")||($cnpj == "05285816000122")||
			($cnpj == "05285816000203")||($cnpj == "05442121000107")||($cnpj == "05442121000298")||
			($cnpj == "05442121000530")||($cnpj == "09597026000133")){
				$pasta = $empresa."-VW";
		}elseif(($cnpj == "84189950000104")||($cnpj == "84189950000287")||($cnpj == "84189950000368")||
			($cnpj == "84189950000449")||($cnpj == "08904510000103")||($cnpj == "13976589000100")||
			($cnpj == "13976589000290")||($cnpj == "13976589000371")||($cnpj == "13976589000452")||
			($cnpj == "13976589000533")||($cnpj == "13976589000703")||($cnpj == "05298654000167")||
			($cnpj == "07431634000148")||($cnpj == "07431634000490")||($cnpj == "02952676000100")||
			($cnpj == "02952676000453")||($cnpj == "02952676000704")||($cnpj == "02952676000887")){
				$pasta = $empresa."-HONDA";
		}elseif (($cnpj == "19954308000102")||($cnpj == "19954308000285")){
			$pasta = $empresa."-AUTOMOTORES";
		}elseif (($cnpj == "18548319000111")||($cnpj == "18548319000200")||($cnpj == "18548319000464")){
			$pasta = $empresa."-VEICULOS";
		}elseif (($cnpj == "09163579000188")||($cnpj == "02671917000143")||($cnpj == "07031623000170")){
			$pasta = $empresa."-PARTICIPACOES";
		}
		if (rename("ssh2.sftp://". intval($this->resSFTP)."/apollo_notas/".$pasta."/".$nome_antigo.".pdf","ssh2.sftp://". intval($this->resSFTP)."/apollo_notas/".$pasta."/".$nome_novo.".pdf")){
			return 'sucesso';
		}else{
			return 'falha';
		}		
	}

	public function RemoverNota($nome,$empresa,$cnpj) {
		if (($cnpj == "05024583000104")||($cnpj == "05024583000295")||($cnpj == "05024583000538")||
			($cnpj == "07811058000164")||($cnpj == "07811058000245")||($cnpj == "07811058000326")||
			($cnpj == "07811058000407")||($cnpj == "07811058000598")||($cnpj == "05285816000122")||
			($cnpj == "05285816000203")||($cnpj == "05442121000107")||($cnpj == "05442121000298")||
			($cnpj == "05442121000530")||($cnpj == "09597026000133")){
				$pasta = $empresa."-VW";
		}elseif(($cnpj == "84189950000104")||($cnpj == "84189950000287")||($cnpj == "84189950000368")||
			($cnpj == "84189950000449")||($cnpj == "08904510000103")||($cnpj == "13976589000100")||
			($cnpj == "13976589000290")||($cnpj == "13976589000371")||($cnpj == "13976589000452")||
			($cnpj == "13976589000533")||($cnpj == "13976589000703")||($cnpj == "05298654000167")||
			($cnpj == "07431634000148")||($cnpj == "07431634000490")||($cnpj == "02952676000100")||
			($cnpj == "02952676000453")||($cnpj == "02952676000704")||($cnpj == "02952676000887")){
				$pasta = $empresa."-HONDA";
		}elseif (($cnpj == "19954308000102")||($cnpj == "19954308000285")){
			$pasta = $empresa."-AUTOMOTORES";
		}elseif (($cnpj == "18548319000111")||($cnpj == "18548319000200")||($cnpj == "18548319000464")){
			$pasta = $empresa."-VEICULOS";
		}elseif (($cnpj == "09163579000188")||($cnpj == "02671917000143")||($cnpj == "07031623000170")){
			$pasta = $empresa."-PARTICIPACOES";
		}
		if (unlink("ssh2.sftp://". intval($this->resSFTP)."/apollo_notas/".$pasta."/".$nome.".pdf")){
			return 'sucesso';
		}else{
			return 'falha';
		}		
	}
}