<?php

namespace helper;

use classes\PHPMailer;
use api\geral\apiEmail;
use obj\modules\Emails;
use obj\geral\Email;


include 'classes/PHPMailer/class.phpmailer.php';

class EnvioEmail {

	private $Host = "email-ssl.com.br";
	private $IsHTML = true;
	private $SMTPAuth = true;
	private $SMTPSecure = "ssl";
	private $Username = 'infosismonaco@grupomonaco.com.br';
	private $Password = '4dM.grup0.D0mR';
	private $Port = 465;

	public function Envio($de, $assunto, $mensagem, $para, $cc = NULL,$anexo = NULL) {
		$email = new PHPMailer();
		$email->IsSMTP();
		$email->Host = $this->Host;
		$email->IsHTML($this->IsHTML);
		$email->SMTPAuth = $this->SMTPAuth;
		$email->SMTPSecure = $this->SMTPSecure;
		
		$email->Username = $this->Username;
		$email->Password = $this->Password;
		$email->Port = $this->Port;


		$email->From = $this->Username;
		$email->FromName  = $de;
		$email->Subject   = $assunto;
		$email->MsgHTML($mensagem);

		foreach ($para as $para){
			$email->AddAddress("{$para}");
		}
		if ($cc != NULL) {
			foreach ($cc as $cc){	
				$email->AddCC("{$cc}");	
			}
		}
		if ($anexo != NULL) {
			$email->AddAttachment($_SERVER["DOCUMENT_ROOT"] . "/".RAIZ_PATH.$anexo."");
		}

		$email->Send();
		$email->ClearAllRecipients();
		$email->ClearAttachments();

		if($email->ErrorInfo != NULL){
			return 'falha';	
		}else {
			@unlink($_SERVER["DOCUMENT_ROOT"] . "/".RAIZ_PATH.$anexo."");
			return 'sucesso';		
		}

	}

	public function Envioagendado($emails,$rotinas) {
		$qtd = 0;
		$conta = 1;
		$envio = array();
		$sql = array();
		$ind = 0;
		$Email = new Email();
		$apiEmail = new apiEmail();

		foreach ($emails as $em) {	
			$qtd = $qtd + 1;	
			if ($qtd == 91||$qtd == 181||$qtd == 271||$qtd == 361) {
				$conta = $conta + 1;
			}
			$envio[$conta][$em->ROTINA][$em->N_LINHA] = array('cod' => $em->COD, 'rotina' => $em->ROTINA,
			'remetente'=>$em->REMETENTE,'destinatario'=>$em->DESTINATARIO,'assunto'=>$em->ASSUNTO,
			'mensagem'=>$em->MENSAGEM,'anexo'=>$em->ANEXO);
		}
		$conta = $conta + 1;
		for ($i=1;$i<$conta;$i++){
			foreach ($rotinas as $ro) {
				unset($email);
				$email = new PHPMailer();
				$email->IsSMTP();
				$email->Host = $this->Host;
				$email->IsHTML($this->IsHTML);
				$email->SMTPAuth = $this->SMTPAuth;
				$email->SMTPSecure = $this->SMTPSecure;
				$email->Username = "noreply.sis{$i}@grupomonaco.com.br";
				$email->Password = "sis no10";
				$email->Port = $this->Port;
				$email->From  = "noreply.sis{$i}@grupomonaco.com.br";

				foreach ($envio[$i][$ro->ROTINA] as $e) {
					$email->FromName  = $e['remetente'];
					$email->Subject   = $e['assunto'];
					$email->MsgHTML($e['mensagem']);
					$email->AddAddress("{$e['destinatario']}");
					$Email->cod .= "'{$e['cod']}',";	
					if ($e['anexo'] != NULL) {	
						$email->AddAttachment($_SERVER["DOCUMENT_ROOT"] . "/".RAIZ_PATH.$e['anexo']);	
					}
				}
				$email->Send();
				$email->ClearAllRecipients();
				$email->ClearAttachments();
				$Email->dta_enviado = date("d/m/Y H:i:s");
				if($email->ErrorInfo == NULL){
					$Email->situacao = 'E';	
				}else{
					$Email->situacao = 'N';
					$Email->mensagem_erro = $email->ErrorInfo;		
				}
				$sql[$ind] = $apiEmail->editEmail($Email);
				$ind = $ind + 1;
			}
		}
		$rs = $apiEmail->executeSQL($sql);
		if ($rs[4] == "sucesso"){
			return "sucesso";	
		}else{
			return "falha";	
		}
	}
}