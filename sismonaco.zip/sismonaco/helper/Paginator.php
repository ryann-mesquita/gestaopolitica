<?php

namespace helper;

class Paginator {
	
	public function navPaginator($Modulo,$Controle,$Acao,$PaginaAtual,$ItemPorPagina,$TotalItem) {
		
		$PageView = "";
		$url = APP_ROOT.$Modulo.'/'.$Controle.'/'.$Acao;
		if ($TotalItem > $ItemPorPagina) {
			
			$TotalPaginas = ceil($TotalItem/$ItemPorPagina);
			
			$PageView .= "<div class='pagination-wrap'>";
			$PageView .="<ul class='pagination'>";
			
			if ($PaginaAtual != 1){
				
				$Previous = $PaginaAtual - 1;
				$PageView .= "<li><a href='{$url}/pagina/1'>Primeira</a></li>";
				$PageView .= "<li><a href='{$url}/pagina/{$Previous}'>Anterior</a></li>";
			}
			
			for ($i=1;$i<=$TotalPaginas;$i++){
				
				if ($i == $PaginaAtual){
					
					$PageView .= "<li class='active'><a href='{$url}/pagina/{$i}'>{$i}</a></li>";
				}else{
					$PageView .= "<li><a href='{$url}/pagina/{$i}'>{$i}</a></li>";
				}
				
			}
			
			if ($PaginaAtual != $TotalPaginas){
				
				$Next = $PaginaAtual + 1;
				$PageView .= "<li><a href='{$url}/pagina/{$Next}'>Pr�xima</a></li>";
				$PageView .= "<li><a href='{$url}/pagina/{$TotalPaginas}'>�ltima</a></li>";
			}
			$PageView .="</ul>";
			$PageView .="</div>";
		}
		return $PageView;
	}
}