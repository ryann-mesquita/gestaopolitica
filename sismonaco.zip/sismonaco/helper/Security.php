<?php

namespace helper;

class Security {
	
	public function __construct($module,$controller,$action) {
		
		if (!isset($_SESSION['usuario_sessao']) || empty($_SESSION['usuario_sessao'])) {
			
			header('location:' .APP_ROOT. 'home/auth/auth');
			
		}else {
			
			if (isset($_SESSION['tempo_sessao'])) {
				
				$duracao_sessao = 1800;
				
				if(((time() - $_SESSION['tempo_sessao']) > $duracao_sessao)){
					session_unset();
					header('location:' .APP_ROOT. 'home/auth/auth');
					exit();
				}else{
					$_SESSION['tempo_sessao'] = $_SESSION['tempo_sessao'] + (time() - $_SESSION['tempo_sessao']);
				}
			}
			
			if (!isset($_SESSION["permissao_sessao"]["{$_SESSION['empresa_sessao']}-{$module['modulo']}-{$controller['controle']}-{$action['acao']}"])){
				header('location:' .APP_ROOT. ''.$_SESSION['modulo_anterior'].'/'.$_SESSION['controle_anterior'].'/'.$_SESSION['acao_anterior'].'/acessonegado');
				exit();			
			}else{
				$_SESSION['modulo_anterior'] = $module['des_modulo'];
				$_SESSION['controle_anterior'] = $controller['des_controle'];
				$_SESSION['acao_anterior'] = $action['des_acao'];
			}
		}
	}
}
