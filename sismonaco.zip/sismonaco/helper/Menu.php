<?php

namespace helper;

use lib\Router;

class Menu extends Router{
	public function criarMenu($modulo) {
		
		$pageView = "";
		
		if ($modulo == "dev") {
			
			if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['modulo']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['controle']['controle']}-{$this->actions['index']['acao']}"]) 
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['acao']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['funcao']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['rotina']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['modulocontroleacao']['controle']}-{$this->actions['index']['acao']}"])) {
				$pageView .= "<ul class='nav navbar-nav'><li class='dropdown'>";
				$pageView .= "<a href='#' class='dropdown-toggle' data-toggle='dropdown'><span class='glyphicon glyphicon-th-list align-left' aria-hidden='true'></span> Cadastros<b class='caret'></b></a>";
				$pageView .= "<ul class='dropdown-menu'>";
					if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['modulo']['controle']}-{$this->actions['index']['acao']}"])) {
						$pageView .= "<li><a href='modulo/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Modulo</a></li>";
					}
					if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['controle']['controle']}-{$this->actions['index']['acao']}"])) {
						$pageView .= "<li><a href='controle/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Controle</a></li>";
					}
					if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['acao']['controle']}-{$this->actions['index']['acao']}"])) {
						$pageView .= "<li><a href='acao/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> A��o</a></li>";
					}
					if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['funcao']['controle']}-{$this->actions['index']['acao']}"])) {
						$pageView .= "<li><a href='funcao/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Fun��o</a></li>";
					}
					if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['rotina']['controle']}-{$this->actions['index']['acao']}"])) {
						$pageView .= "<li><a href='rotina/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Rotina</a></li>";
					}
					if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['modulocontroleacao']['controle']}-{$this->actions['index']['acao']}"])) {
						$pageView .= "<li><a href='modulocontroleacao/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Modulo x Controle x A��o</a></li>";
					}
				$pageView .= "</ul>";
				$pageView .= "</li></ul>";
			}
		}
		
		if ($modulo == "adm") {
				
			if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['empresa']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['tipo']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['departamento']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['area']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['cargo']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['usuario']['controle']}-{$this->actions['index']['acao']}"])) {
				$pageView .= "<ul class='nav navbar-nav'><li class='dropdown'>";
				$pageView .= "<a href='#' class='dropdown-toggle' data-toggle='dropdown'><span class='glyphicon glyphicon-th-list align-left' aria-hidden='true'></span> Cadastros<b class='caret'></b></a>";
				$pageView .= "<ul class='dropdown-menu'>";
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['empresa']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='empresa/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Empresa</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['tipo']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='tipo/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Tipo</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['departamento']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='departamento/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Departamento</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['area']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='area/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Area</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['cargo']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='cargo/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Cargo</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['usuario']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='usuario/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Usu�rio</a></li>";
				}
				$pageView .= "</ul>";
				$pageView .= "</li></ul>";
			}
			
			if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['permissao']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['rotinausuario']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['agendarotina']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['log']['controle']}-{$this->actions['index']['acao']}"])) {
				$pageView .= "<ul class='nav navbar-nav'><li class='dropdown'>";
				$pageView .= "<a href='#' class='dropdown-toggle' data-toggle='dropdown'><span class='glyphicon glyphicon-th-list align-left' aria-hidden='true'></span> Gerenciamento<b class='caret'></b></a>";
				$pageView .= "<ul class='dropdown-menu'>";
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['permissao']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='permissao/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Permiss�o</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['rotinausuario']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='rotinausuario/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Rotinas e Usu�rio</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['agendarotina']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='agendarotina/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Agenda de Rotina</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['log']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='log/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Log</a></li>";
				}
				$pageView .= "</ul>";
				$pageView .= "</li></ul>";
			}
		}
		
		if ($modulo == "ged") {
			
			if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['grupo']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['grupousuario']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['tipo']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['orgao']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['aviso']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['usuarioavisoorgao']['controle']}-{$this->actions['index']['acao']}"])) {
				$pageView .= "<ul class='nav navbar-nav'><li class='dropdown'>";
				$pageView .= "<a href='#' class='dropdown-toggle' data-toggle='dropdown'><span class='glyphicon glyphicon-th-list align-left' aria-hidden='true'></span> Cadastros<b class='caret'></b></a>";
				$pageView .= "<ul class='dropdown-menu'>";
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['grupo']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='grupo/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Grupo</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['grupousuario']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='grupousuario/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Grupo x Usuario</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['tipo']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='tipo/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Tipo de �rg�o</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['orgao']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='orgao/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> �rg�o</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['aviso']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='aviso/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Aviso</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['usuarioavisoorgao']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='usuarioavisoorgao/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Usu�rio x Aviso x �rg�o</a></li>";
				}
				$pageView .= "</ul>";
				$pageView .= "</li></ul>";
			}
			
			if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['documento']['controle']}-{$this->actions['index']['acao']}"])) {
				$pageView .= "<ul class='nav navbar-nav'>";
					$pageView .= "<li><a href='documento/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Documento</a></li>";
				$pageView .= "</ul>";
			}
		}
		
		if ($modulo == "monaco") {
				
			if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['notafiscal']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['departamentopessoal']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['contabilidade']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['posvenda']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['recursoshumanos']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['disc']['controle']}-{$this->actions['index']['acao']}"])) {
				$pageView .= "<ul class='nav navbar-nav'><li class='dropdown'>";
				$pageView .= "<a href='#' class='dropdown-toggle' data-toggle='dropdown'><span class='glyphicon glyphicon-th-list align-left' aria-hidden='true'></span> Customiza��es<b class='caret'></b></a>";
				$pageView .= "<ul class='dropdown-menu'>";
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['notafiscal']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='notafiscal/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Nota Fiscal</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['departamentopessoal']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li class='dropdown dropdown-submenu'>";
					$pageView .= "<a href='#' class='dropdown-toggle' data-toggle='dropdown'><span class='glyphicon glyphicon-object-align-left align-left' aria-hidden='true'></span> Departamento Pessoal</a>";
				    $pageView .= "<ul class='dropdown-menu'>";
				    if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['departamentopessoal']['controle']}-{$this->actions['customiza1']['acao']}"])) {
				    	$pageView .= "<li><a href='departamentopessoal/customiza1'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Exporta��o Ponto Metadados</a></li>";
				    }
				    if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['departamentopessoal']['controle']}-{$this->actions['customiza2']['acao']}"])) {
				    	$pageView .= "<li><a href='departamentopessoal/customiza2'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Lista de E-mails</a></li>";
				    }
				    $pageView .= "</ul>";
				    $pageView .= "</li>";	
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['contabilidade']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li class='dropdown dropdown-submenu'>";
					$pageView .= "<a href='#' class='dropdown-toggle' data-toggle='dropdown'><span class='glyphicon glyphicon-object-align-left align-left' aria-hidden='true'></span> Contabilidade</a>";
					$pageView .= "<ul class='dropdown-menu'>";
					if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['contabilidade']['controle']}-{$this->actions['customiza1']['acao']}"])) {
						$pageView .= "<li><a href='contabilidade/customiza1'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Balancete</a></li>";
					}
					$pageView .= "</ul>";
					$pageView .= "</li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['posvenda']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li class='dropdown dropdown-submenu'>";
					$pageView .= "<a href='#' class='dropdown-toggle' data-toggle='dropdown'><span class='glyphicon glyphicon-object-align-left align-left' aria-hidden='true'></span> P�s Venda</a>";
					$pageView .= "<ul class='dropdown-menu'>";
					if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['posvenda']['controle']}-{$this->actions['customiza1']['acao']}"])) {
						$pageView .= "<li><a href='posvenda/customiza1'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Espelho de O.S</a></li>";
					}
					if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['posvenda']['controle']}-{$this->actions['customiza2']['acao']}"])) {
						$pageView .= "<li><a href='posvenda/customiza2'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Arquivo F�brica-Fiat</a></li>";
					}
					$pageView .= "</ul>";
					$pageView .= "</li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['recursoshumanos']['controle']}-{$this->actions['index']['acao']}"])
				||isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['recursoshumanos']['controle']}-{$this->actions['visualizar']['acao']}"])
				||isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['disc']['controle']}-{$this->actions['index']['acao']}"])
			    ||isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['disc']['controle']}-{$this->actions['adicionar']['acao']}"])
				||isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['disc']['controle']}-{$this->actions['visualizar']['acao']}"])) {
					$pageView .= "<li class='dropdown dropdown-submenu'>";
					$pageView .= "<a href='#' class='dropdown-toggle' data-toggle='dropdown'><span class='glyphicon glyphicon-object-align-left align-left' aria-hidden='true'></span> Recursos Humanos</a>";
					$pageView .= "<ul class='dropdown-menu'>";
					if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['recursoshumanos']['controle']}-{$this->actions['index']['acao']}"])
					||isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['recursoshumanos']['controle']}-{$this->actions['visualizar']['acao']}"])){
							$pageView .= "<li class='dropdown dropdown-submenu'>";
							$pageView .= "<a href='#' class='dropdown-toggle' data-toggle='dropdown'><span class='glyphicon glyphicon-object-align-left align-left' aria-hidden='true'></span> Pesquisa de Clima</a>";
							$pageView .= "<ul class='dropdown-menu'>";
							if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['recursoshumanos']['controle']}-{$this->actions['index']['acao']}"])) {
								$pageView .= "<li><a href='recursoshumanos/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Visualizar</a></li>";
							}
							if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['recursoshumanos']['controle']}-{$this->actions['visualizar']['acao']}"])) {
								$pageView .= "<li><a href='recursoshumanos/visualizar'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Sugest�es</a></li>";
							}
							$pageView .= "</ul>";
							$pageView .= "</li>";
				    	}
				    	if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['disc']['controle']}-{$this->actions['index']['acao']}"])
				    	||isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['disc']['controle']}-{$this->actions['adicionar']['acao']}"])
		    			||isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['disc']['controle']}-{$this->actions['visualizar']['acao']}"])){
		    				$pageView .= "<li class='dropdown dropdown-submenu'>";
		    				$pageView .= "<a href='#' class='dropdown-toggle' data-toggle='dropdown'><span class='glyphicon glyphicon-object-align-left align-left' aria-hidden='true'></span> Disc</a>";
		    				$pageView .= "<ul class='dropdown-menu'>";
		    				if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['disc']['controle']}-{$this->actions['index']['acao']}"])) {
		    					$pageView .= "<li><a href='disc/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Responder</a></li>";
		    				}
		    				if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['disc']['controle']}-{$this->actions['adicionar']['acao']}"])) {
		    					$pageView .= "<li><a href='disc/adicionar'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Adicionar</a></li>";
		    				}
		    				if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['disc']['controle']}-{$this->actions['visualizar']['acao']}"])) {
		    					$pageView .= "<li><a href='disc/visualizar'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Visualizar</a></li>";
		    				}
		    				$pageView .= "</ul>";
		    				$pageView .= "</li>";
				    	}
				    	if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['recursoshumanos']['controle']}-{$this->actions['customiza1']['acao']}"])) {
				    		$pageView .= "<li><a href='recursoshumanos/customiza1'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> MP/RP</a></li>";
				    	}
					$pageView .= "</ul>";
					$pageView .= "</li>";
				}
				$pageView .= "</ul>";
				$pageView .= "</li></ul>";
			}
		}
		
		if ($modulo == "gpj") {
			
			if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['natureza']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['consultor']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['vara']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['cidade']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['status']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['tipo']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['item']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['risco']['controle']}-{$this->actions['index']['acao']}"])) {
				$pageView .= "<ul class='nav navbar-nav'><li class='dropdown'>";
				$pageView .= "<a href='#' class='dropdown-toggle' data-toggle='dropdown'><span class='glyphicon glyphicon-th-list align-left' aria-hidden='true'></span> Cadastros<b class='caret'></b></a>";
				$pageView .= "<ul class='dropdown-menu'>";
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['natureza']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='natureza/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Natureza</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['consultor']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='consultor/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Consultor</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['vara']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='vara/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Vara</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['cidade']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='cidade/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Cidade</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['status']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='status/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Status</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['tipo']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='tipo/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Tipo</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['item']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='item/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Item</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['risco']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='risco/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Risco</a></li>";
				}
				$pageView .= "</ul>";
				$pageView .= "</li></ul>";
			}
			
			if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['processo']['controle']}-{$this->actions['index']['acao']}"])) {
				$pageView .= "<ul class='nav navbar-nav'>";
				$pageView .= "<li><a href='processo/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Processo</a></li>";
				$pageView .= "</ul>";
			}
			if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['dashboard']['controle']}-{$this->actions['index']['acao']}"])) {
				$pageView .= "<ul class='nav navbar-nav'>";
				$pageView .= "<li><a href='dashboard/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Dashboard</a></li>";
				$pageView .= "</ul>";
			}
		}
		
		if ($modulo == "help") {
			
			if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['tipo']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['status']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['ambiente']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['categoria']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['subcategoria']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['calendario']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['tecnico']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['tecempsubcategoria']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['consolidado']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['projeto']['controle']}-{$this->actions['index']['acao']}"])) {
				$pageView .= "<ul class='nav navbar-nav'><li class='dropdown'>";
				$pageView .= "<a href='#' class='dropdown-toggle' data-toggle='dropdown'><span class='glyphicon glyphicon-th-list align-left' aria-hidden='true'></span> Cadastros<b class='caret'></b></a>";
				$pageView .= "<ul class='dropdown-menu'>";
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['tipo']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='tipo/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Tipo</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['status']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='status/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Status</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['ambiente']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='ambiente/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Ambiente</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['categoria']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='categoria/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Categoria</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['subcategoria']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='subcategoria/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Sub-Categoria</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['calendario']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='calendario/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Calend�rio</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['tecnico']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='tecnico/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> T�cnico</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['tecempsubcategoria']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='tecempsubcategoria/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> T�cnico X Empresa X Subcategoria</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['consolidado']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='consolidado/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Consolidado</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['projeto']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='projeto/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Projetos</a></li>";
				}
				$pageView .= "</ul>";
				$pageView .= "</li></ul>";
			}
			
			if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['chamado']['controle']}-{$this->actions['index']['acao']}"])) {
				$pageView .= "<ul class='nav navbar-nav'>";
				$pageView .= "<li><a href='chamado/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Chamados</a></li>";
				$pageView .= "</ul>";
			}
			if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['dashboard']['controle']}-{$this->actions['index']['acao']}"])) {
				$pageView .= "<ul class='nav navbar-nav'>";
				$pageView .= "<li><a href='dashboard/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Dashboard</a></li>";
				$pageView .= "</ul>";
			}
		}
		if ($modulo == "sav") {
			
			if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['empresa']['controle']}-{$this->actions['index']['acao']}"])) {
				$pageView .= "<ul class='nav navbar-nav'>";
				$pageView .= "<li><a href='empresa/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Empresas</a></li>";
				$pageView .= "</ul>";
			}
			if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['proposta']['controle']}-{$this->actions['index']['acao']}"])) {
				$pageView .= "<ul class='nav navbar-nav'>";
				$pageView .= "<li><a href='proposta/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Propostas</a></li>";
				$pageView .= "</ul>";
			}
			if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['dashboard']['controle']}-{$this->actions['index']['acao']}"])) {
				$pageView .= "<ul class='nav navbar-nav'>";
				$pageView .= "<li><a href='dashboard/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Dashboard</a></li>";
				$pageView .= "</ul>";
			}
		}
		
		if ($modulo == "finan") {
			
			if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['item']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['tipo']['controle']}-{$this->actions['index']['acao']}"])) {
				$pageView .= "<ul class='nav navbar-nav'><li class='dropdown'>";
				$pageView .= "<a href='#' class='dropdown-toggle' data-toggle='dropdown'><span class='glyphicon glyphicon-th-list align-left' aria-hidden='true'></span> Cadastros<b class='caret'></b></a>";
				$pageView .= "<ul class='dropdown-menu'>";
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['item']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='item/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Item</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['tipo']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='tipo/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Tipo</a></li>";
				}
				$pageView .= "</ul>";
				$pageView .= "</li></ul>";
			}
			if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['adiantamento']['controle']}-{$this->actions['index']['acao']}"])) {
				$pageView .= "<ul class='nav navbar-nav'>";
				$pageView .= "<li><a href='adiantamento/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Adiantamento</a></li>";
				$pageView .= "</ul>";
			}
		}
		
		if ($modulo == "com") {
			
			if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['tipo']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['grupo']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['produtivo']['controle']}-{$this->actions['alterar']['acao']}"])) {
				$pageView .= "<ul class='nav navbar-nav'><li class='dropdown'>";
				$pageView .= "<a href='#' class='dropdown-toggle' data-toggle='dropdown'><span class='glyphicon glyphicon-th-list align-left' aria-hidden='true'></span> Cadastros<b class='caret'></b></a>";
				$pageView .= "<ul class='dropdown-menu'>";
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['tipo']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='tipo/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Tipo</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['grupo']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='grupo/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Grupo</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['campanha']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='campanha/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Campanha</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['grupo']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='produtivo/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Parametros Produtivo</a></li>";
				}
				$pageView .= "</ul>";
				$pageView .= "</li></ul>";
			}
		}
		
		if ($modulo == "sgc") {
			if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['tipo']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['indice']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['pagamento']['controle']}-{$this->actions['index']['acao']}"])
			|| isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['periodicidade']['controle']}-{$this->actions['index']['acao']}"])) {
				$pageView .= "<ul class='nav navbar-nav'><li class='dropdown'>";
				$pageView .= "<a href='#' class='dropdown-toggle' data-toggle='dropdown'><span class='glyphicon glyphicon-th-list align-left' aria-hidden='true'></span> Cadastros<b class='caret'></b></a>";
				$pageView .= "<ul class='dropdown-menu'>";
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['tipo']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='tipo/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Tipo</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['indice']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='indice/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Indice</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['pagamento']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='pagamento/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Forma Pagamento</a></li>";
				}
				if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['periodicidade']['controle']}-{$this->actions['index']['acao']}"])) {
					$pageView .= "<li><a href='periodicidade/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Periodicidade</a></li>";
				}
				$pageView .= "</ul>";
				$pageView .= "</li></ul>";
			}
			
			if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['contrato']['controle']}-{$this->actions['index']['acao']}"])) {
				$pageView .= "<ul class='nav navbar-nav'>";
				$pageView .= "<li><a href='contrato/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Contrato</a></li>";
				$pageView .= "</ul>";
			}

		}
		if ($modulo == "ptc") {
			if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['lote']['controle']}-{$this->actions['index']['acao']}"])) {
				$pageView .= "<ul class='nav navbar-nav'>";
				$pageView .= "<li><a href='lote/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span>Lote</a></li>";
				$pageView .= "</ul>";
			}
		}
		if ($modulo == "bi") {
			if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['consultor']['controle']}-{$this->actions['index']['acao']}"]) 
			||isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['relatorio']['controle']}-{$this->actions['index']['acao']}"])
			||isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['dashboard']['controle']}-{$this->actions['index']['acao']}"]))
			{
				$pageView .= "<ul class='nav navbar-nav'><li class='dropdown'>";
				$pageView .= "<a href='#' class='dropdown-toggle' data-toggle='dropdown'><span class='glyphicon glyphicon-th-list align-left' aria-hidden='true'></span> Cadastros<b class='caret'></b></a>";
				$pageView .= "<ul class='dropdown-menu'>";
			if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['consultor']['controle']}-{$this->actions['index']['acao']}"])) {
				$pageView .= "<li><a href='consultor/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Consultor</a></li>";
			}	
			if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['relatorio']['controle']}-{$this->actions['index']['acao']}"])) {
				$pageView .= "<li><a href='relatorio/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Relatorio</a></li>";
			}	
				$pageView .= "</ul>";
				$pageView .= "</li></ul>";
			}
			
			if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['relatoriodept']['controle']}-{$this->actions['index']['acao']}"]))
			{
				$pageView .= "<ul class='nav navbar-nav'><li class='dropdown'>";
				$pageView .= "<a href='#' class='dropdown-toggle' data-toggle='dropdown'><span class='glyphicon glyphicon-th-list align-left' aria-hidden='true'></span> Gerenciamento<b class='caret'></b></a>";
				$pageView .= "<ul class='dropdown-menu'>";
			if(isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['relatoriodept']['controle']}-{$this->actions['index']['acao']}"])) {
				$pageView .= "<li><a href='relatoriodept/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Relatorio Departamento </a></li>";
			}
				$pageView .= "</ul>";
				$pageView .= "</li></ul>";
			}
			if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['dashboard']['controle']}-{$this->actions['index']['acao']}"])) {
				$pageView .= "<ul class='nav navbar-nav'>";
				$pageView .= "<li><a href='dashboard/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span>Dashboard</a></li>";
				$pageView .= "</ul>";
			}
		}
		
		if ($modulo == "sie") {
			if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['frota']['controle']}-{$this->actions['index']['acao']}"])) {
				$pageView .= "<ul class='nav navbar-nav'><li class='dropdown'>";
				$pageView .= "<a href='#' class='dropdown-toggle' data-toggle='dropdown'><span class='glyphicon glyphicon-th-list align-left' aria-hidden='true'></span> Cadastros<b class='caret'></b></a>";
				$pageView .= "<ul class='dropdown-menu'>";
				
				$pageView .= "</ul>";
				$pageView .= "</li></ul>";
			}
			
			if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['frota']['controle']}-{$this->actions['index']['acao']}"])) {
				$pageView .= "<ul class='nav navbar-nav'>";
				$pageView .= "<li><a href='frota/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Frota</a></li>";
				$pageView .= "</ul>";
			}
			if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['passagem']['controle']}-{$this->actions['index']['acao']}"])) {
				$pageView .= "<ul class='nav navbar-nav'>";
				$pageView .= "<li><a href='passagem/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Passagem</a></li>";
				$pageView .= "</ul>";
			}
			if (isset($_SESSION['permissao_sessao']["{$_SESSION['empresa_sessao']}-{$this->modules[$modulo]['modulo']}-{$this->controllers['hospedagem']['controle']}-{$this->actions['index']['acao']}"])) {
				$pageView .= "<ul class='nav navbar-nav'>";
				$pageView .= "<li><a href='hospedagem/index'><span class='glyphicon glyphicon-object-align-horizontal align-left' aria-hidden='true'></span> Hospedagem</a></li>";
				$pageView .= "</ul>";
			}
			
			
		}
		
		
		
		
		
		return $pageView;
	}
}