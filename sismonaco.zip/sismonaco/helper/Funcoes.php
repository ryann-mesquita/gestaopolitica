<?php

namespace helper;

use classes\Feriado;
use api\com\apiIndex;

class Funcoes {
	
	public function retiraAcentos($string){    // remove qualquer acento
		$de = utf8_decode("áàãâéêíóôõúüçÁÀÃÂÉÊÍÓÔÕÚÜÇ");
		$para = "aaaaeeiooouucAAAAEEIOOOUUC";
		return strtr($string, $de, $para);
	}
	
	public function acentosMaiusculo($string){
		$de = utf8_decode("áàãâéêíóôõúüç");
		$para = utf8_decode("ÁÀÃÂÉÊÍÓÔÕÚÜÇ");
		return strtr($string, $de, $para);
	}
	
	public function naoNumerico($string){   // remove qualquer caracter não numerico
		return preg_replace("/\D+/", "", $string);
	}
	
	public function mask($val, $mask) {
		$maskared = '';
		$k = 0;
		for($i = 0; $i<=strlen($mask)-1; $i++)
		{
			if($mask[$i] == '#')
			{
				if(isset($val[$k]))
					$maskared .= $val[$k++];
			}else{
				if(isset($mask[$i]))
					$maskared .= $mask[$i];
			}
		}
		return $maskared;
	}
	
	public function sanearValor($valor) {
		//pega sinal negativo
		$sinal = substr($valor, 0, 1);
		// Pega apenas as partes numericas
		$partes = array_filter(preg_split("/([\D])/", $valor), 'strlen');
		// Separa a fração do inteiro
		$frac = count($partes) > 1 ? array_pop($partes) : "0";
		$inteiro = implode("", $partes);
		// Junta tudo, converte para ponto-flutuante e arredondanda
		//return ($sinal == "-") ? "-" .str_replace(".", ",", round((float) ($inteiro . "." . $frac), 2)) : str_replace(".", ",", round((float) ($inteiro . "." . $frac), 2));
		return ($sinal == "-") ? "-" .round((float) ($inteiro . "." . $frac), 2) : round((float) ($inteiro . "." . $frac), 2);
	}
	
	public function formataTexto( $texto ) {
		$regra = array(' A '=>' a ',' As '=>' as ',' Os '=>' os ',' E '=>' e ',' Com '=>' com ',
				' Em '=>' em ',' De '=>' de ',' Do '=>' do ',' Das '=>' das ',' Da '=>' da ',' Dos '=>' dos ');
		$texto = ucwords( strtolower( $texto ) );
		return str_replace(array_keys($regra), $regra, $texto);
	}
	
	public function senhaAleatoria()
	{
		$maiusculas = "A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z";
		$minusculas = strtolower($maiusculas);
		$numeros = "1,2,3,4,5,6,7,8,9,0";
		$codigos = "!,@,#,$,%,&";
		
		$word = $maiusculas;
		$word .= $minusculas;
		$word .= $numeros;
		$word .= $codigos;
		
		$array = explode(",", $word);
		shuffle($array);
		$newstring = implode($array, "");
		return substr($newstring, 0, 10);
	}
	
	function somarDiasuteis($str_data,$int_qtd_dias_somar,$feriados) {
		// Caso seja informado uma data do MySQL do tipo DATETIME - aaaa-mm-dd 00:00:00
		// Transforma para DATE - aaaa-mm-dd
		$str_data = substr($str_data,0,10);
		// Se a data estiver no formato brasileiro: dd/mm/aaaa
		// Converte-a para o padrão americano: aaaa-mm-dd
		if ( preg_match("@/@",$str_data) == 1 ) {
			
			$str_data = implode("-", array_reverse(explode("/",$str_data)));
			
		}
		$Feriado = new Feriado();
		// chama a funcao que calcula a pascoa
		$pascoa_dt = $Feriado->dataPascoa(date('Y'));
		$aux_p = explode("/", $pascoa_dt);
		$aux_dia_pas = $aux_p[0];
		$aux_mes_pas = $aux_p[1];
		$pascoa = "$aux_mes_pas"."-"."$aux_dia_pas"; // crio uma data somente como mes e dia
		
		// chama a funcao que calcula o carnaval
		$carnaval_dt = $Feriado->dataCarnaval(date('Y'));
		$aux_carna = explode("/", $carnaval_dt);
		$aux_dia_carna = $aux_carna[0];
		$aux_mes_carna = $aux_carna[1];
		$carnaval = "$aux_mes_carna"."-"."$aux_dia_carna";
		
		// chama a funcao que calcula corpus christi
		$CorpusChristi_dt = $Feriado->dataCorpusChristi(date('Y'));
		$aux_cc = explode("/", $CorpusChristi_dt);
		$aux_cc_dia = $aux_cc[0];
		$aux_cc_mes = $aux_cc[1];
		$Corpus_Christi = "$aux_cc_mes"."-"."$aux_cc_dia";
		
		// chama a funcao que calcula a sexta feira santa
		$sexta_santa_dt = $Feriado->dataSextaSanta(date('Y'));
		$aux = explode("/", $sexta_santa_dt);
		$aux_dia = $aux[0];
		$aux_mes = $aux[1];
		$sexta_santa = "$aux_mes"."-"."$aux_dia";
		
		$feriados = array("01-01", $carnaval, $sexta_santa, $pascoa, $Corpus_Christi, "04-21", "05-01", "06-12" ,"07-09", "07-16", "09-07", "10-12", "11-02", "11-15", "12-24", "12-25", "12-31");
		
		$array_data = explode('-', $str_data);
		$count_days = 0;
		$int_qtd_dias_uteis = 0;
		
		while ( $int_qtd_dias_uteis < $int_qtd_dias_somar ) {
			
			$count_days++;
			$day = date('m-d',strtotime('+'.$count_days.'day',strtotime($str_data)));
			
			if(($dias_da_semana = gmdate('w', strtotime('+'.$count_days.' day', gmmktime(0, 0, 0, $array_data[1], $array_data[2], $array_data[0]))) ) != '0' && $dias_da_semana != '6' && !in_array($day,$feriados)) {
				
				$int_qtd_dias_uteis++;
			}
			
		}
		
		return gmdate('d/m/Y',strtotime('+'.$count_days.' day',strtotime($str_data)));		
	}
	
	function valorPorextenso($valor = 0, $maiusculas = true) {
		$singular = array("centavo", "real", "mil", "milhão", "bilhão", "trilhão", "quatrilhão");
		$plural = array("centavos", "reais", "mil", "milhões", "bilhões", "trilhões","quatrilhões");
		
		$c = array("", "cem", "duzentos", "trezentos", "quatrocentos", "quinhentos", "seiscentos", "setecentos", "oitocentos", "novecentos");
		$d = array("", "dez", "vinte", "trinta", "quarenta", "cinquenta", "sessenta", "setenta", "oitenta", "noventa");
		$d10 = array("dez", "onze", "doze", "treze", "quatorze", "quinze","dezesseis", "dezesete", "dezoito", "dezenove");
		$u = array("", "um", "dois", "três", "quatro", "cinco", "seis", "sete", "oito", "nove");
		
		$z = 0;
		$rt = "";
		
		$valor = number_format($valor, 2, ".", ".");
		$inteiro = explode(".", $valor);
		for($i=0;$i<count($inteiro);$i++)
		for($ii=strlen($inteiro[$i]);$ii<3;$ii++)
		$inteiro[$i] = "0".$inteiro[$i];
		$fim = count($inteiro) - ($inteiro[count($inteiro)-1] > 0 ? 1 : 2);
		
		for ($i=0;$i<count($inteiro);$i++) {
			$valor = $inteiro[$i];
			$rc = (($valor > 100) && ($valor < 200)) ? "cento" : $c[$valor[0]];
			$rd = ($valor[1] < 2) ? "" : $d[$valor[1]];
			$ru = ($valor > 0) ? (($valor[1] == 1) ? $d10[$valor[2]] : $u[$valor[2]]) : "";
			
			$r = $rc.(($rc && ($rd || $ru)) ? " e " : "").$rd.(($rd && $ru) ? " e " : "").$ru;
			$t = count($inteiro)-1-$i;
			$r .= $r ? " ".($valor > 1 ? $plural[$t] : $singular[$t]) : "";
			if ($valor == "000")$z++; elseif ($z > 0) $z–;
			if (($t==1) && ($z>0) && ($inteiro[0] > 0)) $r .= (($z>1) ? " de " : "").$plural[$t];
			if ($r) $rt = $rt . ((($i > 0) && ($i <= $fim) && ($inteiro[0] > 0) && ($z < 1)) ? ( ($i < $fim) ? ", " : " e ") : " ") . $r;
		}
		if(!$maiusculas){
			return($rt ? $rt : "zero");
		}else{
			if ($rt) $rt=ereg_replace(" E "," e ",ucwords($rt));
			return (($rt) ? ($rt) : "Zero");
		}								
	}
	
	public function horasTrabalhadas($empresa, $revenda, $mes, $ano){
		if ($empresa == "13" && $revenda == "1"){
			$emprev = "{$empresa}.{$revenda}";
			$calendario = "0001";
		}elseif ($empresa == "1" && $revenda == "1"){
			$emprev = "{$empresa}.{$revenda}";
			$calendario = "0001";
		}elseif ($empresa == "13" && $revenda == "2"){
			$emprev = "{$empresa}.{$revenda}";
			$calendario = "0019";
		}else{
			$calendario = "";
		}
		$at = cal_days_in_month(CAL_GREGORIAN, $mes, $ano)+1;
		$apiIndex = new apiIndex();
		$fe = $apiIndex->getCalendario("{$mes}/{$ano}", $calendario);
		$feriados = array();
		$f = 0;
		foreach ($fe as $r){
			$feriados[$f] = $r->DATAFERIADO;
			$f = $f+1;
		}
		$uteis = 0;
		$sabado = 0;
		for ($d=1;$d < $at;$d++){
			if((date('N',strtotime(implode("-",array_reverse(explode("/","{$d}/{$mes}/{$ano}")))))) == 6){
				if ((!in_array("".str_pad($d, 2, "0", STR_PAD_LEFT)."/{$mes}/{$ano}", $feriados))){
					$sabado = $sabado + 4;
				}
			}elseif ((date('N',strtotime(implode("-",array_reverse(explode("/","{$d}/{$mes}/{$ano}")))))) != 7){
				if ((!in_array("".str_pad($d, 2, "0", STR_PAD_LEFT)."/{$mes}/{$ano}", $feriados))){
					$uteis = $uteis + 8;
				}
			}
		}
		return $horas = $uteis + $sabado;
	}
	
	function in_array_r($needle, $haystack, $strict = false) {
		foreach ($haystack as $item) {
			if (($strict ? $item === $needle : $item == $needle) || (is_array($item) && in_array_r($needle, $item, $strict))) {
				return true;
			}
		}
		
		return false;
	}
}