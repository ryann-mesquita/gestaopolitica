<?php

namespace helper;

Class PrepareSQL {
	
	public function PrepareInsert($obj,$table,$seq = NULL, $currval = NULL, $multseq = NULL) {
		$variaveis = "";
		foreach ($obj as $key => $v){
			if (is_numeric("{$v}")){
				$variaveis .= "{$v},";
			}else{
				$v = str_replace("<str>", "", $v);
				$variaveis .= "'{$v}',";
			}
		}
		$variaveis = substr($variaveis,0,-1);
		if ($multseq != NULL) {
			$sql = "INSERT INTO {$table} ($seq,".implode(",",array_keys((array) $obj)).") VALUES (seq_".$multseq.".nextval,{$variaveis})";
		}elseif ($seq != NULL){
			$sql = "INSERT INTO {$table} ($seq,".implode(",",array_keys((array) $obj)).") VALUES (seq_".$table.".nextval,{$variaveis})";		
		}elseif ($currval != NULL) {
			$sql = "INSERT INTO {$table} ({$currval['coluna']},".implode(",",array_keys((array) $obj)).") VALUES (seq_".$currval['tabela'].".currval,{$variaveis})";
		}else{
			$sql = "INSERT INTO {$table} (".implode(",",array_keys((array) $obj)).") VALUES ({$variaveis})";
		}	
		return $sql;
	}

	public function PrepareUpdate($obj, $condition, $table,$in = NULL) {
		
		foreach ($obj as $ind => $val) {
			
			$dados[] = "{$ind} = " .(!is_null($val) ? is_numeric($val) ?  "{$val}" : "'".str_replace("<str>", "", $val)."'" : "NULL");
			
		}
		
		if ($in != NULL) {
			
			foreach ($condition as $ind => $val){
					
				$where[] = "{$ind} in ({$val})";
					
			}
			
		}else{
		
			foreach ($condition as $ind => $val){
	
				$where[] = "{$ind} " .(!is_null($val) ? is_numeric($val) ?  " = {$val}" : " = '".str_replace("<str>", "", $val)."'" : " IS NULL ");
					
			}
		}
		
		
		$sql = "UPDATE {$table} SET " . implode(',', $dados) . " WHERE " . implode(' AND ', $where);
		
		return $sql;
		
	}
	
	public function PrepareDelete($condition, $table) {
		
		foreach ($condition as $ind => $val){
			
			$where[] = "{$ind} " .(!is_null($val) ? is_numeric($val) ?  " = {$val}" : " = '".str_replace("<str>", "", $val)."'" : " IS NULL ");
			
		}
		
		$sql = "DELETE FROM {$table} WHERE " . implode(' AND ', $where);
		
		return $sql;
		
	}
}